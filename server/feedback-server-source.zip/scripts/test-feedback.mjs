import assert from 'node:assert/strict';
import { validateSubmission, sameOrigin } from '../lib/feedback-service.ts';
const good={id:'GY-12345678-1234-4234-8234-123456789abc',volume:5,anchor:'V5-F-TITLE-01',printed:'không đánh số',pdfPage:1,excerpt:'Đoạn thử',category:'question',message:'Xin đối chiếu chỗ này.',suggestion:'',reference:'',name:'',email:'',website:'',consent:true};
assert.equal(validateSubmission(good).volume,5);
for(const patch of [{volume:6},{pdfPage:0},{email:'bad-email'},{category:'script'},{message:''},{consent:false},{website:'spam'},{anchor:'../escape'},{id:'invalid'},{message:'x'.repeat(4001)}])assert.throws(()=>validateSubmission({...good,...patch}));
assert.equal(sameOrigin(new Request('https://example.test/api/feedback',{headers:{Origin:'https://example.test'}})),true);
assert.equal(sameOrigin(new Request('https://example.test/api/feedback',{headers:{Origin:'https://other.test'}})),false);
assert.equal(sameOrigin(new Request('https://example.test/api/feedback')),false);
console.log('Feedback validation and same-origin checks passed.');
