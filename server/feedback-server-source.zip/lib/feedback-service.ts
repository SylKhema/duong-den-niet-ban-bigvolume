export const categories = ['typo','translation','terminology','question','other'];
export const statuses = ['new','reviewing','needs-info','resolved','unchanged','duplicate'];
export function validateSubmission(raw: Record<string, unknown>) {
  const field=(key:string,max:number,required=false)=>{
    const v=raw[key]; if(typeof v!=='string' || v.length>max || (required&&!v.trim())) throw Error('Vui lòng kiểm tra trường '+key+'.');
    return v.trim();
  };
  const id=field('id',40,true);
  if(!/^GY-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(id))throw Error('Mã gửi không hợp lệ. Vui lòng mở lại biểu mẫu.');
  const volume=Number(raw.volume),pdfPage=Number(raw.pdfPage);
  if(!Number.isInteger(volume)||volume<1||volume>5||!Number.isInteger(pdfPage)||pdfPage<1||pdfPage>1000)throw Error('Vị trí trang không hợp lệ.');
  const category=field('category',30,true);if(!categories.includes(category))throw Error('Loại góp ý không hợp lệ.');
  const anchor=field('anchor',140,true);if(!/^[A-Za-z0-9_.:-]+$/.test(anchor))throw Error('Mã vị trí không hợp lệ.');
  const message=field('message',4000,true);if(message.length<5)throw Error('Vui lòng mô tả ý kiến rõ hơn (ít nhất 5 ký tự).');
  const email=field('email',254);if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw Error('Địa chỉ email chưa đúng.');
  if(raw.consent!==true)throw Error('Vui lòng xác nhận cho phép lưu ý kiến.');
  if(typeof raw.website!=='string'||raw.website!=='')throw Error('Không thể nhận yêu cầu này.');
  return {id,volume,anchor,printed:field('printed',80,true),pdfPage,excerpt:field('excerpt',2400),category,message,suggestion:field('suggestion',4000),reference:field('reference',1500),name:field('name',100),email};
}
export function sameOrigin(req:Request){return req.headers.get('origin')===new URL(req.url).origin;}
export function json(value:unknown,status=200){return Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});}
