import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../../chatgpt-auth';
import { json, sameOrigin, statuses } from '../../../lib/feedback-service';
export const dynamic='force-dynamic';
async function allowed(){const user=await getChatGPTUser();const address=(env as unknown as {REVIEWER_EMAIL?:string}).REVIEWER_EMAIL;return !!user&&!!address&&user.email.toLowerCase()===address.toLowerCase();}
const db=()=> (env as unknown as {DB:D1Database}).DB;
export async function GET(req:Request){
  if(!await allowed())return json({error:'Chỉ người phụ trách đã được cấp quyền mới xem được góp ý.'},403);
  const u=new URL(req.url);const offset=Math.max(0,Math.min(100000,Number(u.searchParams.get('offset'))||0));
  const result=await db().prepare('SELECT * FROM feedback ORDER BY created_at DESC LIMIT 100 OFFSET ?').bind(offset).all();
  return json({entries:result.results,nextOffset:result.results.length===100?offset+100:null});
}
export async function PATCH(req:Request){
  if(!await allowed()||!sameOrigin(req))return json({error:'Không có quyền cập nhật.'},403);
  if(Number(req.headers.get('content-length')||0)>18000)return json({error:'Nội dung quá dài.'},413);
  let b;try{const raw=await req.text();if(raw.length>18000)throw Error();b=JSON.parse(raw);}catch{return json({error:'Dữ liệu chưa đúng.'},400);}
  if(typeof b.id!=='string'||!/^GY-[0-9a-f-]{36}$/.test(b.id)||!statuses.includes(b.status)||typeof b.editorial_note!=='string'||b.editorial_note.length>4000||typeof b.public_note!=='string'||b.public_note.length>4000||typeof b.published!=='boolean')return json({error:'Dữ liệu cập nhật chưa đúng.'},400);
  if(b.published&&(!['resolved','unchanged'].includes(b.status)||b.public_note.trim().length<10))return json({error:'Chỉ công bố sau khi đã xử lý và có giải thích công khai.'},400);
  const r=await db().prepare('UPDATE feedback SET status=?,editorial_note=?,public_note=?,published=?,updated_at=? WHERE id=?').bind(b.status,b.editorial_note.trim(),b.public_note.trim(),b.published?1:0,new Date().toISOString(),b.id).run();
  return r.meta.changes?json({saved:true}):json({error:'Không tìm thấy góp ý.'},404);
}
