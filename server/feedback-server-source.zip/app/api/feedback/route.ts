import { env } from 'cloudflare:workers';
import { validateSubmission, sameOrigin, json } from '../../../lib/feedback-service';
export const dynamic='force-dynamic';
const db=()=> (env as unknown as {DB:D1Database}).DB;
export async function POST(req:Request){
  if(!sameOrigin(req)||!req.headers.get('content-type')?.startsWith('application/json'))return json({error:'Yêu cầu không hợp lệ.'},403);
  if(Number(req.headers.get('content-length')||0)>24000)return json({error:'Ý kiến quá dài.'},413);
  let value;
  try {const body=await req.text();if(body.length>24000)return json({error:'Ý kiến quá dài.'},413);value=validateSubmission(JSON.parse(body));}catch(e){return json({error:e instanceof Error?e.message:'Dữ liệu chưa hợp lệ.'},400);}
  try {
    const existing=await db().prepare('SELECT id FROM feedback WHERE id=?').bind(value.id).first();
    if(existing)return json({id:value.id,status:'new',received:true});
    const recent=await db().prepare('SELECT count(*) AS n FROM feedback WHERE created_at>?').bind(new Date(Date.now()-60000).toISOString()).first<{n:number}>();
    if((recent?.n||0)>=50)return json({error:'Hệ thống đang nhận nhiều góp ý. Vui lòng thử lại sau một phút.'},429);
    const now=new Date().toISOString();
    await db().prepare('INSERT INTO feedback (id,created_at,updated_at,volume,anchor,printed,pdf_page,excerpt,category,message,suggestion,reference,name,email,status,editorial_note,public_note,published) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(value.id,now,now,value.volume,value.anchor,value.printed,value.pdfPage,value.excerpt,value.category,value.message,value.suggestion,value.reference,value.name,value.email,'new','','',0).run();
    return json({id:value.id,status:'new',received:true},201);
  }catch{ return json({error:'Chưa lưu được ý kiến. Vui lòng giữ nội dung và thử gửi lại; chưa có xác nhận tiếp nhận.'},503); }
}
export async function GET(req:Request){
  const id=new URL(req.url).searchParams.get('id')||'';
  if(!/^GY-[0-9a-f-]{36}$/.test(id))return json({error:'Mã tra cứu chưa đúng.'},400);
  try {const row=await db().prepare('SELECT id,status,created_at,updated_at FROM feedback WHERE id=?').bind(id).first();return row?json(row):json({error:'Không tìm thấy mã này.'},404);}catch{return json({error:'Chưa thể tra cứu. Vui lòng thử lại sau.'},503);}
}
