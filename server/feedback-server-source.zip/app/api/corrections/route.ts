import { env } from 'cloudflare:workers';
import { json } from '../../../lib/feedback-service';
export const dynamic='force-dynamic';
export async function GET(){try {
  const db=(env as unknown as {DB:D1Database}).DB;
  const result=await db.prepare('SELECT id,volume,printed,pdf_page,anchor,status,public_note,updated_at FROM feedback WHERE published=1 AND status IN (?,?) ORDER BY updated_at DESC LIMIT 100').bind('resolved','unchanged').all();
  return json({entries:result.results});
}catch{return json({error:'Chưa tải được nhật ký hiệu đính.'},503);}}
