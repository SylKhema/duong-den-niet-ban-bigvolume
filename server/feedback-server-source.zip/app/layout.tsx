import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Đường Đến Niết-bàn — Bộ Đại I–V",
  description: "Thư viện năm tập và hệ thống góp ý hiệu đính.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi">
      <body className="antialiased">{children}</body>
    </html>
  );
}
