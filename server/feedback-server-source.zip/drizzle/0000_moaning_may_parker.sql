CREATE TABLE `feedback` (
	`id` text PRIMARY KEY NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`volume` integer NOT NULL,
	`anchor` text NOT NULL,
	`printed` text NOT NULL,
	`pdf_page` integer NOT NULL,
	`excerpt` text NOT NULL,
	`category` text NOT NULL,
	`message` text NOT NULL,
	`suggestion` text NOT NULL,
	`reference` text NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`status` text NOT NULL,
	`editorial_note` text NOT NULL,
	`public_note` text NOT NULL,
	`published` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `feedback_created_idx` ON `feedback` (`created_at`);