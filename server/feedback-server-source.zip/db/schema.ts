// Intentionally empty by default.
// Add Drizzle tables here when the site actually needs a database.
// See examples/d1/db/schema.ts for an opt-in example.
import { sqliteTable, text, integer, index } from "drizzle-orm/sqlite-core";
export const feedback = sqliteTable("feedback", {
  id: text("id").primaryKey(),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
  volume: integer("volume").notNull(),
  anchor: text("anchor").notNull(),
  printed: text("printed").notNull(),
  pdfPage: integer("pdf_page").notNull(),
  excerpt: text("excerpt").notNull(),
  category: text("category").notNull(),
  message: text("message").notNull(),
  suggestion: text("suggestion").notNull(),
  reference: text("reference").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  status: text("status").notNull(),
  editorialNote: text("editorial_note").notNull(),
  publicNote: text("public_note").notNull(),
  published: integer("published").notNull().default(0),
}, table => [index("feedback_created_idx").on(table.createdAt)]);
