# Nibbānagāminipaṭipadā · Mini · Cuốn 7 / Volume 7
Conditional Relations According to the Paṭṭhāna
Pa-Auk Tawya Sayadaw
English

## Mục lục / Contents

- [Front and back covers](#M07-cover-P001)
- [Title page](#M07-front-P001)
- [The gift of Dhamma and the aspiration](#M07-front-P002)
- [Original table of contents · first page](#M07-front-P003)
- [Original table of contents · page 2](#M07-front-P004)
- [Original table of contents · page 3](#M07-front-P005)
- [Original table of contents · page 4](#M07-front-P006)
- [Attaining clear comprehension without delusion](#M07-body-P001)
- [Preparation and the great conascence group](#M07-body-P002)
- [Conditioned phenomena of the great and intermediate conascence groups](#M07-body-P003)
- [Result, association, dissociation and root conditions](#M07-body-P004)
- [The minor conascence group, continued](#M07-body-P005)
- [Path condition and the object group](#M07-body-P006)
- [Prenascence conditions and the proximity group](#M07-body-P007)
- [The physical base and postnascence groups](#M07-body-P008)
- [Asynchronous kamma, material nutriment and material life faculty](#M07-body-P009)
- [Natural decisive support and summary](#M07-body-P010)
- [Summary of proximity, base, postnascence and asynchronous kamma](#M07-body-P011)
- [Points to understand before discernment](#M07-body-P012)
- [Kamma-born materiality at three-rooted sense-sphere rebirth-linking](#M07-body-P013)
- [Twenty-five conditions for rebirth-linking materiality apart from the heart-base](#M07-body-P014)
- [Materiality at joyful and equanimous rebirth-linking](#M07-body-P015)
- [Twenty-five conditions for the heart-base at rebirth-linking](#M07-body-P016)
- [Groups conditioning the heart-base, continued](#M07-body-P017)
- [The four mental aggregates at three-rooted sense-sphere rebirth-linking](#M07-body-P018)
- [Object, proximity and kamma conditioning rebirth-linking mentality](#M07-body-P019)
- [The material aggregate among the five life-continuum aggregates](#M07-body-P020)
- [Twenty-four conditions for materiality born of life-continuum consciousness](#M07-body-P021)
- [Kamma-born materiality co-arising at the life-continuum submoments](#M07-body-P022)
- [Conditions for kamma-, temperature- and nutriment-born materiality during life-continuum](#M07-body-P023)
- [Temperature- and nutriment-born materiality. Meaning of yathārahaṃ](#M07-body-P024)
- [Support as applicable and the four life-continuum mental aggregates](#M07-body-P025)
- [Twenty-six conditions for life-continuum mentality](#M07-body-P026)
- [Object, proximity and the heart-base conditioning life-continuum](#M07-body-P027)
- [Asynchronous kamma for life-continuum. The five aggregates at death](#M07-body-P028)
- [Materiality at death and the four death mental aggregates](#M07-body-P029)
- [Mental conascence and object conditions at death](#M07-body-P030)
- [Proximity at death and materiality in five-door processes](#M07-body-P031)
- [The five aggregates of five-door adverting](#M07-body-P032)
- [Twenty-one conditions for materiality born of five-door adverting](#M07-body-P033)
- [Kamma-born materiality simultaneous with five-door adverting](#M07-body-P034)
- [Temperature- and nutriment-born materiality simultaneous with five-door adverting](#M07-body-P035)
- [Summary of the 54 sense-sphere consciousnesses in the five-door process](#M07-body-P036)
- [Twenty-five conditions for five-door adverting mentality](#M07-body-P037)
- [Conditions for five-door adverting. Materiality at eye-consciousness](#M07-body-P038)
- [Kamma-, temperature- and nutriment-born materiality at eye-consciousness](#M07-body-P039)
- [Twenty-eight conditions for eye-consciousness mentality](#M07-body-P040)
- [The physical base for eye-consciousness. The receiving material aggregate](#M07-body-P041)
- [Twenty-two conditions for materiality born of receiving](#M07-body-P042)
- [Twenty-eight conditions for receiving mentality](#M07-body-P043)
- [Conditions for receiving. The investigating material aggregate](#M07-body-P044)
- [Twenty-two conditions for materiality born of investigating](#M07-body-P045)
- [Twenty-eight conditions for investigating mentality](#M07-body-P046)
- [Conditions for investigating. The determining material aggregate](#M07-body-P047)
- [Twenty-one conditions for materiality born of determining](#M07-body-P048)
- [Twenty-five conditions for determining mentality](#M07-body-P049)
- [Conditions for determining. Materiality of the first great wholesome impulsion](#M07-body-P050)
- [Mental aggregates conditioning materiality of the first great wholesome impulsion](#M07-body-P051)
- [Mental aggregates of the first great wholesome impulsion](#M07-body-P052)
- [Thirteen mental conascence conditions of the first great wholesome impulsion](#M07-body-P053)
- [From the first to the second great wholesome impulsion](#M07-body-P054)
- [Mental conascence of the second great wholesome impulsion](#M07-body-P055)
- [Conditions for the second and later great wholesome impulsions](#M07-body-P056)
- [The five aggregates and mentality of unwholesome impulsion](#M07-body-P057)
- [Root, predominance, faculty, jhāna and path in unwholesome impulsion](#M07-body-P058)
- [Subsequent unwholesome impulsions. The five registration aggregates](#M07-body-P059)
- [Materiality born of the first rooted registration](#M07-body-P060)
- [Conditions for registration-born materiality and the great resultant mental aggregates](#M07-body-P061)
- [Thirty conditions for rooted registration mentality](#M07-body-P062)
- [Object, physical base and kamma conditioning rooted registration](#M07-body-P063)
- [Materiality born of the first rootless registration](#M07-body-P064)
- [Rootless registration and the other five-door processes](#M07-body-P065)
- [Five-door objects and mind-door processes with sense-sphere impulsion](#M07-body-P066)
- [The five aggregates of mind-door adverting](#M07-body-P067)
- [Object, proximity and base conditions for mind-door adverting](#M07-body-P068)
- [The first knowledge-associated great wholesome mind-door impulsion](#M07-body-P069)
- [Mental conascence in knowledge-associated great wholesome impulsion](#M07-body-P070)
- [Ordinary and esteemed objects, and proximity](#M07-body-P071)
- [Heart-base, natural decisive support and knowledge-dissociated great wholesome impulsion](#M07-body-P072)
- [Condition groups of knowledge-dissociated great wholesome impulsion](#M07-body-P073)
- [Esteemed objects and conditioning factors in knowledge-dissociated consciousness](#M07-body-P074)
- [Rooted great resultant registration in the mind-door process](#M07-body-P075)
- [Kamma conditioning registration and the rootless registration group](#M07-body-P076)
- [Rootless registration and the physical base near death](#M07-body-P077)
- [Greed-rooted impulsion mentality at the mind door](#M07-body-P078)
- [Predominance, faculty, jhāna, path and ordinary objects of greed-rooted impulsion](#M07-body-P079)
- [Esteemed objects of greed-rooted impulsion](#M07-body-P080)
- [Proximity, base and natural decisive support in greed-rooted impulsion](#M07-body-P081)
- [Hatred-rooted and delusion-rooted impulsion, and smile-producing consciousness](#M07-body-P082)
- [Smile-producing consciousness in the five-door process](#M07-body-P083)
- [Conditions for five-door smile-producing impulsion](#M07-body-P084)
- [Smile-producing impulsion at the mind door](#M07-body-P085)
- [Mental conascence and objects of smile-producing consciousness at the mind door](#M07-body-P086)
- [From smile-producing to knowledge-associated great functional impulsion](#M07-body-P087)
- [Mental conascence of the first great functional impulsion](#M07-body-P088)
- [Faculty, jhāna, path and objects of great functional impulsion](#M07-body-P089)
- [Near-death and esteemed objects of great functional impulsion](#M07-body-P090)
- [Sense-sphere and absorption impulsions](#M07-body-P091)
- [Functional absorption types and exalted wholesome processes](#M07-body-P092)
- [Attainment entry and conditions for exalted wholesome mentality](#M07-body-P093)
- [Mental conascence in the nine exalted wholesome impulsions](#M07-body-P094)
- [Conceptual objects conditioning fine-material jhāna](#M07-body-P095)
- [Object condition for the fifth fine-material jhāna and the immaterial attainments](#M07-body-P096)
- [Proximity conditions for exalted wholesome impulsion](#M07-body-P097)
- [Physical-base conditions for exalted wholesome impulsion](#M07-body-P098)
- [Natural decisive support and the mental aggregates of exalted functional impulsion](#M07-body-P099)
- [Conascence conditions of exalted functional impulsion](#M07-body-P100)
- [Path factors and objects of exalted functional impulsion](#M07-body-P101)
- [Immaterial objects and the proximity group](#M07-body-P102)
- [Proximity and physical-base groups](#M07-body-P103)
- [Natural decisive support and the mental aggregates of noble-path impulsion](#M07-body-P104)
- [Conascence conditions of noble-path impulsion](#M07-body-P105)
- [Nibbāna as object and conditions supporting the noble path](#M07-body-P106)
- [Natural decisive support for the four noble paths](#M07-body-P107)
- [Fruition attainment and the arising of the 20 fruition impulsions immediately after the path](#M07-body-P108)
- [Conascence, object and proximity conditions of fruition immediately after the path](#M07-body-P109)
- [Physical-base and natural decisive support conditions of fruition immediately after the path](#M07-body-P110)
- [Fruition impulsions in fruition attainment](#M07-body-P111)
- [Distinguishing fruition immediately after the path from fruition attainment](#M07-body-P112)
- [Groups of conditions for fruition impulsions distinct from fruition immediately after the path](#M07-body-P113)
- [Jhāna, path, object and proximity conditions in fruition attainment](#M07-body-P114)
- [Proximity conditions of lower fruition and arahant fruition impulsions](#M07-body-P115)
- [Proximity conditions of arahant fruition impulsion](#M07-body-P116)
- [Conditions upon emerging from cessation and physical-base conditions](#M07-body-P117)
- [Physical-base conditions of lower fruition and arahant fruition](#M07-body-P118)
- [Physical-base conditions of arahant fruition and of emergence from cessation](#M07-body-P119)
- [Asynchronous kamma and natural decisive support of fruition impulsion](#M07-body-P120)
- [Natural decisive support of arahant fruition and the journey through saṃsāra](#M07-body-P121)
- [Discerning across lives and the arising of rootless rebirth-linking](#M07-body-P122)
- [Cases of rebirth-linking through rootless wholesome result](#M07-body-P123)
- [Condition groups and mental conascence at rootless rebirth-linking](#M07-body-P124)
- [Material conascence, object, proximity and asynchronous kamma at rootless rebirth-linking](#M07-body-P125)
- [How rootless life-continuum arises](#M07-body-P126)
- [Object, proximity and physical-base conditions of rootless life-continuum](#M07-body-P127)
- [Physical-base and asynchronous kamma conditions of rootless life-continuum](#M07-body-P128)
- [How rootless death arises](#M07-body-P129)
- [Object, proximity, physical-base and kamma conditions of rootless death](#M07-body-P130)
- [How two-rooted sense-sphere rebirth-linking arises](#M07-body-P131)
- [Mental conascence, material conascence and object at two-rooted rebirth-linking](#M07-body-P132)
- [Two-rooted rebirth-linking and life-continuum](#M07-body-P133)
- [Mental conascence, object and proximity of two-rooted life-continuum](#M07-body-P134)
- [Proximity and physical-base conditions of two-rooted life-continuum](#M07-body-P135)
- [Kamma supporting life-continuum and the arising of two-rooted death](#M07-body-P136)
- [Conditions supporting two-rooted death](#M07-body-P137)
- [Two-rooted death and conditions supporting fine-material rebirth-linking](#M07-body-P138)
- [Mental conascence and jhāna factors at fine-material rebirth-linking](#M07-body-P139)
- [Path factors, material conascence and objects of fine-material rebirth-linking](#M07-body-P140)
- [Objects and conditions supporting fine-material rebirth-linking](#M07-body-P141)
- [How fine-material life-continuum arises](#M07-body-P142)
- [Jhāna factors, path factors and objects of fine-material life-continuum](#M07-body-P143)
- [Objects and proximity conditions of fine-material life-continuum](#M07-body-P144)
- [Proximity, physical-base and kamma conditions of fine-material life-continuum](#M07-body-P145)
- [How fine-material death arises](#M07-body-P146)
- [Jhāna factors, path factors, objects and proximity of fine-material death](#M07-body-P147)
- [Conditions supporting fine-material death and immaterial rebirth-linking](#M07-body-P148)
- [Mental conascence and objects of immaterial rebirth-linking](#M07-body-P149)
- [Object, proximity and kamma conditions of immaterial rebirth-linking](#M07-body-P150)
- [How immaterial life-continuum arises](#M07-body-P151)
- [Jhāna factors, path factors and objects of immaterial life-continuum](#M07-body-P152)
- [Proximity for immaterial life-continuum and the arising of immaterial death](#M07-body-P153)
- [Mental conascence and objects of immaterial death](#M07-body-P154)
- [Object, proximity and kamma conditions of immaterial death](#M07-body-P155)
- [Kamma-born materiality of non-percipient beings](#M07-body-P156)
- [Alphabetical index of points to remember](#M07-index-P001)
- [Alphabetical index of points to remember](#M07-index-P002)
- [Alphabetical index of points to remember](#M07-index-P003)
- [Alphabetical index of points to remember](#M07-index-P004)
- [Alphabetical index of points to remember](#M07-index-P005)
- [Alphabetical index of points to remember](#M07-index-P006)
- [Alphabetical index of points to remember](#M07-index-P007)

<a id="M07-cover-P001"></a>
## Front and back covers
Bìa / Cover

Nibbānagāminipaṭipadā — The Practice Leading to Nibbāna (Abridged). Volume 7. Conditional Relations According to the Paṭṭhāna. Pa-Auk Tawya Sayadaw.

Excerpt from the Gotamakacetiya Sutta.

Bhikkhus … I teach the Dhamma only after personally knowing and penetrating it by direct knowledge. I do not teach it without having personally known and penetrated it. Bhikkhus … I teach the Dhamma with grounds and reasons, not without grounds and reasons. Bhikkhus … I teach the Dhamma that has the power to remove what opposes it, not teachings without that power.

Bhikkhus … I teach the Dhamma only after personally knowing and penetrating it by direct knowledge, and do not teach without knowing and penetrating it. I teach the Dhamma with grounds and reasons, not without grounds and reasons. I teach the Dhamma that has the power to remove what opposes it, not teachings lacking that power. I have given you exhortation (ovāda) and have also given you instruction repeatedly (anusāsanī).

Bhikkhus … you should gladly accept that “The Blessed One possesses the quality of perfect awakening. The Dhamma possesses the quality of being well taught. The noble Saṅgha possesses the quality of practicing well.” You should be glad at heart. You should let joy and glad feeling (somanassa) arise. Thus the Buddha taught. (Aṅguttara, vol. 1, p. 280.)


<a id="M07-front-P001"></a>
## Title page
Đầu sách / Front matter - 1

Nibbānagāminipaṭipadā. The Practice Leading to Nibbāna (Abridged), Volume 7. Conditional Relations According to the Paṭṭhāna. Pa-Auk Tawya Sayadaw.


<a id="M07-front-P002"></a>
## The gift of Dhamma and the aspiration
Đầu sách / Front matter - 2

Sabbadānaṃ dhammadānaṃ jināti,
Sabbarasaṃ dhammaraso jināti;
Sabbaratiṃ dhammarati jināti,
Taṇhakkhayo sabbadukkhaṃ jināti.

The gift of Dhamma surpasses every gift.
The taste of Dhamma surpasses every taste.
Delight in Dhamma surpasses every delight.
The ending of craving overcomes all suffering.

Ciraṃ tiṭṭhatu saddhammo, dhamme hontu sagāravā.

May the Buddha’s teaching and dispensation long endure. May all hold the three aspects of the true Dhamma in respect.


<a id="M07-front-P003"></a>
## Original table of contents · first page
Đầu sách / Front matter - 3

Namo tassa bhagavato arahato sammāsambuddhassa.

Attaining clear comprehension without delusion — 1

The twenty-four Paṭṭhāna conditions. Great conascence group (4) — 2

Intermediate conascence group (4) — 3

Minor conascence group (7) — 4

Object conditions, eight or eleven kinds — 6

Proximity group, seven kinds — 7

Physical base group, six kinds — 8

Postnascence group, four kinds — 8

Asynchronous kamma group, six kinds — 9

Material nutriment group, three kinds — 9

Material life faculty group, three kinds — 9

Natural decisive support condition (1) — 10

Summary of the essential meaning — 10

Points to understand beforehand — 12

How kamma-born materiality arises at three-rooted sense-sphere rebirth-linking — 13

How the four mental aggregates arise at three-rooted sense-sphere rebirth-linking — 18

The material aggregate of the life-continuum among its five aggregates — 20

How kamma-born materiality during life arises and persists at the arising, presence and dissolution submoments of life-continuum consciousness — 22

How temperature-born and nutriment-born materiality arise and persist at the arising, presence and dissolution submoments of life-continuum consciousness — 23


<a id="M07-front-P004"></a>
## Original table of contents · page 2
Đầu sách / Front matter - 4

Yathārahaṃ — as appropriate — 24

How the four mental aggregates of three-rooted sense-sphere life-continuum arise and persist — 25

The five death aggregates — three-rooted sense-sphere death — 28

How the four mental aggregates of three-rooted sense-sphere death arise — 29

How materiality in the five-door process arises and persists — 31

The five aggregates of five-door adverting — 32

How consciousness-born materiality from the mental aggregates of five-door adverting arises and persists — 32

How kamma-born materiality during life, co-arising at the arising, presence and dissolution submoments of five-door adverting consciousness, arises and persists — 34

How temperature-born and nutriment-born materiality, co-arising at the arising, presence and dissolution submoments of five-door adverting consciousness, arises and persists — 35

Summary for memorization — classifying the 54 sense-sphere consciousnesses by five-door processes — 36

The mental aggregates of five-door adverting — 37

The five aggregates of eye-consciousness — kamma-born materiality during life — 38

Temperature-born and nutriment-born materiality — 39

How the mental aggregates of eye-consciousness arise and persist — 39

The five aggregates of receiving — the receiving material aggregate — 41

The mental aggregates of receiving — 43

The five aggregates of investigating — investigating — consciousness-born materiality — 44

The mental aggregates of investigating — 46

The five aggregates of determining — determining mental aggregates — consciousness-born materiality (material aggregate) — 47

How the mental aggregates of determining arise and persist — 48

The five aggregates of the first great wholesome impulsion (in the five-door process). The material aggregate of the first great wholesome impulsion — 50

How the mental aggregates of the first great wholesome impulsion arise and persist…


<a id="M07-front-P005"></a>
## Original table of contents · page 3
Đầu sách / Front matter - 5

… (in the five-door process) — 52

The mental aggregates of the second great wholesome impulsion (in the five-door process) — 54

The five aggregates of unwholesome impulsion — 57

How the mental aggregates of unwholesome impulsion arise and persist (in the five-door process) — 57

The five aggregates of registration — 59

The mental aggregates of the first rooted registration. How consciousness-born materiality arises and persists — 60

How the mental aggregates of rooted great-resultant registration arise and persist — 61

The mental aggregates of the first rootless registration. How consciousness-born materiality arises and persists — 64

How consciousness in the mind-door process with sense-sphere impulsion arises and persists — 66

The five aggregates of mind-door adverting — the mental aggregates of mind-door adverting — 67

2. Object group — 67

3. Proximity group — 68

4. Physical-base group — 68

How the mental aggregates of the first knowledge-associated great wholesome impulsion at the mind door arise and persist — 69

The mental aggregates of knowledge-dissociated great wholesome impulsion — 72

Object group — 73

The mental aggregates of rooted great-resultant registration — 75

The mental aggregates of the three kinds of rootless registration — 76

Physical-base group at the approach of death — 77

The mental aggregates of greed-rooted impulsion at the mind door — 78

How the mental aggregates of hatred-rooted and delusion-rooted impulsion at the mind door arise and persist — 82

How the mental aggregates of smile-producing impulsion in the five-door process arise and persist — 82

The mental aggregates of smile-producing impulsion at the mind door — 85

The mental aggregates of great functional impulsion — 87


<a id="M07-front-P006"></a>
## Original table of contents · page 4
Đầu sách / Front matter - 6

Absorption impulsion — sense-sphere impulsion and absorption impulsion in the mind-door process — 91

The exalted wholesome impulsion process — 92

The exalted wholesome impulsion process at initial attainment — 92

The exalted wholesome impulsion process at attainment entry — 93

The mental aggregates of exalted wholesome impulsion — 93

The mental aggregates of exalted functional impulsion — 99

The mental aggregates of noble-path impulsion — 104

Fruition attainment — how the 20 kinds of fruition impulsion immediately after the path arise — 108

How the 20 kinds of fruition impulsion in fruition attainment arise — 111

A point to note carefully — 112

Throughout the journey through saṃsāra — 121

How rootless rebirth-linking arises — 122

How rootless life-continuum arises — 126

How rootless death arises — 129

How two-rooted sense-sphere rebirth-linking arises — 131

How the mental aggregates of two-rooted life-continuum arise — 133

How the mental aggregates of two-rooted death arise — 136

How the mental aggregates of fine-material rebirth-linking arise — 138

How fine-material life-continuum arises — 142

How fine-material death arises — 146

How immaterial rebirth-linking arises — 148

How immaterial life-continuum arises — 151

How immaterial death arises — 153

Kamma-born materiality of non-percipient beings — 156


<a id="M07-body-P001"></a>
## Attaining clear comprehension without delusion
Miến / Burmese 1

Conditional Relations According to the Paṭṭhāna.

Namo tassa bhagavato arahato sammāsambuddhassa.

Evamettha khandhāyatanadhātupaccayapaccavekkhaṇavasenapi asammohasampajaññaṃ veditabbaṃ. (Majjhima Commentary I, p. 268.)

Here, clear comprehension without delusion should also be understood by reviewing the aggregates, bases, elements and conditions.

This section on clear comprehension without delusion presents four methods: (1) by the five aggregates, (2) by the twelve bases, (3) by the eighteen elements, and (4) by examining conditional relations according to the Paṭṭhāna.

The great commentators instructed practitioners to exert themselves by these methods to attain knowledge of clear comprehension without delusion. In accordance with their guidance, this section on conditional relations according to the Paṭṭhāna explains how to examine and discern causal phenomena by the Paṭṭhāna method. It is intended for good people who wish to broaden their understanding through the way the Paṭṭhāna presents the teaching.


<a id="M07-body-P002"></a>
## Preparation and the great conascence group
Miến / Burmese 2

Anyone wishing to study this section should memorize the Explanation of the Conditions (Paccayaniddesa) in the Paṭṭhāna Pāḷi, its Burmese rendering and the essential meaning of the text. This makes it possible to understand more clearly the nature of the causal relationships set out in the Paṭṭhāna. After studying in this way, memorize the twenty-four Paṭṭhāna conditions presented below.

The twenty-four conditions are presented according to the method handed down by successive teachers, as recorded in the abridged explanation of the Paṭṭhāna by the venerable elder Masoeyein Sayadaw, holder of the title Abhidhajamahāraṭṭhaguru.

Namo Buddhāya.

The twenty-four Paṭṭhāna conditions. The great conascence group comprises four conditions.

The conditioning phenomena for conascence, dependence, presence and non-disappearance conditions are:

1. The eighty-nine consciousnesses and fifty-two mental factors, comprising the four mental aggregates in the course of life and at rebirth-linking, support one another.
2. The four great elements support one another.
3. The four mental aggregates and the heart-base at rebirth-linking in the five-aggregate realm support one another.


<a id="M07-body-P003"></a>
## Conditioned phenomena of the great and intermediate conascence groups
Miến / Burmese 3

4. The mental aggregates support consciousness-born materiality and kamma-born materiality at rebirth-linking. They comprise seventy-five consciousnesses, excluding the four immaterial resultant consciousnesses, the ten types of double fivefold sense consciousness and the death consciousness of arahants in the five-aggregate realm, together with the fifty-two mental factors, that is, the four mental aggregates in the course of life and at rebirth-linking.
5. The four great elements support derived materiality.

The conditionally arisen phenomena are: (1) the eighty-nine consciousnesses and fifty-two mental factors, comprising the four mental aggregates in the course of life and at rebirth-linking, supported by one another, (2) the four great elements supported by one another, (3) the four mental aggregates and the heart-base at rebirth-linking in the five-aggregate realm, supported by one another, (4) consciousness-born materiality and kamma-born materiality at rebirth-linking, supported by the mental aggregates, and (5) derived materiality supported by the great elements.

The intermediate conascence group comprises four conditions.

For mutuality condition (aññamaññapaccaya), the conditioning phenomena are precisely those in conascence (1), (2) and (3). The conditionally arisen phenomena are precisely those in conascence (1), (2) and (3).

For result condition (vipākapaccaya), the conditioning phenomena are: (1) the thirty-six resultant consciousnesses and thirty-eight mental factors, comprising the four mental aggregates in the course of life and at rebirth-linking, supporting one another, and (2) resultant mental aggregates supporting materiality born of resultant consciousness and kamma-born materiality at rebirth-linking in the five-aggregate realm…


<a id="M07-body-P004"></a>
## Result, association, dissociation and root conditions
Miến / Burmese 4

… these are the twenty-two resultant consciousnesses, excluding the four immaterial resultant consciousnesses, the ten types of double fivefold sense consciousness and the death consciousness of arahants, together with the thirty-eight mental factors, comprising the four mental aggregates in the course of life and at rebirth-linking. (3) The four mental aggregates at rebirth-linking in the five-aggregate realm support the heart-base.

The conditionally arisen phenomena of result condition are: (1) the thirty-six resultant consciousnesses and thirty-eight mental factors, comprising the four mental aggregates in the course of life and at rebirth-linking, supported by one another, (2) consciousness-born materiality and kamma-born materiality at rebirth-linking supported by the resultant mental aggregates, and (3) the heart-base supported by the rebirth-linking mental aggregates in the five-aggregate realm.

For association condition (sampayuttapaccaya), the conditioning phenomena are precisely those in conascence (1). The conditionally arisen phenomena are precisely those in conascence (1).

For dissociation condition (vippayuttapaccaya), the conditioning phenomena are those in conascence (3) and (4). The conditionally arisen phenomena are precisely those in conascence (3) and (4).

The minor conascence group comprises seven conditions. For root condition (hetupaccaya), the conditioning phenomena are greed, hatred, delusion, non-greed, non-hatred and non-delusion.


<a id="M07-body-P005"></a>
## The minor conascence group, continued
Miến / Burmese 5

The conditionally arisen phenomena of root condition are rooted consciousness, the fifty-two mental factors apart from delusion in the two delusion-rooted consciousnesses, materiality born of rooted consciousness, and kamma-born materiality at rooted rebirth-linking.

For predominance condition (adhipatipaccaya), the conditioning phenomenon is one of zeal, energy, consciousness and investigation when it acts as predominant. The conditionally arisen phenomena are the fifty-two impulsion consciousnesses capable of having a predominance, excluding the two delusion-rooted consciousnesses and smile-producing consciousness, the fifty-one mental factors excluding doubt, and materiality produced by consciousness with a predominance.

For kamma condition (kammapaccaya), the conditioning phenomenon is volition. The conditionally arisen phenomena are the eighty-nine consciousnesses, the fifty-one mental factors other than volition, consciousness-born materiality and kamma-born materiality at rebirth-linking.

For nutriment condition (āhārapaccaya), the conditioning phenomena are contact, volition and consciousness. The conditionally arisen phenomena are the eighty-nine consciousnesses, fifty-two mental factors, consciousness-born materiality and kamma-born materiality at rebirth-linking.

For faculty condition (indriyapaccaya), the conditioning phenomena are life, consciousness, feeling, faith, energy, mindfulness, one-pointedness and wisdom. The conditionally arisen phenomena are the eighty-nine consciousnesses, fifty-two mental factors, consciousness-born materiality and kamma-born materiality at rebirth-linking.

For jhāna condition (jhānapaccaya), the conditioning phenomena are applied thought, sustained thought, joy, feeling and one-pointedness. The conditionally arisen phenomena are the seventy-nine consciousnesses other than the ten types of double fivefold sense consciousness, together with the fifty-two mental factors, consciousness-born materiality and kamma-born materiality at rebirth-linking.


<a id="M07-body-P006"></a>
## Path condition and the object group
Miến / Burmese 6

For path condition (maggapaccaya), the conditioning phenomena are wisdom, applied thought, right speech, right action, right livelihood, energy, mindfulness, one-pointedness and wrong view. The conditioned phenomena are 71 rooted consciousnesses, 52 mental factors, materiality born of rooted consciousness and kamma-born materiality at rooted rebirth-linking.

The object group has eight or eleven kinds.

For object condition (ārammaṇapaccaya), the conditioning phenomena are the six objects. Put another way, they are the 89 consciousnesses, 52 mental factors and 28 material phenomena of the present, past or future, and Nibbāna and concepts, which are independent of time. The conditioned phenomena are 89 consciousnesses and 52 mental factors.

For object predominance and object decisive support, the conditioning phenomena are the 18 desirable concretely produced material phenomena of the present, past or future that are held in esteem, 84 consciousnesses excluding the two hatred-rooted, two delusion-rooted and painful body consciousness, 47 mental factors excluding hatred, envy, stinginess, remorse and doubt, and timeless Nibbāna. The conditioned phenomena are eight greed-rooted consciousnesses, eight great wholesome consciousnesses, four great functional consciousnesses associated with knowledge, eight supramundane consciousnesses, and 45 mental factors excluding hatred, envy, stinginess, remorse, doubt and the two immeasurables.

For base-object prenascence dependence, base-object prenascence, base-object prenascence dissociation, base-object prenascence presence and base-object prenascence non-disappearance, the conditioning phenomenon is…


<a id="M07-body-P007"></a>
## Prenascence conditions and the proximity group
Miến / Burmese 7

… the heart-base that arises with the seventeenth consciousness counting back from death consciousness, where this condition occurs at the approach of death. The conditioned phenomena when base-object prenascence dependence operates in the five-aggregate realm are mind-door adverting, 30 sense-sphere impulsion consciousnesses, 11 registrations, two direct-knowledge consciousnesses, and 44 mental factors excluding envy, stinginess, remorse, abstinences and immeasurables.

For object prenascence, object prenascence presence and object prenascence non-disappearance, the conditioning phenomena are the 18 present concretely produced material phenomena. When receiving a prenascence object in the five-aggregate realm, the conditioned phenomena are 54 sense-sphere consciousnesses, two direct-knowledge consciousnesses and 50 mental factors excluding the two immeasurables.

The proximity group has seven kinds. For proximity, contiguity, proximity decisive support, absence and disappearance, the conditioning phenomena are the 89 consciousnesses and 52 mental factors in the preceding moment, excluding the death consciousness of arahants. The conditioned phenomena are the 89 consciousnesses and 52 mental factors in the succeeding moment, including the death consciousness of arahants.

For repetition condition, the conditioning phenomena are the 47 preceding mundane impulsions other than the final impulsion, and 52 mental factors. The conditioned phenomena are the 51 succeeding impulsions other than the first impulsion and fruition impulsions, and 52 mental factors. For proximity kamma, the conditioning phenomenon is volition in the four path consciousnesses…


<a id="M07-body-P008"></a>
## The physical base and postnascence groups
Miến / Burmese 8

… the conditioned phenomena are the four fruition consciousnesses immediately succeeding the paths and 36 mental factors.

The physical base group has six kinds. For base prenascence dependence, base prenascence, base prenascence dissociation, base prenascence presence and base prenascence non-disappearance, the conditioning phenomena are the six physical bases in the course of life. The conditioned phenomena are 85 consciousnesses arising in the five-aggregate realm, excluding the four immaterial resultants, and 52 mental factors.

For base prenascence faculty condition, the conditioning phenomenon is the eye-base of middle age that arose with an earlier past life-continuum consciousness, pe, the body-base of middle age that arose with an earlier past life-continuum consciousness. The conditioned phenomena are the ten types of double fivefold sense consciousness and the seven universal mental factors.

The postnascence group has four kinds. For postnascence, postnascence dissociation, postnascence presence and postnascence non-disappearance, the conditioning phenomena are 85 consciousnesses in the five-aggregate realm, excluding the four immaterial resultants, from the first life-continuum onward, and 52 mental factors. The conditioned phenomena are materiality of one, two, three or four origins that arose with earlier consciousnesses from rebirth-linking onward and has reached presence.


<a id="M07-body-P009"></a>
## Asynchronous kamma, material nutriment and material life faculty
Miến / Burmese 9

The asynchronous kamma group has six kinds. For asynchronous kamma condition, the conditioning phenomena are the 21 past wholesome kammas and 12 past unwholesome kammas. The conditioned phenomena are 36 resultant consciousnesses, 38 mental factors, kamma-born materiality at rebirth-linking, kamma-born materiality of non-percipient beings and kamma-born materiality in the course of life.

In the asynchronous kamma group, for proximity, contiguity, absence and disappearance, the conditioning phenomenon is volition in the four path consciousnesses. The conditioned phenomena are the four fruition consciousnesses immediately following the paths and the mental aggregates comprising 36 mental factors. For decisive support, the conditioning phenomena are the 21 past wholesome and 12 past unwholesome kammas. The conditioned phenomena are the 36 resultant consciousnesses and mental aggregates comprising 38 mental factors.

The material nutriment group has three kinds. For material nutriment, material nutriment presence and material nutriment non-disappearance, the conditioning phenomenon is nutritive essence of the four origins. The conditioned phenomena are materiality of the four origins in the same or a different group, excluding the nutritive essence in the same group.

The material life faculty group has three kinds. For material life faculty, material life faculty presence and material life faculty non-disappearance, the conditioning phenomenon is the material life faculty…


<a id="M07-body-P010"></a>
## Natural decisive support and summary
Miến / Burmese 10

… the conditioned phenomena are the nine or eight kamma-born material phenomena in the same group, excluding the material life faculty.

For natural decisive support (pakatūpanissaya), the conditioning phenomena are 89 strong consciousnesses, 52 mental factors, 28 material phenomena and certain concepts that can serve as conditions. The conditioned phenomena are 89 consciousnesses and 52 mental factors. This concludes the twenty-four Paṭṭhāna conditions.

Summary of the essential meaning. In the great, intermediate and minor conascence groups, the cause and result arise simultaneously. In the groups of co-arising phenomena each supports the other, like a stake relying on its tether and the tether relying on the stake.

In the object group, the conditioning phenomena are ultimate phenomena of the three periods, namely consciousness, mental factors and materiality, as well as timeless Nibbāna and concepts. They support by serving as objects to be known. The conditioned phenomena are the mental phenomena capable of knowing those objects, namely consciousness and mental factors. One side is the object, the other what takes the object: the object known and the mental phenomena that know it.


<a id="M07-body-P011"></a>
## Summary of proximity, base, postnascence and asynchronous kamma
Miến / Burmese 11

In the proximity group, the conditioning phenomena are the mental phenomena in the preceding consciousness moment, and the conditioned phenomena are the mental phenomena in the succeeding moment. No phenomenon intervenes between the conditioning and conditioned consciousness moments.

In the physical base group, the conditioning phenomena are the six material bases that have reached presence. The conditioned phenomena are the corresponding mental phenomena. Both belong to the present.

In the postnascence group, the conditioning phenomena are mental phenomena in later consciousness moments. The conditioned phenomena are material phenomena that arose with earlier consciousnesses and have reached presence.

In the asynchronous kamma group, cause and result arise at different times. They can be separated by one consciousness moment, as with preceding and succeeding consciousness in path and fruition, or by many moments, a lifetime, many lifetimes or many aeons.

In the material nutriment group, both the cause and the result are material. This explains how nutritive essence supports nutriment-born materiality…


<a id="M07-body-P012"></a>
## Points to understand before discernment
Miến / Burmese 12

… that is, how nutritive essence that has reached presence produces a material group with nutritive essence as the eighth constituent.

In the material life faculty group, life faculty in a group maintains its co-grouped kamma-born materiality through sustaining power (anupālakasatti). Both cause and result are material and arise simultaneously.

Natural decisive support is a conditioning phenomenon with great power by its own natural character. The conditioning phenomena include consciousness, mental factors, materiality and certain concepts suitable as conditions. The conditioned phenomena comprise consciousness and mental factors alone. The ultimate causes and results may be near or far apart in terms of consciousness moments.

This section first presents the five aggregates at rebirth-linking of a three-rooted human being, because the current rebirth-linking is to be shown first. Take again as object the causal relationship studied according to the fifth method of dependent origination. As in the tables in the section on discerning mentality, the five aggregates are distinguished for each consciousness moment, and causal relations are explained by way of these five aggregates. The mental aggregates are presented together.

Materiality as conditioned phenomena comprises (1) consciousness-born materiality…


<a id="M07-body-P013"></a>
## Kamma-born materiality at three-rooted sense-sphere rebirth-linking
Miến / Burmese 13

… (2) kamma-born materiality at rebirth-linking, (3) external materiality, (4) nutriment-born materiality, (5) temperature-born materiality, (6) kamma-born materiality of non-percipient beings and (7) kamma-born materiality during life. Thus there are seven kinds. Consciousness-born materiality has four kinds, born of wholesome, unwholesome, resultant and functional consciousness.

Those kinds of materiality will be seen at their respective consciousness moments. Kamma-born materiality at rebirth-linking also has three kinds, at rootless, two-rooted and three-rooted rebirth-linking. First, the arising of kamma-born materiality at three-rooted sense-sphere rebirth-linking will be presented.

Apart from the heart-base, kamma-born materiality at three-rooted sense-sphere rebirth-linking is conditioned by: (1) 12 mental conascence conditions, (2) 5 material conascence conditions, (3) 4 postnascence conditions, (4) 3 material life faculty conditions…


<a id="M07-body-P014"></a>
## Twenty-five conditions for rebirth-linking materiality apart from the heart-base
Miến / Burmese 14

… (5) 1 asynchronous kamma condition. Those material phenomena arise and persist because these 25 conditions support them together, each with its appropriate power.

1. For mental conascence: (a) the mental aggregates consisting of one of the four three-rooted sense-sphere rebirth-linking consciousnesses and the applicable factors among the 33, excluding abstinences and immeasurables, support by conascence, dependence, result, dissociation, presence and non-disappearance (6). (b) Non-greed, non-hatred and non-delusion support by root condition. (c) Volition supports by conascent kamma. (d) Contact, volition and consciousness support by nutriment condition. (e) Eight mental faculties support by faculty condition. (f) Five jhāna factors for joyful rebirth-linking, or four for equanimous rebirth-linking, support by jhāna condition. (g) Five path factors excluding abstinences support by path condition. Total: 6 + 6 = 12.

2. The four great elements in the same group support as appropriate through conascence, mutuality, dependence, presence and non-disappearance (5). 3. The mental aggregates of the first, subsequently arisen life-continuum support by…


<a id="M07-body-P015"></a>
## Materiality at joyful and equanimous rebirth-linking
Miến / Burmese 15

… postnascence, dissociation, presence and non-disappearance (4). 4. Material life faculty in the same group supports by material life faculty, material life faculty presence and material life faculty non-disappearance (3). 5. One of the four superior three-rooted sense-sphere wholesome kammas supports by asynchronous kamma (1). These material phenomena arise and persist through the joint support of these 25 conditions.

Note. There are four three-rooted sense-sphere rebirth-linkings, all associated with knowledge: (1) joyful and unprompted, (2) joyful and prompted, (3) equanimous and unprompted and (4) equanimous and prompted. Choose the rebirth-linking that actually arose in your own stream of mentality-materiality in this life and discern it. A joyful knowledge-associated rebirth-linking has 34 mental phenomena and an equanimous one has 33. Likewise, for asynchronous kamma, distinguish and select the specific kamma among the four three-rooted sense-sphere wholesome kammas that produced your rebirth-linking.

Apart from postnascence and asynchronous kamma, the above conditioning phenomena arise together with the conditioned phenomena, and so belong to the mental or material conascence groups. Life faculty and that kamma-born rebirth-linking materiality are also co-arising material phenomena…


<a id="M07-body-P016"></a>
## Twenty-five conditions for the heart-base at rebirth-linking
Miến / Burmese 16

… and therefore also belong to the material life faculty group. Discern with knowledge how life faculty supports kamma-born materiality in the same group. This is easier for one who has seen the causal relationship with knowledge according to the fifth method of dependent origination.

The kamma-born heart-base at three-rooted sense-sphere rebirth-linking is conditioned by 13 mental conascence conditions, 4 material conascence conditions, 4 postnascence conditions, 3 material life faculty conditions and 1 asynchronous kamma condition. Through their combined support, that materiality arises and persists.

1. (a) The mental aggregates of one of the four three-rooted sense-sphere rebirth-linking consciousnesses and the applicable factors among the 33, excluding abstinences and immeasurables, support by conascence, mutuality, dependence, result, dissociation, presence and non-disappearance (7). (b) Non-greed, non-hatred and non-delusion support by root condition. (c) Volition supports by conascent kamma…


<a id="M07-body-P017"></a>
## Groups conditioning the heart-base, continued
Miến / Burmese 17

… (d) Contact, volition and consciousness support by nutriment condition. (e) The eight mental faculties support by faculty condition. (f) Five jhāna factors at joyful three-rooted rebirth-linking, or four excluding joy at equanimous three-rooted rebirth-linking, support by jhāna condition. (g) Five path factors excluding abstinences support by path condition. Total: 7 + 6 = 13.

2. The four great elements in the same group support by conascence, dependence, presence and non-disappearance (4). 3. The first life-continuum mental aggregates after rebirth-linking support by postnascence, dissociation, presence and non-disappearance (4). 4. Life faculty in the same group supports by material life faculty, material life faculty presence and material life faculty non-disappearance (3). 5. One of the four superior three-rooted sense-sphere wholesome kammas supports by asynchronous kamma (1). Through the combined support of these 25 conditions, each according to its power, the heart-base arises and persists.


<a id="M07-body-P018"></a>
## The four mental aggregates at three-rooted sense-sphere rebirth-linking
Miến / Burmese 18

The conditioned mental aggregates comprise one of the four three-rooted sense-sphere rebirth-linking consciousnesses and the applicable factors among the 33, excluding abstinences and immeasurables. They arise and persist through the joint support of 27 conditions, each with its appropriate power: (1) 13 mental conascence conditions, (2) 6 material conascence conditions, (3) 1 object condition, (4) 5 proximity conditions and (5) 2 conditions of the asynchronous kamma group.

1. (a) The consciousness and its associated factors, namely the mental aggregates supporting one another, do so by conascence, mutuality, dependence, result, association, presence and non-disappearance (7). (b) Non-greed, non-hatred and non-delusion among the rebirth-linking aggregates support the associated aggregates by root condition. (c) Volition supports by conascent kamma. (d) Contact, volition and consciousness support by nutriment condition. (e) The eight mental faculties support by faculty condition…


<a id="M07-body-P019"></a>
## Object, proximity and kamma conditioning rebirth-linking mentality
Miến / Burmese 19

… (f) The five jhāna factors at joyful rebirth-linking, or four at equanimous rebirth-linking, support by jhāna condition. (g) Wisdom, applied thought, energy, mindfulness and one-pointedness, the five path factors, support by path condition. Total: 7 + 6 = 13.

2. The heart-base arising with one's rebirth-linking mental aggregates supports by conascence, mutuality, dependence, dissociation, presence and non-disappearance (6). 3. One of three objects, kamma, a sign of kamma or a sign of destination, supports by object condition (1). 4. The death mental aggregates of the preceding life, corresponding to one of the 19 kinds of death consciousness, support by proximity, contiguity, decisive support, absence and disappearance (5). 5. One of the four superior past three-rooted sense-sphere wholesome kammas supports by asynchronous kamma and natural decisive support (2). Through these 27 conditions acting together according to their powers, the rebirth-linking mental aggregates arise and persist.

Note. For one being in one life, only one of the four kinds of three-rooted sense-sphere rebirth-linking occurs. Likewise, only one of the four superior three-rooted sense-sphere wholesome kammas produces that life's rebirth result. Results during the course of life and the kammas that produce them can, however, be of various kinds.


<a id="M07-body-P020"></a>
## The material aggregate among the five life-continuum aggregates
Miến / Burmese 20

In general, four kinds of materiality can arise at the arising submoment of life-continuum consciousness: (a) consciousness-born, (b) kamma-born during the course of life, (c) temperature-born and (d) nutriment-born materiality.

At the presence and dissolution submoments of those life-continuum consciousnesses, three kinds of materiality can arise: (a) kamma-born during the course of life, (b) temperature-born and (c) nutriment-born materiality.

Note. Nutriment-born materiality cannot yet arise during certain initial life-continuum moments after rebirth-linking. It can arise from the time the food eaten by the mother reaches the body of the fetus.

The life-continuum material aggregate. Materiality born of life-continuum consciousness is conditioned by (1) 12 mental conascence conditions, (2) 5 material conascence conditions, (3) 4 postnascence conditions and (4) 3 material nutriment conditions…


<a id="M07-body-P021"></a>
## Twenty-four conditions for materiality born of life-continuum consciousness
Miến / Burmese 21

The conditioned phenomena arise and persist through these 24 conditions working together, each according to its appropriate power.

1. (a) The mental aggregates comprising one of the four three-rooted sense-sphere life-continuum consciousnesses and the applicable factors among the 33, excluding abstinences and immeasurables, support by conascence, dependence, result, dissociation, presence and non-disappearance (6). (b) Non-greed, non-hatred and non-delusion support by root condition. (c) Volition supports by conascent kamma. (d) Contact, volition and consciousness support by nutriment. (e) The eight mental faculties support by faculty. (f) The five jhāna factors with joyful feeling, or four with equanimous feeling, support by jhāna. (g) The five path factors excluding abstinences support by path. Total: 6 + 6 = 12.

The applicable members of the four great elements in the same group support by conascence, mutuality, dependence, presence and non-disappearance (5).

3. The appropriate later-arisen resultant or functional mental aggregates support by postnascence, dissociation, presence and non-disappearance (4).


<a id="M07-body-P022"></a>
## Kamma-born materiality co-arising at the life-continuum submoments
Miến / Burmese 22

4. Nutritive essence of the four origins in the same or a different group, excluding the nutritive essence in the group under consideration, supports by material nutriment, material nutriment presence and material nutriment non-disappearance (3).

The conditioned phenomena arise and persist through these 24 conditions working together, each according to its appropriate power.

Kamma-born materiality during life can arise at the arising, presence and dissolution submoments of life-continuum consciousness. Its conditioning phenomena fall under five material conascence, four postnascence, three material nutriment, three material life faculty and one asynchronous kamma condition.

The conditioned phenomena arise and persist through these 16 conditions working together, each according to its appropriate power.

The applicable members of the four great elements in the same group support by conascence, mutuality, dependence, presence and non-disappearance (5).

2. Later-arisen resultant and functional mental aggregates support by postnascence, dissociation, presence and non-disappearance (4).


<a id="M07-body-P023"></a>
## Conditions for kamma-, temperature- and nutriment-born materiality during life-continuum
Miến / Burmese 23

3. Nutritive essence of the four origins in the same or a different group, excluding the nutritive essence in the group under consideration, supports by material nutriment, material nutriment presence and material nutriment non-disappearance (3).

4. Material life faculty in the same group supports by material life faculty, material life faculty presence and material life faculty non-disappearance (3).

5. One of the twenty past kammas, eight wholesome and twelve unwholesome in the sense sphere, supports by asynchronous kamma (1).

The conditioned phenomena arise and persist through these 16 conditions working together, each according to its appropriate power.

Temperature-born and nutriment-born materiality can arise at the arising, presence and dissolution submoments of life-continuum consciousness. Their conditioning phenomena fall under five material conascence, four postnascence and three material nutriment conditions.

The conditioned phenomena arise and persist through these 12 conditions working together, each according to its appropriate power.

The applicable members of the four great elements in the same group support by conascence, mutuality, dependence, presence and non-disappearance (5).


<a id="M07-body-P024"></a>
## Temperature- and nutriment-born materiality. Meaning of yathārahaṃ
Miến / Burmese 24

2. Later-arisen resultant and functional mental aggregates support by postnascence, postnascence dissociation, postnascence presence and postnascence non-disappearance (4).

3. Nutritive essence of the four origins in the same or a different group, excluding the nutritive essence in the group under consideration, supports by material nutriment, material nutriment presence and material nutriment non-disappearance (3).

The conditioned phenomena arise and persist through these 12 conditions working together, each according to its appropriate power.

Note. After the life-continuum there may arise resultant mental phenomena such as life-continuum or death consciousness, or functional mental phenomena such as five-door or mind-door adverting. This is why resultant and functional mental phenomena are listed as postnascence conditions. Temperature-born and nutriment-born materiality are presented together because the kinds and numbers of conditions agree, but they are to be discerned separately.

In the material conascence group, yathārahaṃ means “according to the power applicable.” (1) Three great elements are conditioned by one great element. (2) One great element is conditioned by three great elements…


<a id="M07-body-P025"></a>
## Support as applicable and the four life-continuum mental aggregates
Miến / Burmese 25

… (3) Two great elements are supported by two great elements through conascence, mutuality, dependence, presence and non-disappearance. (4) Derived materiality in the group is supported by all four great elements in the group through conascence, dependence, presence and non-disappearance. This is what is meant by support through such powers.

Understand likewise for the four mental aggregates: (1) three are supported by one, (2) one is supported by three, (3) two are supported by two. They support one another as appropriate through conascence, mutuality, dependence, association, presence and non-disappearance.

The conditioned three-rooted sense-sphere life-continuum mental aggregates comprise the relevant one of the four consciousnesses and the applicable factors among the 33, excluding abstinences and immeasurables. They are supported by (1) thirteen mental conascence conditions, (2) one object condition…


<a id="M07-body-P026"></a>
## Twenty-six conditions for life-continuum mentality
Miến / Burmese 26

… (3) five proximity, (4) five physical base and (5) two asynchronous kamma group conditions. These mental aggregates arise and persist through these 26 conditions working together as appropriate.

1. (a) The mental aggregates comprising one of the four three-rooted sense-sphere life-continuum consciousnesses and the applicable factors among the 33, excluding abstinences and immeasurables, support by conascence, mutuality, dependence, result, association, presence and non-disappearance (7). (b) Non-greed, non-hatred and non-delusion support by root condition. (c) Volition supports by conascent kamma. (d) Contact, volition and consciousness support by nutriment. (e) The eight mental faculties support by faculty. (f) The five jhāna factors with joyful feeling, or four with equanimous feeling, support by jhāna. (g) The five path factors excluding abstinences support by path. Total: 7 + 6 = 13.

2. One of the three objects of the near-death impulsions in the former life, kamma, a sign of kamma…


<a id="M07-body-P027"></a>
## Object, proximity and the heart-base conditioning life-continuum
Miến / Burmese 27

… or a sign of destination, supports through object condition (1).

3. The mental aggregates that ceased immediately before life-continuum are, as applicable, (a) three-rooted sense-sphere rebirth-linking, (b) the preceding three-rooted sense-sphere life-continuum, (c) determining consciousness, (d) the final impulsion, or (e) the second registration. The applicable mental aggregates support by proximity, contiguity, decisive support, absence and disappearance (5).

4. The heart-base that arose with the mental aggregates immediately preceding the life-continuum, as applicable: (a) three-rooted sense-sphere rebirth-linking, (b) the previous three-rooted sense-sphere life-continuum, (c) determining consciousness, (d) the final impulsion, (e) the second registration…


<a id="M07-body-P028"></a>
## Asynchronous kamma for life-continuum. The five aggregates at death
Miến / Burmese 28

… (f) the seventeenth consciousness counting back from death consciousness at the approach of death. The appropriate heart-base supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. One of the four superior past three-rooted sense-sphere wholesome kammas supports by asynchronous kamma and natural decisive support (2).

The conditioned phenomena arise and persist through these 26 conditions working together, each according to its appropriate power.

Note. In the mental conascence group, “as applicable” means that one mental aggregate supports three, three support one, or two support two. Among the four kinds of three-rooted sense-sphere life-continuum, take as object the one that has arisen, is arising or will arise in your own continuity of mentality-materiality. Among the superior three-rooted sense-sphere wholesome kammas, discern the particular kamma producing the result.

The five aggregates at death, here three-rooted sense-sphere death. At death, kamma-born, temperature-born and nutriment-born materiality can no longer arise anew. These kinds of materiality arose with the seventeenth consciousness counting back from death consciousness…


<a id="M07-body-P029"></a>
## Materiality at death and the four death mental aggregates
Miến / Burmese 29

… and reach dissolution together. Teachers differ on whether death consciousness can produce consciousness-born materiality. Yet consciousnesses shortly before death consciousness can produce consciousness-born materiality, and such materiality is still at the stage of presence at death.

If death follows impulsion, that consciousness may be an impulsion. If death follows registration, it may be registration. If death follows life-continuum, it may be life-continuum. Take note of the consciousness-born materiality those consciousnesses have produced, are producing or will produce. Understand kamma-, temperature- and nutriment-born materiality in the same way.

The four three-rooted sense-sphere death mental aggregates, comprising the appropriate one of four death consciousnesses and the applicable factors among the 33, excluding abstinences and immeasurables, are supported by thirteen conascence, one object, five proximity, five physical base and two asynchronous kamma group conditions.

The conditioned phenomena arise and persist through these 26 conditions working together, each according to its appropriate power.


<a id="M07-body-P030"></a>
## Mental conascence and object conditions at death
Miến / Burmese 30

1. (a) The mental aggregates comprising one of the four three-rooted sense-sphere death consciousnesses and the applicable factors among the 33, excluding abstinences and immeasurables, support by conascence, mutuality, dependence, result, association, presence and non-disappearance (7). (b) Non-greed, non-hatred and non-delusion support by root condition. (c) Volition supports by conascent kamma. (d) Contact, volition and consciousness support by nutriment. (e) The eight mental faculties support by faculty. (f) The five jhāna factors with joyful feeling, or four with equanimous feeling, support by jhāna. (g) The five path factors excluding abstinences support by path. Total: 7 + 6 = 13.

2. One of three objects, kamma, a sign of kamma or a sign of destination, supports by object condition (1).

3. The mental aggregates that ceased immediately before death consciousness are, as applicable, (a) the fifth impulsion in the near-death process, or (b) the second registration…


<a id="M07-body-P031"></a>
## Proximity at death and materiality in five-door processes
Miến / Burmese 31

… or (c) one's previous three-rooted sense-sphere life-continuum. Those conditioning phenomena support by proximity, contiguity, decisive support, absence and disappearance (5).

4. The heart-base that arose with the seventeenth consciousness counting back from death consciousness supports by dependence, prenascence, dissociation, presence and non-disappearance (5). 5. The appropriate superior past three-rooted sense-sphere wholesome kamma supports by asynchronous kamma and natural decisive support (2).

The conditioned phenomena arise and persist through these 26 conditions working together, each according to its appropriate power.

In the five-door process, (1) the three kinds of materiality that can arise at the arising, presence and dissolution submoments of the five kinds of sense consciousness are kamma-born materiality during life, temperature-born materiality and nutriment-born materiality. (2) The four kinds that can arise at the arising submoment of consciousness other than sense consciousness, namely five-door adverting, receiving, investigating, determining, impulsion and registration, are…


<a id="M07-body-P032"></a>
## The five aggregates of five-door adverting
Miến / Burmese 32

… (a) consciousness-born, (b) kamma-born during life, (c) temperature-born and (d) nutriment-born materiality. (3) Three kinds can arise at the presence and dissolution submoments of consciousness in the five-door process: kamma-born during life, temperature-born and nutriment-born materiality.

At the five-door adverting moment there are five aggregates. Materiality is presented first, in three groups: (a) consciousness-born, (b) kamma-born during life, and (c) temperature- and nutriment-born materiality, with their corresponding Paṭṭhāna conditions.

Materiality born of five-door adverting consciousness is conditioned by nine mental conascence, five material conascence, four postnascence and three material nutriment conditions…


<a id="M07-body-P033"></a>
## Twenty-one conditions for materiality born of five-door adverting
Miến / Burmese 33

The conditioned phenomena arise and persist through these 21 conditions working together, each according to its appropriate power.

1. (a) Five-door adverting consciousness and ten ethically variable mental factors, excluding zeal, joy and energy, support by conascence, dependence, dissociation, presence and non-disappearance (5). (b) Volition supports by conascent kamma. (c) Contact, volition and consciousness support by nutriment. (d) Life, consciousness and feeling, the three mental faculties, support by faculty. (e) Four jhāna factors excluding joy support by jhāna. Total: 5 + 4 = 9.

The applicable members of the four great elements in the same group support by conascence, mutuality, dependence, presence and non-disappearance (5).

3. The appropriate later-arisen sense-consciousness mental aggregates support by postnascence, dissociation, presence and non-disappearance (4).

4. Nutritive essence of the four origins in the same or a different group, excluding the nutritive essence in the group under consideration, supports by material nutriment, material nutriment presence and material nutriment non-disappearance (3).

The conditioned phenomena arise and persist through these 21 conditions working together, each according to its appropriate power.


<a id="M07-body-P034"></a>
## Kamma-born materiality simultaneous with five-door adverting
Miến / Burmese 34

Kamma-born materiality during life can arise at the arising, presence and dissolution submoments of five-door adverting. The conditioning phenomena fall under five material conascence, four postnascence, three material nutriment, three material life faculty and one asynchronous kamma condition.

The conditioned phenomena arise and persist through these 16 conditions working together, each according to its appropriate power.

The applicable members of the four great elements in the same group support by conascence, mutuality, dependence, presence and non-disappearance (5).

2. Later-arisen sense consciousness supports by postnascence, dissociation, presence and non-disappearance (4).

3. Nutritive essence of the four origins in the same or a different group, excluding the nutritive essence in the group under consideration, supports by material nutriment, material nutriment presence and material nutriment non-disappearance (3).

4. Material life faculty in the same group supports by material life faculty, material life faculty presence and material life faculty non-disappearance (3).

5. One kamma among the eight sense-sphere wholesome, twelve unwholesome and…


<a id="M07-body-P035"></a>
## Temperature- and nutriment-born materiality simultaneous with five-door adverting
Miến / Burmese 35

… five fine-material-sphere wholesome kammas of the past, 25 in all, supports by asynchronous kamma (1).

The conditioned phenomena arise and persist through these 16 conditions working together, each according to its appropriate power.

Temperature- and nutriment-born materiality arising at the arising, presence and dissolution submoments of five-door adverting are conditioned by five material conascence, four postnascence and three material nutriment conditions.

The conditioned phenomena arise and persist through these 12 conditions working together, each according to its appropriate power.

The applicable members of the four great elements in the same group support by conascence, mutuality, dependence, presence and non-disappearance (5).

2. Later-arisen sense consciousness supports by postnascence, dissociation, presence and non-disappearance (4).

3. Nutritive essence of the four origins in the same or a different group, excluding the nutritive essence in the group under consideration, supports by material nutriment, material nutriment presence and material nutriment non-disappearance (3).


<a id="M07-body-P036"></a>
## Summary of the 54 sense-sphere consciousnesses in the five-door process
Miến / Burmese 36

The conditioned phenomena arise and persist through these 12 conditions working together, each according to its appropriate power.

Summary to remember. Classification of conditions for the 54 sense-sphere consciousnesses in a five-door process.

At the eye door, when a very great visible object is taken as object, the sequence is: one past life-continuum, vibration of the life-continuum, arrest of the life-continuum, five-door adverting, eye-consciousness (one of the five sense consciousnesses), receiving, investigating, determining, seven sense-sphere impulsions, two registrations, then life-continuum, life-continuum…

The wholesome, unwholesome and functional consciousnesses occupying the impulsion position in this process arise at the arising submoment and persist at the presence submoment through the simultaneous support, as appropriate, of five groups of conditions: conascence, object, proximity, physical base and natural decisive support.


<a id="M07-body-P037"></a>
## Twenty-five conditions for five-door adverting mentality
Miến / Burmese 37

For resultant consciousness, add the asynchronous kamma group to the five groups above. Through the six groups of conditioning phenomena acting together as appropriate, resultant consciousness arises at the arising submoment and persists at the presence submoment. This is the summary to remember.

The five-door adverting mental aggregates comprise five-door adverting consciousness and ten ethically variable mental factors, excluding zeal, joy and energy. They are supported by ten conascence, four object, five proximity, five physical base and one natural decisive support condition.

The conditioned phenomena arise and persist through these 25 conditions working together, each according to its appropriate power.

1. (a) Five-door adverting consciousness and those ten factors support one another by conascence, mutuality, dependence, association, presence and non-disappearance (6). (b) Volition supports by conascent kamma. (c) Contact, volition and consciousness support by nutriment condition…


<a id="M07-body-P038"></a>
## Conditions for five-door adverting. Materiality at eye-consciousness
Miến / Burmese 38

… (d) Life, consciousness and feeling support by faculty condition. (e) The four jhāna factors excluding joy support by jhāna condition. Total: 6 + 4 = 10.

2. The present visible object supports by object, prenascence, presence and non-disappearance (4). Sound and the other five-door objects are understood in the same way.

3. The previously ceased mental aggregates of the arrest of the life-continuum support by proximity, contiguity, decisive support, absence and disappearance (5).

4. The heart-base that arose with those mental aggregates of the arrest of the life-continuum supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. Strong phenomena comprising 89 consciousnesses, 52 mental factors, 28 material phenomena and certain concepts suitable as conditions support by natural decisive support (1).

The conditioned phenomena arise and persist through these 25 conditions working together, each according to its appropriate power.

The five aggregates of eye-consciousness. Kamma-born materiality during life can arise at the arising, presence and dissolution submoments of eye-consciousness, one of the five kinds of sense consciousness. The conditioning phenomena fall under five material conascence, four postnascence and three material nutriment conditions…


<a id="M07-body-P039"></a>
## Kamma-, temperature- and nutriment-born materiality at eye-consciousness
Miến / Burmese 39

… three material life faculty conditions and one asynchronous kamma condition.

The conditioned phenomena arise and persist through these 16 conditions working together, each according to its appropriate power.

Items (1), (3), (4) and (5) are the same as those given for the material aggregate of five-door adverting. In item (2), the later-arisen receiving mental aggregates support by postnascence, dissociation, presence and non-disappearance (4). This is the point of difference.

Temperature-born and nutriment-born materiality can arise at the arising, presence and dissolution submoments of eye-consciousness. The conditioning phenomena fall under five material conascence, four postnascence and three material nutriment conditions.

The conditioned phenomena arise and persist through these 12 conditions working together, each according to its appropriate power.

Understand according to the method already given for five-door adverting. Here the receiving mental aggregates act as postnascence conditions.

The conditioned eye-consciousness mental aggregates comprise eye-consciousness and the seven universal mental factors…


<a id="M07-body-P040"></a>
## Twenty-eight conditions for eye-consciousness mentality
Miến / Burmese 40

… They are supported by ten conascence, four object, five proximity, six physical base, two kamma group and one natural decisive support condition.

The conditioned phenomena arise and persist through these 28 conditions working together, each according to its appropriate power.

1. (a) Eye-consciousness and the seven universals support one another by conascence, mutuality, dependence, result, association, presence and non-disappearance (7). (b) Volition in the eye-consciousness mental aggregates supports the associated aggregates through conascent kamma. (c) Contact, volition and consciousness support by nutriment condition. (d) Life, consciousness and feeling support by faculty condition. Total: 7 + 3 = 10.

2. The present visible object supports by object, prenascence, presence and non-disappearance (4).


<a id="M07-body-P041"></a>
## The physical base for eye-consciousness. The receiving material aggregate
Miến / Burmese 41

3. The ceased five-door adverting mental aggregates support by proximity, contiguity, decisive support, absence and disappearance (5).

4. The eye-base at its middle stage, which arose with the first past life-continuum, supports by dependence, prenascence, faculty, dissociation, presence and non-disappearance (6).

5. An appropriate past wholesome or unwholesome kamma supports by asynchronous kamma and natural decisive support (2).

6. Strong phenomena comprising 89 consciousnesses, 52 mental factors, 28 material phenomena and certain concepts capable of serving as conditions, such as light, pe, support by natural decisive support (1).

The conditioned phenomena arise and persist through these 28 conditions working together, each according to its appropriate power.

The five receiving aggregates. Materiality born of receiving consciousness is conditioned by ten mental conascence, five material conascence, four postnascence and three material nutriment conditions…


<a id="M07-body-P042"></a>
## Twenty-two conditions for materiality born of receiving
Miến / Burmese 42

The conditioned phenomena arise and persist through these 22 conditions working together, each according to its appropriate power.

1. (a) Receiving consciousness and ten ethically variable mental factors, excluding zeal, joy and energy, support by conascence, dependence, result, dissociation, presence and non-disappearance (6). (b) Volition in the receiving mental aggregates supports by conascent kamma. (c) Contact, volition and consciousness support by nutriment condition. (d) The three mental faculties, life, consciousness and feeling, support by faculty condition. (e) The four jhāna factors excluding joy support by jhāna condition. Total: 6 + 4 = 10.

Note. Items (2)–(4) are as before. In item (3), the investigating mental aggregates are the conditioning phenomena by postnascence.

Discern kamma-born materiality during life, temperature-born and nutriment-born materiality arising at the arising, presence and dissolution submoments of the receiving mental aggregates according to the method given for the material aggregate of five-door adverting. Wholesome-resultant and unwholesome-resultant receiving are presented together because the discernment pattern is the same. Discern them separately in practice. For a desirable object the result is wholesome, for an undesirable object the result is unwholesome.


<a id="M07-body-P043"></a>
## Twenty-eight conditions for receiving mentality
Miến / Burmese 43

Receiving mentality comprises receiving consciousness and ten ethically variable factors excluding zeal, joy and energy. Its conditioning groups are eleven conascence, four object, five proximity, five physical base, two kamma group and one natural decisive support condition.

The conditioned phenomena arise and persist through these 28 conditions working together, each according to its appropriate power.

1. (a) Receiving consciousness and ten ethically variable factors, excluding zeal, joy and energy support one another by conascence, mutuality, dependence, result, association, presence and non-disappearance (7). (b) Volition in the receiving mental aggregates supports the associated aggregates by conascent kamma. (c) Contact, volition and consciousness support by nutriment condition. (d) Life, consciousness and feeling support by faculty condition.

The four jhāna factors excluding joy support by jhāna condition. Total: 7 + 4 = 11.


<a id="M07-body-P044"></a>
## Conditions for receiving. The investigating material aggregate
Miến / Burmese 44

2. The present visible object supports by object, prenascence, presence and non-disappearance (4).

3. The ceased eye-consciousness mental aggregates support by proximity, contiguity, decisive support, absence and disappearance (5).

4. The heart-base arising with eye-consciousness consciousness supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. An appropriate past wholesome or unwholesome kamma supports by asynchronous kamma and natural decisive support (2).

6. Strong phenomena comprising 89 consciousnesses, 52 mental factors, 28 material phenomena and certain concepts suitable as conditions support by natural decisive support (1).

The conditioned phenomena arise and persist through these 28 conditions working together, each according to its appropriate power.

The five investigating aggregates. Materiality born of investigating consciousness is conditioned by ten mental conascence, five material conascence, four postnascence conditions…


<a id="M07-body-P045"></a>
## Twenty-two conditions for materiality born of investigating
Miến / Burmese 45

… and three material nutriment conditions.

The conditioned phenomena arise and persist through these 22 conditions working together, each according to its appropriate power.

1. (a) Investigating consciousness and eleven ethically variable factors excluding zeal and energy, or ten in equanimous investigating, also excluding joy, support by conascence, dependence, result, dissociation, presence and non-disappearance (6). (b) Volition in the investigating aggregates supports by conascent kamma. (c) Contact, volition and consciousness support by nutriment condition. (d) Life, consciousness and feeling support by faculty condition. (e) Five jhāna factors for joyful investigating, or four excluding joy for equanimous investigating, support by jhāna condition. Total: 6 + 4 = 10.

Note. Discern items (2)–(4) as already explained. The determining mental aggregates are the postnascence conditioning phenomena. Similarly, note and discern kamma-born materiality during life and temperature-born and nutriment-born materiality arising at the arising, presence and dissolution submoments of the investigating mental aggregates as already explained.


<a id="M07-body-P046"></a>
## Twenty-eight conditions for investigating mentality
Miến / Burmese 46

Investigating consciousness and its associated mental factors constitute the conditioned mental aggregates. The groups of conditioning phenomena are eleven mental conascence, four object, five proximity, five physical base, two asynchronous kamma group and one natural decisive support condition.

The conditioned phenomena arise and persist through these 28 conditions working together, each according to its appropriate power.

1. (a) Investigating consciousness and eleven or ten ethically variable factors, excluding zeal and energy, and also joy in equanimous investigating support one another by conascence, mutuality, dependence, result, association, presence and non-disappearance (7). (b) Volition in the investigating mental aggregates supports the associated aggregates by conascent kamma. (c) Contact, volition and consciousness support by nutriment condition. (d) Life, consciousness and feeling support by faculty condition.

If investigating is accompanied by joy, five jhāna factors support. If investigating is accompanied by equanimity, four jhāna factors excluding joy…


<a id="M07-body-P047"></a>
## Conditions for investigating. The determining material aggregate
Miến / Burmese 47

… support by jhāna condition. Total: 7 + 4 = 11.

2. The present visible object supports by object, prenascence, presence and non-disappearance (4).

3. The ceased receiving mental aggregates support by proximity, contiguity, decisive support, absence and disappearance (5).

4. The heart-base arising with receiving consciousness supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. An appropriate past wholesome or unwholesome kamma supports by asynchronous kamma and natural decisive support (2).

6. Strong phenomena comprising 89 consciousnesses, 52 mental factors, 28 material phenomena and certain concepts suitable as conditions support by natural decisive support (1).

The conditioned phenomena arise and persist through these 28 conditions working together, each according to its appropriate power.

The five determining aggregates. Materiality produced by the determining mental aggregates is conditioned by nine mental conascence, five material conascence conditions…


<a id="M07-body-P048"></a>
## Twenty-one conditions for materiality born of determining
Miến / Burmese 48

… four postnascence and three material nutriment conditions.

The conditioned phenomena arise and persist through these 21 conditions working together, each according to its appropriate power.

1. (a) Determining consciousness and eleven ethically variable factors, excluding zeal and joy, support by conascence, dependence, dissociation, presence and non-disappearance (5). (b) Volition in the determining mental aggregates supports by conascent kamma. (c) Contact, volition and consciousness support by nutriment condition. (d) The five mental faculties, life, consciousness, feeling, energy and one-pointedness, support by faculty condition. (e) The four jhāna factors excluding joy support by jhāna condition. Total: 5 + 4 = 9.

Note. Understand items (2)–(4) in the way already given. The first impulsion mental aggregates are the postnascence conditioning phenomena. Note and discern as before kamma-born materiality during life and temperature-born and nutriment-born materiality arising at the arising, presence and dissolution submoments of the determining mental aggregates.

The determining mental aggregates comprise determining consciousness and eleven ethically variable factors, excluding zeal and joy…


<a id="M07-body-P049"></a>
## Twenty-five conditions for determining mentality
Miến / Burmese 49

… and are supported by ten mental conascence, four object, five proximity, five physical base and one natural decisive support condition.

The conditioned phenomena arise and persist through these 25 conditions working together, each according to its appropriate power.

1. (a) Determining consciousness and eleven ethically variable factors, excluding zeal and joy, support one another by conascence, mutuality, dependence, association, presence and non-disappearance (6). (b) Volition in the determining mental aggregates supports by conascent kamma. (c) Contact, volition and consciousness support by nutriment condition. (d) Life, consciousness, feeling, energy and one-pointedness support by faculty condition. (e) The four jhāna factors excluding joy support by jhāna condition. Total: 6 + 4 = 10.

2. The present visible object supports by object, prenascence, presence and non-disappearance (4). 3. The ceased investigating mental aggregates support by proximity…


<a id="M07-body-P050"></a>
## Conditions for determining. Materiality of the first great wholesome impulsion
Miến / Burmese 50

… contiguity, decisive support, absence and disappearance (5).

4. The heart-base arising with investigating consciousness supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. Strong phenomena comprising 89 consciousnesses, 52 mental factors, 28 material phenomena and certain concepts suitable as conditions support by natural decisive support (1).

The conditioned phenomena arise and persist through these 25 conditions working together, each according to its appropriate power.

The five aggregates of the first great wholesome impulsion in a five-door process. The consciousness-born materiality produced by the mental aggregates of the first great wholesome impulsion is supported by twelve mental conascence, five material conascence, four postnascence and three material nutriment conditions.

The conditioned phenomena arise and persist through these 24 conditions working together, each according to its appropriate power.

The material phenomena produced by the mental aggregates of the first great wholesome impulsion are conditioned as follows…


<a id="M07-body-P051"></a>
## Mental aggregates conditioning materiality of the first great wholesome impulsion
Miến / Burmese 51

1. (a) The first great wholesome impulsion consciousness and the applicable factors among the 33, excluding abstinences and immeasurables, support by conascence, dependence, dissociation, presence and non-disappearance (5). (b) Non-greed and non-hatred support in the two-rooted case, and non-greed, non-hatred and non-delusion in the three-rooted case. They support by root condition. (c) Where predominance occurs, one of zeal, energy and consciousness in the two-rooted case, or one of zeal, energy, consciousness and investigation in the three-rooted case, supports by predominance. (d) Volition supports by conascent kamma. (e) Contact, volition and consciousness support by nutriment. (f) Seven mental faculties excluding wisdom in the two-rooted case, or eight in the three-rooted case, support by faculty. (g) Five jhāna factors with joy, or four with equanimity, support by jhāna. (h) In the two-rooted case four path factors excluding the abstinences and wisdom support, and in the three-rooted case five excluding the abstinences support, by path condition. Total: 5 + 7 = 12.

Note. Items (2)–(4) are as already stated. In item (3), the later-arisen mental aggregates of the second impulsion condition the materiality of the first by postnascence. The mental aggregates of the third condition the materiality of the second. Understand the succeeding impulsions accordingly.


<a id="M07-body-P052"></a>
## Mental aggregates of the first great wholesome impulsion
Miến / Burmese 52

Note and discern as described above the kamma-born materiality of the course of life and the temperature- and nutriment-born materiality co-arising with the arising, presence and dissolution submoments of the first great wholesome impulsion. Similarly discern consciousness-born materiality at the second and subsequent great wholesome impulsions and at functional and unwholesome impulsions, as well as kamma-, temperature- and nutriment-born materiality arising at their three submoments.

In the five-door process, the first great wholesome impulsion consciousness and its applicable factors among the 33, excluding abstinences and immeasurables, comprise the conditioned mental aggregates. Their condition groups are mental conascence (13), object (4), proximity (5), physical base (5) and natural decisive support (1).

The conditioned phenomena arise and persist through these 28 conditions working together, each according to its appropriate power.

1. (a) The first great wholesome impulsion consciousness and these factors support one another by conascence, mutuality…


<a id="M07-body-P053"></a>
## Thirteen mental conascence conditions of the first great wholesome impulsion
Miến / Burmese 53

… dependence, association, presence and non-disappearance (6).

(b) Non-greed and non-hatred support in the two-rooted case, and non-greed, non-hatred and non-delusion in the three-rooted case. They support by root condition. (c) Where predominance occurs, one of zeal, energy and consciousness in the two-rooted case, or one of zeal, energy, consciousness and investigation in the three-rooted case, supports by predominance. (d) Volition supports by conascent kamma. (e) Contact, volition and consciousness support by nutriment. (f) Seven mental faculties excluding wisdom in the two-rooted case, or eight in the three-rooted case, support by faculty. (g) Five jhāna factors with joy, or four with equanimity, support by jhāna. (h) In the two-rooted case four path factors excluding the abstinences and wisdom support, and in the three-rooted case five excluding the abstinences support, by path condition. Total: 6 + 7 = 13.


<a id="M07-body-P054"></a>
## From the first to the second great wholesome impulsion
Miến / Burmese 54

2. The present visible object supports by object, prenascence, presence and non-disappearance (4).

3. The ceased mental aggregates of determining consciousness support by proximity, contiguity, decisive support, absence and disappearance (5).

4. The heart-base that arose with determining consciousness supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

Strong phenomena comprising 87 consciousnesses excluding the arahant path and fruition, 52 mental factors, 28 material phenomena and certain concepts suitable as conditions support by natural decisive support (1).

The conditioned phenomena arise and persist through these 28 conditions working together, each according to its appropriate power.

Discern the material aggregate of the second great wholesome impulsion in the same way. In the five-door process, the second great wholesome impulsion consciousness and its applicable factors among the 33, excluding abstinences and immeasurables, comprise the conditioned mental aggregates. Their condition groups are mental conascence (13), object (4), proximity (6), physical base (5) and natural decisive support (1).


<a id="M07-body-P055"></a>
## Mental conascence of the second great wholesome impulsion
Miến / Burmese 55

The conditioned phenomena arise and persist through these 29 conditions working together, each according to its appropriate power.

1. (a) The second great wholesome impulsion consciousness and the applicable factors among the 33, excluding abstinences and immeasurables, support by conascence, mutuality, dependence, association, presence and non-disappearance (6).

(b) Non-greed and non-hatred support in the two-rooted case, and non-greed, non-hatred and non-delusion in the three-rooted case. They support by root condition. (c) Where predominance occurs, one of zeal, energy and consciousness in the two-rooted case, or one of zeal, energy, consciousness and investigation in the three-rooted case, supports by predominance. (d) Volition supports by conascent kamma. (e) Contact, volition and consciousness support by nutriment. (f) Seven mental faculties excluding wisdom in the two-rooted case, or eight in the three-rooted case, support by faculty.

With joyful feeling there are five jhāna factors, and with equanimity four, excluding joy…


<a id="M07-body-P056"></a>
## Conditions for the second and later great wholesome impulsions
Miến / Burmese 56

… supporting by jhāna condition. A two-rooted impulsion has four path factors: applied thought, energy, mindfulness and one-pointedness. A three-rooted impulsion has wisdom as a fifth. They support by path condition. Total: 6 + 7 = 13.

2. The present visible object supports by object, prenascence, presence and non-disappearance (4).

3. The ceased mental aggregates of first great wholesome impulsion support by proximity, contiguity, decisive support, repetition, absence and disappearance (6).

4. The heart-base that arose with first great wholesome impulsion supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

Strong phenomena comprising 87 consciousnesses excluding the arahant path and fruition, 52 mental factors, 28 material phenomena and certain concepts suitable as conditions support by natural decisive support (1).

The conditioned phenomena arise and persist through these 29 conditions working together, each according to its appropriate power.

Note. Understand and discern the third through seventh great wholesome impulsions by following the second. In the proximity group the second supports the third, the third the fourth, the fourth the fifth, the fifth the sixth and the sixth the seventh. Only this detail varies.


<a id="M07-body-P057"></a>
## The five aggregates and mentality of unwholesome impulsion
Miến / Burmese 57

Understand and discern the material aggregate of unwholesome impulsion by following the material aggregate already described. The mental aggregates of unwholesome impulsion in the five-door process are presented together here.

The mental aggregates of the first unwholesome impulsion are conditioned by mental conascence (13), object (4), proximity (5), physical base (5) and natural decisive support (1).

The conditioned phenomena arise and persist through these 28 conditions working together, each according to its appropriate power.

1. (a) The first impulsion is one of the twelve unwholesome consciousnesses and takes its applicable factors among the 27. Its mental aggregates support one another by conascence, mutuality, dependence, association, presence and non-disappearance (6). (b) In those aggregates, greed and delusion support in a greed-rooted impulsion, hatred and delusion in a hatred-rooted impulsion…


<a id="M07-body-P058"></a>
## Root, predominance, faculty, jhāna and path in unwholesome impulsion
Miến / Burmese 58

… and delusion alone in a delusion-rooted impulsion. These two roots or this one root support by root condition. (c) In a greed- or hatred-rooted impulsion with a predominance, one of zeal, energy and consciousness supports by predominance. (d) Volition supports by conascent kamma. (e) Contact, volition and consciousness support by nutriment.

(f) In greed-rooted, hatred-rooted or restlessness-associated impulsion, the five mental faculties are life, consciousness, feeling, energy and one-pointedness. In doubt-associated impulsion there are four: life, consciousness, feeling and energy. They support by faculty. (g) With joyful feeling there are five jhāna factors; with grief or equanimity there are four, excluding joy. They support by jhāna condition.

(h) Impulsion associated with wrong view has four path factors: applied thought, energy, one-pointedness and wrong view. Impulsion dissociated from wrong view, rooted in hatred or associated with restlessness has three: applied thought, energy and one-pointedness. Impulsion associated with doubt has two: applied thought and energy. They support by path condition. Total: 6 + 7 = 13.

2. The present visible object supports by object, prenascence, presence and non-disappearance (4).

3. The ceased mental aggregates of determining consciousness support by proximity, contiguity, decisive support, absence and disappearance (5).


<a id="M07-body-P059"></a>
## Subsequent unwholesome impulsions. The five registration aggregates
Miến / Burmese 59

4. The heart-base that arose with determining consciousness supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

Strong phenomena comprising 81 consciousnesses mundane, 52 mental factors, 28 material phenomena and certain concepts suitable as conditions support by natural decisive support (1).

The conditioned phenomena arise and persist through these 28 conditions working together, each according to its appropriate power.

Note. For the second unwholesome impulsion, the ceased first impulsion aggregates support by proximity, contiguity, decisive support, repetition, absence and disappearance (6). The heart-base arising with the first supports by dependence, prenascence, dissociation, presence and non-disappearance (5). Repetition is the additional condition, making 29. Discern the third and subsequent impulsions similarly. Cases with the same pattern are presented together, but only one kind of unwholesome impulsion can arise in a single moment. In practice discern each separately, as in the tables for discerning mentality.

The five registration aggregates. In eye-door and other five-door processes, rooted registration can arise with a desirable object, and rootless registration with an undesirable object, as applicable. Rooted registration, that is, great resultant registration, is presented first…


<a id="M07-body-P060"></a>
## Materiality born of the first rooted registration
Miến / Burmese 60

… and has eight kinds. They are presented together here. Discern each kind separately in practice, since only one kind of registration can occur within a given process.

Materiality produced by the first rooted registration mental aggregates, those of a great resultant consciousness, is supported by mental conascence (12), material conascence (5), postnascence (4) and material nutriment (3).

The conditioned phenomena arise and persist through these 24 conditions working together, each according to its appropriate power.

1. (a) The first rooted registration consciousness and the applicable factors among the 33, excluding abstinences and immeasurables, support by conascence, dependence, result, dissociation, presence and non-disappearance (6). (b) Non-greed and non-hatred support when the materiality is born of two-rooted registration. Non-greed, non-hatred and non-delusion support when it is born of three-rooted registration. These two or three roots support by root condition.


<a id="M07-body-P061"></a>
## Conditions for registration-born materiality and the great resultant mental aggregates
Miến / Burmese 61

(c) Volition supports by conascent kamma. (d) Contact, volition and consciousness support by nutriment. (e) Materiality born of two-rooted registration is supported by seven mental faculties excluding wisdom, that born of three-rooted registration by eight. (f) Five jhāna factors support with joy, or four excluding joy with equanimity. (g) With two roots, four path factors excluding abstinences and wisdom support, and with three roots, five factors excluding abstinences support. Total: 6 + 6 = 12.

Note. Items (2)–(4) are as before. The second rooted registration mental aggregates are the postnascence conditioning phenomena. Follow the earlier pattern for kamma-, temperature- and nutriment-born materiality co-arising with the arising, presence and dissolution submoments of the first rooted registration. Understand as before materiality born of the second rooted registration and the corresponding kinds of materiality. Where life-continuum follows registration, its mental aggregates act by postnascence.

Rooted great resultant registration mentality comprises one of the eight consciousnesses and its applicable factors among the 33, excluding abstinences and immeasurables…


<a id="M07-body-P062"></a>
## Thirty conditions for rooted registration mentality
Miến / Burmese 62

… They are supported by mental conascence (13), object (4), proximity (5), physical base (5), the asynchronous kamma group (2) and natural decisive support (1).

The conditioned phenomena arise and persist through these 30 conditions working together, each according to its appropriate power.

1. (a) One of the eight rooted registration consciousnesses and the applicable factors among the 33, sometimes 32 or 31, support one another by conascence, mutuality, dependence, result, association, presence and non-disappearance (7). (b) Non-greed and non-hatred support at two-rooted registration; non-greed, non-hatred and non-delusion at three-rooted registration, by root condition. (c) Volition supports by conascent kamma. (d) Contact, volition and consciousness support by nutriment. (e) Two-rooted registration has seven mental faculties excluding wisdom, while three-rooted registration has eight…


<a id="M07-body-P063"></a>
## Object, physical base and kamma conditioning rooted registration
Miến / Burmese 63

… supporting by faculty. (f) Five jhāna factors support with joy, four excluding joy with equanimity. (g) Two-rooted registration has four path factors: applied thought, energy, mindfulness and one-pointedness. Three-rooted registration has wisdom as a fifth. They support by path condition. Total: 7 + 6 = 13.

2. The present visible object supports by object, prenascence, presence and non-disappearance (4).

3. For the first registration, the ceased seventh impulsion aggregates support. For the second registration, the ceased first registration aggregates support. They do so by proximity, contiguity, decisive support, absence and disappearance (5).

4. For the first registration, the heart-base that arose with the seventh impulsion supports. For the second, the heart-base that arose with the first registration supports. They do so by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. Strong past sense-sphere wholesome kamma supports by asynchronous kamma and natural decisive support (2).

Strong phenomena comprising 89 consciousnesses, 52 mental factors, 28 material phenomena and certain concepts suitable as conditions support by natural decisive support (1).


<a id="M07-body-P064"></a>
## Materiality born of the first rootless registration
Miến / Burmese 64

The conditioned phenomena arise and persist through these 30 conditions working together, each according to its appropriate power.

Materiality born of the first rootless registration mental aggregates is supported by mental conascence (10), material conascence (5), postnascence (4) and material nutriment (3).

The conditioned phenomena arise and persist through these 22 conditions working together, each according to its appropriate power.

1. (a) The first rootless registration consciousness and eleven ethically variable factors, excluding zeal and energy if joyful, or ten, also excluding joy if equanimous, support by conascence, dependence, result, dissociation, presence and non-disappearance (6). (b) Volition supports by conascent kamma. (c) Contact, volition and consciousness support by nutriment. (d) The three mental faculties of life, consciousness and feeling support by faculty…


<a id="M07-body-P065"></a>
## Rootless registration and the other five-door processes
Miến / Burmese 65

… (e) Five jhāna factors support with joyful first rootless registration, or four excluding joy with equanimity. Total: 6 + 4 = 10.

Note. Items (2)–(4) are as before. For postnascence, the second registration mental aggregates support. Understand by the preceding method the kamma-, temperature- and nutriment-born materiality co-arising with the arising, presence and dissolution submoments of first rootless registration. Understand the materiality born of second rootless registration on the model of the first. The difference is that the first life-continuum mental aggregates after registration support by postnascence. For the three rootless registrations, understand the conascence group according to the three investigating consciousnesses. For the object and other groups, follow rooted registration.

This concludes the overall treatment of Paṭṭhāna conditional relations for the five aggregates at each moment of the eye-door process. In practice, discern each moment separately as set out in the tables for discerning mentality. The differences in the other processes are: (1) the ear-door process takes a present sound, (2) the nose-door process takes a present odor, (3) the tongue-door process takes a present taste, and (4) the body-door process takes a present tangible object.


<a id="M07-body-P066"></a>
## Five-door objects and mind-door processes with sense-sphere impulsion
Miến / Burmese 66

Each corresponding object supports by object, prenascence, presence and non-disappearance (4). This alone differs. Discern how the remaining conditions support by following the eye-door process already described.

In brief, a mind-door process with sense-sphere impulsion comprises (1) mind-door adverting, (2) impulsion and (3) registration. Counting occurrences in the process, there are one adverting, seven impulsions and two registrations, ten in all. Counting the possible types of consciousness, there are one adverting, 29 sense-sphere impulsion consciousnesses and eleven registrations, 41 in all.


<a id="M07-body-P067"></a>
## The five aggregates of mind-door adverting
Miến / Burmese 67

Understand and discern the material aggregate by following the earlier model. The mental aggregates are presented next.

Mind-door adverting consciousness and eleven ethically variable factors excluding zeal and joy comprise the conditioned mental aggregates. The conditioning groups are mental conascence (10), object (1, 4 or 6), proximity (5), physical base (5) and natural decisive support (1). There are 22, 25 or 27 conditions, as applicable.

Understand and discern the ten mental conascence conditions and the one natural decisive support condition by following the determining mental aggregates. Only the differences are set out below.

2. Object group. The four mental aggregates of mind-door adverting that take an object in the ordinary way are conditioned as follows. (a) At times they take as object one of the 89 consciousnesses or 52 mental factors…


<a id="M07-body-P068"></a>
## Object, proximity and base conditions for mind-door adverting
Miến / Burmese 68

… or one of the 18 past or future concretely produced material phenomena, ten non-concretely produced material phenomena of the three periods, Nibbāna or a concept. The appropriate object among the six kinds supports by object condition (1). (b) When present concretely produced materiality is taken as an ordinary object, it supports by object, prenascence, presence and non-disappearance (4). (c) When the heart-base that arose at the arising submoment of the seventeenth consciousness counting back from death is taken as an ordinary object near death, it supports by object, dependence, prenascence, dissociation, presence and non-disappearance (6).

3. Proximity group. The immediately preceding, ceased mental aggregates of life-continuum arrest, of one of the 19 kinds, support by proximity, contiguity, decisive support, absence and disappearance (5).

4. Physical base group. Among the fifteen life-continuum types of the five-aggregate realm, the heart-base that arose at the arising submoment of the applicable life-continuum immediately before mind-door adverting supports by dependence, prenascence, dissociation, presence and non-disappearance (5). These alone are the differences.


<a id="M07-body-P069"></a>
## The first knowledge-associated great wholesome mind-door impulsion
Miến / Burmese 69

Discern the material aggregate by following the earlier model.

A mind-door process with knowledge-associated great wholesome impulsion arises taking an object among 87 consciousnesses excluding the arahant path and fruition, 52 mental factors, 28 material phenomena, Nibbāna or a concept, within the six object classes. Its first knowledge-associated great wholesome impulsion mental aggregates are conditioned by mental conascence (13), object (1, 4, 6 or 3), proximity (5), physical base (5) and natural decisive support (1). According to the case, 25, 28, 30 or 27 conditions support together as appropriate.

Those aggregates comprise the first knowledge-associated great wholesome impulsion consciousness and its applicable factors among the 33, excluding abstinences and immeasurables.


<a id="M07-body-P070"></a>
## Mental conascence in knowledge-associated great wholesome impulsion
Miến / Burmese 70

1. (a) The first knowledge-associated great wholesome impulsion consciousness and those factors support one another by conascence, mutuality, dependence, association, presence and non-disappearance (6). (b) Non-greed, non-hatred and non-delusion in those aggregates support the associated aggregates by root condition. (c) When predominance occurs, one of zeal, energy, consciousness and investigation supports by conascence predominance.

(d) Volition supports by conascent kamma. (e) Contact, volition and consciousness support by nutriment. (f) The eight mental faculties support by faculty. (g) With joy there are five jhāna factors, with equanimity four excluding joy, supporting by jhāna. (h) Wisdom, applied thought, energy, mindfulness and one-pointedness, the five path factors, support by path condition. Total: 6 + 7 = 13.

2. The four knowledge-associated great wholesome impulsion aggregates may take an ordinary object among the six object classes, comprising 87 consciousnesses excluding the arahant path and fruition, 52 mental factors, 28 material phenomena, Nibbāna and concepts, as follows…


<a id="M07-body-P071"></a>
## Ordinary and esteemed objects, and proximity
Miến / Burmese 71

(a) At times one of the 87 consciousnesses excluding the arahant path and fruition, 52 mental factors, 18 past or future concretely produced material phenomena, ten non-concretely produced material phenomena of the three periods, or a concept is taken as an ordinary object and supports by object condition (1).

(b) When one of the 18 present concretely produced material phenomena is taken as an ordinary object, it supports by object, prenascence, presence and non-disappearance (4).

(c) Near death, the heart-base arising at the arising submoment of the seventeenth consciousness counting back from death, when taken as an ordinary object, supports by object, dependence, prenascence, dissociation, presence and non-disappearance (6).

When the object is esteemed, the mental aggregates of one of the 20 wholesome consciousnesses excluding the arahant path, one of the three lower fruitions, or Nibbāna support by object, object predominance and object decisive support (3).

3. The ceased mental aggregates of mind-door adverting support by proximity, contiguity, decisive support, absence and disappearance (5).

Note. For the second impulsion aggregates, the ceased first impulsion aggregates support by proximity, contiguity, decisive support, repetition, absence and disappearance (6). Only this differs…


<a id="M07-body-P072"></a>
## Heart-base, natural decisive support and knowledge-dissociated great wholesome impulsion
Miến / Burmese 72

… The third and subsequent impulsions likewise have only one additional condition, repetition.

4. The heart-base that arose with mind-door adverting supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

Strong phenomena comprising 87 consciousnesses excluding the arahant path and fruition, 52 mental factors, 28 material phenomena and certain concepts suitable as conditions support by natural decisive support (1).

The aggregates arise and persist through the joint support of these 25, 28, 30 or 27 conditions, as applicable. Discern the second and subsequent impulsions on this model. For registration, follow the five-door account.

A mind-door process with knowledge-dissociated great wholesome impulsion arises taking as object one of the 81 mundane consciousnesses, 52 mental factors, 28 material phenomena or a concept, within the six object classes. The conditions for the first impulsion mental aggregates in this process are…


<a id="M07-body-P073"></a>
## Condition groups of knowledge-dissociated great wholesome impulsion
Miến / Burmese 73

… mental conascence (13), object (1, 4, 6 or 3), proximity (5), physical base (5) and natural decisive support (1). The totals are 25, 28, 30 or 27 as applicable. For the second and later impulsions add repetition to the proximity group.

Note. Discern the conascence, proximity, physical base and natural decisive support groups on the earlier model.

Object group. The four mental aggregates of knowledge-dissociated great wholesome impulsion taking an ordinary object are supported as follows. (a) One of the 81 mundane consciousnesses, 52 mental factors, 18 past or future concretely produced material phenomena, ten non-concretely produced material phenomena of the three periods, or a concept may support by object condition (1).

(b) When one of the 18 present concretely produced material phenomena is taken as an ordinary object, it supports by object, prenascence, presence and non-disappearance (4).


<a id="M07-body-P074"></a>
## Esteemed objects and conditioning factors in knowledge-dissociated consciousness
Miến / Burmese 74

(c) Near death, the heart-base arising at the arising submoment of the seventeenth consciousness counting back from death, when taken as an ordinary object, supports by object, dependence, prenascence, dissociation, presence and non-disappearance (6).

When the object is esteemed, the mental aggregates of one of the seventeen mundane wholesome consciousnesses as a mental object may support by object, object predominance and object decisive support (3).

The conascence, object, proximity, physical base and natural decisive support groups total 25, 28, 30 or 27 conditions, as applicable. They support together according to their power so that the mental aggregates arise and persist.

Note. Since knowledge-dissociated great wholesome impulsion is not associated with the wisdom faculty, the two roots non-greed and non-hatred support by root condition. The seven mental faculties of life, consciousness, feeling, faith, energy, mindfulness and one-pointedness support by faculty. The four path factors of applied thought, energy, mindfulness and one-pointedness support by path. Discern on this model.


<a id="M07-body-P075"></a>
## Rooted great resultant registration in the mind-door process
Miến / Burmese 75

The four rooted great resultant registration mental aggregates in the mind-door process are supported by mental conascence (13), object (4), proximity (5), physical base (5), the asynchronous kamma group (2) and natural decisive support (1).

The conditioned phenomena arise and persist through these 30 conditions working together, each according to its appropriate power.

Understand the conascence, object and proximity groups of mind-door registration by following the five-door account. The physical base and remaining groups are presented below.

4. For the first registration, the heart-base that arose at the arising submoment of the seventh sense-sphere impulsion supports by dependence, prenascence, dissociation, presence and non-disappearance (5). For the second registration, the heart-base that arose at the arising submoment of the first registration mental aggregates…


<a id="M07-body-P076"></a>
## Kamma conditioning registration and the rootless registration group
Miến / Burmese 76

… supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. Asynchronous kamma group. (a) The four mental aggregates of one of the ten wholesome-resultant registrations are supported by a strong past sense-sphere wholesome kamma through asynchronous kamma and natural decisive support (2). (b) The four mental aggregates of the equanimous unwholesome-resultant registration are supported by one of the twelve strong past unwholesome kammas through asynchronous kamma and natural decisive support (2).

6. Natural decisive support is as before.

The conditioned phenomena arise and persist through these 30 conditions working together, each according to its appropriate power.

Mental aggregates of the three kinds of rootless registration. The mental aggregates of the first rootless registration are supported by mental conascence (11), object (4)…


<a id="M07-body-P077"></a>
## Rootless registration and the physical base near death
Miến / Burmese 77

… proximity (5), physical base (5), the asynchronous kamma group (2) and natural decisive support (1).

The conditioned phenomena arise and persist through these 28 conditions working together, each according to its appropriate power.

Note. For the three rootless registrations, understand conascence by following the three investigating consciousnesses. Understand the object and other groups by following rooted registration.

Near death, the four mental aggregates of mind-door adverting, the 29 sense-sphere impulsions, the eleven registrations and death consciousness are supported by the heart-base that arose at the arising submoment of the seventeenth consciousness counting back from death, through dependence, prenascence, dissociation, presence and non-disappearance (5). With that support, the aggregates arise and persist.

If the impulsion in a sense-sphere mind-door process is greed-rooted, discern mind-door adverting and registration on the preceding model. The arising of greed-rooted impulsion mentality is explained next.


<a id="M07-body-P078"></a>
## Greed-rooted impulsion mentality at the mind door
Miến / Burmese 78

The conditioning groups are conascence (13), object (a) 1, 4 or 6, or (b) 3, 6 or 8, proximity (6), physical base (5) and natural decisive support (1). Depending on the object group, there are 26, 29 or 31 conditions, or 28, 31 or 33 conditions. They jointly support the arising and persistence of the mental aggregates according to their powers.

1. (a) One of the eight greed-rooted consciousnesses and its applicable factors among the 22, excluding hatred, envy, stinginess, remorse and doubt, support one another by conascence, mutuality, dependence, association, presence and non-disappearance (6). (b) Greed and delusion in those aggregates support the associated aggregates by root condition. (c) Volition supports by conascent kamma…


<a id="M07-body-P079"></a>
## Predominance, faculty, jhāna, path and ordinary objects of greed-rooted impulsion
Miến / Burmese 79

… (d) One of zeal, energy and consciousness supports by predominance. (e) Contact, volition and consciousness, the three mental nutriments, support by nutriment. (f) Life, consciousness, feeling, energy and one-pointedness, the five mental faculties, support by faculty. (g) The four joyful consciousnesses have five jhāna factors and the four equanimous consciousnesses have four, excluding joy, supporting by jhāna. (h) The four wrong-view-associated consciousnesses have four path factors: applied thought, energy, one-pointedness and wrong view. The four dissociated from wrong view have three, excluding wrong view. They support by path. Total: 6 + 7 = 13.

2. (A) With an ordinary object, the four mental aggregates of one of the eight greed-rooted consciousnesses are supported as follows. (a) One of the 81 mundane consciousnesses, 52 mental factors, 18 past or future concretely produced material phenomena, ten non-concretely produced material phenomena of the three periods, or a concept may support by object condition (1).

(b) When one of the 18 present concretely produced material phenomena is taken as an ordinary object, it supports by object, prenascence, presence and non-disappearance (4).

(c) Near death, the heart-base may serve as an ordinary object. It is the base that arose at the arising submoment of the consciousness…


<a id="M07-body-P080"></a>
## Esteemed objects of greed-rooted impulsion
Miến / Burmese 80

… seventeenth counting back from death, which supports by object, prenascence, dependence, dissociation, presence and non-disappearance (6).

2. (B) With an esteemed object, the four mental aggregates of one of the eight greed-rooted consciousnesses are supported as follows. (a) The 76 mundane consciousnesses excluding the two hatred-rooted, the two delusion-rooted and painful body consciousness, the 47 mental factors excluding hatred, envy, stinginess, remorse and doubt, or one of the 18 past or future concretely produced material phenomena, when esteemed, supports by object, object predominance and object decisive support (3).

(b) One of the 18 present concretely produced material phenomena, when esteemed, supports by object, object predominance, object decisive support, prenascence, presence and non-disappearance (6). (c) Near death, the heart-base arising at the arising submoment of the seventeenth consciousness counting back from death, when esteemed, supports by object, predominance, dependence, decisive support, prenascence, dissociation, presence and non-disappearance (8).

3. For the four mental aggregates of the first impulsion, the immediately preceding conditioning phenomena are the ceased mind-door adverting aggregates…


<a id="M07-body-P081"></a>
## Proximity, base and natural decisive support in greed-rooted impulsion
Miến / Burmese 81

… for the second impulsion, the immediate conditions are the four ceased mental aggregates of the first, pe, for the seventh, they are the four ceased mental aggregates of the sixth. The immediately preceding aggregates support by proximity, contiguity, decisive support, repetition, absence and disappearance (6), as applicable to the impulsion position.

4. The heart-base arising at the arising submoment of mind-door adverting supports the first impulsion, pe, the heart-base arising at the arising submoment of the sixth supports the seventh. They support by dependence, prenascence, dissociation, presence and non-disappearance (5). Near death, the heart-base arising at the arising submoment of the seventeenth consciousness counting back from death also supports by these five conditions.

Strong phenomena comprising 81 consciousnesses mundane, 52 mental factors, 28 material phenomena and certain concepts suitable as conditions support by natural decisive support (1).

The mental aggregates arise and persist through the joint support, as applicable, of 26, 29 or 31 conditions, or in the other case 28, 31 or 33.


<a id="M07-body-P082"></a>
## Hatred-rooted and delusion-rooted impulsion, and smile-producing consciousness
Miến / Burmese 82

The mental aggregates of the first hatred-rooted or delusion-rooted mind-door impulsion are supported by mental conascence (13), object (4), proximity (5), physical base (5) and natural decisive support (1).

The conditioned phenomena arise and persist through these 28 conditions working together, each according to its appropriate power.

Note. Discern by following the five-door model. In the proximity group, mind-door adverting supports the first impulsion, the first supports the second, pe, the sixth supports the seventh. Understand the physical base group similarly.

In the continuity of arahants, functional impulsions occupy the impulsion position in five-door and mind-door processes. They are the functional smile-producing consciousness (hasituppāda) and great functional impulsions. When taking an unimpressive object, such as a pile of bones, the consciousness that brings about a smile in the continuity of an arahant…


<a id="M07-body-P083"></a>
## Smile-producing consciousness in the five-door process
Miến / Burmese 83

… is functional smile-producing consciousness. The insight impulsions arising in an arahant's continuity are great functional impulsions. Understand similarly the sense-sphere functional impulsions arising in connection with the three trainings of virtue, concentration and wisdom.

If still an ordinary person or a noble trainee, the practitioner need not yet discern the Paṭṭhāna relations of these functional impulsions. Discern them only upon attaining arahantship in accordance with the perfections. The following is set out for discernment when appropriate, beginning with the relations of the smile-producing mental aggregates in a five-door process.

The mental aggregates of the first smile-producing impulsion comprise that consciousness and twelve ethically variable factors excluding zeal. The conditioning groups are mental conascence (10), object (4), proximity (5), physical base (5) and natural decisive support (1).

The conditioned phenomena arise and persist through these 25 conditions working together, each according to its appropriate power.


<a id="M07-body-P084"></a>
## Conditions for five-door smile-producing impulsion
Miến / Burmese 84

1. (a) The first smile-producing impulsion and its twelve ethically variable factors excluding zeal support one another by conascence, mutuality, dependence, association, presence and non-disappearance (6). (b) Volition in those aggregates supports by conascent kamma. (c) Contact, volition and consciousness support by nutriment. (d) Life, consciousness, feeling, energy and one-pointedness, the five mental faculties, support by faculty. (e) The five jhāna factors support by jhāna. Total: 6 + 4 = 10.

Note. Object, proximity and physical base support in the same way as explained for the first great wholesome impulsion.

Strong phenomena comprising 89 consciousnesses, 52 mental factors, 28 material phenomena and certain concepts suitable as conditions support by natural decisive support (1).

The conditioned phenomena arise and persist through these 25 conditions working together, each according to its appropriate power.

Note. From the second impulsion onward there is the additional condition of repetition. Discern according to that model. Great functional impulsion follows the great wholesome model. In five-door processes with smile-producing or great functional impulsion, the five-door adverting…


<a id="M07-body-P085"></a>
## Smile-producing impulsion at the mind door
Miến / Burmese 85

… sense consciousness, receiving, investigating, determining and registration are also to be noted and discerned as explained above. Next come mind-door processes with smile-producing or great functional impulsion.

One smile-producing consciousness and twelve ethically variable factors excluding zeal comprise the four conditioned mental aggregates. The conditioning groups are mental conascence (10), object (1, 4 or 6), proximity (5), physical base (5) and natural decisive support (1). Depending on the case, 22, 25 or 27 conditions support their arising and persistence.

1. (a) Smile-producing consciousness and those twelve factors support one another by conascence, mutuality, dependence, association, presence and non-disappearance (6)…


<a id="M07-body-P086"></a>
## Mental conascence and objects of smile-producing consciousness at the mind door
Miến / Burmese 86

… (b) Volition in the smile-producing mental aggregates supports by conascent kamma. (c) Contact, volition and consciousness support by nutriment. (d) The three mental faculties of life, consciousness and feeling support by faculty. (e) The five jhāna factors support by jhāna. Total: 6 + 4 = 10.

2. The four smile-producing mental aggregates taking an ordinary object are supported as follows. (a) One of the 54 sense-sphere consciousnesses, 52 mental factors, 18 past or future concretely produced material phenomena, or ten non-concretely produced material phenomena of the three periods, when taken as an ordinary object among the six sense-sphere object classes, supports by object condition (1).

(b) When one of the 18 present concretely produced material phenomena is taken as an ordinary object, it supports by object, prenascence, presence and non-disappearance (4).

(c) Near death, the heart-base arising at the arising submoment of the seventeenth consciousness counting back from death, when taken as an ordinary object, supports by object, dependence, prenascence, dissociation, presence and non-disappearance (6).

3. The immediately preceding, ceased mind-door adverting mental aggregates…


<a id="M07-body-P087"></a>
## From smile-producing to knowledge-associated great functional impulsion
Miến / Burmese 87

… support by proximity, contiguity, decisive support, absence and disappearance (5).

4. The heart-base that arose with the arising submoment of the mind-door adverting aggregates supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

Strong phenomena comprising 89 consciousnesses, 52 mental factors, 28 material phenomena and certain concepts suitable as conditions support by natural decisive support (1).

The mental aggregates arise and persist through the joint support of these 22, 25 or 27 conditions, as applicable. From the second impulsion, add repetition, giving 23, 26 or 28 conditions. Discern mind-door adverting and registration on the earlier model.

A mind-door process with knowledge-associated great functional impulsion arises taking as object one of the 89 consciousnesses, 52 mental factors, 28 material phenomena, Nibbāna or a concept, within the six object classes. Discern mind-door adverting on the model of the great wholesome process. Knowledge-associated great functional impulsion is presented next.


<a id="M07-body-P088"></a>
## Mental conascence of the first great functional impulsion
Miến / Burmese 88

The mental aggregates of the first great functional impulsion are supported by mental conascence (13), object (1, 4, 6 or 3), proximity (5), physical base (5) and natural decisive support (1). They arise and persist through 25, 28, 30 or 27 conditions working together, as applicable.

1. (a) The mental aggregates of the first great functional impulsion support one another by conascence, mutuality, dependence, association, presence and non-disappearance (6). (b) Non-greed and non-hatred support in the two-rooted case, and non-greed, non-hatred and non-delusion in the three-rooted case. These two or three roots support by root condition. (c) Where there is predominance, one of zeal, energy and consciousness in the two-rooted case, or one of zeal, energy, consciousness and investigation in the three-rooted case, supports by predominance.


<a id="M07-body-P089"></a>
## Faculty, jhāna, path and objects of great functional impulsion
Miến / Burmese 89

(d) Volition in the first impulsion aggregates supports the associated aggregates by conascent kamma. (e) Contact, volition and consciousness support by nutriment. (f) Seven mental faculties excluding wisdom in the two-rooted case, or eight in the three-rooted case, support by faculty. (g) Five jhāna factors support with joy, or four with equanimity. (h) In the two-rooted case, applied thought, energy, mindfulness and one-pointedness are four path factors. In the three-rooted case wisdom is added, making five. They support by path condition. Total: 6 + 7 = 13.

2. When taking an ordinary object, the four mental aggregates of the first great functional impulsion are supported as follows. (a) One of the 89 consciousnesses, 52 mental factors, 18 past or future concretely produced material phenomena, ten non-concretely produced material phenomena of the three periods, or a concept supports by object condition (1).

(b) When one of the 18 present concretely produced material phenomena is taken as an ordinary object, it supports by object, prenascence, presence and non-disappearance (4).


<a id="M07-body-P090"></a>
## Near-death and esteemed objects of great functional impulsion
Miến / Burmese 90

(c) Near death, the heart-base arising at the arising submoment of the seventeenth consciousness counting back from death, when taken as an ordinary object, supports by object, dependence, prenascence, dissociation, presence and non-disappearance (6).

(c) When taking an esteemed object, the four mental aggregates of the first knowledge-associated great functional impulsion are supported by one of the mental objects, the arahant path, arahant fruition or Nibbāna, through object, object predominance and object decisive support (3).

Note. Understand proximity, physical base and natural decisive support on the model of great wholesome impulsion.

The mental aggregates arise and persist through the joint support, as applicable, of 25, 28, 30 or 27 conditions. Note. From the second impulsion, add repetition in the proximity group, giving 26, 29, 31 or 28 conditions respectively.


<a id="M07-body-P091"></a>
## Sense-sphere and absorption impulsions
Miến / Burmese 91

Absorption impulsion in the mind-door process.

1. After unprompted or prompted knowledge-associated great wholesome consciousness accompanied by joy, the following joyful absorption impulsions can arise: (a) four exalted wholesome, (b) sixteen path and (c) twelve lower fruition, 32 in all.

2. After unprompted or prompted knowledge-associated great wholesome consciousness accompanied by equanimity, the following equanimous absorption impulsions can arise: (a) five exalted wholesome, (b) four path and (c) three lower fruition, twelve in all.

3. After unprompted or prompted knowledge-associated great functional consciousness accompanied by joy, the following absorption impulsions can arise…


<a id="M07-body-P092"></a>
## Functional absorption types and exalted wholesome processes
Miến / Burmese 92

… (a) four joyful exalted functional and (b) four joyful arahant-fruition impulsions, eight in all. 4. After unprompted or prompted knowledge-associated great functional consciousness accompanied by equanimity, there can arise (a) five equanimous exalted functional impulsions and (b) one equanimous arahant-fruition impulsion, six in all.

There are nine exalted wholesome impulsion processes for initial attainment and nine for attainment entry, eighteen in all.

The initial exalted wholesome process consists of life-continuum vibration, life-continuum arrest, mind-door adverting, preparation (parikamma), access (upacāra), conformity (anuloma) and change of lineage (gotrabhū). Then one of the nine exalted wholesome impulsions at initial attainment arises once only, performs the function of absorption concentration, and ceases. Thereafter one of the thirteen three-rooted life-continuum consciousnesses…


<a id="M07-body-P093"></a>
## Attainment entry and conditions for exalted wholesome mentality
Miến / Burmese 93

… arises and ceases, performing the function of the life-continuum, life-continuum following life-continuum as applicable.

The exalted wholesome attainment process consists of life-continuum vibration, life-continuum arrest, mind-door adverting, preparation, access, conformity and change of lineage. Then one of the nine exalted wholesome impulsions arises many times, performing absorption concentration in succession like the life-continuum, and ceases. Thereafter one of the thirteen three-rooted life-continuum consciousnesses arises and ceases, performing the function of the life-continuum, life-continuum following life-continuum as applicable.

The four mental aggregates of one of the nine exalted wholesome impulsions are supported by mental conascence (13), object (1), proximity (6), physical base (5) and natural decisive support (1).

The conditioned phenomena arise and persist through these 26 conditions working together, each according to its appropriate power.


<a id="M07-body-P094"></a>
## Mental conascence in the nine exalted wholesome impulsions
Miến / Burmese 94

1. (a) The mental aggregates of one of the nine exalted wholesome consciousnesses support one another by conascence, mutuality, dependence, association, presence and non-disappearance (6). (b) Non-greed, non-hatred and non-delusion support the associated aggregates by root condition. (c) One of zeal, energy, consciousness and investigation supports by predominance. (d) Volition supports by conascent kamma. (e) Contact, volition and consciousness, the three mental nutriments, support by nutriment. (f) Life, consciousness, feeling, faith, energy, mindfulness, one-pointedness and wisdom, the eight mental faculties, support by faculty.

(g) Exalted wholesome consciousness has five jhāna factors in the first jhāna, four in the second, three in the third, two in the fourth and two in the fifth. These support by jhāna condition. (h) The first jhāna has five path factors excluding abstinences. The second through fifth have four, also excluding applied thought. These support by path condition. Total: 6 + 7 = 13.


<a id="M07-body-P095"></a>
## Conceptual objects conditioning fine-material jhāna
Miến / Burmese 95

2. The four wholesome mental aggregates of the first fine-material jhāna are supported by an appropriate conceptual object among the following 25: (a) ten kasiṇas, (b) ten foulness subjects, (c) the 32 body parts as object of mindfulness of the body, (d) the sign of in- and out-breathing, that is, the counterpart sign in mindfulness of breathing, (e) beings who are happy or suffering as object of loving-kindness, (f) suffering beings as object of compassion, and (g) happy beings as object of appreciative joy. That object supports by object condition (1).

The objects supporting the four wholesome mental aggregates of the second, third and fourth fine-material jhānas are (a) ten kasiṇas, (b) the breathing counterpart sign, (c) happy or suffering beings as object of loving-kindness, (d) suffering beings as object of compassion and (e) happy beings as object of appreciative joy…


<a id="M07-body-P096"></a>
## Object condition for the fifth fine-material jhāna and the immaterial attainments
Miến / Burmese 96

… An appropriate one of these 14 conceptual objects is the conditioning phenomenon by object condition (1).

The conditioned phenomena are the four wholesome mental aggregates of the fifth fine-material jhāna. The objects are (a) the ten kasiṇa concepts, (b) the concept of in- and out-breathing, the object of mindfulness of breathing, namely its counterpart sign, and (c) the concept of all happy and suffering beings, the object of the divine abiding of equanimity. An appropriate one of these twelve conceptual objects is the conditioning phenomenon by object condition (1).

The four wholesome mental aggregates of the base of infinite space are the conditioned phenomena. The concept of space obtained by removing any one of the nine kasiṇas, excluding the space kasiṇa, is the conditioning phenomenon by object condition (1).

The four wholesome mental aggregates of the base of infinite consciousness are the conditioned phenomena. The past wholesome mental aggregates of the base of infinite space are the conditioning phenomena by object condition (1).

The four wholesome mental aggregates of the base of nothingness are the conditioned phenomena. The concept of absence (natthibhāvapaññatti), namely the absence of the jhāna consciousness of the base of infinite space, is the conditioning phenomenon by object condition (1).

The four wholesome mental aggregates of the base of neither perception nor non-perception are the conditioned phenomena. The past wholesome mental aggregates of the base of nothingness are the conditioning phenomena by object condition (1).


<a id="M07-body-P097"></a>
## Proximity conditions for exalted wholesome impulsion
Miến / Burmese 97

3. The conditioned phenomena are the four mental aggregates of the first thiện đáo đại impulsion accompanied by joy (4 types). The conditioning phenomena are the mental aggregates of unprompted or prompted knowledge-associated great wholesome consciousness accompanied by joy performing the function of change of lineage (gotrabhū), which have just ceased with no interval. They support by proximity, contiguity, decisive support, repetition, absence and disappearance (6).

The conditioned phenomena are the four mental aggregates of the second and subsequent thiện đáo đại impulsions accompanied by joy (4 types). The conditioning phenomena are the mental aggregates of the immediately preceding thiện đáo đại impulsion of the same kind accompanied by joy, beginning with the first impulsion, which have just ceased with no interval. They support by proximity, contiguity, decisive support, repetition, absence and disappearance (6).

The conditioned phenomena are the four mental aggregates of the first thiện đáo đại impulsion accompanied by equanimity (5 types). The conditioning phenomena are the mental aggregates of unprompted or prompted knowledge-associated great wholesome consciousness accompanied by equanimity performing the function of change of lineage (gotrabhū), which have just ceased with no interval. They support by proximity, contiguity, decisive support, repetition, absence and disappearance (6).

The conditioned phenomena are the four mental aggregates of the second and subsequent thiện đáo đại impulsions accompanied by equanimity (5 types). The conditioning phenomena are the mental aggregates of the immediately preceding thiện đáo đại impulsion of the same kind accompanied by equanimity, beginning with the first impulsion, which have just ceased with no interval. They support by proximity, contiguity, decisive support, repetition, absence and disappearance (6).


<a id="M07-body-P098"></a>
## Physical-base conditions for exalted wholesome impulsion
Miến / Burmese 98

4. The conditioned phenomena are the four mental aggregates of the first thiện đáo đại impulsion accompanied by joy (4 types). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of unprompted or prompted knowledge-associated great wholesome consciousness accompanied by joy performing the function of change of lineage (gotrabhū). It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

The conditioned phenomena are the four mental aggregates of the second and subsequent thiện đáo đại impulsions accompanied by joy (4 types). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of the immediately preceding thiện đáo đại impulsion of the same kind accompanied by joy, beginning with the first impulsion. It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

The conditioned phenomena are the four mental aggregates of the first thiện đáo đại impulsion accompanied by equanimity (5 types). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of unprompted or prompted knowledge-associated great wholesome consciousness accompanied by equanimity performing the function of change of lineage (gotrabhū). It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

The conditioned phenomena are the four mental aggregates of the second and subsequent thiện đáo đại impulsions accompanied by equanimity (5 types). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of the immediately preceding thiện đáo đại impulsion of the same kind accompanied by equanimity, beginning with the first impulsion. It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).


<a id="M07-body-P099"></a>
## Natural decisive support and the mental aggregates of exalted functional impulsion
Miến / Burmese 99

5. The conditioned phenomena are the four mental aggregates of the nine kinds of exalted wholesome impulsion. The conditioning phenomena are strong phenomena comprising the 87 consciousnesses, excluding the arahant path and fruition, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions. They support by natural decisive support (1).

These phenomena arise and persist through the simultaneous support of these 26 conditions, each according to its appropriate power.

❀ ❀ ❀

If the good person who is learning reaches arahantship and also obtains the jhāna attainments, they can discern the following account of the conditional relations of exalted functional impulsions according to the Paṭṭhāna.

The mental aggregates of exalted functional impulsion

The conditioned phenomena are the four mental aggregates of the nine kinds of exalted functional impulsion —

1. Conascence group — 13.

2. Object group — 1.

3. Proximity group — 6.

4. Physical-base group — 5.

5. Natural decisive support — 1.

Those conditioned phenomena arise and persist through the simultaneous support of these 26 conditions, each according to its appropriate power.


<a id="M07-body-P100"></a>
## Conascence conditions of exalted functional impulsion
Miến / Burmese 100

The conditioned phenomena are the four mental aggregates of the nine kinds of exalted functional impulsion.

1. (a) The nine kinds of exalted functional impulsion and the 35 mental factors excluding the abstinences support one another. Those constituent mental aggregates support by conascence, mutuality, dependence, association, presence and non-disappearance (6).

(b) The three roots of non-greed, non-hatred and non-delusion in the mental aggregates of the nine kinds of exalted functional impulsion support the associated aggregates by root condition.

(c) One of the four phenomena of zeal, energy, consciousness and investigation supports by predominance.

(d) Volition supports by conascent kamma.

(e) Contact, volition and consciousness, the three mental nutriments, support by nutriment.

(f) The eight mental faculties of life, consciousness, feeling, faith, energy, mindfulness, one-pointedness and wisdom support by faculty.

(g) When exalted functional consciousness arises, the jhāna factors are the conditioning phenomena by jhāna condition:
• First jhāna (1 types of consciousness) — 5 jhāna factors.
• Second jhāna (1 types of consciousness) — 4 jhāna factors.
• Third jhāna (1 types of consciousness) — 3 jhāna factors.
• Fourth jhāna (1 types of consciousness) — 2 jhāna factors.
• Fifth jhāna (5 types of consciousness) — 2 jhāna factors.

(h) When first-jhāna exalted functional consciousness (one type) arises, there are five path factors excluding the abstinences. When second-jhāna exalted functional consciousness (one type), third…


<a id="M07-body-P101"></a>
## Path factors and objects of exalted functional impulsion
Miến / Burmese 101

… jhāna (one type), fourth jhāna (one type) or fifth jhāna (five types) arises, the four path factors excluding the abstinences and applied thought are the conditioning phenomena by path condition (7). Total: 6 + 7 = 13.

2. (a) The conditioned phenomena are the four functional mental aggregates of the first fine-material jhāna. One of the 25 conceptual objects is the conditioning phenomenon by object condition (1).

(b) The conditioned phenomena are the four functional mental aggregates of the second, third and fourth fine-material jhānas. One of the 14 conceptual objects is the conditioning phenomenon by object condition (1).

(c) The conditioned phenomena are the four functional mental aggregates of the fifth fine-material jhāna. One of the 12 conceptual objects is the conditioning phenomenon by object condition (1).

(d) The conditioned phenomena are the four functional mental aggregates of the base of infinite space. The concept of space obtained by removing any one of the nine kasiṇas, excluding the space kasiṇa, is the conditioning phenomenon by object condition (1).

(e) The conditioned phenomena are the four functional mental aggregates of the base of infinite consciousness. One of the two past objects, wholesome or functional consciousness of the base of infinite space, is the conditioning phenomenon by object condition (1).

[Note — Wholesome consciousness of the base of infinite space previously arisen in one’s own continuum in this life or a former life, and functional consciousness of the base of infinite space previously arisen in one’s own continuum in this life…


<a id="M07-body-P102"></a>
## Immaterial objects and the proximity group
Miến / Burmese 102

… Both the wholesome and the functional kind can serve as an object for the mental aggregates of functional impulsion of the base of infinite consciousness.]

(f) The conditioned phenomena are the four functional mental aggregates of the base of nothingness. The concept of absence, namely the absence of the jhāna consciousness of the base of infinite space, is the conditioning phenomenon by object condition (1).

(g) The conditioned phenomena are the four functional mental aggregates of the base of neither perception nor non-perception. One of the two past objects, wholesome or functional consciousness of the base of nothingness, is the conditioning phenomenon by object condition (1).

3. (a) The conditioned phenomena are the four mental aggregates of the first duy tác đáo đại impulsion accompanied by joy (4 types). The conditioning phenomena are the mental aggregates of unprompted or prompted knowledge-associated great functional consciousness accompanied by joy performing the function of change of lineage (gotrabhū), which have just ceased with no interval. They support by proximity, contiguity, decisive support, repetition, absence and disappearance (6).

(b) The conditioned phenomena are the four mental aggregates of the first duy tác đáo đại impulsion accompanied by equanimity (5 types). The conditioning phenomena are the mental aggregates of unprompted or prompted knowledge-associated great functional consciousness accompanied by equanimity performing the function of change of lineage (gotrabhū), which have just ceased with no interval. They support by proximity, contiguity, decisive support, repetition, absence and disappearance (6).

(c) The second and subsequent exalted functional impulsions…


<a id="M07-body-P103"></a>
## Proximity and physical-base groups
Miến / Burmese 103

… accompanied by joy or equanimity have the four mental aggregates as conditioned phenomena. The mental aggregates of the immediately preceding exalted functional impulsion of the same kind, accompanied by joy or equanimity, beginning with the first impulsion, have just ceased with no interval. They are the conditioning phenomena by proximity, contiguity, decisive support, repetition, absence and disappearance (6).

4. (a) The conditioned phenomena are the four mental aggregates of the first duy tác đáo đại impulsion accompanied by joy (4 types). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of unprompted or prompted knowledge-associated great functional consciousness accompanied by joy performing the function of change of lineage (gotrabhū). It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

(b) The conditioned phenomena are the four mental aggregates of the second and subsequent duy tác đáo đại impulsions accompanied by joy (4 types). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of the immediately preceding duy tác đáo đại impulsion of the same kind accompanied by joy, beginning with the first impulsion. It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

(c) The conditioned phenomena are the four mental aggregates of the first duy tác đáo đại impulsion accompanied by equanimity (5 types). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of unprompted or prompted knowledge-associated great functional consciousness accompanied by equanimity performing the function of change of lineage (gotrabhū). It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).


<a id="M07-body-P104"></a>
## Natural decisive support and the mental aggregates of noble-path impulsion
Miến / Burmese 104

(d) The conditioned phenomena are the four mental aggregates of the second and subsequent duy tác đáo đại impulsions accompanied by equanimity (5 types). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of the immediately preceding duy tác đáo đại impulsion of the same kind accompanied by equanimity, beginning with the first impulsion. It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. The conditioned phenomena are the four mental aggregates of the nine kinds of exalted functional impulsion. The conditioning phenomena are strong phenomena comprising the 89 consciousnesses, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions. They support by natural decisive support (1).

These phenomena arise and persist through the simultaneous support of these 26 conditions, each according to its appropriate power.

❀ ❀ ❀

The mental aggregates of noble-path impulsion

The conditioned phenomena are the four mental aggregates of the 20 kinds of noble-path impulsion —

1. Conascence group — 13.

2. Object group — 3.

3. Proximity group — 6.

4. Physical-base group — 5.

5. Natural decisive support — 1.

Those conditioned phenomena arise and persist through the simultaneous support of these 28 conditions, each according to its appropriate power.


<a id="M07-body-P105"></a>
## Conascence conditions of noble-path impulsion
Miến / Burmese 105

The conditioned phenomena are the four mental aggregates of the 20 kinds of noble-path impulsion.

1. (a) The 20 kinds of noble-path impulsion and the 36 mental factors excluding the immeasurables support one another. Those constituent mental aggregates support by conascence, mutuality, dependence, association, presence and non-disappearance (6).

(b) The three roots of non-greed, non-hatred and non-delusion in the mental aggregates of the 20 kinds of noble-path impulsion support the associated aggregates by root condition.

(c) One of the four phenomena of zeal, energy, consciousness and investigation supports by predominance.

(d) Volition supports by conascent kamma.

(e) Contact, volition and consciousness, the three mental nutriments, support by nutriment.

(f) The eight mental faculties of life, consciousness, feeling, faith, energy, mindfulness, one-pointedness and wisdom support by faculty.

(g) When noble-path consciousness arises, the jhāna factors are the conditioning phenomena by jhāna condition:
• First jhāna (4 types of consciousness) — 5 jhāna factors.
• Second jhāna (4 types of consciousness) — 4 jhāna factors.
• Third jhāna (4 types of consciousness) — 3 jhāna factors.
• Fourth jhāna (4 types of consciousness) — 2 jhāna factors.
• Fifth jhāna (4 types of consciousness) — 2 jhāna factors.

(h) When one of the four first-jhāna path consciousnesses arises, there are eight path factors. When a second-, third-, fourth- or fifth-jhāna path consciousness arises…


<a id="M07-body-P106"></a>
## Nibbāna as object and conditions supporting the noble path
Miến / Burmese 106

… the seven path factors excluding applied thought are the conditioning phenomena by path condition (7). Total: 6 + 7 = 13.

2. Nibbāna as object is the conditioning phenomenon by object, object predominance and object decisive support (3).

3. (a) The conditioned phenomena are the four mental aggregates of the 16 kinds of noble-path impulsion accompanied by joy. The conditioning phenomena are the mental aggregates of unprompted or prompted knowledge-associated great wholesome consciousness accompanied by joy, performing the function of change of lineage (gotrabhū) or cleansing (vodāna), which have just ceased with no interval. They support by proximity, contiguity, decisive support, repetition, absence and disappearance (6).

(b) The conditioned phenomena are the four mental aggregates of the 4 kinds of noble-path impulsion accompanied by equanimity. The conditioning phenomena are the mental aggregates of unprompted or prompted knowledge-associated great wholesome consciousness accompanied by equanimity, performing the function of change of lineage (gotrabhū) or cleansing (vodāna), which have just ceased with no interval. They support by proximity, contiguity, decisive support, repetition, absence and disappearance (6).

4. (a) The conditioned phenomena are the four mental aggregates of the 16 kinds of noble-path impulsion accompanied by joy. The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of unprompted or prompted knowledge-associated great wholesome consciousness accompanied by joy, performing change of lineage or cleansing. It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

(b) The conditioned phenomena are the four mental aggregates of the four kinds of noble-path impulsion accompanied by equanimity. The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates performing change of lineage or cleansing…


<a id="M07-body-P107"></a>
## Natural decisive support for the four noble paths
Miến / Burmese 107

… of unprompted or prompted knowledge-associated great wholesome consciousness accompanied by equanimity. It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. (a) The conditioned phenomena are the four mental aggregates of the five kinds of stream-entry path impulsion. The conditioning phenomena are strong phenomena comprising the 81 mundane consciousnesses, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions. They support by natural decisive support (1).

(b) The conditioned phenomena are the four mental aggregates of the five kinds of once-return path impulsion. The conditioning phenomena are strong phenomena comprising the 81 mundane consciousnesses, the stream-entry path, the stream-entry fruition, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions. They support by natural decisive support (1).

(c) The conditioned phenomena are the four mental aggregates of the five kinds of non-return path impulsion. The conditioning phenomena are strong phenomena comprising the 81 mundane consciousnesses, the stream-entry path, the stream-entry fruition, the once-return path, the once-return fruition, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions. They support by natural decisive support (1).

(d) The conditioned phenomena are the four mental aggregates of the five kinds of arahantship path impulsion. The conditioning phenomena are strong phenomena comprising the 81 mundane consciousnesses, the stream-entry path, the stream-entry fruition, the once-return path, the once-return fruition, the non-return path, the non-return fruition, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions…


<a id="M07-body-P108"></a>
## Fruition attainment and the arising of the 20 fruition impulsions immediately after the path
Miến / Burmese 108

… They support by natural decisive support (1).

These phenomena arise and persist through the simultaneous support of these 28 conditions, each according to its appropriate power.

❀ ❀ ❀

Section on fruition attainment (phalasamāpatti)

How the 20 fruition impulsions arise immediately after the path

The conditioned phenomena are the four mental aggregates of the 20 kinds of fruition impulsion immediately after the path —

1. Conascence group — 14.

2. Object group — 3.

3. Proximity group — 6.

4. Physical-base group — 5.

5. Natural decisive support — 1.

Those conditioned phenomena arise and persist through the simultaneous support of these 29 conditions, each according to its appropriate power.

The conditioned phenomena are the four mental aggregates of the 20 kinds of fruition impulsion immediately after the path.

1. (a) The 20 kinds of fruition impulsion immediately after the path and the 36 mental factors excluding the immeasurables support one another. Those constituent mental aggregates support by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

(b) Non-greed, non-hatred and non-delusion in the mental aggregates of the 20 kinds of fruition impulsion immediately after the path support the associated aggregates…


<a id="M07-body-P109"></a>
## Conascence, object and proximity conditions of fruition immediately after the path
Miến / Burmese 109

… These three roots are the conditioning phenomena by root condition.

(c) One of the four phenomena of zeal, energy, consciousness and investigation supports by predominance.

(d) Volition supports by conascent kamma.

(e) Contact, volition and consciousness, the three mental nutriments, support by nutriment.

(f) The eight mental faculties of life, consciousness, feeling, faith, energy, mindfulness, one-pointedness and wisdom support by faculty.

(g) When fruition immediately after the path consciousness arises, the jhāna factors are the conditioning phenomena by jhāna condition:
• First jhāna (4 types of consciousness) — 5 jhāna factors.
• Second jhāna (4 types of consciousness) — 4 jhāna factors.
• Third jhāna (4 types of consciousness) — 3 jhāna factors.
• Fourth jhāna (4 types of consciousness) — 2 jhāna factors.
• Fifth jhāna (4 types of consciousness) — 2 jhāna factors.

(h) When first-jhāna fruition consciousness immediately after the path arises, there are eight path factors. When second-jhāna (four types), third-jhāna (four types), fourth-jhāna (four types), or fifth-jhāna (four types) fruition consciousness immediately after the path arises, the seven path factors excluding applied thought are the conditioning phenomena by path condition (7). Total: 7 + 7 = 14.

2. Nibbāna as object is the conditioning phenomenon by object, object predominance and object decisive support (3).

3. Among the 20 kinds of noble-path impulsion, the mental aggregates of the corresponding path impulsion, which have just ceased with no interval, are the conditioning phenomena by…


<a id="M07-body-P110"></a>
## Physical-base and natural decisive support conditions of fruition immediately after the path
Miến / Burmese 110

… proximity, contiguity, decisive support, kamma, absence and disappearance (6).

4. Among the 20 kinds of noble-path impulsion, the heart-base that arose at the arising submoment of the mental aggregates of the corresponding noble-path impulsion is the conditioning phenomenon by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. (a) The conditioned phenomena are the four mental aggregates of the five kinds of stream-entry fruition impulsion. The conditioning phenomena are strong phenomena comprising the 81 mundane consciousnesses, the stream-entry path, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions. They support by natural decisive support (1).

(b) The conditioned phenomena are the four mental aggregates of the five kinds of once-return fruition impulsion. The conditioning phenomena are strong phenomena comprising the 81 mundane consciousnesses, the stream-entry path, the stream-entry fruition, the once-return path, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions. They support by natural decisive support (1).

(c) The conditioned phenomena are the four mental aggregates of the five kinds of non-return fruition impulsion. The conditioning phenomena are strong phenomena comprising the 81 mundane consciousnesses, the stream-entry path, the stream-entry fruition, the once-return path, the once-return fruition, the non-return path, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions. They support by natural decisive support (1).

(d) The conditioned phenomena are the four mental aggregates of the five kinds of arahantship fruition impulsion. The conditioning phenomena are strong phenomena comprising the 81 mundane consciousnesses…


<a id="M07-body-P111"></a>
## Fruition impulsions in fruition attainment
Miến / Burmese 111

… the stream-entry path and fruition, the once-return path and fruition, the non-return path and fruition, the arahant path, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions. They support by natural decisive support (1).

These phenomena arise and persist through the simultaneous support of these 29 conditions, each according to its appropriate power.

❀ ❀ ❀

How the 20 fruition impulsions in fruition attainment arise

There are vibration of the life-continuum, arrest of the life-continuum, mind-door adverting and four or three occurrences of conformity (anuloma). Stream-entry fruition consciousness, or once-return, non-return or arahant fruition consciousness, then arises and ceases many times in succession, like the life-continuum. Thereafter an appropriate one of the thirteen three-rooted life-continuum consciousnesses arises and ceases, life-continuum following life-continuum … performing that function for as long as appropriate.

[Note — In the fruition-attainment processes of stream-entry, once-return and non-return, the consciousness performing conformity is one of the four knowledge-associated great wholesome consciousnesses. In the arahant fruition-attainment process, the consciousness performing conformity is one of the four knowledge-associated great functional consciousnesses. The stream-enterer can enter stream-entry fruition attainment, the once-returner once-return fruition attainment, the non-returner non-return fruition attainment and the arahant arahant fruition attainment, each…


<a id="M07-body-P112"></a>
## Distinguishing fruition immediately after the path from fruition attainment
Miến / Burmese 112

… according to their own fruition. On entering the corresponding fruition attainment, one can discern the Paṭṭhāna conditional relations as shown below, both for noble fruition impulsions in fruition attainment and for fruition impulsions in the path process distinct from the one immediately following the path.]

A point to note carefully

In a noble-path process, the corresponding noble fruition impulsion occurs twice or three times after the noble path. Fruition impulsion immediately after the path is the corresponding noble fruition impulsion that occurs directly after the noble path. To be precise, when noble fruition impulsion occurs twice or three times in a path process, the first is fruition immediately after the path. The second noble fruition impulsion, or the second and third, are fruition impulsions distinct from the one immediately following the path.

Noble persons can enter again the noble fruition they have attained. This is called fruition attainment (phalasamāpatti). Note that the fruition impulsions in that attainment process also belong to the fruition impulsions distinct from the one immediately following the path.

The Paṭṭhāna conditional relations of fruition immediately after the path have already been set out. What follows sets out the Paṭṭhāna conditional relations of the mental aggregates of fruition impulsions distinct from fruition immediately after the path, that is, fruition impulsions in fruition attainment.


<a id="M07-body-P113"></a>
## Groups of conditions for fruition impulsions distinct from fruition immediately after the path
Miến / Burmese 113

The conditioned phenomena are the four mental aggregates of the 20 kinds of fruition impulsion distinct from the 20 kinds immediately following the path —

1. Conascence group — 14.

2. Object group — 3.

3. Proximity group — 5.

4. Physical-base group — 5.

5. Asynchronous kamma group — 2.

6. Natural decisive support — 1.

These phenomena arise and persist through the simultaneous support of these 30 conditions, each according to its appropriate power.

The conditioned phenomena are the four mental aggregates of the 20 kinds of fruition impulsion distinct from the 20 kinds immediately following the path.

1. (a) The 20 kinds of fruition impulsion distinct from the 20 kinds immediately following the path and the 36 mental factors excluding the immeasurables support one another. Those constituent mental aggregates support by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

(b) The three roots of non-greed, non-hatred and non-delusion in the mental aggregates of the 20 kinds of fruition impulsion distinct from the 20 kinds immediately following the path support the associated aggregates by root condition.

(c) One of the four phenomena of zeal, energy, consciousness and investigation supports by predominance.

(d) Volition supports by conascent kamma.


<a id="M07-body-P114"></a>
## Jhāna, path, object and proximity conditions in fruition attainment
Miến / Burmese 114

(e) Contact, volition and consciousness, the three mental nutriments, support by nutriment.

(f) The eight mental faculties of life, consciousness, feeling, faith, energy, mindfulness, one-pointedness and wisdom support by faculty.

(g) For fruition impulsion distinct from fruition immediately after the path, there are five jhāna factors in first-jhāna fruition, four in the second, three in the third, two in the fourth and two in the fifth. These factors support by jhāna condition.

(h) If that impulsion is first-jhāna fruition, there are eight path factors. If it is second-, third-, fourth- or fifth-jhāna fruition, the seven path factors excluding applied thought are the conditioning phenomena by path condition (7). Total: 7 + 7 = 14.

2. Nibbāna as object is the conditioning phenomenon by object, object predominance and object decisive support (3).

3. (a) The conditioned phenomena are the four mental aggregates of the 12 kinds of first lower fruition impulsion accompanied by joy (in the fruition-attainment process). The conditioning phenomena are the mental aggregates of unprompted or prompted knowledge-associated great wholesome consciousness accompanied by joy performing the function of conformity (anuloma), which have just ceased with no interval. They support by proximity, contiguity, decisive support, absence and disappearance (5).

[This refers to the first fruition impulsion in the fruition-attainment process.]


<a id="M07-body-P115"></a>
## Proximity conditions of lower fruition and arahant fruition impulsions
Miến / Burmese 115

(b) The conditioned phenomena are the four mental aggregates of the 12 kinds of lower fruition impulsion accompanied by joy, from the second impulsion onward (in the path process and the fruition-attainment process). The conditioning phenomena are the mental aggregates of the immediately preceding lower fruition impulsion of the same kind accompanied by joy, beginning with the first impulsion (12 kinds), which have just ceased with no interval. They support by proximity, contiguity, decisive support, absence and disappearance (5).

(c) The conditioned phenomena are the four mental aggregates of the 3 kinds of first lower fruition impulsion accompanied by equanimity (in the fruition-attainment process). The conditioning phenomena are the mental aggregates of unprompted or prompted knowledge-associated great wholesome consciousness accompanied by equanimity performing the function of conformity (anuloma), which have just ceased with no interval. They support by proximity, contiguity, decisive support, absence and disappearance (5).

(d) The conditioned phenomena are the four mental aggregates of the 3 kinds of lower fruition impulsion accompanied by equanimity, from the second impulsion onward (in the path process and the fruition-attainment process). The conditioning phenomena are the mental aggregates of the immediately preceding lower fruition impulsion of the same kind accompanied by equanimity, beginning with the first impulsion (3 kinds), which have just ceased with no interval. They support by proximity, contiguity, decisive support, absence and disappearance (5).

(e) The conditioned phenomena are the four mental aggregates of the 4 kinds of first arahant fruition impulsion accompanied by joy (in the arahant fruition-attainment process)…


<a id="M07-body-P116"></a>
## Proximity conditions of arahant fruition impulsion
Miến / Burmese 116

… The conditioning phenomena are the mental aggregates of unprompted or prompted knowledge-associated great functional consciousness accompanied by joy performing the function of conformity (anuloma), which have just ceased with no interval. They support by proximity, contiguity, decisive support, absence and disappearance (5).

(This refers to the first arahant fruition impulsion in the fruition-attainment process.)

(f) The conditioned phenomena are the four mental aggregates of the 4 kinds of arahant fruition impulsion accompanied by joy, from the second impulsion onward (in the arahant path process and the arahant fruition-attainment process). The conditioning phenomena are the mental aggregates of the immediately preceding arahant fruition impulsion of the same kind accompanied by joy, beginning with the first impulsion (4 kinds), which have just ceased with no interval. They support by proximity, contiguity, decisive support, absence and disappearance (5).

(g) The conditioned phenomena are the four mental aggregates of the first arahant fruition impulsion accompanied by equanimity (one kind) (in the arahant fruition-attainment process). The conditioning phenomena are the mental aggregates of unprompted or prompted knowledge-associated great functional consciousness accompanied by equanimity performing the function of conformity (anuloma), which have just ceased with no interval. They support by proximity, contiguity, decisive support, absence and disappearance (5).

(h) The conditioned phenomena are the four mental aggregates of the 1 kinds of arahant fruition impulsion accompanied by equanimity, from the second impulsion onward (in the arahant path process and the arahant fruition-attainment process)…


<a id="M07-body-P117"></a>
## Conditions upon emerging from cessation and physical-base conditions
Miến / Burmese 117

… The conditioning phenomena are the mental aggregates of the immediately preceding arahant fruition impulsion of the same kind accompanied by equanimity, beginning with the first impulsion (1 kinds), which have just ceased with no interval. They support by proximity, contiguity, decisive support, absence and disappearance (5).

(i) When a non-returner emerges from the attainment of cessation, the conditioned phenomena are the four mental aggregates of the five kinds of non-return fruition impulsion. The conditioning phenomena are the mental aggregates of the last wholesome impulsion of the base of neither perception nor non-perception, which ceased without any intervening consciousness. They support by proximity, contiguity, decisive support, absence and disappearance (5).

(j) When an arahant emerges from the attainment of cessation, the conditioned phenomena are the four mental aggregates of the five kinds of arahant fruition impulsion. The conditioning phenomena are the mental aggregates of the last functional impulsion of the base of neither perception nor non-perception, which ceased without any intervening consciousness. They support by proximity, contiguity, decisive support, absence and disappearance (5).

4. (a) The conditioned phenomena are the four mental aggregates of the 12 kinds of first lower fruition impulsion accompanied by joy (in the fruition-attainment process). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of unprompted or prompted knowledge-associated great wholesome consciousness accompanied by joy performing the function of conformity (anuloma). It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

(b) The conditioned phenomena are the four mental aggregates of the 12 kinds of lower fruition impulsion accompanied by joy, from the second impulsion onward (in the path process and the fruition-attainment process)…


<a id="M07-body-P118"></a>
## Physical-base conditions of lower fruition and arahant fruition
Miến / Burmese 118

… The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of the immediately preceding lower fruition impulsion of the same kind accompanied by joy, beginning with the first impulsion (12 kinds). It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

(c) The conditioned phenomena are the four mental aggregates of the 3 kinds of first lower fruition impulsion accompanied by equanimity (in the fruition-attainment process). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of unprompted or prompted knowledge-associated great wholesome consciousness accompanied by equanimity performing the function of conformity (anuloma). It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

(d) The conditioned phenomena are the four mental aggregates of the 3 kinds of lower fruition impulsion accompanied by equanimity, from the second impulsion onward (in the path process and the fruition-attainment process). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of the immediately preceding lower fruition impulsion of the same kind accompanied by equanimity, beginning with the first impulsion (3 kinds). It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

(e) The conditioned phenomena are the four mental aggregates of the 4 kinds of first arahant fruition impulsion accompanied by joy (in the arahant fruition-attainment process). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of unprompted or prompted knowledge-associated great functional consciousness accompanied by joy performing the function of conformity (anuloma). It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).


<a id="M07-body-P119"></a>
## Physical-base conditions of arahant fruition and of emergence from cessation
Miến / Burmese 119

(f) The conditioned phenomena are the four mental aggregates of the 4 kinds of arahant fruition impulsion accompanied by joy, from the second impulsion onward (in the arahant path process and the arahant fruition-attainment process). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of the immediately preceding arahant fruition impulsion of the same kind accompanied by joy, beginning with the first impulsion (4 kinds). It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

(g) The conditioned phenomena are the four mental aggregates of the first arahant fruition impulsion accompanied by equanimity (one kind) (in the arahant fruition-attainment process). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of unprompted or prompted knowledge-associated great functional consciousness accompanied by equanimity performing the function of conformity (anuloma). It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

(h) The conditioned phenomena are the four mental aggregates of the 1 kinds of arahant fruition impulsion accompanied by equanimity, from the second impulsion onward (in the arahant path process and the arahant fruition-attainment process). The conditioning phenomenon is the heart-base that arose at the arising submoment of the mental aggregates of the immediately preceding arahant fruition impulsion of the same kind accompanied by equanimity, beginning with the first impulsion (1 kinds). It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

(i) On emerging from the attainment of cessation, the four mental aggregates of the five kinds of non-return fruition impulsion and of the five kinds of arahant fruition impulsion are the conditioned phenomena…


<a id="M07-body-P120"></a>
## Asynchronous kamma and natural decisive support of fruition impulsion
Miến / Burmese 120

… The conditioning phenomenon is the respective heart-base which arose exactly one consciousness moment before that consciousness. It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. The conditioned phenomena are the four mental aggregates of the 20 kinds of fruition impulsion distinct from the 20 kinds immediately following the path. The conditioning phenomena are the 20 kinds of strong past wholesome noble-path kamma. They support by asynchronous kamma and natural decisive support (2).

6. (a) The conditioned phenomena are the four mental aggregates of the five kinds of stream-entry fruition impulsion. The conditioning phenomena are strong phenomena comprising the 81 mundane consciousnesses, the stream-entry path, the stream-entry fruition, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions. They support by natural decisive support (1).

(b) The conditioned phenomena are the four mental aggregates of the five kinds of once-return fruition impulsion. The conditioning phenomena are strong phenomena comprising the 81 mundane consciousnesses, the stream-entry path, the stream-entry fruition, the once-return path, the once-return fruition, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions. They support by natural decisive support (1).

(c) The conditioned phenomena are the four mental aggregates of the five kinds of non-return fruition impulsion. The conditioning phenomena are strong phenomena comprising the 81 mundane consciousnesses, the stream-entry path, the stream-entry fruition, the once-return path, the once-return fruition, the non-return path, the non-return fruition, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions. They support by natural decisive support (1).


<a id="M07-body-P121"></a>
## Natural decisive support of arahant fruition and the journey through saṃsāra
Miến / Burmese 121

(d) The conditioned phenomena are the four mental aggregates of the five kinds of arahantship fruition impulsion. The conditioning phenomena are strong phenomena comprising the 81 mundane consciousnesses, the stream-entry path, the stream-entry fruition, the once-return path, the once-return fruition, the non-return path, the non-return fruition, the arahantship path, the arahantship fruition, the 52 mental factors, the 28 material phenomena, and certain concepts capable of acting as conditions. They support by natural decisive support (1).

These phenomena arise and persist through the simultaneous support of these 30 conditions, each according to its appropriate power.

[Note — In the asynchronous kamma group, the wholesome kamma of the noble paths is presented collectively. In actual discernment, discern just how the corresponding noble fruition arises conditioned by its corresponding noble path.]

❀ ❀ ❀

Throughout the journey through saṃsāra

The Paṭṭhāna conditional relations have now been presented by dividing phenomena into five aggregates at the respective moments of the types of consciousness that may appropriately arise throughout a life, from rebirth-linking to death, for a three-rooted human practitioner. Let the good person who is learning take this as a model, divide phenomena into the five aggregates and discern in this way the mind-moments they are able to discern.

Throughout this present life, called the present by period (addhāpaccuppanna), from rebirth-linking to death, in each mind-moment of the types of consciousness that have arisen, are arising and will arise in the good learner’s continuum of mentality and materiality…


<a id="M07-body-P122"></a>
## Discerning across lives and the arising of rootless rebirth-linking
Miến / Burmese 122

… after discerning the Paṭṭhāna conditional relations by the five-aggregate method, one can shift to discerning past lives and future lives.

In discerning this way, one cannot exhaust every mind-moment and every set of five aggregates present in a single life. Bear in mind that one should cover the types as fully as one is able.

In wandering throughout saṃsāra, now sinking and now rising, at times unwholesome kamma gains an opportunity to bear fruit and one falls into a state of deprivation. At other times wholesome kamma gains an opportunity to bear fruit and one is born in a higher realm, such as the human, deva or Brahmā realm, with a fine appearance. In those lives too the Paṭṭhāna conditional relations can be discerned as in the present life. Use the method given above as a model to discern the five aggregates at the mind-moments within cognitive processes. The exposition now continues with consciousness outside the cognitive process.

❀ ❀ ❀

How rootless rebirth-linking arises

[Note — Use the method given above as a model to discern the material aggregate.]

1. Rootless unwholesome-resultant investigating consciousness accompanied by equanimity.
2. Rootless wholesome-resultant investigating consciousness accompanied by equanimity.
There are these two kinds of rootless rebirth-linking.

1. Rootless unwholesome-resultant investigating consciousness accompanied by equanimity is the rebirth-linking consciousness of beings in the states of deprivation.


<a id="M07-body-P123"></a>
## Cases of rebirth-linking through rootless wholesome result
Miến / Burmese 123

2. Rootless wholesome-resultant investigating consciousness accompanied by equanimity is the rebirth-linking consciousness in the following cases —

(a) Jaccandha — one blind from rebirth-linking, that is, blind from birth.

(b) Jaccabadhira — one deaf from rebirth-linking, that is, deaf from birth.

(c) Jaccaghānaka — one without nose-sensitivity from rebirth-linking.

(d) Jaccamūga — one mute from rebirth-linking, unable to speak.

(e) Jaccajaḷa — one of dull intellect from rebirth-linking, who does not know even the directions east, west, south and north.

(f) Jaccummattaka — one mentally deranged from rebirth-linking.

(g) Paṇḍaka — a person called a paṇḍaka.

(h) Ubhatobyañjanaka — one with both sexual characteristics, or with male characteristics at one time and female characteristics at another.

(i) Napuṃsaka — one in whom neither female nor male characteristics are manifest.

(j) A person who stammers — one whose speech is interrupted and who has to draw out sounds when speaking. Along with people with such impairments there are —

(k) Vinipātikāsura — the lesser, low-ranking devas who live in dependence on the great earth-dwelling devas, lack a good dwelling of their own and live in a fallen, unsettled state. This is the rebirth-linking consciousness of those devas.

This consciousness performs rebirth-linking at the beginning of life, the life-continuum in the middle and death at the end. Rebirth-linking is presented first here.


<a id="M07-body-P124"></a>
## Condition groups and mental conascence at rootless rebirth-linking
Miến / Burmese 124

The conditioned phenomena are the four mental aggregates of the two kinds of rootless rebirth-linking —

1. Mental conascence group — 11.

2. Material conascence group — 6.

3. Object group — 1.

4. Proximity group — 5.

5. Asynchronous kamma group — 2.

These phenomena arise and persist through the simultaneous support of these 25 conditions, each according to its appropriate power.

The conditioned phenomena are the four mental aggregates constituted by the two kinds of rootless rebirth-linking consciousness and the ten ethically variable mental factors excluding zeal, joy and energy.

1. (a) The two kinds of rootless rebirth-linking consciousness and the ten ethically variable mental factors excluding zeal, joy and energy support one another. These constituent mental aggregates are conditioning phenomena by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

In the mental aggregates of the two kinds of rootless rebirth-linking, the following support the associated aggregates —

(b) Volition is the conditioning phenomenon by conascent kamma.

(c) Contact, volition and consciousness are the conditioning phenomena by nutriment.

(d) Life, consciousness and feeling, the three mental faculties, are the conditioning phenomena by faculty.

(e) The four jhāna factors excluding joy are the conditioning phenomena by jhāna condition (4). Total: 7 + 4 = 11.

2. The heart-base that arises together with the corresponding mental aggregates of rootless rebirth-linking…


<a id="M07-body-P125"></a>
## Material conascence, object, proximity and asynchronous kamma at rootless rebirth-linking
Miến / Burmese 125

… is the conditioning phenomenon by conascence, mutuality, dependence, dissociation, presence and non-disappearance (6).

3. An object of one of the three kinds, kamma, the sign of kamma or the sign of destination, is the conditioning phenomenon by object condition (1).

4. The mental aggregates of one of the ten sense-sphere death consciousnesses of the immediately past life are the conditioning phenomena by proximity, contiguity, decisive support, absence and disappearance (5).

5. (a) The conditioned phenomena are the four mental aggregates constituted by rootless rebirth-linking consciousness in an unhappy destination (one type) and ten ethically variable mental factors excluding zeal, joy and energy. The conditioning phenomenon is one of the eleven kinds of past unwholesome kamma, excluding volition associated with restlessness. It supports by asynchronous kamma and natural decisive support (2).

(b) The conditioned phenomena are the four mental aggregates constituted by rootless rebirth-linking consciousness in a happy destination (one type) and ten ethically variable mental factors excluding zeal, joy and energy. The conditioning phenomenon is one of the four kinds of inferior two-rooted past sense-sphere wholesome kamma. It supports by asynchronous kamma and natural decisive support (2).

These phenomena arise and persist through the simultaneous support of these 25 conditions, each according to its appropriate power.

[Note — Use the method given above as a model to discern the material aggregate. The mental aggregates of rootless life-continuum are presented next.]

❀ ❀ ❀


<a id="M07-body-P126"></a>
## How rootless life-continuum arises
Miến / Burmese 126

The conditioned phenomena are the four mental aggregates constituted by the 2 kinds of rootless life-continuum consciousness and the 10 ethically variable mental factors excluding zeal, joy and energy —

1. Mental conascence group — 11.

2. Object group — 1.

3. Proximity group — 5.

4. Physical-base group — 5.

5. Asynchronous kamma group — 2.

These phenomena arise and persist through the simultaneous support of these 24 conditions, each according to its appropriate power.

The conditioned phenomena are the four mental aggregates constituted by the 2 kinds of rootless life-continuum consciousness and the 10 ethically variable mental factors excluding zeal, joy and energy —

1. (a) The 2 kinds of rootless life-continuum consciousness and the 10 ethically variable mental factors excluding zeal, joy and energy support one another. These constituent mental aggregates are conditioning phenomena by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

In the mental aggregates of rootless life-continuum, the following support the associated aggregates —

(b) Volition is the conditioning phenomenon by conascent kamma.

(c) Contact, volition and consciousness are the conditioning phenomena by nutriment.

(d) Life, consciousness and feeling, the three mental faculties, are the conditioning phenomena by faculty.


<a id="M07-body-P127"></a>
## Object, proximity and physical-base conditions of rootless life-continuum
Miến / Burmese 127

(e) The four jhāna factors excluding joy are the conditioning phenomena by jhāna condition (4). Total: 7 + 4 = 11.

2. An object of one of the three kinds, kamma, the sign of kamma or the sign of destination, is the conditioning phenomenon by object condition (1).

3. (a) The mental aggregates of rootless rebirth-linking consciousness, which have just ceased with no interval.

(b) The mental aggregates of the preceding rootless life-continuum consciousness, which have just ceased with no interval.

(c) The mental aggregates of determining consciousness (voṭṭhapana), which have just ceased with no interval.

(d) The mental aggregates of the last impulsion, which have just ceased with no interval.

(e) The mental aggregates of registration consciousness, which have just ceased with no interval are the conditioning phenomena by proximity, contiguity, decisive support, absence and disappearance (5).

4. (a) The heart-base that arose together with rootless rebirth-linking consciousness.

(b) The heart-base that arose together with the preceding rootless life-continuum consciousness.

(c) The heart-base that arose together with determining consciousness (voṭṭhapana).

(d) The heart-base that arose together with the last impulsion.


<a id="M07-body-P128"></a>
## Physical-base and asynchronous kamma conditions of rootless life-continuum
Miến / Burmese 128

(e) The heart-base that arose together with the second registration.

(f) The heart-base that arose together with the seventeenth consciousness counting back from death consciousness, at the approach of death is the conditioning phenomenon by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. (a) The conditioned phenomena are the four mental aggregates constituted by one kind of rootless life-continuum consciousness in an unhappy destination and 10 ethically variable mental factors excluding zeal, joy and energy. The conditioning phenomenon is one of the eleven kinds of past unwholesome kamma, excluding volition associated with restlessness. It supports by asynchronous kamma and natural decisive support (2).

(b) The conditioned phenomena are the four mental aggregates constituted by one kind of rootless life-continuum consciousness in a happy destination and 10 ethically variable mental factors excluding zeal, joy and energy. The conditioning phenomenon is one of the four kinds of inferior two-rooted past sense-sphere wholesome kamma. It supports by asynchronous kamma and natural decisive support (2).

These phenomena arise and persist through the simultaneous support of these 24 conditions, each according to its appropriate power.

❀ ❀ ❀


<a id="M07-body-P129"></a>
## How rootless death arises
Miến / Burmese 129

The conditioned phenomena are the four mental aggregates constituted by the 2 kinds of rootless death consciousness and the 10 ethically variable mental factors excluding zeal, joy and energy —

1. Conascence group — 11.

2. Object group — 1.

3. Proximity group — 5.

4. Physical-base group — 5.

5. Asynchronous kamma group — 2.

These phenomena arise and persist through the simultaneous support of these 24 conditions, each according to its appropriate power.

The conditioned phenomena are the four mental aggregates constituted by the 2 kinds of rootless death consciousness and the 10 ethically variable mental factors excluding zeal, joy and energy —

1. (a) The 2 kinds of rootless death consciousness and the 10 ethically variable mental factors excluding zeal, joy and energy support one another. These constituent mental aggregates are conditioning phenomena by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

In the mental aggregates of rootless death, the following support the associated aggregates —

(b) Volition is the conditioning phenomenon by conascent kamma.

(c) Contact, volition and consciousness are the conditioning phenomena by nutriment.

(d) Life, consciousness and feeling, the three mental faculties, are the conditioning phenomena by faculty.


<a id="M07-body-P130"></a>
## Object, proximity, physical-base and kamma conditions of rootless death
Miến / Burmese 130

(e) The four jhāna factors excluding joy are the conditioning phenomena by jhāna condition (4). Total: 7 + 4 = 11.

2. An object of one of the three kinds, kamma, the sign of kamma or the sign of destination, is the conditioning phenomenon by object condition (1).

3. (a) The mental aggregates of the fifth impulsion in the near-death process, which have just ceased with no interval.

(b) The mental aggregates of the second registration, which have just ceased with no interval.

(c) The mental aggregates of life-continuum consciousness, which have just ceased with no interval are the conditioning phenomena by proximity, contiguity, decisive support, absence and disappearance (5).

4. The conditioning phenomenon is the heart-base that arose together with the seventeenth consciousness counting back from the death consciousness under consideration. It supports by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. (a) The conditioned phenomena are the four mental aggregates constituted by one kind of rootless death consciousness in an unhappy destination and 10 ethically variable mental factors excluding zeal, joy and energy. The conditioning phenomenon is one of the eleven kinds of past unwholesome kamma, excluding volition associated with restlessness. It supports by asynchronous kamma and natural decisive support (2).

(b) The conditioned phenomena are the four mental aggregates constituted by one kind of rootless death consciousness in a happy destination and 10 ethically variable mental factors excluding zeal, joy and energy. The conditioning phenomenon is inferior two-rooted past kamma…


<a id="M07-body-P131"></a>
## How two-rooted sense-sphere rebirth-linking arises
Miến / Burmese 131

… one of the four kinds of such sense-sphere wholesome kamma. It is the conditioning phenomenon by asynchronous kamma and natural decisive support (2).

These phenomena arise and persist through the simultaneous support of these 24 conditions, each according to its appropriate power.

❀ ❀ ❀

If the good person who is learning was at some time a two-rooted being while wandering through past saṃsāra, discern the Paṭṭhāna conditional relations of those two-rooted mental aggregates of rebirth-linking, life-continuum and death as set out below.

How two-rooted sense-sphere rebirth-linking arises

The conditioned phenomena are the four mental aggregates constituted by the 4 kinds of two-rooted sense-sphere rebirth-linking consciousness and the 32 mental factors excluding the abstinences, immeasurables and wisdom —

1. Mental conascence group — 13.

2. Material conascence group — 6.

3. Object group — 1.

4. Proximity group — 5.

5. Asynchronous kamma group — 2.

These phenomena arise and persist through the simultaneous support of these 27 conditions, each according to its appropriate power.

The conditioned phenomena are the four mental aggregates constituted by the 4 kinds of two-rooted sense-sphere rebirth-linking consciousness and the 32 mental factors excluding the abstinences, immeasurables and wisdom —


<a id="M07-body-P132"></a>
## Mental conascence, material conascence and object at two-rooted rebirth-linking
Miến / Burmese 132

1. (a) The 4 kinds of two-rooted sense-sphere rebirth-linking consciousness and the 32 mental factors excluding the abstinences, immeasurables and wisdom support one another. These constituent mental aggregates are conditioning phenomena by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

In the mental aggregates of two-rooted sense-sphere rebirth-linking, the following support the associated aggregates —

(b) Non-greed and non-hatred, the 2 roots, are the conditioning phenomena by root condition.

(c) Volition is the conditioning phenomenon by conascent kamma.

(d) Contact, volition and consciousness are the conditioning phenomena by nutriment.

(e) The seven mental faculties, excluding wisdom, are the conditioning phenomena by faculty condition.

(f) When two-rooted sense-sphere rebirth-linking accompanied by joy occurs, the five jhāna factors are applied thought, sustained thought, joy, happiness and one-pointedness. When two-rooted sense-sphere rebirth-linking accompanied by equanimity occurs, the four factors are applied thought, sustained thought, equanimity and one-pointedness. These factors are the conditioning phenomena by jhāna condition.

(g) The four path factors, excluding the abstinences and wisdom, are the conditioning phenomena by path condition (6). Total: 7 + 6 = 13.

2. The heart-base that arises together with the mental aggregates of the corresponding two-rooted rebirth-linking consciousness among the four kinds is the conditioning phenomenon by conascence, mutuality, dependence, dissociation, presence and non-disappearance (6).

3. An object of one of the three kinds, kamma, the sign of kamma or the sign of destination, is the conditioning phenomenon by object condition (1).


<a id="M07-body-P133"></a>
## Two-rooted rebirth-linking and life-continuum
Miến / Burmese 133

4. The mental aggregates of an appropriate one of the five fine-material death consciousnesses or ten sense-sphere death consciousnesses that have ceased are the conditioning phenomena by proximity, contiguity, decisive support, absence and disappearance (5).

5. One of the eight kinds of past sense-sphere wholesome kamma, either inferior three-rooted or superior two-rooted, is the conditioning phenomenon by asynchronous kamma and natural decisive support (2).

These phenomena arise and persist through the simultaneous support of these 27 conditions, each according to its appropriate power.

❀ ❀ ❀

How the mental aggregates of two-rooted life-continuum arise

The conditioned phenomena are the four mental aggregates constituted by the 4 kinds of two-rooted sense-sphere life-continuum consciousness and the 32 mental factors excluding the abstinences, immeasurables and wisdom —

1. Mental conascence group — 13.

2. Object group — 1.

3. Proximity group — 5.

4. Physical-base group — 5.

5. Asynchronous kamma group — 2.

These phenomena arise and persist through the simultaneous support of these 26 conditions, each according to its appropriate power.

The conditioned phenomena are the four mental aggregates constituted by the 4 kinds of two-rooted sense-sphere life-continuum consciousness and the 32 mental factors excluding the abstinences, immeasurables and wisdom —


<a id="M07-body-P134"></a>
## Mental conascence, object and proximity of two-rooted life-continuum
Miến / Burmese 134

1. (a) The 4 kinds of two-rooted sense-sphere life-continuum consciousness and the 32 mental factors excluding the abstinences, immeasurables and wisdom support one another. These constituent mental aggregates are conditioning phenomena by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

In the mental aggregates of two-rooted sense-sphere life-continuum, the following support the associated aggregates —

(b) Non-greed and non-hatred, the 2 roots, are the conditioning phenomena by root condition.

(c) Volition is the conditioning phenomenon by conascent kamma.

(d) Contact, volition and consciousness are the conditioning phenomena by nutriment.

(e) The seven mental faculties, excluding wisdom, are the conditioning phenomena by faculty condition.

(f) When two-rooted sense-sphere life-continuum accompanied by joy occurs, the five jhāna factors are applied thought, sustained thought, joy, happiness and one-pointedness. When two-rooted sense-sphere life-continuum accompanied by equanimity occurs, the four factors are applied thought, sustained thought, equanimity and one-pointedness. These factors are the conditioning phenomena by jhāna condition.

(g) Applied thought, energy, mindfulness and one-pointedness, the four path factors, are the conditioning phenomena by path condition (6). Total: 7 + 6 = 13.

2. The conditioned phenomena are the four mental aggregates constituted by the 4 kinds of two-rooted sense-sphere life-continuum consciousness and the 32 mental factors excluding the abstinences, immeasurables and wisdom. An object of one of the three kinds, kamma, the sign of kamma or the sign of destination, is the conditioning phenomenon by object condition (1).

3. (a) The mental aggregates of two-rooted rebirth-linking consciousness, which have just ceased with no interval.


<a id="M07-body-P135"></a>
## Proximity and physical-base conditions of two-rooted life-continuum
Miến / Burmese 135

(b) The mental aggregates of the preceding two-rooted life-continuum consciousness, which have just ceased with no interval.

(c) The mental aggregates of determining consciousness (voṭṭhapana), which have just ceased with no interval.

(d) The mental aggregates of the last impulsion, which have just ceased with no interval.

(e) The mental aggregates of the second registration, which have just ceased with no interval are the conditioning phenomena by proximity, contiguity, decisive support, absence and disappearance (5).

4. (a) The heart-base that arose together with two-rooted rebirth-linking consciousness.

(b) The heart-base that arose together with the preceding two-rooted life-continuum consciousness.

(c) The heart-base that arose together with determining consciousness (voṭṭhapana).

(d) The heart-base that arose together with the last impulsion.

(e) The heart-base that arose together with the second registration.

(f) The heart-base that arose together with the seventeenth consciousness counting back from death consciousness, at the approach of death is the conditioning phenomenon by dependence, prenascence, dissociation, presence and non-disappearance (5).


<a id="M07-body-P136"></a>
## Kamma supporting life-continuum and the arising of two-rooted death
Miến / Burmese 136

5. Past sense-sphere wholesome kamma, either inferior three-rooted or superior two-rooted, is the conditioning phenomenon by asynchronous kamma and natural decisive support (2).

These phenomena arise and persist through the simultaneous support of these 26 conditions, each according to its appropriate power.

How the mental aggregates of two-rooted death arise

The conditioned phenomena are the four mental aggregates constituted by the 4 kinds of two-rooted sense-sphere death consciousness and the 32 mental factors excluding the abstinences, immeasurables and wisdom —

1. Conascence group — 13.

2. Object group — 1.

3. Proximity group — 5.

4. Physical-base group — 5.

5. Asynchronous kamma group — 2.

These phenomena arise and persist through the simultaneous support of these 26 conditions, each according to its appropriate power.

The conditioned phenomena are the four mental aggregates constituted by the 4 kinds of two-rooted sense-sphere death consciousness and the 32 mental factors excluding the abstinences, immeasurables and wisdom —

1. (a) The 4 kinds of two-rooted sense-sphere death consciousness and the 32 mental factors excluding the abstinences, immeasurables and wisdom support one another. These constituent mental aggregates are conditioning phenomena by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

In the mental aggregates of two-rooted sense-sphere death, the following support the associated aggregates —


<a id="M07-body-P137"></a>
## Conditions supporting two-rooted death
Miến / Burmese 137

(b) Non-greed and non-hatred, the 2 roots, are the conditioning phenomena by root condition.

(c) Volition is the conditioning phenomenon by conascent kamma.

(d) Contact, volition and consciousness are the conditioning phenomena by nutriment.

(e) The seven mental faculties, excluding wisdom, are the conditioning phenomena by faculty condition.

(f) When two-rooted sense-sphere death accompanied by joy occurs, there are five jhāna factors. When two-rooted sense-sphere death accompanied by equanimity occurs, there are four jhāna factors excluding joy. These factors are the conditioning phenomena by jhāna condition.

(g) The four path factors, excluding the abstinences and wisdom, are the conditioning phenomena by path condition (6). Total: 7 + 6 = 13.

2. The conditioned phenomena are the four mental aggregates constituted by the 4 kinds of two-rooted sense-sphere death consciousness and the 32 mental factors excluding the abstinences, immeasurables and wisdom. An object of one of the three kinds, kamma, the sign of kamma or the sign of destination, is the conditioning phenomenon by object condition (1).

3. (a) The mental aggregates of the fifth impulsion in the near-death process, which have just ceased with no interval.

(b) The mental aggregates of the second registration, which have just ceased with no interval.

(c) The mental aggregates of the immediately preceding life-continuum consciousness, which have just ceased with no interval are the conditioning phenomena by proximity, contiguity, decisive support, absence and disappearance (5).

4. The conditioning phenomenon is the heart-base that arose together with the seventeenth consciousness counting back from the death consciousness under consideration…


<a id="M07-body-P138"></a>
## Two-rooted death and conditions supporting fine-material rebirth-linking
Miến / Burmese 138

… It is the conditioning phenomenon by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. Past sense-sphere wholesome kamma, either inferior three-rooted or superior two-rooted, is the conditioning phenomenon by asynchronous kamma and natural decisive support (2).

These phenomena arise and persist through the simultaneous support of these 26 conditions, each according to its appropriate power.

❀ ❀ ❀

If the good person who is learning once wandered through some fine-material realms in past saṃsāra, discern the Paṭṭhāna conditional relations of the fine-material mental aggregates of rebirth-linking, life-continuum and death as set out below. Fine-material rebirth-linking, life-continuum and death are presented together here. In actual discernment, discern each corresponding instance of rebirth-linking, life-continuum and death separately.

How the mental aggregates of fine-material rebirth-linking arise

The conditioned phenomena are the four mental aggregates constituted by the 5 kinds of fine-material rebirth-linking consciousness and the 35 mental factors excluding the abstinences [or 34/33/32/31] —

1. Mental conascence group — 13.

2. Material conascence group — 6.

3. Object group — 1.

4. Proximity group — 5.

5. Asynchronous kamma group — 2.

These phenomena arise and persist through the simultaneous support of these 27 conditions, each according to its appropriate power.


<a id="M07-body-P139"></a>
## Mental conascence and jhāna factors at fine-material rebirth-linking
Miến / Burmese 139

The conditioned phenomena are the four mental aggregates constituted by the 5 kinds of fine-material rebirth-linking consciousness and the 35 mental factors excluding the abstinences —

1. (a) The 5 kinds of fine-material rebirth-linking consciousness and the 35 mental factors excluding the abstinences [or 34/33/32/31] support one another. These constituent mental aggregates are conditioning phenomena by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

In the mental aggregates of fine-material rebirth-linking, the following support the associated aggregates —

(b) Non-greed, non-hatred and non-delusion, the 3 roots, are the conditioning phenomena by root condition.

(c) Volition is the conditioning phenomenon by conascent kamma.

(d) Contact, volition and consciousness are the conditioning phenomena by nutriment.

(e) The eight mental faculties are the conditioning phenomena by faculty condition.

(f) The following support by jhāna condition:
• First-jhāna rebirth-linking — applied thought, sustained thought, joy, happiness and one-pointedness (5).
• Second-jhāna rebirth-linking — sustained thought, joy, happiness and one-pointedness (4).
• Third-jhāna rebirth-linking — joy, happiness and one-pointedness (3).
• Fourth-jhāna rebirth-linking — happiness and one-pointedness (2).
• Fifth-jhāna rebirth-linking — equanimity and one-pointedness (2).

(g) When first-jhāna rebirth-linking occurs, the five path factors are right view, right intention, right effort, right mindfulness and right concentration. When second-, third-, fourth- or fifth-jhāna rebirth-linking occurs…


<a id="M07-body-P140"></a>
## Path factors, material conascence and objects of fine-material rebirth-linking
Miến / Burmese 140

… the four path factors of right view, right effort, right mindfulness and right concentration are the conditioning phenomena by path condition (6). Total: 7 + 6 = 13.

2. The heart-base that arises together with the mental aggregates of the corresponding fine-material rebirth-linking consciousness among the five kinds is the conditioning phenomenon by conascence, mutuality, dependence, dissociation, presence and non-disappearance (6).

3. When first-jhāna rebirth-linking occurs —

(a) Ten kasiṇa concepts.

(b) Ten foulness concepts.

(c) The concept of the bodily parts, beginning with head hair, as the object of mindfulness of the body.

(d) In- and out-breathing as object of mindfulness of breathing, namely the concept of its counterpart sign.

(e) The concept of all happy and suffering beings as the object of loving-kindness.

(f) The concept of all suffering beings as the object of compassion.

(g) The concept of all happy beings as the object of appreciative joy.

One of these 25 conceptual kamma signs is the conceptual kamma sign taken as object.

When second-, third- or fourth-jhāna rebirth-linking occurs —

(a) Ten kasiṇa concepts.

(b) In- and out-breathing as object of mindfulness of breathing, namely the concept of its counterpart sign.


<a id="M07-body-P141"></a>
## Objects and conditions supporting fine-material rebirth-linking
Miến / Burmese 141

(c) The concept of all happy and suffering beings as the object of loving-kindness.

(d) The concept of all suffering beings as the object of compassion.

(e) The concept of all happy beings as the object of appreciative joy.

One of these 14 conceptual kamma signs is the conceptual kamma sign taken as object.

When fifth-jhāna rebirth-linking occurs —

(a) Ten kasiṇa concepts.

(b) The concept of in- and out-breathing as the object of mindfulness of breathing, namely the concept of its counterpart sign.

(c) The concept of all happy and suffering beings as the object of equanimity, that is, the divine abiding of equanimity.

One of these 12 conceptual kamma signs is the conceptual kamma sign taken as object.

The appropriate conceptual kamma sign among those conceptual kamma signs is the conditioning phenomenon by object condition (1).

4. The mental aggregates of an appropriate one of the nine three-rooted death consciousnesses of the previous life, which has just ceased, are the conditioning phenomena by proximity, contiguity, decisive support, absence and disappearance (5).

5. An appropriate one of the five kinds of past fine-material wholesome kamma is the conditioning phenomenon by asynchronous kamma and natural decisive support (2).

These phenomena arise and persist through the simultaneous support of these 27 conditions, each according to its appropriate power.


<a id="M07-body-P142"></a>
## How fine-material life-continuum arises
Miến / Burmese 142

The conditioned phenomena are the four mental aggregates of the five kinds of fine-material life-continuum consciousness —

1. Mental conascence group — 13.

2. Object group — 1.

3. Proximity group — 5.

4. Physical-base group — 5.

5. Asynchronous kamma group — 2.

These phenomena arise and persist through the simultaneous support of these 26 conditions, each according to its appropriate power.

The conditioned phenomena are the four mental aggregates constituted by the five kinds of fine-material life-continuum consciousness and the 35 mental factors excluding the abstinences —

1. (a) The five kinds of fine-material life-continuum consciousness and the 35 mental factors support one another. These constituent mental aggregates are conditioning phenomena by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

In the mental aggregates of fine-material life-continuum, the following support the associated aggregates —

(b) Non-greed, non-hatred and non-delusion, the three roots, are the conditioning phenomena by root condition.

(c) Volition is the conditioning phenomenon by conascent kamma.

(d) Contact, volition and consciousness are the conditioning phenomena by nutriment.

(e) The eight mental faculties are the conditioning phenomena by faculty condition.


<a id="M07-body-P143"></a>
## Jhāna factors, path factors and objects of fine-material life-continuum
Miến / Burmese 143

(f) When first-jhāna life-continuum occurs, five jhāna factors are the conditioning phenomena; when second-jhāna life-continuum occurs, four jhāna factors; when third-jhāna life-continuum occurs, three jhāna factors; when fourth-jhāna life-continuum occurs, happiness and one-pointedness, two jhāna factors; when fifth-jhāna life-continuum occurs, equanimity and one-pointedness, two jhāna factors. These jhāna factors support by jhāna condition.

(g) When first-jhāna life-continuum occurs, the five path factors of wisdom, applied thought, energy, mindfulness and one-pointedness are the conditioning phenomena by path condition. When second-, third-, fourth- or fifth-jhāna life-continuum occurs, the four path factors of wisdom, energy, mindfulness and one-pointedness are the conditioning phenomena by path condition (6). Total: 7 + 6 = 13.

2. When first-jhāna life-continuum occurs —

(a) Ten kasiṇa concepts.

(b) Ten foulness concepts.

(c) The concept of the bodily parts as the object of mindfulness of the body.

(d) The concept of in- and out-breathing as the object of mindfulness of breathing, namely the concept of its counterpart sign.

(e) The concept of all happy and suffering beings as the object of loving-kindness.

(f) The concept of all suffering beings as the object of compassion.

(g) The concept of all happy beings as the object of appreciative joy.

One of these 25 conceptual kamma signs is the conceptual kamma sign taken as object.


<a id="M07-body-P144"></a>
## Objects and proximity conditions of fine-material life-continuum
Miến / Burmese 144

When second-, third- or fourth-jhāna life-continuum occurs —

(a) Ten kasiṇa concepts.

(b) The concept of in- and out-breathing as the object of mindfulness of breathing, namely the concept of its counterpart sign.

(c) The concept of all happy and suffering beings as the object of loving-kindness.

(d) The concept of all suffering beings as the object of compassion.

(e) The concept of all happy beings as the object of appreciative joy.

One of these 14 conceptual kamma signs is the conceptual kamma sign taken as object.

When fifth-jhāna life-continuum occurs —

(a) Ten kasiṇa concepts.

(b) The concept of in- and out-breathing as the object of mindfulness of breathing, namely the concept of its counterpart sign.

(c) The concept of all happy and suffering beings as the object of equanimity, that is, the divine abiding of equanimity.

One of these 12 conceptual kamma signs is the conceptual kamma sign taken as object.

The appropriate conceptual kamma sign among those conceptual kamma signs is the conditioning phenomenon by object condition (1).

3. (a) The mental aggregates of fine-material rebirth-linking which have just ceased with no interval.

(b) The mental aggregates of fine-material life-continuum which have just ceased with no interval…


<a id="M07-body-P145"></a>
## Proximity, physical-base and kamma conditions of fine-material life-continuum
Miến / Burmese 145

… those mental aggregates.

(c) The mental aggregates of determining consciousness which have just ceased with no interval.

(d) The mental aggregates of the last impulsion which have just ceased with no interval. Those appropriate mental aggregates are the conditioning phenomena by proximity, contiguity, decisive support, absence and disappearance (5).

4. (a) The heart-base that arose together with the mental aggregates of fine-material rebirth-linking that ceased immediately before the life-continuum.

(b) The heart-base that arose together with the preceding fine-material life-continuum consciousness that ceased immediately before the life-continuum.

(c) The heart-base that arose together with the determining mental aggregates that ceased immediately before the life-continuum.

(d) The heart-base that arose together with the mental aggregates of the last impulsion that ceased immediately before the life-continuum.

(e) The heart-base that arose together with the seventeenth consciousness counting back from death consciousness at the approach of death.

That appropriate heart-base is the conditioning phenomenon by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. An appropriate one of the five kinds of past fine-material wholesome kamma is the conditioning phenomenon by asynchronous kamma and natural decisive support (2).

These phenomena arise and persist through the simultaneous support of these 26 conditions, each according to its appropriate power.


<a id="M07-body-P146"></a>
## How fine-material death arises
Miến / Burmese 146

The conditioned phenomena are the four mental aggregates constituted by the five kinds of fine-material death consciousness and the 35 mental factors excluding the abstinences —

1. Mental conascence group — 13.

2. Object group — 1.

3. Proximity group — 5.

4. Physical-base group — 5.

5. Asynchronous kamma group — 2.

These phenomena arise and persist through the simultaneous support of these 26 conditions, each according to its appropriate power.

The conditioned phenomena are the four mental aggregates constituted by the five kinds of fine-material death consciousness and the 35 mental factors excluding the abstinences —

1. (a) The five kinds of fine-material death consciousness and the 35 mental factors support one another. These constituent mental aggregates are conditioning phenomena by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

In the mental aggregates of fine-material death, the following support the associated aggregates —

(b) Non-greed, non-hatred and non-delusion, the three roots, are the conditioning phenomena by root condition.

(c) Volition is the conditioning phenomenon by conascent kamma.

(d) Contact, volition and consciousness are the conditioning phenomena by nutriment.

(e) The eight mental faculties are the conditioning phenomena by faculty condition.


<a id="M07-body-P147"></a>
## Jhāna factors, path factors, objects and proximity of fine-material death
Miến / Burmese 147

(f) When first-jhāna death occurs, five jhāna factors are the conditioning phenomena; when second-jhāna death occurs, four jhāna factors; when third-jhāna death occurs, three jhāna factors; when fourth-jhāna death occurs, happiness and one-pointedness, two jhāna factors; when fifth-jhāna death occurs, equanimity and one-pointedness, two jhāna factors. These jhāna factors support by jhāna condition.

(g) When first-jhāna death occurs, the five path factors excluding the abstinences are the conditioning phenomena by path condition. When second-, third-, fourth- or fifth-jhāna death occurs, the four path factors excluding the abstinences and applied thought are the conditioning phenomena by path condition (6). Total: 7 + 6 = 13.

2. (a) When first-jhāna death occurs — ten kasiṇa concepts. pe. One of these 25 conceptual kamma signs is the conceptual kamma sign taken as object.

(b) When second-, third- or fourth-jhāna death occurs — ten kasiṇa concepts. pe. One of these 14 conceptual kamma signs is the conceptual kamma sign taken as object.

(c) When fifth-jhāna death occurs — ten kasiṇa concepts. pe. One of these twelve conceptual kamma signs is the conceptual kamma sign taken as object.

The appropriate conceptual kamma sign among those conceptual kamma signs is the conditioning phenomenon by object condition (1).

3. (a) The mental aggregates of the fifth impulsion in the near-death process, which have just ceased with no interval.

(b) The preceding fine-material life-continuum mental aggregates, which have just ceased with no interval…


<a id="M07-body-P148"></a>
## Conditions supporting fine-material death and immaterial rebirth-linking
Miến / Burmese 148

… Those appropriate mental aggregates are the conditioning phenomena by proximity, contiguity, decisive support, absence and disappearance (5).

4. The heart-base that arose with the seventeenth consciousness counting back from the fine-material death consciousness under consideration is the conditioning phenomenon by dependence, prenascence, dissociation, presence and non-disappearance (5).

5. The five kinds of past fine-material wholesome kamma are the conditioning phenomena by asynchronous kamma and natural decisive support (2).

These phenomena arise and persist through the simultaneous support of these 26 conditions, each according to its appropriate power.

❀ ❀ ❀

How immaterial rebirth-linking arises

The conditioned phenomena are the four mental aggregates constituted by the four kinds of immaterial rebirth-linking consciousness and the 30 mental factors excluding the abstinences, immeasurables, applied thought, sustained thought and joy —

1. Mental conascence group — 13.

2. Object group — 1.

3. Proximity group — 5.

4. Asynchronous kamma group — 2.

These phenomena arise and persist through the simultaneous support of these 21 conditions, each according to its appropriate power.

The conditioned phenomena are the four mental aggregates constituted by the four kinds of immaterial rebirth-linking consciousness and the 30 mental factors excluding the abstinences, immeasurables, applied thought, sustained thought and joy…


<a id="M07-body-P149"></a>
## Mental conascence and objects of immaterial rebirth-linking
Miến / Burmese 149

… together with the 30 mental factors, are the constituent mental aggregates conditioned as follows —

1. (a) The four kinds of immaterial rebirth-linking consciousness and the 30 mental factors excluding the abstinences, immeasurables, applied thought, sustained thought and joy support one another. These constituent mental aggregates are conditioning phenomena by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

In the mental aggregates of the four kinds of immaterial rebirth-linking, the following support the associated aggregates —

(b) Non-greed, non-hatred and non-delusion, the three roots, are the conditioning phenomena by root condition.

(c) Volition is the conditioning phenomenon by conascent kamma.

(d) Contact, volition and consciousness, the three mental nutriments, are the conditioning phenomena by nutriment.

(e) The eight mental faculties are the conditioning phenomena by faculty condition.

(f) Equanimity and one-pointedness, the two jhāna factors, are the conditioning phenomena by jhāna condition.

(g) Wisdom, energy, mindfulness and one-pointedness, the four path factors, are the conditioning phenomena by path condition (6). Total: 7 + 6 = 13.

2. (a) When rebirth-linking of the base of infinite space occurs — The concept of space, the concept of the empty space obtained by removing any one of the nine kasiṇas excluding the space kasiṇa, is the kamma sign serving as the conditioning phenomenon.

(b) When rebirth-linking of the base of infinite consciousness occurs — The sign of past wholesome kamma of the base of infinite space, namely the sign of that exalted wholesome kamma, is the conditioning phenomenon.

(c) When rebirth-linking of the base of nothingness occurs — The concept of absence (natthibhāvapaññatti), namely the absence of the jhāna consciousness of the base of infinite space, is the kamma sign serving as the conditioning phenomenon.


<a id="M07-body-P150"></a>
## Object, proximity and kamma conditions of immaterial rebirth-linking
Miến / Burmese 150

(d) When rebirth-linking of the base of neither perception nor non-perception occurs — The sign of past wholesome kamma of the base of nothingness, namely the sign of that exalted wholesome kamma, is the conditioning phenomenon.

Those appropriate conditioning phenomena support by object condition (1).

3. (a) When rebirth-linking of the base of infinite space occurs, the ceased mental aggregates of sense-sphere death or death of the base of infinite space, among the nine kinds of death consciousness of the preceding life are the conditioning phenomena.

(b) When rebirth-linking of the base of infinite consciousness occurs, the ceased mental aggregates of sense-sphere death, death of the base of infinite space or death of the base of infinite consciousness, among the ten kinds of death consciousness of the preceding life are the conditioning phenomena.

(c) When rebirth-linking of the base of nothingness occurs, the ceased mental aggregates of sense-sphere death, death of the base of infinite space, death of the base of infinite consciousness or death of the base of nothingness, among the eleven kinds of death consciousness of the preceding life are the conditioning phenomena.

(d) When rebirth-linking of the base of neither perception nor non-perception occurs, the ceased mental aggregates of one of the thirteen kinds of death consciousness of the preceding life are the conditioning phenomena.

In each case, the respective death mental aggregates support by proximity, contiguity, decisive support, absence and disappearance (5).

4. An appropriate wholesome kamma among the four kinds of past immaterial wholesome kamma is the conditioning phenomenon by asynchronous kamma and natural decisive support (2).

These phenomena arise and persist through the simultaneous support of these 21 conditions, each according to its appropriate power.


<a id="M07-body-P151"></a>
## How immaterial life-continuum arises
Miến / Burmese 151

The conditioned phenomena are the four mental aggregates constituted by the four kinds of immaterial life-continuum consciousness and the 30 mental factors excluding the abstinences, immeasurables, applied thought, sustained thought and joy —

1. Mental conascence group — 13.

2. Object group — 1.

3. Proximity group — 5.

4. Asynchronous kamma group — 2.

These phenomena arise and persist through the simultaneous support of these 21 conditions, each according to its appropriate power.

The conditioned phenomena are the four mental aggregates constituted by the four kinds of immaterial life-continuum consciousness and the 30 mental factors excluding the abstinences, immeasurables, applied thought, sustained thought and joy —

1. (a) The four kinds of immaterial life-continuum consciousness and the 30 mental factors excluding the abstinences, immeasurables, applied thought, sustained thought and joy support one another. These constituent mental aggregates are conditioning phenomena by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

In the mental aggregates of immaterial life-continuum, the following support the associated aggregates —

(b) Non-greed, non-hatred and non-delusion, the three roots, are the conditioning phenomena by root condition.

(c) Volition is the conditioning phenomenon by conascent kamma.

(d) Contact, volition and consciousness, the three mental nutriments, are the conditioning phenomena by nutriment.

(e) The eight mental faculties are the conditioning phenomena by faculty condition.


<a id="M07-body-P152"></a>
## Jhāna factors, path factors and objects of immaterial life-continuum
Miến / Burmese 152

(f) Equanimity and one-pointedness, the two jhāna factors, are the conditioning phenomena by jhāna condition.

(g) Wisdom, energy, mindfulness and one-pointedness, the four path factors, are the conditioning phenomena by path condition (6). Total: 7 + 6 = 13.

2. (a) The conditioned phenomena are the four mental aggregates constituted by the four kinds of life-continuum of the base of infinite space consciousness and the 30 mental factors excluding the abstinences, immeasurables, applied thought, sustained thought and joy. The concept of space, the concept of the empty space obtained by removing any one of the nine kasiṇas excluding the space kasiṇa, is the kamma sign serving as the conditioning phenomenon by object condition (1).

(b) The conditioned phenomena are the four mental aggregates constituted by the four kinds of life-continuum of the base of infinite consciousness consciousness and the 30 mental factors excluding the abstinences, immeasurables, applied thought, sustained thought and joy. The sign of past wholesome kamma of the base of infinite space, namely the sign of that exalted wholesome kamma, is the conditioning phenomenon by object condition (1).

(c) The conditioned phenomena are the four mental aggregates constituted by the four kinds of life-continuum of the base of nothingness consciousness and the 30 mental factors excluding the abstinences, immeasurables, applied thought, sustained thought and joy. The concept of absence (natthibhāvapaññatti), namely the absence of the jhāna consciousness of the base of infinite space, is the kamma sign serving as the conditioning phenomenon by object condition (1).

(d) The conditioned phenomena are the four mental aggregates constituted by the four kinds of life-continuum of the base of neither perception nor non-perception consciousness and the 30 mental factors excluding the abstinences, immeasurables, applied thought, sustained thought and joy. The sign of past wholesome kamma of the base of nothingness, namely the sign of that exalted wholesome kamma, is the conditioning phenomenon by object condition (1).


<a id="M07-body-P153"></a>
## Proximity for immaterial life-continuum and the arising of immaterial death
Miến / Burmese 153

3. (a) The conditioning phenomena are the corresponding immaterial rebirth-linking mental aggregates, which have just ceased with no interval.

(b) The conditioning phenomena are the immediately preceding immaterial life-continuum mental aggregates, which have just ceased with no interval.

(c) The conditioning phenomena are the last impulsion mental aggregates, which have just ceased with no interval.

Those appropriate mental aggregates support by proximity, contiguity, decisive support, absence and disappearance (5).

4. An appropriate wholesome kamma among the four kinds of past immaterial wholesome kamma is the conditioning phenomenon by asynchronous kamma and natural decisive support (2).

These phenomena arise and persist through the simultaneous support of these 21 conditions, each according to its appropriate power.

How immaterial death arises

The conditioned phenomena are the four mental aggregates constituted by the four kinds of immaterial death consciousness and the 30 mental factors excluding the abstinences, immeasurables, applied thought, sustained thought and joy —

1. Mental conascence group — 13.

2. Object group — 1.

3. Proximity group — 5.

4. Asynchronous kamma group — 2.

These phenomena arise and persist through the simultaneous support of these 21 conditions, each according to its appropriate power.


<a id="M07-body-P154"></a>
## Mental conascence and objects of immaterial death
Miến / Burmese 154

The conditioned phenomena are the four mental aggregates constituted by the four kinds of immaterial death consciousness and the 30 mental factors excluding the abstinences, immeasurables, applied thought, sustained thought and joy —

1. (a) The four kinds of immaterial death consciousness and the 30 mental factors excluding the abstinences, immeasurables, applied thought, sustained thought and joy support one another. These constituent mental aggregates are conditioning phenomena by conascence, mutuality, dependence, result, association, presence and non-disappearance (7).

In the mental aggregates of immaterial death, the following support the associated aggregates —

(b) Non-greed, non-hatred and non-delusion, the three roots, are the conditioning phenomena by root condition.

(c) Volition is the conditioning phenomenon by conascent kamma.

(d) Contact, volition and consciousness, the three mental nutriments, are the conditioning phenomena by nutriment.

(e) The eight mental faculties are the conditioning phenomena by faculty condition.

(f) Equanimity and one-pointedness, the two jhāna factors, are the conditioning phenomena by jhāna condition.

(g) Wisdom, energy, mindfulness and one-pointedness, the four path factors, are the conditioning phenomena by path condition (6). Total: 7 + 6 = 13.

2. (a) When death of the base of infinite space occurs — The concept of space, the concept of the empty space obtained by removing any one of the nine kasiṇas excluding the space kasiṇa, is the kamma sign serving as the conditioning phenomenon.

(b) When death of the base of infinite consciousness occurs — The sign of past wholesome kamma of the base of infinite space, namely the sign of that exalted wholesome kamma, is the conditioning phenomenon.

(c) When death of the base of nothingness occurs — the concept of the absence of the jhāna consciousness of the base of infinite space…


<a id="M07-body-P155"></a>
## Object, proximity and kamma conditions of immaterial death
Miến / Burmese 155

… is the kamma sign serving as the conditioning phenomenon.

(d) When death of the base of neither perception nor non-perception occurs — The sign of past wholesome kamma of the base of nothingness, namely the sign of that exalted wholesome kamma, is the conditioning phenomenon.

Those appropriate conditioning phenomena support by object condition (1).

3. (a) The conditioning phenomena are the mental aggregates of the fifth impulsion in the near-death process, which have just ceased with no interval.

(b) The conditioning phenomena are the immediately preceding immaterial life-continuum mental aggregates, which have just ceased with no interval.

Those appropriate mental aggregates support by proximity, contiguity, decisive support, absence and disappearance (5).

4. The corresponding volitions among the four kinds of past immaterial wholesome kamma support according to their appropriate power by asynchronous kamma and natural decisive support (2).

These phenomena arise and persist through the simultaneous support of these 21 conditions, each according to its appropriate power.

If the good person who is learning previously reached an immaterial realm in the course of past saṃsāra, discern the corresponding immaterial rebirth-linking, life-continuum and death as set out above. For future lives, discern by the same method for as long as that arising continues. If the good person who is learning previously reached the realm of non-percipient beings, discern the Paṭṭhāna conditional relations of the kamma-born materiality of non-percipient beings as follows.

❀ ❀ ❀


<a id="M07-body-P156"></a>
## Kamma-born materiality of non-percipient beings
Miến / Burmese 156

The conditioned phenomena are the kamma-born material phenomena of non-percipient beings —

1. Material conascence group — 5.

2. Asynchronous kamma group — 1.

3. Material life-faculty group — 3.

These material phenomena arise and persist through the simultaneous support of those nine conditions.

For the kamma-born materiality of non-percipient beings —

1. The great elements within the same material group are the conditioning phenomena by conascence, mutuality, dependence, presence and non-disappearance (5).

2. Past wholesome kamma of the fifth fine-material jhāna is the conditioning phenomenon by asynchronous kamma condition (1).

3. The material life-faculty within the same material group is the conditioning phenomenon by material life-faculty, material life-faculty presence and material life-faculty non-disappearance (3).

These material phenomena arise and persist through the simultaneous support of those nine conditions.

Pa-Auk Tawya Sayadaw
Cittala Taung Monastery
Pa-Auk Tawya
Myanmar Era 1367

❀ ❀ ❀


<a id="M07-index-P001"></a>
## Alphabetical index of points to remember
Chỉ mục / Index - Miến / Burmese 157

[အ]

The five aggregates of unwholesome impulsion — 57

How unwholesome impulsion mental aggregates arise and persist in the five-door process — 57

Summary to remember, grouping the conditions of the 54 sense-sphere consciousnesses in the five-door process — 36

Reciprocal support — 28

Conditioning phenomena of mutuality condition — 3

A point to note carefully — 112

The present by period (addhāpaccuppanna) — 121

The proximity group — 68

Conditioning phenomena of the proximity group — 11

The seven proximity-group conditions — 7

Conditioning phenomena of proximity, contiguity, absence and disappearance — 9

The sequence of non-return fruition consciousness — 111

Absorption impulsion, the mind-door process, sense-sphere impulsion and absorption impulsion — 91

Rebirth-linking of beings in states of deprivation — 122

Food that is eaten — 20

The sequence of arahant fruition consciousness — 111

The mental aggregates of noble-path impulsion — 104

How immaterial death arises — 153

How immaterial rebirth-linking arises — 148

How immaterial life-continuum arises — 151

Conditioning phenomena of non-disappearance condition — 2

Kamma-born materiality of non-percipient beings — 156

To obtain clear comprehension through non-delusion (asammohasampajañña) — 1

How rootless death arises — 129

The mental aggregates of the three rootless registration consciousnesses — 76

The two kinds of rootless rebirth-linking — 122

How rootless rebirth-linking arises — 122

How the mental aggregates of the first rootless registration and its consciousness-born materiality arise and persist — 64

How rootless life-continuum arises — 126


<a id="M07-index-P002"></a>
## Alphabetical index of points to remember
Chỉ mục / Index - Miến / Burmese 158

[အာ]

The initial-attainment exalted wholesome impulsion process — 92

Conditioning phenomena of object prenascence non-disappearance condition — 7

The object group — 67, 73

Conditioning phenomena of the object group — 10

Eight or eleven object-group conditions — 6

Conditioning phenomena of object decisive support condition — 6

Conditioning phenomena of repetition condition — 7

Conditioning phenomena of nutriment condition — 5

[ဣ]

Conditioning phenomena of faculty condition — 5

[ဥ]

Temperature-born and nutriment-born materiality — 39

Conditioning phenomena of decisive support condition — 9

[က]

Conditioning phenomena of kamma condition — 5, 7

How sense-sphere impulsion consciousness at the mind door arises and persists — 66

The four kinds of three-rooted sense-sphere wholesome kamma — 15

How the four mental aggregates of three-rooted sense-sphere death arise — 29

How kamma-born materiality at three-rooted sense-sphere rebirth-linking arises — 13

How the four mental aggregates of three-rooted sense-sphere rebirth-linking arise — 18

The four kinds of three-rooted sense-sphere rebirth-linking — 15

How the four mental aggregates of three-rooted sense-sphere life-continuum arise and persist — 25

How two-rooted sense-sphere rebirth-linking arises — 131

The five-aggregate home of the embryo — 20

A point to remember beforehand — 12

[စ]

The five eye-consciousness aggregates, kamma-born materiality during life — 38

How the eye-consciousness mental aggregates arise and persist — 39

The five death aggregates, three-rooted sense-sphere death — 28


<a id="M07-index-P003"></a>
## Alphabetical index of points to remember
Chỉ mục / Index - Miến / Burmese 159

[ဆ]

A summary of the meaning — 10

[ဈ]

Conditioning phenomena of jhāna condition — 5

[တ]

The five registration aggregates — 59

[ဒ]

How the mental aggregates of two-rooted death arise — 136

How the mental aggregates of two-rooted life-continuum arise — 133

[န]

Conditioning phenomena of asynchronous kamma condition — 9

Conditioning phenomena of the asynchronous kamma group — 11

The six asynchronous kamma-group conditions — 9

[ပ]

Natural decisive support — 12

Conditioning phenomena of natural decisive support — 10

Natural decisive support (1) — 10

Twenty-nine conditions — 59

Conditioning phenomena of postnascence non-disappearance condition — 8

Conditioning phenomena of the postnascence group — 11

The four postnascence-group conditions — 8

The five-door process — 52

How materiality arises and persists during a five-door process — 31

The five five-door-adverting aggregates — 32

How temperature-born and nutriment-born materiality arise and persist simultaneously with the arising, presence and dissolution submoments of five-door-adverting consciousness — 35

How kamma-born materiality during life arises and persists simultaneously with the arising, presence and dissolution submoments of five-door-adverting consciousness — 34

The five-door-adverting mental aggregates — 37

How the five-door-adverting mental aggregates and their consciousness-born materiality arise and persist — 32


<a id="M07-index-P004"></a>
## Alphabetical index of points to remember
Chỉ mục / Index - Miến / Burmese 160

How the mental aggregates of smile-producing impulsion in the five-door process arise and persist — 82

Kamma-born materiality at rebirth-linking — 13

The two groups of Paṭṭhāna — 2

Phenomena arising simultaneously — 10

[ဖ]

How the 20 fruition impulsions in fruition attainment arise — 111

The fruition-attainment process, how the 20 fruition impulsions immediately after the path arise — 108

[ဘ]

The life-continuum material aggregate among the five life-continuum aggregates — 20

Arising simultaneously with the arising submoment of life-continuum consciousness — 20

How temperature-born and nutriment-born materiality arise and persist simultaneously with the arising, presence and dissolution submoments of life-continuum consciousness — 23

How kamma-born materiality during life arises and persists simultaneously with the arising, presence and dissolution submoments of life-continuum consciousness — 22

Can arise simultaneously with the presence and dissolution submoments of life-continuum consciousness — 20

[မ]

Conditioning phenomena of path condition — 6

What is called fruition impulsion immediately after the path — 112

The five mind-door-adverting aggregates, the mind-door-adverting mental aggregates — 67

How the mental aggregates of hate-rooted and delusion-rooted impulsions at the mind door arise and persist — 82

The mental aggregates of greed-rooted impulsion at the mind door — 78

The mental aggregates of smile-producing impulsion at the mind door — 85

The physical-base group at the approach of death — 77

The mental aggregates of exalted wholesome impulsion — 93

The exalted wholesome impulsion process — 92


<a id="M07-index-P005"></a>
## Alphabetical index of points to remember
Chỉ mục / Index - Miến / Burmese 161

The mental aggregates of exalted functional impulsion — 99

The mental aggregates of knowledge-dissociated great wholesome impulsion — 72

How the mental aggregates of the first knowledge-associated great wholesome impulsion at the mind door arise and persist — 69

The mental aggregates of the second great wholesome impulsion in the five-door process — 54

The five aggregates of the first great wholesome impulsion in the five-door process — —

How the mental aggregates of the first great wholesome impulsion arise and persist — —

The material aggregate of the first great wholesome impulsion — 50

The mental aggregates of great functional impulsion — 87

One’s own corresponding fruition attainment — 112

Yathāraha, according to what is appropriate — 24

The continuum of arahants — 83

[ယ]

Conditioning phenomena of material nutriment non-disappearance condition — 9

[ရ]

Conditioning phenomena of the material nutriment group — 11

The three material nutriment-group conditions — 9

How fine-material death arises — 146

Conditioning phenomena of material life faculty non-disappearance condition — 9

The material life faculty group — 12

The three material life faculty-group conditions — 9

How the mental aggregates of fine-material rebirth-linking arise — 138

How fine-material life-continuum arises — 142

Conditioned material phenomena — 12

Conditioning phenomena of base-object prenascence non-disappearance condition — 6

[ဝ]

Conditioning phenomena of physical-base prenascence non-disappearance condition — 8

Conditioning phenomena of physical-base prenascence faculty condition — 8

The physical-base group — 68

Conditioning phenomena of the physical-base group — 11


<a id="M07-index-P006"></a>
## Alphabetical index of points to remember
Chỉ mục / Index - Miến / Burmese 162

The six physical-base-group conditions — 8

Conditioning phenomena of disappearance condition — 7

Conditioning phenomena of result condition — 3

Conditioning phenomena of dissociation condition — 4

The five determining aggregates, determining mental aggregates, consciousness-born materiality (the material aggregate) — 47

How the determining mental aggregates arise and persist — 48

The sequence of once-return fruition consciousness — 111

[သ]

The five investigating aggregates, investigating and consciousness-born materiality — 44

The investigating mental aggregates — 46

The exalted wholesome impulsion process for attainment entry — 93

The five receiving aggregates, the receiving material aggregate — 41

The receiving mental aggregates — 43

Conditioning phenomena of association condition — 4

The four major conascence conditions — 2

The seven minor conascence conditions — 4

The four intermediate conascence conditions — 3

How the mental aggregates of the first rooted registration and its consciousness-born materiality arise and persist — 60

The mental aggregates of rooted great-resultant registration — 75

How the mental aggregates of rooted great-resultant registration arise and persist — 61

[ဟ]

The sequence of stream-entry fruition consciousness — 111

Throughout the journey through saṃsāra — 121

[ဂဏန်းများ]

The heart-base (hadayavatthu) — 28

Conditioning phenomena of root condition — 4

Five conditioning phenomena — 36

Six conditioning phenomena — 37

Nine conditioning phenomena — 156

Twelve conditioning phenomena — 23, 35, 39


<a id="M07-index-P007"></a>
## Alphabetical index of points to remember
Chỉ mục / Index - Miến / Burmese 163

Twelve conceptual kamma signs — 147

Fourteen conceptual kamma signs — 156

Sixteen conditioning phenomena — 22, 34, 39

Twenty-one conditioning phenomena — 33, 48, 151, 153, 155

Twenty-two conditioning phenomena — 42, 45, 64

22/25/27 conditioning phenomena — 85, 87

Twenty-four conditioning phenomena — 21, 50, 60, 128, 131

Twenty-five conditioning phenomena — 14, 16, 37, 50, 84, 125

Twenty-five conceptual kamma signs — 140, 143, 147

25/28/30/27 conditioning phenomena — 69, 74, 88, 90

Twenty-six conditioning phenomena — 26, 28, 29, 93, 99, 133, 136, 145, 148

26/29/31 conditioning phenomena — 78

Twenty-seven conditioning phenomena — 18, 133, 141

Twenty-eight conditioning phenomena — 40, 43, 47, 52, 57, 77, 82, 104

Twenty-nine conditioning phenomena — 55, 108

Thirty conditioning phenomena — 62, 76, 113
