# Nibbānagāminipaṭipadā · Mini · Cuốn 4 / Volume 4
Meditation on Mentality
Pa-Auk Tawya Sayadaw
English

## Mục lục / Contents

- [Title page](#M04-front-P001)
- [The gift of Dhamma and aspiration](#M04-front-P002)
- [Contents — က](#M04-front-P003)
- [Contents — ခ](#M04-front-P004)
- [Contents — ဂ](#M04-front-P005)
- [Contents — ဃ](#M04-front-P006)
- [Contents — င](#M04-front-P007)
- [Contents — စ](#M04-front-P008)
- [Contents — ဆ](#M04-front-P009)
- [Contents — ဇ](#M04-front-P010)
- [What to know about consciousness — A hundred thousand koṭis](#M04-body-P001)
- [Three ways to apprehend mental phenomena](#M04-body-P002)
- [Apprehending materiality as the basis for discerning mentality](#M04-body-P003)
- [Apprehending materiality before mentality](#M04-body-P004)
- [The simile of the mountain cow](#M04-body-P005)
- [Discerning mentality with tranquillity as the vehicle](#M04-body-P006)
- [Two points to know beforehand](#M04-body-P007)
- [Further explanation of bases and doors](#M04-body-P008)
- [Why apprehend mentality by door](#M04-body-P009)
- [Two practical rules and the scope of mundane mentality](#M04-body-P010)
- [Mundane consciousnesses within the scope of discernment](#M04-body-P011)
- [What to know before discerning mentality](#M04-body-P012)
- [The six bases and six doors](#M04-body-P013)
- [Six objects and six kinds of mind-object](#M04-body-P014)
- [The meaning of object and the first consciousness elements](#M04-body-P015)
- [The remaining consciousness elements and the six cognitive processes](#M04-body-P016)
- [Naming processes by consciousness and the order of their moments](#M04-body-P017)
- [Cognitive processes and the presentation of objects](#M04-body-P018)
- [The remaining modes of presentation and the objects of insight knowledge](#M04-body-P019)
- [Consciousness and the kinds of unwholesome consciousness](#M04-body-P020)
- [Greed-rooted and hatred-rooted consciousness](#M04-body-P021)
- [Delusion-rooted consciousness and rootless unwholesome resultants](#M04-body-P022)
- [Rootless wholesome resultants and rootless functional consciousness](#M04-body-P023)
- [Eighteen rootless consciousnesses and beautiful sense-sphere consciousnesses](#M04-body-P024)
- [Great wholesome and great resultant consciousnesses](#M04-body-P025)
- [Great functional consciousnesses and the sense-sphere total](#M04-body-P026)
- [Sense-sphere objects of insight and five fine-material wholesome consciousnesses](#M04-body-P027)
- [Fine-material consciousness and wholesome immaterial consciousnesses](#M04-body-P028)
- [Immaterial consciousness and the scope of discernment for jhāna attainments](#M04-body-P029)
- [Eighty-one mundane and eight supramundane consciousnesses](#M04-body-P030)
- [Path, fruition and jhāna factors](#M04-body-P031)
- [Forty supramundane consciousnesses](#M04-body-P032)
- [Part 2. What to know about mental factors](#M04-body-P033)
- [The fifty-two mental factors and the universals](#M04-body-P034)
- [The seven universal mental factors, continued](#M04-body-P035)
- [The six occasional mental factors](#M04-body-P036)
- [Desire and the distinction between applied thought, volition and attention](#M04-body-P037)
- [The four unwholesome universals and the greed group](#M04-body-P038)
- [Conceit and ignorance](#M04-body-P039)
- [Correct knowing and mistaken knowing](#M04-body-P040)
- [Two kinds of clinging to self](#M04-body-P041)
- [Clinging by convention and clinging by wrong view](#M04-body-P042)
- [Distinguishing delusion from wrong view, and the hatred group](#M04-body-P043)
- [Remorse, sloth, torpor and doubt](#M04-body-P044)
- [Doubt and the beautiful mental factors](#M04-body-P045)
- [Faith, mindfulness, moral shame, moral dread and non-greed](#M04-body-P046)
- [The beautiful universals, continued](#M04-body-P047)
- [Proficiency, rectitude and two kinds of deceit](#M04-body-P048)
- [Abstinences, immeasurables and the faculty of wisdom](#M04-body-P049)
- [The faculty of wisdom and an important guideline](#M04-body-P050)
- [Discerning internally and externally, materiality and mentality](#M04-body-P051)
- [The four contemplations and the scope of discernment](#M04-body-P052)
- [Discerning all types and the four establishments of mindfulness](#M04-body-P053)
- [Entrances to mindfulness and how the tranquillity practitioner begins](#M04-body-P054)
- [Beginning the apprehension of mentality with feeling](#M04-body-P055)
- [Apprehending the five when beginning with feeling or consciousness](#M04-body-P056)
- [Beginning with contact and apprehending all mental phenomena](#M04-body-P057)
- [Why the five with contact as the fifth are named](#M04-body-P058)
- [Apprehending all associated phenomena](#M04-body-P059)
- [A very difficult undertaking](#M04-body-P060)
- [The similes of mixed oils and the waters of five rivers](#M04-body-P061)
- [The meaning of the simile for distinguishing mentality](#M04-body-P062)
- [Material phenomena in mixed waters and oils](#M04-body-P063)
- [The Buddha’s distinction of individual mental phenomena](#M04-body-P064)
- [The dialogue between Nāgasena and King Milinda](#M04-body-P065)
- [The simile of tasting seawater](#M04-body-P066)
- [The difficult task accomplished by the Buddha](#M04-body-P067)
- [Apprehend base and object together](#M04-body-P068)
- [How Venerable Sāriputta discerned the mentality of jhāna](#M04-body-P069)
- [The base and object to apprehend first](#M04-body-P070)
- [Return to apprehending materiality](#M04-body-P071)
- [The material body as the support](#M04-body-P072)
- [From the guidelines to the cognitive processes](#M04-body-P073)
- [Part 3. Jhāna attainment with the breathing counterpart sign](#M04-body-P074)
- [Jhāna attainment with a kasiṇa counterpart sign](#M04-body-P075)
- [Jhāna factors at access and absorption](#M04-body-P076)
- [Four divine abidings · Jhāna attainment tables](#M04-body-P077)
- [Only for those who have attained jhāna](#M04-body-P078)
- [Process abbreviations and beginning to apprehend jhāna](#M04-body-P079)
- [Training to apprehend jhāna mentality](#M04-body-P080)
- [Thirty-four first-jhāna mental phenomena with the breathing counterpart sign](#M04-body-P081)
- [First-jhāna mental phenomena from feeling to joy](#M04-body-P082)
- [First-jhāna mental phenomena from desire to lightness of the mental body](#M04-body-P083)
- [First-jhāna mental phenomena from lightness of consciousness to wisdom](#M04-body-P084)
- [Knowledge delimiting mentality](#M04-body-P085)
- [How to begin apprehending first-jhāna mentality](#M04-body-P086)
- [Gradually increasing the number of mental phenomena apprehended](#M04-body-P087)
- [Delimiting mentality and a note on the sixteen phenomena](#M04-body-P088)
- [Two interpretations of the mental phenomena named in the Anupada Sutta](#M04-body-P089)
- [Phenomena included in the further interpretation](#M04-body-P090)
- [Distinguishing mentality and materiality](#M04-body-P091)
- [From jhāna mentality to mentality that takes materiality as object](#M04-body-P092)
- [Wise and unwise attention](#M04-body-P093)
- [Definition and four ways of attending wisely](#M04-body-P094)
- [Attention in accordance with and contrary to the Four Noble Truths](#M04-body-P095)
- [Great wholesome mentality taking eye-sensitivity as object](#M04-body-P096)
- [Mental phenomena taking eye-sensitivity as object](#M04-body-P097)
- [Preparing to read the bare mind-door process table](#M04-body-P098)
- [Wholesome bare mind-door process table](#M04-body-P099)
- [How to apprehend mind-door processes with wholesome impulsions](#M04-body-P100)
- [Six ways of attending wisely to eye-sensitivity](#M04-body-P101)
- [Apprehending individual mental phenomena in the mind-door process](#M04-body-P102)
- [Four cases of association with knowledge and joy](#M04-body-P103)
- [Points to know about registration](#M04-body-P104)
- [Registration after weak insight impulsion](#M04-body-P105)
- [Conditions and kinds of registration consciousness](#M04-body-P106)
- [Registration table and the distinction between resultants and impulsion](#M04-body-P107)
- [Undesirable objects and guest life-continuum](#M04-body-P108)
- [The object of guest life-continuum and three cases without registration](#M04-body-P109)
- [The linking function of guest life-continuum](#M04-body-P110)
- [Wholesome mind-door process table with concrete materiality as object](#M04-body-P111)
- [Registration with undesirable and desirable objects](#M04-body-P112)
- [Reading the registration counts and discerning concrete materiality](#M04-body-P113)
- [How to discern non-concrete materiality](#M04-body-P114)
- [Wholesome mind-door process table with non-concrete materiality as object](#M04-body-P115)
- [Analysing material clusters before apprehending mentality](#M04-body-P116)
- [Abstinence through right speech](#M04-body-P117)
- [Abstinence through right action](#M04-body-P118)
- [Abstinence through right livelihood](#M04-body-P119)
- [Table of the three abstinence factors in mind-door processes](#M04-body-P120)
- [Three senses of right speech and right action](#M04-body-P121)
- [Right livelihood and two kinds of mundane abstinence](#M04-body-P122)
- [Abstinence through eradication and objects of mundane abstinence](#M04-body-P123)
- [The object in relation to which one could transgress, and the volition to transgress](#M04-body-P124)
- [Objects of particular kinds of abstinence](#M04-body-P125)
- [The two immeasurable mental factors](#M04-body-P126)
- [Feeling in appreciative joy, faith and wisdom](#M04-body-P127)
- [Table of immeasurable factors and recollection of the Buddha](#M04-body-P128)
- [The Buddha’s qualities as mind-door objects](#M04-body-P129)
- [Recollection of death](#M04-body-P130)
- [Mind-door process table for recollection of the Buddha and death](#M04-body-P131)
- [From recollection of death to five-door processes](#M04-body-P132)
- [One object appears simultaneously at two doors](#M04-body-P133)
- [The simile of the alighting bird and its shadow](#M04-body-P134)
- [Eye-door process abbreviations and past life-continuum](#M04-body-P135)
- [Eye-door processes ending in registration or impulsion](#M04-body-P136)
- [Eye-door processes with a great object of the second type and a slight object of the first type](#M04-body-P137)
- [Eye-sensitivity of medium duration](#M04-body-P138)
- [Three groups of sensitivity and the base of mind consciousness](#M04-body-P139)
- [Which heart-base supports each consciousness](#M04-body-P140)
- [Operation of five-door and mind-door processes](#M04-body-P141)
- [The first processes from visible form to recognition of colour](#M04-body-P142)
- [Recognizing colour, convention, and the entity](#M04-body-P143)
- [Four conditions for wholesome impulsion](#M04-body-P144)
- [Four wholesome conditions and discerning the visible-object group](#M04-body-P145)
- [Four process types according to the remaining duration of the object](#M04-body-P146)
- [Wholesome-group table taking colour as object](#M04-body-P147)
- [How to apprehend eye-door and mind-door processes taking colour](#M04-body-P148)
- [Limits of sense consciousness and the following mind-door process](#M04-body-P149)
- [Gradually increasing the number of mental factors apprehended](#M04-body-P150)
- [Supporting materiality, life-continuum, and wise attention](#M04-body-P151)
- [Ways of attending wisely to visible form](#M04-body-P152)
- [Why mentality is apprehended in six ways](#M04-body-P153)
- [Registration after insight impulsion and the table of mental factors](#M04-body-P154)
- [Explaining the mental counts in the eye-door process](#M04-body-P155)
- [Apprehending wholesome mentality taking sound as object](#M04-body-P156)
- [Six ways of attending to sound](#M04-body-P157)
- [Apprehending wholesome mentality taking odour as object](#M04-body-P158)
- [Apprehending wholesome mentality taking taste as object](#M04-body-P159)
- [Six ways of attending to taste and beginning to discern tangibles](#M04-body-P160)
- [Discerning tangibles by three elements](#M04-body-P161)
- [The brain and knowing wisdom](#M04-body-P162)
- [Body-consciousness, wisdom and feeling](#M04-body-P163)
- [Four mind-object groups and immaterial jhāna mentality](#M04-body-P164)
- [Objects of the remaining immaterial jhānas](#M04-body-P165)
- [Part 4. Apprehending unwholesome mentality](#M04-body-P166)
- [The condition for unwholesome impulsion](#M04-body-P167)
- [Discerning three kinds of unwholesome thought](#M04-body-P168)
- [Abandoning unwholesome thought by substitution and eradication](#M04-body-P169)
- [Four cases of the greed-and-wrong-view group](#M04-body-P170)
- [The greed-and-conceit group and the hatred group](#M04-body-P171)
- [Hatred with envy, stinginess, or remorse](#M04-body-P172)
- [The two delusion-rooted groups](#M04-body-P173)
- [Beginning from ultimate materiality or a conceptual object](#M04-body-P174)
- [Example of the greed-and-wrong-view group taking gold as object](#M04-body-P175)
- [Wrong view taking gold and familiar things as objects](#M04-body-P176)
- [Objects for the greed-and-conceit group and hatred groups](#M04-body-P177)
- [Objects of remorse, restlessness, and doubt](#M04-body-P178)
- [Twenty mental phenomena in the greed-and-wrong-view group](#M04-body-P179)
- [Mental factors from life faculty to delusion](#M04-body-P180)
- [The remaining factors and four cases of the greed group](#M04-body-P181)
- [Delusion, lack of shame, and lack of dread in the unwholesome groups](#M04-body-P182)
- [Mind-door process table for unwholesome impulsion taking mind objects](#M04-body-P183)
- [Discerning greed and wrong view with eye-sensitivity as object](#M04-body-P184)
- [Discerning conceit, hatred, envy, and stinginess with eye-sensitivity](#M04-body-P185)
- [Discerning remorse, restlessness and doubt, and the rule for registration](#M04-body-P186)
- [Alternating discernment of wholesome and unwholesome groups](#M04-body-P187)
- [How the ten fetters arise on seeing visible form](#M04-body-P188)
- [The fetters of sensual desire and desire for existence](#M04-body-P189)
- [Fetters of desire for existence, wrong view and attachment to rules and observances](#M04-body-P190)
- [Attachment to observances, conceit, aversion and envy](#M04-body-P191)
- [Stinginess and remorse over what was done](#M04-body-P192)
- [Remorse over omission, restlessness, doubt and ignorance](#M04-body-P193)
- [Fetters arise in groups, and the limits of eye-consciousness](#M04-body-P194)
- [Colour in eye-door and mind-door processes](#M04-body-P195)
- [Eye-door and mind-door process table with unwholesome impulsion](#M04-body-P196)
- [How to discern the unwholesome group taking visible form](#M04-body-P197)
- [Wrong view at the mind-door and its imprint in the eye-door process](#M04-body-P198)
- [Feeling in investigating, impulsion and registration](#M04-body-P199)
- [Applying the method to sound, odour, taste and tangibles](#M04-body-P200)
- [Taste, tangibles, and the order of the six groups](#M04-body-P201)
- [The detailed method of apprehending mentality](#M04-body-P202)
- [Applying the detailed method at the six doors and in the forty-two parts](#M04-body-P203)
- [Three summary tables of mentality groups](#M04-body-P204)
- [Objects of the four immaterial jhānas and defining mentality](#M04-body-P205)
- [Grouping mental phenomena and apprehending mentality and materiality together](#M04-body-P206)
- [Base, object and mentality in each moment](#M04-body-P207)
- [Delimiting mentality and materiality](#M04-body-P208)
- [Part 5. Four kinds of compactness of mentality](#M04-body-P209)
- [The four kinds of compactness and compactness of continuity](#M04-body-P210)
- [Breaking compactness of continuity and recognizing compactness of collection](#M04-body-P211)
- [Distinguishing individual phenomena and functions](#M04-body-P212)
- [Breaking compactness of mental function](#M04-body-P213)
- [Compactness of object and the two sides of insight](#M04-body-P214)
- [Three kinds of compactness in the insight process](#M04-body-P215)
- [Breaking compactness of object to see non-self](#M04-body-P216)
- [The characteristic of non-self and three insights](#M04-body-P217)
- [Part 6. Postures and clear comprehension](#M04-body-P218)
- [Discerning the five aggregates in postures and activities](#M04-body-P219)
- [An example of discerning the five aggregates while looking](#M04-body-P220)
- [The five aggregates in the eye-door process and the walking exercise](#M04-body-P221)
- [Predominant and non-predominant materiality](#M04-body-P222)
- [Materiality producing motion and materiality moved](#M04-body-P223)
- [The simile of a person carrying a sack of rice](#M04-body-P224)
- [How to discern the five aggregates while walking](#M04-body-P225)
- [Four tasks and internal and external contemplation](#M04-body-P226)
- [Why both internal and external contemplation are needed](#M04-body-P227)
- [The external domain and how to begin](#M04-body-P228)
- [Apprehending external materiality from clothing to inanimate objects](#M04-body-P229)
- [Extending external discernment of materiality and mentality](#M04-body-P230)
- [Apprehending external processes collectively](#M04-body-P231)
- [The scope of insight and four steps of practice](#M04-body-P232)
- [Contemplating arising and passing away by condition and by moment](#M04-body-P233)
- [Three knowledges and two ways of apprehending conditions](#M04-body-P234)
- [Developing the four foundations of mindfulness and choosing a starting point](#M04-body-P235)
- [Beginning with materiality or mentality and proceeding with both](#M04-body-P236)
- [The four foundations distinguished in the preparatory phase](#M04-body-P237)
- [Four functions of one mindfulness at the path moment](#M04-body-P238)
- [Contemplation of body and feelings, and names according to the person](#M04-body-P239)
- [Contemplation of mind and phenomena, and names according to phenomena](#M04-body-P240)
- [One mindfulness completes four tasks](#M04-body-P241)
- [Practising the four foundations from four starting points](#M04-body-P242)
- [Three points to remember about practising the foundations](#M04-body-P243)
- [In the seen, only the seen](#M04-body-P244)
- [The seen, heard, sensed and cognized as objects of insight](#M04-body-P245)
- [Eye-consciousness sees and the process continues according to conditions](#M04-body-P246)
- [Where a process ends and what “only” means](#M04-body-P247)
- [The meaning for practice and closing aspiration](#M04-body-P248)
- [Alphabetical index — Burmese page 249](#M04-index-P001)
- [Alphabetical index — Burmese page 250](#M04-index-P002)
- [Alphabetical index — Burmese page 251](#M04-index-P003)
- [Alphabetical index — Burmese page 252](#M04-index-P004)
- [Alphabetical index — Burmese page 253](#M04-index-P005)
- [Alphabetical index — Burmese page 254](#M04-index-P006)
- [Alphabetical index — Burmese page 255](#M04-index-P007)
- [Alphabetical index — Burmese page 256](#M04-index-P008)
- [Alphabetical index — Burmese page 257](#M04-index-P009)
- [Alphabetical index — Burmese page 258](#M04-index-P010)
- [Alphabetical index — Burmese page 259](#M04-index-P011)

<a id="M04-front-P001"></a>
## Title page
Đầu sách / Front matter - 1

Nibbānagāminipaṭipadā. The Practice Leading to Nibbāna (Abridged), Volume 4.

Meditation on Mentality (Nāmakammaṭṭhāna).

Pa-Auk Tawya Sayadaw.


<a id="M04-front-P002"></a>
## The gift of Dhamma and aspiration
Đầu sách / Front matter - 2

Sabbadānaṃ dhammadānaṃ jināti.
Sabbarasaṃ dhammaraso jināti.
Sabbaratiṃ dhammarati jināti.
Taṇhakkhayo sabbadukkhaṃ jināti.

The gift of Dhamma surpasses every gift.
The taste of Dhamma surpasses every taste.
Delight in Dhamma surpasses every delight.
The destruction of craving overcomes all suffering.

Ciraṃ tiṭṭhatu saddhammo, dhamme hontu sagāravā.

May the Buddha’s dispensation endure for a long time.
May all honour the three kinds of true Dhamma.


<a id="M04-front-P003"></a>
## Contents — က
Đầu sách / Front matter - 3

Namo tassa bhagavato arahato sammāsambuddhassa.

Part 1. What to know about consciousness — 1

A hundred thousand koṭis — 1

Three ways to apprehend mental phenomena — 2

Two points to know beforehand — 7

Further explanation — 8

Mundane mental phenomena only — 10

What to know beforehand — 12

Six bases — material supports for the arising of mentality — 13

Six doors — 13

Six objects — 14

Six kinds of mind-object — 14

Six consciousness elements — 15

Six kinds of cognitive process — 16

Six modes of occurrence of objects — 18

Types of consciousness that can be objects of insight knowledge — 19

Twelve kinds of unwholesome consciousness — 20

Eight kinds rooted in greed — 20

Two kinds rooted in hatred — 21

Two kinds rooted in delusion — 22

Eighteen rootless consciousnesses — seven unwholesome-resultant consciousnesses — 22


<a id="M04-front-P004"></a>
## Contents — ခ
Đầu sách / Front matter - 4

Eight rootless wholesome-resultant consciousnesses — 23

Three rootless functional consciousnesses — 23

Twenty-four sense-sphere beautiful consciousnesses — eight great wholesome consciousnesses — 24

Eight great resultant consciousnesses — 25

Eight great functional consciousnesses — 26

Fifteen fine-material-sphere consciousnesses — five wholesome consciousnesses — 27

Twelve immaterial-sphere consciousnesses — four wholesome consciousnesses — 28

Eight supramundane consciousnesses in brief — four noble path consciousnesses — 30

Four noble fruition consciousnesses — 30

Forty supramundane consciousnesses in detail — 31

Part 2. What to know about mental factors — 33

Four characteristics of mental factors associated with consciousness — 33

Fifty-two mental factors — 34

Seven universal mental factors — 34

Six occasional mental factors — 36

Applied thought, volition and attention — 37

Fourteen unwholesome mental factors — four universal unwholesome mental factors — 38

Three mental factors in the greed group — 38

Further explanation — 39

Two kinds of clinging to self — 41

Distinguishing delusion from wrong view in brief — 43

Four mental factors in the hatred group — 43

Two mental factors in the sloth group — 44


<a id="M04-front-P005"></a>
## Contents — ဂ
Đầu sách / Front matter - 5

One mental factor in the delusion group — 44

Twenty-five beautiful mental factors — 45

Nineteen universal beautiful mental factors — 45

Māyā and sāṭheyya — concealment of faults and deceit — 48

Three abstinence mental factors — 49

Two immeasurable mental factors — 49

One mental factor that is the faculty of wisdom — 49

An important guideline — 50

Four kinds of contemplation — 52

Guideline for beginning apprehension from feeling — 55

Guideline for beginning apprehension from consciousness — 56

Guideline for beginning apprehension from contact — 57

Apprehend all mental phenomena — 57

A very difficult undertaking — 60

Apprehend base and object together — 68

Return to apprehending material phenomena — 71

Part 3. How to apprehend and discern — 74

The counterpart sign as the object of mindfulness of breathing — 74

Mind-object track — table of the mind-door process of jhāna attainment — 74

Applied thought, sustained thought and joy — 75

Four divine abidings — table of the process of jhāna attainment — 77

Only for those who have attained jhāna — 78

Names of the consciousnesses in a process — 79

How to apprehend the mental phenomena of jhāna — 79


<a id="M04-front-P006"></a>
## Contents — ဃ
Đầu sách / Front matter - 6

Thirty-four mental phenomena of first jhāna taking the breathing counterpart sign as object — 81

Knowledge of apprehending mentality — 85

Distinctions to bear in mind — 88

Distinguish mentality and materiality — 91

Wise attention and unwise attention — 93

What wise attention means — 94

What unwise attention means — 95

Thirty-four mental phenomena in great wholesome impulsion taking eye-sensitivity as object — 96

Mind-object track — table of the wholesome group in the pure mind-door process — 99

How to apprehend and discern the succession of consciousness in a wholesome mind-door impulsion process — 100

What to know about registration — 104

Registration table for three-rooted worldlings — 107

Actual resultants and what lies outside impulsion — 107

Mind-object track — wholesome mind-door process table and how to discern concrete materiality as object — 111

Concrete material phenomena to discern in the same way — 113

Mind-object track — wholesome mind-door process table and how to discern non-concrete materiality as object — 115

Nine kinds of non-concrete materiality to discern in the same way — 115

Right speech — abstinence — 117

Right action — abstinence — 118

Right livelihood — abstinence — 119

Mind-object track — table of abstinence in the mind-door process — 120


<a id="M04-front-P007"></a>
## Contents — င
Đầu sách / Front matter - 7

Three kinds of right speech — 121

Three kinds of right action — 121

Right livelihood — 122

Abstinence on encountering an occasion, through undertaking, and through eradication — 122

Objects of abstinence on encountering an occasion and abstinence through undertaking — 123

Two immeasurable mental factors — 126

Mind-object track — table of the immeasurable mental factors in the sense-sphere mind-door process — 128

Meditation subject of recollection of the Buddha — 128

Meditation subject of mindfulness of death — 130

Mind-object track — table of recollection of the Buddha and mindfulness of death — 131

Points to know beforehand — 132

Symbols used in the eye-door process — 135

Eye-door process with a very great object — course ending in registration — 136

Eye-door process with a great object, first type — course ending in impulsion — 136

Eye-door process with a great object, second type — course ending in impulsion — 137

Eye-door process with a slight object, first type — course ending in determining — 137

Weak, strong and intermediate sensitivity — 138

The strength of the five-door and mind-door processes — 141

The occurrence of wholesome impulsion — 144

Visible-object track — how to discern the wholesome group — 145

Visible object — colour track — tables of the wholesome group — 147

Wise attention — 151

Table of the numbers of consciousnesses and mental factors — 154

Further explanations — 155


<a id="M04-front-P008"></a>
## Contents — စ
Đầu sách / Front matter - 8

Sound-object track — how to apprehend the mental phenomena of the wholesome group — 156

Odour-object track — how to apprehend the mental phenomena of the wholesome group — 158

Taste-object track — how to apprehend the mental phenomena of the wholesome group — 159

Tangible-object track — how to apprehend the mental phenomena of the wholesome group — 160

The brain and consciousness — 162

Part 4. How to apprehend and discern the unwholesome group — 166

Does unwholesomeness arise again when discerning unwholesome phenomena? — 166

Four points on the mental phenomena of the greed-and-wrong-view group — 170

Four points on the mental phenomena of the greed-and-conceit group — 171

Two points on the mental phenomena of the hatred group — 171

Two points on the mental phenomena of the hatred-and-envy group — 172

Two points on the mental phenomena of the hatred-and-stinginess group — 172

Four points on the mental phenomena of the hatred-and-remorse group — 172

One point on the mental phenomena of the delusion-and-restlessness group — 173

One point on the mental phenomena of the delusion-and-doubt group — 173

Summary of how to apprehend groups of unwholesome mental phenomena taking concepts as object — 175

Twenty mental phenomena in the greed-and-wrong-view group — 179

Mind-object track — table of the unwholesome group in the mind-door process — 183

Taking eye-sensitivity as object — how to discern the greed-and-wrong-view group — 184

Taking eye-sensitivity as object — how to discern the greed-and-conceit group and related groups — 185

Registration following unwholesome impulsion — 186

A request for a suitable method of practice — 187

How the ten fetters arise — 188


<a id="M04-front-P009"></a>
## Contents — ဆ
Đầu sách / Front matter - 9

Visible object — colour track — table of processes with unwholesome impulsion — 196

A point to note — 194

Visible-object track — how to discern the unwholesome group when unwholesome impulsion occurs — 197

Sound-, odour-, taste- and tangible-object tracks — 200

How to apprehend mentality in detail — 202

Summary table of the six object tracks — 204

Apprehend mental phenomena as “mentality, mentality” — 205

Apprehend materiality and mentality together — the work of apprehending both — 206

Defining mentality and materiality (nāmarūpavavatthāna) — distinguishing and noting mentality and materiality — 208

Part 5. Mental compactness — 209

The four kinds of mental compactness — 209

1. Compactness of continuity (santatighana) — the compactness of the mental succession — 210

2. Compactness of group (samūhaghana) — the compactness of the mental group — 211

3. Compactness of function (kiccaghana) — the compactness of mental functions — 212

4. Compactness of object (ārammaṇaghana) — the compactness of mental phenomena that take an object — 214

Part 6. Postures, clear comprehension and related topics — 218

The scope of discernment in postures and clear comprehension — 218

Outline of discerning the five aggregates — 220

Summary of the method of discernment — 221

1. Padhāna — prominent materiality — 222

2. Appadhāna — less prominent materiality — 222

Materiality that carries and materiality that is carried — 223

Method for discerning the five aggregates — 225


<a id="M04-front-P010"></a>
## Contents — ဇ
Đầu sách / Front matter - 10

The scope of discernment for advancing a step further — 226

Summary of the method of discerning externally — 228

Advancing a step further — 232

How to continue developing the four establishments of mindfulness — 235

Practice method for “in the seen, only the seen” (diṭṭhe diṭṭhamattaṃ) — 244


<a id="M04-body-P001"></a>
## What to know about consciousness — A hundred thousand koṭis
Miến / Burmese 1

Namo tassa bhagavato arahato sammāsambuddhassa.

Meditation on Mentality. Part 1. What to know about consciousness.

Ekaccharakkhaṇe koṭisatasahassasaṅkhyā uppajjitvā nirujjhanti. (Saṃyutta Nikāya Commentary, vol. 2, p. 295.)
In a finger snap, a hundred thousand koṭis arise and cease.

In the time it takes to blink, for lightning to flash, or to snap the fingers, mental phenomena arise and cease more than a hundred thousand koṭis of times. Citing such statements in the texts, people repeatedly challenge practitioners with that number: “How can one discern mental phenomena arising and ceasing more than a hundred thousand koṭis of times in the blink of an eye, a flash of lightning, or a snap of the fingers?” Thus a meditation subject that once flourished receives little favour in today’s insight circles, as though it lay quietly hidden in a corner of the dispensation. We have now reached the section on apprehending and discerning those mental phenomena. May all good friends of pure heart apply themselves diligently to developing this meditation subject.


<a id="M04-body-P002"></a>
## Three ways to apprehend mental phenomena
Miến / Burmese 2

Tividho hi arūpakammaṭṭhāne abhiniveso phassavasena vedanāvasena cittavasenāti. (Dīgha Nikāya Commentary, vol. 2, p. 314; Majjhima Nikāya Commentary, vol. 1, p. 280; Abhidhamma Commentary, vol. 2, p. 252.)
There are three ways of entering meditation on mentality, by way of contact, feeling, or consciousness.

There are three ways to begin meditation on mentality, that is, to begin distinguishing mental phenomena with wisdom:
1. Begin apprehending them from contact, for those to whom contact is prominent.
2. Begin from feeling, for those to whom feeling is prominent.
3. Begin from consciousness, for those to whom consciousness is prominent.

If you are a practitioner whose vehicle is pure insight (suddhavipassanāyānika), take the following guideline to heart and follow it when beginning meditation on mentality.

Yasmā ca evaṃ suvisuddharūpapariggahasseva tassa arūpadhammā tīhākārehi pākaṭā honti. Tasmā suvisuddharūpapariggaheneva arūpapariggahāya yogo kātabbo, na itarena. Sace hi ekasmiṃ vā rūpadhamme upaṭṭhite dvīsu vā rūpaṃ pahāya arūpapariggahaṃ ārabhati kammaṭṭhānato parihāyati, pathavīkasiṇabhāvanāya vuttappakārā pabbateyyā gāvī viya. Suvisuddharūpapariggahassa pana arūpapariggahāya yogaṃ karoto kammaṭṭhānaṃ vuddhiṃ virūḷhiṃ vepullaṃ pāpuṇāti. (Visuddhimagga, vol. 2, p. 227.)

Mental phenomena become clear in those three ways when one’s apprehension of materiality is thoroughly purified. Therefore, undertake the apprehension of mentality once the apprehension of materiality is thoroughly purified. If one or two material phenomena have become evident and one abandons materiality to begin apprehending mentality, one falls away from the meditation subject, like the mountain cow described in the development of the earth kasiṇa. When one whose apprehension of materiality is thoroughly purified works at apprehending mentality, the meditation subject grows, develops and comes to fullness.

A lower jhāna that has been well developed and brought to mastery serves as the basis and principal condition for a higher jhāna. Mere attainment does not suffice. So it is with the apprehension of materiality … (Mahāṭīkā, vol. 2, p. 357. The quotation continues on Burmese page 3.)


<a id="M04-body-P003"></a>
## Apprehending materiality as the basis for discerning mentality
Miến / Burmese 3

… The apprehension of materiality, once purified and cleared of impediments, serves as the basis and principal condition for apprehending mentality. Thus, when even a portion of the apprehension of materiality and mentality has yet to develop, there is no growth. This is all the clearer for someone in whom many portions remain undeveloped. Hence the text says “sace hi”, “for if”, and so on. (Mahāṭīkā, vol. 2, p. 357.) [The Latin transcription of the quotation continued from page 2 is pending, particularly the phrase just before eva arūpapariggahassa.]

If you take pure insight as your vehicle, first become one whose apprehension of materiality is thoroughly purified (suvisuddharūpapariggaha), that is, one who has clearly distinguished and apprehended material phenomena with wisdom. In the continuum of a being with all five aggregates, eye-, ear-, nose-, tongue- and body-sensitivity are the material bases on which the groups of mental phenomena called eye-, ear-, nose-, tongue- and body-consciousness arise in the regular course of events. The groups of mental phenomena called mind element and mind-consciousness element arise dependent on the heart-base, with the life-continuum, the clear mind-door, supporting the process.

Thus, if you cannot yet apprehend and discern the respective material bases on which those mental phenomena arise, and the life-continuum, the clear mind-door, you are still far from apprehending and distinguishing mental phenomena with wisdom to the level of ultimate reality and breaking up mental compactness.

Why? Only in the knowledge of a meditator who has thoroughly purified the apprehension of materiality do mental phenomena become evident by one or by all three of the ways of apprehending and discerning mentality described above. Therefore, thoroughly purify the apprehension of materiality …


<a id="M04-body-P004"></a>
## Apprehending materiality before mentality
Miến / Burmese 4

… and only when a meditator has apprehended materiality should they make an effort to apprehend mental phenomena. One who has yet to apprehend material phenomena thoroughly and clearly should refrain from attempting to apprehend mentality. If, when just one or two material phenomena have become evident to wisdom, one stops developing meditation on materiality and abandons apprehending materiality to undertake apprehension of mentality, one may regress and lose the meditation subject. (Visuddhimagga, vol. 2, p. 227, para. 671.)

The comparison is with a lower jhāna developed well enough to attain the five masteries. Only such a jhāna can serve as the foundation and closest cause for a higher jhāna. Mere attainment of a lower jhāna cannot serve as the foundation and proximate condition for a higher one. Likewise, only knowledge that apprehends materiality (rūpapariggahañāṇa) thoroughly and clearly, free from confusion and blemish, can be the foundation and closest cause for knowledge that apprehends mentality (arūpapariggahañāṇa). Until the former is purified, it cannot serve as that foundation and closest cause. Thus even if only a portion of material and mental phenomena fails to appear clearly to the meditator’s wisdom, that knowledge of apprehending materiality is still called unpurified. If many…


<a id="M04-body-P005"></a>
## The simile of the mountain cow
Miến / Burmese 5

… material and mental phenomena fail to appear clearly and are not seen by wisdom, what more need be said? The commentator spoke as above to make this meaning clear. (Mahāṭīkā, vol. 2, p. 357.)

In the Aṅguttara Nikāya (vol. 3, p. 216), the Buddha taught the Discourse on the Simile of the Cow (Gāvī-upamā Sutta). He spoke of a foolish, clumsy cow unskilled in grazing on rugged mountains. Looking out from a spot on the mountaintop, it saw a large lake of clear, cool water with lush grass and foliage around it. Intending to eat the tender grass and leaves and drink the clear, cool water, it descended. Before planting its front foot firmly, it lifted its hind foot. It tumbled down the mountain. It could neither eat the grass and leaves it had hoped for nor drink the water, and could not climb back to its former place.

Likewise, the Buddha taught that if a meditating bhikkhu attempts a higher jhāna before training to attain the five masteries over a lower jhāna, he may fail to reach the higher jhāna and fall away from the lower one already attained. (For details, see the Discourse on the Simile of the Cow.)


<a id="M04-body-P006"></a>
## Discerning mentality with tranquillity as the vehicle
Miến / Burmese 6

Using the same simile, the commentator warns that if one tries to apprehend the subject of mentality before thoroughly purifying one's apprehension of materiality, one may regress and lose the meditation subject. The hoped-for progress in mentality may fail to come, and the progress already made in materiality may be lost.

If you take tranquillity as your vehicle (samathayānika), the strength of jhāna concentration enables you to begin by apprehending the mental phenomena of jhāna, led by factors such as applied thought, sustained thought, joy, pleasure and one-pointedness. After apprehending them, continue with the heart-base on which they arise and the accompanying great elements and derived materiality. This is the instruction of the Visuddhimagga (vol. 2, p. 222). Then, when continuing to apprehend the five aggregates subject to clinging, called formations that have ripened (pakkasaṅkhāra), you must also apprehend sense-sphere mental phenomena. By that stage it is especially necessary to have apprehended the respective material bases. Therefore, when apprehending sense-sphere mental phenomena, the tranquillity practitioner should also take the guideline to heart and follow it, just as the pure-insight practitioner should.

If, without developing either of the two kinds of concentration, access or absorption, and without following the guideline above, you begin meditation on mentality…


<a id="M04-body-P007"></a>
## Two points to know beforehand
Miến / Burmese 7

… that is, attempt the meditation work of apprehending and discerning mental phenomena, you too might become one of those who use the number of a hundred thousand koṭis to challenge the Buddha’s teaching on mental phenomena.

Tassevaṃ pariggahitarūpassa dvāravasena arūpadhammā pākaṭā honti. (Visuddhimagga, vol. 2, p. 223.)
For one who has thus apprehended materiality, mental phenomena become evident by way of the doors.

Kāmaṃ vatthuvasenāpi arūpadhammā pākaṭā honti, dvāravasena pana pariggaho anākuloti katvā vuttaṃ “dvāravasena arūpadhammā pākaṭā hontī”ti. (Mahāṭīkā, vol. 2, pp. 352–353.)
Mental phenomena are also evident by way of their bases. Since apprehension by way of the doors is free of confusion, the text says, “mental phenomena become evident by way of the doors.”

In apprehending mental phenomena one may proceed by way of the material bases or by way of the doors classed as sense bases, as in the eye-door and ear-door processes. Of the two methods, the commentator explains that mental phenomena become evident by way of the doors classed as sense bases to a meditator who has thoroughly purified the apprehension of materiality. There is a reason for that instruction.

1. Mental phenomena arising dependent on the eye-base.
2. Mental phenomena arising dependent on the ear-base.
3. Mental phenomena arising dependent on the nose-base.


<a id="M04-body-P008"></a>
## Further explanation of bases and doors
Miến / Burmese 8

4. Mental phenomena arising dependent on the tongue-base.
5. Mental phenomena arising dependent on the body-base.
6. Mental phenomena arising dependent on the heart-base.

When mental phenomena are apprehended in this way by their supporting bases, there is overlap. By door, however, there are six groups: the mental phenomena of eye-door, ear-door, nose-door, tongue-door, body-door and mind-door processes.

Apprehending these groups by the doors classed as sense bases is free of confusion (anākula). The commentator therefore instructs one to apprehend mental phenomena by such doors, for example the group of mental phenomena in an eye-door process. (Visuddhimagga, vol. 2, p. 223; Mahāṭīkā, vol. 2, pp. 352–353.)

1. The mental group of eye-consciousness arises dependent on the eye-base.
2. The mental group of ear-consciousness arises dependent on the ear-base.
3. The mental group of nose-consciousness arises dependent on the nose-base.
4. The mental group of tongue-consciousness arises dependent on the tongue-base…


<a id="M04-body-P009"></a>
## Why apprehend mentality by door
Miến / Burmese 9

… 5. The mental group of body-consciousness arises dependent on the body-base.
6. The mental groups called mind element and mind-consciousness element arise dependent on the heart-base.

The respective mental groups dependent on the eye-, ear-, nose-, tongue- and body-bases do not overlap. The groups dependent on the heart-base, however, can take any of the six objects as appropriate, so there is overlap. For a clearer understanding, see the tables in the section on meditation on mentality. Consider also the classification by object:

1. Visible form: the mental phenomena in eye-door and mind-door processes that take visible form as object.
2. Sound: the mental phenomena in ear-door and mind-door processes that take sound as object.
3. Odour: the mental phenomena in nose-door and mind-door processes that take odour as object.
4. Taste: the mental phenomena in tongue-door and mind-door processes that take taste as object.
5. Tangible object: the mental phenomena in body-door and mind-door processes that take a tangible object.
6. Mind-object: the mental phenomena in mind-door processes that take a mind-object.

Thus apprehending mental phenomena by the doors classed as sense bases is free of confusion. That is why the commentator instructs one to apprehend mental phenomena by those doors…


<a id="M04-body-P010"></a>
## Two practical rules and the scope of mundane mentality
Miến / Burmese 10

… If you wish to apprehend mental phenomena, especially if you take pure insight as your vehicle, take these two rules to heart: (1) First apprehend material phenomena. (2) Apprehend mental phenomena by the doors classed as sense bases. Apply yourself so that you do not become one who uses the number of a hundred thousand koṭis to challenge the Buddha’s teaching on mental phenomena.

Āyatanadvāravasenāti āyatanasaṅkhātadvāravasena. Kammadvāranivattanatthaṃ āyatanaggahaṇaṃ. (Mahāṭīkā, vol. 2, p. 410.)
“By the doors classed as sense bases” means by doors called sense bases. “Sense bases” is specified to exclude the doors of action.

In the dispensation, “door” is used in two senses. The three doors of body, speech and mind are called doors of action (kammadvāra). The six doors of eye, ear, nose, tongue, body and mind are called doors classed as sense bases (āyatanadvāra). Apprehend mental phenomena by these doors and in the order of consciousnesses in the process, using wisdom to break up the compactness that makes mentality appear as a solid mass, so that wisdom reaches ultimate reality. (The four kinds of mental compactness will be presented later.)

Mundane mental phenomena only. Lokuttaracittāni pana neva suddhavipassakassa, na samathayānikassa pariggahaṃ gacchanti anadhigatattā. (Visuddhimagga, vol. 2, p. 223.)
Supramundane consciousnesses fall within the apprehension of neither the pure-insight practitioner nor the practitioner with tranquillity as vehicle at this stage, since they have yet to attain them.

In setting out the mental phenomena that are objects of insight knowledge, the Visuddhimagga says…


<a id="M04-body-P011"></a>
## Mundane consciousnesses within the scope of discernment
Miến / Burmese 11

Ekāsīti lokiyacittāni. (Visuddhimagga, vol. 2, p. 223.)
“Eighty-one mundane consciousnesses.” This indicates groups of mundane mental phenomena consisting of consciousness and mental factors. Since supramundane consciousness has yet to be attained, neither pure-insight practitioners nor those with tranquillity as vehicle can apprehend it. On this point the author of the Great Subcommentary explains as follows.

Sabbasaṅgāhikavasena “ekāsīti lokiyacittānī”ti vuttaṃ, lābhino eva pana mahaggatacittāni supākaṭāni honti. (Mahāṭīkā, vol. 2, p. 353.)
“Eighty-one mundane consciousnesses” is a comprehensive enumeration. Exalted consciousnesses become quite evident only to those who have attained them.

The statement that all eighty-one mundane consciousnesses and their associated phenomena are objects of insight knowledge is made by way of a comprehensive count of the consciousnesses that can be its objects. Exalted consciousnesses can become evident only to the knowledge of meditators who have attained jhāna. (Mahāṭīkā, vol. 2, p. 353.)

Only meditators who have attained jhāna can discern exalted consciousnesses. Thus, when apprehending mental phenomena, those who have attained jhāna should also apprehend and discern the mental phenomena of the jhāna they have attained. Pure-insight practitioners who have not attained jhāna may leave that discernment aside. Likewise, functional impulsions can arise only in the continuum of arahants. Thus when apprehending materiality and mentality or developing insight, worldlings and trainees may…


<a id="M04-body-P012"></a>
## What to know before discerning mentality
Miến / Burmese 12

… leave those functional impulsions aside.

Consciousness cannot arise on its own without mental factors. Mental factors likewise cannot arise on their own without consciousness. In each consciousness moment they arise together in groups. Therefore know beforehand the consciousnesses and mental factors you will apprehend and discern at the stage of insight.

Broadly, consciousness is of two kinds: consciousness in a cognitive process and consciousness outside a process (vīthimutta). The latter has three kinds: rebirth-linking, life-continuum and death consciousness. The first consciousness to arise in a life is rebirth-linking consciousness (paṭisandhicitta), since it links the previous life and the new life, and the aggregates of the two lives. The final consciousness to arise in a life is death consciousness (cuticitta), the life-continuum consciousness at departure from the present life. Between rebirth-linking and death, whenever process consciousnesses are absent, resultant consciousness of the same kind as rebirth-linking arises as a factor sustaining the continuity of the resultant aggregates and the stream of consciousness throughout that life, for as long as the kamma has power. It is called life-continuum consciousness (bhavaṅgacitta). It stops when process consciousnesses arise and arises repeatedly again when they cease. This occurs throughout a life. The mental phenomena accompanying life-continuum consciousness generally become accessible after one has apprehended process consciousnesses…


<a id="M04-body-P013"></a>
## The six bases and six doors
Miến / Burmese 13

… especially when they reach knowledge of apprehending conditions (paccayapariggahañāṇa). For this reason, a meditator wishing to apprehend mental phenomena should begin with the mental groups in the succession of process consciousnesses. Before apprehending mental phenomena in cognitive processes, one should know the following sets of six.

Six bases (vatthu), the material supports on which mental phenomena arise:
1. The eye-base (cakkhuvatthu) is eye-sensitivity (cakkhupasāda), the transparent materiality of the eye.
2. The ear-base (sotavatthu) is ear-sensitivity (sotapasāda), the transparent materiality of the ear.
3. The nose-base (ghānavatthu) is nose-sensitivity (ghānapasāda), the transparent materiality of the nose.
4. The tongue-base (jivhāvatthu) is tongue-sensitivity (jivhāpasāda), the transparent materiality of the tongue.
5. The body-base (kāyavatthu) is body-sensitivity (kāyapasāda), the transparent materiality of the body.
6. The heart-base (hadayavatthu) is heart materiality (hadayarūpa), the material support for the mind element and mind-consciousness element.

Six doors (dvāra):
1. The eye-door (cakkhudvāra) is eye-sensitivity.
2. The ear-door (sotadvāra) is ear-sensitivity.
3. The nose-door (ghānadvāra) is nose-sensitivity.
4. The tongue-door (jivhādvāra) is tongue-sensitivity.
5. The body-door (kāyadvāra) is body-sensitivity.
6. The mind-door (manodvāra) is the life-continuum (bhavaṅga), the clear mind.

An opening fitted to a house for people to enter and leave, which can be opened and closed, is literally a door. People cannot enter a house without a door. Just as a doorway is where people enter…


<a id="M04-body-P014"></a>
## Six objects and six kinds of mind-object
Miến / Burmese 14

… likewise, without eye-sensitivity and the other sensitivities, the consciousnesses of the eye-door process and the corresponding processes cannot arise. Eye-sensitivity and the other sensitivities within the body serve, as it were, as entrances for consciousnesses in their respective processes. By analogy with the ordinary doors fitted to a house, eye-sensitivity and the other sensitivities are called the eye-door and the corresponding doors.

Six objects:
1. Visible object (rūpārammaṇa) is colour (vaṇṇa).
2. Sound object (saddārammaṇa) is sound.
3. Odour object (gandhārammaṇa) is odour.
4. Taste object (rasārammaṇa) is taste.
5. Tangible object (phoṭṭhabbārammaṇa) is what can be touched: earth, fire and wind.
6. Mind-object (dhammārammaṇa) comprises phenomena that serve as objects of mind.

Six kinds of mind-object:
1. Sensitive materiality (pasādarūpa): the five kinds of transparent materiality.
2. Subtle materiality (sukhumarūpa): sixteen kinds of subtle materiality.
3. Consciousness (citta): the six consciousness elements.
4. Mental factors (cetasika): the fifty-two phenomena associated with consciousness.
5. Nibbāna: the unconditioned, the element of peace.
6. Concepts (paññatti): various concepts, such as kasiṇas, names and shapes.

Note. The twelve kinds of materiality comprising the five sensitivities and the seven kinds of objective materiality…


<a id="M04-body-P015"></a>
## The meaning of object and the first consciousness elements
Miến / Burmese 15

… readily become evident and are easily seen in the meditator’s knowledge when discerning. Being coarse, they are called gross materiality (oḷārikarūpa). Of the twenty-eight kinds of materiality, the sixteen remaining apart from the twelve gross kinds do not readily become evident to the knowledge of the meditator. Being subtle, they are called subtle materiality (sukhumarūpa).

Ārammaṇa and ālambana are synonymous terms for an object. Ārammaṇa means a place of delight. Just as a garden with flowers is a place of delight for people, the six objects, beginning with visible form, are places of delight for consciousness and mental factors. Thus they are called ārammaṇa. Ālambana means something to hold on to. Just as a person who is weak needs to hold on to a stick, a rope or some other support to get up or sit down, consciousness and mental factors can arise only by relying on and taking hold of an object. So the six objects are also called ālambana, what consciousness and mental factors rely on and take hold of.

Six consciousness elements:
1. Eye-consciousness arises dependent on eye-sensitivity and knows only visible form.
2. Ear-consciousness arises dependent on ear-sensitivity and knows only sound.
3. Nose-consciousness arises dependent on nose-sensitivity and knows only odour…


<a id="M04-body-P016"></a>
## The remaining consciousness elements and the six cognitive processes
Miến / Burmese 16

4. Tongue-consciousness arises dependent on tongue-sensitivity and knows only taste.
5. Body-consciousness arises dependent on body-sensitivity and knows only a tangible object.
6. Mind-consciousness arises dependent on the heart-base, with the life-continuum, the clear mind-door, supporting the process, and knows the six objects as appropriate.

Apart from the five pairs of consciousnesses under items 1–5, all consciousnesses arising dependent on the heart-base are termed mind-consciousness in the sense used here. They are consciousnesses that know objects in various ways. Except for the three kinds of consciousness outside a process, the remaining mind-consciousnesses, as well as the five kinds of sense consciousness above, arise in the fixed order of consciousness called a cognitive process (vīthi). In brief, there are six processes.

The six processes by door:
1. Eye-door process (cakkhudvāravīthi): the succession of consciousnesses arising at the eye-door.
2. Ear-door process (sotadvāravīthi): the succession arising at the ear-door.
3. Nose-door process (ghānadvāravīthi): the succession arising at the nose-door.
4. Tongue-door process (jivhādvāravīthi): the succession arising at the tongue-door.
5. Body-door process (kāyadvāravīthi): the succession arising at the body-door.
6. Mind-door process (manodvāravīthi): the succession arising at the mind-door.
These are reckoned by door. They may also be reckoned…


<a id="M04-body-P017"></a>
## Naming processes by consciousness and the order of their moments
Miến / Burmese 17

1. Eye-consciousness process (cakkhuviññāṇavīthi): the process named for eye-consciousness.
2. Ear-consciousness process (sotaviññāṇavīthi): the process named for ear-consciousness.
3. Nose-consciousness process (ghānaviññāṇavīthi): the process named for nose-consciousness.
4. Tongue-consciousness process (jivhāviññāṇavīthi): the process named for tongue-consciousness.
5. Body-consciousness process (kāyaviññāṇavīthi): the process named for body-consciousness.
6. Mind-consciousness process (manoviññāṇavīthi): the process named for mind-consciousness.

Thus there are also six processes reckoned by consciousness. When visible form appears at the eye-door, the succession of consciousnesses taking it as object is called the eye-door process. When sound appears at the ear-door, the succession taking that sound as object is called the ear-door process. Pe. When a mind-object appears at the mind-door, or when any of the six objects appears there as appropriate, the succession taking that object is called the mind-door process. The processes are also named for their consciousnesses, as follows.

1. Eye-door process: five-door adverting, eye-consciousness, receiving, investigating, determining, seven impulsion moments and two registration moments.
2. Ear-door process: five-door adverting, ear-consciousness, receiving, investigating, determining, seven impulsion moments and two registration moments.
3. Nose-door process: five-door adverting, nose-consciousness, receiving, investigating, determining, seven impulsion moments and two registration moments.


<a id="M04-body-P018"></a>
## Cognitive processes and the presentation of objects
Miến / Burmese 18

4. Tongue-door process: five-door adverting, tongue-consciousness, receiving, investigating, determining, seven impulsion moments and two registration moments.
5. Body-door process: five-door adverting, body-consciousness, receiving, investigating, determining, seven impulsion moments and two registration moments.
6. Mind-door process: mind-door adverting, seven impulsion moments and two registration moments.

The consciousnesses that distinguish these processes are those such as eye- and ear-consciousness. Five-door adverting, receiving and the like do not distinguish them. The process is therefore called the eye-consciousness process and so on, after its distinctive consciousness. The mind-door process has no such distinctive sense consciousness, since all its consciousnesses are mind-consciousness. Hence it is called the mind-consciousness process. Here a “process” means the arising of consciousnesses in sequence at the respective door, such as five-door adverting followed by eye-consciousness and the subsequent moments.

Six modes of presentation of objects (visayappavatti).
1. Very great object (atimahantārammaṇa): a very large number of consciousness moments can be counted from its appearance at the corresponding door to its cessation. This is the course with registration (tadārammaṇavāra).
2. Great object (mahantārammaṇa): many consciousness moments can be counted from its appearance at the corresponding door to its cessation. This is the course with impulsion (javanavāra).
3. Slight object (parittārammaṇa): few consciousness moments can be counted from its appearance at the corresponding door to its cessation. This is the course ending in determining (voṭṭhabbanavāra).


<a id="M04-body-P019"></a>
## The remaining modes of presentation and the objects of insight knowledge
Miến / Burmese 19

4. Very slight object (atiparittārammaṇa): very few consciousness moments can be counted from its appearance at the corresponding door to its cessation. (In the futile course, moghavāra, no process consciousness arises and only the life-continuum continues its function.) The four preceding kinds pertain to the five sense doors.
5. Clear object (vibhūtārammaṇa): an object that appears clearly. This is the course with registration.
6. Obscure object (avibhūtārammaṇa): an object that does not appear clearly. This is the course with impulsion. These two pertain to the mind-door.

There are thus six modes of presentation. These are the sets of six to know beforehand. If you wish to practise meditation on mentality, first learn the consciousnesses comprised in the six consciousness elements and their associated mental factors. We will begin with consciousnesses that can arise in your own continuum and can therefore serve as objects to discern and investigate in insight.

Types of consciousness that are objects of insight knowledge. The Buddha taught four ultimate realities: consciousness, mental factors, materiality and Nibbāna. If you wish to realize Nibbāna, the fourth ultimate reality, first strive to know consciousness, mental factors and materiality, the first three ultimate realities, together with dependent origination, the causal relationship through which consciousness, mental factors and materiality arise repeatedly…


<a id="M04-body-P020"></a>
## Consciousness and the kinds of unwholesome consciousness
Miến / Burmese 20

… Only when one can thoroughly discern in insight those consciousnesses, mental factors and material phenomena together with their conditions under the three characteristics can the knowledge of the noble path and fruition, arising at the culmination of mature insight, penetrate and see Nibbāna, the fourth ultimate reality. Of these ultimate realities, consciousness and mental factors are called mentality. We will now present the consciousnesses that are objects of insight knowledge.

Consciousness (citta) is the phenomenon capable of knowing an object. “Knowing” here means apprehending the object: “Vijānanaṃ ārammaṇassa upaladdhi.” (Mūlaṭīkā, vol. 1, p. 87.) When you can take eye-sensitivity as object at the level of ultimate reality, you are said to know eye-sensitivity. Until you can take eye-sensitivity as object, you cannot be said to know it. Understand the other cases in the same way.

Twelve unwholesome consciousnesses. There are four classes of consciousness: sense-sphere, fine-material-sphere, immaterial-sphere and supramundane. Among the fifty-four sense-sphere consciousnesses are the following twelve unwholesome consciousnesses.

Eight greed-rooted consciousnesses.
1. One consciousness accompanied by gladness (somanassa), associated with wrong view and unprompted.
2. One consciousness accompanied by gladness (somanassa), associated with wrong view and prompted.


<a id="M04-body-P021"></a>
## Greed-rooted and hatred-rooted consciousness
Miến / Burmese 21

3. One consciousness accompanied by equanimity, associated with wrong view, and unprompted.
4. One consciousness accompanied by equanimity, associated with wrong view, and prompted.
5. One consciousness accompanied by gladness, dissociated from wrong view, and unprompted.
6. One consciousness accompanied by gladness, dissociated from wrong view, and prompted.
7. One consciousness accompanied by equanimity, dissociated from wrong view, and unprompted.
8. One consciousness accompanied by equanimity, dissociated from wrong view, and prompted.

Thus there are eight greed-rooted consciousnesses.

Somanassasahagata: arising together with gladness.
Upekkhāsahagata: arising together with equanimity.
Diṭṭhigatasampayutta: associated with wrong acceptance, that is, wrong view.
Diṭṭhigatavippayutta: dissociated from wrong view.
Sasaṅkhārika: prompted, occurring with prompting.
Asaṅkhārika: unprompted, occurring without prompting.

Two hatred-rooted consciousnesses

1. One consciousness accompanied by displeasure, associated with aversion, and unprompted.
2. One consciousness accompanied by displeasure, associated with aversion, and prompted.

Domanassasahagata: arising together with displeasure, the unpleasant feeling of mind.
Paṭighasampayutta: associated with harshness and aggression of mind, that is, hatred.


<a id="M04-body-P022"></a>
## Delusion-rooted consciousness and rootless unwholesome resultants
Miến / Burmese 22

Two delusion-rooted consciousnesses

1. One consciousness accompanied by equanimity and associated with doubt.
2. One consciousness accompanied by equanimity and associated with restlessness.

Vicikicchāsampayutta: associated with doubt.
Uddhaccasampayutta: associated with restlessness, agitation of the mind.

1. Eight consciousnesses with greed as root.
2. Two consciousnesses with hatred as root.
3. Two consciousnesses with delusion as root.

Thus there are twelve unwholesome consciousnesses.

Eighteen rootless consciousnesses. Seven unwholesome-resultant consciousnesses

1. One unwholesome-resultant eye-consciousness accompanied by equanimity.
2. One unwholesome-resultant ear-consciousness accompanied by equanimity.
3. One unwholesome-resultant nose-consciousness accompanied by equanimity.
4. One unwholesome-resultant tongue-consciousness accompanied by equanimity.
5. One unwholesome-resultant body-consciousness accompanied by bodily pain.
6. One unwholesome-resultant receiving consciousness accompanied by equanimity.
7. One unwholesome-resultant investigating consciousness accompanied by equanimity.

Dukkhasahagata: arising together with bodily pain.
Sampaṭicchanacitta: consciousness that arises in the role of receiving the object.
Santīraṇacitta: consciousness that arises in the role of investigating the object.


<a id="M04-body-P023"></a>
## Rootless wholesome resultants and rootless functional consciousness
Miến / Burmese 23

These seven consciousnesses are results of past unwholesome kamma. They arise in your continuum when you encounter undesirable objects. Remember that encounters with the various undesirable objects in this life are due to past unwholesome kamma. This is a point to bear in mind.

Eight rootless wholesome-resultant consciousnesses

1. One rootless wholesome-resultant eye-consciousness accompanied by equanimity.
2. One rootless wholesome-resultant ear-consciousness accompanied by equanimity.
3. One rootless wholesome-resultant nose-consciousness accompanied by equanimity.
4. One rootless wholesome-resultant tongue-consciousness accompanied by equanimity.
5. One rootless wholesome-resultant body-consciousness accompanied by bodily pleasure.
6. One rootless wholesome-resultant receiving consciousness accompanied by equanimity.
7. One rootless wholesome-resultant investigating consciousness accompanied by gladness.
8. One rootless wholesome-resultant investigating consciousness accompanied by equanimity.

These eight consciousnesses are results of past wholesome kamma. They arise in your continuum through past wholesome kamma when you encounter desirable objects.
Sukhasahagata: arising together with bodily pleasure.

Three rootless functional consciousnesses

1. One five-door-adverting consciousness accompanied by equanimity.
2. One mind-door-adverting consciousness accompanied by equanimity.
3. One smile-producing consciousness accompanied by gladness.


<a id="M04-body-P024"></a>
## Eighteen rootless consciousnesses and beautiful sense-sphere consciousnesses
Miến / Burmese 24

Five-door adverting (pañcadvārāvajjana): consciousness that adverts to an object appearing at one of the five doors.
Mind-door adverting (manodvārāvajjana): consciousness that adverts to an object appearing at the mind-door.
Smile-producing consciousness (hasituppādacitta): consciousness that produces a smile in the continuum of arahants.

These three merely advert when a door encounters an object, or produce a smile. They have no power to produce a result, so they are called functional consciousnesses (kiriyacitta).

1. Seven unwholesome-resultant consciousnesses.
2. Eight rootless wholesome-resultant consciousnesses.
3. Three rootless functional consciousnesses.

These eighteen consciousnesses are associated with none of the roots greed, hatred, delusion, non-greed, non-hatred and non-delusion. Hence they are called rootless. The remaining consciousnesses, apart from the unwholesome and the rootless, are beautiful and are called beautiful consciousnesses (sobhanacitta). There are fifty-nine in the concise enumeration and ninety-one in the detailed enumeration.

Twenty-four beautiful sense-sphere consciousnesses. Eight great wholesome consciousnesses

1. One consciousness accompanied by gladness, associated with knowledge, and unprompted.
2. One consciousness accompanied by gladness, associated with knowledge, and prompted.
3. One consciousness accompanied by equanimity, associated with knowledge, and unprompted.


<a id="M04-body-P025"></a>
## Great wholesome and great resultant consciousnesses
Miến / Burmese 25

4. One consciousness accompanied by equanimity, associated with knowledge, and prompted.
5. One consciousness accompanied by gladness, dissociated from knowledge, and unprompted.
6. One consciousness accompanied by gladness, dissociated from knowledge, and prompted.
7. One consciousness accompanied by equanimity, dissociated from knowledge, and unprompted.
8. One consciousness accompanied by equanimity, dissociated from knowledge, and prompted.

These eight are wholesome sense-sphere consciousnesses. Generally they can produce favourable results in the eleven sense-sphere planes. In your continuum as a worldling, the consciousnesses developing tranquillity as far as access concentration and those developing insight before and after the noble path belong to this class of wholesome sense-sphere consciousness. Because their range is wide, they are also called great wholesome consciousnesses.

Eight great resultant consciousnesses

1. One consciousness accompanied by gladness, associated with knowledge, and unprompted.

Pe.
8. One consciousness accompanied by equanimity, dissociated from knowledge, and prompted.

They parallel the eight great wholesome consciousnesses, differing only in being resultant rather than wholesome. The eight great resultant consciousnesses are results of great wholesome kamma. One of them performs rebirth-linking, life-continuum and death in the continuum of a three-rooted or two-rooted worldling. During life, when various sense objects are encountered, all eight can perform registration, continuing to take the same object after sense-sphere impulsion, and…


<a id="M04-body-P026"></a>
## Great functional consciousnesses and the sense-sphere total
Miến / Burmese 26

… arise as appropriate in the continuum of beings in the sense sphere. Sense-sphere objects here are sense-sphere consciousness and mental factors and the twenty-eight kinds of materiality, when desirable and pleasing.

Eight great functional consciousnesses

1. One consciousness accompanied by gladness, associated with knowledge, and unprompted.

Pe.
8. One consciousness accompanied by equanimity, dissociated from knowledge, and prompted.

The great functional consciousnesses likewise have eight kinds corresponding to the great wholesome consciousnesses. They are the consciousnesses of arahants when giving, observing virtue, and developing tranquillity and insight. Here tranquillity extends to access concentration. The consciousnesses with which arahants practise giving, virtue, tranquillity and insight have no power to generate results, so they are called functional, merely performing their work.

The eight great wholesome, eight great resultant and eight great functional consciousnesses make twenty-four beautiful sense-sphere consciousnesses. They usually operate and arise in the sense sphere.

Twelve unwholesome, eighteen rootless, and twenty-four beautiful sense-sphere consciousnesses. Total: fifty-four. They are called sense-sphere consciousnesses because they arise mostly in the eleven sense-sphere planes. Sense-sphere mentality comprises these fifty-four consciousnesses…


<a id="M04-body-P027"></a>
## Sense-sphere objects of insight and five fine-material wholesome consciousnesses
Miến / Burmese 27

… and the fifty-two mental factors associated with them as appropriate. If you are a three-rooted worldling, the sense-sphere consciousnesses that can arise in your continuum and serve as objects of your insight knowledge are:

1. Twelve unwholesome consciousnesses.
2. Seventeen rootless consciousnesses, excluding smile-producing consciousness.
3. Eight great wholesome consciousnesses.
4. Eight great resultant consciousnesses.

Total: forty-five consciousnesses.

Fifteen fine-material-sphere consciousnesses. Five wholesome consciousnesses

1. Wholesome first jhāna consciousness arises with 5 factors: applied thought, sustained thought, joy, pleasure, one-pointedness.
2. Wholesome second jhāna consciousness arises with 4 factors: sustained thought, joy, pleasure, one-pointedness.
3. Wholesome third jhāna consciousness arises with 3 factors: joy, pleasure, one-pointedness.
4. Wholesome fourth jhāna consciousness arises with 2 factors: pleasure, one-pointedness.
5. Wholesome fifth jhāna consciousness arises with 2 factors: equanimity, one-pointedness.


<a id="M04-body-P028"></a>
## Fine-material consciousness and wholesome immaterial consciousnesses
Miến / Burmese 28

Thus there are five wholesome fine-material consciousnesses by the fivefold reckoning of jhāna. There are also five corresponding fine-material resultant consciousnesses. These arise only in the respective fine-material planes in the continuum of brahmās, performing rebirth-linking, life-continuum and death. Likewise, if arahants attain fine-material jhānas, these jhānas are called functional because they cannot produce a result. There are five fine-material functional consciousnesses. In all there are fifteen fine-material-sphere consciousnesses.

If you attain a wholesome fine-material jhāna, that jhāna is among the objects of your insight knowledge. If you attain all four fine-material jhānas by the fourfold reckoning or all five by the fivefold reckoning, all of them are among the objects of your insight knowledge.

Twelve immaterial-sphere consciousnesses. Four wholesome consciousnesses

1. Wholesome consciousness of the base of infinite space (ākāsānañcāyatana) takes the concept of unbounded space as object.
2. Wholesome consciousness of the base of infinite consciousness (viññāṇañcāyatana) takes the consciousness of the base of infinite space as object.
3. Wholesome consciousness of the base of nothingness (ākiñcaññāyatana) takes…


<a id="M04-body-P029"></a>
## Immaterial consciousness and the scope of discernment for jhāna attainments
Miến / Burmese 29

… the absence of the consciousness of the base of infinite space, the concept of absence (natthibhāvapaññatti), as object.

4. Wholesome consciousness of the base of neither perception nor non-perception (nevasaññānāsaññāyatana): it cannot be said to have perception or to be without perception. Clear, gross perception is absent, and only exceedingly subtle perception remains.

There are four wholesome immaterial-sphere consciousnesses. Their resultants are also of four kinds and arise only in the continuum of brahmās of the corresponding immaterial planes. If arahants attain the immaterial jhānas, those consciousnesses are called functional because they have no power to produce a result. The eight wholesome and resultant immaterial consciousnesses and the four functional immaterial consciousnesses make twelve. If you attain the immaterial jhānas, all four are also objects of your insight knowledge. Thus the maximum number of consciousnesses that can arise in your continuum and serve as objects of insight knowledge if you have attained jhāna is:

1. Forty-five sense-sphere consciousnesses.
2. Five wholesome fine-material jhāna consciousnesses by the fivefold reckoning.
3. Four wholesome immaterial jhāna consciousnesses.

Total: fifty-four consciousnesses. These are what sense-sphere worldlings and trainees who have attained jhāna use insight knowledge to…


<a id="M04-body-P030"></a>
## Eighty-one mundane and eight supramundane consciousnesses
Miến / Burmese 30

… discern. They are the phenomena that serve as objects of insight knowledge.

Reckoning comprehensively for worldlings, trainees and those beyond training in the sense, fine-material and immaterial realms, eighty-one mundane consciousnesses serve as objects of insight knowledge. They consist of fifty-four sense-sphere, fifteen fine-material and twelve immaterial-sphere consciousnesses. They are called mundane because they operate and arise in the world of thirty-one planes.

Eight supramundane consciousnesses in brief. Four noble path consciousnesses

1. Stream-entry path consciousness.
2. Once-return path consciousness.
3. Non-return path consciousness.
4. Arahantship path consciousness.

Thus there are four path consciousnesses.

Four noble fruition consciousnesses

1. Stream-entry fruition consciousness.
2. Once-return fruition consciousness.
3. Non-return fruition consciousness.
4. Arahantship fruition consciousness.

Thus there are four fruition consciousnesses. They are the resultants of the corresponding noble paths.


<a id="M04-body-P031"></a>
## Path, fruition and jhāna factors
Miến / Burmese 31

After apprehending the mundane mentality that can arise in your continuum, that is, consciousness and mental factors, and the material phenomena presented in the section on materiality, seek their conditions. When you thoroughly develop insight into mentality and materiality together with their conditions under the three characteristics, the knowledge of the noble path and fruition arises at the culmination of insight.

If one reaches a noble path while discerning sense-sphere mentality or material phenomena, that noble path and fruition are associated with first jhāna. (Abhidhamma Commentary, vol. 1, pp. 272–273.)

Lokuttaramaggo hi appanaṃ appatto nāma natthi, tasmā rūpaṃ sammasitvā vuṭṭhitassa aṭṭhaṅgiko somanassasahagatamaggo hoti. (Abhidhamma Commentary, vol. 1, p. 274.)
A supramundane path always reaches absorption. Thus, for one emerging after discerning materiality, the path has eight factors and is accompanied by gladness.

Thus when the noble path is reached by discerning sense-sphere mentality or materiality, there are eight path factors, seven awakening factors and five jhāna factors. These are factors of supramundane jhāna. This is called the supramundane path associated with first jhāna.

Forty supramundane consciousnesses in detail

1. If one reaches a noble path while discerning the mentality of first jhāna, that path and fruition are associated with first jhāna.


<a id="M04-body-P032"></a>
## Forty supramundane consciousnesses
Miến / Burmese 32

2. If one reaches a noble path while discerning the mentality of second jhāna, that path and fruition are associated with second jhāna.
3. If one reaches a noble path while discerning the mentality of third jhāna, that path and fruition are associated with third jhāna.
4. If one reaches a noble path while discerning the mentality of fourth jhāna, that path and fruition are associated with fourth jhāna.
5. If one reaches a noble path while discerning the mentality of fifth jhāna, that path and fruition are associated with fifth jhāna.

If one reaches the noble path while discerning sense-sphere mentality or materiality, the path and fruition are associated with first jhāna. Thus:

1. Five stream-entry path consciousnesses and five stream-entry fruition consciousnesses.
2. Five once-return path consciousnesses and five once-return fruition consciousnesses.
3. Five non-return path consciousnesses and five non-return fruition consciousnesses.
4. Five arahantship path consciousnesses and five arahantship fruition consciousnesses.

This gives forty supramundane consciousnesses in detail. In brief, eighty-one mundane and eight supramundane consciousnesses make eighty-nine, one short of ninety. In detail, eighty-one plus forty make one hundred and twenty-one by the fivefold reckoning of jhāna.


<a id="M04-body-P033"></a>
## Part 2. What to know about mental factors
Miến / Burmese 33

By its characteristic of knowing or apprehending an object, consciousness is of one kind. Yet because the mental factors arising with it in each moment vary, consciousness is classified into many kinds. Neither consciousness nor mental factors can arise separately from the other. At every moment they arise together in a group. The Great Subcommentary to the Visuddhimagga calls the group of consciousness and mental factors arising in one moment an immaterial group (arūpakalāpa), or mental group (nāmakalāpa). (Mahāṭīkā, vol. 2, p. 235.)

Four characteristics of mental factors associated with consciousness

1. Ekuppāda: arising together with consciousness.
2. Ekanirodha: ceasing together with consciousness.
3. Ekārammaṇa: taking the same object as consciousness.


<a id="M04-body-P034"></a>
## The fifty-two mental factors and the universals
Miến / Burmese 34

4. Ekavatthuka: sharing the same base as consciousness.

These are the four characteristics of association. When a mental factor is associated with consciousness in a sense or fine-material plane, all four are present. In the immaterial planes the shared base is absent because there is no material base. There are fifty-two mental factors.

1. Seven universals (sabbacittasādhāraṇa), common to all consciousnesses.
2. Six occasionals (pakiṇṇaka), associated only on certain occasions.
3. Fourteen unwholesome mental factors, associated with unwholesome consciousnesses.
4. Twenty-five beautiful mental factors, associated with beautiful consciousnesses.

Total: fifty-two mental factors.

Seven universals: mental factors associated with every consciousness

1. Contact (phassa): characterized by touching the object, with the function of bringing object and consciousness together.
2. Feeling (vedanā): experiencing the flavour of the object.


<a id="M04-body-P035"></a>
## The seven universal mental factors, continued
Miến / Burmese 35

3. Perception (saññā): marking the object.
4. Volition (cetanā): leading and urging the associated consciousness and mental factors toward the object.
5. One-pointedness (ekaggatā): convergence of consciousness on one object, steadiness, and keeping the associated phenomena from scattering.
6. Life faculty (jīvita): maintaining the associated consciousness and mental factors, the vitality of mentality.
7. Attention (manasikāra): directing and driving the associated phenomena toward the object, bringing the object to mind.

Note. Consciousness and the mental factors associated with it in a moment are called associated phenomena (sampayuttadhamma). Depending on the occasion and the strength of the mind’s steadiness, one-pointedness is also called the faculty of concentration, the power of concentration, the concentration awakening factor, right concentration, access concentration, absorption concentration, and so on. Notice also the mental factor of feeling. It is universal, associated with every consciousness. As long as there is consciousness, there is feeling. Feeling may be bodily pleasure, bodily pain, gladness, displeasure, or equanimity. A consciousness devoid of feeling, unassociated with feeling…


<a id="M04-body-P036"></a>
## The six occasional mental factors
Miến / Burmese 36

… cannot occur according to the Buddha’s teaching. Feeling ceases. The view that feeling ceases while the knowing consciousness does not is not the Buddhist view.

Six occasional mental factors (pakiṇṇaka), associated on certain occasions

1. Applied thought (vitakka): placing consciousness and its associates on the object, directing the mind to it.
2. Sustained thought (vicāra): examining the object repeatedly, continuing to hold it.
3. Decision (adhimokkha): making a decision regarding the object.
4. Energy (viriya): exertion, effort, and having the strength to press on.

Energy is the effort for the associated consciousness and mental factors to arise on an object. On the unwholesome side, there is effort toward greed, hatred and delusion, and so on. On the wholesome side, there is effort toward non-greed, non-hatred and non-delusion, and so on. In concentration there is effort to develop concentration. In insight there is effort to know the four great elements, materiality, mentality, their conditions, and the characteristics of impermanence, suffering and non-self of mentality and materiality together with those conditions.

5. Joy (pīti): delighting in the object.


<a id="M04-body-P037"></a>
## Desire and the distinction between applied thought, volition and attention
Miến / Burmese 37

6. Desire (chanda): wanting the object, wishing to act in relation to it.

According to the occasion, understand this as the wish for greed, hatred, delusion, non-greed, non-hatred, non-delusion, concentration or wisdom in relation to an object. Wishing to see, hear, smell, taste, touch or know is also wishing to act in relation to the object.

These six are associated with only some consciousnesses. As they accompany them on particular occasions, one or another as the case may be, they are called occasionals. The seven universals and six occasionals together are the thirteen ethically variable mental factors (aññasamāna). They are associated as appropriate with unwholesome and rootless consciousnesses, classed as non-beautiful, and with the fifty-nine beautiful consciousnesses in brief or ninety-one in detail. They are thus shared by both the wholesome and unwholesome sides.

Applied thought, volition and attention

Applied thought places the associated phenomena on the object. Volition brings into engagement with the object the associated phenomena that applied thought has placed there. Attention…


<a id="M04-body-P038"></a>
## The four unwholesome universals and the greed group
Miến / Burmese 38

… directs the associated phenomena straight toward the object, driving them toward it.

Fourteen unwholesome mental factors. Four unwholesome universals

1. Delusion (moha): not knowing the true nature of the object, knowing it wrongly.
2. Shamelessness (ahirika): absence of shame about misconduct or unwholesome states such as greed, hatred and delusion.
3. Moral recklessness (anottappa): absence of dread of misconduct or unwholesome states such as greed, hatred and delusion.
4. Restlessness (uddhacca): agitation and instability of mind regarding the object.

Since these four always accompany every unwholesome consciousness, they are called unwholesome universals.

Three mental factors in the greed group

5. Greed (lobha): taking an object as “mine”, craving it and clinging to it.
6. Wrong view (diṭṭhi): holding and believing the object to be permanent, pleasant, self, and beautiful. It is a mistaken view, a mistaken conviction.


<a id="M04-body-P039"></a>
## Conceit and ignorance
Miến / Burmese 39

7. Conceit (māna): the mind exalting itself, “I, I”, being proud and wanting to be superior.

Further explanation

Paramatthato avijjamānesu itthipurisādīsu javati, vijjamānesupi khandhādīsu na javatīti avijjā. (Abhidhamma Commentary, vol. 2, p. 127; Visuddhimagga, vol. 2, p. 157.)
Ignorance runs toward what does not exist ultimately, such as women and men, and does not run toward what does exist, such as the aggregates.

Delusion is also called ignorance. When one can analyse with the right view of insight the animate and inanimate world in the thirty-one planes down to ultimate reality, one knows that:

1. There are only groups of material phenomena.
2. There are only groups of mental phenomena.
3. There are only groups of mentality and materiality, the five aggregates, twelve bases or eighteen elements. This is correct knowledge, called knowledge of delimiting mentality and materiality.
4. There are only groups of causes and groups of effects. This is also correct knowledge, called knowledge of apprehending conditions.

Materiality, mentality, causes and effects are called conditioned phenomena. They are impermanent because they arise and cease, and suffering because arising and ceasing constantly oppress them. They are all non-self, since there is no solid, indestructible self that persists as a core…


<a id="M04-body-P040"></a>
## Correct knowing and mistaken knowing
Miến / Burmese 40

… They are also only unattractive phenomena, liable to arouse disenchantment. Thus it is correct to know those conditioned phenomena as only impermanent, suffering, non-self and unattractive. These are knowledges of insight.

If one knows animate and inanimate things in the thirty-one planes as groups of materiality, mentality, or mentality and materiality, that is, as the five aggregates, twelve bases or eighteen elements, as groups of causes and effects, or as groups of impermanent, suffering, non-self and unattractive phenomena, that knowing is correct knowing, right view or knowledge.

If, instead of knowing in accordance with their actual nature, one knows them as men, women, persons, beings, devas or brahmās, as a life, soul, consciousness or self, as gold, silver, trees, water, land, forests or mountains, or knows those animate and inanimate things in the contrary way as permanent, pleasant, self and beautiful, that mistaken knowing is called ignorance or delusion.

To clarify the difference between ignorance, or delusion, and wrong view, two kinds of clinging to self important in insight practice will be explained.


<a id="M04-body-P041"></a>
## Two kinds of clinging to self
Miến / Burmese 41

Broadly, there are two kinds of clinging to self: clinging based on ordinary worldly usage (lokavohāra), and clinging based on the view of self posited by proponents of wrong view outside the dispensation. (Majjhima Nikāya Subcommentary, vol. 1, pp. 365–366.)

1. Clinging to self by worldly convention: taking living things as men, women, persons, beings, devas, brahmās, buffaloes, cattle, animals and so on, and inanimate things as gold, silver, fields, gardens, houses, trees, water, land, forests, mountains and so on.

When you can apprehend external mentality and materiality, direct insight knowledge toward the external animate world. You will see for yourself by right view that what is called external living beings are only groups of materiality, mentality, mentality and materiality, causes, effects, impermanent, suffering, non-self and unattractive phenomena.

Direct insight knowledge also toward the external inanimate world. Use wisdom to discern the four great elements in external inanimate things such as gold and silver. On seeing minute material clusters, you will see only successive temperature-produced materiality due to fire, or temperature, in each cluster. Where there is sound, there are temperature-produced sound nonads. Thus if you know inanimate things as groups of temperature-produced materiality, or where there is sound…


<a id="M04-body-P042"></a>
## Clinging by convention and clinging by wrong view
Miến / Burmese 42

… as groups of temperature-produced sound nonads, that knowing is correct. If one knows them as gold, silver and so forth, that knowing is mistaken. It is ignorance, or delusion.

If one fails to know living beings as groups of materiality, mentality, causes and effects, the conditioned phenomena, or as groups of impermanent, suffering, non-self and unattractive phenomena, and knows them as men, women, persons, beings, devas and brahmās, that knowing is mistaken. It is ignorance or delusion. If one further clings to and believes that men, women, persons, beings, devas and brahmās truly exist just as they are conventionally called, that belief, clinging and mistaken conviction is conventional clinging to self, a wrong view.

Likewise, failure to know inanimate objects as groups of materiality and knowing them as gold, silver, diamonds or gems is mistaken knowing, ignorance. If one clings to, believes and accepts that gold, silver, diamonds and gems really exist as they are called in the world, that is clinging to self by worldly convention, a mistaken conviction and wrong view.

2. The view of self (attadiṭṭhi). Broadly, there are two kinds: (a) the view of a supreme self (paramattadiṭṭhi); (b) the view of a living self (jīvattadiṭṭhi).

(a) The supreme self: clinging to the idea of a creator self that creates the world and its beings…


<a id="M04-body-P043"></a>
## Distinguishing delusion from wrong view, and the hatred group
Miến / Burmese 43

… is the view of a supreme self.
(b) The view of a living self is the belief and clinging that each being’s continuum contains an enduring life, soul, consciousness or self.

Mistakenly knowing a supreme self or living self is ignorance, or delusion. Clinging, believing and mistakenly accepting that such selves actually exist is the view of self, a wrong view.

Distinguishing delusion from wrong view in brief

Delusion mistakenly knows animate and inanimate things in the thirty-one planes as permanent, pleasant, self and beautiful. Wrong view believes and mistakenly accepts them as permanent, pleasant, self and beautiful. That mistaken knowing is delusion. That mistaken view is wrong view.

Four mental factors in the hatred group

8. Hatred (dosa): harshness and roughness of mind, wishing to destroy.
9. Envy (issā): begrudging the property, standing and happiness of others, wishing to be the only one who excels.
10. Stinginess (macchariya): hiding one’s possessions, unwillingness to share them, meanness.


<a id="M04-body-P044"></a>
## Remorse, sloth, torpor and doubt
Miến / Burmese 44

11. Remorse (kukkucca): later distress over having done what is bad, unwholesome or misconduct, or over having omitted what is good, wholesome or good conduct.

Two mental factors in the prompted group

12. Sloth (thīna): sluggishness of consciousness, its lack of alertness and vigour.
13. Torpor (middha): sluggishness of the associated mental factors, their lack of alertness and vigour.

One mental factor in the delusion group

14. Doubt (vicikicchā), uncertainty concerning:
1. The genuine, fully awakened Buddha.
2. The genuine Dhamma of the fully awakened Buddha.
3. The genuine Saṅgha of noble disciples of the fully awakened Buddha.
4. The three trainings in virtue, concentration and wisdom.
5. Past life, the past aggregates, called the earlier end of saṃsāra.
6. Future life, the future aggregates, called the later end of saṃsāra.
7. Both past and future lives, the two ends of saṃsāra…


<a id="M04-body-P045"></a>
## Doubt and the beautiful mental factors
Miến / Burmese 45

… that is, both the past and future aggregates.
8. The connection of cause and effect, dependent origination.
Doubt is uncertainty regarding these eight subjects. (Abhidhamma, vol. 1, p. 208.)

Note. Doubt about kamma and its results is included in doubt about the connection of cause and effect, dependent origination.

Twenty-five beautiful mental factors

(a) Nineteen beautiful universals, common to all beautiful consciousnesses.
(b) Three abstinences.
(c) Two immeasurables.
(d) One faculty of wisdom.
Total: twenty-five.

Nineteen beautiful universal mental factors

1. Faith (saddhā): confidence and clarity regarding the eight subjects listed under doubt, that is, trust and conviction. Note. This is a general description. Distinguish the cases as follows:
1. Taking the qualities of the Buddha as object, confidence in those qualities.
2. Taking the qualities of the Dhamma as object, confidence in those qualities.


<a id="M04-body-P046"></a>
## Faith, mindfulness, moral shame, moral dread and non-greed
Miến / Burmese 46

3. Taking the qualities of the Saṅgha as object, confidence in those qualities.
4. In virtue, confidence in the training in virtue. In concentration, confidence in training in jhāna concentration. In wisdom, confidence in training to penetrate the actual nature of ultimate mentality and materiality, and in training to penetrate the four truths.
5. When discerning the past, confidence regarding the past aggregates.
6. When discerning the future, confidence regarding the future aggregates.
7. When discerning both past and future, confidence regarding both sets of aggregates.
8. When discerning the link of cause and effect, dependent origination, confidence in the actual nature of that connection.

Understand in this way how confidence varies according to the object discerned.

2. Mindfulness (sati): on an object where mindfulness is established, such as the four establishments of mindfulness, it causes the associated phenomena to sink like a stone instead of floating like a gourd. The mind stands firmly on the object and does not forget it.
3. Moral shame (hiri): shame regarding unwholesome acts and misconduct.
4. Moral dread (ottappa): dread regarding unwholesome acts and misconduct.
5. Non-greed (alobha): the mind does not cling to or crave mundane objects…


<a id="M04-body-P047"></a>
## The beautiful universals, continued
Miến / Burmese 47

… and does not take them as “mine”.

6. Non-hatred (adosa): absence of harshness or roughness toward the object, and absence of the wish to destroy.
7. Mental balance (tatramajjhattatā): keeping the mind balanced on its object, without falling into conceit or shrinking through sloth and torpor, so that consciousness and mental factors are neither excessive nor deficient in their functions, and attend to the object evenly.
8. Tranquillity of the mental body (kāyapassaddhi): tranquillity of the mental factors.
9. Tranquillity of consciousness (cittapassaddhi): tranquillity of consciousness.
10. Lightness of the mental body (kāyalahutā): agility and lightness of the mental factors.
11. Lightness of consciousness (cittalahutā): agility and lightness of consciousness.
12. Malleability of the mental body (kāyamudutā): pliancy of the mental factors.
13. Malleability of consciousness (cittamudutā): pliancy of consciousness.
14. Wieldiness of the mental body (kāyakammaññatā): fitness of the mental factors for giving, virtue, meditation and so on, and their smooth functioning. In meditation, discernment proceeds smoothly.
15. Wieldiness of consciousness (cittakammaññatā): fitness of consciousness for giving, virtue, meditation and so on, and its smooth functioning. In meditation, discernment proceeds smoothly.
16. Proficiency of the mental body (kāyapāguññatā): in giving, virtue, meditation and similar wholesome activities…


<a id="M04-body-P048"></a>
## Proficiency, rectitude and two kinds of deceit
Miến / Burmese 48

… the mental factors are well trained and skilful, free from the disease of defilements.

17. Proficiency of consciousness (cittapāguññatā): in giving, virtue, meditation and so on, consciousness is well trained and skilful, free from the disease of defilements.
18. Rectitude of the mental body (kāyujukatā): straightness of the mental factors, free from the crookedness of concealment and deceit.
19. Rectitude of consciousness (cittujukatā): straightness of consciousness, free from the crookedness of concealment and deceit.

Māyā and sāṭheyya

Santadosapaṭicchādanalakkhaṇā māyā. Asantaguṇasambhāvanalakkhaṇaṃ sāṭheyyaṃ. (Mahāṭīkā, vol. 1, p. 84.)
Asantaguṇappakāsanalakkhaṇaṃ sāṭheyyaṃ. (Mahāṭīkā, vol. 1, p. 128.)
Concealing a fault that is actually present is māyā. Parading or boasting of qualities one does not have is sāṭheyya.


<a id="M04-body-P049"></a>
## Abstinences, immeasurables and the faculty of wisdom
Miến / Burmese 49

Three abstinences (virati)

1. Right speech: abstaining from the four kinds of verbal misconduct unrelated to livelihood, refraining from verbal misconduct.
2. Right action: abstaining from the three kinds of bodily misconduct unrelated to livelihood, refraining from bodily misconduct.
3. Right livelihood: abstaining from the four kinds of verbal and the three kinds of bodily misconduct connected with livelihood, refraining from such bodily and verbal misconduct.

Two immeasurables (appamaññā)

1. Compassion (karuṇā): taking suffering beings as object, feeling compassion and wishing to rescue them from distress.
2. Appreciative joy (muditā): taking happy beings as object, rejoicing with them and not begrudging their prosperity.

One faculty of wisdom (paññindriya)

1. The faculty of wisdom, or wisdom: penetrating the actual nature of ultimate phenomena…


<a id="M04-body-P050"></a>
## The faculty of wisdom and an important guideline
Miến / Burmese 50

… penetrating the four truths. Wisdom, also called knowledge, non-delusion, right view or investigation of phenomena, is called a faculty because it predominates in knowing the four truths.

This completes the twenty-five beautiful mental factors. A beginner distinguishing and apprehending ultimate phenomena with wisdom may start by attending to the individual characteristic or the function. Hence for some mental factors both characteristic and function have been given.

An important guideline

Idhekacco āditova ajjhattaṃ pañcasu khandhesu abhinivisati. Abhinivisitvā te aniccādito passati. Yasmā pana na suddhaajjhattadassanamatteneva maggavuṭṭhānaṃ hoti, bahiddhāpi daṭṭhabbameva. Tasmā parassa khandhepi anupādinnasaṅkhārepi “aniccaṃ dukkhamanattā”ti passati. So kālena ajjhattaṃ sammasati, kālena bahiddhāti.
One practitioner first enters into discernment of the five aggregates internally. Having done so, one sees them as impermanent and so on. Since path knowledge does not arise through seeing only internally, one also discerns the aggregates of others and unappropriated formations externally as impermanent, suffering and non-self. One discerns at times internally and at times externally. (Abhidhamma Commentary, vol. 1, p. 270.)

Aparo āditova rūpe abhinivisati. Abhinivisitvā bhūtarūpañca upādārūpañca paricchinditvā aniccādito passati. Yasmā pana na suddharūpadassanamatteneva vuṭṭhānaṃ hoti, arūpampi daṭṭhabbameva. Tasmā taṃ rūpaṃ ārammaṇaṃ katvā uppannaṃ vedanaṃ saññaṃ saṅkhāre viññāṇañca “idaṃ arūpan”ti paricchinditvā aniccādito passati. So kālena rūpaṃ sammasati kālena arūpaṃ.
Another first enters into discernment of materiality. Having done so, one distinguishes the great elements and derived materiality and sees them as impermanent and so on. Since path knowledge does not arise through seeing only materiality, one takes materiality as object, distinguishes the four mental aggregates arising on that object as mentality, and sees them as impermanent and so on. One discerns at times materiality and at times mentality. (Abhidhamma Commentary, vol. 1, p. 271.)


<a id="M04-body-P051"></a>
## Discerning internally and externally, materiality and mentality
Miến / Burmese 51

The meaning of the commentary above is as follows. Once a meditator has attained knowledge of distinguishing mentality and materiality and knowledge of apprehending conditions, they may begin insight by discerning the five aggregates internally. They may also begin with the five aggregates externally, including inanimate formations not appropriated by kamma. But discerning only the internal aggregates or only the external aggregates cannot give rise to insight leading to emergence (vuṭṭhānagāminīvipassanā), which leads directly from conditioned objects to Nibbāna and the noble path. Therefore discern the five aggregates at times internally and at times externally under the three characteristics.

Likewise, insight leading to emergence cannot arise if one discerns only materiality or only mentality. At times distinguish with wisdom the great elements and derived materiality at the ultimate level and discern them under the three characteristics. At times distinguish the four mental aggregates, feeling, perception, formations and consciousness, arising with that materiality as object, and discern them under the three characteristics. This is the meaning of the commentary and agrees with the Aparijānana Sutta and similar discourses in the Saṃyutta Nikāya (vol. 2, pp. 249–250).


<a id="M04-body-P052"></a>
## The four contemplations and the scope of discernment
Miến / Burmese 52

Whether in the internal or external continuum, discerning only materiality or only mentality cannot lead to the noble path. One must therefore discern both. Countless groups of materiality and mentality arise and cease over a lifetime. They cannot all be discerned individually by number, but all types must be discerned.

The meaning is this. When the material phenomena arising concurrently in the body are seen with wisdom, the material clusters appear as tiny particles. All four great elements occur in these clusters, which are many times smaller than a speck of dust. Disciples cannot discern each element in every cluster. They can discern only some (kesāci), a portion. The same applies to derived materiality.

In the very short time of a blink, a flash of lightning or a finger snap, mental phenomena can arise in hundreds of thousands of koṭis of consciousness moments. Over a lifetime their number is incalculable. Disciples cannot discern all of them, only a portion. Yet although they cannot discern them exhaustively by number…


<a id="M04-body-P053"></a>
## Discerning all types and the four establishments of mindfulness
Miến / Burmese 53

… they must discern all kinds of material clusters, that is, all types of materiality, as listed in the tables in the section on materiality. They must likewise discern all six kinds of cognitive process, beginning with the eye-door process. Countless eye-door processes know visible objects in a lifetime. One cannot discern every occurrence, only a portion. Understand the same of the ear-door and remaining processes. The commentators accordingly explain:

1. Kāyānupassanāmukhena: through contemplation of the body as the entry.
2. Vedanānupassanāmukhena: through contemplation of feeling as the entry.
3. Cittānupassanāmukhena: through contemplation of consciousness as the entry.
4. Dhammānupassanāmukhena: through contemplation of phenomena as the entry.

(See Majjhima Nikāya Commentary, vol. 1, p. 245.) Understand the four contemplations as follows.

1. If one takes materiality as primary, apprehends materiality, mentality, causes and effects, the conditioned phenomena, and discerns them in insight, that comes under the establishment of mindfulness in contemplation of the body. In particular, pure-insight practitioners enter insight through the four great elements, taking materiality as primary when apprehending conditioned phenomena, so their contemplation generally falls under this establishment of mindfulness.
2. Of the three ways of beginning meditation on mentality, if one takes feeling as primary, apprehends materiality, mentality, causes and effects, the conditioned phenomena, and discerns them in insight, that comes under the establishment of mindfulness in contemplation of feeling.


<a id="M04-body-P054"></a>
## Entrances to mindfulness and how the tranquillity practitioner begins
Miến / Burmese 54

3. If one takes knowing consciousness as primary, apprehends materiality, mentality, causes and effects, the conditioned phenomena, and discerns them in insight, that comes under the establishment of mindfulness in contemplation of consciousness.
4. If one takes contact as primary, apprehends materiality, mentality, causes and effects, the conditioned phenomena, and discerns them in insight, that comes under the establishment of mindfulness in contemplation of phenomena. Discernment by the five aggregates, twelve bases, eighteen elements and so forth also comes under this establishment of mindfulness. (See Abhidhamma Commentary, vol. 2, p. 273.)

Of the three ways of apprehending mentality, beginning with feeling to apprehend and discern conditioned phenomena is contemplation of feeling. Beginning with knowing consciousness is contemplation of consciousness. Beginning with contact is contemplation of phenomena.

When moving on to purification of view, one who takes tranquillity as the vehicle may begin practice with either mentality or materiality. If beginning with mentality, first apprehend the jhāna factors and the phenomena associated with jhāna. Then apprehend the heart-base as their support, together with the great elements and derived materiality. (See Visuddhimagga, vol. 2, p. 222.) Then continue to apprehend the sense-sphere mental phenomena called ripened formations and the remaining material phenomena…


<a id="M04-body-P055"></a>
## Beginning the apprehension of mentality with feeling
Miến / Burmese 55

… Likewise, the pure-insight practitioner must continue with sense-sphere mental phenomena after practising the materiality meditation subject. Both the tranquillity-vehicle and pure-insight practitioners, when wishing to apprehend sense-sphere mentality, must first develop and apprehend materiality, following the instruction below and the Visuddhimagga commentary cited on Burmese pages 2–4:

Pariggahite rūpakammaṭṭhāne — when the meditation subject of materiality has been apprehended. (Majjhima Nikāya Commentary, vol. 1, p. 280.)
Tasmiṃ ārammaṇe — on that object. (Majjhima Nikāya Commentary, vol. 1, p. 280.)

Tasmā taṃ rūpaṃ ārammaṇaṃ katvā uppannaṃ vedanaṃ saññaṃ saṅkhāre viññāṇañca “idaṃ arūpan”ti paricchinditvā aniccādito passati. (Abhidhamma Commentary, vol. 1, p. 271.)
Thus one delimits feeling, perception, formations and consciousness that arise taking that materiality as object as “this is mentality”, and sees them as impermanent and so on.

In accordance with that guideline, begin with the mental phenomena that arise taking those very material phenomena as object. When apprehending them, take particular care to follow the guidelines below.

Guideline for beginning with feeling

Yassa vedanā pākaṭā hoti, so “na kevalaṃ vedanāva uppajjati. Tāya saddhiṃ tadevārammaṇaṃ phusamāno phassopi uppajjati, sañjānanamānā saññāpi, cetayamānā cetanāpi, vijānanamānaṃ viññāṇampi uppajjatī”ti phassapañcamakeyeva pariggaṇhāti. (Dīgha Nikāya Commentary, vol. 2, p. 314; Majjhima Nikāya Commentary, vol. 1, p. 280; Abhidhamma Commentary, vol. 2, p. 252.)


<a id="M04-body-P056"></a>
## Apprehending the five when beginning with feeling or consciousness
Miến / Burmese 56

One to whom feeling is prominent should attend thus: “Feeling does not arise alone. Contact touching that very object also arises with it. Perception marking that object arises. Volition leading and urging the associated phenomena toward that object arises. Consciousness distinguishing or knowing that object also arises.” Apprehend the five phenomena with contact as the fifth (phassapañcamaka). (Dīgha Nikāya Commentary, vol. 2, p. 314; Majjhima Nikāya Commentary, vol. 1, p. 280; Abhidhamma Commentary, vol. 2, p. 252.)

Guideline for beginning with consciousness

Yassa viññāṇaṃ pākaṭaṃ hoti, so “na kevalaṃ viññāṇameva uppajjati. Tena saddhiṃ tadevārammaṇaṃ phusamāno phassopi uppajjati, anubhavamānā vedanāpi, sañjānanamānā saññāpi, cetayamānā cetanāpi uppajjatī”ti phassapañcamakeyeva pariggaṇhāti. (Dīgha Nikāya Commentary, vol. 2, p. 314; Majjhima Nikāya Commentary, vol. 1, pp. 280–281; Abhidhamma Commentary, vol. 2, p. 252.)

One to whom knowing consciousness is prominent should attend thus: “Consciousness does not arise alone. Contact touching that very object also arises with it. Feeling experiencing the flavour of that object arises. Perception marking it arises. Volition leading and urging the associated phenomena toward it also arises.” Apprehend the five phenomena with contact as the fifth…


<a id="M04-body-P057"></a>
## Beginning with contact and apprehending all mental phenomena
Miến / Burmese 57

… those very phenomena. (Dīgha Nikāya Commentary, vol. 2, p. 314; Majjhima Nikāya Commentary, vol. 1, pp. 280–281; Abhidhamma Commentary, vol. 2, p. 252.)

Guideline for beginning with contact

Yassa phasso pākaṭo hoti, so “na kevalaṃ phassova uppajjati. Tena saddhiṃ tadevārammaṇaṃ anubhavamānā vedanāpi uppajjati, sañjānanamānā saññāpi, cetayamānā cetanāpi, vijānanamānaṃ viññāṇampi uppajjatī”ti phassapañcamakeyeva pariggaṇhāti. (Dīgha Nikāya Commentary, vol. 2, p. 314; Majjhima Nikāya Commentary, vol. 1, p. 280; Abhidhamma Commentary, vol. 2, p. 252.)

One to whom contact is prominent should attend thus: “Contact does not arise alone. Feeling experiencing that very object, tasting its flavour, also arises with it. Perception marking the object arises. Volition leading and urging the associated phenomena toward that object arises. Consciousness distinguishing or knowing that object also arises.” Apprehend the five phenomena with contact as the fifth. (Dīgha Nikāya Commentary, vol. 2, p. 314; Majjhima Nikāya Commentary, vol. 1, p. 280; Abhidhamma Commentary, vol. 2, p. 252.)

Apprehend all mental phenomena

Evaṃ tassa tasseva pākaṭabhāvepi “sabbaṃ, bhikkhave, abhiññeyyan”ti, “sabbañca kho, bhikkhave, abhijānan”ti ca evamādivacanato sabbe sammasanupagā dhammā pariggahetabbāti dassento “tattha yassā”tiādimāha. Tattha phassapañcamakeyevāti avadhāraṇaṃ tadantogadhattā taggahaṇeneva gahitattā catunnaṃ arūpakkhandhānaṃ. Phassapañcamakaggahaṇaṃ…
Although these phenomena become evident to the meditator in those ways, the Blessed One taught, “Bhikkhus, all is to be directly known,” and “Bhikkhus, when directly knowing all…”. Therefore all associated phenomena should be apprehended. To make this clear, the explanation begins with “Tattha yassa”. Where it names only the five with contact as the fifth, it is an exposition by way of the principal phenomena, since those phenomena embrace the four mental aggregates…


<a id="M04-body-P058"></a>
## Why the five with contact as the fifth are named
Miến / Burmese 58

… hi tassa sabbacittuppādasādhāraṇabhāvato, tattha ca phassacetanāggahaṇena sabbasaṅkhārakkhandhadhammasaṅgaho cetanāpadhānattā tesaṃ. Tathā hi suttantabhājanīye saṅkhārakkhandhavibhaṅge “cakkhusamphassajā cetanā”tiādinā cetanāva vibhattā, itare pana khandhā sarūpeneva gahitā.
… Of these, contact and volition belong to the formations aggregate. Among the associated phenomena, the formations aggregate may be presented by way of volition, since volition is foremost among them. In the sutta method of presenting the formations aggregate, as in the six classes of volition beginning with volition concerning visible form, volition alone is named. The other aggregates are presented under their own names. (Majjhima Nikāya Subcommentary, vol. 1, p. 370.)

Even though contact, feeling or knowing consciousness is more prominent for different meditators when they begin the subject of mentality, the Buddha himself taught:

Sabbaṃ, bhikkhave, abhiññeyyaṃ. — Bhikkhus, all is to be directly known. (Saṃyutta Nikāya, vol. 2, p. 258; Khuddaka Nikāya, vol. 9, p. 6.)
Sabbañca kho, bhikkhave, abhijānaṃ. — And, bhikkhus, when directly knowing all… (Saṃyutta Nikāya, vol. 2, p. 250.)

He taught that one should endeavour to distinguish and know all conditioned phenomena called the truth of suffering and the truth of its origin by the three kinds of full understanding. To show that the meditator must distinguish with wisdom all actual phenomena suitable for discerning under the three characteristics, the commentator set out the foregoing method of apprehending mentality.

The commentary’s instruction to apprehend the five with contact as fifth is a way of naming the principal phenomena. In the mental group of a single consciousness moment there are other mental phenomena besides those five. Since the other phenomena of the four mental aggregates are also present…


<a id="M04-body-P059"></a>
## Apprehending all associated phenomena
Miến / Burmese 59

… naming the five with contact as the fifth also comprises the four mental aggregates. That is why the commentary says to apprehend those five. They are named because they are common to all consciousnesses. Of the five, contact and volition belong to the formations aggregate. In that aggregate, volition is predominant. Therefore when instructed to apprehend contact and volition, one should apprehend those two principal phenomena together with the remaining associated phenomena belonging to the formations aggregate. Naming contact and volition embraces all the actual phenomena in the formations aggregate, because volition is predominant there. The Buddha himself also makes volition primary in analysing the formations aggregate in the sutta analysis of the Vibhaṅga (Abhidhamma, vol. 2, p. 37). This is an established principle. The remaining aggregates are named and taught directly. (Majjhima Nikāya Subcommentary, vol. 1, p. 370.)

Under the guideline established in the texts, commentaries and subcommentaries, especially for a meditator wishing to apprehend sense-sphere mentality, after apprehending the subject of materiality, whether beginning with contact, feeling or knowing consciousness, apprehending mental phenomena within a consciousness moment is not a matter of taking only one contact, one feeling or one knowing consciousness…


<a id="M04-body-P060"></a>
## A very difficult undertaking
Miến / Burmese 60

… then stubbornly holding to it like a frog clinging tightly, straining for minutes, hours, days, months or years, repeatedly apprehending and discerning that one phenomenon alone. All the phenomena associated with that contact, feeling or consciousness must also be apprehended and discerned. Good friends should put clear, upright wise attention first and receive and remember the instruction accordingly.

A very difficult undertaking

It is difficult to use wisdom to break up the compactness that makes consciousness and mental factors arising according to the order of consciousness look like a solid mass, and to apprehend and discern them to the level of ultimate reality. Disciples nevertheless can apprehend and discern them. Some misunderstand the words of the Questions of King Milinda and thus say that disciples cannot discern those mental phenomena. To clear up the doubt, the explanations of the Saṃyutta Commentary and the Aṭṭhasālinī and the words of the Questions of King Milinda are given below.

Yathā hi tilatelaṃ sāsapatelaṃ madhukatelaṃ eraṇḍakatelaṃ vasātelanti imāni pañca telāni ekacāṭiyaṃ pakkhipitvā divasaṃ yamakamanthehi manthetvā tato “idaṃ tilatelaṃ, idaṃ sāsapatelan”ti ekekassa pāṭiyekkaṃ uddharaṇaṃ nāma dukkaraṃ, idaṃ tato dukkarataraṃ. Bhagavā pana sabbaññutaññāṇassa suppaṭividdhattā dhammissaro dhammarājā imesaṃ arūpīnaṃ dhammānaṃ ekārammaṇe vattamānānaṃ vavatthānaṃ…
Suppose five oils, sesame, mustard, madhuka, castor and animal fat, are poured together in one vessel and stirred all day. It is difficult to separate them and declare, “This is sesame oil, this is mustard oil.” Still more difficult is what the Blessed One, the All-knowing, Master and King of the Dhamma, accomplished in distinguishing immaterial phenomena operating on one object…


<a id="M04-body-P061"></a>
## The similes of mixed oils and the waters of five rivers
Miến / Burmese 61

… akāsi. Pañcannaṃ mahānadīnaṃ samuddaṃ paviṭṭhānaṃ “idaṃ gaṅgāya udakaṃ, idaṃ yamunāyā”ti evaṃ pāṭiyekkaṃ udakuddharaṇenāpi ayamattho veditabbo.
… Understand this meaning also from the simile of the water in the ocean into which five great rivers flow. It is difficult to distinguish and say, “This is water from the Gaṅgā, this is water from the Yamunā,” and so on. (Saṃyutta Nikāya Commentary, vol. 2, p. 271.)

Imesañca pana phassapañcamakānaṃ dhammānaṃ pāṭiyekkaṃ pāṭiyekkaṃ vinibbhogaṃ katvā paññattiuddharaṇena bhagavatā dukkaraṃ kataṃ. Nānāudakānañhi nānātelānaṃ vā ekabhājane pakkhipitvā divasaṃ nimadditānaṃ vaṇṇagandharasānaṃ nānatāya disvā vā ghāyitvā vā sāyitvā vā nānākaraṇaṃ sakkā bhaveyya ñātuṃ. Evaṃ santampi taṃ dukkaraṃ vuttaṃ. Sammāsambuddhena pana imesaṃ arūpīnaṃ cittacetasikānaṃ dhammānaṃ ekārammaṇe vattamānānaṃ pāṭiyekkaṃ pāṭiyekkaṃ vinibbhogaṃ katvā paññattiuddharaṇena atidukkaraṃ kataṃ. Tenāha āyasmā Nāgasenatthero:
The Blessed One accomplished a difficult task when he analysed the five with contact as the fifth and named each separately. If waters and oils of different colours, odours and flavours are mixed together in one vessel and stirred throughout the day, their differences in colour, smell and taste can still be distinguished to some extent by looking, smelling or tasting. Thus the distinction of mental phenomena is called difficult. The Fully Awakened One did what is more difficult in analysing and naming each immaterial consciousness and mental factor operating on one object. Hence Venerable Nāgasena said:

Dukkaraṃ, mahārāja, bhagavatā katanti. Kiṃ, bhante Nāgasena, bhagavatā dukkaraṃ katanti? Dukkaraṃ, mahārāja, bhagavatā kataṃ, yaṃ imesaṃ arūpīnaṃ cittacetasikānaṃ dhammānaṃ ekārammaṇe pavattamānānaṃ vavatthānaṃ akkhātaṃ: “ayaṃ phasso, ayaṃ vedanā, ayaṃ saññā, ayaṃ cetanā, idaṃ cittan”ti. Opammaṃ, bhante, karohīti.
“Great king, the Blessed One did something difficult.”
“Venerable Nāgasena, what difficult thing did the Blessed One do?”
“Great king, the Blessed One did something difficult. He distinguished the immaterial consciousness and mental factors operating on one object: ‘This is contact, this is feeling, this is perception, this is volition, this is consciousness.’”
“Give me a simile, venerable sir.”

Yathā, mahārāja, kocideva puriso nāvāya samuddaṃ ajjhogāhetvā hatthapuṭena udakaṃ gahetvā jivhāya sāyitvā jāneyya nu kho, mahārāja, so puriso “idaṃ gaṅgāya udakaṃ, idaṃ yamunāya udakaṃ, idaṃ aciravatiyā udakaṃ, idaṃ sarabhuyā udakaṃ, idaṃ mahiyā udakan”ti? Dukkaraṃ, bhante, jānitunti.
“Great king, suppose a man went out into the ocean in a boat, scooped up water in his cupped hand, and tasted it with his tongue. Could he know, ‘This is water from the Gaṅgā, this from the Yamunā, this from the Aciravatī, this from the Sarabhū, this from the Mahī’?”
“It would be difficult to know, venerable sir.”


<a id="M04-body-P062"></a>
## The meaning of the simile for distinguishing mentality
Miến / Burmese 62

Tato dukkarataraṃ kho, mahārāja, bhagavatā kataṃ, yaṃ imesaṃ arūpīnaṃ cittacetasikānaṃ dhammānaṃ, pe, “idaṃ cittan”ti.
“Great king, the Blessed One did what is more difficult than that in distinguishing those immaterial consciousness and mental factors: pe, ‘this is consciousness’.” (Abhidhamma Commentary, vol. 1, pp. 186–187; Milindapañha, p. 94.)

The meaning of the Pāli text and commentaries above is as follows. When distinguishing and apprehending mental phenomena with wisdom, or discerning and investigating them in insight, for every moment of process-free consciousness, namely rebirth-linking, life-continuum and death, and every moment of process consciousness arising in its fixed order, one must apprehend and discern the mental phenomena headed by the five with contact as the fifth. This has already been explained.

Within each consciousness moment, the Buddha distinguished each of the five with contact as the fifth and set out their names as contact, feeling, perception, volition and consciousness. In distinguishing them in this way, he accomplished a difficult task. The following simile makes it clear.

Suppose waters differing in colour, odour and taste are placed in one pot and stirred diligently all day. Or suppose oils and fats differing in flavour, such as ghee, sesame oil, mustard oil, peanut oil, chicken fat and pork fat, are put in one large pan and stirred diligently from morning to evening.


<a id="M04-body-P063"></a>
## Material phenomena in mixed waters and oils
Miến / Burmese 63

Even when different waters or oils have been mixed in the same vessel and stirred all day, their colours, odours and flavours remain distinct. By looking with the eye, smelling with the nose or tasting with the tongue, one may still recognize something of the differences between them.

Note. Material phenomena arise only as tiny particles called material clusters. Water and oil are collections of clusters in which the nature and power of the water element predominate. The material phenomena in one cluster and those in another are separated by the space element, so they do not merge or associate. One with the eye of wisdom that sees ultimate reality can analyse, know and apprehend colour, odour and flavour within each cluster. Because this can be apprehended with wisdom, someone with knowledge of ultimate reality, even if unable to use ordinary eye-, nose- or tongue-sensitivity to tell apart the colours, odours and flavours of waters or oils mixed in one vessel and stirred all day, may still use the eye, nose and tongue of wisdom to recognize those differences within the waters or oils…


<a id="M04-body-P064"></a>
## The Buddha’s distinction of individual mental phenomena
Miến / Burmese 64

… this is the point of the explanation. Though such recognition may still be possible, Venerable Nāgasena says in the Questions of King Milinda that distinguishing mental phenomena is difficult. The Fully Awakened Buddha, endowed with six excellences, had penetrated with omniscient knowledge and was truly King of the Dhamma, master of the teaching. Thus, for each consciousness and mental factor in the groups of mentality arising together and taking one object, he distinguished each separately by his knowledge and taught by assigning names: “This is contact, this is feeling, this is perception, this is volition, this is consciousness.” In teaching the Dhamma by setting out these distinct names, the Buddha performed a very difficult task.

The point. For example, in one mind-door moment of great wholesome impulsion of knowledge distinguishing mentality and materiality, or of insight knowledge apprehending and distinguishing materiality, there are thirty-four mental phenomena, consciousness and mental factors, when both knowledge and joy are present. They arise together, cease together, share the same material support, the heart-base, and take one and the same object, the materiality being discerned. Were there no Fully Awakened Buddha endowed with omniscience, the teaching that distinguishes each by name, such as “this nature is contact, this nature…


<a id="M04-body-P065"></a>
## The dialogue between Nāgasena and King Milinda
Miến / Burmese 65

… is feeling”, so that disciples can use wisdom to distinguish and know them through names such as contact and feeling, could not arise by any worldly means in the past, present or succeeding aeons. To clarify that meaning for King Milinda, the renowned Venerable Nāgasena used the simile of waters from five great rivers flowing into the ocean and spoke as follows.

“King Milinda, the Buddha accomplished a very difficult task.”
“Venerable Nāgasena, what very difficult task did the Buddha accomplish?”
“King Milinda, consciousness and mental factors are mental phenomena that arise together and take one object. The Buddha distinguished them as follows:

1. The phenomenon that touches this object is contact.
2. The phenomenon that experiences the flavour of this object is feeling.
3. The phenomenon that marks this object is perception.
4. The phenomenon that leads the associated phenomena to this object is volition.
5. The phenomenon that apprehends, that is, knows this object, is consciousness.

By setting out these names, he distinguished each mental phenomenon that exists ultimately…


<a id="M04-body-P066"></a>
## The simile of tasting seawater
Miến / Burmese 66

… and taught them in this way. In distinguishing and teaching each phenomenon, he accomplished a very difficult task.
“Venerable sir, please give a simile.”

“King Milinda, suppose a man goes out to sea by boat, scoops up water with his cupped hand and tastes it with his tongue. Could he know: (1) This is water from the Gaṅgā, (2) this from the Yamunā, (3) this from the Aciravatī, (4) this from the Sarabhū, (5) this from the Mahī?”
“Venerable Nāgasena, it would be difficult to know.”

“King Milinda, consciousness and mental factors are mental phenomena that arise together on one object. He taught: (1) What touches this object is contact. Pe. (5) What apprehends, that is, knows this object, is consciousness. By setting out these names he distinguished and taught each ultimately existing mental phenomenon. In distinguishing and teaching them in this way…


<a id="M04-body-P067"></a>
## The difficult task accomplished by the Buddha
Miến / Burmese 67

… the Buddha accomplished a very difficult task.” (Milindapañha, p. 94.)

The meaning of the text and commentary above is this. In a single moment, consciousness and mental factors, which are ultimate phenomena, arise together taking one object. It is very difficult to distinguish each with knowledge, give it a name and teach “this is contact, this is feeling,” and so on. That is the point of the quotation. Disciples can still discern the mental phenomena in a single moment of consciousness. Understand this carefully. A mistaken understanding can lead to mistaken practice, so take particular care when applying it.

Notice again the passage from the Aṭṭhasālinī quoted above.

Sammāsambuddhena pana imesaṃ arūpīnaṃ cittacetasikānaṃ dhammānaṃ ekārammaṇe vattamānānaṃ pāṭiyekkaṃ pāṭiyekkaṃ vinibbhogaṃ katvā paññattiuddharaṇena atidukkaraṃ kataṃ.
The Fully Awakened Buddha accomplished something exceedingly difficult by distinguishing individually these immaterial consciousnesses and mental factors operating on one object and assigning their names. (Abhidhamma Commentary, vol. 1, p. 186.)

In each consciousness moment taking one object, the Fully Awakened Buddha distinguished with omniscient knowledge each mental phenomenon, consciousness or mental factor: “This is contact, this is feeling, this is perception, this is volition…


<a id="M04-body-P068"></a>
## Apprehend base and object together
Miến / Burmese 68

… this is consciousness.” The explanation stresses the great difficulty of naming and teaching each phenomenon in that way. That is the point to remember.

An established principle to follow carefully when apprehending mentality is to apprehend base and object together. Venerable Sāriputta followed this principle. Take his discernment of the mentality of first jhāna as an example. The Buddha described it as follows:

Tyāssa dhammā anupadavavatthitā honti. Tyāssa dhammā viditā uppajjanti, viditā upaṭṭhahanti, viditā abbhatthaṃ gacchanti. So evaṃ pajānāti: “Evaṃ kirame dhammā ahutvā sambhonti, hutvā paṭiventī”ti.
He distinguished the phenomena one by one in sequence. He knew them as they arose, as they were present and as they disappeared. He understood: “These phenomena, not having been, come to be. Having come to be, they vanish.” (Majjhima Nikāya, vol. 3, p. 75.)

Venerable Sāriputta knew each mental phenomenon of first jhāna individually in sequence. The jhāna mentality was evident to his knowledge as it arose, was present and ceased. In other words, he knew clearly its arising, presence…


<a id="M04-body-P069"></a>
## How Venerable Sāriputta discerned the mentality of jhāna
Miến / Burmese 69

… and cessation. He knew clearly: “These mental phenomena of jhāna were not previously present and have now arisen afresh. Having arisen, they always quickly cease.” (Majjhima Nikāya, vol. 3, p. 75.)

From first jhāna through the base of nothingness, he discerned the jhāna mental phenomena individually in sequence, by insight into each successive phenomenon (anupadadhamma-vipassanā). For the base of neither perception nor non-perception he grouped the jhāna mentality and discerned it collectively (kalāpasammasana). (Majjhima Nikāya Commentary, vol. 4, p. 61.) When discerning each phenomenon, he knew its arising, presence and cessation clearly. The commentary explains why.

Vatthārammaṇānaṃ pariggahitattāya. Therena hi vatthu ceva ārammaṇañca pariggahitaṃ. Tenassa tesaṃ dhammānaṃ uppādaṃ āvajjentassa uppādo pākaṭo hoti, ṭhānaṃ āvajjentassa ṭhānaṃ pākaṭaṃ hoti, vayaṃ āvajjentassa vayo pākaṭo hoti. Tena vuttaṃ “viditā uppajjanti, viditā upaṭṭhahanti, viditā abbhatthaṃ gacchantī”ti.
Because base and object had been apprehended. The elder had apprehended both. When he adverted to the arising of those phenomena, their arising was evident. When he adverted to their presence, it was evident. When he adverted to their dissolution, it was evident. Hence they were said to be known as they arose, were present and disappeared. (Majjhima Nikāya Commentary, vol. 4, p. 60.)

The subcommentary explains that the bases and objects had already been apprehended with knowledge, including the jhāna phenomena occurring on that object. Pe. These are the phenomena of the attainment process. (Majjhima Nikāya Subcommentary, vol. 3, p. 278.) Venerable Sāriputta was able to discern in this way because he had apprehended base and object together…


<a id="M04-body-P070"></a>
## The base and object to apprehend first
Miến / Burmese 70

… Before apprehending each mental phenomenon in a jhāna process, Venerable Sāriputta had apprehended both the supporting base, including the life-continuum mind-door at which those phenomena arise, and the corresponding jhāna object, such as the counterpart sign of breathing or of a kasiṇa. Thus when he attended to the arising, presence or cessation of the mentality in the process, each phase became evident to his knowledge. That is why the Buddha said he knew it when it arose, was present and ceased. (Majjhima Nikāya Commentary, vol. 4, p. 60.)

Note. In the instruction to apprehend base and object together, “base” refers to the six doors: eye, ear, nose, tongue, body and mind.

For good friends wishing to practise meditation on mentality, this principle is as precious as a priceless gem. Develop meditation on mentality. But if base and object are not apprehended together, such a meditator…


<a id="M04-body-P071"></a>
## Return to apprehending materiality
Miến / Burmese 71

… sits with their back turned to the Buddha’s teaching. They will likely use the number of a hundred thousand koṭis to challenge the practice of mentality taught by the Buddha.

As explained above, a meditator wishing to apprehend the mentality headed by the five with contact as the fifth must first apprehend materiality, especially the material base and material object. After apprehending that mentality, one is instructed to return to materiality as follows.

So ime phassapañcamakā kiṃnissitāti upadhārento “vatthunissitā”ti pajānāti. Vatthu nāma karajakāyo, yaṃ sandhāya vuttaṃ “idañca me viññāṇaṃ ettha sitaṃ ettha paṭibaddhan”ti. So atthato bhūtānicceva upādārūpāni ca.
Considering what supports the five with contact as fifth, one knows that they depend on a base. The base is the material body (karajakāya), as in the statement, “This consciousness of mine depends on this and is bound to this.” In actual terms that body consists of the great elements and derived materiality. (Majjhima Nikāya Commentary, vol. 1, p. 281; Abhidhamma Commentary, vol. 2, pp. 252–253.)

The subcommentary explains that to delimit mentality and materiality, materiality must be apprehended without omission. Thus it says “the base is the material body”. In presenting the material body as the support, it quotes, “This consciousness of mine depends on this and is bound to this.” (Mūlaṭīkā, vol. 2, p. 157.)

The meditator who has apprehended the mentality headed by the five with contact as fifth should investigate with wisdom: “Dependent on what do these mental phenomena arise?”…


<a id="M04-body-P072"></a>
## The material body as the support
Miến / Burmese 72

… On investigating, one knows clearly that they arise dependent on a material base. The base is the material body. Regarding this body the Buddha taught: “This consciousness of mine is dependent on this material body and bound to it.” (Dīgha Nikāya, vol. 1, p. 72; Majjhima Nikāya, vol. 2, p. 209.) In actual phenomena, the material body comprises the great elements and derived materiality. (Dīgha Nikāya Commentary, vol. 2, pp. 314–315; Majjhima Nikāya Commentary, vol. 1, p. 281; Abhidhamma Commentary, vol. 2, pp. 252–253.)

“There is no person, being, life, self, deva or brahmā, only mentality and materiality.” To attain knowledge delimiting mentality and materiality in that way, one must apprehend materiality without omission. Thus the commentary says “the base is the material body”. Here it includes the great elements and derived materiality present at the same location or door as the bases, all fifty-four or forty-four kinds of materiality at the corresponding door. To show that all the great elements and derived materiality of the material body constitute the support, the subcommentary quotes the Sāmaññaphala Sutta (Dīgha Nikāya, vol. 1, p. 72) and the Mahāsakuludāyi Sutta (Majjhima Nikāya, vol. 2, p. 209). (Mūlaṭīkā, vol. 2, p. 157.)

These are some guidelines for meditators wishing to apprehend mentality. Other guidelines…


<a id="M04-body-P073"></a>
## From the guidelines to the cognitive processes
Miến / Burmese 73

… will be explained as the occasion arises. In apprehending mental phenomena there are six processes, beginning with the eye-door process. As the mind-door process has fewer process consciousnesses, the method will first be presented starting with the mind-door process. The Visuddhimagga instructs the tranquillity-vehicle practitioner to begin with the mind-door process of absorption impulsion (vol. 2, p. 222). Therefore the apprehension of jhāna mentality in the attainment process is presented first.

Note. Mental phenomena in eye-door and mind-door processes taking visible form are called the visible-object track. Likewise, those in ear-door and mind-door processes taking sound form the sound track, those in nose-door and mind-door processes taking odour the odour track, those in tongue-door and mind-door processes taking taste the taste track, and those in body-door and mind-door processes taking a tangible object the tangible track. Mental phenomena in a mind-door process taking a mind-object, or any member of that class, form the mind-object track.


<a id="M04-body-P074"></a>
## Part 3. Jhāna attainment with the breathing counterpart sign
Miến / Burmese 74

Breathing counterpart sign · Mind-object track · Mind-door jhāna attainment
Attainment | M | P | U | A | G | J · repeated jhāna impulsions
Heart-base materiality | 54 | 54 | 54 | 54 | 54 | 54
First jhāna | 12 | 34 | 34 | 34 | 34 | 34 …
Second jhāna | 12 | 34 | 34 | 34 | 34 | 32 … (applied and sustained thought fall away)
Third jhāna | 12 | 34 | 34 | 34 | 34 | 31 … (joy also falls away)
Fourth jhāna | 12 | 33 | 33 | 33 | 33 | 31 … (equanimity replaces pleasure)

If you have developed the ten kasiṇas and attained the eight attainments, continue apprehending their mental phenomena in accordance with the following table.


<a id="M04-body-P075"></a>
## Jhāna attainment with a kasiṇa counterpart sign
Miến / Burmese 75

Kasiṇa counterpart sign · Mind-object track · Mind-door jhāna attainment
Attainment | M | P | U | A | G | J · repeated jhāna impulsions
Heart-base materiality | 54 | 54 | 54 | 54 | 54 | 54
First jhāna | 12 | 34 | 34 | 34 | 34 | 34 …
Second jhāna | 12 | 34 | 34 | 34 | 34 | 32 … (applied and sustained thought fall away)
Third jhāna | 12 | 34 | 34 | 34 | 34 | 31 … (joy also falls away)
Fourth jhāna | 12 | 33 | 33 | 33 | 33 | 31 … (equanimity replaces pleasure)
Base of infinite space | 12 | 33 | 33 | 33 | 33 | 31 … (equanimity and one-pointedness)
Base of infinite consciousness | 〃 | 〃 | 〃 | 〃 | 〃 | 〃
Base of nothingness | 〃 | 〃 | 〃 | 〃 | 〃 | 〃
Base of neither perception nor non-perception | 〃 | 〃 | 〃 | 〃 | 〃 | 〃

Applied thought, sustained thought and joy. The stilling of applied and sustained thought is the surmounting of those two. Because both have subsided, the second jhāna is without them. (Visuddhimagga, vol. 1, p. 151.)
In the preliminary stage the sense-sphere consciousnesses are accompanied by applied thought, sustained thought and joy… (Abhidhamma Commentary, vol. 2, p. 237.) According to these explanations…


<a id="M04-body-P076"></a>
## Jhāna factors at access and absorption
Miến / Burmese 76

… applied thought, sustained thought and joy are still associated with the sense-sphere access impulsions, such as preparation and access. Only in the absorption consciousnesses of second jhāna onward are applied and sustained thought absent, according to the fourfold reckoning. In the case of fourth jhāna, joy is also absent from the sense-sphere access impulsions. The Visuddhimagga explains this as follows.

Pleasant feeling cannot serve as repetition condition for neither-painful-nor-pleasant feeling. Since fourth jhāna must arise with neither-painful-nor-pleasant feeling, those consciousnesses are associated with equanimity. Because of association with equanimity, joy also falls away. (Visuddhimagga, vol. 1, p. 160.) “Those consciousnesses” refers to the absorption consciousnesses and their related moments in that process. (Mahāṭīkā, vol. 1, p. 189.)

This is the distinction. Since pleasant feeling cannot condition equanimous feeling by repetition, the four or five sense-sphere access impulsions and the absorption impulsions in a fourth-jhāna process are accompanied by equanimity. As these impulsions in the fourth-jhāna process are accompanied by equanimity, joy is also absent. (Visuddhimagga, vol. 1, p. 160; Mahāṭīkā, vol. 1, p. 189.)


<a id="M04-body-P077"></a>
## Four divine abidings · Jhāna attainment tables
Miến / Burmese 77

Loving-kindness (divine abiding)
Attainment | M | P | U | A | G | J · repeated jhāna impulsions
Heart-base materiality | 54 | 54 | 54 | 54 | 54 | 54
First jhāna | 12 | 34 | 34 | 34 | 34 | 34 …
Second jhāna | 12 | 34 | 34 | 34 | 34 | 32 … (applied and sustained thought fall away)
Third jhāna | 12 | 34 | 34 | 34 | 34 | 31 … (joy also falls away)

Compassion (divine abiding)
Attainment | M | P | U | A | G | J · repeated jhāna impulsions
Heart-base materiality | 54 | 54 | 54 | 54 | 54 | 54
First jhāna | 12 | 35 | 35 | 35 | 35 | 35 …
Second jhāna | 12 | 35 | 35 | 35 | 35 | 33 … (applied and sustained thought fall away)
Third jhāna | 12 | 35 | 35 | 35 | 35 | 32 … (joy also falls away)

Appreciative joy (divine abiding)
Attainment | M | P | U | A | G | J · repeated jhāna impulsions
Heart-base materiality | 54 | 54 | 54 | 54 | 54 | 54
First jhāna | 12 | 35 | 35 | 35 | 35 | 35 …
Second jhāna | 12 | 35 | 35 | 35 | 35 | 33 … (applied and sustained thought fall away)
Third jhāna | 12 | 35 | 35 | 35 | 35 | 32 … (joy also falls away)

Equanimity (divine abiding)
Attainment | M | P | U | A | G | J · repeated jhāna impulsions
Heart-base materiality | 54 | 54 | 54 | 54 | 54 | 54
Fourth jhāna | 12 | 33 | 33 | 33 | 33 | 31 …


<a id="M04-body-P078"></a>
## Only for those who have attained jhāna
Miến / Burmese 78

If you have developed the skeleton or foulness subject to absorption, apprehend the mentality of first jhāna on the skeleton attended to as repulsive, and on the foulness subject, as in the first-jhāna row of the attainment tables with the breathing or kasiṇa counterpart sign. The tables above suffice for apprehending the mentality called jhāna phenomena.

Lābhino eva pana mahaggatacittāni supākaṭāni honti.
Exalted consciousnesses are very evident only to those who have attained them. (Mahāṭīkā, vol. 2, p. 353.) Thus only those who have attained jhāna apprehend and discern its mentality. Pure-insight practitioners without jhāna leave this part aside.

Both those who have apprehended jhāna mentality and pure-insight practitioners without jhāna should continue with sense-sphere mentality. As the Visuddhimagga says, “Evaṃ chasu dvāresu arūpassa nibbatti passitabbā”, apprehend and discern so that wisdom sees the arising of mentality at the six doors. (Vol. 2, p. 253.)


<a id="M04-body-P079"></a>
## Process abbreviations and beginning to apprehend jhāna
Miến / Burmese 79

Names of the process consciousnesses in the tables above:

M — mind-door adverting: adverts to or determines the jhāna object, such as the breathing counterpart sign.
P — preparation (parikamma): a great wholesome sense-sphere impulsion preparing for jhāna impulsion.
U — access (upacāra): a great wholesome impulsion arising close to jhāna impulsion.
A — conformity (anuloma): a great wholesome impulsion conforming to the arising of jhāna impulsion.
G — change-of-lineage (gotrabhū): a great wholesome impulsion crossing out of the sense-sphere lineage.
J — jhāna impulsion: fine-material or immaterial wholesome impulsion.

When apprehending the mentality in the first-jhāna attainment process shown above, meditators know the impulsions occurring in the modes of preparation, access, conformity and change-of-lineage, rather than knowing the conventional names. For worldlings and trainees, those impulsions…


<a id="M04-body-P080"></a>
## Training to apprehend jhāna mentality
Miến / Burmese 80

… are great wholesome impulsions. For arahants they are great functional impulsions. In one of keen understanding there are just three access impulsions: access, conformity and change-of-lineage.

A beginner in meditation on mentality who wishes to apprehend jhāna mentality should enter the jhāna to be apprehended. After emerging, apprehend together the clear life-continuum mind-door and the jhāna object, such as the breathing counterpart sign. Begin with the jhāna factors. Repeat the exercise many times. When the tranquillity sign, such as the breathing counterpart sign, appears at the life-continuum mind-door, use wisdom to see, apprehend and distinguish the factors arising together in each successive jhāna impulsion moment. Once successful through repetition, one may begin with knowing consciousness, feeling, or contact.

Choose one of the three ways and increase the number one mental phenomenon at a time until all the jhāna factors and associated phenomena are apprehended with wisdom in each moment. First enter jhāna and, as soon as you emerge, practise seeing one jhāna mental phenomenon over many moments. Enter again and on emerging practise seeing two over many moments. Continue entering and emerging in this way…


<a id="M04-body-P081"></a>
## Thirty-four first-jhāna mental phenomena with the breathing counterpart sign
Miến / Burmese 81

… increasing by one jhāna mental phenomenon at a time. Those with a strong grounding in Abhidhamma and keen understanding may apprehend them this way. Those with less grounding and slower understanding can find it very difficult to grasp their nature. For their sake the 34 first-jhāna mental phenomena that arise taking the breathing counterpart sign as object are set out again below.

The group of factors such as applied thought is called jhāna. The consciousness and mental factors associated with it are called phenomena associated with jhāna. Discern the jhāna and the associated phenomena by characteristic, function, manifestation and proximate cause (Visuddhimagga, vol. 2, p. 222).

1. Knowing consciousness (citta) — apprehending the breathing counterpart sign as object. “Vijānanaṃ ārammaṇassa upaladdhi” (Mūlaṭīkā, vol. 1, p. 87).

2. Contact (phassa) — has the characteristic of touching the breathing counterpart sign. Its function is to connect knowing consciousness with that object.
Note: “object” for the mental factors listed below also means the breathing counterpart sign.


<a id="M04-body-P082"></a>
## First-jhāna mental phenomena from feeling to joy
Miến / Burmese 82

3. Feeling (vedanā) — experiencing the flavour of the object pleasantly and gladly. In first jhāna this is joyful feeling (somanassavedanā).
4. Perception (saññā) — marking the object.
5. Volition (cetanā) — prompting and urging the associated phenomena towards the object.
6. One-pointedness (ekaggatā) — the mind resting on one object, standing firm and keeping the associated phenomena from scattering.
7. Life faculty (jīvita) — maintaining the associated phenomena.
8. Attention (manasikāra) — directing and driving the mind and associated phenomena towards the object, bringing the object to mind.

9. Applied thought (vitakka) — placing the mind and associated phenomena on the object, also having the nature of thinking.
10. Sustained thought (vicāra) — repeatedly examining, rubbing against and taking hold of the object.
11. Decision (adhimokkha) — deciding with respect to the object.
12. Energy (viriya) — striving to know the object, that is, for the associated phenomena to arise, and supporting them in reaching the object.
13. Joy (pīti) — delighting in the object.


<a id="M04-body-P083"></a>
## First-jhāna mental phenomena from desire to lightness of the mental body
Miến / Burmese 83

14. Desire (chanda) — wishing to know the object, that is, wishing the associated phenomena to arise.
15. Faith (saddhā) — confidence in the practice of jhāna concentration.
16. Mindfulness (sati) — making associated phenomena sink into the object like a stone instead of floating like a gourd. It does not forget the object and keeps the mind on it.
17. Moral shame (hiri) — shame at evil, unwholesome phenomena and misconduct.
18. Moral dread (ottappa) — fear of evil, unwholesome phenomena and misconduct.

19. Non-greed (alobha) — not clinging or being attached to the object, and not appropriating it as “mine”.
20. Non-hatred (adosa) — the mind is neither harsh nor fierce towards the object and does not wish to destroy it.
21. Specific neutrality (tatramajjhattatā) — keeping the mind balanced on the meditation object so it neither becomes elated through conceit nor sinks through sloth and torpor. It remains equanimous towards the object.
22. Tranquillity of the mental body (kāyapassaddhi) — the mental factors are tranquil on the object.
23. Tranquillity of consciousness (cittapassaddhi) — consciousness is tranquil on the object.
24. Lightness of the mental body (kāyalahutā) — the mental factors are quick and light on the object.


<a id="M04-body-P084"></a>
## First-jhāna mental phenomena from lightness of consciousness to wisdom
Miến / Burmese 84

25. Lightness of consciousness (cittalahutā) — consciousness is quick and light on the object.
26. Malleability of the mental body (kāyamudutā) — the mental factors are pliant on the object.
27. Malleability of consciousness (cittamudutā) — consciousness is pliant on the object.
28. Wieldiness of the mental body (kāyakammaññatā) — the mental factors are workable, suitable and serviceable on the object.
29. Wieldiness of consciousness (cittakammaññatā) — consciousness is workable, suitable and serviceable on the object.

30. Proficiency of the mental body (kāyapāguññatā) — the mental factors are adept, readily trained and free of the sickness of defilements.
31. Proficiency of consciousness (cittapāguññatā) — consciousness is adept, readily trained and free of the sickness of defilements.
32. Rectitude of the mental body (kāyujukatā) — the mental factors are straight on the object, free from deceit and duplicity.
33. Rectitude of consciousness (cittujukatā) — consciousness is straight on the object, free from deceit and duplicity.
34. Wisdom (paññā) — penetrating the breathing counterpart sign as object.

Note: The twelve mental phenomena at mind-door adverting are consciousness and the mental factors from knowing consciousness through energy in the list of thirty-four above.


<a id="M04-body-P085"></a>
## Knowledge delimiting mentality
Miến / Burmese 85

Jhāna mental phenomena generally take a counterpart sign as object, with some exceptions. In mindfulness of breathing, jhāna and its associated mental phenomena take the breathing counterpart sign. In attention to the repulsiveness of bones they take the bone counterpart sign. In the white kasiṇa (odāta) they take the white kasiṇa counterpart sign. In loving-kindness the object is a being as a concept. In foulness meditation the object is the counterpart sign of a foul corpse. If the meditator has developed and dwelt in jhāna with breathing, attention to the repulsiveness of bones, the white kasiṇa and the four protective meditations, the jhāna mental phenomena to apprehend and seek are as follows.

1. Breathing — first, second, third and fourth jhānas.
2. Attention to the repulsiveness of bones — first jhāna.
3. White kasiṇa — first, second, third and fourth jhānas.
4. Loving-kindness — first, second and third jhānas.
5. Foulness — first jhāna.

If the good person has developed all ten kasiṇas and the attainments with each kasiṇa, all eight attainments are included among the objects discerned by insight knowledge. The immaterial jhānas…


<a id="M04-body-P086"></a>
## How to begin apprehending first-jhāna mentality
Miến / Burmese 86

… each have thirty-one mental phenomena, the same number as fourth jhāna. Seek and apprehend them according to the fourth-jhāna table. Understand the other subjects similarly except compassion and appreciative joy. These two subjects can reach third jhāna. In compassion meditation, add the compassion factor to the breathing-jhāna mental phenomena. In appreciative-joy meditation, add the appreciative-joy factor. Thus the three levels have thirty-five, thirty-three and thirty-two mental phenomena respectively.

Seek and apprehend the jhāna mental phenomena as shown in the tables. In the impulsions leading to second jhāna and higher levels, namely preparation, access, conformity and change-of-lineage, applied and sustained thought are still associated (Abhidhamma Commentary, vol. 2, p. 237). In the access moments for fourth jhāna, joy too is absent (Visuddhimagga, vol. 1, p. 160).

To seek and apprehend the first-jhāna mental phenomena of breathing, first enter the first jhāna of breathing. After emerging, begin by apprehending its factors. Practise seeing them arise many times in uninterrupted succession. If the ability is still weak, take the breathing counterpart sign as object and enter first jhāna again. On emerging:

1. Apprehend the clear life-continuum, the mind-door.
2. Direct attention to and apprehend the breathing counterpart sign.
3. When that sign appears in the clear life-continuum, the mind-door, apprehend and seek the jhāna factors again.


<a id="M04-body-P087"></a>
## Gradually increasing the number of mental phenomena apprehended
Miến / Burmese 87

Just after emerging from jhāna, the breathing counterpart sign remains and does not readily disappear. By repeatedly training in this method, apprehending the base and object together with jhāna mentality, meditators gradually learn to seek and apprehend many occurrences of the jhāna factors. This is an ancient instruction that Venerable Sāriputta, the General of the Dhamma, followed with care.

First return to first jhāna with the breathing counterpart sign. Then begin apprehending jhāna mentality from knowing consciousness, or from feeling or contact. If you start from consciousness, practise seeing just knowing consciousness arise many times in succession. Starting from feeling or contact works similarly. Once successful, enter jhāna again. As soon as you emerge, practise seeing with wisdom repeated pairs of knowing consciousness and contact. When successful, enter again. On emerging, apprehend repeated groups of three: knowing consciousness, contact and feeling. Then take groups of four by adding perception, groups of five by adding volition, and continue increasing one phenomenon at a time.

Finally, practise seeing with wisdom the twelve mental phenomena at the moment of mind-door adverting and thirty-four at each impulsion moment, occurring many times in succession. Enter jhāna repeatedly and add one mental phenomenon to apprehend each time you emerge. When successful…


<a id="M04-body-P088"></a>
## Delimiting mentality and a note on the sixteen phenomena
Miến / Burmese 88

Pariggahetvā sabbampetaṃ ārammaṇābhimukhaṃ namanato namanaṭṭhena nāmanti vavatthapeti.
Having apprehended it, one determines all this as mentality in the sense of bending, because it inclines towards the object (Visuddhimagga, vol. 2, p. 222).

When you discern with wisdom the twelve mental phenomena at mind-door adverting and the thirty-four arising together at each moment of preparation, access, conformity, change-of-lineage and jhāna impulsion, occurring in repeated succession, see that they all turn and incline towards the same object, the breathing counterpart sign. Because they incline towards the object, distinguish and apprehend them as mentality, mental phenomena.

Note: Alternate repeatedly between entering jhāna and apprehending its mental phenomena. They are clear to wisdom immediately after emergence. Remember to re-enter when they are indistinct.

Points to note. In the Anupada Sutta, when Venerable Sāriputta apprehended the first-jhāna mental phenomena for insight, the Pāli names sixteen directly: applied thought, sustained thought, joy, pleasure, one-pointedness, contact, feeling, perception, volition, consciousness, desire, decision, energy, mindfulness, equanimity (specific neutrality), and attention. The commentary also says “soḷasa dhammā”, sixteen phenomena (Majjhima Commentary, vol. 4, p. 60), and explains that he apprehended them by their individual characteristics. However, the teacher known as Ācariya Dhammapāla…


<a id="M04-body-P089"></a>
## Two interpretations of the mental phenomena named in the Anupada Sutta
Miến / Burmese 89

… distinguishes two interpretations, the elders’ interpretation and a further interpretation, as follows (Majjhima Subcommentary, vol. 3, p. 277).

Soḷasannaṃ eva cettha dhammānaṃ gahaṇaṃ tesaṃyeva therena vavatthāpitabhāvato, te evassa tadā upaṭṭhahiṃsu, na itareti vadanti. Vīriyasatiggahaṇena cettha indriyabhāvasāmaññato saddhāpaññā, satiggahaṇeneva ekantānavajjabhāvasāmaññato passaddhiādayo cha yugaḷā, alobhādosā ca saṅgahitā jhānacittuppādapariyāpannattā tesaṃ dhammānaṃ. Therena ca dhammā vavatthānasāmaññato āraddhā. Te na upaṭṭhahiṃsūti na sakkā vattunti apare.

The elders’ interpretation. The discourse directly teaches and singles out sixteen jhāna-associated phenomena because Venerable Sāriputta distinguished each of those sixteen by wisdom. At that time those sixteen phenomena were clear and established in his knowing wisdom. The other phenomena associated with jhāna were indistinct, according to these teachers.

The further interpretation. Among the first-jhāna mental phenomena, energy and mindfulness serve as faculties called the energy faculty and the mindfulness faculty. Naming energy and mindfulness directly thus includes and teaches faith and wisdom, which also serve as faculties. The life faculty is understood similarly. Mindfulness is associated only with beautiful consciousness and is wholly faultless. In expressly teaching faultless mindfulness…


<a id="M04-body-P090"></a>
## Phenomena included in the further interpretation
Miến / Burmese 90

… the teaching also includes and teaches the entirely faultless mental factors of the same nature. These are the six pairs: tranquillity of the mental body and of consciousness, lightness of each, malleability of each, wieldiness of each, proficiency of each, and rectitude of each, as well as non-greed and non-hatred. These phenomena are all included in the arising of jhāna consciousness. Venerable Sāriputta also distinguished the phenomena associated with jhāna individually by their own characteristics and developed insight. Therefore the teachers of the further interpretation say it is inappropriate to claim that the jhāna-associated phenomena outside the sixteen were indistinct to his knowing wisdom (Majjhima Subcommentary, vol. 3, p. 277).

Yo yo aṭṭhakathāvādo vā theravādo vā pacchā vuccati, so pamāṇato daṭṭhabbo.
Whichever interpretation of the commentary or the elders is stated last should be regarded as authoritative (Vinaya Commentary, vol. 1, p. 260).

Under this convention of exposition (Vinaya Commentary, vol. 1, p. 260), the subcommentator placed the further interpretation last for the reader to take as the authoritative conclusion. It also accords with discourses that give an open-ended exposition. After apprehending the mental phenomena in a jhāna attainment in this way, the next stage of practice…


<a id="M04-body-P091"></a>
## Distinguishing mentality and materiality
Miến / Burmese 91

… is described in the Visuddhimagga as follows.

Tato yathā nāma puriso antogehe sappaṃ disvā taṃ anubandhamāno tassa āsayaṃ passati, evameva ayampi yogāvacaro taṃ nāmaṃ upaparikkhanto “idaṃ nāmaṃ kiṃ nissāya pavattatī”ti pariyesamāno tassa nissayaṃ hadayarūpaṃ passati. Tato hadayarūpassa nissayabhūtāni, bhūtanissitāni ca sesupādāyarūpānīti rūpaṃ pariggaṇhāti. So sabbampetaṃ ruppanato rūpanti vavatthapeti. Tato namanalakkhaṇaṃ nāmaṃ, ruppanalakkhaṇaṃ rūpanti saṅkhepato nāmarūpaṃ vavatthapeti.
Visuddhimagga, vol. 2, p. 222.

After apprehending jhāna mentality, the meditator is like a person who sees a snake in a house and follows it to its dwelling. The meditator investigates with wisdom, “Depending on what does this mentality occur?” In seeking, the meditator sees the heart-base materiality on which mentality depends. Then the meditator uses wisdom to distinguish and apprehend the four great elements supporting the heart-base and the other derived materiality that depends on those elements. Owing to their susceptibility to alteration, the meditator determines all these phenomena to be materiality. Then…


<a id="M04-body-P092"></a>
## From jhāna mentality to mentality that takes materiality as object
Miến / Burmese 92

1. What has the characteristic of inclining towards an object is mentality.
2. What has the characteristic of being altered is materiality.
One thus distinguishes mentality and materiality in brief (Visuddhimagga, vol. 2, p. 222).

Following the commentary above, after apprehending jhāna mentality, apprehend the fifty-four instances of elemental and derived materiality in the heart on which jhāna mentality depends, and distinguish materiality and mentality. When apprehending sense-sphere mentality in the eye-door process and the other five-door and mind-door processes, likewise apprehend the materiality at the relevant door on which those mental phenomena depend, then distinguish mentality and materiality. See the materiality tables for elemental and derived materiality at the six doors.

After apprehending the jhāna mental phenomena in the domain of mind objects, the meditator proceeds to apprehend mentality arising with materiality as object. By object, materiality is classified under six headings: visible form, sound, odour, taste, tangible object and mind object. Among these, it is easier to begin with the bare mind-door process taking the five sensitivities and sixteen subtle material phenomena that are mind objects, because fewer kinds of consciousness occur. Of the material phenomena classed as mind objects, eleven are concrete and ten non-concrete. Since a male meditator cannot find femininity materiality in his own continuum, nor a female meditator masculinity materiality in hers, only ten concrete material phenomena in one’s own continuum serve as objects for…


<a id="M04-body-P093"></a>
## Wise and unwise attention
Miến / Burmese 93

… the mental phenomena to be sought and apprehended. For practical purposes the material phenomena may be grouped where the practice is the same. The subcommentary also explains that this is a generalization for the hearer based on similarity of practice, without separate treatment of another person’s continuum (Majjhima Subcommentary, vol. 3, pp. 274–275). Apprehend mentality arising with each of those material phenomena as object. When mind-door adverting in these processes determines the object with wise attention, a bare mind-door process with wholesome impulsions arises. When it determines the object with unwise attention, a bare mind-door process with unwholesome impulsions arises. The two ways of attending are briefly explained below.

Parasantānagate ca tesaṃ santānavibhāgaṃ akatvā bahiddhābhāvasāmaññato sammasanaṃ, ayaṃ sāvakānaṃ sammasanacāro.

So “idaṃ dukkhan”ti yoniso manasi karoti, “ayaṃ dukkhasamudayo”ti yoniso manasi karoti, “ayaṃ dukkhanirodho”ti yoniso manasi karoti, “ayaṃ dukkhanirodhagāminī paṭipadā”ti yoniso manasi karoti.
Majjhima Nikāya, vol. 1, pp. 11–12.

Tattha katamo ayoniso manasikāro? “Anicce niccan”ti ayoniso manasikāro, “dukkhe sukhan”ti ayoniso manasikāro, “anattani attā”ti ayoniso manasikāro, “asubhe subhan”ti ayoniso manasikāro. Saccavippaṭikūlena vā cittassa āvaṭṭanā anāvaṭṭanā ābhogo samannāhāro manasikāro. Ayaṃ vuccati ayoniso manasikāro.
Abhidhamma, vol. 2, pp. 387–388.


<a id="M04-body-P094"></a>
## Definition and four ways of attending wisely
Miến / Burmese 94

Tattha yoniso manasikāro nāma upāyamanasikāro pathamanasikāro. Aniccādīsu aniccantiādināva nayena saccānulomikena vā cittassa āvaṭṭanā anāvaṭṭanā ābhogo samannāhāro manasikāro. Ayaṃ vuccati yoniso manasikāroti.
Majjhima Commentary, vol. 1, p. 66.

Ayoniso manasikāroti anupāyamanasikāro uppathamanasikāro. Anicce niccanti dukkhe sukhanti anattani attāti asubhe subhanti ayoniso manasikāro uppathamanasikāro. Saccavippaṭikūlena vā cittassa āvaṭṭanā anāvaṭṭanā ābhogo samannāhāro manasikāro. Ayaṃ vuccati ayoniso manasikāroti.
Majjhima Commentary, vol. 1, pp. 66–67.

Cittassa āvaṭṭanātiādīni sabbāni pi āvajjanasseva vevacanāni. Āvaṭṭanāti bhavaṅgaṃ āvaṭṭetīti cittassa āvaṭṭanā.
Abhidhamma Commentary, vol. 2, p. 482.

Wise attention attends by the proper means, on the proper path: “This is the noble truth of suffering”, “This is the noble truth of the origin of suffering”, “This is the noble truth of the cessation of suffering”, and “This is the noble truth of the way leading to the cessation of suffering, to Nibbāna”. Attending in this way is called wise attention (Majjhima Nikāya, vol. 1, pp. 11–12).


<a id="M04-body-P095"></a>
## Attention in accordance with and contrary to the Four Noble Truths
Miến / Burmese 95

Wise attention sets the object in mind and attends by the proper means and on the proper path, as a cause for the welfare and happiness of path, fruition and Nibbāna.

1. Attend to the five impermanent aggregates as impermanent.
2. Attend to the five suffering aggregates as suffering.
3. Attend to the five non-self aggregates as non-self.
4. Attend to the five unattractive aggregates as unattractive.

Adverting in that way or in a manner consistent with the Four Noble Truths turns the life-continuum, redirects the mind rightly, brings an object to mind, turns properly towards an object other than that of the life-continuum, and sets that other object in mind. Adverting in this way is called wise attention (Majjhima Commentary, vol. 1, p. 66).

What is unwise attention?
1. Attending to the five impermanent aggregates as permanent.
2. Attending to the five suffering aggregates as pleasant.
3. Attending to the five non-self aggregates as self.
4. Attending to the five unattractive aggregates as attractive.

That sets the object in mind in a way that does not lead to the welfare and happiness of path, fruition and Nibbāna. It attends by wrong means, on the wrong path. Further, adverting turns the life-continuum in a manner unfavourable to penetrating the Four Noble Truths…


<a id="M04-body-P096"></a>
## Great wholesome mentality taking eye-sensitivity as object
Miến / Burmese 96

… redirects the mind wrongly, brings the object to mind, directs it to an object other than that of the life-continuum and places that other object in mind. Adverting by such wrong means and on such a wrong path is called unwise attention (Abhidhamma, vol. 2, pp. 387–388. Majjhima Commentary, vol. 1, pp. 66–67).

As explained above, attending to ultimate mentality and materiality as materiality, mentality, cause, effect, impermanent, suffering, non-self or unattractive is wise attention. Attending to eye-sensitivity as eye-sensitivity, as materiality, impermanent, suffering, non-self or unattractive is also wise attention. Understand the same for all materiality and mentality.

Thirty-four great wholesome mental phenomena arise taking eye-sensitivity as object.
1. Knowing consciousness — apprehends eye-sensitivity as object.
2. Contact — touches eye-sensitivity and connects knowing consciousness with that object.
3. Feeling — experiences the flavour of the eye-sensitivity object…


<a id="M04-body-P097"></a>
## Mental phenomena taking eye-sensitivity as object
Miến / Burmese 97

… pleasantly (joyful feeling).
4. Perception — marks eye-sensitivity as object.
5. Volition — prompts and urges associated phenomena towards the object of eye-sensitivity.
6. One-pointedness — rests the mind on the single object of eye-sensitivity, keeps it steady and prevents the associated phenomena from scattering.
7. Life faculty — sustains the associated phenomena.
8. Attention — directs and drives the mind and associated phenomena towards eye-sensitivity, bringing that object to mind.

This suffices to convey the meaning, so only selected mental factors are shown here. They differ from the thirty-four jhāna mental phenomena only in object. Their types are the same.

15. Faith — confidence in the training in wisdom that penetrates the eye-sensitivity object.
34. Wisdom — penetrates eye-sensitivity as object.

This suffices to understand the mental phenomena arising with eye-sensitivity as object. For a good person who has thoroughly memorized the fifty-two mental factors…


<a id="M04-body-P098"></a>
## Preparing to read the bare mind-door process table
Miến / Burmese 98

… together with their nature and meaning, this is not very difficult. Understand ear-sensitivity and the other concrete and non-concrete material phenomena similarly. Taking eye-sensitivity as an example, the following table presents the wholesome group of bare mind-door processes in the domain of mind objects. The “wholesome group” here means processes containing wholesome impulsions.


<a id="M04-body-P099"></a>
## Wholesome bare mind-door process table
Miến / Burmese 99

Bare mind-door processes taking mind objects. Supporting materiality in the heart: 54.
Way of knowing the object | Mind-door adverting | Impulsion (7 times) | Registration (2 times) | Four cases
1. As eye-sensitivity | 12 | 34 | 34 | With knowledge, with joy
 | 12 | 33 | 33 | With knowledge, without joy
 | 12 | 33 | 33 | Without knowledge, with joy
 | 12 | 32 | 32 | Without knowledge, without joy
2. As materiality | 12 | 34 (33 / 33 / 32) | 34 (33 / 33 / 32) | As in the four cases above
3. As impermanent | 12 | 34 (33 / 33 / 32) | 34 (33 / 33 / 32) | As in the four cases above
4. As suffering | 12 | 34 (33 / 33 / 32) | 34 (33 / 33 / 32) | As in the four cases above
5. As non-self | 12 | 34 (33 / 33 / 32) | 34 (33 / 33 / 32) | As in the four cases above
6. As unattractive | 12 | 34 (33 / 33 / 32) | 34 (33 / 33 / 32) | As in the four cases above


<a id="M04-body-P100"></a>
## How to apprehend mind-door processes with wholesome impulsions
Miến / Burmese 100

Here the consciousness and mental factors that know “eye-sensitivity”, “materiality”, “impermanent”, “suffering”, “non-self” and “unattractive” are the mental phenomena being sought and apprehended.

The table above shows twenty-four cases for apprehending mentality arising with eye-sensitivity as object. It is intended to show how wholesome impulsions occur when one attends wisely. In apprehending them, remember first to analyse material clusters until you penetrate eye-sensitivity as ultimate reality. Understand the same for all concrete and non-concrete materiality. The method is illustrated below with mind-door processes having wholesome impulsions and taking eye-sensitivity as object.

1. Re-establish a previously attained fourth-jhāna concentration or the highest concentration you favour.
2. Apprehend the clear life-continuum, the mind-door.


<a id="M04-body-P101"></a>
## Six ways of attending wisely to eye-sensitivity
Miến / Burmese 101

3. Direct the mind to ultimate eye-sensitivity. When that object appears before the clear life-continuum, the mind-door, series of mind-door processes with impulsion arise. Mind-door adverting in those series determines the object in the following ways.

1. Determine it as eye-sensitivity.
2. Determine eye-sensitivity as materiality.
3. Take its arising and passing away, its liability to break up, as object and discern it as impermanent.
4. Take its being continually oppressed by arising and passing away as object and discern it as suffering.
5. Take its lack of any permanent, enduring, indestructible self as object and discern it as non-self.
6. Take its repulsiveness due to being mixed with unattractive colours, smells and the like as object and discern it as unattractive.

With correct attention, that is, wise attention, wholesome impulsions arise. Of these six ways, begin by apprehending the series of mind-door processes with impulsion that know the object in the first way, as eye-sensitivity. You may start with knowing consciousness, with contact, or with feeling.


<a id="M04-body-P102"></a>
## Apprehending individual mental phenomena in the mind-door process
Miến / Burmese 102

If you begin from knowing consciousness, practise seeing repeatedly with wisdom that knowing consciousness arises once at mind-door adverting, seven times at impulsion and twice at registration. When eye-sensitivity appears at the clear life-continuum, the mind-door, use that door and the heart-base to practise seeing mind-door processes recur with many life-continuum moments between them.

When successful, add one mental factor at a time: knowing consciousness and contact in pairs, then add feeling for groups of three, perception for groups of four, and so on. Practise until you see the complete set arising together in each moment: twelve at mind-door adverting, thirty-four at each impulsion, and thirty-four at each registration. If mentality becomes indistinct, re-establish a fourth-jhāna concentration. Once the light of wisdom is strong again, apprehend both the object being discerned, such as eye-sensitivity, and the clear life-continuum, and add one mental phenomenon at a time. Practise repeatedly, apprehending the mind-door and the object together. Use this method whenever the mental phenomena are unclear.

When able to see with wisdom, see these phenomena incline towards eye-sensitivity as object and apprehend them as “mentality, mentality”. Discern in the same way in the remaining kinds of wise attention. When discerning in this way, at impulsion and registration…


<a id="M04-body-P103"></a>
## Four cases of association with knowledge and joy
Miến / Burmese 103

1. Sometimes both knowledge and joy are present. This is great wholesome consciousness accompanied by joyful feeling and associated with knowledge.
2. Sometimes knowledge is present without joy. This is great wholesome consciousness accompanied by equanimous feeling and associated with knowledge.
3. Sometimes joy is present without knowledge. This is great wholesome consciousness accompanied by joyful feeling and dissociated from knowledge.
4. Sometimes neither knowledge nor joy is present. This is great wholesome consciousness accompanied by equanimous feeling and dissociated from knowledge.
There are four cases in all.

When discerning eye-sensitivity as eye-sensitivity, there are four modes according to whether knowledge and joy are present. Likewise discern four modes each when knowing eye-sensitivity as materiality, impermanent, suffering, non-self and unattractive. In all there are twenty-four instances.

There are four prompted (sasaṅkhārika) and four unprompted (asaṅkhārika) types of great wholesome consciousness, eight in all. Prompted means with inducement, unprompted without inducement. Since this distinction does not change the number of mental factors, only the four modes above are presented here. As meditators discern, they gradually understand the nature of the prompted and unprompted types. The four modes in each group together make eight types of great wholesome consciousness. The same applies to great functional consciousness, which arises only in the continuum of arahants.


<a id="M04-body-P104"></a>
## Points to know about registration
Miến / Burmese 104

Generally, registration can occur only when impulsion is sense-sphere, the being is a sense-sphere being, and the object is sense-sphere, very great at the five doors or clear at the mind-door. Sense-sphere objects comprise sense-sphere consciousness and mental factors and the twenty-eight material phenomena. In a sense-sphere being’s continuum, registration may follow sense-sphere impulsions in mind-door processes taking sense-sphere consciousness and mental factors as object. As the twenty-eight material phenomena are also sense-sphere phenomena, registration may follow sense-sphere impulsions in processes taking them as object. But in five-door processes such as the eye-door process the object must be very great, and in mind-door processes it must be clear. Hence “generally”. Under this condition registration cannot follow impulsions in a process that takes a concept as object.

The Sammohavinodanī commentary on the Vibhaṅga explains as follows.

Tilakkhaṇārammaṇikavipassanāya tadārammaṇaṃ na labbhati.
Registration does not occur after insight impulsion taking one of the three characteristics as object (Abhidhamma Commentary, vol. 2, p. 147).

The teachers explain that this statement about registration being unable to follow insight impulsion refers specifically to strong insight impulsion. They cite the following canonical and commentarial passages.


<a id="M04-body-P105"></a>
## Registration after weak insight impulsion
Miến / Burmese 105

Sekkhā vā puthujjanā vā kusalaṃ aniccato dukkhato anattato vipassanti. Kusale niruddhe vipāko tadārammaṇatā uppajjati.
Paṭṭhāna, vol. 1, p. 133.

Kusale niruddheti vipassanāvasena pavattitvā niruddhe. Vipākoti kāmāvacaravipāko. Tadārammaṇatāti tadārammaṇatāya. Taṃ kusalassa javanassa ārammaṇabhūtaṃ vipassitakusalaṃ ārammaṇaṃ katvā uppajjatīti attho.
Abhidhamma Commentary, vol. 3, p. 436.

Trainees and worldlings discern wholesome mentality by one of the three characteristics, impermanence, suffering or non-self. After that wholesome insight impulsion, sense-sphere resultant mentality takes the same wholesome mentality that was discerned, the very object taken by the impulsion. It arises to perform the function of registration (Paṭṭhāna, vol. 1, p. 133. Abhidhamma Commentary, vol. 3, p. 436).

Here the object of insight knowledge is wholesome, and the series of insight impulsions discerning it is wholesome as well. Because the object is sense-sphere wholesome, the insight impulsion discerning it is great wholesome sense-sphere impulsion. All three factors are present: sense-sphere impulsion, a sense-sphere being, and a sense-sphere object. Since the teaching says registration can follow this insight impulsion, the teachers explain that the passage refers to insight impulsion that is still weak (see Mūlaṭīkā, vol. 1, p. 131).


<a id="M04-body-P106"></a>
## Conditions and kinds of registration consciousness
Miến / Burmese 106

At this stage the meditator is still at the knowledge that delimits mentality and materiality, apprehending mentality that arises with sense-sphere materiality as object. The actual insight stage has yet to be reached. Here, when apprehending mentality taking materiality as object, registration may also follow the great wholesome impulsions of the knowledge that apprehends materiality if that material object is clear.

After great wholesome impulsions, great resultant consciousness performing registration may be accompanied by joyful or equanimous feeling as appropriate. Rootless investigating consciousness may also perform registration as appropriate. After unwholesome impulsions, great resultant and rootless investigating consciousness may also perform that function as appropriate. The preceding table illustrates only great resultant registration under the general rule. Meditators can gradually understand the other cases as they discern. Under the general rule, joyful registration follows joyful impulsions, and equanimous registration follows equanimous or displeased impulsions.

The eight great resultant and three investigating consciousnesses, eleven in all, are called registration because they can perform the function of continuing to receive the very object taken by impulsion. The following table shows registration that can follow impulsion, especially for good meditators who are three-rooted worldlings. Stream-enterers, once-returners and non-returners can understand it similarly, leaving out the defilements they have abandoned.


<a id="M04-body-P107"></a>
## Registration table and the distinction between resultants and impulsion
Miến / Burmese 107

Registration for three-rooted worldlings
After impulsion | Possible registration
Any of the 8 great wholesome impulsions | Any of the 11 registration consciousnesses
Any of the 8 greed-rooted impulsions | Any of the 11 registration consciousnesses
Either of the 2 hatred-rooted impulsions | Any of the 6 equanimous registration consciousnesses
Either of the 2 delusion-rooted impulsions | Any of the 11 registration consciousnesses

1. Naturally desirable or exceptionally desirable objects are encountered owing to previous wholesome kamma. With a moderately desirable object, the process consciousnesses apart from adverting and impulsion are great resultant or rootless wholesome resultant consciousnesses. At the five doors these are five-door sense consciousness, receiving, investigating and registration. At the mind-door this refers to registration. With wise attention wholesome impulsion can occur. With unwise attention unwholesome impulsion can occur.

2. With an exceptionally desirable and precious object such as the Buddha, only the five joyful types of wholesome-resultant registration can occur. Impulsion may be wholesome with wise attention or unwholesome with unwise attention.

3. Naturally undesirable objects are encountered owing to previous unwholesome kamma. With such an object, wise attention leads to wholesome impulsion and unwise attention to unwholesome impulsion. In five-door processes, the five kinds of sense consciousness such as eye-consciousness…


<a id="M04-body-P108"></a>
## Undesirable objects and guest life-continuum
Miến / Burmese 108

… together with receiving, investigating and registration, and the registration in mind-door processes, must be rootless unwholesome-resultant consciousnesses. Under this rule, with an undesirable object there is only one kind of registration, namely unwholesome-resultant investigating consciousness accompanied by equanimity.

The tables illustrate the general rule. Under it joyful registration follows joyful impulsion, and equanimous registration follows equanimous or displeased impulsion. For a being reborn with joyful consciousness, the life-continuum is of the same type as rebirth-linking and is also joyful. If hatred-rooted impulsion arises in that being’s continuum and for some reason registration cannot follow, ordinarily life-continuum would follow the hatred-rooted impulsion. But rebirth-linking, life-continuum and death consciousness in one life are of the same type, so here the life-continuum must be joyful. Joyful life-continuum cannot suitably follow hatred-rooted impulsion immediately. In this difficulty one of the two kinds of equanimous investigating consciousness arises as guest life-continuum, linking the hatred-rooted impulsion with the original joyful life-continuum. It is unwholesome resultant if the object is undesirable and wholesome resultant if the object is desirable or exceptionally desirable.

Guest life-continuum (āgantukabhavaṅga). The life-continuum moments that begin to occur after rebirth-linking are of the same type as rebirth-linking. Being present from the beginning in the house of the aggregates and residing there, they are called resident life-continuum (āvāsikabhavaṅga)…


<a id="M04-body-P109"></a>
## The object of guest life-continuum and three cases without registration
Miến / Burmese 109

… the householder life-continuum. Equanimous investigating consciousness arises only occasionally when a difficulty like the one above occurs, so it is called guest life-continuum. Since it does not take the object taken by impulsion, it is not called registration. Nor can it take the resident life-continuum’s object. It takes a previously familiar sense-sphere object. If that familiar object, to which much attention has been given, is desirable, the investigating consciousness accompanied by equanimity is wholesome resultant. If it is undesirable, the investigating consciousness accompanied by equanimity is unwholesome resultant.

1. A person with joyful rebirth-linking who holds wrong view may have hatred-rooted impulsion with an exceptionally desirable object such as the Buddha as a very great or clear object. Or a person with joyful rebirth-linking may have hatred-rooted impulsion from fright at a celestial maiden, an exceptionally desirable object that is very great or clear. There is no opportunity for registration after that hatred-rooted impulsion. With an exceptionally desirable object only joyful registration is possible, and joyful registration cannot suitably follow hatred-rooted impulsion.

2. If a person with joyful rebirth-linking has hatred-rooted impulsion taking a sense-sphere object that is large or indistinct, registration does not follow it. Registration has an opportunity only with a very great object at the five doors or a clear object at the mind-door.

3. If a meditator with joyful rebirth-linking attains jhāna and then loses it, they may take the lost exalted jhāna as object and have hatred-rooted impulsion: “My sublime attainment has been lost!” As the object is exalted, registration does not occur.


<a id="M04-body-P110"></a>
## The linking function of guest life-continuum
Miến / Burmese 110

4. If a person with joyful rebirth-linking has hatred-rooted impulsion taking a concept as object, registration does not occur with that concept, because it is not a sense-sphere object.

In such processes, where registration has no opportunity to arise, the original joyful life-continuum, of the same type as rebirth-linking, also cannot follow hatred-rooted impulsion immediately. Because neither registration nor the original life-continuum can immediately follow, investigating consciousness accompanied by equanimity arises as guest life-continuum, linking hatred-rooted impulsion to the original joyful life-continuum.

To understand one case of registration according to the explanations above, the table of wholesome bare mind-door processes taking mind objects is presented again below. Use it to understand the remaining tables similarly. Remember the general rule: joyful registration follows joyful impulsion and equanimous registration follows equanimous impulsion, as appropriate. With an undesirable object, however, the resultant five-door sense consciousness, receiving, investigating and registration in five-door processes must be unwholesome resultants. Thus even when joyful impulsion occurs with an undesirable object, registration can only be unwholesome-resultant investigating consciousness with equanimity, comprising eleven mental phenomena. Wholesome-resultant investigating consciousness with equanimity also has eleven mental phenomena (see the visible-object process table). Thus when the table shows eleven, understand this as unwholesome-resultant equanimous investigating for an undesirable object and wholesome-resultant equanimous investigating for a desirable object.


<a id="M04-body-P111"></a>
## Wholesome mind-door process table with concrete materiality as object
Miến / Burmese 111

Wholesome mind-door processes taking mind objects. Supporting materiality in the heart: 54.
Object | Mind-door adverting | Impulsion (7 times) | Rooted registration (2 times) (8) | Rootless registration (2 times)
1. As eye-sensitivity | 12 | 34 | 34 | 12/11
 | 12 | 33 | 33 | 11/11
 | 12 | 33 | 33 | 12/11
 | 12 | 32 | 32 | 11/11
2. As materiality | 12 | 34 | 34 | 12/11
 | 12 | 33 | 33 | 11/11
 | 12 | 33 | 33 | 12/11
 | 12 | 32 | 32 | 11/11
3. As impermanent | 12 | 34 | 34 | 12/11
 | 12 | 33 | 33 | 11/11
 | 12 | 33 | 33 | 12/11
 | 12 | 32 | 32 | 11/11
4. As suffering | 12 | 34 | 34 | 12/11
 | 12 | 33 | 33 | 11/11
 | 12 | 33 | 33 | 12/11
 | 12 | 32 | 32 | 11/11
5. As non-self | 12 | 34 | 34 | 12/11
 | 12 | 33 | 33 | 11/11
 | 12 | 33 | 33 | 12/11
 | 12 | 32 | 32 | 11/11
6. As unattractive | 12 | 34 | 34 | 12/11
 | 12 | 33 | 33 | 11/11
 | 12 | 33 | 33 | 12/11
 | 12 | 32 | 32 | 11/11


<a id="M04-body-P112"></a>
## Registration with undesirable and desirable objects
Miến / Burmese 112

The table shows joyful registration following joyful impulsion and equanimous registration following equanimous impulsion. With wise attention, even when encountering an undesirable object, joyful or equanimous impulsion can arise as appropriate. Because the object is undesirable, however, only the rootless unwholesome-resultant investigating consciousness accompanied by equanimity can occur as registration.

With a moderately desirable object, wise attention may lead to joyful or equanimous impulsion as appropriate. Either rooted great-resultant registration or rootless wholesome-resultant registration may occur. In a single process only one of these kinds occurs. If great wholesome impulsion is joyful and associated with knowledge, registration may be joyful great resultant associated with knowledge or joyful rootless wholesome-resultant investigating consciousness. If great wholesome impulsion is equanimous and associated with knowledge, registration may be equanimous great resultant associated with knowledge or equanimous rootless wholesome-resultant investigating consciousness. Understand the joyful and equanimous cases dissociated from knowledge similarly, with knowledge absent.

If the object is exceptionally desirable, wise attention can lead to joyful or equanimous impulsion as appropriate. Joyful feeling, however, is more frequent.


<a id="M04-body-P113"></a>
## Reading the registration counts and discerning concrete materiality
Miến / Burmese 113

One of five kinds can occur as registration, as appropriate: four joyful great-resultant registration consciousnesses and one joyful rootless wholesome-resultant investigating consciousness.

Accordingly the rootless registration column gives 12/11 or 11/11. The first number 12 refers to the group of mental phenomena in joyful rootless wholesome-resultant registration. The first number 11 refers to equanimous rootless wholesome-resultant investigating registration. The second number 11 refers to equanimous rootless unwholesome-resultant investigating registration when the object is undesirable.

Concrete material phenomena to discern following the example: 1. Ear-sensitivity. 2. Nose-sensitivity. 3. Tongue-sensitivity. 4. Body-sensitivity. 5. Water element. 6. Femininity materiality. 7. Masculinity materiality. 8. Heart-base. 9. Material life faculty. 10. Nutriment.

Including eye-sensitivity, eleven concrete material phenomena belong to the mind-object group. Analyse the material cluster containing the material phenomenon you wish to take as object, select that concrete material phenomenon as object, and seek and apprehend the mentality arising with it as object. When discerning internally, male meditators take masculinity materiality and female meditators femininity materiality, and apprehend the mentality arising with the respective object…


<a id="M04-body-P114"></a>
## How to discern non-concrete materiality
Miến / Burmese 114

… alone. The method of practice is the same for the two sex materialities. Taken collectively, one may seek and apprehend mentality arising with both kinds of sex materiality as objects.

The ten non-concrete material phenomena, those without individual nature in the mind-object group, are not material phenomena to be discerned in insight by the three characteristics. Thus whether one discerns one or all of them as impermanent, processes with insight impulsion knowing “impermanent” cannot arise. Understand suffering and non-self similarly. For each non-concrete material phenomenon, therefore, discern in only two ways, for example:

1. Discern it as the space element. Discern four cases of consciousness and mental factors knowing it as the space element, varying the presence of knowledge and joy.
2. Discern that same space element as materiality. Discern four cases of consciousness and mental factors knowing it as materiality, varying the presence of knowledge and joy.

Here too, first see the space element as the gaps between material clusters. Then apprehend the mentality taking that space element as object. Understand the same pattern for all the non-concrete material phenomena below.


<a id="M04-body-P115"></a>
## Wholesome mind-door process table with non-concrete materiality as object
Miến / Burmese 115

Wholesome mind-door processes taking mind objects. Supporting materiality in the heart: 54.
Object | Mind-door adverting | Impulsion (7 times) | Rooted registration (2 times) (8) | Rootless registration (2 times)
As the space element | 12 | 34 | 34 | 12/11
 | 12 | 33 | 33 | 11/11
 | 12 | 33 | 33 | 12/11
 | 12 | 32 | 32 | 11/11
As materiality | 12 | 34 | 34 | 12/11
 | 12 | 33 | 33 | 11/11
 | 12 | 33 | 33 | 12/11
 | 12 | 32 | 32 | 11/11

Nine non-concrete material phenomena to discern in the same way: 1. Bodily intimation (kāyaviññatti). 2. Verbal intimation (vacīviññatti). 3. Lightness of materiality (rūpassa lahutā). 4. Malleability of materiality (rūpassa mudutā). 5. Wieldiness of materiality (rūpassa kammaññatā). 6. Accumulation (upacaya).* 7. Continuity (santati). 8. Ageing (jaratā). 9. Impermanence (aniccatā).

* Note: Mentality arising with accumulation of materiality as object can be discerned once the mentality and materiality present at rebirth-linking, at the kalala embryonic stage, can be apprehended.


<a id="M04-body-P116"></a>
## Analysing material clusters before apprehending mentality
Miến / Burmese 116

To seek and apprehend mentality taking non-concrete materiality as object, analyse the cluster containing the materiality to be discerned until wisdom sees the ultimate materiality originated by consciousness, temperature, or nutriment in the same cluster. Then select the particular materiality to be discerned. Material phenomena arise in clusters or groups.

First see the material cluster. Analyse it by wisdom into the individual ultimate material phenomena, all eight, nine, or ten according to the cluster. Then select a concrete material phenomenon such as eye-sensitivity, or a non-concrete one such as bodily intimation. When it appears before the clear life-continuum, the mind-door, seek and apprehend the mentality arising with it as object.

The foregoing explained how to apprehend mentality in mind-door processes with wholesome impulsion that take concrete or non-concrete materiality belonging to the mind-object domain as object. For convenience, the impulsion mentality and great-resultant registration mentality are called the faith-and-wisdom group. Next comes apprehending mentality in wholesome mind-door processes associated with abstinence and immeasurable mental factors.


<a id="M04-body-P117"></a>
## Abstinence through right speech
Miến / Burmese 117

Of the three abstinence factors (virati), right speech is abstaining from four kinds of verbal misconduct apart from livelihood. Discern the four cases separately because their objects differ: take abstaining from lying as object once, abstaining from divisive speech once, abstaining from harsh speech once, and abstaining from idle chatter once. For each, discern four cases according to the presence or absence of knowledge and joy.

1. Apprehend the clear life-continuum, the mind-door, at the earlier time when you abstained from lying.
2. Direct the mind to that past abstention from lying.
3. When that object appears at the mind-door, apprehend the mind-door impulsion mentality that arose at the time of abstaining.

In each impulsion, adding right speech to the thirty-four mental phenomena of the faith-and-wisdom group makes thirty-five. Discern four cases varying knowledge and joy. With a clear object, rooted great-resultant or rootless registration may occur as appropriate. If registration is great resultant, right speech…


<a id="M04-body-P118"></a>
## Abstinence through right action
Miến / Burmese 118

… cannot be associated with it. Only mental phenomena of the faith-and-wisdom group occur, with thirty-four as appropriate. Discern four cases varying knowledge and joy. Discern abstention from divisive speech, harsh speech and idle chatter in the same way.

Right action is abstaining from three kinds of bodily misconduct apart from livelihood. Discern three cases separately because their objects differ: take abstaining from killing as object once, abstaining from taking what is not given once, and abstaining from sexual misconduct once. In each case discern four modes varying knowledge and joy.

1. Apprehend the clear life-continuum, the mind-door, at the time of abstaining from killing.
2. Direct the mind to that past abstention. For example, attend to an occasion when you refrained from killing a mosquito.
3. When the object appears at the mind-door, apprehend the mentality in the mind-door process with great wholesome impulsion that arose at the time of abstaining.

In each impulsion, adding right action to the thirty-four mental phenomena of the faith-and-wisdom group makes thirty-five. Varying the presence of knowledge and joy, discern four…


<a id="M04-body-P119"></a>
## Abstinence through right livelihood
Miến / Burmese 119

… cases. If the object is clear, registration can occur, either rooted great-resultant or rootless registration as appropriate. Right action cannot be associated with great-resultant registration. There can be thirty-four mental phenomena of the faith-and-wisdom group in great-resultant registration as appropriate. Discern four cases varying knowledge and joy. Discern abstention from taking what is not given and from sexual misconduct similarly.

Right livelihood is abstaining from bodily and verbal misconduct connected with livelihood. With three kinds of bodily and four kinds of verbal misconduct, there are various ways of discerning. Take one object in relation to which you habitually abstain or have abstained. For example, refrain from eating a food when you know an animal was killed specifically for you.

1. Apprehend the clear life-continuum, the mind-door, at the time when you abstained from wrong livelihood.
2. Direct the mind to one occasion of abstaining from wrong livelihood. For example, if you refrained from eating unsuitable meat or fish, attend to that abstention.
3. When the object appears at the mind-door, apprehend the mentality in the mind-door process with great wholesome impulsion that arose at the time of abstaining. Registration may occur.


<a id="M04-body-P120"></a>
## Table of the three abstinence factors in mind-door processes
Miến / Burmese 120

Abstinence factors in mind-door processes taking mind objects. Supporting materiality in the heart: 54.
Abstinence | Mind-door adverting | Impulsion (7 times) | Rooted registration (2 times) (8) | Rootless registration (2 times)
1. Right speech | 12 | 35 | 34 | 12/11
 | 12 | 34 | 33 | 11/11
 | 12 | 34 | 33 | 12/11
 | 12 | 33 | 32 | 11/11
2. Right action | 12 | 35 | 34 | 12/11
 | 12 | 34 | 33 | 11/11
 | 12 | 34 | 33 | 12/11
 | 12 | 33 | 32 | 11/11
3. Right livelihood | 12 | 35 | 34 | 12/11
 | 12 | 34 | 33 | 11/11
 | 12 | 34 | 33 | 12/11
 | 12 | 33 | 32 | 11/11


<a id="M04-body-P121"></a>
## Three senses of right speech and right action
Miến / Burmese 121

Right speech is of three kinds: right speech as the utterance (kathāsammāvācā), as volition (cetanāsammāvācā), and as abstinence (viratisammāvācā). Good, faultless speech connected with causes and effects is right speech as utterance. The volition associated with preparatory, direct-knowledge, great wholesome or great functional impulsion that brings about such faultless speech is right speech as volition. When there is an occasion for lying, divisive speech, harsh speech or idle chatter, one may abstain and instead speak truthfully, harmoniously, gently or beneficially, or one may remain silent. The abstinence present in the consciousness that arises in speaking or remaining silent is right speech as abstinence. The misconduct abstained from through right speech here is apart from livelihood.

Right action likewise has three kinds: right action as activity, as volition, and as abstinence. The bodily activity of someone doing a faultless deed, such as giving, keeping precepts or developing meditation, is right action as activity. The volition that performs that faultless deed is right action as volition. When an opportunity for bodily misconduct arises and one refrains, whether or not one performs some other bodily action, this is right action as abstinence. All misconduct abstained from in this sense is apart from livelihood.


<a id="M04-body-P122"></a>
## Right livelihood and two kinds of mundane abstinence
Miến / Burmese 122

Right livelihood has two kinds: right livelihood as activity and right livelihood as abstinence. Rightful activity in making a living by an ordinary occupation such as farming or trade, or in a renunciant’s seeking the four requisites in accordance with the Dhamma while avoiding wrong livelihood such as cultivating donor families and procuring requisites through gifts, is right livelihood as activity. Refraining from bodily and verbal misconduct connected with livelihood, or from using the four requisites obtained through such wrong livelihood, is right livelihood as abstinence.

There are three kinds of abstinence: abstinence upon encountering an occasion (sampattavirati), abstinence through undertaking precepts (samādānavirati), and abstinence through eradication (samucchedavirati). Someone who has not undertaken the training rules reflects on family, age, learning or good fortune and thinks, “It is unfitting for us to do such a wrong deed.” Encountering an object in relation to which a transgression is possible, that person refrains. The abstinence arising in that continuum is abstinence upon encountering an occasion (Abhidhamma Commentary, vol. 1, p. 146).

Someone who undertakes the training rules, whether at the time of undertaking them or later, refrains from transgression because of the undertaking, even at the cost of their life. The abstinence arising in that continuum is abstinence through undertaking precepts (Abhidhamma Commentary, vol. 1, p. 146).


<a id="M04-body-P123"></a>
## Abstinence through eradication and objects of mundane abstinence
Miến / Burmese 123

Abstinence through eradication is abstinence associated with the noble path. It arises through cutting off at the root the latent tendencies underlying unwholesome conduct and wrong livelihood. From its arising onward, even the thought “I will kill a living being” does not arise in a noble disciple’s continuum (Abhidhamma Commentary, vol. 1, p. 147). Being associated with the noble path, it clearly takes Nibbāna as object. The objects of abstinence upon encountering an occasion and abstinence through undertaking call for further examination.

Ārammaṇato pāṇātipāto jīvitindriyārammaṇo. Adinnādānaṃ sattārammaṇaṃ vā saṅkhārārammaṇaṃ vā. Micchācāro itthipurisārammaṇo. Musāvādo sattārammaṇo vā saṅkhārārammaṇo vā. Surāpānaṃ saṅkhārārammaṇaṃ.
Abhidhamma Commentary, vol. 2, p. 366.

Satta-itthi-purisārammaṇato tathāgahitasaṅkhārārammaṇatāya dhammā.
Mūlaṭīkā, vol. 2, p. 189.

As to objects, killing takes the life faculty as object. Taking what is not given and similar cases can take a being or formations as object. Sexual misconduct takes a woman or a man as object. False speech can take a being or formations as object. Taking intoxicants has formations as object (Abhidhamma Commentary, vol. 2, p. 366). According to the Mūlaṭīkā, phenomena described as taking a being, woman or man as object have the corresponding formations as object (vol. 2, p. 189).

Ārammaṇato pāṇātipātā veramaṇī parassa jīvitindriyaṃ ārammaṇaṃ katvā attano veracetanāya viramati. Itarāsupi eseva nayo. Sabbāpi hi etā vītikkamitabbavatthuṃ ārammaṇaṃ katvā veracetanāhiyeva viramanti.
Abhidhamma Commentary, vol. 2, p. 368.

When abstaining from killing, one takes the life faculty of the being that could be killed as object and refrains from the volition to transgress. Similar cases follow the same principle, because abstinence arises by taking the object in relation to which transgression is possible and refraining from the volition to transgress (Abhidhamma Commentary, vol. 2, p. 368).

Parittārammaṇā… pe… paccuppannārammaṇā… pe… bahiddhārammaṇā.
Taking a limited object… pe… taking a present object… pe… taking an external object (Abhidhamma, vol. 2, p. 205).


<a id="M04-body-P124"></a>
## The object in relation to which one could transgress, and the volition to transgress
Miến / Burmese 124

Ārammaṇattikesu pana yāni sikkhāpadāni ettha sattārammaṇānīti vuttāni, tāni yasmā sattoti saṅkhaṃ gate saṅkhāreyeva ārammaṇaṃ karonti, yasmā ca sabbānipi etāni sampattavirativaseneva niddiṭṭhāni, tasmā “parittārammaṇā”ti ca “paccuppannārammaṇā”ti ca vuttā. Yato pana viramati, tassa vatthuno accantabahiddhattā sabbesampi bahiddhārammaṇatā veditabbāti.
Among the object triads, the training rules described here as taking a being as object take as object the very formations designated “a being”. Since all these rules are explained in terms of abstinence upon encountering an occasion, they are said to take a limited object and a present object. Since the basis in relation to which one abstains is entirely external, all are to be understood as taking an external object. (Abhidhamma Commentary, vol. 2, p. 369.)

“Volition of abstinence upon encountering an occasion” means volition with a present object on that occasion, in relation to which one abstains from transgression (Mūlaṭīkā, vol. 2, p. 190).

Sampattaviraticetanāti sampatte paccuppanne ārammaṇe yathāviramitabbato viraticetanāti attho.
Mūlaṭīkā, vol. 2, p. 190.

The meaning of the canonical, commentarial and subcommentarial passages above is as follows. Abstinence upon encountering an occasion and abstinence through undertaking take as object only limited sense-sphere phenomena, called the basis in relation to which one could transgress (vītikkamitabbavatthu) or should abstain (viramitabbavatthu). These are formations of sense-sphere mentality and materiality. The object is present and is external mentality and materiality.

The unwholesome volition to transgress in relation to that object is the volition of transgression (veracetanā), the real enemy. When the sense-sphere mentality and materiality in relation to which one could transgress are taken as object, the nature of refraining from the volition of transgression in one’s own continuum is abstinence. Abstinence from killing takes another being’s life faculty as object and refrains from the unwholesome volition to transgress in one’s own continuum. Abstinence from taking what is not given takes that in relation to which one could transgress…


<a id="M04-body-P125"></a>
## Objects of particular kinds of abstinence
Miến / Burmese 125

… either a being or formations as object, and refrains from the volition to transgress that has arisen in one’s own continuum. Abstinence from sexual misconduct takes a woman or a man, the possible object of transgression, as object, and refrains from the volition of sexual misconduct in one’s own continuum. Abstinence from lying takes a being or formations, the possible object of transgression, as object, and refrains from the volition to lie in one’s own continuum. Abstinence from intoxicants takes formations constituting an intoxicant, the possible object of transgression, as object, and refrains from the unwholesome volition to take it in one’s own continuum (Abhidhamma Commentary, vol. 2, pp. 366–368).

The explanation that abstinence takes a being, woman or man as object means that it takes only the formations, sense-sphere mentality and materiality, which exist in a manner that can be designated a being, woman or man (Abhidhamma Commentary, vol. 2, p. 369. Mūlaṭīkā, vol. 2, p. 187).

Only on encountering a present object in relation to which a transgression is possible does abstinence take that object and refrain from the unwholesome volition to transgress arising in one’s continuum. Thus abstinence upon encountering an occasion and abstinence through undertaking take present sense-sphere mentality and materiality in relation to which transgression is possible as object. That mentality and materiality are external.


<a id="M04-body-P126"></a>
## The two immeasurable mental factors
Miến / Burmese 126

It remains to examine whether abstinence takes a being, woman, or man as object. If it takes such objects, there is no opportunity for registration.

Compassion (karuṇā) is wishing to rescue a suffering being. 1. Apprehend the clear life-continuum, the mind-door. 2. Direct the mind to a suffering being you wish to rescue. 3. When that conceptual object of a being appears at the mind-door, apprehend the series of mind-door processes with impulsion in which compassion predominates. The thirty-four mental phenomena of the faith-and-wisdom group plus compassion make thirty-five as appropriate. Discern the four cases varying knowledge and joy.

Appreciative joy (muditā) is rejoicing in the happiness of a being. 1. Apprehend the clear life-continuum, the mind-door. 2. Direct the mind to a happy being. 3. When that conceptual object of a happy being appears at the mind-door, apprehend the series of mind-door processes with impulsion that arose.


<a id="M04-body-P127"></a>
## Feeling in appreciative joy, faith and wisdom
Miến / Burmese 127

If appreciative joy has not matured to the attainment of its jhāna, its impulsion should have joyful feeling only. Discern the two cases, with and without knowledge. With knowledge, thirty-four plus appreciative joy makes thirty-five. Without knowledge, thirty-three plus appreciative joy makes thirty-four. Venerable Anuruddha holds that for one who has developed appreciative joy to jhāna, the strength of development also allows access impulsions accompanied by equanimity. Such a person can discern four cases varying knowledge and joy. Since compassion and appreciative joy take a being as a concept, registration cannot follow their impulsions. For apprehending their jhāna mentality, see the tables on the divine abidings.

In the groups of impulsion mentality containing abstinence or immeasurable factors, faith is confidence in kamma and its results. Wisdom is understanding kamma and its results, right view of ownership of kamma (kammassakatā sammādiṭṭhi). Alternatively, faith in abstinence is confidence in training in virtue. Here the special reference is to the sense-sphere impulsions called preparation and access that precede jhāna with compassion or appreciative joy.


<a id="M04-body-P128"></a>
## Table of immeasurable factors and recollection of the Buddha
Miến / Burmese 128

Mind-door processes with sense-sphere impulsion taking mind objects. Supporting materiality in the heart: 54.
Immeasurable factor | Mind-door adverting | Impulsion (7 times)
1. Compassion | 12 | 35
 | 12 | 34
 | 12 | 34
 | 12 | 33
2. Appreciative joy | 12 | 35
 | 12 | 34
 | 12 | 34
 | 12 | 33

If you have developed the four protective meditation subjects, apprehend the series of mind-door processes with great wholesome impulsion taking the Buddha’s qualities as object. The impulsion mentality belongs to the faith-and-wisdom group. Recollection of the Buddha reaches access concentration only, so there are just seven impulsion moments. Registration may or may not follow. The Buddha’s qualities…


<a id="M04-body-P129"></a>
## The Buddha’s qualities as mind-door objects
Miến / Burmese 129

… include both mundane and supramundane qualities. For example, the Buddha’s generosity, virtue, concentration up to access, insight knowledge, teaching knowledge and omniscience, in terms of actual phenomena, are series of unprompted, knowledge-associated great functional impulsions of the sense sphere. If recollection takes such qualities as object, registration has an opportunity to follow the meditator’s great wholesome impulsion because the object is sense-sphere. With a clear object registration may occur, and with an indistinct one it does not. It is very difficult, however, to penetrate the Buddha’s qualities to the level of ultimate reality.

The Buddha’s absorption concentration and direct knowledges are exalted functional phenomena. His path and fruition knowledges are supramundane wisdom. When recollection takes these exalted or supramundane qualities of concentration and wisdom as object, registration cannot follow the meditator’s great wholesome impulsion because the object is outside the sense sphere.

If registration occurs, it may be rooted or rootless as appropriate. However, “atikuddake pana somanassasahagatāneva santīraṇatadārammaṇāni”: with an exceptionally desirable object, investigating and registration are accompanied only by joy. The Buddha’s qualities are exceptionally desirable, so only one of the five joyful registrations can occur as appropriate.


<a id="M04-body-P130"></a>
## Recollection of death
Miến / Burmese 130

Recollection of death also reaches access concentration only. Its meditation impulsions are sense-sphere access impulsions and occur seven times. Registration may or may not follow. If one takes the cutting off of one’s life faculty as object, that life faculty consists of material life and the mental life associated with death consciousness, so the object is sense-sphere. If it is clear, there is opportunity for registration. If indistinct, there is none.

If one cannot take the cutting off of the life faculty as object and remains only with the concept “I am dying”, registration cannot follow those impulsions of recollection of death. Only one who has apprehended mentality and materiality at the level of ultimate reality can take the cutting off of material and mental life at that level. For one who has yet to attain such knowledge of delimiting mentality and materiality, the mind in recollection of death will generally remain with the concept “I am dying”.


<a id="M04-body-P131"></a>
## Mind-door process table for recollection of the Buddha and death
Miến / Burmese 131

Recollection of the Buddha and death. Supporting materiality in the heart: 54.
Subject | Mind-door adverting | Impulsion (7 times) | Rooted registration (2 times) (8) | Rootless registration (2 times)
1. Recollection of the Buddha | 12 | 34 | 34 | 12
 | 12 | 33 | 34 | 12
 | 12 | 33 | 33 (with joy) | 12
 | 12 | 32 | 33 (with joy) | 12
2. Recollection of death | 12 | 34 | 34 | 12/11
 | 12 | 33 | 33 | 11/11
 | 12 | 33 | 33 | 12/11
 | 12 | 32 | 32 | 11/11

Note: In recollection of the Buddha it is very difficult for joyful registration to arise after equanimous impulsion. Since the object is exceptionally desirable, equanimous registration also has no opportunity to follow equanimous impulsion. Apprehend the phenomena in practice to know for certain.

A person who has developed recollection of the Buddha and wishes to apprehend mentality taking his qualities as object should: 1. Apprehend the clear life-continuum, the mind-door. 2. Direct the mind to a quality of the Buddha you favour. 3. When that quality appears at the mind-door, apprehend the mentality in the resulting series of mind-door processes with impulsion.


<a id="M04-body-P132"></a>
## From recollection of death to five-door processes
Miến / Burmese 132

A meditator who has developed recollection of death and wishes to apprehend mentality taking the severing of their life faculty as object should: 1. Apprehend the clear life-continuum, the mind-door. 2. Direct the mind to the severing of your life faculty. 3. When that object appears at the mind-door, apprehend the mentality in the resulting series of mind-door processes with impulsion. When apprehending mentality taking a Buddha quality or death as object, you may extend the discernment according to your wisdom.

The foregoing presented the method for apprehending mind-door process series with great wholesome impulsion in the domain of mind objects. Next comes the method for apprehending mentality in five-door processes with great wholesome impulsion.

Tattha ekekaṃ ārammaṇaṃ dvisu dvisu dvāresu āpāthamāgacchati. Rūpārammaṇañhi cakkhupasādaṃ ghaṭṭetvā taṅkhaṇaññeva manodvāre āpāthamāgacchati, bhavaṅgacalanassa paccayo hotīti attho. Sadda-gandha-rasa-phoṭṭhabbārammaṇesupi eseva nayo. Yathā hi sakuṇo ākāsenāgantvā rukkhagge nilīyamānova rukkhasākhaṃ ghaṭṭeti, chāyā cassa pathaviyaṃ paṭihaññati, sākhāghaṭṭana-chāyāpharaṇāni apubbaṃ acarimaṃ ekakkhaṇeyeva bhavanti. Evaṃ paccuppannarūpādīnaṃ cakkhupasādādighaṭṭanānañca bhavaṅga-
Quotation continued on Burmese page 133.

Points to know beforehand. One object comes into range at two doors. A visible object impinges on eye-sensitivity and at the same time enters the range of the mind-door, meaning that it causes the life-continuum to vibrate. Sounds, odours, tastes and tangibles follow the same pattern. As a bird descending from the sky alights on a branch and its shadow simultaneously appears on the ground, its touch and shadow occur together…


<a id="M04-body-P133"></a>
## One object appears simultaneously at two doors
Miến / Burmese 133

calanasamatthatāya manodvāre āpāthagamanāñca apubbaṃ acarimaṃ ekakkhaṇeyeva hoti. Tato bhavaṅgaṃ vicchinditvā cakkhudvārādīsu uppannānaṃ āvajjanādīnaṃ voṭṭhabbanapariyosānānaṃ anantarā tesaṃ ārammaṇānaṃ aññatarasmiṃ idaṃ mahācittaṃ uppajjati.
Abhidhamma Commentary, vol. 1, p. 114.

… so too, when a visible object impinges on eye-sensitivity and can cause the life-continuum to vibrate, impingement and coming into mind-door range occur simultaneously. After the life-continuum stops, following adverting and other consciousnesses and their associated phenomena, a great wholesome consciousness arises taking one of those objects (Abhidhamma Commentary, vol. 1, p. 114).
Āpāthamāgacchati manasā pañcaviññāṇehi ca gahetabbabhāvūpagamanena. Ghaṭṭetvā paṭimukhabhāvāpāthaṃ gantvā.
“Comes into range” means becoming accessible to the mind and the five sense consciousnesses. “Impinges” means coming into range directly before the corresponding door. (Mūlaṭīkā, vol. 1, p. 70.)

1. A visible object appears at the eye-door and mind-door. 2. A sound appears at the ear-door and mind-door. 3. An odour appears at the nose-door and mind-door. 4. A taste appears at the tongue-door and mind-door. 5. A tangible object appears at the body-door and mind-door. Thus each object appears simultaneously at two doors. When the object appears, sense consciousness such as eye-consciousness and mind consciousness such as five-door adverting arise in the fixed order of the process. The object must therefore appear at the corresponding sense door for sense consciousness to know it, and at the life-continuum, the mind-door, for mind consciousness to know it.

When a visible object impinges on eye-sensitivity, it appears at that very time at the life-continuum, the mind-door, and makes it vibrate. Understand the same for sound, odour, taste…


<a id="M04-body-P134"></a>
## The simile of the alighting bird and its shadow
Miến / Burmese 134

… and tangible objects (Abhidhamma Commentary, vol. 1, p. 114). The commentary uses “ghaṭṭetvā”, meaning touching or striking. One might think a visible object actually strikes both the eye-door and mind-door. This refers to the object and door coming close enough to have the effect of impingement (Mūlaṭīkā, vol. 1, p. 70).

For example, a bird flying down lands on a branch. As the bird touches the branch, its shadow touches the ground. The two occur simultaneously, neither before nor after the other. Likewise, a present visible object impinges on eye-sensitivity and comes before the mind-door by its ability to make the life-continuum vibrate. The two occur simultaneously, neither before nor after. After the life-continuum vibrates and ceases, following the process consciousnesses from adverting through determining at the eye-door or the other sense doors, the first great wholesome consciousness arises to perform impulsion regarding one of the objects such as visible form, according to how it is attended to (Abhidhamma Commentary, vol. 1, p. 114).


<a id="M04-body-P135"></a>
## Eye-door process abbreviations and past life-continuum
Miến / Burmese 135

The eye-door process abbreviations denote past life-continuum (atītabhavaṅga), vibration of the life-continuum (bhavaṅgacalana) as an object appears at the mind-door, arrest of the life-continuum (bhavaṅgupaccheda) as that object appears, five-door adverting to the object present at both doors, eye-consciousness knowing visible form in dependence on the eye-base, receiving the object of eye-consciousness, investigating it, determining it, successive impulsions experiencing its flavour, and registration continuing with that same object.

Past life-continuum. A visible object cannot appear at the eye-door and mind-door the instant it arises. It can appear only after one or several consciousness moments have passed. The life-continuum moments elapsed between its arising and its appearance at the two doors are called past life-continuum. Life-continuum before that object arises is marked separately. This does not imply that there are consciousness moments when no visible materiality arises at all, since materiality originated by kamma, consciousness, temperature or nutriment that includes visible form can generally arise during the arising, presence and dissolution of consciousness. Here the reference is only to the visible object capable of appearing at the eye-door and mind-door.


<a id="M04-body-P136"></a>
## Eye-door processes ending in registration or impulsion
Miến / Burmese 136

Very great object — process ending in registration
Stage | Object and sequence of consciousness
Life-continuum | Kamma, a kamma sign, or a destination sign. Life-continuum before the visible object → past life-continuum ×1 → vibration → arrest.
Eye-door process | Present visible object. Five-door adverting → eye-consciousness → receiving → investigating → determining ×1 → impulsion ×7 → registration ×2 → life-continuum.
Short-lived eye-sensitivity | 37
Medium-lived eye-sensitivity | 1
Long-lived eye-sensitivity | 11

Great object, first type — process ending in impulsion
Stage | Object and sequence of consciousness
Life-continuum | Kamma, a kamma sign, or a destination sign. Life-continuum before the visible object → past life-continuum ×2 → vibration → arrest.
Eye-door process | Present visible object. Five-door adverting → eye-consciousness → receiving → investigating → determining ×1 → impulsion ×7 → life-continuum.
Short-lived eye-sensitivity | 34
Medium-lived eye-sensitivity | 1
Long-lived eye-sensitivity | 14


<a id="M04-body-P137"></a>
## Eye-door processes with a great object of the second type and a slight object of the first type
Miến / Burmese 137

Great object, second type — process ending in impulsion
Stage | Object and sequence of consciousness
Life-continuum | Kamma, a kamma sign, or a destination sign. Life-continuum before the visible object → past life-continuum ×3 → vibration → arrest.
Eye-door process | Present visible object. Five-door adverting → eye-consciousness → receiving → investigating → determining ×1 → impulsion ×7 → life-continuum.
Short-lived eye-sensitivity | 31
Medium-lived eye-sensitivity | 1
Long-lived eye-sensitivity | 17

Slight object, first type — process ending in determining
Stage | Object and sequence of consciousness
Life-continuum | Kamma, a kamma sign, or a destination sign. Life-continuum before the visible object → past life-continuum ×4 → vibration → arrest.
Eye-door process | Present visible object. Five-door adverting → eye-consciousness → receiving → investigating → determining ×2 → life-continuum.
Short-lived eye-sensitivity | 28
Medium-lived eye-sensitivity | 1
Long-lived eye-sensitivity | 20


<a id="M04-body-P138"></a>
## Eye-sensitivity of medium duration
Miến / Burmese 138

In the very-great-object process, one past life-continuum moment has elapsed. Eye-sensitivity arising simultaneously with that past life-continuum is called medium-lived (majjhimāyuka). In the first great-object process there are two past life-continuum moments. Eye-sensitivity arising with the first of them is called medium-lived. In the second great-object process there are three past life-continuum moments. The first to sixth slight-object processes have four, five, six, seven, eight, and nine respectively. Counting from the life-continuum, the eye-sensitivity arising with the first past life-continuum is called medium-lived.

From rebirth-linking through the seventeenth consciousness counting back from death consciousness, kamma-born materiality, including eye-sensitivity, arises continuously at the arising, presence and dissolution submoments of each consciousness throughout life. Depending on the strength of kamma, many clusters of each kind may arise at each submoment, including many eye-decads. When eye-consciousness occurs, their eye-sensitivities may be arising, present, or dissolving. Eye-consciousness mentality arises dependent on the strongest medium-lived eye-sensitivity among them.

Sensitivities described as short-lived, long-lived and medium-lived all last seventeen consciousness moments. The names indicate their duration relative to the five-door object of the five-door process…


<a id="M04-body-P139"></a>
## Three groups of sensitivity and the base of mind consciousness
Miến / Burmese 139

… according to whether they cease with, before, or after the object. In a very-great-object eye-door process, eye-sensitivity arising at the arising submoment of the past life-continuum ceases with the visible object that impinges on it, so is called medium-lived. Thirty-seven eye-sensitivities arising in moments before that past life-continuum cease before the visible object and are called short-lived. Eleven arising from the presence submoment of that past life-continuum through subsequent moments are still present when the visible object ceases and are called long-lived. Understand the same for the other eye-door processes and for ear-door processes and the rest.

The five sense consciousnesses depend on sensitivity materiality that arose earlier and is still present when they arise, by the prenascence dependence condition. Of the three types of sensitivity, the Abhidhamma subcommentary determines that the five sense consciousnesses depend on the medium-lived type. The view that they depend on sensitivity arising with five-door adverting or with arrest of the life-continuum is rejected (Vīthipāṭha, pp. 2–3).

For mind consciousness in an existence with five aggregates, rebirth-linking consciousness depends on the heart-base that arises with it. All mind consciousness from the life-continuum onward, including five-door adverting, receiving, investigating, determining, impulsion and registration, as well as mind-door adverting, impulsion and registration in mind-door processes, depends on the heart-base arising with the immediately preceding consciousness. On emerging from cessation attainment…


<a id="M04-body-P140"></a>
## Which heart-base supports each consciousness
Miến / Burmese 140

… non-returner fruition or arahant fruition depends on the heart-base that arose one consciousness moment earlier. Near death, life-continuum, adverting and similar mind consciousnesses depend on the heart-base arising with the seventeenth consciousness counting back from death consciousness (Visuddhimagga, vol. 2, p. 279). Remember the following cases.

Heart-base serving as support
Consciousness | Depends on heart-base arising with
1. Rebirth-linking | That same consciousness
2. First life-continuum | Rebirth-linking
3. Second life-continuum | First life-continuum
4. Five-door adverting | Arrest of the life-continuum
5. Receiving | Sense consciousness
6. Investigating | Receiving
7. Determining | Investigating
8. First impulsion | Determining… pe…
9. Seventh impulsion | Sixth impulsion
10. First registration | Seventh impulsion
11. Second registration | First registration

Remember these respective dependencies. Understand the mind-door processes in the same way.


<a id="M04-body-P141"></a>
## Operation of five-door and mind-door processes
Miến / Burmese 141

Usually, in five-door processes and mind-door processes with sense-sphere impulsion, impulsion occurs seven times and registration twice. Each other process consciousness occurs once. After five-door processes such as the eye-door process, many mind-door processes can occur interspersed with life-continuum. The first is called the following mind-door process (tadanuvattaka). From the second mind-door process onward, the succeeding processes are called bare mind-door processes. Some teachers call them all following mind-door processes. The tables here simply say “mind-door process”.

Pañcamajavanepi … pe … na hotīti idaṃ pañcaviññāṇavīthiyaṃ itthipurisoti rajjanādīnaṃ abhāvaṃ sandhāya vuttaṃ. Tattha hi āvajjanavoṭṭhabbanānaṃ ayoniso āvajjanavoṭṭhabbanavasena iṭṭhe itthirūpādimhi lobho, aniṭṭhe ca paṭigho uppajjati. Manodvāre pana itthipurisoti rajjanādi hoti.
The statement “even at the fifth impulsion … pe … it does not occur” refers to the absence, in the five-sense process, of lust and related reactions towards an object recognized as “woman” or “man”. In that process, unwise adverting and determining can give rise to greed for a desirable object such as a woman’s visible form, or to aversion towards an undesirable object. It is at the mind-door that lust and related reactions occur towards an object recognized as “woman” or “man”. (Mūlaṭīkā, vol. 2, p. 188.)

Tatthāyaṃ pavattikkamo, pañcadvāre rūpādiārammaṇe āpāthagate niyamitādivasena kusalākusalajavane uppajjitvā bhavaṅgaṃ otiṇṇe manodvārikajavanaṃ taṃyevārammaṇaṃ katvā bhavaṅgaṃ otarati. Puna tasmiṃyeva dvāre itthipurisotiādinā vavatthapetvā javanaṃ uppajjitvā bhavaṅgaṃ otarati. Puna vāre pasādarajjanādivasena javanaṃ javati.
Anuṭīkā, vol. 1, p. 200.

In that sequence, at the five doors, when a visible object or the like enters range, wholesome or unwholesome impulsion arises through determination and related conditions, and the mind then subsides into life-continuum. The next mind-door process takes the same object, runs and returns to life-continuum. A further mind-door process identifies the entity in terms such as “female” or “male”, runs and returns to life-continuum. On a further turn, impulsion runs through faith, lust and similar conditions (Anuṭīkā, vol. 1, p. 200).


<a id="M04-body-P142"></a>
## The first processes from visible form to recognition of colour
Miến / Burmese 142

Saññaṃ paṭhamavīthena, tītaṃ dutiyacetasā. Nāmaṃ tatiyavīthena, atthaṃ catutthacetasā.
Perception in the first process, the past object in the second consciousness, the name in the third process, and the meaning in the fourth consciousness.

1. When visible form comes before the eye-door and mind-door, an eye-door process with wholesome or unwholesome impulsion arises in accordance with prior determination, such as “I will give rise only to the wholesome”, or the reverse. The mental phenomena in the eye-door process know only the colour of visible form and have yet to recognize a man, woman, pot, or cloth. At this point object and door merely meet. Wise attention can lead to wholesome impulsion, and unwise attention to unwholesome impulsion. These impulsions still take only the colour of the visible object, based on prior determination and other conditions.

2. After the eye-door process comes a mind-door process called the following mind-door process. It can take only the past visible object taken by the eye-door process. Wholesome or unwholesome impulsion may arise as appropriate. Counting the eye-door process, this is the second process. Registration may or may not occur.
3. After the second process comes a third, called the third bare mind-door process. This process…


<a id="M04-body-P143"></a>
## Recognizing colour, convention, and the entity
Miến / Burmese 143

… knows that same past visible form as brown, yellow, blue, and so on. The first two processes know colour only. At the third process one distinguishes the particular colours. This process differentiates the past visible object seen through the previous two processes. Registration may or may not arise. Wholesome or unwholesome impulsion may occur according to wise or unwise attention.

4. The fourth bare mind-door process relies on the visible object seen and distinguished through the first three processes to know conventional entities such as man, woman, pot, cloth, robe, gold and silver. With a concept as object, registration has no opportunity to arise. If it takes only ultimate reality and continues to know just the colour of the visible object, registration may occur. Wholesome or unwholesome impulsion again depends on the manner of attention.

5. In the fifth bare mind-door process the particular conceptual entity can be distinguished as a man, woman, pot, cloth, gold, or silver. With wise attention, faith may arise. With unwise attention, attachment and affection may arise. An able insight meditator may take only ultimate colour in this process, giving registration an opportunity to occur. If the object is solely a concept, there is no such opportunity.


<a id="M04-body-P144"></a>
## Four conditions for wholesome impulsion
Miến / Burmese 144

1. Determination (niyamita): deciding firmly to apply the mind to the wholesome, thinking “I should do only what is wholesome.” Wholesome impulsion arises through the strength of the mind resolved to practise generosity, virtue, meditation and other good deeds.

2. Inclination (pariṇāmita): drawing the mind away from the unwholesome and inclining it only to good deeds. Wholesome impulsion arises through the strength of the mind so inclined.
3. Habitual practice (samudācāra): continually practising generosity, virtue, tranquillity and insight and training the mind to occur continuously in wholesome states. Wholesome impulsion arises through the strength of the mind habituated to the wholesome.

4. Wise attention (ābhoga): living in a suitable place where the Triple Gem flourishes and good people live, relying on good persons such as the Buddha, hearing the true Dhamma concerning the Four Noble Truths, and having previously made merit. Owing to these conditions one knows how to attend by the right means and on the right path. Wholesome impulsion arises through the strength of this wise attention. Through these conditions wholesome impulsion arises (Abhidhamma Commentary, vol. 1, p. 117).


<a id="M04-body-P145"></a>
## Four wholesome conditions and discerning the visible-object group
Miến / Burmese 145

One who has resolved, “Whatever object I encounter, I will give rise only to wholesome consciousness,” has wholesome consciousness. One who guards the mind against the unwholesome and inclines it to the wholesome has wholesome consciousness. One already habituated to wholesome consciousness also commonly has wholesome consciousness. One able to attend in the right way in any undertaking, that is, with wise attention, also commonly has wholesome consciousness. Owing to these four conditions, even on encountering an attractive sign or desirable object, wholesome consciousness arises in place of greed.

The wholesome visible-object group. Mentality taking visible form as object comprises eye-door and mind-door mentality. After one eye-door process, many mind-door processes can arise, with numerous life-continuum moments intervening. The commentary to the Meghiya Sutta says that in an extremely brief interval, such as a blink, flash of lightning or snap of the fingers, countless consciousnesses can arise and cease (Aṅguttara Commentary, vol. 2, p. 325). Many eye-door and mind-door processes can therefore occur in such a short time.

Some of those processes can be discerned and others cannot yet be discerned. Use wisdom to analyse and break down the compactness of mentality, apprehending the processes that you can discern and catch until ultimate phenomena are seen…


<a id="M04-body-P146"></a>
## Four process types according to the remaining duration of the object
Miến / Burmese 146

… The four kinds of compactness of mentality are explained on pp. 209–217 of this book. Depending on the object’s remaining lifespan when the meditator catches it, there are four cases.

1. Only life-continuum vibration occurs (moghavāra).
2. The process goes as far as determining (voṭṭhabbanavāra).
3. It reaches impulsion (javanavāra).
4. It reaches registration (tadārammaṇavāra).

Of the four types, the sample tables use the registration process as the main example. Meditators can gradually understand the other processes as they discern. The Aṭṭhasālinī calls the first three the first, second and third abortive courses, since they respectively lack process consciousness, impulsion and registration (Abhidhamma Commentary, vol. 1, p. 130).


<a id="M04-body-P147"></a>
## Wholesome-group table taking colour as object
Miến / Burmese 147

Visible object — eye-door, intervening life-continuum, and mind-door. Supporting materiality: fifty-four at the eye or heart as indicated in the source table.
Five-door adverting | Eye-consciousness | Receiving | Investigating | Determining | Impulsion (7) | Registration (2) | Life-continuum | Mind-door adverting | Impulsion (7) | Registration (2)
11 | 8 | 11 | 12 | 12 | 34 | 34/12/11 | 34 | 12 | 34 | 34/12/11
11 | 8 | 11 | 11 | 12 | 33 | 33/11/11 | 34 | 12 | 33 | 33/11/11
11 | 8 | 11 | 12 | 12 | 33 | 33/12/11 | 34 | 12 | 33 | 33/12/11
11 | 8 | 11 | 11 | 12 | 32 | 32/11/11 | 34 | 12 | 32 | 32/11/11

Mind-door — further modes of discernment
Mode of discernment | Mind-door adverting | Impulsion (7) | Registration (2)
2. As materiality | 12 | 34 (33 / 33 / 32) | 34 (33 / 33 / 32), 12/11
3. As impermanent | 12 | 34 (33 / 33 / 32) | 34 (33 / 33 / 32), 12/11
4. As suffering | 12 | 34 (33 / 33 / 32) | 34 (33 / 33 / 32), 12/11
5. As non-self | 12 | 34 (33 / 33 / 32) | 34 (33 / 33 / 32), 12/11
6. As unattractive | 12 | 34 (33 / 33 / 32) | 34 (33 / 33 / 32), 12/11


<a id="M04-body-P148"></a>
## How to apprehend eye-door and mind-door processes taking colour
Miến / Burmese 148

To apprehend eye-door and mind-door processes arising with visible form as object, proceed as follows.
1. Re-establish a previously attained fourth-jhāna concentration in sequence.
2. Apprehend the two doors together so that they appear clearly: eye-sensitivity as the eye-door and the clear life-continuum as the mind-door.
3. Direct the mind to the colour of many material clusters or of a single cluster.
4. When that colour appears simultaneously at the eye-door and mind-door, an eye-door process arises and mind-door processes continue to take the same visible object.
5. Adverting, determining and mind-door adverting in those processes turn to and determine it simply as visible form, or colour. With wise attention, wholesome impulsions arise. The mentality in wholesome impulsion and registration, such as the set of thirty-four, belongs to the faith-and-wisdom group.

One view holds that eye-door process mentality can take only the colour of many material clusters as object. A mind-door process can know the colour of one cluster or of many clusters. This is why both cases, the visible form of many clusters and of a single cluster, are stated here.


<a id="M04-body-P149"></a>
## Limits of sense consciousness and the following mind-door process
Miến / Burmese 149

Pañcahi viññāṇehi na kañci dhammaṃ paṭivijānāti aññatra abhinipātamattā. Pañcannaṃ viññāṇānaṃ samanantarāpi na kañci dhammaṃ paṭivijānāti.
With the five consciousnesses one does not recognize any phenomenon beyond mere impingement. Immediately after the five consciousnesses one still does not recognize any phenomenon in that way (Abhidhamma, vol. 2, p. 123).

According to this Pāli passage and the commentaries and subcommentaries on the Vibhaṅga, five-door process series with impulsion only know the meeting of door and object, namely the object coming before the respective door. They know only colour, sound, odour, taste or touch, and cannot yet distinguish white, red, yellow, blue and the like. Adverting and determining in the five-door process and mind-door adverting in the following mind-door process therefore cannot yet distinguish the object by such categories. That ability comes in later mind-door processes. The consciousnesses at adverting and determining in the five-door and following processes are called so because they operate in a way resembling decision.

Practise seeing knowing consciousness in each moment: five-door adverting, eye-consciousness, receiving, investigating, determining, seven impulsions and two registrations. Many intervening life-continuum moments follow, then mind-door adverting, seven impulsions and two registrations…


<a id="M04-body-P150"></a>
## Gradually increasing the number of mental factors apprehended
Miến / Burmese 150

Practise repeatedly, apprehending together the two doors, eye-sensitivity and the clear life-continuum, along with the visible object. When one eye-door process arises, many mind-door processes continue to take visible form, with many life-continuum moments between them. Practise until you distinguish these processes by wisdom. Once you can apprehend each process consciousness, add mental factors one by one, such as contact and feeling, in groups of two, three, four, five, six, seven, eight, and so on. When you clearly see them arising together in each moment, discern consciousness and mental factors as set out in the table. You may begin from contact or feeling similarly. If not yet successful, repeatedly return to apprehending materiality. When the wisdom apprehending materiality becomes clear and free of confusion, mental phenomena naturally become clear to the meditator’s wisdom, as instructed in the Visuddhimagga (vol. 2, p. 223).

Concrete and non-concrete materiality. In these processes eye-consciousness depends only on the eye-base, the medium-lived eye-sensitivity. The other mental phenomena in the eye-door and mind-door processes depend on the heart-base that arose with their respective immediately preceding consciousness. The table therefore also gives the supporting materiality. According to the method in the discourse, one must analyse with wisdom until compactness is broken down and apprehend ultimate materiality, so with regard to the base…


<a id="M04-body-P151"></a>
## Supporting materiality, life-continuum, and wise attention
Miến / Burmese 151

… apprehend all discernible elemental and derived materiality together with the supporting materiality, rather than only bases such as the eye-base. The first part of the Majjhima Commentary (vol. 1, p. 281) and similar sources instruct apprehension in this way. The tables emphasize concrete materiality. At the stage of knowledge delimiting mentality and materiality, also apprehend any non-concrete materiality you can discern. At the insight stage set aside non-concrete materiality and discern concrete materiality alone.

The table gives thirty-four life-continuum mental phenomena for a person with three-rooted rebirth-linking accompanied by joy. For a person with three-rooted rebirth-linking accompanied by equanimity, the life-continuum group contains thirty-three. Life-continuum takes just one of three objects: kamma, a kamma sign, or a destination sign, which appeared as the object of impulsion near death in the preceding existence. Once you can discern the past life-continuum object as indicated, include the life-continuum moments interspersed between the process series. At the beginning of apprehending mentality, if you cannot yet discern its actual object, you may temporarily set life-continuum mentality aside.

Wise attention. 1. When discerning visible form, or colour, as visible form or colour, an eye-door process knowing colour arises, together with the following mind-door process and bare mind-door processes. The method of apprehension has already been given. Further, mind-door adverting in the mind-door process…


<a id="M04-body-P152"></a>
## Ways of attending wisely to visible form
Miến / Burmese 152

2. When discerning that visible object as materiality, apprehend the mind-door process consciousnesses that know it as materiality.
3. When taking its arising and passing away as object, seeing by wisdom and discerning it as impermanent, apprehend the mind-door process consciousnesses that know it as impermanent.
4. When taking its continual oppression by arising and passing away as object, seeing by wisdom and discerning it as suffering, apprehend the mind-door process consciousnesses that know it as suffering.

5. When taking its lack of an indestructible, enduring, permanent self with substance as object, seeing by wisdom and discerning that visible object as non-self, apprehend the mind-door process series that know it as non-self.
6. When taking its unattractive and repulsive nature through being mixed with unpleasant colours and smells as object, seeing by wisdom and discerning the visible object as unattractive, apprehend the mind-door process consciousnesses that know it as unattractive. Continue apprehending these mental phenomena.

Eye-door process consciousnesses can know visible form only as visible form, or colour. They cannot know that colour as materiality, impermanent, suffering, non-self, or unattractive. Mind-door process consciousnesses can know that visible form as visible form or colour…


<a id="M04-body-P153"></a>
## Why mentality is apprehended in six ways
Miến / Burmese 153

… or as materiality, impermanent, suffering, non-self, or unattractive.

Apprehend the mentality taking visible form as object in six rounds to understand how wholesome impulsion arises through wise attention. Another reason is to prepare for insight practice, including comprehension by groups (kalāpasammasana) in the Visuddhimagga, vol. 2, pp. 260–264, and the sections on subsequent knowledges.

Ñātañca ñāṇañca ubhopi vipassati.
One discerns with insight both what is known and the knowledge (Visuddhimagga, vol. 2, p. 278).

According to the determination of the ancient commentators, discern both with insight: what is known (ñāta), the phenomena of the truths of suffering and its origin to be penetrated by insight knowledge, and the knowledge (ñāṇa), the consciousness and mental factors in the mind-door process with insight impulsion, including the wisdom that discerns. Since the consciousness and mental factors in the insight process itself must also later be discerned, this prepares for discerning insight knowledge and its associated mentality. For these two reasons, apprehend the six rounds described above. Each round has four cases, twenty-four in all.

Here too, according to the Sammohavinodanī commentary, registration cannot follow insight impulsions taking the characteristics of impermanence, suffering, and non-self of formations as object…


<a id="M04-body-P154"></a>
## Registration after insight impulsion and the table of mental factors
Miến / Burmese 154

… and therefore some works omit registration after the insight impulsions knowing impermanence, suffering, and non-self. However, according to the Paṭṭhāna and commentary, registration still has an opportunity to occur after insight impulsions that are weak. Therefore, following insight impulsion, apprehend mentality according to the case with registration if it occurs, and according to the case without registration if it does not.

Counts of consciousness and mental factors
Five-door adverting | Eye-consciousness | Receiving | Investigating | Determining
11 | 8 | 11 | 12/11 | 12
1. Knowing consciousness | Knowing consciousness | Knowing consciousness | Knowing consciousness | Knowing consciousness
2. Contact | Contact | Contact | Contact | Contact
3. Feeling | Feeling | Feeling | Feeling | Feeling
4. Perception | Perception | Perception | Perception | Perception
5. Volition | Volition | Volition | Volition | Volition
6. One-pointedness | One-pointedness | One-pointedness | One-pointedness | One-pointedness
7. Life faculty | Life faculty | Life faculty | Life faculty | Life faculty
8. Attention | Attention | Attention | Attention | Attention
9. Applied thought |  | Applied thought | Applied thought | Applied thought
10. Sustained thought |  | Sustained thought | Sustained thought | Sustained thought
11. Decision |  | Decision | Decision | Decision
12 |  |  | Joy* | Energy


<a id="M04-body-P155"></a>
## Explaining the mental counts in the eye-door process
Miến / Burmese 155

Five-door adverting has eleven instances of consciousness and mental factors and is always accompanied by equanimity. Eye-consciousness has eight and is always accompanied by equanimity. Receiving has eleven and is always accompanied by equanimity. Investigating accompanied by joyful feeling has twelve, because joy is present. In the second row investigating is accompanied by equanimity, so joy is absent and there are eleven. Determining has twelve and is always accompanied by equanimity.

The thirty-four at impulsion are the thirty-four mental phenomena of the faith-and-wisdom group. 1. With knowledge and joy: thirty-four, accompanied by joyful feeling. 2. With knowledge and without joy: thirty-three, accompanied by equanimous feeling. 3. Without knowledge and with joy: thirty-three, accompanied by joyful feeling. 4. Without knowledge or joy: thirty-two, accompanied by equanimous feeling.

For registration remember the four cases as for impulsion. However, when registration is rootless investigating accompanied by joy it has twelve instances of consciousness and mental factors. When investigating is accompanied by equanimity it has eleven. With an undesirable object it is unwholesome resultant, and with a desirable object it is wholesome resultant, as appropriate. If registration is great resultant, discern the same four cases as at impulsion.


<a id="M04-body-P156"></a>
## Apprehending wholesome mentality taking sound as object
Miến / Burmese 156

Mind-door adverting is the same as determining and is accompanied by equanimous feeling.

Note. Investigating, impulsion, and registration generally share the same kind of feeling. If impulsion is joyful, investigating and registration usually have joyful feeling. If impulsion is equanimous, they usually have equanimous feeling. With great wholesome impulsion, registration is usually great resultant. The table follows this general rule (see Abhidhamma Commentary, vol. 1, pp. 130–131). The following briefly explains how to apprehend the sound group and the subsequent groups.

To seek and apprehend mentality in ear-door and mind-door processes with wholesome impulsion taking sound as object, proceed as follows.
1. If needed, re-establish your attained concentration in stages.
2. Apprehend together the ear-sensitivity, the ear-door, and the clear life-continuum, the mind-door.

3. Direct the mind to a sound you can hear, whether internal or external.
4. When the sound simultaneously impinges on, or comes before, the ear-door and mind-door, five-door adverting, ear-consciousness, receiving, investigating, determining, seven impulsions and two registrations arise. This is the ear-door process…


<a id="M04-body-P157"></a>
## Six ways of attending to sound
Miến / Burmese 157

… followed by mind-door processes with mind-door adverting, seven impulsions and two registrations. Five-door adverting and determining, or mind-door adverting, attend to sound in the following ways. The first knows it as sound. The other five belong to mind-door adverting.

1. As sound.
2. As materiality.
3. As impermanent.
4. As suffering.
5. As non-self.
6. As unattractive.

Discern each mode separately. With wise attention, wholesome impulsion arises. For each mode discern four cases, varying the presence or absence of knowledge and joy. This makes twenty-four rounds in all.

Note. Re-establish concentration when needed. At the start of each sitting, re-establish concentration, up to fourth jhāna if possible. If one establishment allows continuous apprehension of mentality and materiality throughout the sitting, there is no need to repeat it. Repeat it only when apprehension becomes difficult. If you can apprehend continuously across all six groups beginning with visible form, continue. An adept may need to re-establish concentration only once per sitting.


<a id="M04-body-P158"></a>
## Apprehending wholesome mentality taking odour as object
Miến / Burmese 158

Understand the same when apprehending mentality in the odour group and those that follow.

To seek and apprehend mentality in nose-door and mind-door processes with wholesome impulsion taking odour as object, proceed as follows.
1. If needed, re-establish your attained concentration in stages.
2. Apprehend together the nose-sensitivity, the nose-door, and the clear life-continuum, the mind-door.

3. Direct the mind to the odour of many material clusters or of a single cluster.

4. When odour impinges on, or appears before, the nose-door and mind-door simultaneously, the nose-door process arises with five-door adverting, nose-consciousness, receiving, investigating, determining, seven impulsions and two registrations. It is followed by mind-door processes with mind-door adverting, seven impulsions and two registrations, with many life-continuum moments between processes.

Five-door adverting and determining, or mind-door adverting, know the odour: 1. As odour. 2. As materiality. 3. As impermanent. 4. As suffering…


<a id="M04-body-P159"></a>
## Apprehending wholesome mentality taking taste as object
Miến / Burmese 159

5. As non-self.
6. As unattractive.

Discern each mode separately. With wise attention, wholesome impulsion arises. For each mode discern four cases, varying the presence or absence of knowledge and joy. This makes twenty-four rounds in all.

To seek and apprehend mentality in tongue-door and mind-door processes with wholesome impulsion taking taste as object, proceed as follows.
1. If needed, re-establish your attained concentration in stages.
2. Apprehend together the tongue-sensitivity, the tongue-door, and the clear life-continuum, the mind-door.

3. Direct the mind to the taste of many material clusters or of a single cluster.

4. When taste impinges on, or appears before, the tongue-door and mind-door simultaneously, the tongue-door process arises with five-door adverting, tongue-consciousness, receiving, investigating, determining, seven impulsions and two registrations. It is followed by mind-door processes with mind-door adverting, seven impulsions and two registrations, with many life-continuum moments between processes.

One tongue-door process may be followed by many mind-door processes. Five-door adverting and determining, or mind-door adverting, attend in the following ways.


<a id="M04-body-P160"></a>
## Six ways of attending to taste and beginning to discern tangibles
Miến / Burmese 160

1. As taste.
2. As materiality.
3. As impermanent.
4. As suffering.
5. As non-self.
6. As unattractive.

Discern each mode separately. With wise attention, wholesome impulsion arises. For each mode discern four cases, varying the presence or absence of knowledge and joy. This makes twenty-four rounds in all.

To seek and apprehend mentality in body-door and mind-door processes with wholesome impulsion taking tangibles as object, proceed as follows.
1. If needed, re-establish your attained concentration in stages.
2. Apprehend together the body-sensitivity, the body-door, and the clear life-continuum, the mind-door.

3. Direct the mind to the tangible object of many material clusters or of a single cluster. It is the tangible object in the material clusters immediately adjoining the body-sensitivity, the body-door you are apprehending.


<a id="M04-body-P161"></a>
## Discerning tangibles by three elements
Miến / Burmese 161

There are three kinds of tangible object. Take one of the three elements, earth, fire, or wind, as object and discern it.

4. When the tangible object impinges on, or appears before, the body-door and mind-door simultaneously, the body-door process arises with five-door adverting, body-consciousness, receiving, investigating, determining, seven impulsions and two registrations. It is followed by mind-door processes with mind-door adverting, seven impulsions and two registrations, with many life-continuum moments between processes.

One body-door process may be followed by many mind-door processes. Five-door adverting and determining, or mind-door adverting, know the object in the following six ways.

1. As a tangible object, namely the earth, fire, or wind element.
2. As materiality.
3. As impermanent.
4. As suffering.
5. As non-self.
6. As unattractive.

Discern the six modes separately for each element: six rounds for earth, six for fire, and six for wind. Within each discern the four cases with and without knowledge and joy. The total is 3 × 6 × 4 = 72 rounds.


<a id="M04-body-P162"></a>
## The brain and knowing wisdom
Miến / Burmese 162

Here meditators may test for themselves whether the brain contains the wisdom called the wisdom faculty. According to the Buddha’s Abhidhamma, the brain is a collection of material clusters. Attend closely to the four elements in the brain. The minute material clusters soon become easy to see, since the five kinds of cluster and forty-four kinds of materiality in the brain were already apprehended in the section on materiality. Apprehend those forty-four again, then select and apprehend body-sensitivity.

1. Apprehend body-sensitivity, the body-door, and the clear life-continuum, the mind-door.
2. Apprehend together with them one of the elements of earth, fire, or wind in one or many clusters next to that body-sensitivity.

When such a tangible object comes before and appears simultaneously at the two doors, the body-sensitivity in the brain and the clear life-continuum, body-door process consciousnesses and mind-door process series with impulsion arise taking that same tangible object. In those processes…


<a id="M04-body-P163"></a>
## Body-consciousness, wisdom and feeling
Miến / Burmese 163

… if determining and mind-door adverting attend wisely, determining the object as earth, fire, wind, materiality, impermanent and the like, processes with great wholesome impulsion arise. Each impulsion moment contains thirty-four mental phenomena with knowledge and joy, or thirty-three with knowledge and without joy. These sets of thirty-four or thirty-three arise depending on the heart-base, with the clear life-continuum as door. They include wisdom called the wisdom faculty. Body-consciousness dependent on body-sensitivity in the brain, however, can arise only with the seven universal mental factors, eight mental phenomena altogether. Those eight do not include wisdom. Practise repeatedly to verify this statement yourself.

Note. With a desirable tangible object, body-consciousness is accompanied by pleasant bodily feeling. With an undesirable object, it is accompanied by painful bodily feeling. Apprehend this until it is clear. Beyond body-consciousness, apprehend the distinct feelings, such as joy and equanimity, in each process moment across all six groups.

This completes the explanation of apprehending the wholesome-group mentality with wholesome impulsion in the six domains: visible form, sound, odour, taste, tangibles, and mind objects. When you have become adept at apprehending the mentality associated with wholesome impulsion in all six groups…


<a id="M04-body-P164"></a>
## Four mind-object groups and immaterial jhāna mentality
Miến / Burmese 164

… apprehend them in sequence from visible form to mind objects. For ease of recollection, the processes with wholesome impulsion taking mind objects are divided into four groups.

a. Mentality discerned taking ten or eleven concrete material phenomena as objects.
b. Mentality discerned taking ten non-concrete material phenomena as objects.
c. Mentality of abstinence, immeasurable factors, recollection of the Buddha, and recollection of death.
d. Jhāna mentality.

This concludes apprehending mentality in the group with wholesome impulsion. If you have developed the ten kasiṇas and eight attainments, proceed to apprehend mentality in those attainments. The four immaterial jhānas have only two factors, equanimity and one-pointedness. With applied thought, sustained thought, and joy absent, each has thirty-one mental phenomena.

1. To apprehend the mentality of the base of infinite space, apprehend together the mind-door and the conceptual object of infinite space, then seek and apprehend the jhāna mentality.
2. To apprehend the mentality of the base of infinite consciousness, apprehend the mind-door together with its object, the consciousness of the base of infinite space…


<a id="M04-body-P165"></a>
## Objects of the remaining immaterial jhānas
Miến / Burmese 165

… then seek and apprehend the jhāna mentality.
3. To apprehend the mentality of the base of nothingness, apprehend together the mind-door and the conceptual object “there is nothing”, the absence of the consciousness of the base of infinite space, then seek and apprehend the jhāna mentality.
4. To apprehend the mentality of the base of neither-perception-nor-non-perception, apprehend together the mind-door and its object, the jhāna of the base of nothingness, then seek and apprehend the jhāna mentality.

The following explains how to seek and apprehend mentality in the unwholesome group, with unwholesome impulsion.


<a id="M04-body-P166"></a>
## Part 4. Apprehending unwholesome mentality
Miến / Burmese 166

Does discerning unwholesome phenomena make more unwholesomeness arise? Many meditators ask this. In answer, the Buddha teaches in the Mahāsatipaṭṭhāna Sutta:

Sarāgaṃ vā cittaṃ sarāgaṃ cittanti pajānāti, vītarāgaṃ vā cittaṃ vītarāgaṃ cittanti pajānāti.
One understands a mind with lust as a mind with lust, and a mind free from lust as a mind free from lust (Majjhima Nikāya, vol. 1, p. 56).

When told that the Buddha himself teaches discerning a mind with lust and a mind free from lust in this way, some think the instruction means only to discern lust, hatred, and delusion when they arise of themselves. No conditioned phenomenon arises on its own at will. Conditioned phenomena can arise only when their respective conditions come together and operate. Among the conditions for those conditioned phenomena…


<a id="M04-body-P167"></a>
## The condition for unwholesome impulsion
Miến / Burmese 167

… unwise attention is the nearest condition for unwholesome impulsion. When one encounters an object and attends to it in the wrong way, unwholesome impulsions arise as appropriate. Beings also tend to relish unwholesome phenomena. They take pride in loving a son, delight in loving a daughter, and love grandchildren so much they cannot bear to be parted. They relish their own unwholesomeness again, thinking, “My greed is different from others’ greed, my aversion is different from others’ aversion.” Earlier instances of greed or aversion condition later ones. Greed, aversion and such unwholesome phenomena therefore also need to be discerned with insight. If this is unclear, read the following commentary.

Tattha yogāvacaro kāmavitakkassa padaghātanatthaṃ kāmavitakkaṃ vā sammasati aññaṃ vā kiñci saṅkhāraṃ. Athassa vipassanākkhaṇe vipassanāsampayutto saṅkappo tadaṅgavasena kāmavitakkassa padaghātaṃ padacchedaṃ karonto uppajjati. Vipassanaṃ ussukkāpetvā maggaṃ pāpeti. Athassa maggakkhaṇe maggasampayutto saṅkappo samucchedavasena kāmavitakkassa padaghātaṃ padacchedaṃ karonto uppajjati. Byāpādavitakkassāpi padaghātanatthaṃ byāpādavitakkaṃ vā aññaṃ vā saṅkhāraṃ, vihiṃsāvitakkassa padaghātanatthaṃ vihiṃsāvitakkaṃ vā aññaṃ vā saṅkhāraṃ sammasati. Athassa vipassanākkhaṇeti sabbaṃ purimanayeneva yojetabbaṃ.
Abhidhamma Commentary, vol. 2, p. 100. The explanation continues on Burmese pages 168–169.


<a id="M04-body-P168"></a>
## Discerning three kinds of unwholesome thought
Miến / Burmese 168

There are three unwholesome thoughts: sensual thought, thought of ill will, and thought of harming. To abandon the conditions for sensual thought, thinking and planning about sensuality, the meditator discerns sensual thought or some other formation by one of the three characteristics, impermanence, suffering, and non-self. While discerning, applied thought called right intention arises associated with insight knowledge. Through abandonment by substitution of opposites (tadaṅgappahāna), it strikes down and cuts off the conditions for sensual thought. The meditator strives to bring insight to the noble path. At the path moment, right intention associated with the noble path arises, striking down and cutting off the conditions for sensual thought through eradication (samucchedappahāna).

To abandon the conditions for thought of ill will, thinking and planning to destroy beings, discern thought of ill will or another formation by the three characteristics. To abandon the conditions for thought of harming, thinking and planning to cause beings pain, discern thought of harming or another formation by the three characteristics. While discerning in this way…


<a id="M04-body-P169"></a>
## Abandoning unwholesome thought by substitution and eradication
Miến / Burmese 169

… in the meditator’s continuum, when insight knowledge arises, applied thought called right intention associated with that knowledge arises, striking down and cutting off conditions for ill will and harming through abandonment by substitution of opposites. The meditator strives through the sequence of insight knowledges up to the noble path. At the noble path moment, right intention associated with the path arises, striking down and cutting off the conditions for ill will and harming through eradication (Abhidhamma Commentary, vol. 2, p. 100).

Sensual thought is applied thought associated with greed-rooted consciousness and its mental factors. Ill will and harming are applied thought associated with hatred-rooted consciousness and its mental factors. Discern the greed-rooted groups with sensual thought and the hatred-rooted groups with ill will or harming by the three characteristics. Also discern the other formations. During insight, insight knowledge, or the right intention associated with it, abandons those unwholesome thoughts by substitution of opposites. The noble path arising at the culmination of mature insight eradicates them. This is the meaning of the commentary above.

Thus, discerning unwholesome phenomena with insight serves to abandon them by substitution and by eradication…


<a id="M04-body-P170"></a>
## Four cases of the greed-and-wrong-view group
Miến / Burmese 170

… Understand that the purpose of that discernment is to abandon the unwholesome. First, the following presents the groups of unwholesome mentality that commonly arise.

Greed and wrong view
Component | Count
Knowing consciousness | 1
Ethically variable mental factors | 13
Universal unwholesome mental factors | 4
Greed and wrong view | 2
Total | 20

Four cases associated with wrong view
Case | Mental phenomena
1. Joyful, unprompted | 20
2. Equanimous, unprompted, without joy | 19
3. Joyful, prompted | 20 + sloth and torpor = 22
4. Equanimous, prompted | 19 + sloth and torpor = 21

In these groups, joyful feeling occurs with joy, while equanimous feeling does not. Energy here is the particular effort for greed and wrong view to arise. Desire is the wish for greed and wrong view to arise…


<a id="M04-body-P171"></a>
## The greed-and-conceit group and the hatred group
Miến / Burmese 171

… In other words, energy is striving for greed to arise, while desire is wanting greed to arise. The remaining mental factors may be understood by their respective natures.

The greed-and-conceit group has four cases. Substitute conceit for wrong view in the greed-and-wrong-view group, and the counts remain twenty, nineteen, twenty-two and twenty-one. Conceit is an occasional mental factor and is sometimes absent. When neither conceit nor wrong view occurs, the counts are nineteen, eighteen, twenty-one and twenty respectively. Discern these four cases. Four consciousnesses associated with wrong view and four dissociated from it make eight greed-rooted consciousnesses.

Two cases of the hatred group
Component | Count
Knowing consciousness | 1
Ethically variable mental factors, excluding joy | 12
Universal unwholesome mental factors | 4
Hatred | 1
Unprompted total | 18
Prompted, adding sloth and torpor | 20


<a id="M04-body-P172"></a>
## Hatred with envy, stinginess, or remorse
Miến / Burmese 172

Hatred and envy
Component | Count
Mental phenomena of the hatred group | 18
Envy | 1
Unprompted total | 19
Prompted, adding sloth and torpor | 21

Hatred and stinginess
Component | Count
Mental phenomena of the hatred group | 18
Stinginess | 1
Unprompted total | 19
Prompted, adding sloth and torpor | 21

Hatred and remorse
Component | Count
Mental phenomena of the hatred group | 18
Remorse | 1
Unprompted total | 19
Prompted, adding sloth and torpor | 21

For remorse, take misconduct already done as object and discern the unprompted and prompted cases. Take good conduct that should have been done but was omitted as object and discern the unprompted and prompted cases. This completes the discernment of the two hatred-rooted consciousnesses. The following deals with the two delusion-rooted consciousnesses.


<a id="M04-body-P173"></a>
## The two delusion-rooted groups
Miến / Burmese 173

Delusion and restlessness
Component | Count
Knowing consciousness | 1
Universal mental factors | 7
Applied thought, sustained thought, decision and energy. Joy and desire are absent. | 4
Universal unwholesome mental factors | 4
Total | 16

Delusion and doubt
Component | Count
Knowing consciousness | 1
Universal mental factors | 7
Applied thought, sustained thought and energy. Decision, joy and desire are absent. | 3
Universal unwholesome mental factors | 4
Doubt | 1
Total | 16

This completes the discernment of the two delusion-rooted consciousnesses. Eight rooted in greed, two rooted in hatred, and two rooted in delusion make twelve unwholesome consciousnesses to discern. According to the analysis of processes in the Abhidhammatthasaṅgaha and Abhidhamma teachings such as the Dhammasaṅgaṇī, all twenty-nine sense-sphere impulsions can occur in five-door processes such as the eye-door process, and in mind-door processes. These include twelve unwholesome impulsions. The Buddha himself also teaches discerning a mind with lust accompanied by lust…


<a id="M04-body-P174"></a>
## Beginning from ultimate materiality or a conceptual object
Miến / Burmese 174

… a mind with hatred accompanied by hatred and a mind with delusion accompanied by delusion, in the contemplation of mind in the Mahāsatipaṭṭhāna Sutta.

Tasmā taṃ rūpaṃ ārammaṇaṃ katvā uppannaṃ vedanaṃ saññaṃ saṅkhāre viññāṇañca “idaṃ arūpan”ti vavatthapetvā aniccādito passati.
Abhidhamma Commentary, vol. 1, p. 128. Beginners in the meditation on mentality first apprehend the mentality arising with each of the twenty-eight material phenomena as object. Seek and apprehend all twenty-eight. Classified by object, there are six kinds. First comes mentality arising with each of the ten or eleven concrete and ten non-concrete material phenomena belonging to the mind-object domain.

Some meditators may find it difficult to discern the individual groups of unwholesome phenomena arising with an ultimate material phenomenon as object. If so, begin with unwholesome groups arising with particular conceptual objects already familiar to you. This is easier because the mind of one who has yet to develop knowledge of ultimate reality generally operates within the sphere of concepts. Just as when watering a tree, to learn the method more easily also practise discerning mentality arising with concepts as objects, as when directing water into a channel…


<a id="M04-body-P175"></a>
## Example of the greed-and-wrong-view group taking gold as object
Miến / Burmese 175

… and thereby understand unwholesome phenomena. For these two purposes, those who encounter difficulty may begin by apprehending mentality arising with a concept as object. They may also discern directly with ultimate materiality as object. Once they can apprehend unwholesome mentality taking ultimate materiality as object, they need not repeat the exercise with conceptual objects. An example follows for those whose discernment is still weak, using mentality in a mind-door process with unwholesome impulsion taking a concept as object.

The greed-and-wrong-view group.
1. If needed, re-establish concentration.
2. Apprehend the clear life-continuum, the mind-door.
3. Direct the mind to gold, for example gold you own and like.
4. When gold appears at the mind-door, series of mind-door processes with impulsion arise taking a particular conceptual object, gold, as object. Mind-door adverting in those processes turns towards and determines it as “gold”. Attend unwisely. The unwholesome impulsion group with greed and wrong view will then arise.


<a id="M04-body-P176"></a>
## Wrong view taking gold and familiar things as objects
Miến / Burmese 176

When this process takes a concept as object, registration has no opportunity to occur. If, instead of the concept “gold”, one takes as object the colour of the many material clusters in it, registration has an opportunity to occur.

In the unwholesome impulsion group with greed and wrong view, misapprehending it as “gold” belongs to delusion, while believing in and holding to “gold” belongs to wrong view. This is one kind of worldly convention. Understand the remaining factors by their natures. Likewise try determining that lump of gold as permanent, pleasant, self, or beautiful. Unwholesome processes of the greed-and-wrong-view group occur similarly. In these mental phenomena, misapprehension as permanent, pleasant, self, and attractive is delusion, while belief in and adherence to those views is wrong view. Understand and discern clothing similarly. Discern clearly how joy often arises for a new garment or robe but does not arise for an old one.

Misapprehension and adherence to permanence here take forms such as “Yesterday it was my gold and today it is still my gold. Yesterday it was my garment or robe and today it is still mine. Yesterday he was my son and today he is still my son.” If someone says, “That is not your gold, garment, robe, or son,” one who has yet to discern ultimate reality and is clinging will find this hard to accept. Understand the nature of these phenomena through such misapprehension and adherence.


<a id="M04-body-P177"></a>
## Objects for the greed-and-conceit group and hatred groups
Miến / Burmese 177

Greed and conceit. Conceit is the wish to surpass others and stand above them. One considers one’s own animate or inanimate sensual possessions superior to those of others and of a higher order, exalts oneself and takes pride. Take a familiar object concerning which you wish to compete or excel, such as clothing, houses, cars, sons, or wives. Apprehend the mind-door together with it and discern. Once you understand the greed-and-wrong-view or greed-and-conceit group with concepts as objects, discern with ultimate materiality as object.

Hatred-rooted groups. 1. For hatred, take a person you habitually dislike or an object that provokes hatred. 2. For hatred and envy, take another’s possession that surpasses yours. 3. For hatred and stinginess, take one of your own animate or inanimate sensual possessions that you do not want another to have. 4. For hatred and remorse, take misconduct already done, such as an occasion of killing, or good conduct omitted, such as failing to carry out an act of giving or observe virtue.


<a id="M04-body-P178"></a>
## Objects of remorse, restlessness, and doubt
Miến / Burmese 178

Remorse is later distress at misconduct already done, so that misconduct can be taken as object for discernment. It is also distress at having omitted good conduct, so that omission too can be taken as object. Extend the discernment according to your wisdom. Many meditators find this group difficult to discern with ultimate materiality as object.

Delusion-rooted groups. For delusion and restlessness, first discern a familiar conceptual object that makes the mind wander without greed or hatred. For delusion and doubt, take an object liable to stir doubt, for example, “Was there really a previous life?”

When discerning concepts in this way, registration does not follow unwholesome mind-door impulsion. If one can take ultimate materiality such as colour, sound or odour as object, registration has an opportunity to arise. Once you have apprehended unwholesome mentality taking concepts as objects, proceed to apprehend unwholesome mentality taking each kind of ultimate materiality as object. As with the processes with wholesome impulsion, begin with the mind-object group.


<a id="M04-body-P179"></a>
## Twenty mental phenomena in the greed-and-wrong-view group
Miến / Burmese 179

For those whose discernment is still weak, the twenty mental phenomena in the greed-and-wrong-view group arising with eye-sensitivity as object are presented again. Understand the other groups of unwholesome mentality on the same model.

1. Knowing consciousness. Apprehending eye-sensitivity as object.
2. Contact (phassa). Touching eye-sensitivity and connecting it with knowing consciousness. Note: “object” in the following entries means eye-sensitivity.
3. Feeling (vedanā). Experiencing the flavour of the object, here with joyful feeling.
4. Perception (saññā). Marking the object as beautiful. Understand similarly when marking it as permanent, pleasant or self.
5. Volition (cetanā). Prompting and urging the associated phenomena towards the object.
6. One-pointedness (ekaggatā). Placing the mind on a single object and keeping the associated phenomena from scattering away from it.


<a id="M04-body-P180"></a>
## Mental factors from life faculty to delusion
Miến / Burmese 180

7. Life faculty (jīvita). Sustaining associated phenomena on the object.
8. Attention (manasikāra). Directing and driving consciousness and associated phenomena towards the object, bringing the object to mind.
9. Applied thought (vitakka). Placing consciousness and associated phenomena on the object, thinking about it.
10. Sustained thought (vicāra). Continually examining and rubbing against the object, taking it again and again.
11. Decision (adhimokkha). Deciding that the object is beautiful. Understand similarly when deciding it to be permanent, pleasant or self.

12. Energy (viriya). Striving for greed, wrong view, and similar unwholesome phenomena to arise in relation to the object.
13. Joy (pīti). Taking delight in the object.
14. Desire (chanda). Wanting the object, that is, wanting greed to arise.
15. Delusion (moha). Failing to know the object’s truly unattractive nature. Understand its truly impermanent, suffering and non-self nature similarly. Delusion also misapprehends the object as beautiful. Understand similarly when misapprehending it as permanent, pleasant or self.


<a id="M04-body-P181"></a>
## The remaining factors and four cases of the greed group
Miến / Burmese 181

16. Lack of moral shame (ahirika). Lack of shame at greed, wrong view, and similar unwholesome phenomena arising in relation to the object.
17. Lack of moral dread (anottappa). Lack of fear of such unwholesome phenomena arising in relation to the object.
18. Restlessness (uddhacca). The mind is unsettled and agitated in relation to the object.
19. Greed (lobha). Appropriating the object as “mine”, wanting and becoming infatuated with it, clinging to it.
20. Wrong view (diṭṭhi). Holding and believing the object to be beautiful, misconstruing and misjudging it in that way. Understand similarly when it is held to be permanent, pleasant or self.

Feeling, joy, sloth and torpor. Greed-rooted consciousness accompanied by joyful feeling has joy. When accompanied by equanimous feeling it lacks joy. Unprompted consciousness lacks sloth and torpor, while prompted consciousness can have them. Discern four cases according to whether joy, sloth and torpor are associated.

Energy and desire. In each of the groups of hatred, hatred and envy, hatred and stinginess, and hatred and remorse, energy is the particular effort for those respective phenomena to arise. Desire is wanting them to arise.


<a id="M04-body-P182"></a>
## Delusion, lack of shame, and lack of dread in the unwholesome groups
Miến / Burmese 182

Delusion misapprehends eye-sensitivity and similar objects as permanent, pleasant, self, or attractive, or misapprehends them in such terms as “another’s eye-sensitivity” or “my eye-sensitivity”.

Lack of moral shame and lack of moral dread are being unashamed and unafraid of the arising of such unwholesome phenomena as greed and wrong view, greed and conceit, hatred, hatred and envy, hatred and stinginess, hatred and remorse, delusion and restlessness, and delusion and doubt. When apprehending mentality arising while committing misconduct, the absence of shame and dread at that moment concerns the very misconduct being committed.

For unwholesome mentality arising with the remaining nine or ten concrete material phenomena and the ten non-concrete material phenomena in the mind-object group, discern using eye-sensitivity as the model. First comes the table of mind-door processes with unwholesome impulsion.


<a id="M04-body-P183"></a>
## Mind-door process table for unwholesome impulsion taking mind objects
Miến / Burmese 183

Unwholesome group taking mind objects. Supporting materiality in the heart: 54.
Group | Mind-door adverting | Impulsion (7) | Rootless registration (2) | Rooted registration (2)
1. Greed and wrong view | 12 | 20 (19/22/21) | 12 (11/12/11) (8) | 34/33/33/32
2. Greed and conceit | 12 | 20 (19/22/21) | 12 (11/12/11) | 34/33/33/32
3. Hatred | 12 | 18 (20) | 11 (11) | 33/32
4. Hatred and envy | 12 | 19 (21) | 11 (11) | 33/32
5. Hatred and stinginess | 12 | 19 (21) | 11 (11) | 33/32
6. Hatred and remorse | 12 | 19 (21) | 11 (11) | 33/32
7. Restlessness | 12 | 16 | 12 (11/11) | 34/33/33/32
8. Doubt | 12 | 16 | 12 (11/11) | 34/33/33/32


<a id="M04-body-P184"></a>
## Discerning greed and wrong view with eye-sensitivity as object
Miến / Burmese 184

1. If needed, re-establish concentration in stages.
2. Apprehend the clear life-continuum, the mind-door.
3. Analyse the eye-decad and direct the mind to eye-sensitivity.
4. When eye-sensitivity appears before the mind-door, mind-door process series with impulsion arise taking it as object. Mind-door adverting in these processes determines it to be beautiful. Even when that eye-sensitivity is desirable, unwise attention gives rise to greed-and-wrong-view mentality at impulsion, delighting and clinging on account of regarding it as beautiful. Wrong attention, attending as beautiful, is among the nearest conditions for greed impulsion.

Understand similarly when determining and attending to eye-sensitivity as permanent, pleasant, or self. Of eight greed-rooted consciousnesses four are associated with wrong view. Joy is present with joyful feeling and absent with equanimity. Prompted means with inducement, so sloth and torpor may be present. Unprompted means without inducement, so they are absent. Inducement is prompting oneself or being prompted by another for greed, hatred, or similar unwholesome phenomena to arise. The counts of consciousness and mental factors in each moment of the process series are given in the table.


<a id="M04-body-P185"></a>
## Discerning conceit, hatred, envy, and stinginess with eye-sensitivity
Miến / Burmese 185

In the greed-and-conceit group, conceit is occasional and is associated only when conditions are present. When neither conceit nor wrong view is associated, the respective counts of consciousness and mental factors at impulsion are nineteen, eighteen, twenty-one, and twenty. There are four cases according to joyful or equanimous feeling and prompted or unprompted occurrence.

Greed and conceit taking eye-sensitivity. Apprehend the mind-door together with eye-sensitivity and try attending, “I have obtained this eye-sensitivity.” Mind-door process series with unwholesome impulsion in which greed and conceit predominate will arise. Break down the compactness of mentality and apprehend ultimate mental phenomena.

Hatred. Take as object undesirable eye-sensitivity that was once impaired. Apprehend the mind-door together with the mental phenomena of the hatred group.
Hatred and envy. Take another’s eye-sensitivity that surpasses your own, that is, eyes more beautiful than yours, and attend, “If only that person did not have such eye-sensitivity”, or “If only that person did not have such eyes”. Mentality in which hatred and envy predominate will arise. Apprehend it down to ultimate reality.
Hatred and stinginess. Take your own eye-sensitivity that you do not want others to encroach upon. You may take as object your unwillingness to bear it when someone scoffs, “What is so beautiful about your eyes?”


<a id="M04-body-P186"></a>
## Discerning remorse, restlessness and doubt, and the rule for registration
Miến / Burmese 186

Hatred and remorse. Take as object a wrong thing said or done in connection with eye-sensitivity. Alternatively, take the later distress over failing to do something that should have been done in connection with eye-sensitivity.
Delusion and restlessness. If the mind has been agitated in relation to eye-sensitivity, discern with that same object in the absence of greed and hatred.
Delusion and doubt. Discern with the question, “Is this eye-sensitivity the sensitivity of a self?” This follows the arising of the ten fetters with visible form as object as explained in the commentary. See Dīgha Commentary, vol. 2, p. 377, and Majjhima Commentary, vol. 1, p. 292. This will be explained below.

Registration. The table shows both rootless and rooted registration. Both kinds should not be understood to arise in the same process. Either one rootless kind or one rooted kind can occur as appropriate. Of the eleven kinds of registration, only one can occur in a process. Impulsion and registration generally have the same feeling. If impulsion has joyful feeling, registration also has joyful feeling. When joy is associated with impulsion, it is associated with registration. If impulsion has equanimous feeling, registration has equanimous feeling. If impulsion lacks joy, registration lacks it too. However, if impulsion is accompanied by displeasure, registration cannot have displeasure and can only have equanimity. Thus after hatred impulsion only equanimous registration has an opportunity to occur. As the preceding table shows…


<a id="M04-body-P187"></a>
## Alternating discernment of wholesome and unwholesome groups
Miến / Burmese 187

… great-resultant registration can also follow unwholesome impulsion as appropriate. For instance, with an exceptionally desirable object such as the Buddha, unwise attention can give rise to unwholesome impulsion, which can also be followed by great-resultant registration as appropriate. Hence the table shows both rootless and rooted registration. Meditators will understand through practice.

For unwholesome mentality taking the remaining concrete and non-concrete material phenomena in the mind-object domain as objects, follow the model of eye-sensitivity.

A way to practise. From observing many meditators, when they devote a whole sitting to apprehending only processes with unwholesome impulsion, the mind sometimes becomes clouded and the light gradually dims. Having learned to apprehend wholesome processes, it is better to alternate wholesome and unwholesome processes. For instance, after apprehending wholesome mind-door processes with eye-sensitivity as object, continue with unwholesome mind-door processes taking that same eye-sensitivity as object, determining the same object…


<a id="M04-body-P188"></a>
## How the ten fetters arise on seeing visible form
Miến / Burmese 188

… If the wholesome and unwholesome groups that arise with each kind of materiality are apprehended in turn like this, the mind usually does not become clouded and the light does not fade.

Next comes apprehending mentality in five-door and mind-door processes with unwholesome impulsion taking the five objects beginning with visible form. Before apprehending it, learn how the ten fetters arise as explained in the commentaries.

Cakkhudvāre tāva āpāthagataṃ iṭṭhārammaṇaṃ kāmassādavasena assādayato abhinandato kāmarāgasaṃyojanaṃ uppajjati. Aniṭṭhārammaṇe kujjhato paṭighasaṃyojanaṃ uppajjati. “Ṭhapetvā maṃ na koci añño etaṃ ārammaṇaṃ vibhāvetuṃ samattho atthī”ti maññato mānasaṃyojanaṃ uppajjati. “Etaṃ rūpārammaṇaṃ niccaṃ dhuvan”ti gaṇhato diṭṭhisaṃyojanaṃ uppajjati. “Etaṃ rūpārammaṇaṃ satto nu kho, sattassa nu kho”ti vicikicchato vicikicchāsaṃyojanaṃ uppajjati. “Sampattibhave vata no idaṃ sulabhaṃ jātan”ti bhavaṃ patthentassa bhavarāgasaṃyojanaṃ uppajjati. “Āyatimpi evarūpaṃ sīlabbataṃ samādiyitvā sakkā laddhun”ti sīlabbataṃ samādiyantassa sīlabbataparāmāsasaṃyojanaṃ uppajjati. “Aho vata etaṃ rūpārammaṇaṃ aññe na labheyyun”ti usūyato issāsaṃyojanaṃ uppajjati. Attanā laddhaṃ rūpārammaṇaṃ aññassa maccharāyato macchariyasaṃyojanaṃ uppajjati. Sabbeheva sahajātaaññāṇavasena avijjāsaṃyojanaṃ uppajjati.
Dīgha Commentary, vol. 2, p. 377. Majjhima Commentary, vol. 1, p. 292. The translation and explanation of each fetter follow.


<a id="M04-body-P189"></a>
## The fetters of sensual desire and desire for existence
Miến / Burmese 189

Niccaṃ dhuvanti etaṃ nidassanamattaṃ. “Ucchijjissati vinassissatī”ti gaṇhatoti evamādīnampi saṅgaho icchitabbo. Bhavaṃ patthentassāti “īdise sampattibhave yasmā amhākaṃ idaṃ iṭṭhārammaṇaṃ sulabhaṃ jātaṃ, tasmā āyatimpi sampattibhavo bhaveyyā”ti bhavaṃ nikāmentassa. Evarūpaṃ sakkā laddhunti yojanā.
“Permanent, enduring” is an example only. Views such as “it will be cut off and perish” are also included. One who longs for existence wishes for a prosperous existence in the future, thinking that an agreeable object is easily obtained in such an existence. The passage is construed as saying that such an object can be obtained. (Majjhima Subcommentary, vol. 1, p. 379.)

Of the twenty-eight material phenomena, the Dīgha Commentary, Mahāvagga (vol. 2, p. 377), and the Majjhima Commentary, Mūlapaṇṇāsa (vol. 1, p. 292), explain the arising of the ten fetters with visible form as object in the section on the bases in the Mahāsatipaṭṭhāna Sutta. By understanding visible form, you can understand and apprehend how they arise with the remaining twenty-seven material phenomena. The commentaries also explain the ten fetters by the Abhidhamma method. Here they are presented in order of greed-, hatred-, and delusion-rooted consciousness to facilitate discernment and recollection.

1. The fetter of sensual desire. When a desirable, agreeable and prized visible object appears before the eye-door and mind-door, the fetter of sensual desire arises in the continuum of one who regards it as beautiful and relishes it for the gratification of sensuality. This fetter is craving, greed associated with the eight greed-rooted consciousnesses, both with and without wrong view, clinging to animate or inanimate sensual objects.

2. The fetter of desire for existence. This fetter arises in the continuum of one who longs for a prosperous existence, thinking, “Indeed, in a prosperous existence such visible forms are easily obtained.”


<a id="M04-body-P190"></a>
## Fetters of desire for existence, wrong view and attachment to rules and observances
Miến / Burmese 190

In terms of actual phenomena it is greed clinging to a prosperous existence. In the discourse method, desire for form and desire for the formless can also be given in place of desire for existence. Craving, or greed, that delights in fine-material jhāna and its result is the fetter of desire for form. Craving that delights in immaterial jhāna and its result is the fetter of desire for the formless. Here the commentaries exemplify longing for a prosperous existence replete with all six objects, beginning with visible form. Hence desire for existence can differ in scope from desire for form and for the formless. Understand desire for existence as greed that may be associated with all eight greed-rooted consciousnesses as appropriate.

3. The fetter of wrong view. It arises through holding that same visible object to be (a) permanent, enduring and solid, (b) pleasant and comfortable, or (c) a self, a living entity, a soul, consciousness, or a selfhood. Misapprehending it as permanent, pleasant and self is delusion. Wrongly holding and believing it to be so is wrong view. Each impulsion contains the mentality of the greed-and-wrong-view group, numbering twenty, nineteen, twenty-two, or twenty-one. This is greed associated with wrong view.

4. The fetter of attachment to rules and observances. Thinking that by practising mistaken observances such as the ox or dog practice one can obtain such visible forms in the future, one adheres to such observances…


<a id="M04-body-P191"></a>
## Attachment to observances, conceit, aversion and envy
Miến / Burmese 191

… and practises them, the fetter of attachment to rules and observances arises in that continuum. This fetter belongs to the greed-and-wrong-view group of twenty, nineteen, twenty-two or twenty-one mental phenomena, greed associated with wrong view. It is very difficult for that kind of attachment to arise in a worldling who has gone for refuge to the Triple Gem, has confidence in kamma and its results, has right view of ownership of kamma, and is striving for knowledge delimiting mentality and materiality. The explanation here concerns beings in whom that fetter can arise.

5. The fetter of conceit. When one exalts oneself, thinking, “No one apart from me can make the colour of the visible object in these material clusters clear to wisdom. I alone can see it,” the fetter of conceit arises. It is unwholesome impulsion of the greed-and-conceit group, dissociated from wrong view, with twenty, nineteen, twenty-two or twenty-one mental phenomena in each impulsion moment.

6. The fetter of aversion. When one encounters an unwanted, disagreeable visible object and dislikes it or becomes angry, the fetter of aversion arises. This is the mentality of the hatred group. Discern taking a disagreeable visible object as object. Each impulsion contains eighteen or twenty mental phenomena.

7. The fetter of envy. It arises in the continuum of one who envies, thinking, “If only others apart from me could not obtain such visible forms.” This is the mentality of the hatred-and-envy group. In each impulsion…


<a id="M04-body-P192"></a>
## Stinginess and remorse over what was done
Miến / Burmese 192

… there are nineteen or twenty-one mental phenomena of the hatred-and-envy group. Discern with the visible form of someone you habitually envy as object. For example, take the colour of another person’s fine, sparkling earrings as object.

8. The fetter of stinginess. In the continuum of one who keeps an acquired visible object to oneself and resents others sharing in it, the fetter of stinginess arises. This is the mentality of the hatred-and-stinginess group, nineteen or twenty-one in each impulsion. Discern taking the colour of an animate or inanimate sensual possession of your own that you habitually cannot bear others to touch. For example, when someone touches your clean garment with an ink-stained hand, you may say nothing but inwardly cannot bear it. Discern taking the object that has stirred or habitually stirs that response.

Remorse is not among these ten fetters. Discern two kinds separately: (a) misconduct committed and (b) good conduct omitted. In case (a), remorse arises from later distress over misconduct done in relation to a visible object. This is the hatred-and-remorse group. Discern using the object that previously gave rise to remorse. For example, if you damaged the colour of another’s garment with ink and later felt distressed and unhappy, discern with that same object. In case (b), take a good deed that was omitted…


<a id="M04-body-P193"></a>
## Remorse over omission, restlessness, doubt and ignorance
Miến / Burmese 193

… and are later distressed over it, remorse arises. This is the hatred-and-remorse group, with nineteen or twenty-one mental phenomena in each impulsion. For example, if you intended to offer flowers to the Buddha but could not do so and later felt unhappy, discern taking that object. Some meditators find it difficult to discern the hatred-and-remorse group with ultimate reality as object. In that case first apprehend the mentality with a concept as object, then apprehend the same group again with ultimate reality as object.

Restlessness does not occur among the ten fetters in the Abhidhamma method given here, but does occur among the ten according to the discourse method. When visible form is taken as object and the mind is agitated, restlessness arises. This is the delusion-and-restlessness group, with sixteen mental phenomena in each impulsion. Greed and hatred are absent. Discern taking as object the colour of a visible form that unsettled the mind.

9. The fetter of doubt. It arises in the continuum of someone who doubts, “Is this visible form a being, a self, something belonging to a being, or something belonging to a self, that is, the colour of a self?” This is the doubt group, with sixteen mental phenomena in each impulsion. Discern with visible form as object, with the doubt whether it is the colour of a self.

10. The fetter of ignorance. Whenever the preceding fetters arise, ignorance, misapprehension, always accompanies them. See Dīgha Commentary, vol. 2, p. 377 and Majjhima Commentary, vol. 1, p. 292. These fetters do not arise in isolation…


<a id="M04-body-P194"></a>
## Fetters arise in groups, and the limits of eye-consciousness
Miến / Burmese 194

… but are associated with other consciousness and mental factors and arise in groups. These groups of mentality arise in accordance with the fixed sequence of the cognitive process. When apprehending them, break down the compactness of mentality so that wisdom reaches ultimate reality.

A point to note. In explaining the ten fetters arising with visible form, the commentaries say “at the eye-door” (cakkhudvāre), meaning that they can also occur in the eye-door process (Dīgha Commentary, vol. 2, p. 377. Majjhima Commentary, vol. 1, p. 292). When visible form is attended to as permanent, pleasant, self or attractive, many mind-door processes follow the eye-door process. After those mind-door processes have discerned the object in these ways many times, subsequent eye-door processes can bear an imprint of taking the object in those ways. Clear determination as permanent, pleasant, self, or attractive does not occur in the eye-door process itself. Only a general imprint of that nature may be present there. See the commentary and subcommentary below.

Cakkhuviññāṇañhi rūpe rūpamattameva passati, na niccādisabhāvaṃ.
Eye-consciousness sees visible form merely as visible form and does not know characteristics such as permanence or impermanence (Saṃyutta Commentary, vol. 3, p. 28).

Rūpamattamevāti nīlādibhedaṃ rūpāyatanamattaṃ, na nīlādi. Visesanivattanattho hi ayaṃ matta-saddo. Yadi evaṃ, eva-kāro kimatthiyo? Cakkhuviññāṇañhi rūpāyatane labbhamānampi nīlādivisesaṃ “idaṃ nīlaṃ nāma, idaṃ pītaṃ nāmā”ti na gaṇhāti. Kuto niccādisabhāvatthanti…
Subcommentarial passage continued on Burmese page 195.


<a id="M04-body-P195"></a>
## Colour in eye-door and mind-door processes
Miến / Burmese 195

… saṃhitassapi nivattanatthaṃ evakāraggahaṇaṃ. Tenāha “na niccādisabhāvan”ti.
Saṃyutta Subcommentary, vol. 2, p. 303.

Subcommentarial passage continued from the preceding page. “Merely visible form” means only the visible-form base, without distinguishing blue and other colours. Colour is still an object of eye-consciousness, but eye-consciousness cannot be said to determine “this is called blue, this is called yellow”. Hence the statement that it does not know characteristics such as permanence or impermanence (Saṃyutta Subcommentary, vol. 2, p. 303).

According to the commentary and subcommentary, eye-consciousness, or the group of mental phenomena in the eye-door process with eye-consciousness, knows colour, such as brown and yellow, without distinguishing “brown” or “yellow”. Although it can take visible form as object, it is unable to determine “this is brown, this is yellow”. Still less can it take the actual characteristic as object and determine permanence or impermanence (Saṃyutta Commentary, vol. 3, p. 28. Saṃyutta Subcommentary, vol. 2, p. 303).

Nevertheless, wrong view can occur at impulsion in the eye-door process, since all unwholesome impulsions can occur in this process. Therefore, wrong-view-associated consciousness in an eye-door process can bear the imprint of a view held by wrong-view-associated consciousness in mind-door processes, that is, taking the object as permanent, pleasant, self, or attractive. Test this for yourselves. A meditator who has thoroughly discerned materiality before taking up mentality may find it difficult to hold material phenomena to be permanent, pleasant, or self, and may still hold them only as attractive. For one without knowledge of ultimate reality, the views of permanence, pleasure, self, and attractiveness are readily present.


<a id="M04-body-P196"></a>
## Eye-door and mind-door process table with unwholesome impulsion
Miến / Burmese 196

Unwholesome group taking colour as object. Supporting materiality in the eye or heart: 54 in the corresponding columns.
Group | Five-door adverting | Eye-consciousness | Receiving | Investigating | Determining | Eye-door impulsion (7) | Eye-door registration (2) | Life-continuum | Mind-door adverting | Mind-door impulsion (7) | Mind-door registration (2)
1. Greed and wrong view | 11 | 8 | 11 | 12 | 12 | 20 | 34/33/12/11 | 34 | 12 | 20 | 34/33/12/11
2. Greed and wrong view | 11 | 8 | 11 | 11 | 12 | 19 | 33/32/11/11 | 34 | 12 | 19 | 33/32/11/11
3. Greed and wrong view | 11 | 8 | 11 | 12 | 12 | 22 | 34/33/12/11 | 34 | 12 | 22 | 34/33/12/11
4. Greed and wrong view | 11 | 8 | 11 | 11 | 12 | 21 | 33/32/11/11 | 34 | 12 | 21 | 33/32/11/11
5. Greed and conceit | 11 | 8 | 11 | 12 | 12 | 20 | 34/33/12/11 | 34 | 12 | 20 | 34/33/12/11
6. Greed and conceit | 11 | 8 | 11 | 11 | 12 | 19 | 33/32/11/11 | 34 | 12 | 19 | 33/32/11/11
7. Greed and conceit | 11 | 8 | 11 | 12 | 12 | 22 | 34/33/12/11 | 34 | 12 | 22 | 34/33/12/11
8. Greed and conceit | 11 | 8 | 11 | 11 | 12 | 21 | 33/32/11/11 | 34 | 12 | 21 | 33/32/11/11
9. Hatred | 11 | 8 | 11 | 11 | 12 | 18 | 33/32/11/11 | 34 | 12 | 18 | 33/32/11/11
10. Hatred | 11 | 8 | 11 | 11 | 12 | 20 | 33/32/11/11 | 34 | 12 | 20 | 33/32/11/11
11. Hatred and envy | 11 | 8 | 11 | 11 | 12 | 19 | 33/32/11/11 | 34 | 12 | 19 | 33/32/11/11
12. Hatred and envy | 11 | 8 | 11 | 11 | 12 | 21 | 33/32/11/11 | 34 | 12 | 21 | 33/32/11/11
13. Hatred and stinginess | 11 | 8 | 11 | 11 | 12 | 19 | 33/32/11/11 | 34 | 12 | 19 | 33/32/11/11
14. Hatred and stinginess | 11 | 8 | 11 | 11 | 12 | 21 | 33/32/11/11 | 34 | 12 | 21 | 33/32/11/11
15. Hatred and remorse | 11 | 8 | 11 | 11 | 12 | 19 | 33/32/11/11 | 34 | 12 | 19 | 33/32/11/11
16. Hatred and remorse | 11 | 8 | 11 | 11 | 12 | 21 | 33/32/11/11 | 34 | 12 | 21 | 33/32/11/11
17. Restlessness | 11 | 8 | 11 | 11 | 12 | 16 | 33/32/11/11 | 34 | 12 | 16 | 33/32/11/11
18. Doubt | 11 | 8 | 11 | 11 | 12 | 16 | 33/32/11/11 | 34 | 12 | 16 | 33/32/11/11

Note: For hatred and remorse, discern two cases with misconduct already done as object and two with good conduct omitted as object, four in all.


<a id="M04-body-P197"></a>
## How to discern the unwholesome group taking visible form
Miến / Burmese 197

The preceding explanation showed how the ten fetters arise among the consciousness and mental factors of eye-door processes with unwholesome impulsion taking visible form. This is one method of apprehending mentality in eye-door and mind-door processes with unwholesome impulsion and visible form as object. Discern the remaining twenty-seven material phenomena similarly. The greed-and-wrong-view group serves as the example below.

1. If needed, re-establish concentration in stages.
2. Apprehend the two doors together until clear to wisdom: eye-sensitivity, the eye-door, and the clear life-continuum, the mind-door.
3. Direct the mind to the colour of the many material clusters around that eye-sensitivity.
4. When the colour impinges on and appears at both doors together, eye-door and mind-door processes taking that same visible form arise. Five-door adverting, determining and mind-door adverting in these processes attend to the colour as: (a) permanent, enduring, (b) pleasant, comfortable, (c) self, a selfhood, or (d) attractive, beautiful…


<a id="M04-body-P198"></a>
## Wrong view at the mind-door and its imprint in the eye-door process
Miến / Burmese 198

… turn to and determine each mode separately. With unwise attention, series of eye-door and mind-door processes with unwholesome impulsion led by greed and wrong view will arise. As explained above, five-door adverting and determining cannot decide conclusively that the object is permanent, pleasant, self, or attractive. Only mind-door adverting in repeatedly arising mind-door processes, or decision associated with it, can decide conclusively. Greed and wrong view in the mind-door processes that decide this way hold the object to be permanent, pleasant, self or attractive. Five-door adverting and determining operate in a manner resembling decision, as already explained.

One who sees ultimate reality may find it difficult to discern visible form as permanent, pleasant or self. Holding it to be attractive and becoming infatuated with it, the fetter of sensual desire, can still occur. Holding it to be permanent, pleasant, self, or attractive belongs to the four greed-rooted consciousnesses associated with wrong view. When one delights in an attractive object and the fetter of sensual desire arises, any of the eight greed-rooted consciousnesses can occur as appropriate. The same applies when clinging to visible form and becoming attached to a prosperous existence. Extend the discernment according to your wisdom. With joyful feeling there is joy, and with equanimous feeling there is none. In prompted consciousness there is inducement and sloth and torpor are associated. In unprompted consciousness there is no inducement and they are absent.


<a id="M04-body-P199"></a>
## Feeling in investigating, impulsion and registration
Miến / Burmese 199

The table gives the counts of consciousness and mental factors in each process moment. When impulsion has joyful feeling and joy, investigating and registration also have joyful feeling and joy. When impulsion has equanimous feeling without joy, investigating and registration also have equanimous feeling without joy. Investigating and registration generally have the same feeling as impulsion. When impulsion has displeased feeling, however, investigating and registration cannot have displeased feeling, so only equanimous investigating and registration occur.

With an exceptionally desirable object only the five joyful registrations can occur. Great-resultant registration with joyful feeling and knowledge (thirty-four mental phenomena), great-resultant registration with joyful feeling but without knowledge (thirty-three), or joyful rootless wholesome-resultant investigating registration (twelve) can occur.

With a desirable object the eight kinds of great-resultant registration (thirty-four/thirty-three/thirty-three/thirty-two mental phenomena) and the two kinds of rootless wholesome-resultant registration (twelve/eleven) can occur. With an undesirable object there is only one unwholesome-resultant registration (eleven mental phenomena). The table therefore gives two instances of eleven. One is rootless wholesome-resultant equanimous investigating, the other rootless unwholesome-resultant equanimous investigating. A desirable object gives wholesome result and an undesirable object gives unwholesome result as appropriate. But within a single process…


<a id="M04-body-P200"></a>
## Applying the method to sound, odour, taste and tangibles
Miến / Burmese 200

… only one kind of registration can occur. Apprehend the registration that actually occurs.

The numbers at five-door adverting, eye-consciousness, receiving, investigating and determining follow the same pattern as the wholesome group. The difference between the wholesome and unwholesome groups is the number of mental phenomena at impulsion. For the other unwholesome groups, such as greed and conceit, hatred and the rest, consult the arising of the ten fetters and discern following the model of greed and wrong view.

The groups of sound, odour, taste and tangibles. For visible form, eye-sensitivity and the clear life-continuum were apprehended together, then the colour of desirable or undesirable clusters was taken as object for apprehending the groups with wholesome and with unwholesome impulsion. Follow that model.

For sound, apprehend ear-sensitivity together with the clear life-continuum and discern with a desirable or undesirable sound as object. Depending on wise or unwise attention, ear-door and mind-door processes with wholesome or unwholesome impulsion will arise. Similarly, for odour, apprehend nose-sensitivity together with the clear life-continuum and discern taking the desirable or undesirable odour of material clusters as object.


<a id="M04-body-P201"></a>
## Taste, tangibles, and the order of the six groups
Miến / Burmese 201

For taste, apprehend tongue-sensitivity together with the clear life-continuum and discern the taste of desirable or undesirable material clusters.

For tangibles, apprehend body-sensitivity together with the clear life-continuum and discern the tangibles of desirable or undesirable material clusters. As tangibles comprise the earth, fire and wind elements, apprehend both wholesome and unwholesome groups separately with each element as object. Thus divide tangibles into three and discern three rounds. Apprehension of mentality taking material mind objects was explained above. When you can apprehend the groups with wholesome and unwholesome impulsion in all six domains, proceed in the order visible form, sound, odour, taste, tangibles, and mind objects. This makes it easy to distinguish which groups have been apprehended and which remain.

The method presented thus far is the concise method for apprehending jhāna mentality and mentality arising with materiality as object.


<a id="M04-body-P202"></a>
## The detailed method of apprehending mentality
Miến / Burmese 202

In the detailed method, apprehend mentality arising with each material phenomenon at the six doors and in the forty-two parts as object. For example, there are fifty-four material phenomena at the eye-door. Begin with mentality taking each of them as object. First, the eye-decad at the eye-door has ten kinds:

1. Earth element — mentality in the tangible-object group.
2. Water element — mind-door mentality in the mind-object group.
3. Fire element — mentality in the tangible-object group.
4. Wind element — mentality in the tangible-object group.
5. Colour, visible form — mentality in the visible-object group.
6. Odour — mentality in the odour group.
7. Taste — mentality in the taste group.
8. Nutriment — mentality in the mind-object group.
9. Life faculty — mentality in the mind-object group.
10. Eye-sensitivity — mentality in the mind-object group.

Apprehend each kind of mentality separately in this way. With each material phenomenon as object, apprehend both the processes with wholesome impulsion and those with unwholesome impulsion, both the wholesome and the unwholesome groups. After taking each material phenomenon in the eye-decad as object…


<a id="M04-body-P203"></a>
## Applying the detailed method at the six doors and in the forty-two parts
Miến / Burmese 203

… continue with the ten material phenomena in the body-decad, ten in the sex-decad, eight in the consciousness-born cluster, eight in the temperature-born cluster, and eight in the nutriment-born cluster. With each as object, apprehend both wholesome and unwholesome mentality. There are fifty-four rounds at the eye-door. Continue separately with fifty-four at the ear-door, fifty-four at the nose-door, fifty-four at the tongue-door, forty-four at the body-door, and fifty-four at the mind-door in the heart. Also apprehend mentality taking each material phenomenon in the forty-two parts as object. The detailed method can be found in the Visuddhimagga, vol. 2, p. 226. Practise it when needed, if the concise method has yet to succeed.

The following summarizes the six groups in meditation on mentality. The mind-object group comprises mind-door mentality taking material mind objects and other ultimate or conceptual phenomena as objects. It is divided into four parts, (a), (b), (c), and (d). When proficient in all six groups, apprehend mentality in the order shown in the following tables.


<a id="M04-body-P204"></a>
## Three summary tables of mentality groups
Miến / Burmese 204

Summary of the six groups
Object group | Wholesome group | Unwholesome group
1. Visible form | Wholesome impulsion | Unwholesome impulsion
2. Sound | Wholesome impulsion | Unwholesome impulsion
3. Odour | Wholesome impulsion | Unwholesome impulsion
4. Taste | Wholesome impulsion | Unwholesome impulsion
5. Tangibles | Wholesome impulsion | Unwholesome impulsion
6. Mind objects | Wholesome impulsion | Unwholesome impulsion
(a) Concrete materiality (10/11) | Wholesome impulsion | Unwholesome impulsion
(b) Non-concrete materiality (10) | Wholesome impulsion | Unwholesome impulsion

(c) Mind objects — wholesome mind-door processes
Subject | Mind-door adverting | Impulsion (7) | Rooted registration (2) | Rootless registration (2)
Right speech | 12 | 35/34/34/33 | 34/33/33/32 | 12/11/11
Right action | 12 | 35/34/34/33 | 34/33/33/32 | 12/11/11
Right livelihood | 12 | 35/34/34/33 | 34/33/33/32 | 12/11/11
Compassion | 12 | 35/34/34/33 | × | ×
Appreciative joy | 12 | 35/34/34/33 | × | ×
Recollection of the Buddha | 12 | 34/33/33/32 | 34/33 | 12
Recollection of death | 12 | 34/33/33/32 | 34/33/33/32 | 12/11/11

(d) Mind objects — jhāna mentality
Subject | Jhānas
Breathing | First, second, third and fourth jhānas
Kasiṇas from earth through light | First, second, third and fourth jhānas, infinite space, infinite consciousness, nothingness, neither-perception-nor-non-perception
Space kasiṇa | First, second, third and fourth jhānas
Loving-kindness | First, second and third jhānas
Compassion | First, second and third jhānas
Appreciative joy | First, second and third jhānas
Equanimity | Fourth jhāna
Bones (repulsiveness) | First jhāna
Foulness | First jhāna


<a id="M04-body-P205"></a>
## Objects of the four immaterial jhānas and defining mentality
Miến / Burmese 205

If you have attained the immaterial jhānas, apprehend the mind-door together with the corresponding object and then apprehend that jhāna mentality. 1. The object of infinite space is the concept of space without limits. 2. The object of infinite consciousness is the consciousness of infinite space. 3. The object of nothingness is the concept “there is nothing”, the absence of the consciousness of infinite space. 4. The object of neither-perception-nor-non-perception is the consciousness of nothingness.

Apprehend the life-continuum mind-door together with the corresponding object, then apprehend the mentality of that jhāna. The pattern is the same as in the fourth-jhāna table. Mind-door adverting has twelve mental phenomena. Preparation, access, conformity and change-of-lineage each have thirty-three. Each absorption impulsion has thirty-one.

So sabbepi te arūpadhamme namanalakkhaṇena ekato katvā taṃ nāmanti passati.
Apprehend mentality as mentality. One brings together all those immaterial phenomena by their characteristic of inclining and sees them as mentality (Visuddhimagga, vol. 2, p. 223).


<a id="M04-body-P206"></a>
## Grouping mental phenomena and apprehending mentality and materiality together
Miến / Burmese 206

Following the commentary above, apprehend the mental phenomena as a group. As set out in the tables, when apprehending mentality by doors and bases, begin with knowing consciousness and gradually add contact, feeling, perception, volition and each further mental phenomenon. Once all the phenomena in a moment have been apprehended as in the tables and appear together to wisdom, take their characteristic of inclining towards an object and apprehend them as one group, noting “This is mentality” or “Mentality, mentality”. Wait to apply this collective method until all the co-arising phenomena in each process moment are seen. When seen by wisdom, discern them together.

Rūpārūpānaṃ lakkhaṇādīhi paricchinditvā gahaṇaṃ rūpārūpapariggaho.
Rūpārūpaṃ pana pariggaṇhanto…
Paricchinditvā gahaṇaṃ pariggaho.
Apprehending mentality and materiality together (rūpārūpapariggaha). After delimiting mentality and materiality by characteristics and the other aspects, distinguish them. Mūlaṭīkā, vol. 1, p. 112. Abhidhamma Commentary, vol. 1, p. 260. Anuṭīkā, vol. 1, p. 139.


<a id="M04-body-P207"></a>
## Base, object and mentality in each moment
Miến / Burmese 207

Following the instruction above, meditators should apprehend and distinguish mentality and materiality by wisdom according to characteristic, function, manifestation and proximate cause. This will be presented separately in the section on characteristics and related aspects. Here the emphasis has been on apprehending ultimate mentality and materiality by their individual characteristics. Since mentality was apprehended by bases and doors, it is appropriate to use that method when apprehending mentality and materiality together. In apprehending supporting materiality as given in the tables, give priority to concrete materiality and also apprehend non-concrete materiality. The tables emphasize concrete materiality that can be an object of insight knowledge. For example, in the eye-door process:

1. At five-door adverting, the fifty-four supporting material phenomena at the heart and the visible object are materiality, and eleven instances of consciousness and mental factors are mentality.
2. At eye-consciousness, the fifty-four supporting material phenomena at the eye and the visible object are materiality, and eight instances of consciousness and mental factors are mentality. Apprehend each process moment fully in this way. Apprehend mentality and materiality together in the same way in all six groups and all rounds. See the tables.


<a id="M04-body-P208"></a>
## Delimiting mentality and materiality
Miến / Burmese 208

Yopi rūpārūpaṃ pariggahetvā nāmarūpaṃ vavatthapento…
Abhidhamma Commentary, vol. 1, p. 260.

Tato namanalakkhaṇaṃ nāmaṃ, ruppanalakkhaṇaṃ rūpanti saṅkhepato nāmarūpaṃ vavatthapeti.
Visuddhimagga, vol. 2, p. 222.

Iti idañca nāmaṃ, idañca rūpaṃ, idaṃ vuccati nāmarūpanti saṅkhepato nāmarūpaṃ vavatthapeti.
Visuddhimagga, vol. 2, p. 223.

Na añño sattādikoti vavatthāpanaṃ nāmarūpavavatthāpanaṃ.
Mūlaṭīkā, vol. 1, p. 112.

Once able to apprehend mentality and materiality together in each process moment of all six groups, take that very mentality and materiality as object and see by wisdom that there are only groups of mentality and materiality. There is no person, being, living principle, self, human, deva or brahmā in them. Distinguish thus: “There is no person, being, living principle, self, human, deva or brahmā. There is only mentality and materiality.”


<a id="M04-body-P209"></a>
## Part 5. Four kinds of compactness of mentality
Miến / Burmese 209

Compactness (ghana) means a mass or group. Material compactness is a grouping of materiality, and mental compactness a grouping of mentality. The three kinds of material compactness were explained in the section on materiality. The four kinds of mental compactness are presented here.

Santatighanādīnaṃ ayaṃ viseso: purimapacchimānaṃ nirantaratāya ekībhūtānamiva pavatti santatighanatā. Tathā phassādīnaṃ ekasamūhavasena dubbiññeyyakiccabhedavasena ekārammaṇatāvasena ca ekībhūtānamiva pavatti samūhādighanatā.
The subcommentary distinguishes compactness of continuity from compactness of collection. Because of uninterrupted occurrence, the difference between what precedes and what follows is obscured. In such phenomena as contact, lack of analysis into individual constituents makes their collection appear as a compact mass (Mūlaṭīkā, vol. 1, p. 80). When the different elements are analysed, compactness is broken and non-self becomes evident according to its nature (Abhidhamma Commentary, vol. 2, p. 47. Visuddhimagga, vol. 2, p. 276).

Nānādhātuyo vinibbhujitvā ghanavinibbhoge kate anattalakkhaṇaṃ yāthāvasarasato upaṭṭhāti.
The subcommentary explains analysis of the different elements as recognizing each by its own nature, such as “the earth element is one phenomenon, the water element another”, or “contact is one phenomenon, feeling another”. In this way wisdom analyses and breaks compactness. The quotation continues on the next page.


<a id="M04-body-P210"></a>
## The four kinds of compactness and compactness of continuity
Miến / Burmese 210

The compactness of collection arises when many phenomena co-arising in groups of mentality and materiality appear as one. The compactness of function arises when their distinct functions are undifferentiated. The compactness of object arises when the phenomena taking an object appear as one. When these compact masses are analysed by wisdom, their characteristic of non-self becomes clear, since the phenomena occur according to conditions, empty and ownerless. Thus four kinds of compactness are spoken of (Mahāṭīkā, vol. 2, p. 437).

Mentality has four kinds of compactness: 1. Continuity (santatighana). 2. Collection (samūhaghana). 3. Function (kiccaghana). 4. Object (ārammaṇaghana).

1. Compactness of continuity is the apparent connectedness of the mental stream. The eye-door process illustrates the other processes. There is mentality in processes and outside processes. Both occur in groups called mental clusters. Process consciousnesses arise only in the fixed order called the regularity of the cognitive process. When a very great visible object comes before the eye-door and mind-door, the groups of eye-door process mentality arise in sequence as five-door adverting, eye-consciousness, receiving, investigating, determining, seven impulsions and two registrations…


<a id="M04-body-P211"></a>
## Breaking compactness of continuity and recognizing compactness of collection
Miến / Burmese 211

… arise without interruption according to the regularity of consciousness (Abhidhamma Commentary, vol. 1, p. 128). If wisdom has yet to distinguish each moment of the process, from five-door adverting, eye-consciousness, receiving, investigating, determining, first impulsion … pe … seventh impulsion, to first and second registration, they are grasped as one mass. This is mental compactness of continuity. It is broken when wisdom distinguishes the individual moments. Likewise, for consciousness outside processes, distinguish rebirth-linking, first life-continuum, second life-continuum and subsequent consciousnesses, moment by moment, to break compactness of continuity. Meditators should apprehend mentality in this way.

2. Compactness of collection is the grouping of mentality. Mental phenomena arising according to the regularity of consciousness arise in each moment as a mental cluster. They cannot arise separately. Mental phenomena belonging to a single group are called associated phenomena or a mental cluster. A moment contains at least eight mental phenomena. For example, eye-consciousness and the seven universal mental factors make eight…


<a id="M04-body-P212"></a>
## Distinguishing individual phenomena and functions
Miến / Burmese 212

… there is no mental group smaller than eight. While one has yet to analyse each mental phenomenon in a moment by right view, or wisdom, as “this is contact, this is feeling, this is perception, this is volition, this is consciousness”, and apprehends them as one phenomenon, the compactness of collection has yet to be broken. When each is directly penetrated with wisdom, the compactness of collection is broken. Meditators must analyse with wisdom and apprehend them down to ultimate reality.

3. Compactness of function is the lumping together of the functions of mentality. Even after breaking compactness of continuity and collection, continue to apprehend mentality so as to break compactness of function. Among mental phenomena arising together in each moment: 1. Contact has the function of bringing the object and knowing consciousness together (saṅghaṭṭanarasa). 2. Pleasant feeling has the function of fostering associated phenomena (sampayuttānaṃ upabrūhanarasā). 3. Perception has the function of marking the object so it can be recognized again…


<a id="M04-body-P213"></a>
## Breaking compactness of mental function
Miến / Burmese 213

… (paccābhiññāṇarasā). 4. Volition has the function of accumulating and constructing (āyūhanarasā). 5. Consciousness has the function of leading in knowing the object (pubbaṅgamarasa).

Each mental phenomenon in a moment has its own function. While one has yet to analyse those functions and see them separately with right view, or wisdom, and apprehends them as one function, compactness of function has yet to be broken. When one distinguishes by wisdom, “this is the function of contact, this of feeling, this of perception, this of volition, this of consciousness”, and sees the distinct function of each mental phenomenon in each moment, compactness of function is broken. Meditators need to analyse and apprehend mentality by right view in this way.

Mentality in an eye-door process takes visible form alone and can arise only with that visible form as object. It therefore consists of phenomena having an object (sārammaṇa). The three kinds of compactness of continuity, collection and function have been explained for that object-taking eye-door mentality.


<a id="M04-body-P214"></a>
## Compactness of object and the two sides of insight
Miến / Burmese 214

Another group of mentality exhibits compactness of object (ārammaṇaghana), the compactness of mental phenomena taking an object. Insight involves two kinds: mentality discerned as object and mentality led by insight knowledge that discerns that object. The discerning mentality also has an object. The compactness of continuity, collection and function must be broken in the mentality discerned, and likewise in the insight mentality doing the discerning. The section on comprehension by groups (Visuddhimagga, vol. 2, pp. 260–262) and the higher knowledges such as dissolution give the following instruction:

Ñātañca ñāṇañca ubhopi vipassati.
One discerns with insight both what is known and the knowledge (Visuddhimagga, vol. 2, p. 278).

1. What is known (ñāta) is the five aggregates subject to clinging belonging to the truth of suffering and formations such as ignorance, craving, clinging and kamma belonging to the truth of origin, which insight knowledge must penetrate. 2. Knowledge (ñāṇa) is the mentality led by the insight knowledge doing the discerning. Discern both by the three characteristics. The mental group led by the discerning insight knowledge…


<a id="M04-body-P215"></a>
## Three kinds of compactness in the insight process
Miến / Burmese 215

… in worldlings and trainees consists of mind-door process series with great wholesome impulsion. Mind-door adverting has twelve mental phenomena, and each of seven impulsion moments has thirty-four, thirty-three, thirty-three or thirty-two as appropriate. With weak insight there can be registration. With strong insight such as knowledge of dissolution, registration has no opportunity to occur. Sometimes thirty-three is shown because wisdom can be associated. Sometimes joy is absent, so thirty-three or thirty-two is also shown.

For a mind-door process series with impulsion led by discerning insight knowledge: 1. Distinguish each moment as mind-door adverting, first impulsion, second impulsion, and so forth, to break compactness of continuity. 2. Distinguish “this is contact, feeling, perception, volition, consciousness” and so forth in each moment to break compactness of collection. 3. Use wisdom to distinguish the separate function of each mental phenomenon in each moment to break compactness of function.

Thus there are three kinds of compactness on the side of mentality discerned and three on the side led by discerning wisdom. Those in the mentality discerned are separately called compactness of continuity, collection and function. The three on the side of discerning wisdom are collectively called compactness of object…


<a id="M04-body-P216"></a>
## Breaking compactness of object to see non-self
Miến / Burmese 216

… When the phenomena taking an object remain undifferentiated and are grasped as one, compactness of object persists. When one distinguishes each moment from mind-door adverting to the first impulsion … pe … the seventh, and distinguishes contact, feeling, perception, volition, consciousness and their respective functions, compactness of object is broken.

The meditator must break the compactness of mentality and materiality by wisdom, apprehend and distinguish them, and discern them with insight to penetrate ultimate reality. Penetrating ultimate reality makes it possible to see non-self, and penetrating non-self makes it possible to reach path knowledge, fruition knowledge, and Nibbāna. The commentaries say:

Nānādhātuyo vinibbhujitvā ghanavinibbhoge kate anattalakkhaṇaṃ yāthāvasarasato upaṭṭhāti.
When the different elements are analysed and compactness is broken, the characteristic of non-self appears according to its actual nature (Abhidhamma Commentary, vol. 2, p. 47. Visuddhimagga, vol. 2, p. 276).


<a id="M04-body-P217"></a>
## The characteristic of non-self and three insights
Miến / Burmese 217

Thus the characteristic of non-self, the true nature of the phenomena, becomes clear in the meditator’s wisdom (Abhidhamma Commentary, vol. 2, p. 47. Visuddhimagga, vol. 2, p. 276).

Discern the formations called what is known (ñāta) and knowledge (ñāṇa) by the three characteristics. When insight into impermanence, suffering and non-self matures, the noble path can be reached (Visuddhimagga, vol. 2, p. 301). Since compactness must be broken for wisdom to penetrate non-self, proceed to apprehend formations of mentality and materiality by characteristic, function, manifestation and proximate cause. This will become clear in the section on those four aspects.


<a id="M04-body-P218"></a>
## Part 6. Postures and clear comprehension
Miến / Burmese 218

1. Once able to discern the four elements, discern them while walking, standing, sitting and lying down, and in activities of clear comprehension such as stepping forward, stepping back, looking straight ahead, looking aside, bending and stretching.
2. Once able to discern materiality, discern all material phenomena in those postures and activities (rūpapariggaha).
3. Once able to apprehend mentality, discern it in those postures and activities (arūpapariggaha).
4. Once able to apprehend mentality and materiality together, apprehend and distinguish them in those postures and activities (rūpārūpapariggaha).
5. Once able to delimit mentality and materiality…


<a id="M04-body-P219"></a>
## Discerning the five aggregates in postures and activities
Miến / Burmese 219

… delimit mentality and materiality also in the activities of clear comprehension (nāmarūpavavatthāna). Apprehending in this way brings one within the scope of discerning the five aggregates. Materiality is the materiality aggregate. Mentality in each moment falls into four mental aggregates: feeling, perception, formations and consciousness. Apart from feeling and perception, all mental factors in a moment belong to the formations aggregate. One material and four mental aggregates make five. An aggregate means a group.

Discern the five aggregates: 1. While walking. 2. While standing. 3. While sitting. 4. While lying down. 5. When stepping forward. 6. When stepping back. 7. When looking straight ahead (eye-door and mind-door processes). 8. When looking aside (eye-door and mind-door processes). 9. When bending the limbs. 10. When stretching the limbs. 11. When carrying the double robe. 12. When carrying the bowl. 13. When carrying the robe. 14. When eating. 15. When drinking…


<a id="M04-body-P220"></a>
## An example of discerning the five aggregates while looking
Miến / Burmese 220

16. When licking. 17. When chewing. 18. When defecating. 19. When urinating. 20. While walking. 21. While standing. 22. While sitting. 23. While sleeping. 24. When waking up. 25. When speaking. 26. When silent. Understand how to discern the five aggregates in these cases (see Majjhima Commentary, vol. 1, pp. 255–257).

Ettha hi cakkhu ceva rūpañca rūpakkhandho, dassanaṃ viññāṇakkhandho, taṃsampayuttā vedanā vedanākkhandho, saññā saññākkhandho, phassādikā saṅkhārakkhandho. Evam etesaṃ pañcannaṃ khandhānaṃ samavāye ālokanavilokanaṃ paññāyati.
The commentary explains that the eye and visible form belong to the materiality aggregate, seeing consciousness to the consciousness aggregate, associated feeling to the feeling aggregate, perception to the perception aggregate, and contact and similar phenomena to the formations aggregate. Looking straight ahead and looking aside are apparent through the conjunction of these five aggregates (Majjhima Commentary, vol. 1, pp. 267–268).

When looking straight ahead or aside, groups of eye-door and mind-door mentality have arisen. At the moment of eye-consciousness the five aggregates are as follows. 1. Eye-sensitivity and visible form, that is, the fifty-four material phenomena at the eye and the visible object, belong to the materiality aggregate…


<a id="M04-body-P221"></a>
## The five aggregates in the eye-door process and the walking exercise
Miến / Burmese 221

2. Eye-consciousness that sees visible form is the consciousness aggregate. 3. Its associated feeling is the feeling aggregate. 4. Perception is the perception aggregate. 5. Contact, volition, one-pointedness, life faculty and attention are the formations aggregate. When these five aggregates combine, looking straight ahead or aside becomes apparent (Majjhima Commentary, vol. 1, pp. 267–268).

Eye-consciousness cannot arise without preceding five-door adverting. When it occurs, a slight-object process can reach determining, a great-object process impulsion, and a very-great-object process registration. Thus, once able to discern the five aggregates at eye-consciousness, apprehend them at every remaining moment beginning with five-door adverting. The commentary indicates this through characteristic, indication and example.

Exercise. Stand at one end of the walking path and re-establish concentration in stages. Apprehend materiality at the six doors and in the forty-two parts, then take a few steps. Of the material phenomena that bring about motion and those moved, either group can be given priority…


<a id="M04-body-P222"></a>
## Predominant and non-predominant materiality
Miến / Burmese 222

… in apprehending each material phenomenon. Distinguish predominant (padhāna) and non-predominant materiality (appadhāna).

1. Predominant materiality. Among consciousness-born clusters, with the non-concrete materiality included, are the ninefold cluster with bodily intimation and the twelvefold cluster with bodily intimation, lightness, malleability, wieldiness and the accompanying phenomena. The nine or twelve material phenomena in these two kinds of cluster are predominant when discerning postures and activities of clear comprehension. The wind element is especially strong in them. That strong wind element gives rise to bodily intimation, the bodily action.

2. Non-predominant materiality. The remaining material phenomena throughout the body at the six doors and in the forty-two parts are non-predominant. “Non-predominant” here refers specifically to discernment of postures and clear comprehension.


<a id="M04-body-P223"></a>
## Materiality producing motion and materiality moved
Miến / Burmese 223

Predominant materiality causes the remaining bodily clusters originated by kamma, consciousness, temperature and nutriment to occur in the manner of walking. The postural materiality producing motion, the ninefold or twelvefold clusters with bodily intimation, does not literally carry materiality from one place to another. “Producing motion” means causing materiality to arise successively at new locations. Ultimate materiality cannot leave the place of its arising and ceases there. As conditions continue to operate, new materiality arises in succession at new locations. This continuity is due to the strength of the clusters with strong wind element and bodily intimation.

Non-predominant materiality, the remaining phenomena produced by the four origins at the six doors and in the forty-two parts, is the materiality moved. These phenomena are not literally carried away…


<a id="M04-body-P224"></a>
## The simile of a person carrying a sack of rice
Miến / Burmese 224

… “being moved” means arising continuously at new locations in succession. When one apprehends the materiality producing motion as primary, apprehending the non-predominant materiality moved is accomplished along with it. That is, when attention is given to the materiality producing motion, the materiality moved is easily seen and discerned.

One may also give priority to the materiality moved, produced by the four origins. Giving priority to the non-predominant materiality moved makes it possible to see the predominant materiality producing motion. When the materiality moved is discerned as primary, discernment of the materiality producing motion is accomplished along with it (see Majjhima Commentary, vol. 1, p. 273).

For example, when someone carries a sack of rice, attending to the carrier makes the sack easy to see. Attending to the sack likewise makes the carrier easy to see. Remember this simile. See the section on materiality.


<a id="M04-body-P225"></a>
## How to discern the five aggregates while walking
Miến / Burmese 225

As explained above, stand on the walking path and re-establish your highest attained concentration. Analyse and apprehend the materiality from the four origins at the six doors and in the forty-two parts. Then step forward a little. Apprehend by giving priority in turn to the materiality producing motion and to that moved. Both belong to the materiality aggregate.

The mind-door process series with impulsion wishing to walk directly produce the postural materiality that brings about motion, and belong to the four mental aggregates. Apprehend those four aggregates. In these mind-door series, impulsion can be wholesome, functional or unwholesome. Mind-door processes are specified because five-door impulsion processes cannot produce postural materiality. Each mind-door process moment has four mental aggregates: feeling is the feeling aggregate, perception the perception aggregate, the remaining factors the formations aggregate, and knowing consciousness the consciousness aggregate. Supporting materiality, the postural materiality producing motion, and the materiality moved are the materiality aggregate. Together there are five aggregates. Once able to apprehend the five, apprehend mentality and materiality together, then distinguish them. Do the same in postures and activities of clear comprehension…


<a id="M04-body-P226"></a>
## Four tasks and internal and external contemplation
Miến / Burmese 226

… continue the four tasks: 1. Apprehending materiality (rūpapariggaha). 2. Apprehending mentality (arūpapariggaha). 3. Apprehending mentality and materiality together (rūpārūpapariggaha). 4. Delimiting mentality and materiality (nāmarūpavavatthāna). Once able to practise in this way, proceed a further step as the Buddha taught in the Mahāsatipaṭṭhāna Sutta.

Iti ajjhattaṃ vā kāye kāyānupassī viharati, bahiddhā vā kāye kāyānupassī viharati, ajjhattabahiddhā vā kāye kāyānupassī viharati.
One dwells contemplating body as body internally, externally, or both internally and externally (Majjhima Nikāya, vol. 1, p. 73).

Iti ajjhattaṃ vā vedanāsu vedanānupassī viharati, bahiddhā vā vedanāsu vedanānupassī viharati, ajjhattabahiddhā vā vedanāsu vedanānupassī viharati.
One dwells contemplating feelings as feelings internally, externally, or both internally and externally (Majjhima Nikāya, vol. 1, p. 75…).

Iti ajjhattaṃ vā citte cittānupassī viharati, bahiddhā vā citte cittānupassī viharati, ajjhattabahiddhā vā citte cittānupassī viharati.
One dwells contemplating mind as mind internally, externally, or both internally and externally (Majjhima Nikāya, vol. 1, p. 76).

Iti ajjhattaṃ vā dhammesu dhammānupassī viharati, bahiddhā vā dhammesu dhammānupassī viharati, ajjhattabahiddhā vā dhammesu dhammānupassī viharati.
One dwells contemplating phenomena as phenomena internally, externally, or both internally and externally (Majjhima Nikāya, vol. 1, p. 77).

In the foregoing Pāli, body, feelings, mind and phenomena refer to the five aggregates, that is, mentality and materiality…


<a id="M04-body-P227"></a>
## Why both internal and external contemplation are needed
Miến / Burmese 227

… Repeatedly apprehend and discern the five aggregates internally, externally, and both internally and externally. This is the Buddha’s instruction. The commentaries explain how to proceed in accordance with it.

Yasmā pana na suddhaajjhattadassanamatteneva maggavuṭṭhānaṃ hoti, bahiddhāpi daṭṭhabbameva. Tasmā parassa khandhepi anupādinnasaṅkhārepi aniccaṃ dukkhamanattāti passati.
Seeing only internally cannot bring emergence into the path. The external must also be seen. Hence one sees the aggregates of others and non-clung-to formations as impermanent, suffering, and non-self (Abhidhamma Commentary, vol. 1, p. 270. Visuddhimagga, vol. 2, p. 300).

Insight leading to emergence (vuṭṭhānagāminivipassanā) comprises two or three mind-door processes with insight impulsion immediately preceding the path process, emerging from formations as object towards Nibbāna, the unconditioned, the stilling of formations.


<a id="M04-body-P228"></a>
## The external domain and how to begin
Miến / Burmese 228

Tasmā sasantānagate sabbadhamme, parasantānagate ca tesaṃ santānavibhāgaṃ akatvā bahiddhābhāvasāmaññato sammasanaṃ, ayaṃ sāvakānaṃ sammasanacāro.
The disciples’ scope of comprehension is to discern all phenomena in their own continuum and the phenomena in others’ continua under the common designation external, without separating those continua (Majjhima Subcommentary, Uparipaṇṇāsa, subcommentary to the Anupada Sutta).

According to this instruction, when discerning externally within the scope of a disciple’s wisdom, do not separate males, females, persons, beings, humans, devas, brahmās or particular individuals. Discern collectively the five aggregates of living beings and temperature-born materiality in inanimate things, called non-clung-to formations. There is no need to discern each individual separately.

Once able to apprehend the internal five aggregates, mentality and materiality, down to ultimate reality, one can begin apprehending the external five aggregates. Some meditators begin externally. Those beginning internally still need to apprehend external aggregates and non-clung-to formations, since internal discernment alone cannot reach the noble path. Similarly, those who begin externally…


<a id="M04-body-P229"></a>
## Apprehending external materiality from clothing to inanimate objects
Miến / Burmese 229

… must also apprehend the internal five aggregates, since external discernment alone cannot reach the noble path (see Abhidhamma Commentary, vol. 1, pp. 270–271. Visuddhimagga, vol. 2, p. 300).

1. Re-establish concentration if needed. 2. When the light is strong, apprehend internal materiality again. 3. With the aid of that light, apprehend the four elements in the clothing being worn.

Seeing the four elements in clothing with wisdom makes the minute material clusters easy to see. If unsuccessful, return to internal materiality and then to the four elements in the clothing. When the mass of the elements is seen, attend to the space element with the aid of the light. The minute clusters will readily appear. The clothing will then appear as a collection of clusters. Analyse them. The materiality in each is temperature-born materiality with nutriment as the eighth, arising in succession due to the fire element in the cluster. Gradually extend wisdom to the four elements in trees, water, earth, forests, mountains, gold, silver, bricks and stones…


<a id="M04-body-P230"></a>
## Extending external discernment of materiality and mentality
Miến / Burmese 230

… in the inanimate world. When only the minute clusters are seen, analyse them until wisdom penetrates ultimate materiality. There are only two kinds in the inanimate world: temperature-born octads and temperature-born octads with sound.

Continue apprehending concrete and non-concrete materiality at the six doors and in the forty-two parts of the external animate world following the internal pattern. Begin nearby. For example, apprehend the fifty-four material phenomena at the eye internally, then the fifty-four at nearby external eyes collectively, without distinguishing males, females, brahmās or particular individuals. Apprehend one round internally and one externally to strengthen development. Do likewise at the remaining five doors and in the forty-two parts. When all concrete and non-concrete materiality there is seen, apprehend it as “materiality, materiality”, alternating internal and external. Gradually extend to the thirty-one planes and, if possible, to innumerable world systems. Remember that alternating internal and external strengthens development.

Next apprehend mentality in all six groups following the internal pattern. For example, when apprehending visible-object mentality internally, apprehend the eye-door and mind-door together and take as object the colour of many material clusters or of one cluster. According to wise attention…


<a id="M04-body-P231"></a>
## Apprehending external processes collectively
Miến / Burmese 231

… or unwise attention, apprehend the wholesome or unwholesome group in eye-door and mind-door processes. Follow the same pattern externally, collectively, without separating eye-sensitivity, life-continuum and visible form by individual.

1. Apprehend simultaneously eye-sensitivity, the eye-door, and the clear life-continuum, the mind-door. 2. Take the colour of many material clusters or of one cluster as object. Apprehend wholesome and unwholesome mentality of eye-door and mind-door processes arising according to wise or unwise attention. Understand the sound group and the remaining groups similarly. If discernment can reach as far as the thirty-one planes, gradually extend it to innumerable world systems. Alternate internal and external to strengthen development.

When discerning external mentality and materiality, group them by the shared feature of being external, without separating continua by male, female, person, being, human, deva, brahmā or individual. In discerning the thirty-two parts externally, the thirty-two parts in a being’s continuum can be discerned…


<a id="M04-body-P232"></a>
## The scope of insight and four steps of practice
Miến / Burmese 232

… Thus in apprehending external materiality, one can analyse and discern all materiality, including that in the thirty-two parts of a being’s continuum. As for mentality, within the scope of insight one cannot know precisely another individual’s mind by insight knowledge. Knowing another person’s mind precisely belongs to the direct knowledge of others’ minds (cetopariyañāṇa). In insight, discern collectively without separating persons and beings. This is the disciples’ domain of comprehension, the scope of knowledge discerning by the three characteristics.

When successful in apprehending mentality and materiality both internally and externally, practise in sequence in both domains: 1. Apprehend materiality separately at the six doors and in the forty-two parts. 2. Apprehend mentality separately in all six groups. 3. Apprehend and distinguish mentality and materiality together in all six groups. 4. Delimit mentality and materiality in all six groups.

After repeatedly performing those four tasks internally and externally, proceed a step further as instructed by the Buddha below…


<a id="M04-body-P233"></a>
## Contemplating arising and passing away by condition and by moment
Miến / Burmese 233

Samudayadhammānupassī vā kāyasmiṃ viharati, vayadhammānupassī vā kāyasmiṃ viharati, samudayavayadhammānupassī vā kāyasmiṃ viharati.
One dwells contemplating the nature of arising in the body, the nature of passing away in the body, or both (Majjhima Nikāya, vol. 1, p. 73). The same pattern is taught for feelings, mind and phenomena.

Here the Buddha teaches developing insight up to seeing arising and passing away by condition (paccayato udayabbayadassana) and by moment (khaṇato udayabbayadassana).

1. See the arising of the five resultant aggregates because such causes as ignorance, craving, clinging, formations and kamma arise. This is seeing arising by condition.
2. See that the five resultant aggregates do not arise again after final Nibbāna because causes such as ignorance, craving, clinging, formations and kamma have been cut off by the arahant path and do not arise again. This is seeing passing away by condition.
3. See the moment of arising of both causes and effects, seeing arising by moment.
4. See the moment of dissolution of both causes and effects…


<a id="M04-body-P234"></a>
## Three knowledges and two ways of apprehending conditions
Miến / Burmese 234

… seeing passing away by moment. The Buddha taught apprehending these four aspects by wisdom and discerning the causative and resultant formations according to the three characteristics. Here he teaches together knowledge apprehending conditions, comprehension knowledge, and knowledge of arising and passing away. Knowledge apprehending conditions also has two modes: apprehending conditions and apprehending by inference.

Apprehending conditions (paccayapariggaha) emphasizes seeing the five present effects, consciousness, mentality-materiality, the six bases, contact and feeling, arising because of the respective past causes cultivated, such as ignorance, craving, clinging, formations and kamma. Apprehending by inference (anvayapariggaha) apprehends the corresponding causes and effects in successive past and future lives. Both are collectively called knowledge apprehending conditions, also the section on purification by overcoming doubt. Development of this knowledge will be explained in the section on dependent origination by the fifth and first methods.


<a id="M04-body-P235"></a>
## Developing the four foundations of mindfulness and choosing a starting point
Miến / Burmese 235

Yasmā pana na suddharūpadassanamatteneva vuṭṭhānaṃ hoti, arūpampi daṭṭhabbameva.
Insight into materiality alone by the three characteristics cannot reach noble path knowledge or amount to insight leading to emergence. Mentality too must be discerned by the three characteristics (Abhidhamma Commentary, vol. 1, p. 270. Visuddhimagga, vol. 2, p. 300).

When first attending to and apprehending mentality and materiality as objects of insight, one may begin with either materiality or mentality. Beginning with materiality is possible both for one whose vehicle is tranquillity and for one whose vehicle is insight (see Visuddhimagga, vol. 2, p. 222. Mahāṭīkā, vol. 2, p. 373).

Pariggahite rūpakammaṭṭhāneti idaṃ rūpamukhena vipassanābhinivesaṃ sandhāya vuttaṃ, arūpamukhena pana vipassanābhiniveso yebhuyyena samathayānikassa icchitabbo. So ca paṭhamaṃ jhānaṅgāni pariggahetvā tato paraṃ sesadhamme pariggaṇhāti.
The subcommentary says that “having apprehended materiality” implies beginning insight with materiality. Starting from mentality is more usual for one whose vehicle is tranquillity, who first apprehends the jhāna factors and then the associated phenomena (Majjhima Subcommentary, vol. 1, p. 369). The bare-insight practitioner generally begins apprehending mentality and materiality as insight objects with materiality…


<a id="M04-body-P236"></a>
## Beginning with materiality or mentality and proceeding with both
Miến / Burmese 236

… For this reason the commentary says that one wishing to begin the subject of mentality should first have apprehended materiality. Beginning with mentality in apprehending the objects of insight is generally appropriate for one whose vehicle is tranquillity. Such a person first apprehends the jhāna factors, then the associated phenomena together with mentality and materiality called ordinary formations (Majjhima Subcommentary, vol. 1, p. 369). See also Visuddhimagga, vol. 2, p. 222, and Mahāṭīkā, vol. 2, p. 373.

Even when beginning with materiality as an insight object, discerning materiality alone cannot reach the noble path. Continue to apprehend and discern mentality arising with materiality as object. Even when beginning with mental formations as insight objects, discerning mentality alone cannot reach the noble path. Continue to apprehend and discern materiality. Earlier the Aparijānana Sutta was cited, where the Buddha says suffering cannot be ended without fully distinguishing and knowing all five aggregates of mentality and materiality through the three kinds of full understanding…


<a id="M04-body-P237"></a>
## The four foundations distinguished in the preparatory phase
Miến / Burmese 237

The Buddha teaches that suffering cannot be ended without fully distinguishing and knowing all five aggregates through the three kinds of full understanding. The commentaries also explain that neither discerning materiality alone nor mentality alone can reach the noble path. When discerning materiality, distinguish the elements and derived materiality by wisdom and discern them with insight. When discerning mentality, distinguish by wisdom the four mental aggregates of feeling, perception, formations, and consciousness arising with materiality as object and discern them with insight (Abhidhamma Commentary, vol. 1, pp. 270–271. Visuddhimagga, vol. 2, pp. 300–301). The discourses and commentaries agree like the waters of the Gaṅgā and Yamunā. Thus the commentaries explain the foundations of mindfulness as follows.

Iti ime cattāro satipaṭṭhānā pubbabhāge nānācittesu labbhanti. Aññeneva hi cittena kāyaṃ pariggaṇhāti, aññena vedanaṃ, aññena cittaṃ, aññena dhamme pariggaṇhāti. Lokuttaramaggakkhaṇe pana ekacitteyeva labbhanti. Ādito hi kāyaṃ pariggaṇhitvā āgatassa vipassanāsampayuttā sati kāyānupassanā nāma, tāya satiyā samannāgato puggalo kāyānupassī nāma. Vipassanaṃ ussukkāpetvā ariyamaggaṃ pattassa maggakkhaṇe maggasampayuttā sati kāyānupassanā nāma, tāya satiyā samannāgato puggalo kāyānupassī nāma. Vedanaṃ pariggaṇhitvā, cittaṃ pariggaṇhitvā, dhamme pariggaṇhitvā āgatassa vipassanāsampayuttā sati…
Question: Are the four foundations of mindfulness obtained in different consciousnesses in the preparatory phase? Yes. One apprehends body, feelings, mind and phenomena in different consciousnesses. At the supramundane moment, however, they are obtained in the same consciousness. After apprehending the body, mindfulness associated with insight is called contemplation of the body, and one endowed with it a contemplator of the body. When insight is brought to maturity and the noble path is reached, mindfulness associated with the path is likewise called contemplation of the body, and one endowed with it a contemplator of the body. Similarly, after apprehending feelings, mind, or phenomena…


<a id="M04-body-P238"></a>
## Four functions of one mindfulness at the path moment
Miến / Burmese 238

… dhammānupassanā nāma, tāya satiyā samannāgato puggalo dhammānupassī nāma. Vipassanaṃ ussukkāpetvā ariyamaggaṃ pattassa maggakkhaṇe maggasampayuttā sati dhammānupassanā nāma, tāya satiyā samannāgato puggalo dhammānupassī nāma. Evaṃ tāva desanā puggale tiṭṭhati.
… mindfulness associated with insight and mindfulness associated with the noble path are respectively called contemplation of feelings, mind or phenomena. A person endowed with the relevant mindfulness is called a contemplator of feelings, mind or phenomena. This is exposition in terms of the person.

Kāye pana “subhan”ti vipallāsappahānā kāyapariggāhikā sati maggena samijjhatīti kāyānupassanā nāma. Vedanāya “sukhan”ti vipallāsappahānā vedanāpariggāhikā sati maggena samijjhatīti vedanānupassanā nāma. Citte “niccan”ti vipallāsappahānā cittapariggāhikā sati maggena samijjhatīti cittānupassanā nāma. Dhammesu “attā”ti vipallāsappahānā dhammapariggāhikā sati maggena samijjhatīti dhammānupassanā nāma.
In terms of phenomena, 1. Mindfulness apprehending the body, abandoning the distortion of seeing beauty in it, is fulfilled by the path and is called contemplation of the body. 2. Mindfulness apprehending feeling, abandoning the distortion of seeing pleasure in it, is fulfilled by the path and is called contemplation of feelings. 3. Mindfulness apprehending mind, abandoning the distortion of seeing permanence in it, is fulfilled by the path and is called contemplation of mind. 4. Mindfulness apprehending phenomena, abandoning the distortion of seeing self in them, is fulfilled by the path and is called contemplation of phenomena.

Iti ekāva maggasampayuttā sati catukiccasādhanena cattāri nāmāni labhati. Tena vuttaṃ “lokuttaramaggakkhaṇe pana ekacitteyeva labbhantī”ti.
Question: Why does one mindfulness associated with the path have four names? Because it accomplishes four functions. Hence the four foundations are said to be obtained in a single consciousness at the supramundane moment (Abhidhamma Commentary, vol. 2, pp. 273–274).

The Buddha teaches contemplation of the body with both tranquillity and insight. Contemplation of feelings, mind and phenomena is taught by insight. Before the noble path, the four foundations are obtained in different consciousnesses: 1. Consciousness apprehending the body is one distinct kind. 2. Consciousness apprehending feelings is a distinct kind…


<a id="M04-body-P239"></a>
## Contemplation of body and feelings, and names according to the person
Miến / Burmese 239

… 3. Consciousness apprehending mind is a distinct kind. 4. Consciousness apprehending phenomena is a distinct kind. At the supramundane noble-path moment, however, all four foundations are obtained in a single consciousness.

1. When a meditator initially apprehends and distinguishes the body by wisdom and proceeds to insight, mindfulness associated with that insight knowledge is called contemplation of the body (kāyānupassanā). A person endowed with it is a contemplator of the body (kāyānupassī). When the meditator strives to bring insight to the noble path, mindfulness associated with the path is also called contemplation of the body, and one endowed with it a contemplator of the body. There are two bodies, the mental body and the material body (Paṭisambhidāmagga, vol. 1, pp. 177–178).

2. When a meditator initially apprehends and distinguishes feelings by wisdom and proceeds to insight, mindfulness associated with that insight knowledge is called contemplation of feelings (vedanānupassanā). One endowed with it is a contemplator of feelings (vedanānupassī). When the meditator strives to bring insight to the noble path, mindfulness associated with the path is also called contemplation of feelings, and one endowed with it a contemplator of feelings.
3. When a meditator initially apprehends and distinguishes mind by wisdom and proceeds to insight…


<a id="M04-body-P240"></a>
## Contemplation of mind and phenomena, and names according to phenomena
Miến / Burmese 240

… mindfulness associated with insight knowledge is called contemplation of mind (cittānupassanā). One endowed with it is a contemplator of mind (cittānupassī). When the meditator strives to bring insight to the noble path, mindfulness associated with the path is likewise called contemplation of mind, and one endowed with it a contemplator of mind.

4. When a meditator initially apprehends and distinguishes phenomena by wisdom and proceeds to insight, mindfulness associated with insight knowledge is called contemplation of phenomena (dhammānupassanā). One endowed with it is a contemplator of phenomena (dhammānupassī). When the meditator strives to bring insight to the noble path, mindfulness associated with the path is likewise called contemplation of phenomena, and one endowed with it a contemplator of phenomena.

The names contemplator of body, feelings, mind and phenomena follow the course of insight before reaching the noble path. This is exposition by person. For exposition by phenomena understand as follows. 1. Mindfulness apprehends and distinguishes the body, abandons the distortion that grasps it as beautiful, and is fulfilled through the noble path. Thus it is called contemplation of the body. 2. Mindfulness apprehends and distinguishes feelings and abandons the distortion that grasps them as pleasant…


<a id="M04-body-P241"></a>
## One mindfulness completes four tasks
Miến / Burmese 241

… and is fulfilled through the noble path, so it is called contemplation of feelings. 3. Mindfulness apprehends and distinguishes mind, abandons the distortion that grasps it as permanent, and is fulfilled through the noble path, so it is called contemplation of mind. 4. Mindfulness apprehends and distinguishes phenomena, abandons the distortion that grasps them as self, and is fulfilled through the noble path, so it is called contemplation of phenomena.

One mindfulness associated with the noble path has four names because it completes the four tasks of abandoning distortions that grasp beauty, pleasure, permanence and self. Thus the commentary says that the four foundations are obtained in one consciousness at the supramundane noble-path moment (Abhidhamma Commentary, vol. 2, pp. 273–274).

The discourse states that without fully distinguishing the mentality and materiality of the five aggregates subject to clinging by the three kinds of full understanding, one cannot reach the noble path or put an end to the suffering of saṃsāra. The commentaries also say that discerning the internal five aggregates alone, the external alone, materiality alone, or mentality alone cannot lead to the noble path…


<a id="M04-body-P242"></a>
## Practising the four foundations from four starting points
Miến / Burmese 242

… In light of these instructions, remember the four foundations as follows.

Begin with materiality, apprehend mentality and materiality, and seek their conditions. Discerning that mentality and materiality with their conditions according to the three characteristics is developing the foundation of mindfulness called contemplation of the body.

Begin with feeling, apprehend mentality and materiality, and seek their conditions. Discerning that mentality and materiality with their conditions according to the three characteristics is developing the foundation of mindfulness called contemplation of feelings.

Begin with knowing consciousness, apprehend mentality and materiality, and seek their conditions. Discerning that mentality and materiality with their conditions according to the three characteristics is developing the foundation of mindfulness called contemplation of mind.

Begin with contact, apprehend mentality and materiality, and seek their conditions. Discerning that mentality and materiality with their conditions according to the three characteristics is developing the foundation of mindfulness called contemplation of phenomena.

For contemplation of phenomena one may also begin with the five hindrances or the seven awakening factors and discern the causative and resultant formations of mentality and materiality. Discerning these formations by the five aggregates, twelve bases, the truths and similar schemes also develops contemplation of phenomena. A meditator wishing to apprehend mentality led by feeling, knowing consciousness, or contact…


<a id="M04-body-P243"></a>
## Three points to remember about practising the foundations
Miến / Burmese 243

… should apprehend together the supporting materiality and the material object of that mentality. After apprehending mentality, apprehend the supporting materiality again so that mentality and materiality are apprehended together. This was explained repeatedly above.

1. Developing one foundation of mindfulness is called developing all four. 2. Discerning the five aggregates thoroughly by the three kinds of full understanding is developing the foundations. 3. If the five aggregates of mentality and materiality have yet to be apprehended down to ultimate reality and discerned together with their conditions according to the three characteristics, that practice does not yet constitute developing all four foundations. Those who earnestly seek the true Dhamma and aspire to Nibbāna should remember these three points with care.

Consciousness in processes and consciousness outside processes are summarized here for ease of recollection.


<a id="M04-body-P244"></a>
## In the seen, only the seen
Miến / Burmese 244

Tasmātiha te, Bāhiya, evaṃ sikkhitabbaṃ: diṭṭhe diṭṭhamattaṃ bhavissati, sute sutamattaṃ bhavissati, mute mutamattaṃ bhavissati, viññāte viññātamattaṃ bhavissatīti.
Bāhiya, train in this way: in the seen there will be only the seen, in the heard only the heard, in the sensed only the sensed, and in the cognized only the cognized (Udāna, p. 85).

The Buddha taught this practice in the Māluṅkyaputta Sutta (Saṃyutta Nikāya, vol. 2, p. 94) and the Bāhiya Sutta (Udāna, p. 85). Its meaning is as follows.

Ettha hi rūpāyatanaṃ passitabbaṭṭhena diṭṭhaṃ nāma, cakkhuviññāṇaṃ pana saddhiṃ taṃdvārikaviññāṇehi dassanaṭṭhena. Tadubhayampi yathāpaccayaṃ pavattamānaṃ dhammamattameva, na ettha koci kattā vā kāretā vā. Yato taṃ hutvā abhāvaṭṭhena aniccaṃ, udayabbayappaṭipīḷanaṭṭhena dukkhaṃ, avasavattanaṭṭhena anattāti, kuto tattha paṇḍitassa rajjanādīnaṃ okāsoti? Ayamettha adhippāyo sutādīsupi.
The explanation calls the visible-form base “the seen” because it is what is to be seen. It also calls eye-consciousness and consciousnesses in the eye-door and subsequent mind-door processes taking that object “the seen” in the sense that they see visible form. They proceed according to conditions. No one does it or makes them do it. Seen in terms of arising and passing away and their independence of anyone’s will, they are impermanent, suffering and non-self. Understand the heard and the remaining kinds similarly (Udāna Commentary, p. 152).

Meditators should apprehend: 1. Visible form that is seen and eye-door and mind-door mentality that sees it. 2. Sound that is heard and ear-door and mind-door mentality that hears it…


<a id="M04-body-P245"></a>
## The seen, heard, sensed and cognized as objects of insight
Miến / Burmese 245

3. Odours, tastes and tangibles that are sensed, and the mentality of nose-door, tongue-door, body-door and corresponding mind-door processes that senses them. 4. Mind objects that are cognized and mind-door mentality that cognizes them.

First apprehend that mentality and materiality. Then seek the causes that bring them about, such as ignorance, craving, clinging, formations and kamma, and discern deeply the seen, heard, sensed and cognized together with their causes by the three characteristics. When one practises this way, greed, hatred and delusion have no opportunity to arise on account of those objects. Instead, mind-door process series with great wholesome insight impulsion arise continuously. When insight knowledge develops to the noble path, the practice of “in the seen, only the seen” is fulfilled.

Some teachers say, “When seeing, keep the mind only at seeing. Do not let other consciousnesses arise further on that object.” This point calls for further explanation.

Ettha pana cakkhuviññāṇameva dassanakiccaṃ sādheti.
Here eye-consciousness alone accomplishes the function of seeing visible form (Abhidhamma Commentary, vol. 1, p. 130).


<a id="M04-body-P246"></a>
## Eye-consciousness sees and the process continues according to conditions
Miến / Burmese 246

If “keep the mind only at seeing” is understood to mean allowing only eye-consciousness to arise with visible form as object and preventing other process consciousnesses from arising, the question is whether a disciple can train to make that happen. The commentary explains as follows.

Sace pana bhavaṅgaṃ āvaṭṭeti, kiriyāmanodhātuyā bhavaṅge āvaṭṭite voṭṭhabbanaṃ appāpetvā antarā cakkhuviññāṇe vā sampaṭicchane vā santīraṇe vā ṭhatvā nivattissatīti netaṃ ṭhānaṃ vijjati. Voṭṭhabbanavasena pana ṭhatvā ekaṃ vā dve vā tīṇi vā cittāni vattanti.
If the life-continuum has been turned and interrupted by five-door adverting, the functional mind-element, the process cannot stop at eye-consciousness, receiving or investigating and return to life-continuum before reaching determining. Determining consciousness can arise once, twice or three times to perform the function of determining the object (Abhidhamma Commentary, vol. 1, pp. 129–130).

Here the commentary uses a slight-object process as an example. When visible form impinges, or appears before the eye-door and mind-door, a slight object must reach determining, a great object impulsion, and a very great object registration. The process cannot stop midway before those points. Understand similarly for heard and sensed objects. An object appearing at the mind-door…


<a id="M04-body-P247"></a>
## Where a process ends and what “only” means
Miến / Burmese 247

… if indistinct cannot stop before impulsion, and if clear cannot stop before registration. With objects appearing at the two corresponding doors: 1. A slight object reaches determining. 2. A great object reaches impulsion. 3. A very great object reaches registration. At the mind-door: 1. A clear object reaches registration. 2. An indistinct object reaches impulsion. Only then does the process return to life-continuum.

Therefore train in “in the seen only the seen”, “in the heard only the heard”, “in the sensed only the sensed”, and “in the cognized only the cognized”. These words do not mean letting only eye-consciousness arise when seeing, only ear-consciousness when hearing, or only nose-, tongue-, or body-consciousness when sensing, and training to suppress the subsequent process consciousnesses. Their meaning is…


<a id="M04-body-P248"></a>
## The meaning for practice and closing aspiration
Miến / Burmese 248

1. The phenomena seen and the phenomena that see. 2. The phenomena heard and the phenomena that hear. 3. The phenomena sensed and the phenomena that sense. 4. The phenomena cognized and the phenomena that cognize. Having apprehended and distinguished them by wisdom, seek their causes and discern deeply the seen, heard, sensed and cognized together with their causes by the three characteristics. Remember this as the main point. It is an instruction for practising so that greed, hatred and delusion do not arise in relation to the seen, heard, sensed and cognized.

May you practise diligently and realize Nibbāna for yourselves in this very life, making full use of the opportunity to encounter the Buddha’s dispensation and following in the footsteps of arahants such as Venerable Bāhiya Dārucīriya and Venerable Māluṅkyaputta…

Pa-Auk Tawya Sayadaw
Cittalapabbata Monastery, Pa-Auk Tawya
Myanmar Era 1367.


<a id="M04-index-P001"></a>
## Alphabetical index — Burmese page 249
Chỉ mục / Index - Miến / Burmese 249

Seven unwholesome-resultant consciousnesses — 22

The term universal unwholesome mental factors — 38

Fourteen unwholesome factors and the four universal unwholesome factors — 38

Twelve unwholesome consciousnesses — 20

Does discerning the unwholesome make more of it arise? — 166

Forty supramundane consciousnesses in the detailed classification — 31

Ethically variable mental factors — 37

Very slight object — 19

Very great object — 18

Very-great-object eye-door process ending in registration — 136

Past life-continuum — 135

Breaking compactness of collection — 212

Two kinds of clinging to self — 41

Apprehending by inference — 234

Sequential insight into individual phenomena — 69

Four contemplations — 52

The term non-clung-to formations — 228

The further interpretation — 89

Non-predominant materiality — 222

Two immeasurable mental factors — 49, 126

Part 1. Points to know about consciousness — 1

Part 2. Points to know about mental factors — 33

Part 3. How to apprehend — 74

Part 4. Apprehending the unwholesome group — 166

Part 5. Mental compactness — 209

Part 6. Postures and clear comprehension — 218

Long-lived sensitivity — 139


<a id="M04-index-P002"></a>
## Alphabetical index — Burmese page 250
Chỉ mục / Index - Miến / Burmese 250

Unwise attention — 95

Four noble fruition consciousnesses — 30

Knowledge apprehending mentality — 4

Twelve immaterial-sphere consciousnesses, four wholesome — 28

An important rule — 58

Venerable Nāgasena — 65

An exceedingly difficult task — 66

Fetter of ignorance — 193

Indistinct object — 19

Misapprehension, ignorance or delusion — 40

Misapprehension and mistaken adherence — 176

Right knowing, right view or wisdom faculty — 40

Three rootless functional consciousnesses — 23

Seven rootless unwholesome-resultant consciousnesses — 23

The term rootless consciousness — 24

Eighteen rootless consciousnesses — 22

A beginning meditator — 80

Breathing counterpart sign as object — 74

Thirty-four first-jhāna mental phenomena taking the breathing counterpart sign — 81

Breaking compactness of object — 216

Compactness of object in object-taking mentality — 214

Objects and exceptions — 85

Six objects — 14

The term object (ārammaṇa) — 15

Discerning postures and clear comprehension — 218

Fetter of envy — 191

Two rules — 10

The brain and knowing wisdom — 162

The brain — 162


<a id="M04-index-P003"></a>
## Alphabetical index — Burmese page 251
Chỉ mục / Index - Miến / Burmese 251

Guest life-continuum — 109

The term faculty materiality — 15

Resident life-continuum — 108

Right speech as utterance — 121

The body of the doer — 72

Compassion — 126

Method of analysing clusters — 69

Sense-sphere object — 104

Sense-sphere mentality — 26

Fetter of sensual desire — 189

Sensual thought — 169

Twenty-four beautiful sense-sphere consciousnesses — 24

Body-door process — 18

Contemplation of the body — 239

Contemplator of the body — 239

Compactness of mental function — 212

Breaking compactness of function — 215

The term functional consciousness — 24

Right action as activity — 121

One hundred thousand koṭis — 1

Conditions for wholesome impulsion — 144

A suitable way to practise — 187

Scriptural statement — 1

Points to know beforehand — 132

Two points to remember beforehand — 7

Things to remember beforehand — 12

Discerning the five aggregates — 220

Example of discerning the five aggregates — 220

How to discern the five aggregates — 225

Summary table of the six groups — 204

Like the confluence of the Gaṅgā and Yamunā — 237

Apprehending the wholesome odour group — 158


<a id="M04-index-P004"></a>
## Alphabetical index — Burmese page 252
Chỉ mục / Index - Miến / Burmese 252

The Discourse on the Simile of the Snake — 5

Compactness — 209

Four kinds of compactness — 210

Nose-door process — 17

The simile of the bird — 134

Discerning greed and wrong view with eye-sensitivity as object — 184

Discerning greed and conceit with eye-sensitivity as object — 185

Thirty-four great wholesome mental phenomena taking eye-sensitivity — 96

Eye-door process — 17

Abbreviations in the eye-door process — 135

Fourth bare mind-door process — 143

Regularity of consciousness — 211

Contemplation of mind — 240

Contemplator of mind — 240

Death consciousness — 12

Right action as volition — 121

Right speech as volition — 121

Fifty-two mental factors — 34

Table of counts of consciousness and mental factors — 154

Four characteristics of mental factors associated with consciousness — 33

Consciousness — 20

Tongue-door process — 18

Clinging to the living principle as self — 43

Apprehending jhāna mentality — 79

For those who have attained jhāna — 78

What is known and the knowledge — 153, 214


<a id="M04-index-P005"></a>
## Alphabetical index — Burmese page 253
Chỉ mục / Index - Miến / Burmese 253

Third bare mind-door process — 142

Registration after unwholesome impulsion — 186

Points to know about registration — 104

Registration table for three-rooted worldlings — 107

Further explanations — 155

Further explanation — 8, 39

The seen — 244

Fetter of wrong view — 190

In the seen, only the seen — 243, 244

Second mind-door process — 142

Second great-object eye-door process ending in impulsion — 137

Two cases of hatred and envy — 172

Four mental factors of the hatred group — 43

Two cases of the hatred group — 171

Four cases of hatred and remorse — 172

Two cases of hatred and stinginess — 172

Two hatred-rooted consciousnesses — 21

Two uses of the term door — 10

Door — 13

Six doors — 13, 78

Exposition in terms of phenomena — 240

Contemplation of phenomena — 240

Contemplator of phenomena — 240

Immeasurable factors in sense-sphere mind-door processes — 128

Table for recollection of the Buddha and death — 131

Mind-door jhāna attainment process table — 74

Wholesome mind-door process table with concrete materiality — 111


<a id="M04-index-P006"></a>
## Alphabetical index — Burmese page 254
Chỉ mục / Index - Miến / Burmese 254

Wholesome mind-door process table with non-concrete materiality — 115

Unwholesome mind-door process table taking mind objects — 183

Abstinence factors in mind-door processes — 120

Wholesome bare mind-door process table — 99

Six kinds of mind objects — 14

Knowledge delimiting mentality — 85

Delimiting mentality and materiality — 208

Following mind-door process — 141

Detailed method of apprehending mentality — 202

Three ways of apprehending mentality — 2

How to apprehend mentality — 57

The term mental cluster — 33

Four kinds of mental compactness — 209

Apprehending all mental phenomena — 57

Seeing mentality arise by wisdom — 78

Apprehending mentality as mentality — 205

Distinguishing mentality and materiality — 91

Comparative simile — 4

The term occasional mental factor — 37

Six occasional mental factors — 36

Apprehending conditions — 234

Operation of five-door and mind-door processes — 141

Fifth bare mind-door process — 143

The single wisdom-faculty factor — 49

The term wisdom faculty — 50

Example of apprehending unwholesome mentality taking a concept — 175

Rebirth-linking consciousness — 12


<a id="M04-index-P007"></a>
## Alphabetical index — Burmese page 255
Chỉ mục / Index - Miến / Burmese 255

First slight-object eye-door process ending in determining — 137

First great-object eye-door process ending in impulsion — 136

Predominant materiality — 222

Domain of direct knowledge of others’ minds — 232

Clinging to a supreme self — 42

Slight object — 18

Concrete materiality to discern by the model — 113

Nine non-concrete material phenomena to discern by the model — 115

Materiality cannot move from place to place — 223

Rules when starting from contact — 57

The five phenomena beginning with contact — 56

Like a snake — 60

Apprehending the wholesome tangible-object group — 160

Example of external discernment — 228

The elders’ interpretation — 89

Recollection of the Buddha — 128

Jhāna attainment processes for the four divine abidings — 77

Fetter of desire for existence — 189

A person sitting and listening to the Buddha teach — 71

Fetter of stinginess — 192

Medium-lived eye-sensitivity — 138

The term medium-lived — 139

The middle of the deer’s body — 70

Mind-door process — 18

Apprehending mind-door processes with wholesome impulsion — 100

Mind-consciousness — 16

Short-, long- and medium-lived sensitivity — 138

The term short-lived — 139

Recollection of death — 130


<a id="M04-index-P008"></a>
## Alphabetical index — Burmese page 256
Chỉ mục / Index - Miến / Burmese 256

Great object — 18

Eight great wholesome consciousnesses — 24

Eight great functional consciousnesses — 26

Eight great resultant consciousnesses — 25

Fetter of conceit — 191

Deceit and duplicity — 48

Māluṅkyaputta Sutta — 244

Milindapañha — 65

Appreciative joy — 126

Delusion-and-restlessness group — 173

The single factor in the delusion group — 44

Brief distinction between delusion and wrong view — 43

Two delusion-rooted consciousnesses — 22

Delusion-and-doubt group — 173

Six pairs of mental factors — 90

Wise attention — 151

Wise and unwise attention — 93

Definition of wise attention — 94

Apprehending the wholesome taste group — 159

Knowledge apprehending materiality — 4

Wholesome-group table taking colour as object — 147

Unwholesome impulsion table taking colour as object — 196

How to discern the unwholesome visible-object group — 197

How to discern the wholesome visible-object group — 145

Fifteen fine-material-sphere consciousnesses, five wholesome — 27

Absence of intermixture of mentality and materiality — 9

Presence of intermixture of mentality and materiality — 8

Apprehending materiality again — 73


<a id="M04-index-P009"></a>
## Alphabetical index — Burmese page 257
Chỉ mục / Index - Miến / Burmese 257

Materiality cannot move — 63

Apprehending mentality and materiality together — 206

Proceeding a step further — 232

Discernment for progressing further — 226

An example of the discernment method — 221

Worldly example — 91

Clinging to self through worldly convention — 41

The term mundane consciousness — 30

Mundane mentality — 10

Eight supramundane consciousnesses in brief, four noble path consciousnesses — 30

Worldly simile — 224

Three factors of the greed group — 38

Twenty mental phenomena of greed and wrong view — 179

Four cases of greed and wrong view — 170

Four cases of greed and conceit — 171

Eight greed-rooted consciousnesses — 20

Four main tasks — 226

Apprehending base and object together — 68

Six material bases of mentality — 13

The elders’ interpretation — 89

Four process types — 146

Fetter of doubt — 193

Six consciousness elements — 15

Rules for apprehending from consciousness — 56

Applied thought, volition and attention — 37

Applied thought, sustained thought and joy — 75

Types of consciousness serving as objects of insight knowledge — 39

The distinction between resultants and impulsion — 107

Clear object — 19

Three abstinence factors — 49

Right livelihood as abstinence — 122

Right action as abstinence — 121

Right speech as abstinence — 121

Six cognitive processes — 18


<a id="M04-index-P010"></a>
## Alphabetical index — Burmese page 258
Chỉ mục / Index - Miến / Burmese 258

Thought of harming — 169

The basis for possible transgression and the basis for abstinence — 124

Names of the process consciousnesses — 79

Cessation of process consciousnesses — 246

Six processes — 16

Energy and desire — 181

Right livelihood as activity — 122

Insight leading to emergence — 51

The term insight leading to emergence — 227

Rules for apprehending from feeling — 55

Contemplation of feelings — 239

Contemplator of feelings — 239

The term formations — 39

Four foundations of mindfulness — 242

Developing the four foundations of mindfulness — 235

Note — 157

Point to note — 194

Interpretations to note — 88

Apprehending the wholesome sound group — 156

The sound, odour, taste and tangible groups — 200

Compactness of mental continuity — 210

Breaking compactness of continuity — 215

Seven universal mental factors — 34

Naturally exceptionally desirable object — 107

Naturally undesirable object — 107

Naturally desirable object — 107

One whose vehicle is tranquillity — 6

For one whose vehicle is tranquillity — 236

Abstinence through undertaking — 122

Abstinence through eradication — 123

Compactness of mental collection — 211

Breaking compactness of collection — 215

Abstinence upon encountering an occasion — 122


<a id="M04-index-P011"></a>
## Alphabetical index — Burmese page 259
Chỉ mục / Index - Miến / Burmese 259

Objects of abstinence upon encountering an occasion and through undertaking — 123

Abstinence upon encountering an occasion, through undertaking, and through eradication — 122

The term associated phenomena — 35

Right livelihood — 122

Right livelihood as abstinence — 119

Definition of right livelihood as abstinence — 119

Right action as abstinence — 118

Definition of right action as abstinence — 118

Three kinds of right action — 121

Right speech as abstinence — 117

Definition of right speech — 117

Three kinds of right speech — 121

Two factors that can accompany the prompted group — 44

Fetter of attachment to rules and observances — 190

The term subtle materiality — 15

Bare mind-door process — 141

One whose vehicle is bare insight — 3

Ear-door process — 17

Twenty-five beautiful mental factors — 45

Beautiful consciousnesses — 24

Nineteen universal beautiful mental factors — 45

Fetters — 190

How the ten fetters arise — 188

Materiality producing motion and materiality moved — 223
