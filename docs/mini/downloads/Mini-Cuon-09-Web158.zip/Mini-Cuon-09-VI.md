# Nibbānagāminipaṭipadā · Mini · Cuốn 9 / Volume 9
Đề mục thiền minh sát (Vipassanākammaṭṭhāna)
Pa-Auk Tawya Sayadaw
Việt

## Mục lục / Contents

- [Bìa trước và bìa sau](#M09-cover-P001)
- [Trang nhan đề](#M09-front-P001)
- [Pháp thí và lời nguyện](#M09-front-P002)
- [Mục lục nguyên tác · trang 1](#M09-front-P003)
- [Mục lục nguyên tác · trang 2](#M09-front-P004)
- [Mục lục nguyên tác · trang 3](#M09-front-P005)
- [Mục lục nguyên tác · trang 4](#M09-front-P006)
- [Mục lục nguyên tác · trang 5](#M09-front-P007)
- [Mục lục nguyên tác · trang 6](#M09-front-P008)
- [Mục lục nguyên tác · trang 7](#M09-front-P009)
- [Mục lục nguyên tác · trang 8](#M09-front-P010)
- [Đề mục thiền minh sát và tuệ thẩm sát](#M09-body-P001)
- [Thẩm sát theo nhóm và minh sát theo phương pháp](#M09-body-P002)
- [Các phương pháp và đối tượng của tuệ minh sát](#M09-body-P003)
- [Các nhóm đối tượng của tuệ minh sát, tiếp theo](#M09-body-P004)
- [Các đối tượng còn lại và ba hạng chúng sinh](#M09-body-P005)
- [Căn cơ, sở thích và cách Đức Phật chỉ dạy](#M09-body-P006)
- [Phương pháp mười tám giới và bốn sự thật](#M09-body-P007)
- [Bốn pháp chân đế và các cách quán minh sát](#M09-body-P008)
- [Các cách phân nhóm cùng quy về những pháp chân đế](#M09-body-P009)
- [Bắt đầu với những pháp hiện rõ và dễ quán](#M09-body-P010)
- [Quán đầy đủ sau khi đã phân định năm phạm vi](#M09-body-P011)
- [Quy định cần theo khi quán minh sát](#M09-body-P012)
- [Minh sát đưa đến xuất khởi](#M09-body-P013)
- [Ý nghĩa của sự bắt đầu và các trường hợp xuất khởi](#M09-body-P014)
- [Xuất khởi từ sắc, danh và năm uẩn](#M09-body-P015)
- [Bắt đầu quán nội phần và ngoại phần](#M09-body-P016)
- [Bắt đầu từ sắc hoặc danh và xuất khởi](#M09-body-P017)
- [Chọn pháp hiện rõ để bắt đầu quán](#M09-body-P018)
- [Không bỏ sót sắc, danh, nội phần và ngoại phần](#M09-body-P019)
- [Những điều cần nhớ và ba đặc tính](#M09-body-P020)
- [Bắt đầu quán theo từng đặc tính và xuất khởi](#M09-body-P021)
- [Luân phiên quán ba đặc tính. Ánh sáng vô ngã](#M09-body-P022)
- [Phá khối sắc và danh để thấy vô ngã](#M09-body-P023)
- [Căn cứ của minh sát và hai phương pháp quán](#M09-body-P024)
- [Hai cách quán và các chi Duyên khởi](#M09-body-P025)
- [Quán nhân và quả cùng các nhóm pháp](#M09-body-P026)
- [Quán bất tịnh, quá khứ và vị lai](#M09-body-P027)
- [Tuệ minh sát và thắng trí](#M09-body-P028)
- [Đối tượng nhớ lại bằng tuệ minh sát](#M09-body-P029)
- [Phân biệt hai cách nhớ lại đời trước](#M09-body-P030)
- [Quán các uẩn quá khứ](#M09-body-P031)
- [Một chìa khóa quan trọng](#M09-body-P032)
- [Nhận diện cảnh cận tử](#M09-body-P033)
- [Nhận diện cảnh cận tử](#M09-body-P034)
- [Bắt đầu minh sát từ đối tượng dễ nhận diện](#M09-body-P035)
- [Quán ba đặc tướng của sắc](#M09-body-P036)
- [Sự biến mất của sắc và danh](#M09-body-P037)
- [Sự biến mất của sắc và danh](#M09-body-P038)
- [Cách quán minh sát danh pháp](#M09-body-P039)
- [Quán các lộ tâm qua sáu môn](#M09-body-P040)
- [Thứ tự quán của hành giả lấy thiền chỉ làm cỗ xe](#M09-body-P041)
- [Sự hỗ trợ giữa ba tuệ tùy quán](#M09-body-P042)
- [Tùy quán vô thường và tùy quán khổ](#M09-body-P043)
- [Hiện tại theo đời và phương pháp năm uẩn](#M09-body-P044)
- [Phương pháp năm uẩn](#M09-body-P045)
- [Quán từng uẩn từ cận hiện tại đến trọn một đời](#M09-body-P046)
- [Quán từng uẩn và quán chung sắc danh](#M09-body-P047)
- [Luân phiên quán sắc danh và mở rộng sang ba thời](#M09-body-P048)
- [Đối tượng của minh sát qua các đời](#M09-body-P049)
- [Trình tự quán các đời và các uẩn](#M09-body-P050)
- [Quán đủ mười một phương diện và Kinh Vô ngã tướng](#M09-body-P051)
- [Mười một phương diện của sắc trong Kinh Vô ngã tướng](#M09-body-P052)
- [Quán sắc không phải của ta, không phải là ta, không phải tự ngã của ta](#M09-body-P053)
- [Sắc và danh thô, tế, hạ liệt, thù thắng, xa và gần](#M09-body-P054)
- [Danh pháp tế và các phân loại hạ liệt, thù thắng, xa, gần](#M09-body-P055)
- [Quán gồm đủ các loại sắc danh](#M09-body-P056)
- [Tu tập bất tịnh và bất tịnh ở thân sống](#M09-body-P057)
- [Từ ba mươi hai phần thân đến các nhóm sắc](#M09-body-P058)
- [Căn nhà thân uẩn đầy các loài trùng](#M09-body-P059)
- [Tính bất tịnh của sắc chân đế](#M09-body-P060)
- [Bất tịnh ngoài thân và bất tịnh của tử thi](#M09-body-P061)
- [Bất tịnh ngoài thân và bất tịnh của tử thi](#M09-body-P062)
- [Cách quán](#M09-body-P063)
- [Cách quán](#M09-body-P064)
- [Cách quán](#M09-body-P065)
- [Một điểm đặc biệt và các chi duyên khởi](#M09-body-P066)
- [Các chi duyên khởi](#M09-body-P067)
- [Một số cách quán](#M09-body-P068)
- [Bốn mươi cách quán theo đuôi -to](#M09-body-P069)
- [1. Là vô thường](#M09-body-P070)
- [2–4. Là tan rã, dao động và dễ vỡ](#M09-body-P071)
- [4–6. Là dễ vỡ, không bền và có tính biến đổi](#M09-body-P072)
- [7–10. Là không có lõi, tiêu hoại, phải chết và hữu vi](#M09-body-P073)
- [10. Là hữu vi](#M09-body-P074)
- [Đặc tướng khổ: hai mươi lăm mục](#M09-body-P075)
- [Khổ và ba loại khổ](#M09-body-P076)
- [Quán là bệnh và là tai họa](#M09-body-P077)
- [Quán là ung nhọt](#M09-body-P078)
- [Quán là mũi tên và là chứng bệnh](#M09-body-P079)
- [Quán là tai ách và là mối nguy](#M09-body-P080)
- [Quán là hiểm họa, tai ương và không có sự che chở](#M09-body-P081)
- [Quán là không có nơi ẩn náu và không có chỗ quy y](#M09-body-P082)
- [Quán là kẻ sát nhân và là gốc tai họa](#M09-body-P083)
- [Quán là mối bất lợi](#M09-body-P084)
- [Quán là hữu lậu và là mồi của Māra](#M09-body-P085)
- [Năm loại Māra](#M09-body-P086)
- [Mồi của Māra, sinh, già, bệnh, sầu, bi và não](#M09-body-P087)
- [Sầu, bi, não và tính nhiễm ô](#M09-body-P088)
- [Năm phương diện của đặc tướng vô ngã](#M09-body-P089)
- [Quán là xa lạ và là trống không](#M09-body-P090)
- [Quán là trống không và là rỗng tuếch](#M09-body-P091)
- [Nguyên nhân của vô thường, khổ và vô ngã](#M09-body-P092)
- [Minh sát theo phương pháp gồm 200 cách](#M09-body-P093)
- [Sự tu tập tuệ có thể viên mãn](#M09-body-P094)
- [Phương pháp quán minh sát bảy cách về sắc](#M09-body-P095)
- [Chia tuổi thọ và ngày đêm thành các thời đoạn](#M09-body-P096)
- [Quán sắc theo động tác trong ngày](#M09-body-P097)
- [Quán sắc do vật thực và do thời tiết](#M09-body-P098)
- [Quán sắc do nghiệp và sắc do tâm sinh](#M09-body-P099)
- [Quán sắc theo quy ước và bảy cách quán danh](#M09-body-P100)
- [Quán theo nhóm](#M09-body-P101)
- [Tâm minh sát trước và tâm minh sát sau](#M09-body-P102)
- [Lộ đổng lực ý môn minh sát](#M09-body-P103)
- [Quán theo cặp](#M09-body-P104)
- [Quán theo từng bước và theo chuỗi tiếp nối](#M09-body-P105)
- [Quán tâm nối tiếp và từ bỏ tà kiến, ngã mạn](#M09-body-P106)
- [7. Làm cạn sự ưa thích](#M09-body-P107)
- [Ưu tiên một đặc tướng và đạt sự thuần thục](#M09-body-P108)
- [Kết thúc chương Trí thẩm sát](#M09-body-P109)
- [Chương Trí sinh diệt](#M09-body-P110)
- [Trí sinh diệt theo cách phân danh sắc và năm uẩn](#M09-body-P111)
- [Quán năm uẩn trong ba thời, nội và ngoại](#M09-body-P112)
- [Cách tu tập trí sinh diệt rộng](#M09-body-P113)
- [Quán sự sinh khởi của sắc uẩn](#M09-body-P114)
- [Sắc do thời tiết và vật thực sinh, thọ và tưởng lúc tái tục](#M09-body-P115)
- [Tưởng uẩn và hành uẩn lúc tái tục](#M09-body-P116)
- [Hành uẩn và thức uẩn lúc tái tục](#M09-body-P117)
- [2. Quán riêng sự hoại diệt](#M09-body-P118)
- [Diệt sau khi sinh và diệt do không sinh lại](#M09-body-P119)
- [Quán sự diệt do không sinh lại của sắc uẩn](#M09-body-P120)
- [Quán sự diệt của sắc](#M09-body-P121)
- [Cách quán thọ uẩn thuộc nhãn thức](#M09-body-P122)
- [Quán sinh diệt của sắc uẩn](#M09-body-P123)
- [Sinh diệt của sắc uẩn và thọ thuộc nhãn thức](#M09-body-P124)
- [Sinh diệt của thọ thuộc nhãn thức](#M09-body-P125)
- [Sinh diệt của thọ và lời giải thích](#M09-body-P126)
- [Nhân quả trong các đời quá khứ và vị lai](#M09-body-P127)
- [Các lộ ý môn và sự phân biệt hành với nghiệp](#M09-body-P128)
- [Hành, năng lực nghiệp và các nhóm cần quán](#M09-body-P129)
- [Duyên khởi, phương pháp thứ nhất](#M09-body-P130)
- [Công thức duyên khởi](#M09-body-P131)
- [Tùy quán tính sinh và tùy quán tính diệt](#M09-body-P132)
- [Tùy quán tính diệt và cả tính sinh lẫn tính diệt](#M09-body-P133)
- [Những lợi ích có thể đạt được](#M09-body-P134)
- [Bốn Thánh đế hiển lộ](#M09-body-P135)
- [Các sự thật hiển lộ khi quán sinh và diệt](#M09-body-P136)
- [Đạo đế hiệp thế và năm chi đạo hiệp thế](#M09-body-P137)
- [Năm chi đạo trong tuệ minh sát](#M09-body-P138)
- [Các pháp duyên khởi hiển lộ](#M09-body-P139)
- [Các pháp duyên sinh và bốn phương pháp](#M09-body-P140)
- [Dòng tâm tương tục](#M09-body-P141)
- [Phương pháp thấy sự tiếp nối và sai biệt](#M09-body-P142)
- [Phương pháp thấy nhân và quả không có chủ ý](#M09-body-P143)
- [Phương pháp thấy quy luật và năm đặc tướng](#M09-body-P144)
- [Đặc tướng vô ngã và đặc tướng vô thường](#M09-body-P145)
- [Đặc tướng khổ, đặc tướng riêng và đặc tướng hữu vi](#M09-body-P146)
- [Trình tự tu tập minh sát sinh diệt](#M09-body-P147)
- [Hiện tại theo dòng tương tục và hiện tại sát-na](#M09-body-P148)
- [Tuệ minh sát còn non và các tùy phiền não](#M09-body-P149)
- [Những người có hoặc không có tùy phiền não minh sát](#M09-body-P150)
- [1. Obhāsa — ánh sáng](#M09-body-P151)
- [Ánh sáng và thức nhận biết sắc](#M09-body-P152)
- [Ánh sáng do tâm và thời tiết sinh](#M09-body-P153)
- [Vì sao lại giải thích ánh sáng ở giai đoạn này?](#M09-body-P154)
- [Ánh sáng và sự đi chệch đường minh sát](#M09-body-P155)
- [Cách trở lại đường minh sát](#M09-body-P156)
- [2. Trí và 3. Hỷ](#M09-body-P157)
- [4. Passaddhi — an tịnh minh sát](#M09-body-P158)
- [5. Lạc, 6. Tín và 7. Tinh tấn](#M09-body-P159)
- [8. Niệm và 9. Xả](#M09-body-P160)
- [Xả minh sát và xả hướng tâm](#M09-body-P161)
- [Tám hiện tượng làm chỗ nương cho tùy phiền não](#M09-body-P162)
- [Cách vượt qua và 10. Nikanti — ưa thích minh sát](#M09-body-P163)
- [Nhận diện và quán sự ưa thích minh sát](#M09-body-P164)
- [Tri kiến thanh tịnh về đạo lộ](#M09-body-P165)
- [Bốn phép tùy quán và bốn niệm xứ](#M09-body-P166)
- [Quán thọ, tâm và pháp](#M09-body-P167)
- [Các cách phân loại trong pháp tùy quán](#M09-body-P168)
- [Quán các uẩn trong oai nghi và tỉnh giác](#M09-body-P169)
- [Kết thúc chương tuệ sinh diệt](#M09-body-P170)
- [Chương Tuệ hoại diệt](#M09-body-P171)
- [Chỉ lấy sự hoại diệt làm cảnh](#M09-body-P172)
- [Khi các nhóm sắc biến mất](#M09-body-P173)
- [Từ tướng của các hành đến tuệ hoại diệt](#M09-body-P174)
- [Vì sao sự sinh, trụ và tướng không còn hiện rõ](#M09-body-P175)
- [Thấy rõ các pháp chân đế đang hoại diệt](#M09-body-P176)
- [Minh sát trở lại chính tuệ đang quán](#M09-body-P177)
- [Mẫu quán cảnh và tuệ quán](#M09-body-P178)
- [Sức thấy sự hoại diệt](#M09-body-P179)
- [Có thể ưu tiên quán điều mình ưa thích](#M09-body-P180)
- [Quán sự tan rã và chuyển sang niệm hơi thở](#M09-body-P181)
- [Niệm hơi thở — Bộ bốn thứ nhất](#M09-body-P182)
- [Bộ bốn thứ nhất và chuẩn bị quán danh sắc](#M09-body-P183)
- [Niệm hơi thở — Bộ bốn thứ hai](#M09-body-P184)
- [Biết rõ hỷ trong thiền chỉ và minh sát](#M09-body-P185)
- [Biết rõ lạc và làm lắng dịu tâm hành](#M09-body-P186)
- [Niệm hơi thở — Bộ bốn thứ ba](#M09-body-P187)
- [Biết rõ tâm và làm tâm hân hoan](#M09-body-P188)
- [Định tâm trong thiền chỉ và minh sát](#M09-body-P189)
- [Định sát-na trong minh sát](#M09-body-P190)
- [Lưu ý về định sát-na và giải thoát tâm](#M09-body-P191)
- [Giải thoát tâm bằng các phép quán minh sát](#M09-body-P192)
- [Niệm hơi thở — Bộ bốn thứ tư](#M09-body-P193)
- [Quán vô thường, ly tham, diệt và xả ly](#M09-body-P194)
- [Phạm vi thực hành của bốn bộ bốn](#M09-body-P195)
- [Lợi ích của niệm hơi thở](#M09-body-P196)
- [Từ tuệ hiện khởi là đáng sợ đến tuệ hành xả](#M09-body-P197)
- [Tuệ quán nhàm chán, tuệ muốn thoát khỏi và tuệ quán xét lại](#M09-body-P198)
- [Tâm minh sát an trú trên sự hoại diệt](#M09-body-P199)
- [Con đường cần đi với niệm vững mạnh](#M09-body-P200)
- [Ưu tiên cảnh và đặc tướng thấy rõ](#M09-body-P201)
- [Quán danh pháp và thành tựu xả](#M09-body-P202)
- [Tuệ hành xả](#M09-body-P203)
- [Tiến đến Tri kiến thanh tịnh](#M09-body-P204)
- [Từ tuệ hành xả đến tuệ Thánh đạo](#M09-body-P205)
- [Làm chín muồi tuệ hành xả](#M09-body-P206)
- [Quán từng pháp và thấy thế gian là trống không](#M09-body-P207)
- [Người mà vua Chết không thể thấy](#M09-body-P208)
- [Năm phép phản khán và lời kết](#M09-body-P209)
- [Miến 210 — trang trắng](#M09-index-P001)
- [Chỉ mục theo thứ tự chữ cái](#M09-index-P002)
- [Chỉ mục theo thứ tự chữ cái](#M09-index-P003)
- [Chỉ mục theo thứ tự chữ cái](#M09-index-P004)
- [Chỉ mục theo thứ tự chữ cái](#M09-index-P005)
- [Chỉ mục theo vần Miến](#M09-index-P006)
- [Chỉ mục theo vần Miến](#M09-index-P007)
- [Chỉ mục theo vần Miến](#M09-index-P008)
- [Chỉ mục theo vần Miến](#M09-index-P009)
- [Chỉ mục theo vần Miến](#M09-index-P010)

<a id="M09-cover-P001"></a>
## Bìa trước và bìa sau
Bìa / Cover

Nibbānagāminipaṭipadā — Đường đến Niết-bàn (bản lược), Cuốn 9. Phần đề mục thiền minh sát (Vipassanākammaṭṭhāna). Thiền sư Pa-Auk Tawya Sayadaw.

Yo ca vassasataṃ jīve, apassaṃ udayabbayaṃ.
Ekāhaṃ jīvitaṃ seyyo, passato udayabbayaṃ.

Có người sống trọn một trăm năm mà không thấy biết bằng tuệ minh sát sự sinh diệt (udayabbaya) của các pháp danh sắc thuộc năm uẩn. So với người ấy sống suốt một trăm năm, sống chỉ một ngày, một hôm, một buổi sáng của người thật sự thấy biết bằng tuệ minh sát sự sinh diệt của các pháp danh sắc thuộc năm uẩn thì thù thắng, cao quý hơn. (Dhammapada, kệ 113.)

Yo ca vassasataṃ jīve, apassaṃ amataṃ padaṃ.
Ekāhaṃ jīvitaṃ seyyo, passato amataṃ padaṃ.

Có người sống trọn một trăm năm mà không thấy biết pháp Niết-bàn cao quý, bất tử. So với người ấy sống suốt một trăm năm, sống chỉ một ngày, một hôm, một buổi sáng của người thấy biết pháp Niết-bàn cao quý, bất tử thì thù thắng, cao quý hơn. (Dhammapada, kệ 114.)

Yo ca vassasataṃ jīve, apassaṃ dhammamuttamaṃ.
Ekāhaṃ jīvitaṃ seyyo, passato dhammamuttamaṃ.

Có người sống trọn một trăm năm mà không thấy biết pháp siêu thế cao quý. So với người ấy sống suốt một trăm năm, sống chỉ một ngày, một hôm, một buổi sáng của người thật sự thấy biết pháp siêu thế cao quý thì thù thắng, cao quý hơn. (Dhammapada, kệ 115.)


<a id="M09-front-P001"></a>
## Trang nhan đề
Đầu sách / Front matter - 1

Nibbānagāminipaṭipadā — Đường đến Niết-bàn (bản lược), Cuốn 9. Phần đề mục thiền minh sát (Vipassanākammaṭṭhāna). Thiền sư Pa-Auk Tawya Sayadaw.


<a id="M09-front-P002"></a>
## Pháp thí và lời nguyện
Đầu sách / Front matter - 2

Sabbadānaṃ dhammadānaṃ jināti,
Sabbarasaṃ dhammaraso jināti;
Sabbaratiṃ dhammarati jināti,
Taṇhakkhayo sabbadukkhaṃ jināti.

Pháp thí thắng mọi sự bố thí.
Vị Pháp thắng mọi hương vị.
Niềm vui trong Pháp thắng mọi niềm vui.
Sự đoạn tận ái thắng mọi khổ đau.

Ciraṃ tiṭṭhatu saddhammo, dhamme hontu sagāravā.

Nguyện lời giáo huấn và giáo pháp của Đức Phật trường tồn. Nguyện mọi người tôn kính ba phương diện của Chánh pháp.


<a id="M09-front-P003"></a>
## Mục lục nguyên tác · trang 1
Đầu sách / Front matter - 3

Namo tassa bhagavato arahato sammāsambuddhassa.

Phần đề mục thiền minh sát. Mục lục.

Phần tuệ quán theo nhóm (sammasanañāṇa) — 1

Quán theo nhóm (kalāpasammasana) — minh sát theo phương pháp suy rộng (nayavipassanā) — 2

Đối tượng được tuệ minh sát quán — 3

Để nâng đỡ ba loại chúng sinh — 5

Điều cần lưu ý — 8

Bắt đầu từ chỗ rõ ràng, dễ quán — 10

Những quy định cần tuân theo — 12

Minh sát dẫn đến xuất khởi (vuṭṭhānagāminīvipassanā) — 16

Điều cốt yếu cần ghi nhớ — 20

Ba đặc tướng — 20

Ánh sáng rực rỡ của vô ngã — 22

Quán theo nhóm và minh sát tuần tự từng pháp — 24

Các chi duyên khởi — 25

Tuệ minh sát và thắng trí — 28

Một điểm then chốt — 31

Hãy phân định rồi bắt đầu quán minh sát từ chỗ dễ quán — 35

Quan điểm về sự chấm dứt của sắc và danh — 37

Cách quán minh sát các danh pháp — 39

Trường hợp hành giả lấy thiền chỉ làm cỗ xe — 41

Hãy ưu tiên quán đặc tướng mình ưa thích — 41


<a id="M09-front-P004"></a>
## Mục lục nguyên tác · trang 2
Đầu sách / Front matter - 4

Hiện tại theo thời kỳ (addhāpaccuppanna) — 44

Phương pháp năm uẩn — 44

Hãy quán cả sắc và danh cùng nhau — 47

Quá khứ, hiện tại và vị lai — 48

Đối tượng quán trong Kinh Đặc Tướng Vô Ngã — 51

Thô và tế, hạ liệt và cao quý, xa và gần — 54

Tu tập quán bất tịnh — 57

Bất tịnh có thức — 57

Căn nhà năm uẩn đầy giòi bọ — 59

Tính bất tịnh của sắc chân đế — 60

Bất tịnh không có thức — tử thi bất tịnh — 61

Phương pháp và trình tự quán — 63

Một điểm đặc biệt — 66

Các chi duyên khởi — 66

Một số ví dụ về đối tượng quán — 68

Bốn mươi cách quán với hậu tố -to — 69

Mười phương diện của đặc tướng vô thường — 69

Aniccato — là vô thường — 69

Palokato — là tan rã — 71

Calato — là dao động — 71

Pabhaṅguto — là dễ tan vỡ — 71

Addhuvato — là không bền — 72

Vipariṇāmadhammato — là pháp phải biến đổi — 72

Asārakato — là không có lõi — 73

Vibhavato — là tiêu hoại — 73


<a id="M09-front-P005"></a>
## Mục lục nguyên tác · trang 3
Đầu sách / Front matter - 5

Maraṇadhammato — là pháp phải chết (maccu) — 73

Saṅkhatato — là hữu vi — 73

Hai mươi lăm phương diện của đặc tướng khổ — 75

Dukkhato — là khổ — 75

Rogato — như bệnh — 77

Aghato — như tai họa — 77

Gaṇḍato — như ung nhọt — 78

Sallato — như mũi tên — 79

Ābādhato — như bệnh hoạn — 79

Upaddavato — như hoạn nạn — 80

Bhayato — là đáng sợ — 80

Ītito — như tai ương — 81

Upasaggato — như hiểm họa — 81

Atāṇato — là không có chỗ che chở — 81

Aleṇato — là không có chỗ ẩn náu — 82

Asaraṇato — là không có chỗ nương tựa — 82

Vadhakato — như kẻ sát hại — 83

Aghamūlato — là gốc tai họa — 83

Ādīnavato — là nguy hại — 84

Sāsavato — là còn lậu hoặc — 85

Mārāmisato — là mồi của Māra — 85

Jātidhammato, jarādhammato, byādhidhammato — là pháp phải sinh, phải già, phải bệnh — 87

Sokadhammato, paridevadhammato, upāyāsadhammato — là pháp phải sầu, bi, não — 87

Saṅkilesikadhammato — là pháp dẫn đến ô nhiễm — 88

Năm phương diện của đặc tướng vô ngã — 89


<a id="M09-front-P006"></a>
## Mục lục nguyên tác · trang 4
Đầu sách / Front matter - 6

Suññato và anattato — là rỗng không và vô ngã — 89

Anattato — là vô ngã — 89

Suññato — là rỗng không — 89

Parato — là xa lạ — 90

Rittato — là trống rỗng — 90

Tucchato — là rỗng tuếch — 91

Nguyên do của vô thường, khổ và vô ngã — 92

Minh sát theo phương pháp suy rộng với hai trăm cách phân tích — 93

Có thể làm viên mãn sự tu tập tuệ — 94

Cách quán minh sát theo bảy phương diện về sắc (rūpasattaka) — 95

Cách quán sắc từ lúc thọ sinh đến lúc bỏ thân (ādānanikkhepa) — 95

Cách quán sắc theo các giai đoạn tuổi đời (vayovuḍḍhatthagama) — 95

Cách quán sắc do vật thực sinh — 98

Cách quán sắc do thời tiết sinh — 98

Cách quán sắc do nghiệp sinh — 99

Cách quán sắc do tâm sinh — 99

Cách quán sắc theo tính tự nhiên của pháp (dhammatā) — 100

Cách quán theo bảy phương diện về danh (arūpasattaka) — 100

Cách quán theo nhóm — quán chung các pháp đã gom lại — 101

Tâm minh sát trước và tâm minh sát sau — 102

Lộ tốc hành ý môn minh sát — 103

Yamaka — cách quán theo cặp — 104

Cách quán theo sát-na — 105

Cách quán theo trình tự — 105

Diṭṭhiugghāṭana — cách quán để nhổ bỏ kiến — 106


<a id="M09-front-P007"></a>
## Mục lục nguyên tác · trang 5
Đầu sách / Front matter - 7

Mānaugghāṭana — cách quán để nhổ bỏ mạn — 106

Nikantipariyādāna — cách quán để dứt sự ưa thích do ái, để nó không sinh khởi — 107

Đã là người thuần thục — 108

Phần tuệ sinh diệt (udayabbayañāṇa) — 111

Phương pháp hai nhóm sắc và danh cùng phương pháp năm uẩn — 111

Quá khứ, vị lai, hiện tại, nội phần và ngoại phần — 112

Cách quán rộng về tuệ sinh diệt — 113

Samudayadhammānupassī — udayadassana — cách quán riêng sự sinh — 113

Sắc uẩn — 114

Thọ uẩn lúc tái tục — 115

Tưởng uẩn lúc tái tục — 115

Hành uẩn lúc tái tục (= tư) — 116

Hành uẩn lúc tái tục (= 34 trừ thọ, tưởng và thức, còn 31) — 116

Thức uẩn lúc tái tục — 117

Vayadhammānupassī — vayadassana — cách quán riêng sự diệt — 118

Uppādanirodha — sự diệt của pháp đã sinh — 119

Anuppādanirodha — sự diệt do không còn sinh — 119

Cách quán sắc uẩn — 120

Cách quán nhãn thức và thọ uẩn — 122

Samudayavayadhammānupassī — udayavayadassana — cách quán sinh và diệt — 122

Thấy sự sinh và diệt của sắc uẩn — 123

Cách quán nhãn thức và thọ uẩn — 124

Những điểm giải thích — 126


<a id="M09-front-P008"></a>
## Mục lục nguyên tác · trang 6
Đầu sách / Front matter - 8

Hành và nghiệp hữu — 128

Hãy quán minh sát tất cả — 129

Phương pháp duyên khởi thứ nhất — 130

Samudayadhammānupassī — quán tính sinh khởi — 132

Vayadhammānupassī — quán tính hoại diệt — 132

Samudayavayadhammānupassī — quán tính sinh và diệt — 133

Những kết quả có thể đạt được — 134

Bốn Thánh đế hiện rõ thế nào — 135

Paccayato udayabbayadassana — thấy sinh diệt theo duyên — 135

Khaṇato udayadassana — thấy sự sinh theo sát-na — 136

Paccayato vayadassana — thấy sự diệt theo duyên — 136

Khaṇato vayadassana — thấy sự diệt theo sát-na — 136

Paccayato udayabbayadassana — thấy sinh diệt theo duyên — 136

Đạo đế hiệp thế — năm chi đạo hiệp thế — 137

Các pháp duyên khởi hiện rõ thế nào — 139

Paccayato udayadassana — thấy sự sinh theo duyên — 139

Paccayato vayadassana — thấy sự diệt theo duyên — 139

Khaṇato udayabbayadassana — thấy sinh diệt theo sát-na — 139

Bốn phương pháp hiện rõ thế nào — 140

Paccayato udayadassana — thấy sự sinh theo duyên — 140

Khaṇato udayadassana — thấy sự sinh theo sát-na — 142

Paccayato udayabbayadassana — thấy sinh diệt theo duyên — 143

Paccayato udayadassana — thấy sự sinh theo duyên — 144

Năm đặc tính hiện rõ thế nào — 144

Paccayato udayadassana — thấy sự sinh theo duyên — 144


<a id="M09-front-P009"></a>
## Mục lục nguyên tác · trang 7
Đầu sách / Front matter - 9

Khaṇato udayabbayadassana — thấy sinh diệt theo sát-na — 145

Trình tự thực hành minh sát về sinh diệt — 147

Phần các tùy phiền não minh sát (upakkilesa) — 149

Obhāsa — ánh sáng — 151

Vì sao phải giải thích lại? — 154

Cách trở lại con đường đúng — 156

Ñāṇa — tuệ minh sát — 157

Pīti — hỷ minh sát — 157

Passaddhi — an tịnh minh sát — 158

Sukha — lạc minh sát — 159

Adhimokkha — tín — 159

Paggaha — tinh tấn — 159

Upaṭṭhāna — niệm — 160

Upekkhā — xả minh sát và xả hướng tâm — 160

Cách tu tập để vượt qua — 163

Nikanti — sự ưa thích minh sát — 163

Phần thanh tịnh do tri kiến về đạo lộ hành trì — tuệ minh sát bậc cao — 165

Bốn phép tùy quán — cách đi vào bốn niệm xứ — 166

Đối tượng quán trong phần các oai nghi và tỉnh giác — 168

Phần tuệ hoại diệt (bhaṅgañāṇa) — 171

Tiến đến tuệ hoại diệt — 171

Điều cần lưu ý — 172

Các nhóm sắc đã biến mất — 173


<a id="M09-front-P010"></a>
## Mục lục nguyên tác · trang 8
Đầu sách / Front matter - 10

Lại quán minh sát chính tuệ đang quán minh sát — minh sát lại (paṭivipassanā) — 177

Một số ví dụ về đối tượng quán — 178

Năng lực thấy sự hoại diệt — 179

Có thể ưu tiên quán theo một trong hai cách mình ưa thích — 180

Niệm hơi thở — bộ bốn thứ nhất — 182

Niệm hơi thở — bộ bốn thứ hai — 184

Niệm hơi thở — bộ bốn thứ ba — 187

Một điểm cần đặc biệt lưu ý — 191

Niệm hơi thở — bộ bốn thứ tư — 193

Hãy hiểu những lợi ích và phẩm tính — 196

Từ tuệ kinh sợ đến tuệ hành xả — 197

Tuệ hiện khởi là đáng sợ (bhayatupaṭṭhānañāṇa) — 197

Tuệ quán nguy hại (ādīnavānupassanāñāṇa) — 197

Tuệ quán nhàm chán (nibbidānupassanāñāṇa) — 198

Tuệ muốn thoát khỏi (muñcitukamyatāñāṇa) — 198

Tuệ quán xét lại (paṭisaṅkhānupassanāñāṇa) — 198

Con đường phải đi với niệm vững chắc — 200

Tiến đến phần tri kiến thanh tịnh — 205

Từ tuệ hành xả đến tuệ Thánh đạo — 205

Hãy quán cho đến khi thấy tính rỗng không — 207

Người mà Tử thần không thể thấy — 208


<a id="M09-body-P001"></a>
## Đề mục thiền minh sát và tuệ thẩm sát
Miến / Burmese 1

Namo tassa bhagavato arahato sammāsambuddhassa.

Thanh tịnh do tri kiến về đạo và phi đạo (maggāmaggañāṇadassanavisuddhi)

Chương Tuệ thẩm sát (sammasanañāṇa)

Tuệ minh sát đã thoát khỏi các tùy phiền não minh sát và đang đi theo con đường đúng đắn, theo lối minh sát đã có từ xưa, là đạo dự bị đi trước Thánh đạo. Mười tùy phiền não minh sát, bắt đầu bằng ánh sáng, không phải là đạo dự bị đi trước Thánh đạo, không phải con đường minh sát đúng đắn. Như vậy, tuệ hiểu rõ và phân biệt chính xác cả đạo dự bị là con đường minh sát đúng đắn đi trước Thánh đạo, lẫn phi đạo, tức điều không phải con đường minh sát đúng đắn, được gọi là thanh tịnh do tri kiến về đạo và phi đạo. Vì tuệ ấy biết rõ “đây là con đường đúng, đây là con đường sai”, nên gọi là tuệ trong sạch khỏi các tùy phiền não minh sát. (ဝိသုဒ္ဓိ၊၂၊၂၄၁။)


<a id="M09-body-P002"></a>
## Thẩm sát theo nhóm và minh sát theo phương pháp
Miến / Burmese 2

Hành giả đã thành tựu sự thanh tịnh do tri kiến về đạo và phi đạo hãy bắt đầu nỗ lực thực hành minh sát theo phương pháp (nayavipassanā), còn gọi là thẩm sát theo nhóm (kalāpasammasana). (ဝိသုဒ္ဓိ၊၂၊၂၄၁။)

Thẩm sát theo nhóm (kalāpasammasana) — Gom các sắc pháp và danh pháp thành từng nhóm theo quá khứ, vị lai, hiện tại, bên trong, bên ngoài v.v., rồi lần lượt đặt lên chúng ba đặc tính và quán xét bằng minh sát. Phương pháp ấy gọi là thẩm sát theo nhóm. Tên gọi này là cách dùng của các vị trưởng lão ở đảo Jambudīpa.

Minh sát theo phương pháp (nayavipassanā) — Như chính Đức Phật đã thuyết giảng trong Kinh Vô ngã tướng và các bài pháp khác ở nhiều nơi, bắt đầu bằng “Yaṃ kiñci rūpaṃ atītānāgatapaccuppannaṃ”, các pháp được gọi là thủ uẩn hiện hữu theo mười một phương diện: quá khứ, vị lai, hiện tại, bên trong, bên ngoài, thô, tế, hạ liệt, thù thắng, xa và gần. Đó là —

1. Tập hợp sắc pháp, tức sắc uẩn.

2. Tập hợp thọ, tức thọ uẩn.

3. Tập hợp tưởng, tức tưởng uẩn.

4. Tập hợp hành, tức hành uẩn.

5. Tập hợp thức, tức thức uẩn.

1. Chia các pháp ấy thành năm nhóm theo từng tập hợp, lần lượt đặt lên chúng ba đặc tính và quán xét bằng minh sát, tức phương pháp…


<a id="M09-body-P003"></a>
## Các phương pháp và đối tượng của tuệ minh sát
Miến / Burmese 3

… năm uẩn.

2. Chia thành mười hai nhóm rồi quán xét bằng minh sát, tức phương pháp mười hai xứ.

3. Chia thành mười tám nhóm rồi quán xét bằng minh sát, tức phương pháp mười tám giới.

Những phương pháp quán minh sát như vậy gọi là minh sát theo phương pháp. Tên gọi “minh sát theo phương pháp” là cách dùng của các vị trưởng lão ở đảo Sīhaḷa. (မဟာဋီ၊၂၊၃၈၆။)

Đối tượng được quán của tuệ minh sát

1. Sáu loại pháp sinh ở các môn tương ứng cùng với môn và cảnh, tức pháp thuộc nhãn môn, nhĩ môn, tỷ môn, thiệt môn, thân môn và ý môn.

2. Năm uẩn, tức sắc uẩn, thọ uẩn, tưởng uẩn, hành uẩn và thức uẩn.

3. Sáu môn, tức nhãn môn, nhĩ môn, tỷ môn, thiệt môn, thân môn và ý môn.

4. Sáu cảnh, tức cảnh sắc, thinh, khí, vị, xúc và pháp.

5. Sáu thức, tức nhãn thức, nhĩ thức, tỷ thức, thiệt thức, thân thức và ý thức.

6. Sáu xúc, tức nhãn xúc, nhĩ xúc, tỷ xúc, thiệt xúc, thân xúc và ý xúc.

7. Thọ sinh do nhãn xúc, thọ sinh do nhĩ xúc, thọ sinh do tỷ xúc…


<a id="M09-body-P004"></a>
## Các nhóm đối tượng của tuệ minh sát, tiếp theo
Miến / Burmese 4

… thọ sinh do thiệt xúc, thọ sinh do thân xúc và thọ sinh do ý xúc. Đó là sáu thọ.

8. Sáu tưởng, tức sắc tưởng, thinh tưởng, khí tưởng, vị tưởng, xúc tưởng và pháp tưởng.

9. Sáu tư, tức tư đối với cảnh sắc, thinh, khí, vị, xúc và pháp.

10. Sáu ái, tức sắc ái, thinh ái, khí ái, vị ái, xúc ái và pháp ái.

11. Sáu tầm, tức tầm đối với cảnh sắc, thinh, khí, vị, xúc và pháp.

12. Sáu tứ, tức tứ đối với cảnh sắc, thinh, khí, vị, xúc và pháp.

13. Sáu giới, tức địa giới, thủy giới, hỏa giới, phong giới, hư không giới và thức giới.

14. Mười kasiṇa.

15. Ba mươi hai phần thân.

16. Mười hai xứ.

17. Mười tám giới.

18. Hai mươi hai quyền.

19. Ba giới, tức dục giới, sắc giới và vô sắc giới.

20. Chín hữu: dục hữu, sắc hữu, vô sắc hữu, hữu tưởng hữu, vô tưởng hữu, phi tưởng phi phi tưởng hữu, nhất uẩn hữu (chúng sinh vô tưởng), tứ uẩn hữu (bốn cõi vô sắc) và ngũ uẩn hữu (mười một cõi dục và mười lăm cõi sắc).

21. Bốn thiền sắc giới.


<a id="M09-body-P005"></a>
## Các đối tượng còn lại và ba hạng chúng sinh
Miến / Burmese 5

22. Bốn vô lượng, tức từ, bi, hỷ và xả.

23. Bốn thiền chứng vô sắc.

24. Mười hai chi duyên khởi.

Hãy ghi nhớ các tập hợp pháp này là những đối tượng được quán. (ဝိသုဒ္ဓိ၊၂၊၂၄၃-၂၄၄။)

Để nâng đỡ ba hạng chúng sinh

Những chúng sinh đáng được hướng dẫn và đang chờ đến lúc giải thoát có ba hạng. Vì muốn nâng đỡ cả ba hạng chúng sinh ấy, Đức Phật đã chỉ dạy các phương pháp quán minh sát khác nhau, bắt đầu bằng phương pháp năm uẩn.

Tu tập minh sát bằng phương pháp năm uẩn có thể đạt đến quả A-la-hán. Tu tập minh sát bằng phương pháp mười hai xứ cũng có thể đạt đến quả A-la-hán. Tu tập minh sát bằng phương pháp mười tám giới cũng có thể đạt đến quả A-la-hán. Nếu chỉ tu tập đề mục thiền minh sát bằng một phương pháp cũng có thể thành tựu kết quả mong muốn là quả A-la-hán, vì sao Đức Phật thuyết giảng nhiều phương pháp thay vì chỉ một phương pháp? Câu trả lời là Ngài thuyết giảng để nâng đỡ ba hạng chúng sinh.

1. Rūpasammūḷha — chúng sinh mê mờ về sắc pháp.

2. Arūpasammūḷha — chúng sinh mê mờ về danh pháp.

3. Ubhayasammūḷha — chúng sinh mê mờ về cả sắc lẫn danh.


<a id="M09-body-P006"></a>
## Căn cơ, sở thích và cách Đức Phật chỉ dạy
Miến / Burmese 6

1. Tikkhindriya — chúng sinh có các quyền sắc bén.

2. Majjhimindriya — chúng sinh có các quyền ở mức trung bình.

3. Mudindriya — chúng sinh có các quyền yếu.

1. Saṅkhittaruci — chúng sinh ưa phương pháp vắn tắt.

2. Majjhimaruci — chúng sinh ưa phương pháp vừa phải, không quá tóm lược cũng không quá rộng.

3. Vitthāraruci — chúng sinh ưa phương pháp trình bày rộng.

Như vậy, trong số những chúng sinh đáng được hướng dẫn đang chờ đến lúc giải thoát có ba hạng theo mỗi phương diện. Để nâng đỡ ba hạng ấy, Đức Phật đã trình bày giáo pháp bằng những phương pháp khác nhau.

1. (a) Người mê mờ về danh pháp, arūpasammūḷha.
(b) Người có các quyền sắc bén, tikkhindriya.
(c) Người ưa phương pháp vắn tắt, saṅkhittaruci.
Để nâng đỡ những người này, Ngài chỉ dạy cách quán minh sát theo phương pháp năm uẩn trong các bài pháp như Kinh Vô ngã tướng.

2. (a) Người mê mờ về sắc pháp, rūpasammūḷha.
(b) Người có các quyền trung bình, majjhimindriya.
(c) Người ưa cách thực hành vừa phải, không quá tóm lược cũng không quá rộng, majjhimaruci.
Để nâng đỡ những người này, Ngài thuyết giảng, chỉ dạy và khuyên bảo cách quán minh sát theo phương pháp mười hai xứ.


<a id="M09-body-P007"></a>
## Phương pháp mười tám giới và bốn sự thật
Miến / Burmese 7

3. (a) Người mê mờ về cả sắc lẫn danh, ubhayasammūḷha.
(b) Người có các quyền yếu, mudindriya.
(c) Người ưa phương pháp trình bày rộng, vitthāraruci.
Để nâng đỡ những người này, Ngài chỉ dạy cách quán minh sát theo phương pháp mười tám giới.

Để có thể phân định đặc tính vô ngã một cách thuận lợi và dễ dàng, Ngài cũng dạy cách quán minh sát theo phương pháp thuyết về các quyền.

1. Pavatti — sự sinh khởi của các pháp thuộc khổ đế, tức năm thủ uẩn.

2. Pavattihetu — các nhân của những pháp thuộc khổ đế ấy.

3. Nivatti — sự diệt của những pháp thuộc khổ đế và tập đế ấy.

4. Nivattihetu — sự thực hành làm nhân cho sự diệt của những pháp thuộc khổ đế và tập đế ấy.

Chỉ khi tự mình trực chứng bốn điều này bằng tuệ chánh kiến thì các cách quán minh sát nêu trên mới có thể đem lại lợi ích là đạo, quả và Niết-bàn. Để người nghe hiểu rằng nếu chưa tự mình trực chứng bốn điều ấy bằng tuệ chánh kiến thì chưa thể thành tựu kết quả là đạo, quả và Niết-bàn, Đức Phật cũng dạy và chỉ dẫn các cách quán minh sát liên quan đến phương pháp thuyết về các đế và phương pháp thuyết về duyên khởi. (မဟာဋီ၊၂၊၈၄-၈၅။)


<a id="M09-body-P008"></a>
## Bốn pháp chân đế và các cách quán minh sát
Miến / Burmese 8

Điều cần lưu ý

Có bốn pháp chân đế, tức tâm, tâm sở, sắc và Niết-bàn. Trong đó, tâm, tâm sở và sắc là những pháp chân đế vô thường, khổ và vô ngã. Pháp cao quý Niết-bàn là pháp chân đế thường, lạc và vô ngã.

Người thiện mong cầu pháp cao quý Niết-bàn, pháp chân đế thứ tư, vượt trội với những phẩm tính thường, lạc và vô ngã, phải phân định tâm, tâm sở và sắc là các pháp chân đế thứ nhất, thứ hai và thứ ba, cùng với các nhân của chúng. Rồi vị ấy phải đặt lên chúng ba đặc tính và chuyên cần quán minh sát.

Khi quán như vậy —

1. Chia tâm và tâm sở thành một nhóm danh, chia sắc pháp thành một nhóm sắc. Dù quán xét bằng minh sát theo phương pháp hai nhóm sắc và danh như vậy, vẫn có thể đạt đến đạo, quả và Niết-bàn.

2. Chia sắc pháp thành một nhóm, chia danh pháp thành bốn nhóm thọ, tưởng, hành và thức. Dù quán xét bằng minh sát theo phương pháp năm uẩn, vẫn có thể đạt đến đạo, quả và Niết-bàn.

3. Lại chia chính sắc và danh ấy thành mười hai nhóm. Dù quán xét bằng minh sát theo phương pháp mười hai xứ, vẫn có thể đạt đến đạo, quả và Niết-bàn.

4. Lại chia chính sắc và danh ấy thành mười tám nhóm. Dù quán xét bằng minh sát theo phương pháp mười tám giới, vẫn có thể đạt đến đạo, quả và Niết-bàn…


<a id="M09-body-P009"></a>
## Các cách phân nhóm cùng quy về những pháp chân đế
Miến / Burmese 9

… như vậy.

5. Lại chia chính sắc và danh ấy thành hai mươi hai nhóm theo phương pháp thuyết về các quyền. Dù quán xét các quyền hiệp thế bằng minh sát, vẫn có thể đạt đến đạo, quả và Niết-bàn.

6. Lại chia chính sắc và danh ấy theo mười hai chi. Dù quán xét bằng minh sát theo phương pháp thuyết duyên khởi, vẫn có thể đạt đến đạo, quả và Niết-bàn.

7. Lại theo phương pháp thuyết về các đế, chia thành hai nhóm, một nhóm khổ đế và một nhóm tập đế. Dù quán xét bằng minh sát theo cách ấy, vẫn có thể đạt đến đạo, quả và Niết-bàn.

Như vậy, sắc và danh, năm uẩn, mười hai xứ, mười tám giới, hai mươi hai quyền, mười hai chi duyên khởi, các pháp thuộc khổ đế và tập đế, được quán xét làm đối tượng của tuệ minh sát để đạt đến Niết-bàn, đều là tâm, tâm sở và sắc. Dù cách quán có khác, các pháp chân đế làm đối tượng của tuệ minh sát vẫn là những pháp ấy.

Vì vậy, hành giả muốn bắt đầu nỗ lực minh sát phải đã có cả hai tuệ phân định danh sắc (nāmarūpaparicchedañāṇa) và phân biệt duyên (paccayapariggahañāṇa) đối với đối tượng của tuệ minh sát —

1. Đã phân định sắc và danh.

2. Đã phân định các nhân.

Đối với các hành là danh sắc cùng nhân và quả đã được phân định như thế, nên bắt đầu quán xét bằng minh sát từ pháp nào…


<a id="M09-body-P010"></a>
## Bắt đầu với những pháp hiện rõ và dễ quán
Miến / Burmese 10

… đó là câu hỏi cần đặt ra. Câu trả lời như sau.

Yepi ca sammasanupagā, tesu ye yassa pākaṭā honti, sukhena pariggahaṃ gacchanti, tesu tena sammasanaṃ ārabhitabbaṃ. (ဝိသုဒ္ဓိ၊၂၊၂၄၄။)

Ye rūpārūpadhammā yassāti yogino, tesu tena sammasanaṃ ārabhitabbaṃ yathāpākaṭaṃ vipassanābhinivesoti katvā. Pacchā pana anupaṭṭhahantepi upāyena upaṭṭhāpetvā anavasesatova sammasitabbā. (မဟာဋီ၊၂၊၃၉၁။)

Trong các sắc pháp và danh pháp hiệp thế thích hợp để quán xét bằng minh sát dưới ba đặc tính, những sắc pháp và danh pháp nào hiện rõ trong trí của hành giả, có thể phân định và quán một cách thuận lợi, dễ dàng, không khó nhọc, thì vị ấy hãy nỗ lực thẩm sát, quán xét bằng minh sát các pháp ấy dưới ba đặc tính. (ဝိသုဒ္ဓိ၊၂၊၂၄၄။)

(a) Lời chỉ dạy rằng hành giả hãy nỗ lực thẩm sát, quán xét bằng minh sát dưới ba đặc tính các sắc pháp và danh pháp hiện rõ, có thể phân định và quán một cách thuận lợi, dễ dàng, không khó nhọc, được Chú giải sư nói với ý rằng minh sát có thể bắt đầu bằng tác ý đến những sắc pháp và danh pháp đang hiện rõ.

(b) Tuy vậy, về sau, những sắc pháp và danh pháp chưa hiện rõ trong trí…


<a id="M09-body-P011"></a>
## Quán đầy đủ sau khi đã phân định năm phạm vi
Miến / Burmese 11

… cũng phải dùng phương tiện thích hợp làm cho chúng hiện rõ trong trí. Rồi hãy quán xét bằng minh sát cho đầy đủ, không bỏ sót, bằng cách đặt ba đặc tính lên các sắc pháp, danh pháp, pháp nhân và pháp quả. (မဟာဋီ၊၂၊၃၉၁။)

Lời Chú giải sư nêu trên nói đến —

1. Rūpapariggaha — phân định sắc pháp.

2. Arūpapariggaha — phân định danh pháp.

3. Rūpārūpapariggaha — phân định sắc và danh.

4. Paccayapariggaha — phân định các nhân của sắc và danh hiện tại.

5. Addhānapariggaha — phân định các nhân của sắc và danh quá khứ và vị lai.

Cần lưu ý rằng lời ấy chỉ được nói cho hành giả đã thấu suốt năm sự phân định này đến tận cùng.

1. Chưa biết sắc pháp đến mức thấy chân đế.

2. Chưa biết danh pháp đến mức thấy chân đế.

3. Chưa biết sắc và danh đến mức thấy chân đế.

4. Chưa biết các nhân của sắc và danh hiện tại.

5. Chưa biết các nhân của sắc và danh quá khứ và vị lai.

Đối với hành giả mới đến thiền viện để ngồi thiền, vẫn mang theo cả khối không biết như vậy, lời ấy không phải chỉ dạy rằng cứ quán những gì hiện rõ, dễ quán theo ý mình mà chưa phân biệt chế định với chân đế…


<a id="M09-body-P012"></a>
## Quy định cần theo khi quán minh sát
Miến / Burmese 12

… Cần lưu ý rằng đó không phải là lời dạy bảo cứ quán theo ý mình khi chưa phân biệt chế định và chân đế.

Tuy nhiên, có người chỉ căn cứ lời Chú giải sư nêu trên và mục (a) của lời Sớ giải sư, rồi chỉ dạy rằng minh sát chỉ cần quán những gì hiện rõ. Họ không xét đến mục (b) của lời Sớ giải sư. Nhưng chính vị thầy Mahāṭīkā, tại မဟာဋီ၊၂၊၃၅၈, đã dẫn Kinh Aparijānana trong Tương ưng Sáu xứ thuộc Tương ưng bộ (သံ၊၂၊၂၄၉-၂၅၀) và xác định rằng phải quán tất cả sắc pháp và danh pháp để biết phân biệt bằng ba loại liễu tri (pariññā). Phải quán minh sát đầy đủ không sót. Hãy đọc lời xác định của Chú giải dưới đây.

Theo các bài pháp Đức Phật thuyết ở nhiều nơi như Kinh Vô ngã tướng, và theo lời chỉ dạy của các Chú giải và Sớ giải nêu trên, cần quán minh sát tất cả các hành là sắc, danh, nhân và quả thuộc quá khứ, vị lai, hiện tại, bên trong và bên ngoài. Vậy phải quán minh sát theo phương pháp nào và theo quy định nào? Chú giải Aṭṭhasālinī, trang 270–271, và Thanh tịnh đạo, quyển hai, trang 300–301, trong phần liệt kê các loại minh sát đưa đến xuất khởi (vuṭṭhānagāminī vipassanā), giải thích các quy định phải tuân theo trong minh sát. Sau đây trình bày tiếp lời giải thích của Chú giải Aṭṭhasālinī.


<a id="M09-body-P013"></a>
## Minh sát đưa đến xuất khởi
Miến / Burmese 13

Idhekacco āditova ajjhattaṃ pañcasu khandhesu abhinivisati. Abhinivisitvā te aniccādito passati. Yasmā pana na suddhaajjhattadassanamatteneva maggavuṭṭhānaṃ hoti, bahiddhāpi daṭṭhabbameva. Tasmā parassa khandhepi anupādinnasaṅkhārepi “aniccaṃ dukkhamanattā”ti passati. So kālena ajjhattaṃ sammasati, kālena bahiddhāti. Tassevaṃ sammasato ajjhattaṃ sammasanakāle vipassanā maggena saddhiṃ ghaṭiyati. Evaṃ ajjhattaṃ abhinivisitvā ajjhattaṃ vuṭṭhāti nāma. Sace panassa bahiddhā sammasanakāle vipassanā maggena saddhiṃ ghaṭiyati, evaṃ ajjhattaṃ abhinivisitvā bahiddhā vuṭṭhāti nāma. Esa nayo bahiddhā abhinivisitvā bahiddhā ca ajjhattañca vuṭṭhānepi.

Một người ở đây bắt đầu với năm uẩn bên trong. Sau khi bắt đầu, vị ấy thấy chúng là vô thường v.v. Vì đạo xuất khởi không xảy ra chỉ do thấy riêng bên trong nên cũng phải thấy bên ngoài. Do đó, vị ấy thấy cả các uẩn của người khác lẫn các hành không do nghiệp chấp thủ là vô thường, khổ, vô ngã. Khi thì vị ấy thẩm sát bên trong, khi thì bên ngoài. Trong khi thẩm sát như vậy, nếu minh sát nối với đạo lúc đang thẩm sát bên trong, đó gọi là bắt đầu từ bên trong và xuất khởi từ bên trong. Nếu minh sát nối với đạo lúc đang thẩm sát bên ngoài, đó gọi là bắt đầu từ bên trong và xuất khởi từ bên ngoài. Cũng theo cách ấy, có trường hợp bắt đầu từ bên ngoài rồi xuất khởi từ bên ngoài hoặc từ bên trong.

Aparo āditova rūpe abhinivisati. Abhinivisitvā bhūtarūpañca upādārūpañca paricchinditvā aniccādito passati. Yasmā pana na suddharūpadassanamatteneva vuṭṭhānaṃ hoti, arūpampi daṭṭhabbameva. Tasmā taṃ rūpaṃ ārammaṇaṃ katvā uppannaṃ vedanaṃ saññaṃ saṅkhāre viññāṇañca “idaṃ arūpan”ti paricchinditvā aniccādito passati. So kālena rūpaṃ sammasati, kālena arūpaṃ. Tassevaṃ sammasato rūpasammasanakāle vipassanā maggena saddhiṃ ghaṭiyati. Evaṃ rūpe abhinivisitvā rūpā vuṭṭhāti nāma. Sace panassa arūpasammasanakāle vipassanā maggena saddhiṃ ghaṭiyati, evaṃ rūpe abhinivisitvā arūpā vuṭṭhāti nāma. Esa nayo arūpe abhinivisitvā arūpā ca rūpā ca vuṭṭhānepi.

Người khác bắt đầu với sắc. Sau khi bắt đầu, vị ấy phân định sắc đại chủng và sắc y sinh rồi thấy chúng là vô thường v.v. Vì xuất khởi không xảy ra chỉ do thấy riêng sắc, nên cũng phải thấy danh. Do đó, vị ấy phân định thọ, tưởng, hành và thức sinh khởi khi lấy sắc ấy làm cảnh, biết “đây là danh”, rồi thấy chúng là vô thường v.v. Khi thì vị ấy thẩm sát sắc, khi thì thẩm sát danh. Trong khi thẩm sát như vậy, nếu minh sát nối với đạo lúc đang thẩm sát sắc, đó gọi là bắt đầu từ sắc và xuất khởi từ sắc. Nếu minh sát nối với đạo lúc đang thẩm sát danh, đó gọi là bắt đầu từ sắc và xuất khởi từ danh. Cũng theo cách ấy, có trường hợp bắt đầu từ danh rồi xuất khởi từ danh hoặc từ sắc.

“Yaṃ kiñci samudayadhammaṃ sabbaṃ taṃ nirodhadhamman”ti evaṃ abhinivisitvā evameva vuṭṭhānakāle pana ekappahārena pañcahi khandhehi vuṭṭhāti nāmāti ayaṃ tikkhavipassakassa mahāpaññassa bhikkhuno vipassanā. (အဘိ၊ဋ္ဌ၊၁၊၂၇၀-၂၇၁။)

“Bất cứ pháp nào có bản chất sinh khởi, tất cả pháp ấy đều có bản chất diệt.” Bắt đầu như vậy, khi xuất khởi, vị ấy xuất khởi khỏi cả năm uẩn trong một lần. Đây là minh sát của vị Tỳ-khưu có đại tuệ, có minh sát sắc bén. (အဘိ၊ဋ္ဌ၊၁၊၂၇၀-၂၇၁။)


<a id="M09-body-P014"></a>
## Ý nghĩa của sự bắt đầu và các trường hợp xuất khởi
Miến / Burmese 14

Abhinivesoti ca vipassanāya pubbabhāge kattabbanāmarūpaparicchedo veditabbo. Tasmā paṭhamaṃ rūpapariggahaṇaṃ rūpe abhiniveso. Esa nayo sesesupi. (မဟာဋီ၊၂၊၄၇၀။)

Abhinivesa chỉ tuệ phân định danh sắc (nāmarūpaparicchedañāṇa), tức sự phân biệt danh sắc bằng trí cần thực hiện ở giai đoạn trước minh sát. Do đó, trước hết phân biệt và phân định sắc pháp bằng trí gọi là rūpe abhinivesa, tức bắt đầu tác ý minh sát với sắc pháp. Những trường hợp bắt đầu còn lại cũng theo cách ấy. (မဟာဋီ၊၂၊၄၇၀။) Việc phân biệt bằng trí các hành thuộc khổ đế và tập đế, vốn là đối tượng của tuệ minh sát, được gọi là abhinivesa.

Đối với Thánh đạo siêu thế —

1. Có trường hợp bắt đầu tác ý minh sát với các hành bên trong rồi xuất khởi từ các hành bên trong.

2. Có trường hợp bắt đầu tác ý minh sát với bên trong rồi xuất khởi từ các hành bên ngoài.

3. Có trường hợp bắt đầu tác ý minh sát với bên ngoài rồi xuất khởi từ bên ngoài.

4. Có trường hợp bắt đầu tác ý minh sát với bên ngoài rồi xuất khởi từ bên trong.

5. Có trường hợp bắt đầu tác ý minh sát với sắc pháp rồi xuất khởi từ sắc pháp.


<a id="M09-body-P015"></a>
## Xuất khởi từ sắc, danh và năm uẩn
Miến / Burmese 15

6. Có trường hợp bắt đầu tác ý minh sát với sắc pháp rồi xuất khởi từ danh pháp.

7. Có trường hợp bắt đầu tác ý minh sát với danh pháp rồi xuất khởi từ danh pháp.

8. Có trường hợp bắt đầu tác ý minh sát với danh pháp rồi xuất khởi từ sắc pháp.

9. Có trường hợp xuất khởi khỏi cả năm uẩn trong cùng một lần. (အဘိ၊ဋ္ဌ၊၁၊၂၇၀။)

1. Trong Giáo pháp này, có hành giả ngay từ đầu nỗ lực tác ý và quán năm uẩn bên trong. Sau khi tác ý và quán như vậy, vị ấy lần lượt đặt ba đặc tính vô thường, khổ, vô ngã lên năm uẩn bên trong ấy, rồi quán xét bằng minh sát. Chỉ quán minh sát riêng năm uẩn bên trong thì minh sát đưa đến xuất khởi (vuṭṭhānagāminī vipassanā) không thể sinh. Đó là minh sát đi cùng dòng tâm lộ đạo, chuyển ngay một lần từ cảnh các hành sang Niết-bàn. Do đó cũng phải quán minh sát năm uẩn bên ngoài. Vì vậy, hãy quán năm uẩn của người khác cũng như các hành không do nghiệp chấp thủ thuộc vật vô tri, lần lượt đặt lên chúng ba đặc tính vô thường, khổ, vô ngã, để thấy rõ bằng tuệ minh sát. Hành giả ấy có khi quán xét bên trong bằng minh sát, lần lượt đặt lên đó ba đặc tính. Có khi vị ấy quán xét bên ngoài bằng minh sát, lần lượt đặt lên đó ba đặc tính. Khi vị hành giả ấy quán xét như vậy, tuệ minh sát có thể nối với tuệ Thánh đạo trong lúc quán xét bên trong bằng minh sát. (Khi tuệ minh sát kết thúc, tuệ Thánh đạo…


<a id="M09-body-P016"></a>
## Bắt đầu quán nội phần và ngoại phần
Miến / Burmese 16

… sinh khởi, nghĩa là như vậy.) Trường hợp này gọi là bắt đầu tác ý đến nội phần rồi xuất khởi từ nội phần. (Nghĩa là minh sát đưa đến xuất khởi sinh khởi.)

[Minh sát đưa đến xuất khởi (vuṭṭhānagāminivipassanā) — Dòng tâm minh sát thoát khỏi cảnh các hành và tiến thẳng một mạch đến Niết-bàn, nơi thoát khỏi các hành. Đây là tên chung của ba tuệ, tức hành xả tuệ, thuận thứ tuệ và chuyển tánh tuệ, vốn được gọi là minh sát đạt đến đỉnh (sikhāppattavipassanā), đã đạt tới chóp đỉnh của sự tiến thẳng một mạch ấy, thoát khỏi cảnh các hành và hướng đến Niết-bàn, nơi thoát khỏi các hành.] (Visuddhi II, 299. Mahāṭī II, 469.)

2. Trường hợp khác — Hành giả bắt đầu nỗ lực từ nội phần, quán minh sát luân phiên nội phần rồi ngoại phần. Nếu tuệ minh sát nối liền với Thánh đạo tuệ trong khi đang quán ngoại phần, trường hợp này gọi là bắt đầu tác ý đến nội phần rồi xuất khởi từ ngoại phần.

3–4. Trường hợp bắt đầu tác ý đến ngoại phần rồi xuất khởi từ ngoại phần hoặc từ nội phần cũng theo cùng cách ấy.

5. (Vì nội phần có hai loại là sắc và danh, và ngoại phần cũng có hai loại là sắc và danh.) Một hành giả khác ngay từ khi mới nỗ lực tu tập, trong hai đề mục là đề mục thiền sắc và đề mục thiền danh, bắt đầu tác ý đến sắc pháp. (Nghĩa là bắt đầu nhận diện từ sắc pháp.) Sau khi tác ý như vậy, vị ấy dùng trí phân biệt để biết rõ riêng từng loại sắc đại chủng, tức bốn đại, và từng loại trong 24 sắc y sinh, rồi quán cho thấy bằng tuệ minh sát, luân phiên áp dụng ba đặc tính…


<a id="M09-body-P017"></a>
## Bắt đầu từ sắc hoặc danh và xuất khởi
Miến / Burmese 17

… Nhưng chỉ quán minh sát riêng sắc pháp thì minh sát đưa đến xuất khởi không thể sinh khởi. Do đó, cũng phải quán minh sát danh pháp, luân phiên áp dụng ba đặc tính. Vì vậy, hãy dùng trí phân biệt rõ thọ, tưởng, nhóm tâm sở thuộc hành uẩn và thức sinh khởi lấy sắc pháp ấy làm cảnh, biết rằng “đây là danh pháp”, rồi quán để thấy bằng tuệ minh sát, luân phiên áp dụng ba đặc tính là vô thường, khổ và vô ngã. Hành giả ấy khi thì quán minh sát sắc pháp, luân phiên áp dụng ba đặc tính, khi thì quán minh sát danh pháp, luân phiên áp dụng ba đặc tính. Khi hành giả quán như vậy, nếu tuệ minh sát nối liền với Thánh đạo tuệ ngay trong lúc đang quán sắc pháp, trường hợp ấy gọi là bắt đầu tác ý và quán từ sắc pháp, rồi xuất khởi từ sắc pháp.

6. Nếu tuệ minh sát của hành giả ấy nối liền với Thánh đạo tuệ trong lúc đang quán danh pháp, trường hợp này gọi là bắt đầu tác ý đến sắc pháp rồi xuất khởi từ danh pháp.

7–8. Hãy hiểu cùng phương pháp ấy đối với trường hợp bắt đầu tác ý đến danh pháp rồi xuất khởi từ danh pháp hoặc từ sắc pháp.

9. “Yaṃ kiñci samudayadhammaṃ, sabbaṃ taṃ nirodhadhammaṃ” — “Bất cứ pháp nào có tính sinh khởi, tất cả pháp ấy đều có tính diệt.” Hãy biết rằng khi tác ý như vậy và minh sát đưa đến xuất khởi sinh khởi, vị ấy xuất khởi từ cả năm uẩn cùng một lúc. Minh sát này là minh sát sắc bén, là minh sát của vị tỳ-khưu có tuệ lớn…


<a id="M09-body-P018"></a>
## Chọn pháp hiện rõ để bắt đầu quán
Miến / Burmese 18

… vị tỳ-khưu đại tuệ có minh sát sắc bén. (Abhi-a I, 270–271.)

Một phán quyết cùng mẫu mực và cùng ý nghĩa với phán quyết trong Chú giải Aṭṭhasālinī vừa dẫn cũng có ở trang 300, tập II của Thanh tịnh đạo, và trong phần giải kinh Kaḷāra thuộc Chú giải Tương ưng, Thiên Nhân duyên. (Saṃ-a II, 59.) Tuy câu chữ hơi khác nhau, ý nghĩa hoàn toàn giống nhau. Vị luận sư Thanh tịnh đạo đã viết phán quyết tường tận như vậy, như đã trình bày ở trên. Trong chương tư duy tuệ (sammasanañāṇa), có người hiểu rằng chỉ cần quán những gì hiện rõ mà không phân biệt chế định với chân đế, không tách chế định với chân đế, dựa vào lời sau đây —

Yepi ca sammasanupagā, tesu ye yassa pākaṭā honti, sukhena pariggahaṃ gacchanti, tesu tena sammasanaṃ ārabhitabbaṃ. (Visuddhi II, 244.)

Nghĩa là, trong các sắc pháp và danh pháp hiệp thế thích hợp để quán minh sát bằng cách áp dụng ba đặc tính, những sắc pháp và danh pháp nào hiện rõ trong trí của hành giả ấy và có thể được nhận diện dễ dàng, thuận lợi, không nhọc công, thì hành giả ấy hãy bắt đầu nỗ lực quán các sắc pháp và danh pháp ấy, thực hành tư duy bằng cách luân phiên áp dụng ba đặc tính. (Visuddhi II, 244.)

Người thiện đang học nên tự suy xét và thẩm định lời ấy được trình bày với ý nghĩa nào. Thật ra, vị luận sư đang nói cho người đã thông suốt và thành thạo cả năm loại nhận diện (pariggaha) rồi mới chuyển sang phần minh sát, tức chương tư duy tuệ…


<a id="M09-body-P019"></a>
## Không bỏ sót sắc, danh, nội phần và ngoại phần
Miến / Burmese 19

… Vị luận sư chỉ dạy người mới bắt đầu nỗ lực minh sát nên bắt đầu từ những sắc pháp và danh pháp dễ nhận diện. Theo lời giải thích của Đại sớ, sau khi đã quán minh sát các sắc pháp và danh pháp dễ nhận diện bằng pháp hành tư duy, cũng phải dùng phương tiện thích hợp làm cho sắc và danh chưa dễ hiện ra trong trí trở nên rõ ràng, rồi áp dụng ba đặc tính mà quán minh sát. Lý do là —

1. Chỉ quán minh sát riêng sắc pháp, tức sắc đại chủng và sắc y sinh, thì không thể đạt Thánh đạo.
2. Chỉ quán minh sát riêng danh pháp, tức bốn danh uẩn, thì không thể đạt Thánh đạo.
3. Chỉ quán minh sát riêng năm uẩn nội phần thì không thể đạt Thánh đạo.
4. Chỉ quán minh sát riêng năm uẩn ngoại phần thì không thể đạt Thánh đạo.

Chính vì các lý do ấy mà vị luận sư tự nêu và giải thích đến đủ 24 nhóm pháp làm cảnh cho tuệ minh sát, cần quán bằng tư duy tuệ, như đã trình bày ở trang 3–4 của sách này. Trong số rất nhiều pháp như vậy, nếu hỏi nên bắt đầu công việc minh sát từ pháp nào, lời chỉ dạy chỉ nói rằng hãy bắt đầu quán minh sát từ pháp dễ nhận diện. Nhưng theo lời giải thích của Đại sớ, về sau…


<a id="M09-body-P020"></a>
## Những điều cần nhớ và ba đặc tính
Miến / Burmese 20

… hãy ghi nhớ rằng phải tiếp tục quán minh sát cho đến khi bao quát hết các pháp chân đế còn lại.

Những điều chính cần ghi nhớ

Khi quán minh sát —
1. Khi thì nội phần, tức năm uẩn nội phần.
2. Khi thì ngoại phần, tức năm uẩn ngoại phần của chúng sinh sống, cùng các sắc pháp không do nghiệp chấp thủ thuộc vật vô tri.
3. Khi thì sắc pháp, tức sắc đại chủng và sắc y sinh.
4. Khi thì danh pháp, tức bốn danh uẩn.
5. Khi thì đặc tính vô thường.
6. Khi thì đặc tính khổ.
7. Khi thì đặc tính vô ngã.

Phải luân phiên áp dụng các phương diện ấy mà quán minh sát. Hãy ghi nhớ rằng cách tu tập này có phương pháp nhất định, phải phân biệt rõ chế định với chân đế và quán theo đúng đối tượng. Không lấy chế định làm đối tượng để quán minh sát. Chỉ lấy chân đế làm đối tượng thích hợp cho minh sát.

Ba đặc tính

Eko āditova aniccato saṅkhāre sammasati. Yasmā pana na aniccato sammasanamatteneva vuṭṭhānaṃ hoti, dukkhato pi anattato pi sammasitabbam eva. Tasmā dukkhato pi anattato pi sammasati. Tassevaṃ paṭipannassa aniccato sammasanakāle vuṭṭhānaṃ hoti. Ayaṃ aniccato abhinivisitvā aniccato vuṭṭhāti nāma.

Sace panassa dukkhato anattato sammasanakāle vuṭṭhānaṃ hoti, ayaṃ aniccato abhinivisitvā dukkhato anattato…


<a id="M09-body-P021"></a>
## Bắt đầu quán theo từng đặc tính và xuất khởi
Miến / Burmese 21

… vuṭṭhāti nāma. Esa nayo dukkhato anattato abhinivisitvā sesavuṭṭhānesupi. (Visuddhi II, 301.)

1. Khi mới bắt đầu tu tập minh sát, một hành giả quán các hành là vô thường, nhìn để dùng trí thấy rõ bản tính sinh rồi diệt. Tuy nhiên, chỉ quán là vô thường thì minh sát đưa đến xuất khởi không thể sinh. Cũng phải quán là khổ, nhìn để dùng trí thấy rõ sự bức bách, áp bức không ngừng do sinh và diệt, và quán là vô ngã, nhìn để dùng trí thấy rõ rằng không có tự ngã chắc thật và cốt lõi nào đứng vững, kiên cố, không bị hủy hoại. Vì vậy, vị ấy cũng quán là khổ và là vô ngã. Trong dòng tương tục của hành giả đang thực hành và quán như vậy, nếu minh sát đưa đến xuất khởi sinh khi đang quán các hành là vô thường, thì gọi là bắt đầu tác ý đến vô thường và xuất khởi từ các hành theo phương diện vô thường.

2–3. Nếu minh sát đưa đến xuất khởi sinh trong dòng tương tục của vị ấy khi quán là khổ hoặc vô ngã, thì gọi là bắt đầu tác ý đến vô thường rồi xuất khởi từ các hành theo phương diện khổ hoặc vô ngã.

Hãy hiểu theo cùng cách ấy đối với các trường hợp xuất khởi còn lại, khi bắt đầu tác ý đến các hành là khổ hoặc là vô ngã. (Visuddhi II, 301.)


<a id="M09-body-P022"></a>
## Luân phiên quán ba đặc tính. Ánh sáng vô ngã
Miến / Burmese 22

Theo phán quyết trong Chú giải vừa nêu, hãy ghi nhớ rằng hành giả phải luân phiên quán các hành bằng minh sát —
1. Khi thì là vô thường.
2. Khi thì là khổ.
3. Khi thì là vô ngã.

Ánh sáng vô ngã

Đặc tính vô thường và đặc tính khổ đều hiển hiện trong thế gian, dù chư Phật xuất hiện hay không xuất hiện. Đặc tính vô ngã không thể hiển hiện trong thế gian nếu chư Phật không xuất hiện. Chỉ trong thời kỳ chư Phật xuất hiện, đặc tính vô ngã ấy mới hiển hiện. Ngay cả những bậc thiện trí có thần lực và uy lực lớn, những vị Bồ-tát đã thành tựu địa vị đạo sĩ như đạo sĩ Sarabhaṅga, cũng chỉ có thể giảng các hành bằng cách nêu chúng là vô thường và khổ. Các ngài không thể nêu chúng là vô ngã mà giảng giải. Nếu các bậc thiện trí ấy có thể nêu các hành là vô ngã và giảng giải cho hội chúng đến trước mặt mình, thì hội chúng ấy hẳn đã có thể thấu suốt và biết Thánh đạo tuệ và Thánh quả tuệ. Thật vậy, khả năng nêu và giảng đặc tính vô ngã không thuộc phạm vi của bất cứ cá nhân hay chúng sinh nào khác, mà chỉ thuộc phạm vi của các Đức Phật Chánh Đẳng Giác, bậc Nhất thiết trí…


<a id="M09-body-P023"></a>
## Phá khối sắc và danh để thấy vô ngã
Miến / Burmese 23

… Vì vậy, đặc tính vô ngã là đặc tính khó hiện rõ. Do đó, khi Đức Phật thuyết giảng đặc tính vô ngã, Ngài giảng kèm với —
1. Đặc tính vô thường.
2. Đặc tính khổ.
3. Hoặc cả hai đặc tính vô thường và khổ. (Abhi-a II, 46–47.)

Nānādhātuyo vinibbhujjitvā ghanavinibbhoge kate anattalakkhaṇaṃ yāthāvasarasato upaṭṭhāti. (Abhi-a II, 47.)

Khi dùng trí phân tách, phá vỡ từng sắc giới và danh giới khác nhau, từng pháp một, cho đến chân đế, và có thể phá vỡ các khối sắc và khối danh (rūpaghana, nāmaghana), thì đặc tính vô ngã, ánh sáng vô ngã, hiện rõ trong trí hành giả theo đúng bản tính riêng của nó. (Abhi-a II, 47.)

Chỉ khi có thể dùng trí phân tích các khối sắc và danh, nhất là các nhóm sắc và nhóm danh, rồi nhận diện từng pháp chân đế bằng tuệ minh sát theo đặc tính, phận sự, biểu hiện và nhân gần, có thể dùng trí phân biệt, quán và thấy chúng, thì các khối sắc và khối danh mới được phá vỡ. Chỉ khi các khối được phá vỡ, trí mới đạt đến chân đế. Chỉ khi trí đạt đến chân đế, ánh sáng vô ngã mới hiển hiện rạng rỡ. Chỉ khi ba đặc tính vô thường, khổ và vô ngã…


<a id="M09-body-P024"></a>
## Căn cứ của minh sát và hai phương pháp quán
Miến / Burmese 24

… được quán bằng tuệ minh sát cho hiện rõ trong trí và được thấy trực tiếp, mới có thể đạt Thánh đạo. Vì vậy, hãy xét những lời quả quyết sau —

1. Không cần quán cho thấy các nhóm sắc và nhóm danh.
2. Các vị đệ tử không thể quán các nhóm sắc và nhóm danh.
3. Các vị đệ tử không thể phân tích các nhóm sắc và nhóm danh thành các giới.
4. Các vị đệ tử không thể quán sắc chân đế và danh chân đế mà Đức Phật đã giảng.
5. Chỉ các Đức Phật Chánh Đẳng Giác, bậc Nhất thiết trí, mới có thể biết các sắc pháp và danh pháp mà Đức Phật đã giảng. Đó chỉ là phạm vi của chư Phật.
6. Chỉ các vị A-la-hán mới có thể biết sắc và danh ấy.

Hãy nhớ rằng những lời quả quyết và quan điểm như vậy đi lệch khỏi ý nghĩa của lời dạy và không có căn cứ kinh điển. Chỉ khi phân tích được các nhóm sắc và danh thành các giới, trí mới đạt đến chân đế. Niết-bàn là pháp có thể chứng đạt khi đi từ lĩnh vực chân đế. Hãy lưu ý rằng không thể đi từ lĩnh vực chế định mà chứng đạt pháp ấy.

Quán theo nhóm và minh sát từng pháp

Samūhaggahaṇavasena pavattaṃ kalāpasammasanaṃ. Phassādiekekadhammaggahaṇavasena pavattā anupadadhammavipassanā. (Mūlaṭī I, 109.)

Minh sát có hai loại, minh sát theo phương pháp nhóm (nayavipassanā), gọi là quán theo nhóm (kalāpasammasana), và minh sát từng pháp (anupadadhammavipassanā). Có thể xếp các hành thành hai nhóm theo sắc và danh, năm nhóm theo năm uẩn, mười hai nhóm theo mười hai xứ, mười tám nhóm theo mười tám giới, mười hai nhóm theo các chi duyên khởi, và những cách khác…


<a id="M09-body-P025"></a>
## Hai cách quán và các chi Duyên khởi
Miến / Burmese 25

… Khi quán bao quát các sắc pháp và danh pháp theo các cách phân nhóm như vậy, lấy cảnh theo từng cụm, từng tập hợp, từng nhóm, thì gọi là quán theo nhóm, tức phương pháp minh sát theo nhóm. [Theo phương pháp này, lấy chung làm cảnh các sắc pháp hiện hữu trong 42 phần thuộc sáu môn, rồi luân phiên áp dụng ba đặc tính mà quán minh sát. Tương tự, đối với các sắc pháp quá khứ, hiện tại và vị lai, nội phần và ngoại phần, hãy quán gộp và dần dần luân phiên áp dụng ba đặc tính. Đối với danh pháp, có thể lấy chung các danh pháp hiện hữu trong một sát-na tâm, hoặc xếp riêng thành nhóm thọ, nhóm tưởng, nhóm hành và nhóm thức để quán minh sát. Áp dụng tương tự đối với quá khứ, vị lai, hiện tại, nội phần, ngoại phần và các trường hợp còn lại.]

Cách tách riêng từng sắc pháp, như địa đại, thủy đại, hỏa đại và phong đại, trong mỗi nhóm sắc để quán minh sát, và cách lấy riêng từng tâm và tâm sở như xúc, thọ, tưởng, tư, trong nhóm tâm và tâm sở ở mỗi sát-na tâm để quán minh sát, gọi là phương pháp minh sát từng pháp (anupadadhammavipassanā).

Trong hai phương pháp minh sát ấy, Thanh tịnh đạo dạy rằng hành giả mới bắt đầu nỗ lực đối với các pháp minh sát nên khởi đầu với phương pháp minh sát theo nhóm, gọi là quán theo nhóm. (Visuddhi II, 241.)

Các chi Duyên khởi

Thanh tịnh đạo giải thích rằng các chi Duyên khởi cũng có mặt trong danh sách các pháp làm cảnh cho tuệ minh sát, bắt đầu bằng lời “dvādasa paṭiccasamuppādaṅgāni”, tức mười hai chi Duyên khởi. (Visuddhi II, 243.)


<a id="M09-body-P026"></a>
## Quán nhân và quả cùng các nhóm pháp
Miến / Burmese 26

Sapaccayanāmarūpavasena tilakkhaṇaṃ āropetvā vipassanāpaṭipāṭiyā “aniccaṃ dukkhaṃ anattā”ti sammasanto vicarati. (M-a I, 281.)

Chú giải Mūlapaṇṇāsa vừa dẫn cũng chỉ dạy quán minh sát danh và sắc cùng các duyên của chúng bằng cách áp dụng ba đặc tính theo thứ tự các tuệ minh sát.

Theo những lời chỉ dạy ấy, hãy nhìn cho thấy bằng trí tính chất liên hệ nhân quả giữa các chi Duyên khởi —
1. Khi thì các pháp nhân.
2. Khi thì các pháp quả.
Với cả hai, khi thì nhìn cho trí thấy tính vô thường, khi thì tính khổ, khi thì tính vô ngã, và quán luân phiên là vô thường, là khổ và là vô ngã.

Tóm gọn các lời chỉ dạy ở trên, khi quán minh sát, hành giả phải quán —
1. Khi thì nội phần.
2. Khi thì ngoại phần. Trong đó —
3. Khi thì sắc pháp.
4. Khi thì danh pháp.
5. Khi thì các pháp nhân.
6. Khi thì các pháp quả.
7. Khi thì là vô thường.
8. Khi thì là khổ.
9. Khi thì là vô ngã.
10. Khi thì là bất tịnh…


<a id="M09-body-P027"></a>
## Quán bất tịnh, quá khứ và vị lai
Miến / Burmese 27

… luân phiên áp dụng các đặc tính mà quán minh sát. Lại nữa —

Asubhā bhāvetabbā rāgassa pahānāya. (Udānapāḷi, Khu I, 120.)

Trong kinh Meghiya vừa dẫn, Đức Phật dạy tu tập bất tịnh để đoạn trừ tham. Tương tự, trong kinh Vijaya (Khu I, 308), Ngài cũng dạy tu tập bất tịnh để cắt đứt tham tận gốc. Pháp tu bất tịnh ấy thuộc lĩnh vực quán khổ trong ba đặc tính. Đây là cách quán minh sát đối với năm uẩn hiện tại.

Lại nữa, trong các bài pháp về ba vòng như kinh Vô ngã tướng, Đức Phật chỉ dạy quán minh sát cả năm uẩn quá khứ và năm uẩn vị lai, bắt đầu bằng lời “yaṃ kiñci rūpaṃ atītānāgatapaccuppannaṃ”, tức bất cứ sắc nào thuộc quá khứ, vị lai hay hiện tại. Theo lời chỉ dạy ấy, hãy ghi nhớ rằng phải quán minh sát các uẩn quá khứ và vị lai theo cùng phương pháp quán các uẩn hiện tại. Do đó, tính tất cả —
11. Khi thì quá khứ.
12. Khi thì vị lai.
Hãy ghi nhớ rằng cũng phải quán minh sát các pháp ấy.

Đó là những điều quan trọng liên quan đến công việc minh sát mà hành giả nên biết trước. Lại nữa, các sắc pháp và danh pháp ấy có thể xếp thành năm nhóm theo năm uẩn, mười hai nhóm theo mười hai xứ…


<a id="M09-body-P028"></a>
## Tuệ minh sát và thắng trí
Miến / Burmese 28

… mười tám nhóm theo mười tám giới, mười hai chi theo Duyên khởi, và có thể quán minh sát bằng từng phương pháp như vậy. Trong sách này, cách quán minh sát chủ yếu được trình bày theo phương pháp hai pháp sắc và danh, gom sắc vào một nhóm và danh vào một nhóm.

Tuệ minh sát và thắng trí

Về việc quán quá khứ và vị lai, một số vị thầy cho rằng chỉ khi đạt thắng trí (abhiññā), đặc biệt là thắng trí nhớ các đời trước (pubbenivāsānussati), mới có thể quán quá khứ và vị lai. Có hai cách quán quá khứ và vị lai, quán bằng thắng trí nhớ các đời trước và quán bằng tuệ minh sát. Trong Pāli thuộc Tương ưng Uẩn và trong Chú giải của bài kinh ấy có lời sau đây —

Ye hi keci, bhikkhave, samaṇā vā brāhmaṇā vā anekavihitaṃ pubbenivāsaṃ anussaramānā anussaranti, sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataraṃ. Katame pañca —
1. “Evaṃrūpo ahosiṃ atītamaddhānan”ti iti vā hi, bhikkhave, anussaramāno rūpaṃyeva anussarati.
2. “Evaṃvedano ahosiṃ atītamaddhānan”ti iti vā hi, bhikkhave, anussaramāno vedanaṃyeva anussarati.
3. “Evaṃsañño ahosiṃ atītamaddhānan”ti. Pe.
4. “Evaṃsaṅkhāro ahosiṃ atītamaddhānan”ti. Pe.
5. “Evaṃviññāṇo ahosiṃ atītamaddhānan”ti iti vā hi, bhikkhave, anussaramāno viññāṇaṃyeva anussarati. (Saṃ II, 71.)

Pubbenivāsanti na kho idaṃ abhiññāvasena anussaraṇaṃ sandhāya vuttaṃ.


<a id="M09-body-P029"></a>
## Đối tượng nhớ lại bằng tuệ minh sát
Miến / Burmese 29

Vipassanāvasena pana pubbenivāsaṃ anussarante samaṇabrāhmaṇe sandhāyetaṃ vuttaṃ. Tenevāha — “Sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataraṃ”ti. Abhiññāvasena hi samanussarantassa khandhāpi upādānakkhandhāpi khandhapaṭibaddhāpi paññattipi ārammaṇaṃ hotiyeva. Rūpaṃyeva anussaratīti evaṃ anussaranto na aññaṃ kiñci sattaṃ vā puggalaṃ vā anussarati. Atīte pana niruddhaṃ rūpakkhandhameva anussarati. Vedanādīsupi eseva nayo. (Saṃ-a II, 266, mục 79.)

Này các tỳ-khưu … một số người được gọi là sa-môn và bà-la-môn ở đời, nếu muốn, có thể dùng trí lần theo và nhớ lại dòng uẩn của nhiều đời trước, không chỉ một đời. Khi nhớ lại như vậy, tất cả những sa-môn và bà-la-môn ấy, nếu muốn, có thể nhớ lại cả năm thủ uẩn hoặc bất kỳ một uẩn nào trong năm thủ uẩn ấy.

Này các tỳ-khưu … những sa-môn và bà-la-môn ấy —
1. Có thể dùng trí lần theo và nhớ lại rằng “Trong thời quá khứ, sắc pháp có tính chất như vậy đã từng sinh khởi.”
2. “Trong thời quá khứ, thọ có tính chất như vậy đã từng sinh khởi.” Pe.
3. “Trong thời quá khứ, tưởng có tính chất như vậy đã từng sinh khởi.” Pe.
4. “Trong thời quá khứ, hành có tính chất như vậy đã từng sinh khởi.” Pe.
5. “Trong thời quá khứ, thức có tính chất như vậy đã từng sinh khởi…


<a id="M09-body-P030"></a>
## Phân biệt hai cách nhớ lại đời trước
Miến / Burmese 30

… ” — cũng có thể dùng trí lần theo và nhớ lại như vậy, nếu họ muốn nhớ lại. (Saṃ II, 71, Khajjanīya Sutta.)

Pubbenivāsa có nghĩa là có thể dùng trí lần theo và nhớ lại dòng uẩn từng hiện hữu trước đây. Khi dùng từ ấy, Đức Phật không có ý nói đến việc dùng năng lực của túc trú tùy niệm thắng trí để lần theo và nhớ lại dòng uẩn từng hiện hữu trước đây. Thực ra, Ngài thuyết bài kinh này chỉ nhằm đến các sa-môn và bà-la-môn dùng năng lực của tuệ minh sát để lần theo bằng trí và nhớ lại dòng uẩn đã từng sinh khởi, từng hiện hữu trước đây. Chính vì thế mà Đức Phật đích thân dạy “Họ có thể dùng trí lần theo và nhớ lại năm thủ uẩn, hoặc bất kỳ một uẩn nào trong năm thủ uẩn ấy.” Điểm phân biệt là thế này. Nếu dùng năng lực của thắng trí để lần theo bằng trí và nhớ lại dòng uẩn đã từng sinh khởi và hiện hữu trước đây, thì túc trú tùy niệm thắng trí ấy —

1. Có thể nhớ và biết cả năm uẩn bao gồm các pháp siêu thế. (Nghĩa là có thể biết năm uẩn bao gồm các pháp siêu thế từng sinh trong dòng tương tục của các bậc Thánh thiện, kể cả các Đức Phật thời quá khứ.)
2. Cũng có thể nhớ và biết năm thủ uẩn. (Nghĩa là trong đó không bao gồm các pháp siêu thế.)
3. Cũng có thể nhớ và biết những gì liên hệ với các uẩn, như dòng họ, hình dáng, thức ăn, lạc, khổ và những điều tương tự.


<a id="M09-body-P031"></a>
## Quán các uẩn quá khứ
Miến / Burmese 31

4. Cũng có thể nhớ và biết các loại chế định như tên gọi, danh xưng.

Nhưng tuệ minh sát không thể biết các mục (1), (3) và (4) nêu trên. Tuệ ấy chỉ có thể lần theo thứ tự mà biết những pháp làm đối tượng quán, tức năm thủ uẩn ở mục (2).

Rūpayeva anussarati, nghĩa là dùng tuệ lần theo thứ tự mà nhớ lại chỉ sắc pháp. Khi nhớ lại dòng uẩn quá khứ theo thứ tự bằng tuệ minh sát như vậy, hành giả không dùng tuệ lần theo thứ tự để nhớ một hữu tình hay một người nào khác với pháp chân đế, tức một tự ngã. Hành giả chỉ dùng tuệ lần theo thứ tự để nhớ sắc uẩn đã diệt trong quá khứ. Với thọ v.v. cũng vậy. Hãy ghi nhớ. (Saṃ. A. 2, 266, đoạn 79.)

Do đó, hãy ghi nhớ rằng người mới hành thiền có thể dùng tuệ minh sát để quán và thấy năm thủ uẩn quá khứ. Ở đây, tuệ minh sát cũng bao gồm tuệ phân định danh sắc và tuệ liễu tri duyên.

Một chìa khóa quan trọng

Có thể dùng tuệ lần theo thứ tự để nhớ lại và nhận diện năm uẩn quá khứ là một công việc đặc biệt quan trọng trong việc nhận diện các nhân quá khứ. Nếu chưa biết cách nhận diện năm uẩn quá khứ thì không thể nhận diện bằng bất cứ phương pháp nào các nhân quá khứ vốn nằm trong năm uẩn quá khứ và là một phần của chúng.


<a id="M09-body-P032"></a>
## Một chìa khóa quan trọng
Miến / Burmese 32

Tương tự, không thể nhận diện bằng bất cứ phương pháp nào cách các quả quá khứ tương ứng sinh do các nhân quá khứ tương ứng, hay cách các quả hiện tại sinh do các nhân quá khứ tương ứng. Cũng vậy, nếu không thể nhận diện năm uẩn vị lai thì không thể nhận diện bằng bất cứ phương pháp nào cách quả vị lai sinh do nhân hiện tại, hoặc do nhân quá khứ tương ứng, hay cách quả vị lai tương ứng sinh do nhân vị lai tương ứng. Đó là vì các quả vị lai và các nhân vị lai chỉ là một phần của năm uẩn vị lai.

Để tìm các nhân và quả quá khứ, các nhân và quả vị lai, một chìa khóa quan trọng là có thể nhận diện một trong ba loại tướng hiện ra lúc cận tử, khi hấp hối, là nghiệp, nghiệp tướng và thú tướng. Tướng ấy hiện ra và được thấy do năng lực của nghiệp sắp cho quả, nên nó là chìa khóa đặc biệt quan trọng để tìm nghiệp sắp cho quả, nghiệp đã cho quả hoặc nghiệp đang cho quả. Đó là tướng hiện ra tương ứng ở một trong sáu môn lúc cận tử, khi hấp hối, đặc biệt là tướng hiện ra nơi yếu tố trong sáng của tâm hữu phần, tức ý môn, lúc cận tử. Chỉ khi nhận diện được sáu môn ấy, nhất là ý môn, mới có thể nhận diện tiếp cảnh tướng hiện ra nơi môn thích hợp. Chỉ khi nhận diện được tướng ấy mới có thể nhận diện nghiệp cho quả và vô minh


<a id="M09-body-P033"></a>
## Nhận diện cảnh cận tử
Miến / Burmese 33

ái và thủ vây quanh nghiệp ấy.

Đặc biệt, chỉ khi có thể nhận diện yếu tố trong sáng của tâm hữu phần, tức ý môn, mới có thể nhận diện các dòng tâm lộ sinh xen giữa các tâm hữu phần ấy. Những nhân gọi là vô minh, ái, thủ, hành và nghiệp chỉ là các pháp nằm trong những dòng tâm lộ ấy. Chúng chỉ là những phần của các tâm lộ ấy.

Để tìm các nhân quá khứ, biết cách nhận diện cảnh của tốc hành tâm cận tử trong quá khứ là điều vô cùng quan trọng. Muốn nhận diện được cảnh của tốc hành tâm cận tử ấy, điều vô cùng quan trọng là có thể nhận diện yếu tố trong sáng của tâm hữu phần, tức ý môn, hiện diện lúc hấp hối trong đời quá khứ ấy. Chỉ khi nhận diện được như vậy mới có thể nhận diện:

1. Cảnh của các tốc hành tâm cận tử hiện ra ở yếu tố trong sáng của tâm hữu phần ấy, tức ý môn.

2. Các dòng tâm lộ, gồm cả những tốc hành tâm cận tử, sinh xen giữa các tâm hữu phần ấy, tức ý môn.

3. Nghiệp làm nhân khiến cảnh ấy hiện ra.

4. Vô minh, ái và thủ khiến nghiệp ấy sinh.

Tương tự, nếu một người mới hành thiền vẫn còn một đời vị lai, người ấy cần nhận diện cảnh của các tốc hành tâm cận tử hiện ra khi hấp hối lúc cận tử trong đời hiện tại này. Muốn nhận diện được như vậy, lúc hấp hối


<a id="M09-body-P034"></a>
## Nhận diện cảnh cận tử
Miến / Burmese 34

trước hết phải biết nhận diện yếu tố trong sáng của tâm hữu phần, tức ý môn, đang sinh. Chỉ khi nhận diện được như vậy mới có thể nhận diện cảnh của tốc hành tâm cận tử hiện ra nơi ý môn ấy, nghiệp sắp cho quả khiến cảnh ấy hiện ra, và vô minh, ái, thủ làm nhân hỗ trợ cho nghiệp ấy.

Tương tự, đối với người mới hành thiền vẫn còn hành trình luân hồi trong vị lai, để tìm sự nối tiếp nhân quả, tức các pháp duyên khởi, qua các đời vị lai, cần nhận diện cảnh của tốc hành tâm cận tử hiện ra tại ý môn gần tử tâm vị lai ấy. Tướng ấy hiện ra do nghiệp sẽ tạo nên một đời vị lai kế tiếp. Vì vậy, nghiệp làm tướng ấy hiện ra chính là một nhân của các uẩn vị lai, bắt đầu từ đời vị lai thứ hai. Các tướng ấy có thể hiện ra do nghiệp quá khứ gọi là aparāpariya, do nghiệp đã tạo và vun bồi trong hiện tại, hoặc do nghiệp vị lai sắp cho quả, thuộc các nghiệp sẽ tạo và vun bồi trước tử tâm vị lai ấy. Dựa trên tướng ấy mà tìm, hành giả sẽ dễ dàng tìm thấy nghiệp ấy. Cũng có thể tìm thấy vô minh, ái và thủ hỗ trợ cho nghiệp ấy. Muốn nhận diện được như vậy, đặc biệt cần có khả năng nhận diện sáu môn lúc hấp hối, nhất là yếu tố trong sáng của tâm hữu phần, tức ý môn.

Do đó, khả năng nhận diện các uẩn quá khứ và vị lai không chỉ là điều quan trọng


<a id="M09-body-P035"></a>
## Bắt đầu minh sát từ đối tượng dễ nhận diện
Miến / Burmese 35

và cần thiết để minh sát các uẩn quá khứ và vị lai. Đó còn là điều kiện đặc biệt quan trọng để nhận diện các pháp duyên khởi và minh sát những pháp do duyên khởi.

Hãy bắt đầu minh sát từ đối tượng dễ nhận diện

Theo nguyên tắc rằng khi bắt đầu minh sát, hành giả có thể bắt đầu với sắc pháp hoặc danh pháp dễ nhận diện và dễ hiện rõ trong tuệ, trước hết sách này trình bày cách bắt đầu minh sát từ danh sắc đang có mặt trong hiện tại.

Hiền giả, trước tiên hãy tuần tự phát triển định mình đã đạt đến mức cao nhất. Nếu có thể phát triển định đến tứ thiền, hãy tái lập định tứ thiền ấy mỗi lần ngồi thiền. Nếu là hành giả thuần minh sát và chỉ thực hành đề mục tứ đại, hãy lấy bốn đại làm cảnh và phát triển định đến khi ánh sáng và năng lực trở nên mạnh mẽ.

Vì sách này trình bày đề mục sắc trước, và vì bắt đầu từ sắc pháp rồi chuyển sang minh sát sẽ dễ dàng hơn, hãy bắt đầu minh sát từ sắc pháp.

Trước tiên, đối với sắc chân thật hiện diện trong sáu môn và 42 phần:

(a) Hoặc quán gộp 54 hay 44 loại sắc pháp hiện diện ở từng môn;

(b) Hoặc quán gộp các sắc pháp, như 44 loại sắc pháp hiện diện ở từng phần;


<a id="M09-body-P036"></a>
## Quán ba đặc tướng của sắc
Miến / Burmese 36

(c) Hoặc quán gộp tất cả sắc pháp hiện diện trong sáu môn và 42 phần:

1. Lấy sự kiện các sắc pháp ấy diệt sau khi sinh làm cảnh, dùng tuệ nhìn cho thấy rõ và quán nhiều lần là vô thường. Quán đi quán lại, khi thì bên trong, khi thì bên ngoài. Khi quán như vậy, ở bên ngoài hãy dần mở rộng từ gần đến xa, cho đến vô lượng thế giới, và quán đi quán lại nhiều lần.

2. Dùng tuệ nhìn cho thấy rõ tính chất luôn bị bức bách, áp đảo bởi sự sinh và diệt của các sắc pháp ấy, rồi quán đi quán lại nhiều lần là khổ. Hãy quán đi quán lại nhiều lần, khi thì bên trong, khi thì bên ngoài, từ gần đến xa. Hãy mở rộng tuệ đến vô lượng thế giới mà quán.

3. Lấy làm cảnh tính chất các sắc pháp ấy không có cốt lõi gọi là tự ngã, một thực thể trường tồn, rắn chắc, đứng vững và không tan rã. Dùng tuệ nhìn cho thấy rõ rồi quán đi quán lại nhiều lần là vô ngã. Hãy quán khi thì bên trong, khi thì bên ngoài. Dần dần mở rộng từng ít một từ gần đến xa, cho đến vô lượng thế giới, và quán khi thì bên trong, khi thì bên ngoài.

[Ghi chú — Các sắc không thật không thích hợp để áp dụng ba đặc tướng rồi quán minh sát. Do đó, từ thời điểm này, từ phần này trở đi, hãy tạm dừng việc xem xét và phân tích các sắc không thật.]

Khi quán minh sát như vậy, áp dụng ba đặc tướng cho hai dòng tương tục bên trong và bên ngoài, luân phiên quán thật nhanh, hãy quán cho đến khi thấy sự sinh diệt diễn ra rất nhanh và thật rõ. Còn việc quán là vô thường,


<a id="M09-body-P037"></a>
## Sự biến mất của sắc và danh
Miến / Burmese 37

quán là khổ, và quán là vô ngã thì hãy quán tương đối chậm. Dùng tuệ quán sao cho thấy sinh diệt nhanh hết mức có thể. Chỉ áp dụng các đặc tướng tương đối chậm.

Đừng lấy sự sinh diệt của các hạt nhỏ là các nhóm sắc làm cảnh rồi áp dụng các đặc tướng. Hãy phân tích các nhóm sắc thành các giới và dùng tuệ nhìn cho thấy chỉ các sắc pháp chân đế đang sinh diệt. Khi thấy được, hãy áp dụng các đặc tướng và quán minh sát.

Hãy coi chừng sự biến mất của sắc và danh

Các nhóm sắc chỉ là những khối, tập hợp và tổ hợp nhỏ nhất vẫn còn thuộc chế định, chẳng hạn chế định tập hợp. Chế định không hiện hữu thực sự nên không chịu được sự quan sát lâu. Khi một người mới hành thiền chuyên cần tu tập một đề mục, người ấy thường thấy các nhóm sắc tùy theo ba-la-mật của mình. Bấy giờ, nếu không thể nhận diện các pháp chân đế có trong từng nhóm sắc, như đất, nước, lửa, gió, sắc, hương, vị và dưỡng chất, và vì không nhận diện được nên tuệ chưa đạt đến chân đế, mà lại nhìn sự sinh diệt của các nhóm sắc ấy, áp dụng đặc tướng và quán là vô thường, khổ hay vô ngã, thì do các chế định ấy không chịu được việc bị nghiền nát lâu bằng tuệ, tức không chịu được sự quan sát lâu, chẳng bao lâu người mới hành thiền thường sẽ không còn thấy các nhóm sắc. Khi không còn thấy các nhóm sắc như vậy, năng lực của định tu tập vẫn chưa suy giảm nhiều, nên người ấy còn có thể thấy khối trắng, mảng trắng, khối trong sáng,


<a id="M09-body-P038"></a>
## Sự biến mất của sắc và danh
Miến / Burmese 38

hoặc mảng trong sáng, thấy dưới dạng một khối, một cục hay cả một mảng lớn. Nếu chuyên chú quán mảng trong sáng hoặc mảng trắng ấy cho tâm an tĩnh, dính sát và trụ nơi đó, tâm có thể an tĩnh, dính sát và trụ nơi cảnh ấy. Một số người mới hành thiền gọi trạng thái như vậy là «sắc diệt». Nếu nới lỏng đôi chút cái tâm đang an tĩnh, dính sát và trụ nơi cảnh ấy thì tâm lại có thể rơi vào hữu phần. Một số người gọi ngay cả việc rơi vào hữu phần như vậy là «danh diệt», vì không biết cảnh đang quán trong hiện tại nên cho rằng không còn biết gì. Họ thường cho rằng chính những hiện tượng như thế đã được thấy bằng tuệ. Hãy cẩn trọng.

Hãy đặc biệt lưu ý những lời đã trình bày ở trên:

1. Chỉ quán minh sát riêng năm uẩn bên trong;

2. Chỉ quán minh sát riêng năm uẩn bên ngoài, và trong đó:

3. Chỉ quán minh sát riêng sắc pháp;

4. Chỉ quán minh sát riêng danh pháp. Những lời dạy nói rằng làm như vậy thì không thể đạt đến Thánh đạo. (Abhi. A. 1, 270–271.)

5. Những lời dạy nói rằng nếu không biết rành rẽ bằng ba loại liễu tri sự nối tiếp nhân quả, tức các pháp duyên khởi, thì không thể thoát luân hồi, tức không thể đạt Thánh đạo. (Dī. 2, 47.)

6. Những lời dạy nói rằng nếu không biết rành rẽ bằng ba loại liễu tri trọn cả năm thủ uẩn, tức sắc pháp và danh pháp, thì không thể thoát khỏi khổ luân hồi


<a id="M09-body-P039"></a>
## Cách quán minh sát danh pháp
Miến / Burmese 39

(Saṃ. 2, 249).

Hãy đặc biệt lưu ý những lời dạy trích từ Chánh tạng Pāli, Chú giải và Phụ chú giải này.

Cũng hãy lưu ý rằng nếu nhận diện trở lại bốn đại hiện diện trong mảng trong sáng ấy, hoặc nhận diện giới hư không, thì chẳng bao lâu có thể thấy lại các hạt nhóm sắc.

[Ghi chú — Khi quán minh sát sắc pháp, hãy quán minh sát cả các sắc vô mạng, gọi là anupādinnaka-sarīra.]

Cách quán minh sát danh pháp

Sau khi quán minh sát sắc pháp và đạt mức tương đối thỏa đáng, hãy chuyển sang quán minh sát danh pháp. Tốt hơn là chuyển sang quán danh pháp khi đã có thể quán minh sát sắc pháp, chuyển qua chuyển lại một cách nhanh nhẹn.

Vì trước kia đã nhận diện danh pháp theo từng xứ và môn, khi quán minh sát cũng hãy bắt đầu quán danh pháp theo từng xứ và môn. Đối với các nhóm tâm thuộc lộ cùng các pháp tương ưng, cũng như các nhóm tâm hữu phần hiện diện xen giữa hai lộ, hãy lấy tính chất mỗi nhóm tâm sinh rồi diệt, từng sát-na, làm cảnh và quán «vô thường, vô thường». Hãy quán hết các lộ như lộ nhãn môn, từng lộ tốc hành thiện và từng lộ tốc hành bất thiện. Hãy quán cả hai dòng tương tục bên trong và bên ngoài. Trước tiên, từ gần


<a id="M09-body-P040"></a>
## Quán các lộ tâm qua sáu môn
Miến / Burmese 40

hãy quán nhiều lần, khi thì bên trong, khi thì bên ngoài. Khi đã thành thục, hãy dần mở rộng từng ít một, quán gộp cả 31 cõi hoặc quán gộp đến vô lượng thế giới. Hãy quán đi quán lại nhiều lần, khi thì bên trong, khi thì bên ngoài. Khi đã thỏa đáng về đặc tướng vô thường, hãy dùng tuệ nhìn cho thấy tính chất luôn bị sự sinh diệt của các danh pháp ấy bức bách và áp đảo. Cũng hãy quán đi quán lại nhiều lần «khổ, khổ». Khi lại đạt đến mức tương đối thỏa đáng về đặc tướng khổ ấy, hãy lấy làm cảnh sự vắng mặt trong các danh pháp của một tự ngã vững chắc, một thực thể cốt lõi không tan rã, tồn tại bền chắc, và quán «vô ngã, vô ngã». Trong cả hai dòng tương tục, bên trong và bên ngoài, hãy quán hết các nhóm tốt với tốc hành thiện và các nhóm xấu với tốc hành bất thiện trong cả sáu nhóm, bắt đầu từ nhóm cảnh sắc. Khi quán danh pháp như vậy:

1. Các lộ nhãn môn và lộ ý môn lấy cảnh sắc làm cảnh;

2. Các lộ nhĩ môn và lộ ý môn lấy cảnh thinh làm cảnh;

3. Các lộ tỷ môn và lộ ý môn lấy cảnh hương làm cảnh;

4. Các lộ thiệt môn và lộ ý môn lấy cảnh vị làm cảnh;

5. Các lộ thân môn và lộ ý môn lấy cảnh xúc làm cảnh;

6. Các lộ ý môn lấy cảnh pháp làm cảnh.

Hãy quán đầy đủ các lộ này theo thứ tự, như đã trình bày trong các bảng ở phần đề mục danh. Hãy quán đi quán lại nhiều lần.


<a id="M09-body-P041"></a>
## Thứ tự quán của hành giả lấy thiền chỉ làm cỗ xe
Miến / Burmese 41

Nếu người mới hành thiền là hành giả lấy thiền chỉ làm cỗ xe, tốt hơn là bắt đầu minh sát từ các danh pháp hiện diện trong lộ tâm nhập thiền mà mình đã đạt. Ví dụ, hãy nhập sơ thiền. Xuất khỏi sơ thiền ấy, hãy bắt đầu quán minh sát các danh pháp hiện diện trong lộ tâm nhập sơ thiền, lần lượt áp dụng từng đặc tướng trong ba đặc tướng. Cũng quán minh sát theo cùng cách đối với các danh pháp hiện diện trong lộ tâm nhập nhị thiền v.v. Hãy quán minh sát đầy đủ các danh pháp hiện diện trong những lộ tâm nhập thiền mình đã đạt. Hãy lần lượt áp dụng ba đặc tướng và quán đi quán lại nhiều lần. Khi đã đạt mức thỏa đáng, hãy quán minh sát các danh pháp hiện diện trong sáu nhóm theo thứ tự, bắt đầu từ lộ nhãn môn và lộ ý môn lấy cảnh sắc, lần lượt áp dụng từng đặc tướng trong ba đặc tướng.

Hãy ưu tiên quán đặc tướng thích hợp với mình

Evaṃ saṅkhāre anattato passantassa diṭṭhisamugghāṭanaṃ nāma hoti. Aniccato passantassa mānasamugghāṭanaṃ nāma hoti. Dukkhato passantassa nikantipariyādānaṃ nāma hoti. Kuto ayaṃ vipassanā attano attano ṭhāneyeva tiṭṭhatīti. (Vism. Mahāṭī. 2, 464.) Khi thấy các hành là vô ngã như vậy thì gọi là nhổ tận gốc kiến. Khi thấy là vô thường thì gọi là nhổ tận gốc mạn. Khi thấy là khổ thì gọi là dứt sạch sự ưa thích. Do đâu mà mỗi phép minh sát này chỉ đứng ở vị trí riêng của mình?

Người mới hành thiền cần tu tập và khảo sát bằng minh sát để trở nên thuần thục và có năng lực vững mạnh trong việc áp dụng ba đặc tướng cho các pháp hữu vi. Khi tu tập và khảo sát như vậy, chỉ khi hai tuệ tùy quán kia trợ giúp một tuệ tùy quán bằng năng lực của duyên y chỉ mạnh (upanissaya), thì tuệ tùy quán ấy


<a id="M09-body-P042"></a>
## Sự hỗ trợ giữa ba tuệ tùy quán
Miến / Burmese 42

trở nên sắc bén, thuần thục và trong sạch. Chỉ tuệ tùy quán đã trở nên sắc bén, thuần thục và trong sạch như vậy mới có thể phá tan phiền não.

Tuệ tùy quán vô ngã, khi nhận được sức hỗ trợ đặc biệt của tuệ tùy quán vô thường và tuệ tùy quán khổ qua năng lực duyên y chỉ mạnh, trở nên sắc bén, thuần thục và trong sạch. Vì vậy, người mới hành thiền đã nhiều lần nghiền nát các pháp hữu vi bằng tuệ tùy quán vô thường và tuệ tùy quán khổ, hãy tiếp tục nghiền nát nhiều lần các pháp hữu vi ấy bằng tuệ tùy quán vô ngã. Hãy ưu tiên quán vô ngã. Khi ấy tuệ tùy quán vô ngã có thể chín muồi, sắc bén, thuần thục và trong sạch. Tuệ tùy quán vô ngã đã chín muồi, sắc bén, thuần thục và trong sạch như vậy có thể loại bỏ sự chấp kiến bám chặt vào các pháp hữu vi ấy. Tất cả tà kiến đều dựa vào ngã kiến và có ngã kiến làm nền tảng, làm nhân. Tuệ tùy quán vô ngã đối lập trực tiếp với ngã kiến. Do đó, tùy quán vô ngã có thể loại bỏ sự chấp kiến.

Lại nữa, tuệ tùy quán vô thường, khi nhận được sức hỗ trợ đặc biệt của tuệ tùy quán khổ và tuệ tùy quán vô ngã qua năng lực duyên y chỉ mạnh, trở nên sắc bén, thuần thục và trong sạch. Vì vậy, người mới hành thiền đã nhiều lần nghiền nát các pháp hữu vi bằng tuệ tùy quán khổ và tuệ tùy quán vô ngã, hãy tiếp tục nghiền nát nhiều lần các pháp hữu vi ấy bằng tuệ tùy quán


<a id="M09-body-P043"></a>
## Tùy quán vô thường và tùy quán khổ
Miến / Burmese 43

vô thường. Hãy ưu tiên quán vô thường. Khi ấy tuệ tùy quán vô thường có thể chín muồi, sắc bén, thuần thục và trong sạch. Tuệ tùy quán vô thường đã chín muồi, sắc bén, thuần thục và trong sạch như vậy có thể loại bỏ mạn bám chặt vào các pháp hữu vi ấy. Khi sự chấp các pháp hữu vi là thường, tức tính thường còn, hiện rõ, người ta có thể vênh váo vì mạn, chẳng hạn trước người khác, «Kvaṃ nīcaṃ, kvaṃ uccaṃ», «Đây là chỗ thấp, đây là chỗ cao.»

Lại nữa, tuệ tùy quán khổ, khi nhận được sức hỗ trợ đặc biệt của tuệ tùy quán vô thường và tuệ tùy quán vô ngã qua năng lực duyên y chỉ mạnh, trở nên sắc bén, thuần thục và trong sạch. Vì vậy, người mới hành thiền đã nhiều lần nghiền nát các pháp hữu vi bằng tuệ tùy quán vô thường và tuệ tùy quán vô ngã, hãy tiếp tục nghiền nát nhiều lần các pháp hữu vi ấy bằng tuệ tùy quán khổ. Hãy ưu tiên quán khổ. Khi tuệ tùy quán khổ ấy chín muồi, sắc bén, thuần thục và trong sạch, tuệ tùy quán khổ đã chín muồi, sắc bén, thuần thục và trong sạch như vậy có thể làm cạn kiệt sự chấp do ái, tức sự ưa thích do ái, đang bám chặt vào các pháp hữu vi ấy với ý nghĩ «của tôi, của tôi». Chỉ khi lạc tưởng, tức sự ghi nhận «là lạc», hiện rõ đối với các pháp hữu vi ấy thì ái chấp, tức sự chấp do ái, mới có thể hiện rõ và nắm lấy các pháp hữu vi ấy với ý nghĩ «của tôi, của tôi». Tuệ tùy quán khổ


<a id="M09-body-P044"></a>
## Hiện tại theo đời và phương pháp năm uẩn
Miến / Burmese 44

đối lập trực tiếp với sự chấp và sự ưa thích do ái ấy. Vì vậy, tuệ tùy quán khổ có thể làm cạn kiệt sự chấp do ái. (Vism. 2, 464. Mahāṭī. 2, 405–406.)

Vì vậy, sau khi đã tu tập thành thạo cả ba đặc tướng, hãy ưu tiên quán một đặc tướng mình ưa thích trong thời gian khá lâu. Nếu năng lực của tuệ tùy quán ấy chưa mạnh, hãy lại quán hai đặc tướng kia. Tuệ minh sát chỉ có thể loại bỏ phiền não bằng sự đoạn trừ từng phần. Chỉ tuệ Thánh đạo mới có thể đoạn trừ tận gốc, không dư sót. Để đạt đến Thánh đạo, hãy nỗ lực làm cho các tuệ minh sát chín muồi.

Hiện tại theo đời (addhā-paccuppanna)

Đối với các sắc pháp và danh pháp đã sinh, đang sinh và sẽ sinh trong suốt một đời, từ tái tục cho đến tử tâm:

1. Áp dụng lần lượt ba đặc tướng cho riêng sắc.

2. Áp dụng lần lượt ba đặc tướng cho riêng danh.

Hãy quán minh sát thật thường xuyên, đi quán lại nhiều lần. Cần quán nhiều lượt theo mỗi phép tùy quán. Hãy quán đi quán lại nhiều lần, khi thì bên trong, khi thì bên ngoài, khi thì vô thường, khi thì khổ, khi thì vô ngã.

Phương pháp năm uẩn

Hiền giả, hãy nhớ lại rằng trước kia mình đã nhận diện danh pháp theo từng xứ và môn. Đặc biệt hãy nhớ lại các bảng trong phần đề mục danh.


<a id="M09-body-P045"></a>
## Phương pháp năm uẩn
Miến / Burmese 45

Trước hết, hãy nhớ lại lộ nhãn môn và lộ ý môn với tốc hành đại thiện tương ưng trí, câu hữu hỷ, v.v. Những pháp hiện diện trong mỗi nhóm tâm gồm:

1. Sắc làm chỗ nương (54) và cảnh sắc là sắc uẩn;

2. Từng thọ là thọ uẩn;

3. Từng tưởng là tưởng uẩn;

4. Từng nhóm các tâm sở hành còn lại là hành uẩn;

5. Từng tâm hay thức biết cảnh là thức uẩn.

Như vậy cũng hãy quán minh sát sắc pháp thành một phần và danh pháp thành bốn phần. Hãy lần lượt áp dụng ba đặc tướng mà quán.

1. Các lộ nhãn môn cùng lộ ý môn còn lại cũng lấy cảnh sắc làm cảnh;

2. Các lộ nhĩ môn cùng lộ ý môn lấy cảnh thinh làm cảnh;

3. Các lộ tỷ môn cùng lộ ý môn lấy cảnh hương làm cảnh;

4. Các lộ thiệt môn cùng lộ ý môn lấy cảnh vị làm cảnh;

5. Các lộ thân môn cùng lộ ý môn lấy cảnh xúc làm cảnh;

6. Các lộ ý môn lấy cảnh pháp làm cảnh.

Đối với từng lộ trong số này, cũng hãy quán minh sát theo phương pháp năm uẩn. Trong từng hàng của các bảng đã trình bày ở phần đề mục danh, từ lộ ý môn theo sau ngũ môn cho đến lộ ý môn thuần túy:

1. Nếu xuyên suốt riêng sắc, xuyên suốt cả hàng;

2. Nếu xuyên suốt riêng thọ, xuyên suốt cả hàng;

3. Nếu xuyên suốt riêng tưởng, xuyên suốt cả hàng;


<a id="M09-body-P046"></a>
## Quán từng uẩn từ cận hiện tại đến trọn một đời
Miến / Burmese 46

4. Quán xuyên suốt, không bỏ sót, riêng các tâm sở thuộc hành.

5. Quán xuyên suốt, không bỏ sót, riêng tâm biết, tức thức.

Hãy quán minh sát bằng cách lần lượt đặt lên chúng ba đặc tính. Khi quán như vậy, hãy quán cả những sát-na hữu phần xen giữa các lộ tâm theo phương pháp năm uẩn. Cũng quán tương tự đối với các lộ ý môn lấy cảnh pháp làm đối tượng.

Khi đã quán minh sát bên trong bằng phương pháp năm uẩn đến mức tương đối nhuần nhuyễn, hãy quán minh sát bên ngoài theo cùng cách. Từ gần đến xa, hãy quán đi quán lại nhiều lần, luân phiên bên trong và bên ngoài. Lấy ba mươi mốt cõi làm phạm vi và mở rộng tuệ quán đến các thế giới vô tận.

Dù quán minh sát theo phương pháp hai nhóm sắc danh hay theo phương pháp năm uẩn, hãy nỗ lực quán đến mức thấy hiện tại sát-na (khaṇapaccuppanna). Để tuệ thấy rõ và trong sáng đến mức hiện tại sát-na, hãy quán xen cả các danh pháp hữu phần giữa các lộ tâm cho đến mức hiện tại sát-na.

Khi đã tương đối nhuần nhuyễn trong việc quán minh sát hiện tại theo phương pháp năm uẩn, hãy tiếp tục quán năm uẩn từ tái tục đến tử, gọi là hiện tại theo một đời (addhāpaccuppanna). Quán xuyên suốt, không bỏ sót, từ tái tục đến tử —

1. riêng sắc

2. riêng thọ

3. riêng tưởng

4. riêng các tâm sở thuộc hành

5. riêng tâm biết, tức thức


<a id="M09-body-P047"></a>
## Quán từng uẩn và quán chung sắc danh
Miến / Burmese 47

Hãy quán minh sát trong cả tâm lộ và tâm ngoài lộ bằng cách lần lượt đặt lên chúng ba đặc tính. Cần quán nhiều lần là vô thường, nhiều lần là khổ và nhiều lần là vô ngã. Khi quán như vậy, hãy quán xuyên suốt từng uẩn từ tái tục đến tử. Ví dụ, sau khi quán minh sát xuyên suốt, thật kỹ sắc uẩn từ tái tục đến tử, mới chuyển sang thọ uẩn và quán tương tự. Hãy luân phiên quán đi quán lại bên trong và bên ngoài.

Cũng hãy quán chung sắc và danh

Khi đã tương đối nhuần nhuyễn trong việc quán minh sát theo phương pháp hai nhóm sắc danh hay theo phương pháp năm uẩn, có thể quán sắc và danh cùng nhau. Trước hết, hãy quán lại minh sát riêng sắc và riêng danh cho thuần thục, cả bên trong lẫn bên ngoài. Khi đã có thể quán nhanh nhạy, luân phiên qua lại, trước hết hãy quán theo từng xứ và môn, trong mỗi sát-na tâm như trình bày trong các bảng ở phần đề mục thiền về danh —

1. Sắc vật nương và sắc làm cảnh.

2. Nhóm danh pháp gồm tâm và tâm sở của mỗi sát-na tâm.

Lấy bản chất tan rã, diệt mất theo từng nhóm của sắc và danh ấy làm cảnh, hoặc lấy chính sự sinh và diệt làm cảnh, rồi quán minh sát bằng cách lần lượt đặt lên chúng ba đặc tính.

Ở sát-na hướng ngũ môn, tức sát-na hướng tâm đến cảnh, 54 sắc vật nương và cảnh sắc sinh diệt, và 11 danh pháp cũng sinh diệt. Hãy nhận diện những bản chất như vậy trong từng sát-na, theo từng nhóm sắc và danh…


<a id="M09-body-P048"></a>
## Luân phiên quán sắc danh và mở rộng sang ba thời
Miến / Burmese 48

… để thấy sự sinh diệt của chúng, rồi lần lượt quán một lượt là vô thường, một lượt là khổ, một lượt là vô ngã. Hãy quán theo từng xứ và môn. Hãy quán ở cả sáu môn. Hãy quán đầy đủ các lộ tốc hành thiện và các lộ tốc hành bất thiện theo các bảng trong phần đề mục thiền về danh. Quán đi quán lại, luân phiên một lượt bên trong, một lượt bên ngoài. Theo cách này, hãy quán —

1. riêng sắc

2. riêng danh

3. sắc và danh cùng nhau

Sau khi đã đặt ba đặc tính và quán luân phiên đi quán lại bên trong và bên ngoài, hãy tiếp tục quán minh sát theo cách tương tự từ tái tục đến tử: (1) riêng sắc, (2) riêng danh, (3) sắc và danh cùng nhau. Hãy quán chúng đúng như chúng đã sinh, đang sinh và sẽ sinh. Tương tự, tiếp tục quán minh sát từ tái tục đến tử theo phương pháp năm uẩn.

Quá khứ, hiện tại và vị lai

Khi đã quán xét nhiều lần và tương đối nhuần nhuyễn các sắc pháp và danh pháp từ tái tục đến tử, gọi là hiện tại theo một đời (addhāpaccuppanna), bằng phương pháp hai nhóm sắc danh hoặc phương pháp năm uẩn, hãy tiếp tục mở rộng tuệ minh sát đến sắc danh quá khứ, hiện tại và vị lai.

Aniccādivasena vividhehi ākārehi dhamme passatīti vipassanā. (အဘိ၊ဋ္ဌ၊၁၊၁၇၅။)

Vì thấy các hành theo những phương diện khác nhau, như vô thường, khổ, vô ngã v.v.…


<a id="M09-body-P049"></a>
## Đối tượng của minh sát qua các đời
Miến / Burmese 49

… nên gọi là minh sát. (အဘိ၊ဋ္ဌ၊၁၊၁၇၅။)

Theo các Đại Chú giải, chỉ sự tu tập và quán xét các hành chân đế bằng cách đặt ba đặc tính lên chúng mới được gọi là minh sát. Cần ghi nhớ rằng nếu hành giả chưa thấy đến mức sắc danh chân đế, chưa phân biệt chế định và chân đế, mà quán ghi nhận các khối chế định thô, thì việc ấy chưa thể gọi là minh sát.

Trong những đời quá khứ mà mình có thể phân định và quán được, hãy quán từ tái tục đến tử của đời ấy. Lại quán từ tái tục đến tử của một đời quá khứ tiếp theo, cho đến từ tái tục đến tử của đời quá khứ liền trước. Sau đó, quán từ tái tục đến tử của đời hiện tại. Kế đến, quán từ tái tục đến tử của đời vị lai thứ nhất, rồi nếu còn có đời vị lai, từ tái tục đến tử của đời vị lai thứ hai. Cứ như vậy, từ tái tục đến tử của những đời vị lai mình có thể quán được, hãy quán các pháp có mặt trong các đời ấy —

1. Đặt lần lượt ba đặc tính lên riêng sắc.

2. Đặt lần lượt ba đặc tính lên riêng danh.

3. Đặt lần lượt ba đặc tính lên sắc và danh cùng nhau.

Hãy quán minh sát như vậy nhiều lần, luân phiên qua lại. Quán một lượt bên trong rồi một lượt bên ngoài. Đối với người vẫn chưa hiểu rõ, cách quán sẽ được trình bày lại. Nếu người thiện đang học có thể phân định sắc, danh, nhân và quả, tức các hành, đến đời quá khứ thứ năm —


<a id="M09-body-P050"></a>
## Trình tự quán các đời và các uẩn
Miến / Burmese 50

1. Từ tái tục đến tử của đời quá khứ thứ năm.

2. Từ tái tục đến tử của đời quá khứ thứ tư.

3. Từ tái tục đến tử của đời quá khứ thứ ba.

4. Từ tái tục đến tử của đời quá khứ thứ hai.

5. Từ tái tục đến tử của đời quá khứ thứ nhất.

6. Từ tái tục đến tử của đời hiện tại. Nếu còn đời vị lai…

7. Từ tái tục đến tử của đời vị lai thứ nhất. Nếu còn đời vị lai nữa…

8. Từ tái tục đến tử của đời vị lai thứ hai.

Cứ như vậy, từ đời quá khứ xa nhất có thể phân định được đến đời hiện tại, rồi từ đời hiện tại đến đời vị lai cuối cùng —

1. riêng sắc

2. riêng danh

3. sắc và danh cùng nhau

Hãy chuyên cần quán minh sát bằng cách lần lượt đặt ba đặc tính lên chúng. Có khi quán bên trong, có khi quán bên ngoài, có khi quán luân phiên bên trong và bên ngoài. Tương tự, theo phương pháp năm uẩn —

1. riêng sắc

2. riêng thọ

3. riêng tưởng

4. riêng các tâm sở thuộc hành

5. riêng tâm biết, tức thức

Có khi quán là vô thường, có khi là khổ, có khi là vô ngã, luân phiên bên trong và bên ngoài. Hãy quán nhiều lần, lặp đi lặp lại, luân phiên qua lại…


<a id="M09-body-P051"></a>
## Quán đủ mười một phương diện và Kinh Vô ngã tướng
Miến / Burmese 51

… Khi quán như vậy —

1. Dù là sắc, thọ, tưởng, hành và thức thô (oḷārika).

2. Dù là sắc, thọ, tưởng, hành và thức tế (sukhuma).

3. Dù là sắc, thọ, tưởng, hành và thức hạ liệt (hīna).

4. Dù là sắc, thọ, tưởng, hành và thức thù thắng (paṇīta).

5. Dù là sắc, thọ, tưởng, hành và thức xa (dūra).

6. Dù là sắc, thọ, tưởng, hành và thức gần (santika).

Dù là sắc, thọ, tưởng, hành hay thức nào, hãy quán minh sát tất cả. Khi có thể quán như vậy, hành giả đã biết quán minh sát năm uẩn, tức sắc, thọ, tưởng, hành và thức, theo mười một phương diện: quá khứ, vị lai, hiện tại, bên trong, bên ngoài, thô, tế, hạ liệt, thù thắng, xa và gần. Khi ấy cũng đã biết cách quán theo Kinh Vô ngã tướng dưới đây.

Cách quán theo Kinh Vô ngã tướng

1. Tasmātiha bhikkhave yaṃ kiñci rūpaṃ atītānāgatapaccuppannaṃ ajjhattaṃ vā bahiddhā vā oḷārikaṃ vā sukhumaṃ vā hīnaṃ vā paṇītaṃ vā yaṃ dūre santike vā, sabbaṃ rūpaṃ “netaṃ mama, nesohamasmi, na meso attā”ti evametaṃ yathābhūtaṃ sammappaññāya daṭṭhabbaṃ.


<a id="M09-body-P052"></a>
## Mười một phương diện của sắc trong Kinh Vô ngã tướng
Miến / Burmese 52

2. Yā kāci vedanā. Pe.

3. Yā kāci saññā. Pe.

4. Ye keci saṅkhārā. Pe.

5. Yaṃ kiñci viññāṇaṃ. Pe. (သံ၊၂၊၅၆။)

“Netaṃ mama, nesohamasmi, na meso attā”ti samanupassāmīti aniccaṃ dukkhaṃ anattāti samanupassāmi. (မ၊၄၊၂၃၂။)

Này các Tỳ-khưu… vì năm uẩn là vô thường, khổ và vô ngã như vậy, nên trong Giáo pháp cao quý này, các thiện nam tử hãy quán —

1. Tất cả sắc pháp quá khứ.

2. Tất cả sắc pháp vị lai.

3. Tất cả sắc pháp hiện tại.

4. Tất cả sắc pháp bên trong.

5. Tất cả sắc pháp bên ngoài.

6. Tất cả sắc pháp thô (oḷārika).

7. Tất cả sắc pháp tế (sukhuma).

8. Tất cả sắc pháp hạ liệt (hīna).

9. Tất cả sắc pháp thù thắng (paṇīta).

10. Tất cả sắc pháp xa (dūra).

11. Tất cả sắc pháp gần (santika).

Đối với tất cả sắc pháp hiện hữu theo mười một phương diện ấy —

(a) Netaṃ mama — sắc pháp này không phải của ta, tức là khổ.

(b) Nesohamasmi — sắc pháp này không phải là ta, tức là vô thường.


<a id="M09-body-P053"></a>
## Quán sắc không phải của ta, không phải là ta, không phải tự ngã của ta
Miến / Burmese 53

(c) Na meso attā — sắc pháp này không phải tự ngã của ta, tức là vô ngã.

Như vậy hãy quán bằng ánh sáng của tuệ minh sát, đúng như thật, không đảo ngược, các sắc pháp hiện hữu theo mười một phương diện ấy, phá vỡ và xuyên thấu các khối kết chặt của sắc và danh.

Nếu diễn nghĩa theo cách khác thì như sau —

Này các Tỳ-khưu… vì năm uẩn là vô thường, khổ và vô ngã như vậy, nên trong Giáo pháp cao quý này, các thiện nam tử hãy quán —

1. Dù là sắc pháp quá khứ.

2. Dù là sắc pháp vị lai.

3. Dù là sắc pháp hiện tại.

4. Dù là sắc pháp bên trong.

5. Dù là sắc pháp bên ngoài.

6. Dù là sắc pháp thô (oḷārika).

7. Dù là sắc pháp tế (sukhuma).

8. Dù là sắc pháp hạ liệt (hīna).

9. Dù là sắc pháp thù thắng (paṇīta).

10. Dù là sắc pháp xa (dūra).

11. Dù là sắc pháp gần (santika).

Đối với tất cả sắc pháp hiện hữu theo mười một phương diện ấy —

(a) Netaṃ mama — sắc pháp này không phải của ta, tức là khổ.

(b) Nesohamasmi — sắc pháp này không phải là ta, tức là vô thường.

(c) Na meso attā — sắc pháp này không phải tự ngã của ta…


<a id="M09-body-P054"></a>
## Sắc và danh thô, tế, hạ liệt, thù thắng, xa và gần
Miến / Burmese 54

… tức là vô ngã.

Như vậy hãy quán bằng ánh sáng của tuệ minh sát, đúng như thật, không đảo ngược, các sắc pháp hiện hữu theo mười một phương diện ấy, phá vỡ và xuyên thấu các khối kết chặt của sắc và danh. (သံ၊၂၊၅၆။)

Hãy quán tương tự đối với bốn danh uẩn là thọ, tưởng, hành và thức. Hãy hiểu phần diễn nghĩa theo cùng cách.

Thô và tế, hạ liệt và thù thắng, xa và gần

Khi quán như vậy, nếu muốn phân chia sắc và danh theo thô, tế v.v. để quán, cũng có thể quán như sau.

1. Mười hai sắc, gồm năm sắc tịnh sắc (pasādarūpa) và bảy sắc cảnh giới (gocararūpa), gọi là sắc thô vì dễ hiện rõ và dễ thấy đối với trí của hành giả đang quán, nên được xem là thô.

2. Mười sáu sắc còn lại gọi là sắc tế vì khó hiện rõ và khó thấy đối với trí của hành giả đang quán, nên được xem là vi tế.

3. Trong các danh pháp, thọ, tưởng, hành và thức bất thiện được gọi là thô vì dễ hiện rõ và dễ thấy đối với trí của hành giả đang quán.

4. Thọ, tưởng, hành và thức thiện, cũng như các danh pháp ở hướng ngũ môn, ngũ thức, tiếp thọ, quan sát, xác định, đăng ký, hướng ý môn, đăng ký…


<a id="M09-body-P055"></a>
## Danh pháp tế và các phân loại hạ liệt, thù thắng, xa, gần
Miến / Burmese 55

… tái tục, hữu phần, tử và tốc hành duy tác v.v., tức thọ, tưởng, hành và thức thuộc quả và duy tác, gọi chung là vô ký, được gọi là tế vì khó hiện rõ và khó thấy đối với trí của hành giả đang quán. (Các cách phân loại còn lại xin xem Chú giải Thanh tịnh đạo, quyển hai, trang 104–105 v.v.)

5. Sắc pháp do nghiệp bất thiện sinh là hạ liệt.

6. Sắc pháp do nghiệp thiện sinh là thù thắng.

7. Danh pháp thô là hạ liệt.

8. Danh pháp tế là thù thắng.

9. Sắc tế khó hiện rõ và khó thấy đối với trí của hành giả đang quán. Do xa trí ấy, chúng được gọi là xa.

10. Sắc thô dễ hiện rõ và dễ thấy đối với trí của hành giả đang quán. Do gần trí ấy, chúng được gọi là gần.

11. Thọ, tưởng, hành và thức bất thiện gọi là xa vì xa thọ, tưởng, hành và thức quả và duy tác, tức vô ký, và cũng xa thọ, tưởng, hành và thức thiện. Tương tự, thọ, tưởng, hành và thức thiện và vô ký gọi là xa vì xa thọ, tưởng, hành và thức bất thiện.

12. Thọ, tưởng, hành và thức bất thiện gọi là gần vì gần thọ, tưởng, hành và thức bất thiện. Tương tự, thọ, tưởng, hành và thức thiện và vô ký gọi là gần vì gần thọ, tưởng, hành và thức thiện và vô ký.


<a id="M09-body-P056"></a>
## Quán gồm đủ các loại sắc danh
Miến / Burmese 56

Các pháp được gọi bằng những tên riêng như vậy. Về những cách phân biệt khác, hãy xem Thanh tịnh đạo, quyển hai, trang 106–107.

Đối với các pháp hiện hữu trong ba thời quá khứ, vị lai, hiện tại và trong hai dòng tương tục bên trong và bên ngoài —

1. Các sắc pháp có mặt trong sáu môn và bốn mươi hai phần thân.

2. Các nhóm danh pháp trong lộ tốc hành thiện và lộ tốc hành bất thiện, cùng các nhóm danh pháp ngoài lộ là tái tục, hữu phần và tử.

Nếu có thể chia chúng thành hai nhóm theo phương pháp sắc danh, hoặc thành năm nhóm theo phương pháp năm uẩn, và quán minh sát xuyên suốt từ quá khứ đến hiện tại, từ hiện tại đến cuối vị lai, thì trong những sắc danh ấy đã bao gồm cả sắc danh thô, tế, hạ liệt, thù thắng, xa và gần, không còn sót. Do đó, như đã trình bày ở trên —

1. riêng sắc

2. riêng danh

3. sắc và danh cùng nhau

Cũng có thể quán minh sát theo phương pháp hai nhóm sắc danh như vậy. Chẳng hạn, hai vợ chồng bà Bà-la-môn Pañcaggadāyikā chia các hành thành hai nhóm sắc và danh, rồi quán xét bằng minh sát theo phương pháp hai nhóm ấy và an lập trong đạo và quả Bất lai. (ဓမ္မပဒဋ္ဌ၊၂၊၃၆၉။)

Lại nữa, nếu chia sắc danh ấy thành năm nhóm theo phương pháp năm uẩn và quán minh sát, thì như các vị trưởng lão có tên trong nhóm năm vị được nhắc đến trong Kinh Vô ngã tướng…


<a id="M09-body-P057"></a>
## Tu tập bất tịnh và bất tịnh ở thân sống
Miến / Burmese 57

… có thể đạt đến quả A-la-hán. (သံ၊၂၊၅၅။)

Nếu có khả năng, việc quán riêng sắc và danh thô, tế, hạ liệt, thù thắng, xa và gần trong cả ba thời quá khứ, vị lai, hiện tại và trong cả hai dòng tương tục bên trong và bên ngoài thì càng tốt.

Tu tập bất tịnh (asubhabhāvanā)

Trong Kinh Girimānanda (အံ၊၃၊၃၄၃), Đức Phật dạy nỗ lực tu tập tưởng bất tịnh (asubhasaññā). Savijjāṇaka-asubha là tu tập bất tịnh ở thân sống. Trong Kinh Meghiya, Ngài cũng dạy “asubhā bhāvetabbā rāgassa pahānāya”, tức hãy nỗ lực tu tập bất tịnh để đoạn trừ tham. (ဥဒါန၊၁၂၀။) Trong Kinh Vijaya (သုတ္တနိပါတ၊၃၀၇-၃၀၈), Đức Phật dạy tu tập savijjāṇaka-asubha, bất tịnh ở thân sống, và avijjāṇaka-asubha, bất tịnh ở xác chết. Tu tập bất tịnh ấy chính là nền tảng của quán khổ (dukkhānupassanā).

Bất tịnh ở thân sống (savijjāṇaka-asubha)

Khi lấy tính chất bất tịnh đáng ghê tởm của ba mươi hai phần thân hiện hữu trong dòng tương tục của các chúng sinh còn sống làm cảnh và tác ý tu tập bất tịnh, có hai cách quán. Một là quán để đạt thiền theo phương pháp tác ý tính đáng ghê tởm (paṭikkūlamanasikāra). Hai là quán để thấy tính bất tịnh, bất lợi của căn nhà thân uẩn, gọi là quán sự nguy hại (ādīnavānupassanā). Đối với ba mươi hai phần thân có mặt trong dòng tương tục bên trong, có thể lấy cả ba mươi hai phần, một số phần, hoặc từng phần riêng lẻ làm cảnh và tác ý tính đáng ghê tởm…


<a id="M09-body-P058"></a>
## Từ ba mươi hai phần thân đến các nhóm sắc
Miến / Burmese 58

… tức tính chất đáng ghê tởm, thì có thể đạt định sơ thiền. Tương tự, nếu tác ý đến các phần thân bên ngoài, có thể đạt cận định. Điều này đã được giải thích ở phần trước. Ở đây chỉ trình bày cách quán sắc trong ba mươi hai phần thân ấy theo quán sự nguy hại —

Lấy tính đáng ghê tởm của ba mươi hai phần thân làm cảnh và quán “bất tịnh, bất tịnh”. Dùng tuệ thấy rõ tính bất tịnh đáng ghê tởm. Quán đi quán lại, luân phiên trong cả hai dòng tương tục bên trong và bên ngoài. Hãy mở rộng dần phạm vi quán tùy khả năng.

Khi ấy, do năng lực của tuệ đã được rèn luyện mạnh trong lĩnh vực sắc và danh chân đế, có khi đang quán luân phiên tính bất tịnh đáng ghê tởm của ba mươi hai phần thân trong cả hai dòng tương tục bên trong và bên ngoài thì chẳng bao lâu ba mươi hai phần thân biến mất, chỉ thấy những hạt nhóm sắc. Điều ấy là do năng lực của tuệ đã được rèn luyện trong lĩnh vực chân đế. Nếu khi quán luân phiên tính bất tịnh của ba mươi hai phần thân trong cả hai dòng tương tục mà các hạt nhóm sắc chưa dễ hiện ra, hãy quán các phần thân ấy riêng từng phần hay gộp chung, hướng sự quán đến chỗ thấy bốn đại có mặt trong các phần thân ấy. Do năng lực của tuệ tu tập đã được rèn luyện, sẽ dễ dàng thấy những hạt nhóm sắc. Khi thấy các nhóm sắc, hãy phân tích chúng bằng trí đến mức chân đế, như đã trình bày trong phần đề mục thiền về sắc. Rồi hãy tiếp tục quán minh sát các sắc chân đế ấy bằng cách lần lượt đặt lên chúng ba đặc tính.


<a id="M09-body-P059"></a>
## Căn nhà thân uẩn đầy các loài trùng
Miến / Burmese 59

Quán luân phiên bên trong và bên ngoài. Khi đã tương đối nhuần nhuyễn trong việc tu tập bất tịnh theo cách ấy, hãy phân định bốn đại trong từng phần thân và quán minh sát các sắc chân đế trong từng nhóm sắc.

Căn nhà thân uẩn đầy các loài trùng

Lại nữa, một phương pháp quán bất tịnh ở thân sống (savijjāṇaka-asubha) được trình bày trong Kinh Pheṇapiṇḍūpama và Chú giải của kinh ấy. Căn nhà thân uẩn lớn này đầy các loài trùng. Căn nhà thân uẩn này là chỗ cư trú và sinh sản của nhiều loài trùng, là chỗ chúng thải phân, thải nước tiểu, là bệnh xá và là nghĩa địa của chúng. Hãy lấy tính chất đáng ghê tởm của căn nhà thân uẩn đầy những vật bất tịnh, đáng ghê tởm ấy làm cảnh, rồi quán “bất tịnh, bất tịnh”. Quán luân phiên, đi quán lại bên trong và bên ngoài. (သံ၊ဋ္ဌ၊၂၊၂၉၄။)

Khi đã quán nhiều lần như vậy, do năng lực của tuệ đã được rèn luyện trong lĩnh vực chân đế, chẳng bao lâu có thể thấy các nhóm sắc. Lúc ấy, hãy phân định các sắc pháp chân đế có trong những nhóm sắc ấy, rồi đặt ba đặc tính lên các sắc chân đế ấy và quán minh sát một lần nữa. Nếu các nhóm sắc chưa dễ hiện ra nhưng việc tu tập bất tịnh ấy đã tương đối nhuần nhuyễn, hãy lấy các loài trùng hoặc căn nhà thân uẩn lớn đầy các loài trùng làm cảnh, rồi bắt đầu phân định bốn đại trong các loài trùng hoặc…


<a id="M09-body-P060"></a>
## Tính bất tịnh của sắc chân đế
Miến / Burmese 60

… trong căn nhà thân uẩn đầy các loài trùng ấy. Do năng lực của tuệ đã được rèn luyện trong lĩnh vực chân đế, chẳng bao lâu có thể thấy các nhóm sắc. Hãy phân định các sắc chân đế trong những nhóm sắc ấy và quán minh sát một lần nữa. Hãy quán cả bên trong lẫn bên ngoài.

Trong các sắc pháp chân đế cũng có —

1. Duggandha — có mùi hôi.

2. Asuci — bất tịnh, có tính đáng ghê tởm.

3. Byādhi — có tính bệnh hoạn.

4. Jarā — có sự già cỗi, tức có thời kỳ chín muồi.

5. Maraṇa — có sự chết và tan hoại, tức có thời kỳ tan hoại. (သံ၊ဋ္ဌ၊၃၊၅၉။ သံ၊ဋ္ဌ၊၂၊၂၉၄။)

Những tính bất tịnh này hiện hữu rõ ràng. Hãy dùng tuệ minh sát để thấy tính bất tịnh ấy rồi quán “bất tịnh, bất tịnh”. Hãy quán luân phiên một lượt bên trong, một lượt bên ngoài.

Như vậy, đối với bất tịnh ở thân sống (savijjāṇaka-asubha), hãy phân chia và quán ba loại tính bất tịnh —

1. Tính bất tịnh đáng ghê tởm của ba mươi hai phần thân.

2. Tính bất tịnh đáng ghê tởm của căn nhà thân uẩn đầy các loài trùng.

3. Tính bất tịnh đáng ghê tởm của các sắc pháp chân đế.


<a id="M09-body-P061"></a>
## Bất tịnh ngoài thân và bất tịnh của tử thi
Miến / Burmese 61

Puna caparaṃ, bhikkhave, bhikkhu seyyathāpi passeyya sarīraṃ sivathikāya chaḍḍitaṃ ekāhamataṃ vā dvīhamataṃ vā tīhamataṃ vā uddhumātakaṃ vinīlakaṃ vipubbakajātaṃ. So imameva kāyaṃ upasaṃharati: “Ayampi kho kāyo evaṃdhammo evaṃbhāvī evaṃanatīto”ti. (Dī. 2.235.)

Này các tỳ-khưu, lại nữa, nếu vị tỳ-khưu hành thiền thấy một tử thi bị bỏ tại bãi tha ma, chết đã một ngày, hai ngày hay ba ngày, trương phồng, biến sắc xanh tím, chảy mủ nhớp nhúa, vị ấy lấy trí đối chiếu ngay thân mình: “Thân này của ta cũng có tính chất như thế, sẽ thành như thế, không vượt khỏi tính chất ấy.” (Dī. 2.235, Mahāsatipaṭṭhānasutta.)

Dīyabhāṇakamahāsivatthero pana “navasivathikā ādīnavānupassanāvasena vuttā”ti āha. (Dī. A. 2.394, Maj. A. 1.305.)

Trưởng lão A-la-hán Mahāsiva, vị thông thuộc Dīghanikāya, nói rằng Đức Phật đã dạy chín phép tu bất tịnh liên hệ đến bãi tha ma theo cách quán sự nguy hại (ādīnavānupassanā). (Dī. A. 2.394, Maj. A. 1.305.)

Theo chính văn Pāli và chú giải trên, hành giả muốn tu bất tịnh ngoài thân phải chọn một tử thi…


<a id="M09-body-P062"></a>
## Bất tịnh ngoài thân và bất tịnh của tử thi
Miến / Burmese 62

…để quán. Khi tu bất tịnh theo thiền chỉ đến định sơ thiền, nam hành giả phải quán tử thi nam, nữ hành giả phải quán tử thi nữ. Trong phần minh sát này, khi quán sự nguy hại, không cần lựa chọn tử thi nam hay nữ. Cùng giới hay khác giới đều được. Trong thiền chỉ, hành giả chuyên chú vào tử thi bên ngoài cho đến sơ thiền. Khi đạt tợ tướng, tham ái có thể xen vào và làm rối loạn, nên chỉ tu với tử thi cùng giới.

Quán sự nguy hại (ādīnavānupassanā). Trong phần minh sát này, hành giả quán để thấy khuyết điểm của năm uẩn nơi mình và người khác. Vì quán qua lại giữa nội phần và ngoại phần, và vì quán sự nguy hại là phương pháp quán để thấy khuyết điểm, hành giả có thể lấy bất cứ tử thi bất tịnh nào mà mình có thể nắm được tướng, dù cùng giới hay khác giới.

Trong Vijayasutta (Suttanipāta 307–308) có lời chỉ dạy bốn hội chúng, gồm tỳ-khưu, tỳ-khưu-ni, nam cư sĩ và nữ cư sĩ, tu bất tịnh dựa trên tử thi của Sirimā. Trong thiền chỉ, hành giả phải chuyên chú duy nhất vào tử thi bên ngoài, đặc biệt chỉ một tử thi, cho đến khi đạt thiền. Trong minh sát, hành giả quán qua lại nội và ngoại để thấy khuyết điểm và nguy hại. Đó là sự khác nhau giữa tu bất tịnh theo thiền chỉ và theo minh sát.


<a id="M09-body-P063"></a>
## Cách quán
Miến / Burmese 63

Khi có thể quán minh sát sắc pháp và danh pháp, tức năm uẩn, trong ba thời quá khứ, vị lai, hiện tại, và trong hai dòng tương tục nội và ngoại, luân phiên đặt chúng dưới ba đặc tướng, ánh sáng rực rỡ sẽ lóe chiếu do trí minh sát của thiện nhân đang tu minh sát. Hoặc nếu khi ngồi thiền, hành giả tái lập định tứ thiền mình đã đạt, ánh sáng rực rỡ cũng sẽ lóe chiếu do trí tương ưng với định tứ thiền đó. Bởi lẽ cơ hội quán bất tịnh ngoài thân, tức bất tịnh của tử thi, đã đến sau khi từng bước thiết lập định và từng bước tiến qua minh sát. Nếu ánh sáng của trí ấy hơi mờ và yếu, hãy tái lập định từng bước. Khi ánh sáng do trí đi cùng định ấy lại rực lên, lóe chiếu, có thể quán bất tịnh ngoài thân.

Khi ánh sáng lóe chiếu rực rỡ nhờ trí thiền chỉ hoặc trí minh sát, dùng ánh sáng của trí ấy hướng đến một tử thi mình từng thấy và còn nhớ rõ. Như rọi đèn pin, hãy rọi ánh sáng của trí ấy vào tử thi rồi quán. Tính bất tịnh ghê tởm, nhớp nhúa sẽ hiện rõ trong trí. Nếu là tử thi trương phồng, rỉ mủ…


<a id="M09-body-P064"></a>
## Cách quán
Miến / Burmese 64

…thì rất tốt. Hãy tác ý tính bất tịnh ghê tởm, nhớp nhúa ấy và quán tử thi: “Bất tịnh, bất tịnh.” Khi tướng bất tịnh hiện rõ trong trí và tâm tu tập an trú vững trên cảnh bất tịnh ấy, lại dùng trí hướng về thân mình và quán. Thấy bằng trí rằng chính thân mình cũng đang chết, trương phồng và bất tịnh như tử thi bên ngoài ấy. Khi thấy tướng tử thi của mình trương phồng, nhớp nhúa, hãy quán: “Bất tịnh, bất tịnh.”

Nếu đã hướng trí quán mà tướng bất tịnh nơi mình vẫn không hiện, hãy trở lại quán bất tịnh bên ngoài, rồi quay về quán bên trong. Thực tập như thế nhiều lần, có thể thấy tướng bất tịnh bên trong. Nếu vẫn chưa thấy, hãy hướng trí từ hiện tại về tương lai và quán dần từng bước. Khi ấy sẽ dễ thấy tính bất tịnh của thân mình lúc chết. Cách quán này sẽ dễ đối với hành giả đã quán được tính liên hệ nhân quả giữa nhân hiện tại và quả tương lai, tức các pháp duyên khởi.

Khi thấy tính bất tịnh của thân mình bằng trí, tức bằng ánh sáng của trí, hãy quán nội rồi ngoại luân phiên: “Bất tịnh, bất tịnh.” Khi quán như thế, hãy dần mở rộng sang những người mà mình từng tham ái hoặc đang tham ái và quán qua lại nội và ngoại: “Bất tịnh.”


<a id="M09-body-P065"></a>
## Cách quán
Miến / Burmese 65

Khi đã quán nhiều lần “Bất tịnh, bất tịnh” cả nội lẫn ngoại, do sức minh sát đã tu trước đây hoặc do đã thực hành nhiều trong lĩnh vực chân đế, hành giả có thể thấy các nhóm sắc trong những tử thi nội và ngoại. Hoặc các tử thi bất tịnh có thể dần tan rã và hiện trong trí dưới dạng đống xương hay đống bột xương. Nếu dần hướng trí đến tương lai của tử thi ấy thì trí có thể thấy đến lúc chỉ còn xương, đống xương hoặc bột xương. Ở bất cứ giai đoạn nào cũng quán “Bất tịnh, bất tịnh.” Nếu dễ dàng tìm thấy các hạt nhóm sắc, hãy nhận diện sắc pháp chân đế trong các nhóm sắc ấy, đặc biệt sắc do thời tiết sinh, rồi đặt chúng dưới các đặc tướng và quán minh sát.

Nếu chưa dễ thấy các hạt nhóm sắc, hãy bắt đầu nhận diện bốn đại trong các tử thi bất tịnh nội và ngoại ấy. Khi đó sẽ bắt đầu thấy những nhóm sắc trong các tử thi ấy. Phân tích các hạt nhóm sắc ấy thành các giới thì có thể thấy những nhóm tám sắc do thời tiết sinh nối tiếp phát sinh do hỏa giới có trong từng nhóm sắc. Hãy nhận diện các sắc pháp ấy rồi tiếp tục quán minh sát. Chuyển từ tu bất tịnh sang minh sát theo cách này khi đã tu bất tịnh đến mức thuần thục thích hợp.


<a id="M09-body-P066"></a>
## Một điểm đặc biệt và các chi duyên khởi
Miến / Burmese 66

Nếu tử thi mà hành giả hướng trí lấy làm cảnh vẫn đang ở giai đoạn bị giòi ăn, khi một số hành giả dùng trí nhận diện bốn đại trong tử thi ấy, ngoài các nhóm tám sắc do thời tiết sinh, họ còn thấy các nhóm sắc trong và đục khác nhau, một số có sắc thần kinh (pasādarūpa). Đó là vì hành giả thấy xen lẫn cả các nhóm sắc của giòi sống bám trên tử thi. Các sắc thần kinh trong suốt và sắc pháp do bốn nguồn sinh mà hành giả thấy thuộc về những con giòi ấy.

Khi thấy các nhóm sắc trong các tử thi nội và ngoại, hãy phân tích các nhóm sắc ấy thành các giới, đặt sắc pháp chân đế dưới các đặc tướng và quán minh sát nhiều lần.

Các chi duyên khởi. Dựa vào Paṭisambhidāmagga, Visuddhimagga, quyển hai, trang 244, trong phần trí thẩm sát (sammasanañāṇa), liệt kê các chi duyên khởi trong những đối tượng của trí minh sát thẩm sát các đặc tướng (lakkhaṇasammasana). Do đó hành giả cũng phải quán minh sát các chi duyên khởi.


<a id="M09-body-P067"></a>
## Các chi duyên khởi
Miến / Burmese 67

Thiện nhân hãy nhớ lại cách đã nhận diện nhân và quả theo lời dạy duyên khởi thuận: “Avijjāpaccayā saṅkhārā — do vô minh làm duyên, các hành sinh khởi,” v.v. Rồi quán minh sát các chi ấy theo đúng cách đã nhận diện chúng.

Nếu lấy đời hiện tại làm trung tâm: (1) vô minh và các hành thuộc quá khứ; (2) thức, danh-sắc, sáu xứ, xúc, thọ, ái, thủ và hữu thuộc hiện tại; (3) sinh, già và chết thuộc vị lai.

Nếu lấy đời quá khứ thứ nhất làm trung tâm: (1) vô minh và các hành thuộc đời quá khứ thứ hai; (2) thức, danh-sắc, sáu xứ, xúc, thọ, ái, thủ và hữu thuộc đời quá khứ thứ nhất; (3) sinh, già và chết thuộc hiện tại.

Nếu lấy đời vị lai thứ nhất làm trung tâm: (1) vô minh và các hành thuộc hiện tại; (2) thức, danh-sắc, sáu xứ, xúc, thọ, ái, thủ và hữu thuộc đời vị lai thứ nhất; (3) sinh, già và chết thuộc đời vị lai thứ hai.

Tương tự như thế, hãy hiểu lần lượt các đời quá khứ và vị lai. Mỗi lần liên hệ ba đời theo nhân quả, rồi quán lặp lại.


<a id="M09-body-P068"></a>
## Một số cách quán
Miến / Burmese 68

1. Do vô minh sinh khởi, các hành sinh khởi. Vô minh (sinh–diệt) là vô thường. Các hành (sinh–diệt) là vô thường.

Hãy quán vô minh và các hành đã sinh, đang sinh và sẽ sinh trong dòng danh-sắc của mình theo cách đã nhận diện ở phương pháp duyên khởi thứ nhất. Ở đây, vô minh thường thuộc các lộ tâm qua ý môn nhóm tham đi cùng tà kiến. Các hành có thể là hành thiện hay hành bất thiện, cũng thuộc các lộ tâm qua ý môn. Đối với thiện nhân, nếu chỉ xét riêng đời hiện tại này, các hành được vun bồi trong đời quá khứ là hành thiện. Hãy quán chúng đúng như chúng đã sinh khởi trong đời ấy, theo sinh và diệt. Cũng quán tương tự theo đặc tướng khổ và vô ngã.

2. Do các hành sinh khởi, thức tái tục sinh khởi. Các hành (sinh–diệt) là vô thường. Thức tái tục (sinh–diệt) là vô thường.

Tương tự, hãy quán hết các thức quả, gồm mọi tâm qua sáu môn như nhãn thức, v.v., cùng thức hữu phần và thức tử. Với các chi duyên khởi còn lại cũng quán đến sinh, già và chết theo cách đã nhận diện nhân và quả trong phương pháp duyên khởi thứ nhất. Quán minh sát cả nhân lẫn quả, luân phiên đặt từng loại dưới ba đặc tướng.

Theo cách trình bày của Kinh, chỉ các pháp quả trong thức, danh-sắc, sáu xứ, xúc và thọ được nhắm đến (Mahāṭī. 2.323). Tuy vậy, chỉ khi quán quan hệ nhân quả giữa nhân và quả…


<a id="M09-body-P069"></a>
## Bốn mươi cách quán theo đuôi -to
Miến / Burmese 69

…mới chỉ quán các pháp quả ấy. Khi quán minh sát, nếu theo cách tu đầy đủ mà quán chung cả hướng tâm ngũ môn, xác định, tốc hành, hướng tâm ý môn và tốc hành trong một lộ tâm, cũng không có lỗi, vì nhằm không bỏ sót các giới chân đế. Hãy quán từ các đời quá khứ nối tiếp cho đến tận vị lai, trong phạm vi có thể quán được. Luân phiên quán nội và ngoại. Khi quán ngoại, hãy quán chung, tránh phân biệt từng cá nhân hay chúng sinh.

Trong phần thẩm sát đặc tướng này, Visuddhimagga (2.246) trình bày bốn mươi cách tu hay bốn mươi cách quán theo đuôi -to, dẫn Paṭisambhidāmagga (411). Để dễ ghi nhớ, Đại trưởng lão Mahāvisuddhārāma soạn kệ trong Paramatthasarūpabhedanī, phân riêng mười mục về đặc tướng vô thường, hai mươi lăm mục về đặc tướng khổ và năm mục về đặc tướng vô ngã. Dưới đây trình bày ba đặc tướng thành ba nhóm theo các bài kệ ấy.

Đặc tướng vô thường: mười mục. Rūpaṃ aniccaṃ palokaṃ, calaṃ pabhaṅgu addhuvaṃ; vipariṇāmaṃ asārakaṃ, vibhavaṃ maccu saṅkhataṃ.

1. Aniccato — là vô thường. Anaccantikatāya ādiantavantatāya ca aniccato. (Visuddhi. 2.247.)


<a id="M09-body-P070"></a>
## 1. Là vô thường
Miến / Burmese 70

Anaccantikatāyāti accantikatābhāvato, asassatattātipi attho. Sassatā hi accantikā, pariyāyakoṭiyā abhāvato. (Mahāṭī. 2.394.)

[Danh và sắc có hai đầu mút: đầu trước là sinh, đầu sau là diệt. Chúng được gọi là sát-na sinh và sát-na diệt. Danh và sắc không thường hằng để có thể vượt qua đầu sau, tức sát-na diệt. Vì không vượt qua được đầu sau là sát-na diệt và vì có đầu trước là sát-na sinh và đầu sau là sát-na diệt, chúng là các pháp vô thường.

Hãy quán thành năm nhóm theo năm uẩn: sắc, thọ, tưởng, hành và thức. Dùng trí minh sát thấy rõ đặc tính không kéo dài đã nói trên nơi sắc pháp (thọ pháp, tưởng pháp, hành pháp và thức pháp), rồi quán là vô thường.

Nói ở đây rằng chúng không vượt khỏi sát-na sinh có nghĩa là sắc pháp và danh pháp chưa hề có trước khi đến sát-na sinh, cũng chẳng có trạng thái chờ sẵn để sinh. Sau thời diệt, chúng cũng không đi đâu để nằm chồng chất như những tử thi bị bỏ ở một nơi. Chỉ giữa hai sự “không có”, tức không có trước khi sinh và không có sau khi đã sinh, chúng mới xuất hiện trong chốc lát theo các sát-na sinh, trụ, diệt. Danh và sắc được gọi là vô thường vì chúng không tồn tại vượt ngoài sát-na sinh và sát-na diệt, và vì chúng có hai giới hạn ấy.] Vì vậy, hãy quán “aniccaṃ”: có tính chất không bền, là vô thường.


<a id="M09-body-P071"></a>
## 2–4. Là tan rã, dao động và dễ vỡ
Miến / Burmese 71

2. Palokato — là tan rã. Byādhijarāmaraṇehi palujjanatāya palokato. (Visuddhi. 2.247.) Do bệnh, già và chết, chúng đổ vỡ, rạn nứt và hoại diệt, nên có tính chất tan rã hoàn toàn. Hãy quán “palokaṃ”: có tính chất tan rã.

3. Calato — là dao động. Byādhijarāmaraṇehi ceva lābhālābhādīhi ca lokadhammehi pacalitatāya calato. (Visuddhi. 2.247.)

Lokadhammā lābhādihetukā anunayapaṭighā. Tehi, byādhiādīhi ca anavaṭṭhitatā pacalitatā. (Mahāṭī. 2.396.)

Yêu và ghét có nguyên nhân là các pháp thế gian như được lợi và mất lợi. Do các pháp thế gian ấy, những xao động của tâm như yêu và ghét nổi lên. Do bệnh, già và chết, cũng như do được lợi, mất lợi và các pháp thế gian khác, danh-sắc không ổn định và dao động theo nhiều cách. Hãy quán “calaṃ”: không ổn định, lay động và dao động.

4. Pabhaṅguto — là dễ vỡ. Upakkamena ceva sarasena ca pabhaṅgupagamanasīlatāya pabhaṅguto. (Visuddhi. 2.247.)


<a id="M09-body-P072"></a>
## 4–6. Là dễ vỡ, không bền và có tính biến đổi
Miến / Burmese 72

Do tác động của chính mình, tác động của người khác hoặc do bản tính của chúng, các pháp thường đi đến vỡ vụn và hư hoại. Pabhaṅgu: có tính chất dễ vỡ vụn và hư hoại.

5. Addhuvato — là không bền. Sabbāvatthānipātitāya, thirabhāvassa ca abhāvato addhuvato. (Visuddhi. 2.247.)

Như trái cây rụng bất chợt khi chưa đến lúc, các pháp có tính rơi rụng ở mọi giai đoạn của đời sống, như tuổi thơ non nớt và tuổi vui đùa. Ngay cả khi chưa rơi rụng, do mọi duyên tác động, chúng cũng thiếu sự bền chắc để có thể tồn tại lâu dài. Addhuvaṃ: không có tính bền chắc.

6. Vipariṇāmadhammato — là có tính biến đổi. Jarāya ceva maraṇena cāti dvedhā pariṇāmapakatitāya vipariṇāmadhammato. (Visuddhi. 2.247.)

Chúng có tính biến đổi qua hai hiện tượng: già (jarā), tức thời trụ, và chết (maraṇa), tức thời diệt. Vipariṇāmaṃ: có tính biến đổi. Ý nói sự chuyển sang già, có tính trụ, và sang chết, có tính diệt, sau giai đoạn sinh.


<a id="M09-body-P073"></a>
## 7–10. Là không có lõi, tiêu hoại, phải chết và hữu vi
Miến / Burmese 73

7. Asārakato — là không có lõi. Dubbalatāya, pheggu viya sukhabhañjanīyatāya ca asārakato. (Visuddhi. 2.247.) Vì yếu ớt và tự nhiên hư hoại, và vì dễ gãy như gỗ giác, asārakaṃ: không có lõi bền chắc.

8. Vibhavato — là tiêu hoại. Vigatabhavatāya, vibhavasambhūtatāya ca vibhavato. (Visuddhi. 2.248.)

Đã sinh thì chúng phải hoại và chấm dứt, nên không có sự lớn thêm, tăng thêm hay sinh sôi. Chúng cũng xuất hiện do ái đối với phi hữu (vibhavataṇhā) và kiến chấp phi hữu (vibhavadiṭṭhi), vốn hướng đến tiêu hoại và mất đi, như có ái và kiến làm cha sinh ra. Vibhavaṃ: có tính tiêu mất.

9. Maraṇadhammato, tức maccu — là phải chết. Maraṇapakatitāya maraṇadhammato. (Visuddhi. 2.248.) Vì có tính chết, tức tính hoại diệt, maraṇadhammaṃ hay maccu: có tính chết, tức có tính hoại diệt.

10. Saṅkhatato — là hữu vi. Hetupaccayehi abhisaṅkhatatāya saṅkhatato. (Visuddhi. 2.248.) Vì các nhân trực tiếp làm sinh khởi, tức các nhân sản sinh…


<a id="M09-body-P074"></a>
## 10. Là hữu vi
Miến / Burmese 74

…và các nhân tăng cường, hỗ trợ, tức các duyên, cùng nhau tạo tác, saṅkhataṃ có tính được các nhân tạo tác lặp đi lặp lại.

Những nguyên nhân trực tiếp sinh sắc pháp ở đây là nghiệp, tức nhân sản sinh, nhân trực tiếp. Những nhân thuộc vòng phiền não, tức vô minh, ái và thủ, là những nhân hỗ trợ, tăng cường cho nghiệp quá khứ ấy. Các phiền não trong vòng này trợ nghiệp thiện bằng các năng lực duyên như cận y duyên. Chúng trợ nghiệp bất thiện bằng các năng lực duyên như cận y duyên, cũng như bằng các duyên như câu sinh duyên.

Tâm, thời tiết và vật thực cũng là những nhân hỗ trợ, tăng cường cho sắc pháp. Tâm, thời tiết và vật thực trực tiếp làm sinh một số sắc do tâm, thời tiết và vật thực sinh, và hỗ trợ một số sắc khác. Tuy vậy, cách chúng làm sinh sắc khác với cách năng lực nghiệp làm sinh sắc do nghiệp sinh. Tâm trợ sắc do tâm sinh bằng các năng lực như câu sinh. Thời tiết trợ sắc do thời tiết sinh bằng các năng lực như cận y. Vật thực trợ sắc do vật thực sinh bằng các năng lực như vật thực duyên. Vì vậy, hãy ghi nhận rằng các nhân ấy được gọi là nhân hỗ trợ vì chúng không phải năng lực nghiệp, vốn được gọi là nhân sản sinh.

Nhân trực tiếp, nhân sản sinh của các danh pháp quả là nghiệp. Hãy hiểu các nhân thuộc vòng phiền não, tức vô minh, ái và thủ, theo cùng cách đã nói về sắc. Các nhân hiện tại của mọi danh pháp thiện, bất thiện và vô ký…


<a id="M09-body-P075"></a>
## Đặc tướng khổ: hai mươi lăm mục
Miến / Burmese 75

…như vật, cảnh và xúc, cần được hiểu là những nhân hỗ trợ.

Dùng trí thấy rõ các tính chất trên nơi sắc pháp (thọ pháp, tưởng pháp, hành pháp và thức pháp) đang quán, rồi lần lượt quán là vô thường, là tan rã, v.v. Đến đây hết mười mục của đặc tướng vô thường.

Đặc tướng khổ: hai mươi lăm mục. Dukkhaṃ rogābādhaṃ gaṇḍaṃ, sallāghāto upaddavaṃ; bhayītupasaggā tāṇaṃ, aleṇāsaraṇaṃ vadhaṃ; aghamūlaṃ ādīnavaṃ, sāsavaṃ māraāmisaṃ; jātijaraṃ byādhisokaṃ, paridevupāyāsaṃ; saṅkilesasabhāvakaṃ.

1. Dukkhato — là khổ. Uppādavayapaṭipīḷanatāya, dukkhavatthutāya ca dukkhato. (Visuddhi. 2.247.)

Uppādavayapaṭipīḷanatāyāti uppādena, vayena ca pati pati so so sattasantāno vibādhanasabhāvattā, tehi vā sayameva vibādhetabbattā. Udayabbayavanto hi dhammā abhiṇhaṃ tehi paṭipīḷitāva hontīti yā pīḷanā “saṅkhāradukkhatā”ti vuccati. Dukkhavatthutāyāti tividhassāpi dukkhassa, saṃsāradukkhassa ca adhiṭṭhānabhāvato. (Mahāṭī. 2.394–395.)

[Danh-sắc, đối với người có đủ danh-sắc ấy, do sự sinh khởi…


<a id="M09-body-P076"></a>
## Khổ và ba loại khổ
Miến / Burmese 76

do sự bức bách của sinh hoặc sự bức bách của diệt, vốn gây đau đớn và áp chế trong từng sát-na. Nói cách khác, do chính danh sắc của mình là đối tượng bị sự sinh diệt ấy bức bách, tức do danh sắc luôn chịu đau đớn và áp chế bởi sự sinh diệt:

(a) Khổ khổ (dukkhadukkha), tức khổ thọ;

(b) Hoại khổ (vipariṇāmadukkha), tức lạc thọ (lạc khi còn, khổ khi mất);

(c) Hành khổ (saṅkhāradukkha), tức xả thọ và danh sắc còn lại ngoài thọ.

Cũng vì là chỗ nương, là nền tảng của cả ba loại khổ ấy, hay nói cách khác, của khổ nghèo túng trong vòng luân hồi, nên gọi là dukkha, cái khổ tệ hại và khốn cùng.

Hành khổ. Mọi pháp hữu vi hiện diện trong ba cõi đều có thể mang tên hành khổ. Tuy nhiên, khổ thọ và lạc thọ đã mang tên riêng là khổ khổ và hoại khổ. Vì vậy, ở đây, xả thọ và tất cả pháp hữu vi thuộc ba cõi còn lại ngoài thọ được gọi là hành khổ. Tất cả các pháp hữu vi danh sắc thuộc ba cõi ấy có tên hành khổ vì ở chúng hiện rõ sự khổ của cái bị tạo tác (saṅkhatadukkha), tức phải có cái tạo tác mới sinh khởi, và vì chúng luôn chịu đau đớn và áp chế bởi sự bức bách của sinh diệt. (Vism. 2, 270. Mahāṭī. 2, 392.)


<a id="M09-body-P077"></a>
## Quán là bệnh và là tai họa
Miến / Burmese 77

2. Rogato — là bệnh

Paccayāyattavuttitāya, rogamūlatāya ca rogato. (Vism. 2, 247.)

Vì danh sắc quả chỉ có thể trụ và hiện hữu khi được các nhân tương ứng hỗ trợ, nên chúng phải nương các nhân thích hợp tương ứng mà trụ. Nói cách khác, vì chúng phải nương các nhân thích hợp tương ứng mà trụ, và vì chúng giống như bệnh yāpya, nguồn gốc của các chứng đau nhức và bệnh kéo dài, nên chúng là roga, thứ bệnh gây đau đớn và khốn khổ.

[Vì danh sắc là nền tảng của mọi thứ bệnh thân và bệnh tâm nên nói chúng giống như bệnh yāpya.]

3. Aghato — là tai họa

Vigarahitatāya, avaḍḍhiāvahanatāya, aghavatthutāya ca aghato. (Vism. 2, 247.)

Vì bị Đức Phật và các bậc Thánh quở trách như các pháp bất thiện, vì gây tổn hại lớn đến lợi ích và sự phát triển của nhiều hữu tình, và vì là nền tảng cho các pháp bất thiện được gọi là agha, nên chúng là agha, thứ tai họa gây tổn hại và bất lợi.


<a id="M09-body-P078"></a>
## Quán là ung nhọt
Miến / Burmese 78

4. Gaṇḍato — là ung nhọt

Dukkhatāsūlayogitāya, kilesāsucipaggharaṇatāya, uppādajarābhaṅgehi uddhumātapakkapabhinnatāya ca gaṇḍato. (Vism. 2, 247.)

Vì chúng đi cùng sự đau nhói như bị đâm, tức tính khổ có ba loại là khổ khổ, hoại khổ và hành khổ. Vì chúng làm cho chất bẩn là phiền não như tham, vốn bất tịnh và đáng ghê, dần dần rỉ ra, tùy trường hợp qua sức của cảnh hoặc sức tương ưng, tức cùng sinh khởi. Và vì do tính sinh mà cái trước đó chưa có nay đột nhiên xuất hiện, như sưng phồng, do tính già trong khi trụ mà chín muồi, như mưng mủ, và do tính tan rã lúc diệt mà vỡ nứt và hư hoại. Vì vậy chúng là gaṇḍa, ung nhọt sưng phồng và lở vỡ.

Kilesāsucipaggharaṇatāya. Câu «tùy trường hợp, do sức của cảnh hoặc sức tương ưng, tức cùng sinh khởi, làm chất bẩn là phiền não như tham, vốn bất tịnh và đáng ghê, dần dần rỉ ra» chỉ sự sinh khởi của tham v.v. về sau khi lấy tham v.v. đã sinh trước đó làm cảnh, và sự sinh khởi của phiền não như tham cùng với tâm và các tâm sở sinh khởi khi lấy một cảnh có thể làm tham hoặc phiền não sinh làm cảnh. Hãy hiểu rằng chất mủ rỉ ra từ danh sắc ở đây cũng giống như mủ rỉ ra từ một ung nhọt thông thường.


<a id="M09-body-P079"></a>
## Quán là mũi tên và là chứng bệnh
Miến / Burmese 79

5. Sallato — là mũi tên

Pīḷājanakatāya, antotudanatāya, dunnīharaṇīyatāya ca sallato. (Vism. 2, 247.)

[(a) Vì chúng gây đau đớn và áp chế do sinh và diệt.

(b) Cũng như khổ thọ v.v. đâm xuyên vào bên trong thân, các pháp hữu vi này đâm xuyên bằng sinh và diệt khi chúng rơi vào ngôi nhà của các uẩn được coi là tự ngã.

(c) Vì khó nhổ bỏ mũi tên là cái khổ của danh sắc hữu vi nếu thiếu chiếc nhíp là Thánh đạo.]

Salla là mũi tên đâm xuyên gây hại.

6. Ābādhato — là chứng bệnh

Aseribhāvajanakatāya, ābādhapadaṭṭhānatāya ca ābādhato. (Vism. 2, 247.)

[(1) Người bệnh nặng không thể tự mình thực hiện đủ bốn oai nghi. Người ấy có các hoạt động của thân nhờ nương vào người khác, khi được họ phục vụ, nâng đỡ hay trở mình v.v. Cũng vậy, các uẩn không thể tự sinh bằng sức mình mà phải nương vào các nhân, ví như những người khác ấy. Chúng gây nên tình trạng lệ thuộc như vậy. (2) Chúng cũng là nguyên nhân của mọi chứng bệnh gây áp chế hết sức nặng nề.]


<a id="M09-body-P080"></a>
## Quán là tai ách và là mối nguy
Miến / Burmese 80

Ābādha là chứng bệnh áp đảo và bức bách.

7. Upaddavato — là tai ách

Aviditānaṃyeva vipulānaṃ anatthānaṃ āvahanato, sabbupaddavavatthutāya ca upaddavato. (Vism. 2, 247.)

[(1) Vì chúng đem đến những tai hại lớn lao và nhiều thứ trái nghịch, như hiểm họa do vua chúa, tai họa do vua chúa, hiểm họa do trộm cướp, bệnh, chết và các cõi khổ, trong lúc người ta không biết đến các hiểm họa ấy và cũng không biết suy xét về chúng, như những đứa trẻ bé bỏng. (2) Vì chúng là nền tảng và chỗ nương của mọi thứ tai ách bám theo và bức bách.]

Upaddava là tai ách bám theo và bức bách dữ dội.

8. Bhayato — là mối nguy

Sabbabhayānaṃ ākaratāya, dukkhūpasamasaṅkhātassa paramassāsassa paṭipakkhabhūtatāya ca bhayato. (Vism. 2, 247.)

[(1) Vì các uẩn là chỗ sinh và nơi chứa mọi thứ hiểm họa, dù là hiểm họa xảy đến trong đời hiện tại trước mắt hay hiểm họa xảy đến ở đời sau. (2) Vì chúng đối nghịch với pháp Nibbāna cao quý, sự an ổn tột bậc, được gọi là sự lắng dịu mọi khổ đau.]

Bhaya là mối nguy lớn, nhiều bề trái nghịch với an lạc v.v., hay là hiểm họa đáng sợ, gây kinh hãi.


<a id="M09-body-P081"></a>
## Quán là hiểm họa, tai ương và không có sự che chở
Miến / Burmese 81

9. Ītito — là hiểm họa

Anekabyasanāvahanatāya ītito. (Vism. 2, 247.)

Vì các uẩn đem đến nhiều thứ hư hoại khác nhau nên gọi là īti, hiểm họa đáng kinh sợ.

10. Upasaggato — là tai ương

Anekehi anatthehi anubaddhatāya, dosupasaṭṭhatāya, upasaggo viya anadhivāsanārahatāya ca upasaggato. (Vism. 2, 247.)

[(1) Vì chúng liên tục bị nhiều loại bất lợi đeo bám, như quyến thuộc suy vong v.v. ở bên ngoài, và đau ốm, bệnh tật v.v. ở bên trong. (2) Vì những lỗi như tham bám vào chúng qua sức của cảnh hoặc sức tương ưng. (3) Vì chúng không thể chịu đựng được, như những tai hại, dịch bệnh v.v. do dạ-xoa, loài phi nhân và các vị trời ác đem đến, làm phát sinh.]

Upasagga là tai ương đeo bám và áp chế.

11. Atāṇato — không có sự che chở

Atāyanatāya ceva, alabbhaneyyakhematāya ca atāṇato. (Vism. 2, 247.)


<a id="M09-body-P082"></a>
## Quán là không có nơi ẩn náu và không có chỗ quy y
Miến / Burmese 82

[(1) Các uẩn sau khi sinh chỉ có diệt, vì không thể che chở chúng khỏi diệt một khi đã sinh. (2) Dù có bám vào các uẩn với ước muốn được che chở, cũng không thể đạt được an ổn, tức không thể có được sự thoát khỏi hiểm nguy.]

Atāṇa là mối nguy vì thiếu sự che chở.

12. Aleṇato — không có nơi ẩn náu

Allīyituṃ anarahatāya, allīnānampi ca leṇakiccākāritāya aleṇato. (Vism. 2, 247.)

[(1) Vì không thích hợp bám vào các uẩn khi sợ khổ và mong nương tựa. (2) Vì với những người sợ khổ, mong nương tựa và bám vào thân uẩn, tức các uẩn, chúng không làm phận sự của nơi ẩn náu, là làm cho khổ biến mất.]

Aleṇa là mối nguy vì thiếu nơi ẩn náu.

13. Asaraṇato — không có chỗ quy y

Nissitānaṃ bhayasārakattābhāvena asaraṇato. (Vism. 2, 247.)

Vì các uẩn không có tính xua tan, loại bỏ hiểm nguy và đau khổ như sinh, già, bệnh, chết cho những người sợ các hiểm nguy và đau khổ như sinh, già, bệnh, chết mà nương tựa vào chúng:


<a id="M09-body-P083"></a>
## Quán là kẻ sát nhân và là gốc tai họa
Miến / Burmese 83

Asaraṇa là mối nguy vì thiếu chỗ quy y.

14. Vadhakato — là kẻ sát nhân

Mittamukhapaccattho viya vissāsaghātitāya vadhakato. (Vism. 2, 248.)

Vì chúng thường giết người đã đặt lòng tin nơi chúng, như một kẻ thù mang vẻ mặt tươi cười của người bạn. Vadha hay vadhaka là kẻ sát nhân, giết hữu tình được gọi theo chế định quy ước là người, trời hay Phạm thiên, bằng cách làm cho dòng tương tục có ba sát-na mỗi lần sinh bị đứt trong một thời gian ngắn, trong chốc lát.

Các pháp sắc, thọ, tưởng, hành và thức này là nhân của khổ, thay vì là nhân của an lạc. Vì thường giết người có lòng tin bị chúng gây nên như vậy, các uẩn là vissāsaghātī, những kẻ sát nhân giết người đã tin cậy. Thật vậy, do sức của sự chấp thủ đối với các uẩn, «etaṃ mama», «đây là của tôi», hữu tình đi đến chỗ hủy hoại. Bởi các uẩn gọi là khổ đế sinh do tham ái gọi là tập đế. Nói cách khác, vì các uẩn có tính giết người đã tin cậy, chúng giết người ấy. Do đó gọi là vissāsaghātī. (Mahāṭī. 2, 393.)

15. Aghamūlato — là gốc tai họa

Aghahetutāya aghamūlato. (Vism. 2, 248.)

Aghassa pāpassa hetuttā aghahetuto. (Mahāṭī. 2, 393.)


<a id="M09-body-P084"></a>
## Quán là mối bất lợi
Miến / Burmese 84

Vì là nguồn gốc của điều ác bất thiện thô bạo, chúng là aghamūla, nguồn gốc của sự tổn hại và khốn khổ.

16. Ādīnavato — là mối bất lợi

Pavattidukkhatāya, dukkhassa ca ādīnavatāya ādīnavato. Atha vā ādīnaṃ vāti gacchati pavattatīti ādīnavo. Kapaṇamanussassetaṃ adhivacanaṃ. Khandhāpi ca kapaṇāyevāti ādīnavasadisatāya ādīnavato. (Vism. 2, 248.)

Pavattidukkhatāyāti bhavapavattidukkhabhāvato. Bhavapavatti ca pañcannaṃ khandhānaṃ aniccādiākārena pavattanameva. So ca ādīnavo. Yathāha “Yaṃ bhikkhave pañcupādānakkhandhā aniccā dukkhā vipariṇāmadhammā, ayaṃ bhikkhave pañcasu upādānakkhandhesu ādīnavo”ti. Tenāha “Dukkhassa ca ādīnavatāyā”ti. Ādīnoti bhāvappadhāno niddeso yathā “Kemajjhā”ti. Ativiya kapaṇoti attho. Bhummatthe hi ayaṃ ā-kāro. (Mahāṭī. 2, 396.)

[(1) Sự diễn tiến của năm uẩn theo các phương diện vô thường v.v. gọi là bhavapavatti, sự diễn tiến của đời sống. Chính sự diễn tiến theo các phương diện vô thường v.v. ấy cũng gọi là ādīnava, mối bất lợi của các uẩn. Đức Phật đã dạy như vậy: «Này các Tỳ-khưu … năm thủ uẩn là vô thường, khổ, có tính biến đổi. Này các Tỳ-khưu … chính tính vô thường, khổ, biến đổi ấy là mối bất lợi của năm thủ uẩn». Do vậy, vì có khổ trong sự diễn tiến của đời sống, tức sự diễn tiến của năm uẩn theo các phương diện vô thường v.v.,


<a id="M09-body-P085"></a>
## Quán là hữu lậu và là mồi của Māra
Miến / Burmese 85

và (2) vì khổ đế là năm uẩn có mối bất lợi là vô thường, khổ, có tính biến đổi, nên gọi là ādīnava, tức mối tai hại và bất lợi.]

[Theo một cách giải thích khác, người nghèo túng tột bậc gọi là ādīnava vì quá nghèo túng nên phải sống cơ cực. Năm uẩn cũng giống như người nghèo túng tột bậc không có chỗ cậy nhờ, gọi là ādīnava.] Ādīnava là người nghèo túng tột bậc, không có chỗ cậy nhờ. (Có nghĩa là các uẩn đã sinh không có chỗ cậy nhờ để khỏi diệt khi đến sát-na diệt.)

17. Sāsavato — là hữu lậu

Āsavapadaṭṭhānatāya sāsavato. (Vism. 2, 248.)

Āsavānaṃ ārammaṇādinā paccayabhāvato āsavapadaṭṭhānatā. (Mahāṭī. 2, 393.)

Các phiền não làm nhân gốc của danh sắc, gọi là vô minh, ái và thủ, chính là các pháp lậu hoặc. Vì các pháp danh sắc thuộc năm uẩn hỗ trợ bằng các năng lực duyên, như cảnh duyên, nên các lậu hoặc ấy sinh khởi. Như vậy, vì các pháp danh sắc thuộc năm uẩn là nhân gần nhất của các lậu hoặc, chúng là sāsava, nơi sinh sôi của bốn lậu hoặc.

18. Mārāmisato — là mồi của Māra

Maccumārakilesamārānaṃ āmisabhūtatāya mārāmisato. (Vism. 2, 248.)


<a id="M09-body-P086"></a>
## Năm loại Māra
Miến / Burmese 86

Maccumārassa adhiṭṭhānabhāvena, kilesamārassa paccayabhāvena saṃvattanato āmisabhūtato. Khandhāpi khandhānaṃ āmisabhūtā paccayabhāvena saṃvattanato. Tathevetaṃ abhisaṅkhāre. Devaputtamārassa pana “mametan”ti abhimānavasena āmisabhāveti khandhādimārānaṃ kathaṃ yathārahaṃ āmisabhūtatā vattabbā. (Mahāṭī. 2, 393.)

[Có năm loại Māra, tức thiên tử Māra, phiền não Māra, uẩn Māra, tử Māra và hành Māra. Trong đó, Chú giải trực tiếp giải thích hai loại là phiền não Māra và tử Māra. Vị soạn Phụ chú giải lớn giải thích rõ vì sao có thể áp dụng thích hợp cho cả năm loại Māra.

Các uẩn cũng là chỗ nương của tử Māra, tức sự chết. (Nếu không có uẩn thì không thể chết.) Các uẩn cũng là nhân để các phiền não Māra, gọi là vô minh, ái và thủ, bám vào mà sinh, và là nhân cho chúng tăng trưởng. Chính các uẩn làm duyên cho các uẩn, khiến các uẩn tăng trưởng, nên chính các uẩn cũng là thức ăn, mồi nhử (āmisa) của các uẩn. Do đó, chính các uẩn cũng là nhân để các uẩn bám vào mà sinh, và là nhân cho chúng tăng trưởng. Hành Māra, tức hành thiện và hành bất thiện có thể tạo tác một đời sống mới, cũng nằm ngay trong các uẩn ấy. Do các hành ấy, các uẩn sinh khởi. Do bám vào các uẩn, các hành ấy cũng sinh khởi. Những pháp gọi là hành ở đây cũng chỉ là các danh uẩn mang tên hành thiện và hành bất thiện. Còn thiên tử Māra thì hãy hiểu tính chất làm mồi qua sức của ý nghĩ kiêu mạn «etaṃ mama, mametaṃ», «tất cả những pháp này là của tôi». Do đó, đối với uẩn Māra v.v. cũng vậy, chính các uẩn này


<a id="M09-body-P087"></a>
## Mồi của Māra, sinh, già, bệnh, sầu, bi và não
Miến / Burmese 87

cũng đáng gọi là mồi, tùy theo trường hợp thích hợp. Do đó, vì năm uẩn là chỗ ăn, chỗ nuốt, là phạm vi hoạt động của năm loại Māra là thiên tử Māra, phiền não Māra, uẩn Māra, tử Māra và hành Māra, nên gọi là mārāmisa, thức ăn và mồi của phiền não Māra và tử Māra, hay thức ăn, mồi và phạm vi hoạt động của cả năm loại Māra.]

19. Jātidhammato — có tính sinh

20. Jarādhammato — có tính già

21. Byādhidhammato — có tính bệnh

Jāti-jarā-byādhi-maraṇapakatitāya jāti-jarā-byādhi-maraṇadhammato. (Vism. 2, 248.)

[Vì chúng có tính sinh, tức xuất hiện, tính già, tức biến đổi trong khi trụ, tính bệnh, và tính chết, tức tan rã.]

19. Jāti là tính sinh khởi mỗi khi có sinh khởi.

20. Jarā là tính hao mòn và suy giảm.

21. Byādhi là tính đau ốm.

(Maraṇadhammato, có tính chết, đã nằm trong mười phương diện của đặc tướng vô thường.)

22. Sokadhammato — có tính sầu

23. Paridevadhammato — có tính bi

24. Upāyāsadhammato — có tính não

Soka-parideva-upāyāsahetutāya soka-parideva-upāyāsadhammato. (Vism. 2, 248.)


<a id="M09-body-P088"></a>
## Sầu, bi, não và tính nhiễm ô
Miến / Burmese 88

Vì các uẩn là nhân cho sầu, bi và não sinh khởi:

22. Soka là tính lo buồn, sầu khổ.

23. Parideva là tính than van, khóc lóc.

24. Upāyāsa là tính sầu khổ dữ dội, đến mức thở dài.

25. Saṅkilesikadhammato — có tính nhiễm ô

Taṇhādiṭṭhiduccaritasaṅkilesānaṃ visayadhammatāya saṅkilesikadhammato. (Vism. 2, 248.)

Saṅkilesattayappahānena tadekadesānaṃ vasena kilesavatthūnaṃ saṅgaho daṭṭhabbo. Tādisakā hi dhammā tadanatiṭṭhānato saṅkilesikā ce. Tattha duṭṭhi, taṇhā, eḷādisu (duṭṭhitaṇhāeḷādisu — Sī.) sarīrassa, saṅkilesassa ca saṅgaho daṭṭhabbo. (Mahāṭī. 2, 393.)

Vì các uẩn là phạm vi của ba pháp nhiễm ô, gọi là nhiễm ô do ái, nhiễm ô do kiến và nhiễm ô do ác hạnh, là những phiền não làm ô nhiễm dòng tâm hay hữu tình mà chúng bám vào, nên gọi là saṅkilesikadhamma, có tính nhiễm ô: có tính làm tăng trưởng ba sự ô nhiễm là ái, kiến, ác hạnh, hay sự ô nhiễm là mười phiền não.

Hãy nghiên cứu các tính chất này đến mức thỏa đáng. Sau đó hãy chia danh sắc thành năm theo phương pháp năm uẩn. Đối với từng uẩn, dùng tuệ thấy rõ ý nghĩa tương ứng và quán «khổ, khổ», «bệnh, bệnh», v.v.


<a id="M09-body-P089"></a>
## Năm phương diện của đặc tướng vô ngã
Miến / Burmese 89

Anattā ca paro ritto, tuccho suññoti tādisā; vedanādayo khandhāpi, tatheva pañcakāpi vā.

Suññato và anattato — là rỗng không và là vô ngã

Sāmi-nivāsī-kāraka-vedaka-adhiṭṭhāyakavirahitatāya suññato. Sayañca assāmikādibhāvatāya anattato. (Vism. 2, 247.)

1. Anattato — là vô ngã

[(1) Ngã là chủ nhân, sở hữu ngôi nhà các uẩn.

(2) Ngã là người cư trú, dù ngôi nhà các uẩn đổi mới thì tự nó vẫn không thay đổi mà theo đó cư trú trong mỗi đời.

(3) Ngã là người làm, thực hiện tất cả các công việc cần làm.

(4) Ngã là người cảm thọ, trải nghiệm đối tượng.

(5) Ngã là người điều khiển, phân xử và quyết định mọi công việc.

Vì chính năm uẩn không có các tính chất như chủ nhân, người cư trú, người làm, người cảm thọ hay người điều khiển,] nên gọi là anattā, vô ngã, tức không phải là cái ngã làm chủ nhân, người cư trú, người làm, người cảm thọ hay người điều khiển.

2. Suññato — là rỗng không

Vì trong mỗi uẩn đều vắng bóng cái ngã làm chủ nhân, người cư trú, người làm, người cảm thọ hay người điều khiển, nên gọi là suñña, rỗng không cái ngã làm chủ nhân, người cư trú, người làm, người cảm thọ hay người điều khiển.


<a id="M09-body-P090"></a>
## Quán là xa lạ và là trống không
Miến / Burmese 90

3. Parato — là xa lạ

Avasatāya, avidheyyatāya ca parato. (Vism. 2, 247.)

Avasatāyāti avasavattanato. Yathā parasantako puriso parassa vasaṃ na gacchati, evaṃ subhasukhādibhāvena vase vattetuṃ asakkuṇeyyato. Avidheyyatāyāti “mā jīratu, mā mīyatū”tiādinā vidhātuṃ asakkuṇeyyato. (Mahāṭī. 2, 392.)

Các uẩn chỉ sinh khởi phù hợp với các nhân, như đã trình bày ở phần sự nối tiếp nhân quả, tức các pháp duyên khởi. Cũng như người thuộc quyền của mình thì không phải làm theo ý của người khác, các uẩn không chiều theo ý ta, dù ta mong chúng đừng sinh khổ thọ v.v., chỉ sinh lạc thọ v.v., hay đẹp đẽ và đáng ưa. Vì chúng không theo ý muốn, và vì không thể ra lệnh cho chúng «đừng già, đừng bệnh, đừng chết» v.v., nên chúng là para, người xa lạ không đặt lòng tin cậy nơi ta.

4. Rittato — là trống không

Yathāparikappitehi dhuvasubhasukha-attabhāvehi rittatāya rittato. (Vism. 2, 247.)


<a id="M09-body-P091"></a>
## Quán là trống không và là rỗng tuếch
Miến / Burmese 91

[Ngoài Giáo pháp, những người theo tà kiến quan niệm rằng các pháp sắc và danh thuộc năm uẩn là (1) dhuva, thường bền, (2) subha, đẹp đẽ, (3) sukha, an lạc, và (4) atta, tự ngã. Tuy nhiên, các pháp sắc và danh thuộc năm uẩn luôn luôn vắng những tính chất thường bền, đẹp đẽ, an lạc và tự ngã mà những người theo tà kiến ấy gán cho chúng. Vì thế,] ritta nghĩa là các pháp vốn hoàn toàn trống không, tuyệt nhiên không có cốt lõi nào gọi là thường bền, đẹp đẽ, an lạc hay tự ngã.

5. Tucchato — là rỗng tuếch

Rittatāyeva tucchato, appakattā vā. Appakampi hi loke tucchanti vuccati. (Vism. 2, 247.)

(Trong các pháp sắc và danh thuộc năm uẩn không có các tính chất thường bền, đẹp đẽ, an lạc và cốt lõi tự ngã được gọi là dhuva, subha, sukha và atta. Vì không có những tính chất ấy, các pháp sắc và danh thuộc năm uẩn là tuccha, các pháp rỗng tuếch. Theo một cách khác, tuy các pháp sắc và danh thuộc năm uẩn vắng các tính chất thường bền, đẹp đẽ, an lạc và tự ngã, chúng quả thật hiện hữu theo thực tính chân đế. Chúng hiện hữu dưới dạng có sinh rồi có diệt. Thọ mạng của các pháp chân đế sinh rồi diệt ấy rất, rất ngắn. Các pháp chân đế sắc và danh chỉ có cơ hội hiện hữu trong một khoảng thời gian cực ngắn. Vì chỉ có cơ hội hiện hữu trong một khoảng cực ngắn, chúng cũng là tuccha, các pháp rỗng tuếch. Quả thật, ở đời người ta cũng gọi cái ít ỏi là tuccha.


<a id="M09-body-P092"></a>
## Nguyên nhân của vô thường, khổ và vô ngã
Miến / Burmese 92

Từ ấy được dùng theo nghĩa như vậy. Vì thế các pháp sắc và danh thuộc năm uẩn) là tuccha, rỗng tuếch vì vắng thường bền, đẹp đẽ, an lạc và tự ngã. Hoặc là tuccha, những pháp rỗng tuếch vì ít ỏi, nhỏ bé.

Rūpaṃ, bhikkhave, aniccaṃ. Yopi hetu yopi paccayo rūpassa uppādāya, sopi anicco. Aniccasambhūtaṃ, bhikkhave, rūpaṃ kuto niccaṃ bhavissati? (Saṃ. 2, 20, Sahetuaniccasutta.)

Này các tỳ-khưu … sắc là vô thường. Có nhân trực tiếp làm sắc sinh khởi, tức hetu hay janaka, nhân sinh. Cũng có duyên hỗ trợ, tức paccaya hay upatthambhaka, duyên nâng đỡ. Chính nhân duyên ấy cũng vô thường. Này các tỳ-khưu … làm sao sắc hiện khởi do nhân vô thường lại có thể là thường? (Saṃ. 2, 20.)

Theo lời Đức Phật dạy trong những bài kinh như trên, chính các nhân sinh ra năm uẩn, như vô minh, ái, thủ, hành và nghiệp, là các pháp vô thường, khổ và vô ngã. Vì thế, quả của chúng, tức năm uẩn sắc và danh, cũng chỉ có thể là các pháp vô thường, khổ và vô ngã. Hành giả cần quán nhiều lần để tuệ thấy rằng chính các nhân là vô thường, khổ và vô ngã, và các quả cũng chỉ là vô thường, khổ và vô ngã.


<a id="M09-body-P093"></a>
## Minh sát theo phương pháp gồm 200 cách
Miến / Burmese 93

Như vậy, đối với sắc uẩn hoặc đối với từng uẩn: 1. Quán vô thường (aniccānupassanā), 10 cách. 2. Quán khổ (dukkhānupassanā), 25 cách. 3. Quán vô ngã (anattānupassanā), 5 cách. Tổng cộng có 40 cách tu tập.

Vì có 40 cách tu tập đối với từng uẩn, nên tuệ thẩm sát được gọi là nayavipassanā, minh sát theo phương pháp, có 200 cách đối với cả năm uẩn.

Các thiện nhân hãy quán mỗi hàng của các bảng trong phần thiền danh, cho lộ nhãn môn và các lộ tương ứng, trước hết lấy riêng vô thường đối với từng nhóm năm uẩn, đủ cả năm uẩn trong mỗi hàng. Quán tất cả sáu lộ, bắt đầu từ lộ sắc cảnh. Quán một lượt bên trong và một lượt bên ngoài. Sau đó lần lượt thêm từng cách, cho đủ 40 cách tu tập. Tổng cộng phải quán 40 lượt.

Cũng vậy, từ quá khứ nối tiếp cho đến tận tương lai, hãy quán theo phương pháp năm uẩn, lần lượt thêm và quán đủ 40 phép tùy quán, từng phép một. Tổng cộng cũng có 40 lượt. Càng quán đi quán lại được nhiều lần càng tốt. Quán cả bên trong lẫn bên ngoài.

Nếu muốn, quý vị cũng có thể quán đủ 40 lượt ấy theo phương pháp hai nhóm sắc và danh. Đối với cả sáu loại lộ tâm như lộ nhãn môn, hãy dùng phương pháp hai nhóm sắc và danh và quán một lượt bên trong, một lượt bên ngoài.


<a id="M09-body-P094"></a>
## Sự tu tập tuệ có thể viên mãn
Miến / Burmese 94

Sau đó, cũng có thể quán theo phương pháp hai nhóm sắc và danh từ quá khứ nối tiếp cho đến tận tương lai. Quán cả bên trong lẫn bên ngoài. Hãy quán đi quán lại nhiều lần.

Evaṃ kālena rūpaṃ kālena arūpaṃ sammasitvāpi tilakkhaṇaṃ āropetvā anukkamena paṭipajjamāno eko paññābhāvanaṃ sampādeti. (Vism. 2, 252.)

Anukkamenāti udayabbayañāṇādikānukkamena paññābhāvanaṃ sampādeti arahattaṃ adhigacchati. (Mahāṭī. 2, 405.)

Như vậy, hành giả có thể dùng phương pháp năm uẩn, hoặc nếu có khả năng, phương pháp 12 xứ và 18 giới, hoặc phương pháp hai nhóm sắc và danh: 1. Khi thì quán riêng sắc. 2. Khi thì quán riêng danh. 3. Khi thì quán sắc và danh thành từng cặp, từng đôi.

Một cách khác: 1. Khi thì quán riêng sắc. 2. Khi thì quán riêng thọ. 3. Khi thì quán riêng tưởng. 4. Khi thì quán riêng hành. 5. Khi thì quán riêng thức. 6. Khi thì quán bên trong. 7. Khi thì quán bên ngoài,


<a id="M09-body-P095"></a>
## Phương pháp quán minh sát bảy cách về sắc
Miến / Burmese 95

8. Khi thì quán quá khứ, tương lai, hiện tại, bên trong và bên ngoài. 9. Khi thì áp dụng tướng vô thường. 10. Khi thì áp dụng tướng khổ. 11. Khi thì áp dụng tướng vô ngã.

Nếu có thể quán minh sát sâu rộng như thế, sau khi quán xét theo cách ấy, hành giả có thể tu tập theo đúng thứ tự các tuệ minh sát, làm cho sự tu tập tuệ viên mãn, tức là có thể đạt quả A-la-hán. Nếu sự tu tập chưa viên mãn thì cần quán đi quán lại nhiều lần. Nếu vẫn chưa thể viên mãn, có thể chuyển sang quán theo phương pháp bảy cách về sắc và bảy cách về danh.

Ādānanikkhepato vayovuḍḍhatthaṅgamito, āhārato ca ututo kammato cāpi cittato, sammatito satta rūpāni vipassati. (Vism. 2, 253.)

1. Quán sắc từ lúc nhận lấy đến lúc đặt xuống (ādānanikkheparūpa). Áp dụng lần lượt cả ba tướng và quán minh sát các pháp sắc hiện hữu từ lúc tái tục cho đến lúc tử. Quán một lượt bên trong và một lượt bên ngoài.

2. Quán sắc theo sự trưởng thành và chấm dứt ở các lứa tuổi (vayovuḍḍhatthaṅgamarūpa). Quán sự chấm dứt từng chặng của sắc phát triển theo tuổi. Hãy định tuổi thọ của quý vị là 100 năm theo mức ấn định thông thường. Tuổi thọ thực có thể chênh lệch đôi chút.


<a id="M09-body-P096"></a>
## Chia tuổi thọ và ngày đêm thành các thời đoạn
Miến / Burmese 96

Chia 100 năm theo các cách sau:
1. Thành 3 phần (33–34–33), mỗi phần khoảng 33 năm.
2. Thành 10 phần, mỗi phần 10 năm.
3. Thành 20 phần, mỗi phần 5 năm.
4. Thành 25 phần, mỗi phần 4 năm.
5. Thành 33 phần, mỗi phần 3 năm.
6. Thành 50 phần, mỗi phần 2 năm.
7. Thành 100 phần, mỗi phần 1 năm.
8. Thành 300 phần, mỗi phần 1 mùa.
9. Thành 600 phần, mỗi phần 2 tháng.
10. Thành 2.400 phần, mỗi phần 1 nửa tháng (pakkha), tức 15 ngày.

Hãy lần lượt áp dụng cả ba tướng đối với các pháp sắc sinh khởi trong từng thời đoạn ấy và quán minh sát từng phần theo thứ tự. Quán cho đến khi hiểu rõ rằng sắc hiện hữu trong một phần không chuyển sang phần kế tiếp. Hãy quán để thấy chúng diệt đi ngay trong từng thời đoạn ấy. Sau đó, đối với các pháp sắc hiện hữu trong một ngày:

1. Có thể chia thành hai phần, một phần ban ngày và một phần ban đêm. 2. Có thể chia ban ngày thành ba phần, sáng, trưa và chiều, và chia ban đêm thành ba canh, purimayāma, majjhimayāma và pacchimayāma, tức canh đầu đêm, canh nửa đêm và canh gần sáng. [Nghĩa là chia một ngày thành sáu phần.]

Hãy lần lượt áp dụng cả ba tướng vào các pháp sắc hiện hữu trong mỗi thời đoạn ấy và quán minh sát. (Trong khoảng thời gian 100 năm đã phân chia như trên, hãy chia từng ngày, ngày này qua ngày khác, thành sáu phần để quán. Hãy lưu ý rằng việc quán này không chỉ giới hạn vào một ngày.)


<a id="M09-body-P097"></a>
## Quán sắc theo động tác trong ngày
Miến / Burmese 97

Sau khi quán minh sát như thế, trong từng phần của sáu thời đoạn của một ngày, hãy quán các pháp sắc hiện hữu ở đó: 1. Sắc sinh khi đi tới. 2. Sắc sinh khi đi lui. 3. Sắc sinh khi nhìn thẳng. 4. Sắc sinh khi nhìn sang bên.

Hãy lần lượt áp dụng cả ba tướng vào từng loại sắc ấy và quán minh sát. (Hãy quán như thế đối với từng ngày trong thời gian đã ấn định là 100 năm.)

Sau đó, trong từng ngày, hãy quán các khoảnh khắc của những động tác như đi tới và đi lui, thuộc phần oai nghi và phần tỉnh giác: 1. Sắc sinh khi nhấc chân lên khỏi mặt đất. 2. Sắc sinh khi đưa chân đã nhấc tới trước, cho đến ngang chân trụ. 3. Sắc sinh khi đưa chân đang bước vượt qua chân trụ. Theo một cách khác, sắc sinh khi đưa chân tránh gai, khúc gỗ v.v. 4. Sắc sinh khi hạ xuống chân đã đưa qua phía trước chân trụ. 5. Sắc sinh khi đặt chân ấy xuống mặt đất. 6. Khi sắp bước thêm một bước, trước khi nhấc chân,


<a id="M09-body-P098"></a>
## Quán sắc do vật thực và do thời tiết
Miến / Burmese 98

sắc sinh vào lúc ấn chân xuống đất.

Phân biệt riêng các pháp sắc sinh trong từng khoảnh khắc thuộc sáu loại trên, nhấc, đưa tới, đưa qua, hạ, đặt và ấn. Lần lượt áp dụng cả ba tướng rồi quán minh sát. (Hãy hiểu chỉ dẫn này theo phương pháp upalakkhaṇa, tức nêu một trường hợp để chỉ các trường hợp tương tự. Cũng như đối với động tác tiến tới, hãy áp dụng các tướng và quán minh sát sắc hiện hữu ở từng khoảnh khắc của các oai nghi và các hoạt động thuộc tỉnh giác trong suốt ngày.) Trong thời gian đã ấn định và phân chia thành 100 năm, hãy quán mọi chuyển động của thân thực sự xảy ra, ngày này qua ngày khác.

3. Quán sắc do vật thực (āhāramayarūpa)

1. Sắc thuộc bốn dòng tương tục sinh khi đói, do bốn nhân là nghiệp, tâm, thời tiết và vật thực. 2. Sắc thuộc bốn dòng tương tục sinh khi đã ăn và đã no. Trong từng ngày, hãy lần lượt áp dụng các tướng và quán minh sát các pháp sắc thuộc bốn dòng tương tục sinh vào hai thời điểm ấy.

4. Quán sắc do thời tiết (utumayarūpa)

Trong từng ngày: 1. Các pháp sắc thuộc bốn dòng tương tục sinh lúc nóng. 2. Các pháp sắc thuộc bốn dòng tương tục sinh lúc lạnh.


<a id="M09-body-P099"></a>
## Quán sắc do nghiệp và sắc do tâm sinh
Miến / Burmese 99

Hãy lần lượt áp dụng các tướng vào các pháp sắc ấy và quán minh sát.

5. Quán sắc do nghiệp (kammajarūpa)

Trong từng ngày: 1. Nhãn môn (cakkhudvāra), 54 loại sắc sinh ở mắt. 2. Nhĩ môn (sotadvāra), 54 loại sắc sinh ở tai. 3. Tỷ môn (ghānadvāra), 54 loại sắc sinh ở mũi. 4. Thiệt môn (jivhādvāra), 54 loại sắc sinh ở lưỡi. 5. Thân môn (kāyadvāra), 44 loại sắc sinh ở thân. 6. Ý môn (manodvāra), 54 loại sắc sinh ở tim.

Hãy quán để tuệ thấy rằng những pháp sắc ấy không chuyển từ môn này sang môn khác, mà tan rã và chấm dứt ngay tại môn tương ứng. Rồi áp dụng các tướng và quán minh sát. Hãy quán minh sát các pháp sắc hiện hữu ở từng môn ấy, ngày này qua ngày khác.

6. Quán sắc do tâm sinh (cittasamuṭṭhānarūpa)

Trong từng ngày: 1. Somanassita, các pháp sắc thuộc bốn dòng tương tục sinh vào lúc vui mừng. 2. Domanassita, các pháp sắc thuộc bốn dòng tương tục sinh vào lúc bất an, buồn rầu. Hãy lần lượt áp dụng cả ba tướng và quán minh sát tất cả các pháp sắc thuộc bốn dòng tương tục sinh như vậy, ngày này qua ngày khác.


<a id="M09-body-P100"></a>
## Quán sắc theo quy ước và bảy cách quán danh
Miến / Burmese 100

7. Quán sắc theo quy ước (sammatarūpa)

Anindriyabaddha nghĩa là không gắn với các căn, như mạng căn thuộc sắc do nghiệp. Cần quán các pháp sắc thuộc nhóm thuần tám do thời tiết sinh, hiện hữu trong thế giới vô tri, chẳng hạn sắt, đồng, thiếc, chì, vàng, bạc, ngọc trai, hồng ngọc, mắt mèo, đá đỏ, đá pha lê, san hô, vườn, vườn hoa, bụi, cây, nước, đất, rừng và núi. Các thiện nhân hãy dùng ánh sáng của tuệ phát sinh nhờ minh sát để phân tích bốn đại hiện hữu trong các vật vô tri ấy như vàng, bạc, hồng ngọc, cây, nước, đất, rừng và núi. Khi tuệ thấy các hạt nhóm sắc, hãy phân tích tám hoặc chín loại sắc chân đế hiện hữu trong các nhóm ấy. Hãy lần lượt áp dụng cả ba tướng vào những sắc chân đế ấy rồi quán minh sát.

[Ghi chú — Các pháp sắc từ số 1 đến số 6 là sắc thuộc thế giới hữu tình. Hãy quán cả dòng tương tục bên trong lẫn bên ngoài. Sắc theo quy ước ở số 7 là sắc vô tri, không do thủ. Hãy quán ở thế giới vô tri bên ngoài.]

Phương pháp bảy cách quán danh (arūpasattaka)

Bảy phương pháp quán minh sát danh là: (1) theo nhóm (kalāpa), (2) theo cặp (yamaka), (3) theo từng bước (satika), (4) theo chuỗi tiếp nối (paṭipāṭi), (5) bằng cách loại bỏ tà kiến (diṭṭhiugghāṭana),


<a id="M09-body-P101"></a>
## Quán theo nhóm
Miến / Burmese 101

(6) bằng cách nhổ tận gốc ngã mạn (mānasamugghāṭana), và (7) bằng cách đoạn trừ sự ưa thích (nikantipariyādāna). Có bảy phương pháp như vậy.

1. Quán theo nhóm (kalāpa), tức gom lại để quán

Hãy lần lượt áp dụng các tướng vô thường, khổ và vô ngã vào các pháp sắc hiện hữu ở bảy phạm vi thuộc phương pháp bảy cách quán sắc ở trên. Dùng tâm minh sát sau để quán trở lại tâm đang quán minh sát ấy, lần lượt áp dụng các tướng vô thường, khổ và vô ngã. Phương pháp quán minh sát này gọi là quán theo nhóm.

Hãy gom các pháp sắc hiện hữu ở bảy phạm vi đã trình bày trong phương pháp bảy cách quán sắc, bắt đầu bằng sắc từ lúc nhận lấy đến lúc đặt xuống, thành một nhóm, không còn chia thành bảy phạm vi, rồi quán sắc đã gom ấy là vô thường. Dùng tâm minh sát sau quán trở lại tâm minh sát đang quán vô thường ấy là vô thường. Dùng tâm minh sát sau quán trở lại tâm minh sát đang quán vô thường ấy là khổ. Lại dùng tâm minh sát sau quán minh sát trở lại tâm minh sát đang quán vô thường ấy là vô ngã.

Kế đến, quán minh sát các pháp sắc hiện hữu ở bảy phạm vi ấy là khổ. Dùng tâm minh sát sau quán minh sát trở lại tâm minh sát đang quán khổ ấy là vô thường. Quán minh sát là khổ. Quán minh sát là vô ngã.

Kế đến, quán minh sát các pháp sắc hiện hữu ở bảy phạm vi ấy là vô ngã. Dùng tâm minh sát sau quán minh sát trở lại tâm minh sát đang quán vô ngã ấy là vô thường. Quán minh sát là khổ. Quán minh sát là vô ngã. Phương pháp quán như vậy được gọi là quán theo nhóm


<a id="M09-body-P102"></a>
## Tâm minh sát trước và tâm minh sát sau
Miến / Burmese 102

(kalāpa). Đó là cách gom các pháp sắc của bảy phạm vi rồi quán minh sát.

Chú giải phần Phân tích về Tuệ nói rằng tâm quán minh sát, đối với phàm nhân và bậc hữu học, chỉ gồm các lộ đổng lực đại thiện qua ý môn. (အဘိ၊ဓ၊၂၊၃၈၈။)

Sekkhā vā puthujjanā vā kusalaṃ aniccato dukkhato anattato vipassanti. Kusale niruddhe vipāko tadārammaṇatā uppajjati. (Paṭṭhāna 1, 133.)

Các thiện nhân bậc Thánh hữu học cũng như các thiện nhân phàm nhân quán minh sát pháp thiện là vô thường, khổ và vô ngã. Khi pháp thiện, tức đổng lực thiện minh sát, đã diệt, tâm quả dục giới làm nhiệm vụ đăng ký sinh khởi sau đổng lực thiện minh sát ấy. (Paṭṭhāna 1, 133.)

Taṃ kusalassa javanassa ārammaṇabhūtaṃ vipassitakusalaṃ ārammaṇaṃ katvā uppajjatīti attho. (အဘိ၊ဓ၊၃၊၄၃၆။)

Tâm quả dục giới lấy chính pháp thiện đã được quán làm cảnh. Pháp thiện ấy là cảnh của đổng lực thiện minh sát. Tâm quả dục giới sinh khởi, làm nhiệm vụ đăng ký, bằng cách lấy chính pháp thiện đã được đổng lực thiện minh sát quán làm cảnh. (အဘိ၊ဓ၊၃၊၄၃၆။)

Theo các đoạn kinh văn trên, hãy ghi nhớ rằng sau các đổng lực minh sát còn non yếu có thể có tâm đăng ký.


<a id="M09-body-P103"></a>
## Lộ đổng lực ý môn minh sát
Miến / Burmese 103

Tilakkhaṇārammaṇikavipassanāya tadārammaṇaṃ na labbhati. Vuṭṭhānagāminiyā balavavipassanāya tadārammaṇaṃ na labbhati. (အဘိ၊ဓ၊၂၊၁၄၇။)

Theo lời giải thích của Chú giải ở trên, hãy ghi nhớ rằng sau các đổng lực minh sát mạnh, mãnh liệt, không có tâm đăng ký. Do đó, sau các đổng lực minh sát có thể có hai trường hợp, có tâm đăng ký hoặc không có tâm đăng ký. Các lộ đổng lực ý môn minh sát ấy như sau.

Lộ đổng lực ý môn minh sát

Phần đề mục thiền minh sát

Namo tassa bhagavato arahato sammāsambuddhassa.

Thanh tịnh do tri kiến về đạo và phi đạo (maggāmaggañāṇadassanavisuddhi)

Chương Tuệ thẩm sát (sammasanañāṇa)

Tuệ minh sát đã thoát khỏi các tùy phiền não minh sát và đang đi theo con đường đúng đắn, theo lối minh sát đã có từ xưa, là đạo dự bị đi trước Thánh đạo. Mười tùy phiền não minh sát, bắt đầu bằng ánh sáng, không phải là đạo dự bị đi trước Thánh đạo, không phải con đường minh sát đúng đắn. Như vậy, tuệ hiểu rõ và phân biệt chính xác cả đạo dự bị là con đường minh sát đúng đắn đi trước Thánh đạo, lẫn phi đạo, tức điều không phải con đường minh sát đúng đắn, được gọi là thanh tịnh do tri kiến về đạo và phi đạo. Vì tuệ ấy biết rõ “đây là con đường đúng, đây là con đường sai”, nên gọi là tuệ trong sạch khỏi các tùy phiền não minh sát. (ဝိသုဒ္ဓိ၊၂၊၂၄၁။)

Hãy ghi nhớ rằng toàn bộ lộ đổng lực ý môn ấy, cùng với các tâm sở tương ưng, được gọi theo lối dùng quy ước (vohāra) là: 1. Tâm quán vô thường, tâm quán khổ, tâm quán vô ngã v.v. 2. Tâm thứ nhất, tâm thứ hai v.v. 3. Tâm trước, tâm sau v.v.

Lý do là cảnh của lộ ý môn minh sát thứ nhất là các pháp sắc hiện hữu ở bảy phạm vi. Cảnh của lộ đổng lực ý môn minh sát thứ hai là chính lộ đổng lực ý môn minh sát thứ nhất,


<a id="M09-body-P104"></a>
## Quán theo cặp
Miến / Burmese 104

tức là các pháp danh. Trong cùng một lộ đổng lực có một cảnh duy nhất, thật hết sức khó có chuyện một số tâm lấy sắc làm cảnh còn một số tâm lấy danh làm cảnh. Do đó, hãy ghi nhớ rằng lộ tâm lấy sắc làm cảnh là một lộ, và lộ tâm lấy danh làm cảnh là một lộ khác. Cũng hãy ghi nhớ rằng những cách gọi như tâm trước và tâm sau là cách gọi quy ước cho toàn bộ lộ tâm. Tâm đăng ký có thể có hoặc có thể không. Nếu có tâm đăng ký, nó sinh theo cách đăng ký cảnh quá khứ hoặc đăng ký hữu nhân.

2. Yamaka — quán theo cặp

Quán sắc từ lúc nhận lấy đến lúc đặt xuống là vô thường. Rồi dùng tâm sau quán riêng tâm đã quán ấy là vô thường, là khổ và là vô ngã. (Khi quán sắc là khổ và khi quán sắc là vô ngã, hãy hiểu theo cùng phương pháp.)

Hãy hiểu cùng phương pháp đối với sắc theo sự trưởng thành và chấm dứt ở các lứa tuổi, sắc do vật thực, sắc do thời tiết, sắc do nghiệp, sắc do tâm sinh và sắc theo quy ước. Trong phương pháp theo nhóm, sắc hiện hữu ở bảy phạm vi được gom thành một phạm vi, không phân chia. Trong phương pháp theo cặp này, hãy chia thành từng phạm vi riêng rồi quán. Sự khác nhau chỉ ở đó. Tuy quán riêng từng phạm vi, cần quán kỹ lưỡng trong mỗi phạm vi. Đặc biệt, với sắc theo sự trưởng thành và chấm dứt ở các lứa tuổi, hãy quán như đã chia ở phần bảy cách quán sắc: quán sắc thời kỳ thứ nhất, rồi quán lại tuệ quán, tức tâm quán. Quán sắc thời kỳ thứ hai, rồi quán lại tuệ quán, tức tâm quán. Tiếp tục như vậy theo các chặng tuổi đã phân định, khi thì quán sắc, khi thì quán tâm minh sát đã quán sắc ấy. Hãy quán kỹ lưỡng. Đối với các loại sắc khác cũng hiểu theo cùng cách.


<a id="M09-body-P105"></a>
## Quán theo từng bước và theo chuỗi tiếp nối
Miến / Burmese 105

3. Quán theo từng bước (satika)

Sau khi quán sắc từ lúc nhận lấy đến lúc đặt xuống là vô thường: 1. Dùng tâm thứ hai, tức lộ đổng lực ý môn minh sát thứ hai, để quán tâm thứ nhất đã quán như vậy, tức lộ đổng lực ý môn minh sát thứ nhất. 2. Dùng tâm thứ ba quán tâm thứ hai. 3. Dùng tâm thứ tư quán tâm thứ ba. 4. Dùng tâm thứ năm quán tâm thứ tư là vô thường. (Quán là khổ. Quán là vô ngã. Quán lần lượt từng tướng.)

Khi quán sắc từ lúc nhận lấy đến lúc đặt xuống là khổ và là vô ngã, hãy hiểu theo cùng phương pháp. Cũng hãy hiểu như vậy đối với các loại sắc bắt đầu bằng sắc theo sự trưởng thành và chấm dứt ở các lứa tuổi. Khi quán sắc theo từng cách trong bảy cách quán sắc, đối với mỗi trường hợp hãy quán những lộ đổng lực ý môn minh sát đã quán sắc ấy theo bốn bước, từng nhóm bốn bước. Đó chính là dùng lộ tâm minh sát sau để quán lộ tâm minh sát trước.

4. Quán theo chuỗi tiếp nối (paṭipāṭi)

Sau khi quán sắc từ lúc nhận lấy đến lúc đặt xuống là vô thường: 1. Dùng tâm thứ hai quán tâm thứ nhất đã quán như vậy là vô thường. 2. Dùng tâm thứ ba quán tâm thứ hai. 3. Dùng tâm thứ tư quán tâm thứ ba. 4. Dùng tâm thứ năm quán tâm thứ tư. 5. Dùng tâm thứ sáu quán tâm thứ năm. 6. Dùng tâm thứ bảy quán tâm thứ sáu,


<a id="M09-body-P106"></a>
## Quán tâm nối tiếp và từ bỏ tà kiến, ngã mạn
Miến / Burmese 106

7. Dùng tâm thứ tám quán tâm thứ bảy.

8. Dùng tâm thứ chín quán tâm thứ tám.

9. Dùng tâm thứ mười quán tâm thứ chín.

10. Dùng tâm thứ mười một quán tâm thứ mười. Cứ tuần tự quán là vô thường.

[Cũng nên tu tập thẩm sát là khổ và cũng nên tu tập thẩm sát là vô ngã. Hãy hiểu tương tự khi thẩm sát chính sắc thuộc nhóm có dưỡng chất là thứ tám (ojāṭṭhamakarūpa) là khổ hay vô ngã, và khi thẩm sát sắc thuộc nhóm có phong đại là thứ tám (vāyoaṭṭhamakarūpa), v.v., là vô thường, khổ hay vô ngã.]

5. Diṭṭhiugghāṭana — cách quán nhằm nhổ bỏ tà kiến. Khi nhiều lần quán minh sát các pháp hành theo tính vô ngã, tức là vô ngã, tà kiến được nhổ bỏ. Trí quán vô ngã, được nâng đỡ bởi năng lực cận y duyên mạnh mẽ của trí quán vô thường và trí quán khổ, có thể nhổ bỏ tà kiến, tức ngã kiến.

6. Mānugghāṭana — cách quán nhằm nhổ bỏ ngã mạn. Khi nhiều lần quán minh sát các pháp hành theo tính vô thường, tức là vô thường, ngã mạn được từ bỏ. Trí quán vô thường, được nâng đỡ bởi năng lực cận y duyên mạnh mẽ của trí quán khổ và trí quán vô ngã, có thể từ bỏ ngã mạn.


<a id="M09-body-P107"></a>
## 7. Làm cạn sự ưa thích
Miến / Burmese 107

7. Nikantipariyādāna — cách quán làm cạn ái luyến và ngăn nó sinh khởi. Khi nhiều lần quán minh sát các pháp hành theo tính khổ, tức là khổ, sự ưa thích vi tế gọi là ái sẽ cạn. Trí quán khổ nhận được sự nâng đỡ, trợ lực đặc biệt của cận y duyên mạnh mẽ từ trí quán vô thường và trí quán vô ngã, nên có thể làm cạn ái. Do đó ái không còn sinh khởi.

Điểm cần ghi nhớ. Nếu chỉ quán các pháp hành là vô ngã, trí quán vô ngã không thể nhổ bỏ tà kiến. Nếu chỉ quán là khổ, trí quán khổ không thể làm cạn ái. Nếu chỉ quán là vô thường, trí quán vô thường không thể nhổ bỏ ngã mạn. Hãy ghi nhớ rằng chỉ khi một trí quán được hai trí quán còn lại nâng đỡ thì trí quán ấy mới có thể nhổ bỏ hoặc đoạn trừ phiền não tương ứng. (Xem Visuddhi. 2.262–264 và Mahāṭī. 2.415–416.)

Theo các chỉ dẫn trên, thiện nhân hãy quán minh sát nhiều lần các pháp hành trong ba thời và hai dòng tương tục, luân phiên đặt chúng dưới ba đặc tướng theo cách phân thành hai là danh và sắc, cách phân thành năm uẩn, cách phân theo các chi duyên khởi, v.v. Sau đó, đối với các pháp hành ấy:

1. Có thể ưu tiên riêng đặc tướng vô ngã.

2. Có thể ưu tiên riêng đặc tướng vô thường.


<a id="M09-body-P108"></a>
## Ưu tiên một đặc tướng và đạt sự thuần thục
Miến / Burmese 108

3. Có thể ưu tiên riêng đặc tướng khổ.

Hãy quán minh sát nhiều lần theo ít nhất một trong ba cách ấy. Khi tri kiến quán vô ngã của hành giả đã chín muồi đối với các pháp hành trong ba thời quá khứ, vị lai và hiện tại, và hai dòng tương tục nội và ngoại, làm sao tưởng về một tự ngã trong các pháp hành ấy còn có chỗ nương đứng trong tri kiến ấy? Tương tự, khi tri kiến quán vô thường của hành giả đã chín muồi đối với các pháp hành ấy, làm sao tưởng chúng là thường còn có chỗ nương đứng trong tri kiến ấy? Cũng vậy, làm sao ngọn cờ ngã mạn vươn cao “ta, ta” còn có chỗ nương đứng? Ngọn cờ ngã mạn chỉ có thể xen vào một dòng tương tục có tưởng về sự thường còn.

Tương tự, trong dòng tương tục của hành giả có tri kiến quán khổ đã chín muồi đối với các pháp hành ấy, làm sao tưởng các pháp hành ấy là lạc còn có chỗ nương đứng? Ái và ưa thích bám víu vào các pháp hành ấy chỉ có thể tìm được chỗ nương đứng trong dòng tương tục có tưởng chúng là lạc. Vì vậy, ái và ưa thích không còn tìm được chỗ nương đứng trong dòng tương tục của thiện nhân có tri kiến quán khổ đã chín muồi.

Đã đạt sự thuần thục. Sattavato panassa rūpakammaṭṭhānepi arūpakammaṭṭhānepi paguṇaṃ hoti. (Visuddhi. 2.264.)


<a id="M09-body-P109"></a>
## Kết thúc chương Trí thẩm sát
Miến / Burmese 109

Khi hành giả có thể thành thạo tu tập cả phương pháp quán bảy cách đối với sắc và phương pháp quán bảy cách đối với vô sắc trong hai dòng tương tục nội và ngoại, hành giả đã có thể thực hành thành thạo cả đề mục sắc và đề mục danh.

Nếu có khả năng quán trong cả ba thời quá khứ, vị lai, hiện tại và cả hai dòng tương tục nội, ngoại, thì đó là sự tinh cần vượt mức thông thường.

Hết chương Trí thẩm sát (sammasanañāṇa).


<a id="M09-body-P110"></a>
## Chương Trí sinh diệt
Miến / Burmese 110

Chương Trí sinh diệt (udayabbayañāṇa)


<a id="M09-body-P111"></a>
## Trí sinh diệt theo cách phân danh sắc và năm uẩn
Miến / Burmese 111

Đối tượng của trí sinh diệt là các uẩn, xứ, giới, đế và các chi duyên khởi. Trong các chi duyên khởi, chỉ những chi từ vô minh đến hữu là đối tượng của trí quán sinh diệt. (Paṭisaṃ. 52.)

Thiện nhân muốn phát triển trí sinh diệt trước hết hãy quán trong hiện tại:

1. Riêng sắc (luân phiên nội và ngoại).

2. Riêng danh (luân phiên nội và ngoại).

3. Danh và sắc cùng nhau (luân phiên nội và ngoại).

Hãy nhiều lần quán minh sát, khi thì đặt dưới đặc tướng vô thường, khi thì dưới đặc tướng khổ, khi thì dưới đặc tướng vô ngã. Như đã trình bày trong các bảng thuộc phần đề mục danh, trong từng hàng của cả sáu loại lộ tâm, bắt đầu với lộ nhãn môn, khi quán riêng sắc cũng như khi quán riêng danh, hãy quán đến khi tri kiến đạt tới hiện tại sát-na. Cũng vậy, trong từng hàng trình bày ở các bảng thuộc phần đề mục danh, theo cách phân năm uẩn…


<a id="M09-body-P112"></a>
## Quán năm uẩn trong ba thời, nội và ngoại
Miến / Burmese 112

1. Riêng sắc.

2. Riêng thọ.

3. Riêng tưởng.

4. Riêng hành.

5. Riêng thức.

Khi thì đặt dưới đặc tướng vô thường, khi thì dưới đặc tướng khổ, khi thì dưới đặc tướng vô ngã, hãy nhiều lần quán minh sát cho đến hiện tại sát-na. Quán luân phiên nội và ngoại.

Tương tự, đối với các chi duyên khởi là vô minh, hành, thức, danh sắc, sáu xứ, xúc, thọ, ái, thủ và hữu (= nghiệp hữu + sinh hữu), lúc này chỉ lấy sự sinh diệt của chính các chi ấy làm cảnh. Chưa cần phân theo nhân và quả. Lần lượt đặt chúng dưới ba đặc tướng rồi quán minh sát. Hãy quán đến hiện tại sát-na.

Quá khứ – vị lai – hiện tại – nội – ngoại. Khi có thể quán minh sát nhiều lần các pháp hành ấy trong hiện tại cho đến hiện tại sát-na, trí đã trong sáng. Khi ấy, hãy quán từ các đời quá khứ nối tiếp mà mình đã quán đến hiện tại, và từ hiện tại đến tận vị lai:

1. Riêng sắc.

2. Riêng danh.

3. Danh và sắc cùng nhau. Lại nữa:

1. Riêng sắc.

2. Riêng thọ.


<a id="M09-body-P113"></a>
## Cách tu tập trí sinh diệt rộng
Miến / Burmese 113

3. Riêng tưởng.

4. Riêng hành.

5. Riêng thức.

Theo cách phân hai là danh sắc và cách phân năm uẩn như vậy, hãy quán minh sát nhiều lần, luân phiên nội và ngoại:

1. Khi thì đặt dưới đặc tướng vô thường.

2. Khi thì đặt dưới đặc tướng khổ.

3. Khi thì đặt dưới đặc tướng vô ngã.

Cần quán vô thường nhiều lần, quán khổ nhiều lần, quán vô ngã nhiều lần. Sau khi đã quán nhiều lần, có thể ưu tiên đặc tướng mình quán rõ nhất và quán một thời gian khá lâu. Khi đã đạt mức thuần thục, khi sự sinh diệt của các pháp hành ấy hiện ra hết sức rõ ràng và nhanh chóng trong trí, cho đến hiện tại sát-na, có thể chuyển sang cách tu tập trí sinh diệt rộng.

1. Samudayadhammānupassī = udayadassana — cách quán riêng sự sinh. Trong phần thực hành của Mahāsatipaṭṭhānasutta, Đức Phật dạy quán theo ba cách ở mỗi niệm xứ:

1. Samudayadhammānupassī — quán tính sinh khởi.

2. Vayadhammānupassī — quán tính hoại diệt.

3. Samudayavayadhammānupassī — quán tính sinh khởi và hoại diệt. Ý nghĩa của lời chỉ dạy ấy cũng…


<a id="M09-body-P114"></a>
## Quán sự sinh khởi của sắc uẩn
Miến / Burmese 114

…được Tôn giả Sāriputta, bậc đại tướng Chánh pháp, trình bày trong chính văn Paṭisambhidāmagga, bắt đầu bằng “Avijjāsamudayā rūpasamudayo — do vô minh sinh khởi, sắc sinh khởi.” Theo những lời chỉ dạy ấy, hành giả hãy tu tập cách quán trí sinh diệt rộng.

Ở đây trình bày mẫu quán sắc uẩn và bốn danh uẩn, bắt đầu bằng thọ uẩn lúc tái tục. Thiện nhân đã thành thạo cách quán mối liên hệ nhân quả, tức pháp duyên khởi theo phương pháp thứ nhất, sẽ có thể áp dụng tương tự để quán năm uẩn có trong từng sát-na tâm còn lại, tức từng sát-na tâm được trình bày trong các bảng của phần đề mục danh. Cần thấy rõ bằng trí và quán mối liên hệ nhân quả ở đây theo mô hình của phương pháp duyên khởi thứ nhất.

Sắc uẩn

1. Do vô minh (20) sinh khởi, sắc tái tục (do nghiệp sinh) sinh khởi.

2. Do ái (20) sinh khởi, ″.

3. Do thủ (20) sinh khởi, ″.

4. Do hành (34) sinh khởi, ″.

5. Do nghiệp (= năng lực nghiệp của 34) sinh khởi, sắc tái tục (do nghiệp sinh) sinh khởi.

* Tính sinh khởi của sắc do nghiệp sinh lúc tái tục.

6. Do tâm sinh khởi, sắc do tâm sinh sinh khởi.

* Tính sinh khởi của sắc do tâm sinh.

7. Do thời tiết sinh khởi, sắc do thời tiết sinh sinh khởi.


<a id="M09-body-P115"></a>
## Sắc do thời tiết và vật thực sinh, thọ và tưởng lúc tái tục
Miến / Burmese 115

* Tính sinh khởi của sắc do thời tiết sinh.

8. Do vật thực sinh khởi, sắc do vật thực sinh sinh khởi.

* Tính sinh khởi của sắc do vật thực sinh.

[Ghi chú. Ở sát-na tái tục chỉ có sắc do nghiệp sinh. Đặc biệt, vào tiểu sát-na sinh của tái tục chỉ có sắc do nghiệp sinh. Sắc do tâm, thời tiết và vật thực sinh chưa có. Chúng được nêu ở đây cho sắc uẩn có ở những sát-na tâm về sau.]

Thọ uẩn lúc tái tục

1. Do vô minh (20) sinh khởi, thọ lúc tái tục sinh khởi.

2. ái (20)  ″  ″

3. thủ (20)  ″  ″

4. hành (34)  ″  ″

5. Do nghiệp (= năng lực nghiệp của 34) sinh khởi, thọ lúc tái tục sinh khởi.

6. vật (= sắc ý vật)  ″  ″

7. cảnh (= cảnh của tâm tái tục)  ″  ″

8. xúc (= 34 − thọ = 33)  ″  ″

* Tính sinh khởi của thọ lúc tái tục.

Tưởng uẩn lúc tái tục

1. Do vô minh (20) sinh khởi, tưởng lúc tái tục sinh khởi.

2. ái (20)  ″  ″

3. thủ (20)  ″  ″

4. hành (34)  ″  ″


<a id="M09-body-P116"></a>
## Tưởng uẩn và hành uẩn lúc tái tục
Miến / Burmese 116

5. Do nghiệp (= năng lực nghiệp của 34) sinh khởi, tưởng lúc tái tục sinh khởi.

6. vật (= sắc ý vật)  ″  ″

7. cảnh (= cảnh của tâm tái tục)  ″  ″

8. xúc (= 34 − tưởng = 33)  ″  ″

* Tính sinh khởi của tưởng lúc tái tục.

Hành uẩn lúc tái tục (= tư)

1. Do vô minh (20) sinh khởi, hành lúc tái tục sinh khởi.

2. ái (20)  ″  ″

3. thủ (20)  ″  ″

4. hành (34)  ″  ″

5. Do nghiệp (= năng lực nghiệp của 34) sinh khởi, hành lúc tái tục sinh khởi.

6. vật (= sắc ý vật)  ″  ″

7. cảnh (= cảnh của tâm tái tục)  ″  ″

8. xúc (= 34 − tư = 33)  ″  ″

* Tính sinh khởi của hành lúc tái tục.

Hành uẩn lúc tái tục (= 34 − thọ, tưởng và thức = 31)

1. Do vô minh (20) sinh khởi, hành lúc tái tục sinh khởi.

2. ái (20)  ″  ″

3. thủ (20)  ″  ″

4. hành (34)  ″  ″

5. Do nghiệp (= năng lực nghiệp của 34) sinh khởi, hành lúc tái tục sinh khởi.

6. vật (= sắc ý vật)  ″  ″

7. cảnh (= cảnh của tâm tái tục)  ″  ″


<a id="M09-body-P117"></a>
## Hành uẩn và thức uẩn lúc tái tục
Miến / Burmese 117

8. ba danh uẩn còn lại  ″  ″

* Tính sinh khởi của hành lúc tái tục.

[Ba danh uẩn còn lại là thọ uẩn, tưởng uẩn và thức uẩn. Về danh pháp, trong 34 pháp, 31 tâm sở ngoài ba uẩn ấy thuộc về phía quả. Xúc cũng có trong số đó. Vì vậy chỉ ba pháp còn lại, thọ, tưởng và thức, ở phía nhân.]

Thức uẩn lúc tái tục

1. Do vô minh (20) sinh khởi, thức lúc tái tục sinh khởi.

2. ái (20)  ″  ″

3. thủ (20)  ″  ″

4. hành (34)  ″  ″

5. nghiệp (= năng lực nghiệp của 34)  ″  ″

6. danh sắc  ″  ″

* Tính sinh khởi của thức lúc tái tục.

Danh = các tâm sở tương ưng (= 33).

Sắc = sắc ý vật trong 30 sắc + sắc làm cảnh.

Cứ theo phương pháp này, hãy quán năm uẩn ở từng sát-na tâm được trình bày trong các bảng phần đề mục danh: năm uẩn lúc hữu phần, năm uẩn lúc tử, năm uẩn lúc hướng tâm ngũ môn, năm uẩn lúc nhãn thức, v.v. Cách quán này không khó đối với những thiện nhân đã thành thạo nhận diện nhân và quả theo phương pháp duyên khởi thứ nhất.


<a id="M09-body-P118"></a>
## 2. Quán riêng sự hoại diệt
Miến / Burmese 118

Điểm cần ghi nhớ. Con số 20 ghi cho vô minh, ái và thủ chỉ là một mẫu. Con số 34 ghi cho hành cũng chỉ là một mẫu. Hãy nhận diện và tu tập đúng theo những gì đã sinh, đang sinh và sẽ sinh trong dòng danh sắc của mình. Số tâm và tâm sở có thể thay đổi. Các hành có thể thay đổi giữa thiện và bất thiện. Hãy quán từ các đời quá khứ nối tiếp đến tận vị lai, trong phạm vi có thể quán được.

2. Vayadhammānupassī = vayadassana — cách quán riêng sự hoại diệt.

Avijjānirodhā rūpanirodhoti paccayanirodhena rūpakkhandhassa vayaṃ passati. (Paṭisaṃ. 54.)

Avijjānirodhā rūpanirodhoti aggamaggakkhaṇena avijjāya anuppādanirodhato anāgatassa rūpassa anuppādanirodho hoti paccayābhāve abhāvato. (Mahāṭī. 2.421.)

Hành giả đã dùng tuệ nhãn minh sát thấy thật rõ sự sinh khởi của các quả như sắc do các nhân như vô minh sinh khởi. Khi các nhân như vô minh chấm dứt do A-la-hán đạo, không sinh lại nữa, tức chấm dứt theo tính diệt do không sinh lại (anuppādanirodha), thì các quả như sắc cũng chấm dứt và không sinh lại theo tính ấy. Nếu hướng trí minh sát về tương lai, quán các sát-na của A-la-hán đạo và thời kỳ sau tâm tử lúc viên tịch, hành giả sẽ dễ thấy điều ấy. Ở đây, thiện nhân cũng cần biết về…


<a id="M09-body-P119"></a>
## Diệt sau khi sinh và diệt do không sinh lại
Miến / Burmese 119

…diệt sau khi sinh (uppādanirodha) và diệt do không sinh lại (anuppādanirodha).

Uppādanirodha. Các pháp hành làm nhân và các pháp hành làm quả đều là các pháp hành diệt sau khi đã sinh. Vì tính vô thường, các pháp hành ấy vừa mới sinh liền diệt, ngay ở hiện tại sát-na. Sự sinh rồi diệt ấy được gọi là diệt sau khi sinh. Bao lâu các nhân còn tiếp tục trợ lực, các quả cũng tiếp tục nối nhau trong suốt thời gian ấy, tức sinh rồi diệt theo tính diệt sau khi sinh. (Hãy ghi nhớ rằng các nhân cũng là các pháp hành làm quả sinh do những nhân tương ứng của chúng.) Vì đã diệt mà các nhân vẫn còn, chúng lại sinh rồi diệt. Do tính chất ấy, đây được gọi là diệt sau khi sinh, tức sự diệt vẫn còn có lần sinh sau. Cũng thường gọi là diệt từng sát-na (khaṇikanirodha).

Anuppādanirodha. Dự lưu đạo, Nhất lai đạo và Bất lai đạo đoạn trừ không dư sót các phiền não tương ứng. Trí A-la-hán đạo, gọi là đạo tối thượng (aggamagga), đoạn trừ không dư sót các phiền não còn lại, như vô minh. Khi các trí Thánh đạo, cho đến trí A-la-hán đạo, đã đoạn trừ không dư sót các phiền não tương ứng, những phiền não ấy tuyệt nhiên không còn cơ hội sinh lại trong dòng danh sắc. Chúng chấm dứt hoàn toàn, không dư sót, theo cách diệt rồi không sinh lại. Sự chấm dứt không sinh lại như thế được gọi là anuppādanirodha.


<a id="M09-body-P120"></a>
## Quán sự diệt do không sinh lại của sắc uẩn
Miến / Burmese 120

Khi các nhân như vô minh đã chấm dứt theo tính diệt do không sinh lại, tức anuppādanirodha, thì các quả như sắc, vốn có thể tiếp tục sinh khởi trong tương lai sau tâm tử lúc viên tịch nếu nhân vẫn còn, cũng không còn cơ hội tiếp tục sinh. Chúng chấm dứt theo tính diệt do không sinh lại. Điều này cũng được gọi là anuppādanirodha. Chúng chấm dứt vì khi các nhân vắng mặt, các quả cũng vắng mặt.

Hành giả nên hướng trí minh sát về tương lai cho đến A-la-hán đạo mà mình sẽ đạt và về tương lai cho đến tâm tử lúc viên tịch, rồi dùng trí minh sát quán cho thấy rõ tính diệt do không sinh lại ấy. Khi đã thực sự thấy bằng tuệ nhãn minh sát rằng vì các nhân chấm dứt theo tính diệt do không sinh lại, các quả cũng chấm dứt theo tính diệt do không sinh lại, hãy tiếp tục theo cách quán dưới đây.

Cách quán sắc uẩn

1. Do vô minh diệt, sắc (do nghiệp sinh) diệt.

2. Do ái diệt, sắc (do nghiệp sinh) diệt.

3. Do thủ diệt, sắc (do nghiệp sinh) diệt.

4. Do hành diệt, sắc (do nghiệp sinh) diệt.

5. Do nghiệp diệt, sắc (do nghiệp sinh) diệt.

[Ở đây là diệt do không sinh lại. Sắc vị lai chấm dứt vì diệt rồi không sinh lại.]


<a id="M09-body-P121"></a>
## Quán sự diệt của sắc
Miến / Burmese 121

* Tính diệt của sắc do nghiệp sinh là tính hoại diệt. (Uppādanirodha.)

6. Do tâm diệt, sắc do tâm sinh diệt. (Anuppādanirodha.)

* Tính diệt của sắc do tâm sinh là tính hoại diệt. (Uppādanirodha.)

7. Do nhiệt độ diệt, sắc do nhiệt độ sinh diệt. (Anuppādanirodha.)

* Tính diệt của sắc do nhiệt độ sinh là tính hoại diệt. (Uppādanirodha.)

8. Do vật thực diệt, sắc do vật thực sinh diệt. (Anuppādanirodha.)

* Tính diệt của sắc do vật thực sinh là tính hoại diệt. (Uppādanirodha.)

Người mới hành thiền phải quán cho biết rõ hai loại diệt trong cách quán này: anuppādanirodha, sự diệt mà sau đó không còn sinh trở lại, và uppādanirodha, sự diệt mà sau đó còn sinh trở lại. Trong Chánh tạng Paṭisambhidāmagga (53), uppādanirodha được gọi là vipariṇāmalakkhaṇa, đặc tướng biến đổi. Đó là sự tan rã ở sát-na diệt của các pháp hữu vi. Với cách quán này cũng vậy, trong cả sáu nhóm, bắt đầu từ nhóm cảnh sắc, hãy chia thành năm uẩn ở từng nhóm tâm đã trình bày trong các bảng ở phần đề mục danh (như đã trình bày ở phương pháp thứ nhất về duyên khởi), và quán đầy đủ các lộ tốc hành thiện và bất thiện. Hãy quán khi thì bên trong, khi thì bên ngoài. Để có mẫu cho phương diện danh uẩn trong cách quán ấy, sau đây trình bày một cách quán thọ uẩn thuộc nhãn thức.


<a id="M09-body-P122"></a>
## Cách quán thọ uẩn thuộc nhãn thức
Miến / Burmese 122

1. Do vô minh diệt, thọ thuộc nhãn thức diệt.

2. Do ái diệt, thọ thuộc nhãn thức diệt.

3. Do thủ diệt, thọ thuộc nhãn thức diệt.

4. Do hành diệt, thọ thuộc nhãn thức diệt.

5. Do nghiệp diệt, thọ thuộc nhãn thức diệt.

6. Do nhãn vật diệt, thọ thuộc nhãn thức diệt.

7. Do cảnh sắc diệt, thọ thuộc nhãn thức diệt.

8. Do nhãn xúc (= 7) diệt, thọ thuộc nhãn thức diệt.

9. Do ánh sáng diệt, thọ thuộc nhãn thức diệt.

10. Do tác ý diệt, thọ thuộc nhãn thức diệt. (Anuppādanirodha.)

* Tính diệt của thọ thuộc nhãn thức là tính hoại diệt. (Uppādanirodha.)

Tùy khả năng của mình, hãy quán theo cùng mẫu từ các đời quá khứ liên tiếp cho đến cuối các đời vị lai.

3. Samudayavayadhammānupassī — tùy quán tính sinh và diệt

Udayavayadassana — cách quán thấy sinh diệt.

Samudayadhammānupassī vā kāyasmiṃ viharati, vayadhammānupassī vā kāyasmiṃ viharati, samudayavayadhammānupassī vā kāyasmiṃ viharati. (Mahāsatipaṭṭhānasutta, Mahā. 173.)

Avijjāsamudayā rūpasamudayoti, pe, avijjānirodhā rūpanirodho. (Paṭis. 53, 54.)


<a id="M09-body-P123"></a>
## Quán sinh diệt của sắc uẩn
Miến / Burmese 123

Tesaṃ vasena evaṃ rūpassa udayo, evaṃ rūpassa vayo, evaṃ rūpaṃ udeti, evaṃ rūpaṃ vetīti paccayato ceva khaṇato ca vitthārena manasikāraṃ karoti. (Vism. 2, 267.)

Theo lời chỉ dẫn trong Chánh tạng Pāli và Chú giải như vậy, hiền giả đang thực hành phương pháp tu tập chi tiết tuệ sinh diệt cần nhìn bằng tuệ minh sát cho thấy rõ quả sinh do nhân sinh và quả diệt do nhân diệt, rồi tu tập lặp đi lặp lại, nối nhân với quả. Để quán như vậy:

Sapaccayanāmarūpadassanaṃ tilakkhaṇaṃ āropetvā vipassanāpaṭipāṭiyā “aniccaṃ dukkhaṃ anattā”ti sammasanto vicarati. (Ma. A. 1, 281.)

Theo các chỉ dẫn của Chú giải như vậy, cần lần lượt áp dụng ba đặc tướng cho cả nhân và quả để quán minh sát. Do đó, ở đây trình bày cách quán minh sát nối nhân với quả và áp dụng đặc tướng vô thường. Đối với cách quán minh sát áp dụng riêng đặc tướng khổ và đặc tướng vô ngã, hãy hiểu theo cùng một cách.

Thấy sự sinh và diệt của sắc uẩn

1. Do vô minh sinh, sắc do nghiệp sinh sinh. Do vô minh diệt, sắc do nghiệp sinh diệt.

Vô minh — (sinh–diệt) vô thường. Sắc do nghiệp sinh — (sinh–diệt) vô thường.

2. Do ái sinh, sắc do nghiệp sinh sinh. Do ái diệt, sắc do nghiệp sinh diệt.


<a id="M09-body-P124"></a>
## Sinh diệt của sắc uẩn và thọ thuộc nhãn thức
Miến / Burmese 124

Ái — (sinh–diệt) vô thường. Sắc do nghiệp sinh — (sinh–diệt) vô thường.

3. Do thủ sinh, sắc do nghiệp sinh sinh. Do thủ diệt, sắc do nghiệp sinh diệt.

Thủ — (sinh–diệt) vô thường. Sắc do nghiệp sinh — (sinh–diệt) vô thường.

4. Do hành sinh, sắc do nghiệp sinh sinh. Do hành diệt, sắc do nghiệp sinh diệt.

Hành — (sinh–diệt) vô thường. Sắc do nghiệp sinh — (sinh–diệt) vô thường.

5. Do nghiệp sinh, sắc do nghiệp sinh sinh. Do nghiệp diệt, sắc do nghiệp sinh diệt.

Nghiệp (= tư) — (sinh–diệt) vô thường. Sắc do nghiệp sinh — (sinh–diệt) vô thường.

6. Do tâm sinh, sắc do tâm sinh sinh. Do tâm diệt, sắc do tâm sinh diệt.

Tâm — (sinh–diệt) vô thường. Sắc do tâm sinh — (sinh–diệt) vô thường.

7. Do nhiệt độ sinh, sắc do nhiệt độ sinh sinh. Do nhiệt độ diệt, sắc do nhiệt độ sinh diệt.

Nhiệt độ — (sinh–diệt) vô thường. Sắc do nhiệt độ sinh — (sinh–diệt) vô thường.

8. Do vật thực sinh, sắc do vật thực sinh sinh. Do vật thực diệt, sắc do vật thực sinh diệt.

Vật thực — (sinh–diệt) vô thường. Sắc do vật thực sinh — (sinh–diệt) vô thường.

Cách quán thọ uẩn thuộc nhãn thức

1. Do vô minh sinh, thọ thuộc nhãn thức sinh. Do vô minh diệt, thọ thuộc nhãn thức diệt.

Vô minh — (sinh–diệt) vô thường. Thọ thuộc nhãn thức — (sinh–diệt) vô thường.


<a id="M09-body-P125"></a>
## Sinh diệt của thọ thuộc nhãn thức
Miến / Burmese 125

2. Do ái sinh, thọ thuộc nhãn thức sinh. Do ái diệt, thọ thuộc nhãn thức diệt.

Ái — (sinh–diệt) vô thường. Thọ thuộc nhãn thức — (sinh–diệt) vô thường.

3. Do thủ sinh, thọ thuộc nhãn thức sinh. Do thủ diệt, thọ thuộc nhãn thức diệt.

Thủ — (sinh–diệt) vô thường. Thọ thuộc nhãn thức — (sinh–diệt) vô thường.

4. Do hành sinh, thọ thuộc nhãn thức sinh. Do hành diệt, thọ thuộc nhãn thức diệt.

Hành — (sinh–diệt) vô thường. Thọ thuộc nhãn thức — (sinh–diệt) vô thường.

5. Do nghiệp sinh, thọ thuộc nhãn thức sinh. Do nghiệp diệt, thọ thuộc nhãn thức diệt.

Nghiệp (= tư) — (sinh–diệt) vô thường. Thọ thuộc nhãn thức — (sinh–diệt) vô thường.

6. Do nhãn vật sinh, thọ thuộc nhãn thức sinh. Do nhãn vật diệt, thọ thuộc nhãn thức diệt.

Nhãn vật — (sinh–diệt) vô thường. Thọ thuộc nhãn thức — (sinh–diệt) vô thường.

7. Do cảnh sắc sinh, thọ thuộc nhãn thức sinh. Do cảnh sắc diệt, thọ thuộc nhãn thức diệt.

Cảnh sắc — (sinh–diệt) vô thường. Thọ thuộc nhãn thức — (sinh–diệt) vô thường.


<a id="M09-body-P126"></a>
## Sinh diệt của thọ và lời giải thích
Miến / Burmese 126

8. Do nhãn xúc sinh, thọ thuộc nhãn thức sinh. Do nhãn xúc diệt, thọ thuộc nhãn thức diệt.

Nhãn xúc — (sinh–diệt) vô thường. Thọ thuộc nhãn thức — (sinh–diệt) vô thường.

9. Do ánh sáng sinh, thọ thuộc nhãn thức sinh. Do ánh sáng diệt, thọ thuộc nhãn thức diệt.

Ánh sáng — (sinh–diệt) vô thường. Thọ thuộc nhãn thức — (sinh–diệt) vô thường.

10. Do tác ý (= hướng ngũ môn — 11) sinh, thọ thuộc nhãn thức sinh. Do tác ý diệt, thọ thuộc nhãn thức diệt.

Tác ý — (sinh–diệt) vô thường. Thọ thuộc nhãn thức — (sinh–diệt) vô thường.

Lời giải thích

Đối với hiền giả đã thành thạo và thỏa đáng trong phương pháp thứ nhất về duyên khởi, chừng ấy cũng đủ để nắm cách quán này. Hãy chia thành năm uẩn trong từng nhóm tâm đã trình bày ở các bảng phần đề mục danh, và quán theo phương pháp tu tập tuệ sinh diệt chi tiết này.

Trong các cách quán này, cũng có thể dùng tuệ minh sát nhìn cho thấy rõ sự liên hệ nhân quả giữa các nhân của đời quá khứ thứ nhất và các quả hiện tại. Cũng có thể quán các nhân của đời quá khứ thứ hai với các quả của đời quá khứ thứ nhất, và sự liên hệ nhân quả giữa các nhân hiện tại và các quả vị lai,


<a id="M09-body-P127"></a>
## Nhân quả trong các đời quá khứ và vị lai
Miến / Burmese 127

dùng tuệ minh sát nhìn cho thấy rõ. Theo cách đã trình bày trong phương pháp thứ nhất ở phần duyên khởi, dùng tuệ minh sát nhìn cho thấy rõ sự liên hệ nhân quả giữa các nhân và quả tương ứng. Đây là các cách quán có thể áp dụng cho bao nhiêu đời quá khứ và vị lai liên tiếp mà mình đã nhận diện được.

Cũng có thể quán bằng cách chia thành hai nhóm như sau: nhóm vô minh, ái và thủ cùng thuộc phiền não luân, và nhóm hành và nghiệp cùng thuộc nghiệp luân.

Nếu các nhân ấy thuộc đời quá khứ thứ nhất thì trước tiên hãy nhận diện tâm hữu phần trong sáng, tức ý môn, của đời quá khứ thứ nhất. Sau đó dùng tuệ minh sát quán cho thấy rõ sự sinh diệt, tức tính vô thường, của các nhân ấy sinh xen giữa các tâm hữu phần trong sáng đó. Hãy hiểu tương tự với các đời quá khứ và vị lai liên tiếp. Như đã trình bày trong phần duyên khởi, vô minh, ái và thủ:

Hướng ý môn (1) | Tốc hành (7) | Na cảnh có hỷ (2) | / Na cảnh không hỷ (2)
12 | 34 | 34 | / 12

thường sinh trong lộ ý môn như vậy. Có lộ tương ưng hỷ, cũng có lộ không tương ưng hỷ. Có lộ có na cảnh, cũng có lộ không có. Đôi khi có thể có na cảnh không hỷ, cũng có thể có na cảnh có hỷ, tùy trường hợp. Đối với hiền giả còn là phàm nhân, vô minh, ái và thủ thường


<a id="M09-body-P128"></a>
## Các lộ ý môn và sự phân biệt hành với nghiệp
Miến / Burmese 128

là các tốc hành thuộc nhóm tham đi kèm tà kiến. Hãy dùng tuệ minh sát nhìn cho thấy rõ tính vô thường của các danh pháp có mặt trong lộ ấy, sự sinh diệt cho đến hiện tại sát-na, tức sự sinh diệt ở từng nhóm tâm. Hãy lần lượt áp dụng ba đặc tướng mà quán minh sát. Còn nhóm hành và nghiệp thường sinh theo trình tự lộ dưới đây.

Hướng ý môn (1) | Tốc hành (7) | Na cảnh có hỷ (2) | / Na cảnh không hỷ (2)
12 | 34 | 34 | / 12

Trong lộ ý môn này, nếu là tâm đại thiện câu hữu hỷ, tương ưng trí, thì có cả hỷ và tuệ. Có 34 danh pháp. Nếu là tâm câu hữu xả, tương ưng trí, thì có tuệ và không có hỷ. Có 33 danh pháp. Có thể có na cảnh hoặc không. Có thể có na cảnh có hỷ hoặc na cảnh không hỷ, tùy trường hợp. Hãy dùng tuệ nhìn cho thấy rõ sự sinh diệt của các danh pháp thuộc hành và nghiệp ấy trong từng nhóm tâm, cho đến hiện tại sát-na. Hãy lần lượt áp dụng ba đặc tướng mà quán minh sát.

Hành và năng lực nghiệp

Năng lực nghiệp là pháp không thích hợp để áp dụng đặc tướng mà quán minh sát. Khi áp dụng đặc tướng để quán minh sát, hãy lấy nhóm hành thiện làm chính. Nói lấy nhóm ấy làm chính là nói riêng đối với loài người. Vì vậy cũng nên biết sự phân biệt giữa hành có thể quán minh sát và năng lực nghiệp. Nếu làm một việc thiện bố thí làm ví dụ,


<a id="M09-body-P129"></a>
## Hành, năng lực nghiệp và các nhóm cần quán
Miến / Burmese 129

xin trình bày như sau:

1. Trước khi cho: tư sinh trước khi làm việc thiện, tức tư trước (pubbacetanā), là hành. Trong khi cho: tư sinh lúc thực hiện việc thiện, tức tư lúc buông vật thí (muñcacetanā), là năng lực nghiệp.

2. Trong bảy tốc hành sinh khi đang tạo nghiệp, tư đi cùng các tốc hành từ thứ nhất đến thứ sáu là hành. Tư ở tốc hành thứ bảy là năng lực nghiệp.

3. Trong các nhóm tâm tốc hành sinh khi đang tạo nghiệp, tư là năng lực nghiệp. Nhóm các pháp tương ưng đi cùng là hành. (Vism. 2, 250–251.)

Theo các cách phân chia đã quy định trên, hãy quán gộp bằng minh sát tất cả danh pháp ở từng nhóm tâm trong trọn dòng lộ tâm tốc hành thiện qua ý môn đã sinh hoặc sẽ sinh lúc tạo nghiệp, cho đến hiện tại sát-na. Nếu có thể quán như vậy, hãy hiểu rằng mình đã quán minh sát cả hành và năng lực nghiệp.

Hãy quán minh sát tất cả

Năm uẩn tái tục, năm uẩn hữu phần, năm uẩn tử tâm, năm uẩn hướng ý môn, năm uẩn nhãn thức v.v. Trong mỗi nhóm tâm hiện diện trong các lộ như lộ nhãn môn, như đã trình bày trong các bảng ở phần đề mục danh, hãy chia thành năm uẩn và quán minh sát như trên. Hãy quán cả hai dòng tương tục bên trong và bên ngoài. Khi quán như vậy:


<a id="M09-body-P130"></a>
## Duyên khởi, phương pháp thứ nhất
Miến / Burmese 130

1. Có thể quán bằng cách nối nhân quả giữa quá khứ và hiện tại.

2. Có thể quán bằng cách nối nhân quả giữa các đời quá khứ.

3. Có thể quán bằng cách nối nhân quả giữa hiện tại và vị lai.

4. Có thể quán bằng cách nối nhân quả giữa các đời vị lai.

Duyên khởi, phương pháp thứ nhất

Nāyaṃ, bhikkhave, kāyo tumhākaṃ, napi aññesaṃ. Purāṇamidaṃ, bhikkhave, kammaṃ abhisaṅkhataṃ abhisañcetayitaṃ vedaniyaṃ daṭṭhabbaṃ.

Tatra kho, bhikkhave, sutavā ariyasāvako paṭiccasamuppādaññeva sādhukaṃ yoniso manasi karoti — “Iti imasmiṃ sati idaṃ hoti, imassuppādā idaṃ uppajjati. Imasmiṃ asati idaṃ na hoti, imassa nirodhā idaṃ nirujjhati. Yadidaṃ avijjāpaccayā saṅkhārā, saṅkhārapaccayā viññāṇaṃ, pe, evametassa kevalassa dukkhakkhandhassa samudayo hoti. Avijjāya tveva asesavirāganirodhā saṅkhāranirodho, saṅkhāranirodhā viññāṇanirodho, pe, evametassa kevalassa dukkhakkhandhassa nirodho hotī”ti. (Saṃ. 1, 295, Natumhasutta.)

Này các Tỳ-khưu … thân sắc và thân danh này, tức toàn thể sắc pháp và danh pháp, chẳng thuộc sở hữu của các con (nghĩa là chẳng phải tự ngã của các con, vì chẳng có tự ngã nào), cũng chẳng thuộc sở hữu của người khác (chẳng phải tự ngã của người khác). Thân sắc và thân danh này là các pháp do cái cũ, cái trước kia, tạo nên. Các pháp ấy do nghiệp thiện và nghiệp bất thiện tạo tác, có tư thiện hay tư bất thiện làm nhân gốc, và là chỗ nương cho cảm thọ.


<a id="M09-body-P131"></a>
## Công thức duyên khởi
Miến / Burmese 131

Này các Tỳ-khưu … ở đây vị Thánh đệ tử có kiến văn nhờ nghe học (āgamasuta) và nhờ thực hành (adhigamasuta), hay vị đệ tử của Như Lai là bậc Thánh, khéo tác ý và tu tập chính các pháp duyên khởi, tức sự nối tiếp nhân quả:

«Khi nhân này hiện hữu thì quả này hiện hữu và sinh khởi. Do nhân này hiện hữu và sinh khởi, quả này hiện hữu và sinh khởi. Khi nhân này không hiện hữu thì quả này không hiện hữu. Do nhân này diệt, quả này diệt. Sự nối tiếp nhân quả, tức các pháp duyên khởi ấy, như sau:

Do vô minh sinh, các hành sinh. Do các hành sinh, thức (quả) sinh. pe. Như vậy, cả khối khổ thuần túy này, không xen lẫn an lạc, hiện hữu và sinh khởi.» Vị ấy quán như vậy.

«Do chính vô minh diệt không dư sót (nhờ Thánh đạo A-la-hán), các hành diệt. Do các hành diệt, thức (quả) diệt. pe. Như vậy là sự tịch diệt của cả khối khổ thuần túy, không xen lẫn an lạc.» Vị ấy quán như vậy. (Saṃ. 1, 295.)

Theo những lời dạy như vậy, người mới hành thiền cũng có thể quán theo phương pháp thứ nhất về duyên khởi, quán riêng sinh, riêng diệt, hoặc cả sinh và diệt. Hãy quán như vậy.


<a id="M09-body-P132"></a>
## Tùy quán tính sinh và tùy quán tính diệt
Miến / Burmese 132

Samudayadhammānupassī — tùy quán tính sinh

1. Do vô minh sinh, hành sinh.

2. Do hành sinh, thức tái tục sinh. Do hành sinh, thức hữu phần sinh. Do hành sinh, thức tử sinh. Do hành sinh, nhãn thức sinh. pe.

Như đã trình bày trong phương pháp thứ nhất về duyên khởi, dùng tuệ nhìn cho thấy rõ sự nối tiếp nhân quả và chỉ quán riêng tính sinh. Hãy quán cả hai dòng tương tục bên trong và bên ngoài. Hãy quán nối nhân với quả trong từng bộ ba đời, từ các đời quá khứ liên tiếp đến hiện tại, và từ hiện tại đến cuối các đời vị lai. Người mới hành thiền đã thỏa đáng trong việc thấy sự nối tiếp nhân quả theo phương pháp thứ nhất về duyên khởi sẽ không còn thấy khó.

Vayadhammānupassī — tùy quán tính diệt

Người mới hành thiền đã có tuệ trong sáng về sự nối tiếp nhân quả, như hành sinh do vô minh sinh, cho đến đời cuối cùng trong vị lai, hãy dùng tuệ minh sát nhìn cho thấy rõ rằng vào thời điểm vị lai khi sẽ đạt tuệ Thánh đạo A-la-hán, do Thánh đạo A-la-hán ấy, theo lối quán thuận, tất cả phiền não như vô minh sẽ tịch diệt, không sinh trở lại. Vì sự tịch diệt ấy, tất cả quả như hành cũng diệt, không sinh trở lại. Hãy thấy rõ tính diệt không tái sinh (anuppādanirodha) ấy bằng tuệ minh sát và quán theo mẫu dưới đây.


<a id="M09-body-P133"></a>
## Tùy quán tính diệt và cả tính sinh lẫn tính diệt
Miến / Burmese 133

1. Do vô minh diệt, hành diệt. Do hành diệt, thức tái tục diệt. Do hành diệt, thức hữu phần diệt. Do hành diệt, thức tử diệt. Do hành diệt, nhãn thức diệt. pe.

Hãy quán như vậy riêng sự diệt. Hãy quán cả ba thời và cả hai dòng tương tục.

Samudayavayadhammānupassī — tùy quán tính sinh và diệt

Dùng tuệ minh sát nhìn cho thấy rõ cả sinh và diệt, tức các tính chất như hành sinh do vô minh sinh và hành diệt do vô minh diệt, rồi quán theo mẫu dưới đây.

1. Do vô minh sinh, hành sinh. Do vô minh diệt, hành diệt.

Vô minh — (sinh–diệt) vô thường. Hành — (sinh–diệt) vô thường.

2. Do hành sinh, thức tái tục sinh. Do hành diệt, thức tái tục diệt.

Hành — (sinh–diệt) vô thường. Thức tái tục — (sinh–diệt) vô thường.

3. Do hành sinh, thức hữu phần sinh. Do hành diệt, thức hữu phần diệt.

Hành — (sinh–diệt) vô thường. Thức hữu phần — (sinh–diệt) vô thường.

4. Do hành sinh, nhãn thức sinh. Do hành diệt, nhãn thức diệt.

Hành — (sinh–diệt) vô thường. Nhãn thức — (sinh–diệt) vô thường.


<a id="M09-body-P134"></a>
## Những lợi ích có thể đạt được
Miến / Burmese 134

Chừng ấy đủ để người mới hành thiền đã thỏa đáng với sự nối tiếp nhân quả theo phương pháp thứ nhất về duyên khởi nắm được cách quán. Hãy quán khắp các đời gọi là nghiệp hữu (kammabhava) và sinh hữu (upapattibhava). Như đã trình bày trong phương pháp thứ nhất ở phần duyên khởi, ở chỗ cần quán cả sáu nhóm thì hãy quán cả sáu nhóm. Hãy quán cả ba thời quá khứ, vị lai và hiện tại, và cả hai dòng tương tục bên trong và bên ngoài. Hãy nối các bộ ba đời với nhau mà quán. Ít nhất hãy quán xuyên suốt một lượt theo mỗi đặc tướng trong ba đặc tướng, từ các đời quá khứ liên tiếp đã nhận diện được cho tới cuối các đời vị lai.

Những lợi ích có thể đạt được

Tass'evaṃ manasikaroto “kuto kirime dhammā ahutvā sambhonti, hutvā paṭiventī”ti ñāṇaṃ visadataraṃ hoti. Tass'evaṃ paccayato ceva khaṇato ca dvedhā udayabbayaṃ passato saccapaṭiccasamuppādanayalakkhaṇabhedā pākaṭā honti. (Vism. 2, 267.)

Dùng tuệ quán thấy rõ quả sinh do nhân sinh gọi là thấy sinh theo duyên (paccayato udayadassana). Dùng tuệ quán thấy rõ quả diệt do nhân diệt gọi là thấy diệt theo duyên (paccayato vayadassana). Dùng tuệ quán thấy rõ quả sinh do nhân sinh và quả diệt do nhân diệt gọi là thấy sinh diệt theo duyên (paccayato udayabbayadassana).

Dùng tuệ quán thấy rõ sự sinh của các pháp hữu vi làm nhân và các pháp hữu vi làm quả ở từng sát-na sinh tương ứng gọi là thấy sinh theo sát-na (khaṇato udayadassana). Đối với chính các pháp hữu vi làm nhân và các pháp hữu vi làm quả ấy,


<a id="M09-body-P135"></a>
## Bốn Thánh đế hiển lộ
Miến / Burmese 135

dùng tuệ quán thấy rõ sự hoại diệt ở từng sát-na diệt tương ứng gọi là thấy diệt theo sát-na (khaṇato vayadassana). Dùng tuệ quán thấy rõ sự sinh và diệt của chính các pháp hữu vi làm nhân và các pháp hữu vi làm quả ấy trong từng sát-na sinh và sát-na diệt tương ứng, cho đến hiện tại sát-na, gọi là thấy sinh diệt theo sát-na (khaṇato udayabbayadassana), tức cách quán sinh diệt theo sát-na.

Khi đã tác ý và tu tập như vậy đối với các pháp hữu vi danh sắc làm nhân và quả, áp dụng lần lượt ba đặc tướng bằng hai cách thấy sinh diệt, tức thấy sinh diệt theo duyên và thấy sinh diệt theo sát-na, thì cái thấy của tuệ minh sát đặc biệt trong sáng: «Các pháp hữu vi này trước đó chưa có mà nay đột nhiên sinh khởi. Sau khi sinh, chúng lại diệt mất». Trong tuệ biết của người mới hành thiền thấy sinh diệt theo hai cách ấy:

1. Bốn đế;

2. Các pháp duyên khởi;

3. Bốn phương pháp;

4. Năm đặc tướng.

Bốn đế hiển lộ như thế nào

1. Paccayato udayadassana — thấy sinh theo duyên. Vì có thể dùng tuệ minh sát thấy quả sinh do nhân sinh, người mới hành thiền thấu hiểu trực tiếp và biết các nhân có khả năng trực tiếp làm cho các quả là những pháp hữu vi danh sắc sinh khởi. Do đó, tập đế hiển lộ trong tuệ biết của người ấy.


<a id="M09-body-P136"></a>
## Các sự thật hiển lộ khi quán sinh và diệt
Miến / Burmese 136

2. Khaṇato udayadassana — Thấy bằng tuệ minh sát sự sinh khởi của các hành gồm danh, sắc, nhân và quả ở từng sát-na, cho đến mức hiện tại sát-na. Do thấu rõ bằng tuệ minh sát cái khổ do sinh của các hành, khổ đế hiển lộ trong tuệ của hành giả.

3. Paccayato vayadassana — Thấy bằng tuệ minh sát rằng do nhân diệt nên quả diệt. Do thấu rõ bằng tuệ minh sát rằng khi nhân vắng mặt, không hiện hữu, thì quả tùy thuộc vào nhân ấy, tức quả chỉ có thể sinh khi nhân ấy hiện hữu, cũng không sinh, diệt đế hiển lộ trong tuệ của hành giả. (Đây là anuppādanirodha, sự diệt do không sinh.)

4. Khaṇato vayadassana — Thấy bằng tuệ minh sát sự tan rã của các hành gồm danh, sắc, nhân và quả ở từng sát-na, cho đến mức hiện tại sát-na, tức thấy bằng tuệ minh sát sự tan rã theo sát-na của các hành. Do thấu rõ bằng tuệ minh sát cái khổ do chết, do các hành tiêu tan và hư hoại, chính khổ đế hiển lộ trong tuệ của hành giả. (Ở đây nói đến cái khổ do chết trong từng sát-na.)

5. Paccayato udayabbayadassana — Thấy bằng tuệ minh sát sinh và diệt xét theo nhân, tức do nhân sinh nên quả sinh, do nhân diệt nên quả diệt. Khaṇato udayabbayadassana — Thấy bằng tuệ minh sát sự sinh và diệt của các hành gồm sắc, danh, nhân và quả ở từng sát-na, cho đến mức hiện tại sát-na. Cái thấy bằng tuệ sinh diệt theo hai cách này


<a id="M09-body-P137"></a>
## Đạo đế hiệp thế và năm chi đạo hiệp thế
Miến / Burmese 137

chính là chánh kiến minh sát. Nói cách khác, đó là nhóm pháp gồm chánh kiến đứng đầu, chánh tư duy, chánh tinh tấn, chánh niệm và chánh định. Nhóm pháp ấy chính là đạo đế hiệp thế. Đạo đế hiệp thế ấy có thể đoạn trừ bằng cách thay thế từng phần bóng tối si mê che khuất các hành gồm sắc, danh, nhân và quả, khiến chúng không được biết. Vì nhóm pháp thuộc đạo đế hiệp thế ấy có thể đoạn trừ yếu tố si mê ấy bằng cách thay thế từng phần, đạo đế hiển lộ trong tuệ của hành giả.

Một cách khác — Đạo đế hiệp thế gọi là chánh kiến ấy là pháp vô si, làm duyên y chỉ cho sự chứng đắc đạo đế gọi là Thánh đạo siêu thế. Cũng như một ngọn đèn đang cháy tự làm cho chính nó hiện rõ, pháp vô si ấy tự làm cho mình hiện rõ là chánh kiến vô si. (Chánh kiến hiện rõ qua sự biết bốn sự thật.) Vì thế, đạo đế hiển lộ. Khi hiển lộ như vậy, đạo đế ấy chỉ hiển lộ khi có thể xua tan bóng tối gọi là si đang che khuất bốn sự thật, khiến chúng không được biết. Bởi thế chánh kiến ấy có tên là đạo đế hiệp thế. (Vism. 2, 268. Mahāṭī. 2, 423–424.)

Đạo đế hiệp thế — Năm chi đạo hiệp thế

1. Tuệ thấu rõ đến mức chân đế các hành gồm sắc, danh, nhân và quả gọi là khổ đế và tập đế, và tuệ thấu rõ tính vô thường, tính khổ và tính vô ngã của các hành ấy,


<a id="M09-body-P138"></a>
## Năm chi đạo trong tuệ minh sát
Miến / Burmese 138

những tuệ minh sát ấy chính là chi đạo chánh kiến hiệp thế.

2. Tính chất hướng tâm minh sát đến cảnh là các hành ấy, và tính chất hướng tâm minh sát đến cảnh là tính vô thường, tính khổ và tính vô ngã của các hành ấy, là chi đạo chánh tư duy hiệp thế.

3. Tính chất nỗ lực để thấu rõ các hành ấy cho đến mức chân đế, và tính chất nỗ lực để thấu rõ tính vô thường, tính khổ và tính vô ngã của các hành ấy, là chi đạo chánh tinh tấn hiệp thế.

4. Tính chất ghi nhớ và nắm giữ các hành ấy, tính chất ghi nhớ và nắm giữ tính vô thường, tính khổ và tính vô ngã của các hành ấy, và tính chất đi sâu vào cảnh là các hành ấy và vào cảnh là tính vô thường, tính khổ và tính vô ngã của chúng, là chi đạo chánh niệm hiệp thế. (Đó là tính chất không quên, không bỏ sót cảnh.)

5. Tính chất tâm minh sát an trụ vững vàng trên cảnh là các hành ấy, và tính chất tâm minh sát an trụ vững vàng trên một trong các phương diện vô thường, khổ hay vô ngã của các hành ấy, là chi đạo chánh định. (Đây là định sát-na minh sát.)

Ở giai đoạn hiệp thế, vì năm chi đạo này và ba chi đạo thuộc giới, tức chánh ngữ, chánh nghiệp và chánh mạng, có cảnh khác nhau, chúng không thể sinh đồng thời trong cùng một sát-na tâm.


<a id="M09-body-P139"></a>
## Các pháp duyên khởi hiển lộ
Miến / Burmese 139

Chỉ năm chi đạo kể trên mới có thể cùng sinh trong một sát-na tâm minh sát.

1. Paccayato udayadassana — Thấy quả sinh vì nhân sinh. Do tuệ minh sát thấu rõ «khi nhân này hiện hữu thì quả này hiện khởi», những pháp duyên khởi theo chiều thuận hiển lộ trong tuệ của hành giả đúng như lời dạy: do vô minh sinh nên hành sinh, do hành sinh nên thức sinh, v.v.

2. Paccayato vayadassana — Thấy bằng tuệ minh sát rằng vì nhân chấm dứt nên quả chấm dứt. Do tuệ minh sát thấu rõ «vì nhân này chấm dứt nên quả này chấm dứt», những pháp duyên khởi theo chiều nghịch hiển lộ trong tuệ của hành giả đúng như lời dạy: do vô minh diệt nên hành diệt, do hành diệt nên thức diệt, v.v.

3. Khaṇato udayabbayadassana — Thấy bằng tuệ minh sát sự sinh và diệt theo từng sát-na, cho đến mức hiện tại sát-na, của các hành gồm hành làm nhân và hành làm quả, tức danh sắc làm nhân và danh sắc làm quả. Do tuệ minh sát thấu rõ tướng hữu vi (saṅkhatalakkhaṇa) là sinh, trụ và diệt (uppāda, ṭhiti, bhaṅga) của các hành ấy, các pháp quả nương vào nhân mà sinh, tức các pháp duyên sinh (paṭiccasamuppanna),


<a id="M09-body-P140"></a>
## Các pháp duyên sinh và bốn phương pháp
Miến / Burmese 140

hiển lộ trong tuệ của hành giả. Quả thật, các pháp hữu vi có tính sinh và diệt. Vì các pháp hữu vi ấy chỉ hiện khởi nương vào các nhân, chúng cũng được gọi là pháp duyên sinh. (Nghĩa là, chính các nhân là vô thường, khổ và vô ngã, nên các pháp quả duyên sinh nương các nhân ấy mà hiện khởi cũng là vô thường, khổ và vô ngã.) (Vism. 2, 268. Mahāṭī. 2, 424.)

Bốn phương pháp hiển lộ như thế nào

1. Paccayato udayadassana — Thấy bằng tuệ minh sát rằng do nhân sinh nên quả sinh. Do tuệ minh sát thấu rõ sự sinh khởi liên tục, lặp đi lặp lại, của dòng danh sắc trong đó nhân và quả nối liền nhau, phương pháp đồng nhất (ekattanaya), tức thấy dòng danh sắc là một dòng liên tục, hiển lộ trong tuệ của hành giả.

Trước đó, khi phân biệt nhân và quả trong mối liên hệ của chúng ở phần duyên khởi, tức ở giai đoạn tuệ phân biệt duyên, hành giả đã hiểu rằng dòng danh sắc quá khứ tạo lập các nhân quá khứ và dòng danh sắc hiện tại sinh đi sinh lại liên tục thành một dòng không gián đoạn. Đặc biệt, theo câu «Sabhāvo vāyaṃ cittassa paṇḍaratā» (Mūlaṭī. 1, 25), vì tất cả các tâm đều có tính sáng tỏ, hành giả thấy giới ý thức quá khứ đã tạo lập các nhân quá khứ và giới ý thức hiện tại là một dòng tương tục danh, xét theo phương diện vô thường,


<a id="M09-body-P141"></a>
## Dòng tâm tương tục
Miến / Burmese 141

tính khổ và tính vô ngã, và hiểu rằng chúng sinh đi sinh lại không gián đoạn thành một dòng liên tục duy nhất.

Lại nữa, trong suốt một đời, loại tâm sinh khởi nhiều nhất là tâm hữu phần. Theo những lời dạy như «Pabhassaram idaṃ, bhikkhave, cittaṃ» (A. 1, 5), tâm hữu phần ấy sáng trong, chiếu rực, lấp lánh. Các tâm trong lộ thỉnh thoảng sinh xen giữa các tâm hữu phần cũng trong sáng (paṇḍara), thanh tịnh. Tâm hữu phần cũng trong sáng. Khi dùng tuệ minh sát nhìn bao quát dòng tương tục danh của giới ý thức gồm tâm hữu phần và tâm trong lộ, từ quá khứ đến hiện tại và từ hiện tại ngược về quá khứ xa đến mức có thể quán, hành giả thấy bằng tuệ minh sát rằng chúng sinh đi sinh lại không gián đoạn, thành một dòng liên tục dưới dạng vô thường, như những hạt được xâu thành một chuỗi. Bằng tuệ minh sát, hành giả biết giới ý thức quá khứ ấy có phải là giới ý thức của chính mình hay không, và có cùng một dòng liên tục với giới ý thức hiện tại của mình hay không. Đối với tương lai cũng hãy hiểu như vậy.

Tuy nhiên, do chưa tác ý sâu rộng đến phương diện vô thường, hành giả có thể chỉ biết ở mức độ nào đó sự sinh diệt cho đến hiện tại sát-na trong một số sát-na tâm, hoặc trong một ít sát-na tâm. Đối với những sát-na tâm khác, hoặc đối với nhiều sát-na tâm, hành giả chưa biết sự sinh diệt cho đến hiện tại sát-na. Giờ đây, ở giai đoạn tuệ sinh diệt này, hành giả cũng biết giới ý thức đang sinh khởi liên tục


<a id="M09-body-P142"></a>
## Phương pháp thấy sự tiếp nối và sai biệt
Miến / Burmese 142

như vậy. Hành giả cũng biết sự sinh diệt trong từng sát-na của giới ý thức ấy dưới phương diện vô thường, khổ và vô ngã, cho đến hiện tại sát-na. Hành giả cũng biết rằng nhân và quả liên kết với nhau, sinh đi sinh lại không gián đoạn dưới phương diện vô thường, khổ và vô ngã. Khi ấy, tuệ minh sát biết và thấy như thế có thể đoạn trừ rất hiệu quả đoạn kiến chấp lầm rằng «người làm là một người, người chịu quả là một người khác». Bởi vì tuệ minh sát thấy sự chấm dứt của các pháp trước gắn liền với sự sinh khởi của các pháp theo sau, tức các pháp sinh kế tiếp. (Vism. 2, 268. Mahāṭī. 2, 424.)

2. Khaṇato udayadassana — Thấy bằng tuệ minh sát tính sinh khởi từng sát-na, cho đến hiện tại sát-na, của các hành danh sắc làm nhân và các hành danh sắc làm quả đang sinh khởi nối liền nhau theo quan hệ nhân quả như thế. Do tuệ minh sát thấu rõ rằng các pháp chân đế danh và sắc mới hiện khởi trong từng sát-na, phương pháp sai biệt (nānattanaya) hiển lộ trong tuệ của hành giả. (Tuy xét như dòng tương tục danh sắc thì đó là một dòng liên tục, dòng ấy là một dòng sinh diệt, hoàn toàn không phải là một dòng không sinh diệt. Dòng tương tục danh sắc trước và dòng tương tục danh sắc sau, cũng như danh sắc trước và danh sắc sau, đều khác nhau, riêng biệt. Vì thấy sự tan rã đến hiện tại sát-na, hành giả biết các yếu tố chân đế trước và các yếu tố chân đế sau đều riêng biệt, từng nhóm một. Điều này có nghĩa là tuệ của hành giả đã phân phá tính đặc khối của dòng tương tục (santatighana), của sự kết hợp (samūhaghana) và của phận sự (kiccaghana).)


<a id="M09-body-P143"></a>
## Phương pháp thấy nhân và quả không có chủ ý
Miến / Burmese 143

Khi biết và thấy như vậy, hành giả có thể đoạn trừ rất hiệu quả thường kiến chấp lầm rằng «chính người ấy làm, chính người ấy chịu quả». (Vism. 2, 268. Mahāṭī. 2, 424.)

3. Paccayato udayabbayadassana — Thấy bằng tuệ minh sát rằng vì nhân sinh nên quả sinh, và vì nhân chấm dứt nên quả chấm dứt. Khi nhân hiện hữu, quả hiện khởi. Khi nhân không hiện hữu, quả không hiện hữu. Vì mọi sự diễn ra đúng theo quy luật tự nhiên ấy, tuệ minh sát thấu rõ rằng trong các pháp chân đế sắc và danh, không có sự sinh khởi theo ý muốn của một cá nhân hay một chúng sinh nào. Vì thế phương pháp vô tác ý (abyāpāranaya) hiển lộ trong tuệ của hành giả. (Nghĩa là về phía các nhân, không có chủ ý rằng «ta sẽ làm cho các quả sinh khởi», và về phía các quả, cũng không có chủ ý rằng «khi các nhân sinh khởi, chúng ta, tức các quả, sẽ sinh khởi». Trong vô minh cũng không có chủ ý rằng «ta sẽ làm cho hành sinh khởi». Cũng vậy, trong hành không có chủ ý rằng «ta sẽ làm cho thức sinh khởi». Hãy hiểu theo cách ấy rằng cả hai phía, nhân lẫn quả, đều không có chủ ý.)

Khi biết và thấy như vậy, tuệ minh sát ấy có thể đoạn trừ rất hiệu quả ngã kiến chấp lầm rằng có một tự ngã tối cao sáng tạo và một tự ngã cá thể được sáng tạo. (Bởi vì tuệ minh sát ấy đều đặn biết và thấy rằng cả nhân lẫn quả đều không có chủ ý và rằng cả nhân lẫn quả chỉ là các nhóm pháp vô thường, các nhóm pháp khổ và các nhóm pháp vô ngã.)


<a id="M09-body-P144"></a>
## Phương pháp thấy quy luật và năm đặc tướng
Miến / Burmese 144

4. Paccayato udayadassana — Thấy bằng tuệ minh sát rằng vì nhân sinh nên quả sinh. Vì tuệ minh sát thấu rõ sự sinh khởi của quả tương ứng với nhân, hành giả thấy bằng tuệ minh sát rằng quả sinh do nhân. Các quả không sinh tùy tiện, vô trật tự, muốn sinh thế nào thì sinh. Các quả chỉ sinh phù hợp với nhân. Khi có các quả sinh do những nhân như vô minh, ái, thủ, hành và nghiệp, chỉ những quả phù hợp với các nhân ấy mới sinh, tức thức, danh sắc, sáu xứ, xúc và thọ. Hành giả biết và thấy rằng một quả khác, không phù hợp với nhân, không sinh. Vì thế phương pháp quy luật như vậy (evaṃdhammatānaya) hiển lộ.

Khi biết và thấy như vậy, tuệ minh sát có thể đoạn trừ rất hiệu quả tà kiến phủ nhận hiệu lực của hành động (akiriyadiṭṭhi), bác bỏ nhân là nghiệp, chủ trương rằng «có làm thì cũng không thành hành động». (Vism. 2, 268. Mahāṭī. 2, 424–425.)

Năm đặc tướng hiển lộ như thế nào

1. Paccayato udayadassana — Thấy bằng tuệ minh sát rằng do nhân hiện khởi nên quả hiện khởi. Khi nhân hiện hữu, quả sinh khởi. Như vậy, các nhân làm duyên cho các quả chỉ bằng sự hiện hữu của chúng, nên tính chất các pháp hữu vi không tự tác động, không có chủ ý,


<a id="M09-body-P145"></a>
## Đặc tướng vô ngã và đặc tướng vô thường
Miến / Burmese 145

hiển lộ. Lại nữa, khi nhân không hiện hữu, quả cũng không hiện hữu, nên tính chất các pháp quả hữu vi liên hệ với các nhân duyên của chúng cũng hiển lộ. Do tuệ minh sát thấu rõ rằng các hành không có sự tác động hay chủ ý như vậy và chỉ sinh trong mối liên hệ với các nhân, hành giả biết và thấy rằng không có tự ngã tối cao (paramatta), tức tự ngã sáng tạo, cũng không có tự ngã cá thể (jīva-atta), tức tự ngã được sáng tạo. Vì thế đặc tướng vô ngã hiển lộ trong tuệ của hành giả. Tuệ ấy làm hiển lộ tính trống không của tự ngã.

2. Khaṇato udayabbayadassana — Thấy bằng tuệ minh sát sự sinh diệt ở từng sát-na, tức tính sinh và diệt của các pháp hữu vi gọi là hành làm nhân và hành làm quả. Bằng tuệ minh sát, hành giả thấu rõ rằng các pháp ấy, trước khi sinh, chưa hiện hữu, nay mới sinh đầy đủ rồi đi đến chỗ không còn hiện hữu. (Hành giả dùng tuệ minh sát thấu rõ hai sự không hiện hữu, tức không hiện hữu trước khi sinh và không hiện hữu sau khi sinh rồi diệt, cũng như sự hiện hữu dưới dạng uppāda, ṭhiti và bhaṅga chỉ giữa hai sự không hiện hữu ấy.) Lại nữa, các hành ấy chỉ hiển lộ trong ba giai đoạn sinh, trụ, diệt, tức uppāda, ṭhiti và bhaṅga. Chúng không hiển lộ trước đó hay sau đó. Chúng chỉ có một khởi đầu là uppāda, sinh, và một kết thúc là bhaṅga, diệt. Vì tuệ minh sát thấu rõ các pháp hữu vi có khởi đầu và kết thúc là sinh và diệt như vậy, đặc tướng vô thường hiển lộ trong tuệ của hành giả.


<a id="M09-body-P146"></a>
## Đặc tướng khổ, đặc tướng riêng và đặc tướng hữu vi
Miến / Burmese 146

3. Vì tuệ minh sát thấu rõ các hành ấy luôn luôn thực sự bị bức bách, hết lần này đến lần khác, bởi hai sự kiện sinh và diệt, nên trong tuệ của hành giả, ngoài đặc tướng vô thường, đặc tướng khổ cũng hiển lộ.

4. Vì tuệ minh sát thấu rõ rằng các pháp hữu vi chỉ có thể hiện hữu giữa lúc sinh (uppāda) và lúc diệt (bhaṅga), tức được giới hạn bởi sinh và diệt, nên trong tuệ của hành giả, ngoài đặc tướng vô thường và đặc tướng khổ, đặc tướng riêng (sabhāvalakkhaṇa), tức tính chất và năng lực riêng của mỗi pháp hữu vi, cũng hiển lộ.

5. Khi các đặc tướng riêng của từng pháp hữu vi hiển lộ trong tuệ của hành giả, đặc tướng hữu vi (saṅkhatalakkhaṇa) cũng hiển lộ, tức tính chất chỉ có thể hiện hữu nhất thời, trong một khoảnh khắc cực ngắn gồm sinh, trụ và diệt. Bởi vì hành giả thấu rõ bằng tuệ minh sát rằng ở ngay lúc sinh (udaya) chưa có tính chất diệt (vaya), và ở ngay lúc diệt (vaya) cũng không có tính chất sinh (udaya).

Đó là những hiểu biết, những tuệ và những kết quả đặc biệt có được nhờ paccayato udayabbayadassana, tức dùng tuệ minh sát thấy sinh diệt theo nhân, thấy quả hiện khởi khi nhân hiện khởi và quả chấm dứt khi nhân chấm dứt, và nhờ khaṇato udayabbayadassana, tức thấy sinh diệt theo sát-na, thấy các hành sinh và diệt ở từng sát-na riêng biệt.


<a id="M09-body-P147"></a>
## Trình tự tu tập minh sát sinh diệt
Miến / Burmese 147

(Vism. 2, 268. Mahāṭī. 2, 425.)

Trình tự tu tập minh sát sinh diệt

Santativasena hi rūpārūpadhamme udayato, vayato ca manasi karontassa anukkamena bhāvanāya balavuppattikāle ñāṇassa tikkhavisadabhāvappattiyā khaṇato udayabbayā upaṭṭhahantīti. Ayañhi paṭhamaṃ paccayato udayabbayaṃ manasi karonto avijjādike paccayadhamme vissajjetvā udayabbayavante khandhe gahetvā tesaṃ paccayato udayabbayadassanamukhena khaṇatopi udayabbayaṃ manasi karoti.

Tassa yadā ñāṇaṃ tikkhaṃ visadaṃ hutvā pavattati, tadā rūpārūpadhammā khaṇe khaṇe uppajjantā, bhijjantā ca hutvā upaṭṭhahanti. (Mahāṭī. 2, 422.)

Các pháp sắc và danh hiện hữu trong một đời, từ tái tục đến tử, được gọi là các pháp hiện tại theo thời kỳ (addhāpaccuppanna). Các pháp danh hiện hữu trong từng lộ tâm, bắt đầu bằng lộ nhãn môn, được gọi là các pháp hiện tại theo dòng tương tục (santatipaccuppanna). Trong mỗi nhóm sắc có hỏa giới, tức thời tiết (utu), làm sinh một dòng sắc nối tiếp qua bốn, năm, sáu thế hệ v.v. Một dòng sắc như vậy được gọi là dòng sắc do một thời tiết sinh. Trong mỗi nhóm sắc cũng có dưỡng chất (ojā). Khi được lửa tiêu hóa do nghiệp sinh và dưỡng chất do vật thực sinh hỗ trợ, dưỡng chất ấy làm sinh một dòng sắc qua bốn, năm, sáu thế hệ v.v. Một dòng sắc như vậy được gọi là dòng sắc do một vật thực sinh. Các dòng sắc do bốn nhân sinh hiện hữu trong phạm vi một thời tiết hoặc một vật thực ấy


<a id="M09-body-P148"></a>
## Hiện tại theo dòng tương tục và hiện tại sát-na
Miến / Burmese 148

là các pháp hiện tại theo dòng tương tục. Các pháp danh hiện hữu trong một sát-na tâm gồm đủ ba tiểu sát-na là uppāda, ṭhiti và bhaṅga, và các pháp sắc hiện hữu trong ba giai đoạn uppāda, ṭhiti và bhaṅga của chúng, chính là các pháp danh và sắc gọi là hiện tại sát-na (khaṇapaccuppanna).

Trước hết hành giả phải tác ý và tu tập để thấy bằng tuệ minh sát các pháp sắc và danh dưới phương diện sinh và dưới phương diện diệt, xét theo hiện tại tương tục. Khi tu tập bằng cách tác ý như vậy, tuệ tu tập minh sát tuần tự đạt đến sức mạnh và trở nên sắc bén, trong sáng, hết sức thanh tịnh. Khi ấy, các tính chất sinh và diệt của các hành trong từng sát-na riêng biệt hiển lộ trong tuệ của hành giả cho đến mức hiện tại sát-na.

Quả thật, ban đầu hành giả tác ý và tu tập paccayato udayabbayadassana, tức sinh diệt theo nhân, chẳng hạn «do vô minh sinh, sắc sinh. Do vô minh diệt, sắc diệt». Trong khi tác ý như vậy, hành giả để sang một bên các nhân như vô minh, tức tạm gác việc quán thấy sự sinh khởi của các quả như sắc do các nhân như vô minh, rồi dùng tuệ minh sát bao quát và nắm lấy các uẩn nhân và uẩn quả mà tính sinh diệt đã hiển lộ. Lấy việc thấy bằng tuệ minh sát rằng các quả sinh do nhân sinh và các quả chấm dứt do nhân chấm dứt, tức paccayato udayabbayadassana, làm cửa ngõ, hành giả cũng tác ý đến các uẩn ấy


<a id="M09-body-P149"></a>
## Tuệ minh sát còn non và các tùy phiền não
Miến / Burmese 149

theo từng sát-na, tu tập tác ý đến tính sinh và diệt (udayabbaya) của chúng.

(Do vô minh sinh, sắc sinh. Do vô minh diệt, sắc diệt. Vô minh sinh diệt, vô thường. Sắc sinh diệt, vô thường. Ý nói đến sự tu tập tác ý theo những cách như vậy.)

Nhờ tác ý nhiều lần như vậy, tuệ của hành giả đến lúc trở nên sắc bén và trong sáng. Khi đó, các pháp sắc và danh hiển lộ trong tuệ của hành giả như đang sinh rồi diệt trong từng sát-na, từng sát-na một. Khi chúng hiển lộ như vậy, hành giả đạt được tuệ minh sát còn non, tức taruṇavipassanāñāṇa, gọi là quán sinh diệt (udayabbayānupassanā). Hành giả ấy được gọi là người mới bắt đầu quán minh sát (āraddhavipassaka). (Mahāṭī. 2, 422.)

Phần các tùy phiền não (upakkilesa)

Cho đến khi đạt tuệ minh sát còn non: 1. Paccayato udayabbayadassana — phương pháp quán sinh diệt theo nhân. 2. Khaṇato udayabbayadassana — phương pháp quán sinh diệt theo sát-na.

Khi hành giả quán minh sát sâu rộng theo hai phương pháp này, và cả khi sau đó trở lại quán minh sát năm uẩn chấp thủ phân theo quá khứ, tương lai, hiện tại, bên trong, bên ngoài v.v., mười loại tùy phiền não minh sát, tức những pháp làm nhiễm ô minh sát, thường có thể sinh khởi.


<a id="M09-body-P150"></a>
## Những người có hoặc không có tùy phiền não minh sát
Miến / Burmese 150

Vipassanupakkilesā hi paṭivedhappattassa ariyasāvakassa ceva vippaṭipannakassa ca nikkhittakammaṭṭhānassa kusītapuggalassa nuppajjanti. Sammāpaṭipannakassa pana yuttapayuttassa āraddhavipassakassa kulaputtassa uppajjantiyeva. (Vism. 2, 269.)

Mười pháp tùy phiền não làm nhiễm ô minh sát ấy:

1. Không sinh trong dòng tương tục của vị Thánh đệ tử đã đạt đến tuệ thể nhập là tuệ đạo và tuệ quả, và cũng không sinh trong dòng tương tục của hành giả đã đạt đến minh sát mạnh mẽ, mãnh liệt, bắt đầu bằng quán yếm ly (nibbidānupassanā). (Mahāṭī. 2, 427.)

2. Không sinh trong dòng tương tục của người thực hành sai lệch, như làm hư hoại giới, làm hư hoại định hay đi lệch trong sự tu tập tuệ.

3. Không sinh trong dòng tương tục của hành giả tuy đã nỗ lực nhiều trong các pháp minh sát, nhưng giữa chừng tâm chán nản và thoái lui đối với công việc minh sát, rồi từ bỏ công việc tu tập minh sát.

4. Không sinh trong dòng tương tục của người tuy đầy đủ giới v.v. nhưng do biếng nhác mà không nỗ lực tu tập minh sát.

Hãy ghi nhớ rằng chúng không sinh trong dòng tương tục của bốn hạng người này. Lại nữa, hãy ghi nhớ rằng chúng nhất định sinh trong dòng tương tục của thiện nam hoặc tín nữ được gọi là người mới bắt đầu quán minh sát (āraddhavipassaka), là người thực hành đúng đắn, không sai lệch trong sự tu tập giới, định và tuệ, luôn chuyên cần trước sau như một, không ngừng nỗ lực tu tập tuệ. (Vism. 2, 269. Mahāṭī. 2, 427.)


<a id="M09-body-P151"></a>
## 1. Obhāsa — ánh sáng
Miến / Burmese 151

Như đã trình bày ở trên, khi nhiều lần quán minh sát danh, sắc, nhân và quả, tức các pháp hành, bằng cách đặt chúng dưới các đặc tướng theo nhiều phương pháp, trí minh sát trở nên sắc bén. Tâm minh sát tương ưng với trí ấy, tức tâm và các tâm sở minh sát, làm sinh các nhóm tám sắc có dưỡng chất là thứ tám do tâm sinh (cittajaojaṭṭhamaka). Cảnh sắc, tức màu sắc (vaṇṇa), trong các nhóm sắc ấy chiếu rất sáng. Hỏa giới, tức thời tiết, trong từng nhóm tám sắc do tâm sinh lại tiếp tục làm sinh hết nhóm này đến nhóm khác gồm tám sắc có dưỡng chất là thứ tám do thời tiết sinh (utujāojaṭṭhamaka). Sắc cảnh, tức màu sắc trong từng nhóm sắc ấy, cũng chiếu rất sáng.

Màu sắc do tâm và do thời tiết sinh chiếu mạnh hay yếu tùy sức của trí. Màu sắc do tâm sinh chỉ lan tỏa bên trong. Màu sắc do thời tiết sinh lan tỏa cả bên trong lẫn bên ngoài, càng xa khi trí càng mạnh. Nó có thể lan tỏa đến cả mười ngàn thế giới.

Taṃ tasseva paññāyati. Tena phuṭṭhokāse rūpagatampi passati. Passanto ca cakkhuviññāṇena passati, udāhu manoviññāṇenāti vīmaṃsitabbaṃ vadanti. Dibbacakkhulābhino viya taṃ manoviññāṇaviññeyyamevāti vuttaṃ viya dissatīti. (Mahāṭī. 2.429.)

Ánh sáng ấy chỉ hiện rõ đối với chính hành giả. Khi ánh sáng do trí lan ra bên ngoài, tại những nơi ánh sáng ấy chiếu đến, hành giả còn có thể thấy…


<a id="M09-body-P152"></a>
## Ánh sáng và thức nhận biết sắc
Miến / Burmese 152

…sắc cảnh, tức toàn bộ những gì thuộc về sắc hiện diện ở đó. Khi hành giả thấy các sắc cảnh ở ngoại giới như thế, các bậc thầy nói cần xét xem vị ấy thấy bằng nhãn thức hay bằng ý thức. Theo vị thầy của bản Đại phụ chú giải, các thiện nhân đã đạt thắng trí thiên nhãn thấy các sắc cảnh xa gần bằng ý thức gọi là tâm thắng trí thiên nhãn. Tương tự, ở đây các cảnh minh sát cũng chỉ được thấy bằng ý thức gọi là tâm minh sát. Tác giả có vẻ cho rằng cách hiểu ấy hợp lý. (Mahāṭī. 2.429.)

Những lời giải thích và nhận xét trên của vị thầy Đại phụ chú giải đặc biệt đáng lưu tâm đối với hành giả đang quán minh sát.

Nếu chấp nhận rằng có ánh sáng trong tâm minh sát hoặc ánh sáng sinh do trí minh sát, thì cũng phải chấp nhận lời Đức Phật trong Adhicittasutta, còn gọi là Nimittasutta (Aṅ. 1.258), rằng tâm tu tập thiền chỉ và tâm tu tập minh sát, gọi là tăng thượng tâm (adhicitta), có ánh sáng rực rỡ, lóe chiếu (pabhassara). Bởi vì các tâm tu tập thiền chỉ và minh sát gọi là tăng thượng tâm có thể làm sinh các nhóm tám sắc có dưỡng chất là thứ tám do tâm sinh. Mỗi tâm tu tập thiền chỉ và mỗi tâm tu tập minh sát…


<a id="M09-body-P153"></a>
## Ánh sáng do tâm và thời tiết sinh
Miến / Burmese 153

…có khả năng làm sinh rất nhiều nhóm sắc. Mỗi hỏa giới, tức thời tiết, trong các nhóm tám sắc có dưỡng chất là thứ tám do tâm sinh ấy cũng có thể liên tiếp làm sinh các nhóm tám sắc có dưỡng chất là thứ tám do thời tiết sinh. Màu sắc, tức sắc cảnh trong từng nhóm tám sắc do tâm và do thời tiết sinh ấy, có thể chiếu sáng tùy sức của trí. Trong số các pháp tương ưng cùng sinh với tâm tu tập thiền chỉ và tâm tu tập minh sát gọi là tăng thượng tâm ấy cũng có trí.

Vì vậy, thiện nhân hành thiền cần có thể chấp nhận lời Đức Phật rằng các tâm tu tập thiền chỉ và minh sát gọi là tăng thượng tâm có ánh sáng rực rỡ, lóe chiếu. Hãy hiểu rằng tên “ánh sáng” của sắc do tâm sinh và sắc do thời tiết sinh, tức quả, được dùng cho trí, tức nhân, trong những cách gọi “ánh sáng trí thiền chỉ” và “ánh sáng trí minh sát”. Đó là cách nói gọi nhân bằng tên quả (kāraṇūpacāra, cũng gọi là phalūpacāra).

Nếu chấp nhận như thế, cũng có thể chấp nhận lời giải thích của Aṅguttaraṭīkā, quyển ba, trong phần chú giải Pacalāyamānasutta (Aṅ. Ṭī. 3.177–178). Như đã trình bày ở phần đầu sách về đề mục thiền chỉ, ánh sáng bắt đầu xuất hiện do tâm tu tập thiền chỉ ngay khi đang thiết lập định, từ giai đoạn định chuẩn bị gần với cận định và an chỉ định. (Đại phụ chú giải và Aṅguttaraṭīkā đều là tác phẩm của cùng một vị thầy, Tôn giả Dhammapāla, gọi là Ācariya Dhammapāla.)


<a id="M09-body-P154"></a>
## Vì sao lại giải thích ánh sáng ở giai đoạn này?
Miến / Burmese 154

Nếu chấp nhận như thế, thì có thể hiểu rằng ánh sáng đã có từ trước khi đạt đến giai đoạn minh sát non yếu của trí sinh diệt. Vì ánh sáng có thể sinh do tâm tu tập thiền chỉ và tâm minh sát gọi là tăng thượng tâm, nên có thể có ánh sáng trong suốt phần định, từ định chuẩn bị gần với cận định và an chỉ định, và cũng có thể có ánh sáng trong suốt phần minh sát, kể từ khi bắt đầu nhận diện danh và sắc. Đó là ánh sáng trí thiền chỉ và ánh sáng trí minh sát.

Vì sao lại phải giải thích? Nếu ánh sáng hiện rõ trong suốt quá trình tu tập thiền chỉ và minh sát gọi là tăng thượng tâm, vì sao đến giai đoạn minh sát non yếu của trí sinh diệt mới lại giải thích sự xuất hiện của obhāsa, tức vipassanobhāsa, ánh sáng của trí minh sát? Câu trả lời như sau.

Tattha obhāsoti vipassanobhāso. Tasmiṃ uppanne yogāvacaro “Na vata me ito pubbe evarūpo obhāso uppannapubbo, addhā maggappattosmi phalappattosmī”ti amaggameva “maggo”ti, aphalameva ca “phalan”ti gaṇhāti. Tassa amaggaṃ “maggo”ti aphalaṃ “phalan”ti gaṇhato vipassanāvīthi ukkantā nāma hoti. So attano mūlakammaṭṭhānaṃ vissajjetvā obhāsameva assādento nisīdati. (Visuddhi. 2.270.)


<a id="M09-body-P155"></a>
## Ánh sáng và sự đi chệch đường minh sát
Miến / Burmese 155

Trong mười pháp tùy phiền não minh sát ấy, obhāsa là ánh sáng, tức vipassanobhāsa, ánh sáng minh sát, nghĩa là ánh sáng sinh do trí minh sát. Khi ánh sáng của trí minh sát ấy xuất hiện, hành giả nghĩ: “Trong dòng tương tục của ta trước đây chưa từng xuất hiện ánh sáng như thế này. Hôm nay ta đã đạt Thánh đạo, đã đạt Thánh quả.” Hành giả nắm lấy ánh sáng obhāsa vốn không phải Thánh đạo làm Thánh đạo, nắm lấy ánh sáng obhāsa vốn không phải Thánh quả làm Thánh quả. Khi nắm lấy như thế, hành giả đi chệch đường minh sát. Bởi vì hành giả buông bỏ đề mục căn bản của mình, tức công việc tu minh sát, rồi ngồi đó thưởng thức chính ánh sáng obhāsa ấy. (Visuddhi. 2.270.)

Theo lời giải thích trên của chú giải Visuddhimagga, ánh sáng xuất hiện trong giai đoạn minh sát non yếu gọi là trí sinh diệt khác với ánh sáng đã xuất hiện trước đây do tâm thiền chỉ và tâm minh sát. Đó là một loại ánh sáng mới, đặc biệt và chưa từng xuất hiện. Tùy người, nó có thể lan ra trong khoảng một căn phòng, hoặc lan đầy cả bầu trời.

Nếu xem chính ánh sáng ấy là đạo hay quả, hoặc là ánh sáng phát ra từ trí đạo và trí quả, rồi…


<a id="M09-body-P156"></a>
## Cách trở lại đường minh sát
Miến / Burmese 156

…dừng tu minh sát và thưởng thức ánh sáng obhāsa ấy, thì sự ưa thích, tức nikanti, mới là tùy phiền não. Khi do ánh sáng ấy mà ngã mạn hay tà kiến sinh khởi, thì chúng mới là tùy phiền não. Vì vậy, ánh sáng obhāsa là chỗ nương của các tùy phiền não. Chính ái, tức nikanti, ngã mạn và tà kiến sinh khi lấy ánh sáng ấy làm cảnh mới là các tùy phiền não.

“Etaṃ mama, esohamasmi, eso me attā — Ánh sáng obhāsa này là của tôi. Ánh sáng obhāsa này là tôi. Ánh sáng obhāsa này là tự ngã của tôi.” Khi chấp thủ như thế thì ái, ngã mạn và tà kiến sinh khởi.

Cách trở lại đường đúng. Trước hết hãy nhận diện bốn đại trong ánh sáng obhāsa. Khi có thể phân biệt được bằng trí từng nhóm bốn đại, hãy tiếp tục quán để thấy cả giới hư không. Khi đó chỉ còn thấy các hạt nhóm sắc. Đó là những hạt nhóm sắc cực kỳ vi tế. Hãy dùng trí phân tích các nhóm sắc ấy để phá khối tưởng (ghana), nhận diện sắc pháp chân đế.

Các hạt nhóm sắc mang tên obhāsa lan tỏa bên trong là các nhóm tám sắc có dưỡng chất là thứ tám do tâm và do thời tiết sinh. Các nhóm sắc lan tỏa ra ngoài là các nhóm tám sắc có dưỡng chất là thứ tám do thời tiết sinh. Hãy nhận diện các sắc pháp chân đế do tâm và thời tiết sinh ấy, phân biệt chúng bằng trí, rồi luân phiên đặt chúng dưới ba đặc tướng và…


<a id="M09-body-P157"></a>
## 2. Trí và 3. Hỷ
Miến / Burmese 157

…quán minh sát. Như vậy hành giả đã trở lại đường minh sát. Sau đó tiếp tục quán minh sát như trước đối với sắc, danh, nhân và quả, tức các pháp hành đang quán dở.

2. Ñāṇa — trí minh sát. Khi hành giả nỗ lực phát triển trí sinh diệt đến mức cao nhất, trí minh sát có khả năng đặt các pháp hành dưới các đặc tướng và quán xét chúng sinh khởi sắc bén, nhanh nhạy, trong sáng và tinh khiết như vũ khí kim cang do vua trời Sakka phóng ra. (Visuddhi. 2.271.)

3. Pīti — hỷ minh sát. Hỷ là sự hoan hỷ và vui mừng sinh cùng trí minh sát. Có năm loại hỷ:

1. Khuddikāpīti — hỷ nhỏ, có thể làm dựng lông và nổi da gà.

2. Khaṇikāpīti — hỷ chớp nhoáng, thỉnh thoảng lóe lên như tia chớp.

3. Okkantikāpīti — hỷ tràn xuống, từng đợt dâng lên trong thân như sóng.

4. Ubbegāpīti — hỷ nâng bổng, có thể làm thân nhấc lên cao và bay.

5. Pharaṇāpīti — hỷ thấm nhuần, làm các sắc thù thắng do tâm sinh lan khắp, tràn đầy và thấm vào toàn thân.


<a id="M09-body-P158"></a>
## 4. Passaddhi — an tịnh minh sát
Miến / Burmese 158

Trong giai đoạn minh sát non yếu này, năm loại hỷ ấy thường xuất hiện trong dòng tương tục của hành giả. Đặc biệt, hỷ thấm nhuần thường xuất hiện rất mạnh. (Visuddhi. 2.272.)

4. Passaddhi là sự an tịnh của tâm và các tâm sở sinh cùng tâm minh sát. Khi hành giả ngồi tác ý các pháp làm đối tượng minh sát ở nơi thích hợp để ngồi và trú, lúc ấy thân và tâm không bị nóng bức, nặng nề hay thô cứng. Hành giả thích thú với cảnh tu tập. Tâm và các tâm sở không bị bệnh hoạn hay cong vạy. Các trạng thái thực sự xuất hiện là sự an tịnh, sự nhẹ nhàng của tâm và các tâm sở, tức khả năng nhanh chóng chuyển qua lại khi quán minh sát: khi sắc, khi danh, khi nhân, khi quả, khi nội, khi ngoại, khi quá khứ, khi vị lai, khi hiện tại, khi vô thường, khi khổ, khi vô ngã, v.v. Cũng xuất hiện tính mềm mại, dễ sử dụng vào công việc tu tập, trong sạch khỏi phiền não, thành thạo trong tu tập và ngay thẳng. [Ý nói cả mười hai tâm sở thành sáu cặp, từ kāyapassaddhi và cittapassaddhi đến kāyujukatā và cittujukatā, đều hiện rõ cùng trí minh sát.] (Visuddhi. 2.272.)


<a id="M09-body-P159"></a>
## 5. Lạc, 6. Tín và 7. Tinh tấn
Miến / Burmese 159

5. Sukha — lạc minh sát. Tâm sở lạc, sự an vui của tâm, sinh cùng trí minh sát. Toàn bộ thân sắc của hành giả tràn ngập sắc thù thắng do tâm minh sát tương ưng với lạc ấy làm sinh, và sắc ấy lan tỏa khắp thân. Ý nói sắc do tâm thù thắng sinh lan khắp toàn thân. (Visuddhi. 2.272.)

6. Adhimokkha — tín. Trong dòng tương tục của hành giả cũng sinh khởi tín đối với công việc tu tập minh sát, gọi là adhimokkha. Tín ấy rất mạnh và kiên cố, có khả năng quyết định dứt khoát và làm cho tâm minh sát cùng các tâm sở tương ưng với trí minh sát rất trong sáng. Đặc biệt, đây là tín đối với ba học cao quý là giới, định và tuệ.

7. Paggaha — tinh tấn. Trong dòng tương tục của hành giả, cùng với trí minh sát, cũng sinh khởi tinh tấn vững vàng, không chùng xuống hay lùi lại, được củng cố bởi sức tu tập trước đó. Nó nâng đỡ mạnh mẽ các pháp tương ưng là tâm và các tâm sở tu tập minh sát, đề cao chúng, bảo vệ chúng khỏi tính lười biếng trong việc tu tập và nâng đỡ công việc ấy. Tinh tấn ấy gọi là paggaha…


<a id="M09-body-P160"></a>
## 8. Niệm và 9. Xả
Miến / Burmese 160

…và tinh tấn ấy cũng đang sinh khởi.

8. Upaṭṭhāna — niệm. Lúc ấy, trong dòng tương tục của hành giả, niệm sinh cùng trí minh sát đang tu tập. Niệm ghi nhận rõ ràng tính vô thường, tính khổ, tính vô ngã và tính bất tịnh của các pháp hành, nên bám chắc vào các pháp hành làm cảnh của trí minh sát. Vì sạch cấu uế của các pháp đối nghịch, tức các chướng ngại, niệm khiến các chướng ngại ấy không thể lay động nó. Niệm vững chắc trên các pháp hành làm cảnh, như núi đá không lay chuyển hay cột đá chôn sâu.

Hành giả hướng đến bất cứ cảnh nào trong sắc, danh, nhân và quả, tức các pháp hành, đều có thể đưa cảnh ấy vào tâm, tác ý và tu tập thẩm sát minh sát từng pháp riêng. Các cảnh ấy hiện rõ trước sức niệm của hành giả. Ý nói hành giả có thể quán bất kỳ pháp hành nào mình muốn quán. Ở giai đoạn này, nếu muốn, hành giả có thể theo phương pháp minh sát quán từng pháp (anupadadhamma-vipassanā) mà quán các pháp hành từng pháp một. (Visuddhi. 2.272.)

9. Upekkhā — xả minh sát và xả hướng tâm. Đối với những cảnh sắc, danh, nhân và quả ấy, tức các pháp hành, tâm tu tập minh sát được giữ ở mức quân bình bởi…


<a id="M09-body-P161"></a>
## Xả minh sát và xả hướng tâm
Miến / Burmese 161

…tâm sở trung tánh (tatramajjhattatā) tương ưng với trí minh sát. Đó gọi là xả minh sát (vipassanupekkhā). Tâm sở tư đi cùng tâm hướng ý môn, tức tâm suy xét và xác định đứng ngay trước tốc hành minh sát, được gọi là xả hướng tâm (āvajjanupekkhā), vì trong lúc suy xét tính vô thường, tính khổ, tính vô ngã và tính bất tịnh của các pháp hành, nó sinh với năng lực nhìn các cảnh pháp hành một cách quân bình.

Lúc ấy, trong dòng tương tục của hành giả, hay đối với trí minh sát, tính sinh diệt của các pháp hành, tức sự sinh và sự hoại diệt, hiện ra hết sức rõ ràng. Vì hiện rõ như thế, khi quán minh sát các pháp hành không còn cần nỗ lực đặc biệt. Hành giả đã đạt đến mức có thể giữ tâm quân bình và an tịnh, có thể quán một cách nhẹ nhàng, đều đặn. Do tính sinh diệt của các pháp hành hiện rõ như thế, tính quân bình và thản nhiên của tâm sở trung tánh trong khi quán sinh diệt được gọi là xả minh sát trong phần minh sát non yếu này.

Tuy vậy, sự sinh diệt ấy là tính sinh diệt của các pháp hành. Hãy ghi nhớ rằng các chú giải dùng cách nói “xả đối với các pháp hành” thay cho “xả đối với sự sinh diệt”. Khi ấy, trong dòng tương tục của hành giả, xả minh sát rất mạnh. Xả hướng tâm cũng rất mạnh. Lúc ấy xả hướng tâm sinh khởi sắc bén và chói sáng như vũ khí kim cang do vua trời Sakka phóng ra. (Visuddhi. 2.273.)


<a id="M09-body-P162"></a>
## Tám hiện tượng làm chỗ nương cho tùy phiền não
Miến / Burmese 162

Trong các tùy phiền não được liệt kê ở đây, các pháp từ mục 2 là trí đến mục 9 là xả là chỗ nương của tùy phiền não. Tám pháp này, tức trí, hỷ, an tịnh, lạc, tín, tinh tấn, niệm và xả, là các tâm sở hành sinh cùng trí minh sát của hành giả đang quán minh sát. Chúng đều có trong 34 danh pháp gồm tâm và các tâm sở sinh cùng trí minh sát trong một sát-na tâm. Đối với phàm nhân và bậc hữu học, các pháp ấy chỉ thuộc tốc hành thiện minh sát, nên chúng không phải chính các tùy phiền não. Tuy vậy, khi lấy các pháp ấy làm cảnh:

“Etaṃ mama, esohamasmi, eso me attā — Pháp này là của tôi. Pháp này là tôi. Pháp này là tự ngã của tôi.” (Đây là trí của tôi. Đây là hỷ của tôi…)

Khi chấp thủ như thế, ái, ngã mạn và tà kiến sinh khởi. Chính ái, ngã mạn và tà kiến ấy là các tùy phiền não.

Khi chấp từng pháp ấy, từ trí, hỷ, v.v., đến xả, là trí đạo và trí quả thì hành giả lại đi chệch đường minh sát. Hành giả bỏ đề mục căn bản của mình, tức công việc tu tập minh sát, rồi ngồi ưa thích một pháp trong số trí, hỷ, v.v., đến xả, xem nó là đạo hay quả, dù nó không phải đạo hay quả thực sự. Do đó đường minh sát bị chệch hướng.


<a id="M09-body-P163"></a>
## Cách vượt qua và 10. Nikanti — ưa thích minh sát
Miến / Burmese 163

Các pháp từ trí, hỷ, v.v., đến xả, sinh tương ưng với tốc hành minh sát lấy tướng vô thường, tướng khổ hay tướng vô ngã của các pháp hành làm cảnh. Một số pháp như xả hướng tâm lại sinh tương ưng với tâm hướng ý môn đứng ngay trước tốc hành minh sát. Chúng sinh theo trình tự lộ tốc hành qua ý môn dưới đây:

Hướng ý môn (1 lần) | Tốc hành (7 lần) | Đăng ký hữu nhân / đăng ký vô nhân (2 lần)
12 | 34 | 34 / 12

Có khi đến đăng ký, có khi không. Hãy dùng trí phân tích các lộ tốc hành minh sát qua ý môn ấy đến khi phá được từng khối danh. Dùng trí minh sát thấy rõ tính sinh diệt ở mỗi sát-na tâm, rồi luân phiên đặt dưới ba đặc tướng và quán minh sát.

10. Nikanti — ưa thích minh sát. Nikanti là sự ưa thích minh sát, một sự dính mắc và say mê minh sát rất vi tế. Do tu tập minh sát có các pháp từ ánh sáng cho đến xả làm nét đặc biệt, trong dòng tương tục của hành giả sinh một sự say mê minh sát vi tế, lấy sự dính mắc vào minh sát làm nhiệm vụ và hiện ra như trạng thái an tĩnh. Sự vi tế và tướng an tĩnh của nikanti ấy…


<a id="M09-body-P164"></a>
## Nhận diện và quán sự ưa thích minh sát
Miến / Burmese 164

…sinh do minh sát đã trở nên cực kỳ sắc bén. Do hành giả không nhận ra nikanti ấy là phiền não, việc dùng trí nhận diện nó là phiền não cũng trở nên khó khăn.

Trong dòng tương tục của hành giả thường sinh tâm trạng như thế này: “Sự thích thú, say mê và vui mừng trong việc tu minh sát như thế này trước đây chưa từng sinh trong dòng tương tục của ta. Chắc chắn hôm nay ta đã đạt đạo và quả.” Hành giả có thể hiểu đó là sự vui mừng hớn hở do say mê tu minh sát mà không nhận ra chính sự ưa thích vi tế. Tuy vậy, có thể dùng trí minh sát sắc bén nhận diện sự ưa thích ấy.

Nikanti là pháp tương ưng với tâm căn tham đi cùng thọ hỷ, nên có thể sinh theo nhóm tham đi cùng tà kiến hoặc nhóm tham đi cùng ngã mạn. Vì ngã mạn là tâm sở chỉ tương ưng đôi khi (kadāci), có lúc cũng không có ngã mạn. Do tương ưng với thọ hỷ, hỷ có mặt.

Hướng ý môn (1 lần) | Tốc hành (7 lần) | Đăng ký hữu nhân / đăng ký vô nhân (2 lần)
12 | 34 | 34 / 33 / 12

Có khi đến đăng ký, có khi không. Khi đến đăng ký, có thể là tâm đăng ký đại quả đi cùng thọ hỷ hoặc tâm suy đạc vô nhân đi cùng thọ hỷ, tùy trường hợp. Hãy dùng trí phân tích lộ tốc hành qua ý môn có sự ưa thích vi tế này cho đến khi phá từng khối danh. Sau đó nhận diện các danh pháp cùng sinh với nikanti, lần lượt đặt dưới ba đặc tướng và tu tập thẩm sát minh sát.


<a id="M09-body-P165"></a>
## Tri kiến thanh tịnh về đạo lộ
Miến / Burmese 165

Sự ưa thích này cũng là tùy phiền não. Nếu lấy chính sự ưa thích ấy làm cảnh rồi chấp thủ: “Etaṃ mama, esohamasmi, eso me attā — Của tôi, là tôi, là tự ngã của tôi,” thì các tùy phiền não là ái, ngã mạn và tà kiến lại có thể sinh. Do đó nó cũng là chỗ nương của tùy phiền não. Vì vậy, nikanti mang cả hai tên: tùy phiền não và chỗ nương của tùy phiền não. (Trích Visuddhi. 2.269–274 và Mahāṭī. 2.427–434.)

Phần tri kiến thanh tịnh về đạo lộ (paṭipadāñāṇadassanavisuddhi) — giai đoạn trí minh sát bậc cao.

Đối với các pháp từ ánh sáng cho đến sự ưa thích, đối với sắc pháp và danh pháp đã trình bày trong cách quán bảy phần về sắc và cách quán bảy phần về vô sắc, cũng như đối với sắc pháp và danh pháp đã nhận diện theo từng môn và xứ ở phần trước:

1. Theo hai phần là danh và sắc.

2. Theo năm uẩn.

3. Theo mười hai xứ.

4. Theo mười tám giới.

Dùng phương pháp mình ưa thích trong các phương pháp ấy, hãy nhận diện rõ bằng trí tính sinh và diệt của các pháp chân đế, cho đến hiện tại sát-na. Hãy quán minh sát nhiều lần bằng cách luân phiên đặt chúng dưới ba đặc tướng. Quán trong cả ba thời, quá khứ, vị lai và hiện tại, và cả hai dòng tương tục, nội và ngoại. Cần lặp lại cách quán ấy nhiều lần. Hãy cố gắng làm cho tri kiến về các pháp hành ở hiện tại sát-na trở nên trong sáng. Ba đặc tướng…


<a id="M09-body-P166"></a>
## Bốn phép tùy quán và bốn niệm xứ
Miến / Burmese 166

đối với mỗi đặc tướng cũng hãy nỗ lực nhiều lần, hết lần này đến lần khác, để tuệ thấy ngày càng trong sáng.

Bốn phép tùy quán liên hệ với bốn niệm xứ như thế nào

1. Khi quán minh sát như vậy, trước hết lấy riêng sắc làm chính và ưu tiên quán sắc, rồi tiếp tục quán minh sát danh. Làm như vậy gọi là tu tập thân tùy quán niệm xứ.

2. Khi quán minh sát danh pháp, như đã giải thích ở phần đề mục danh v.v., người mới hành thiền sắp tu tập ba loại niệm xứ, bắt đầu từ thọ tùy quán, phải làm theo quy định: “Saṅkhittena vā vitthārena vā pariggahite rūpakammaṭṭhāne” (Ma. A. 1, 280), tức phải nhận diện xong đề mục sắc, theo cách tóm tắt hay chi tiết. Vị ấy phải nhận diện cùng nhau sắc làm chỗ nương và sắc làm cảnh của các danh pháp có thọ đứng đầu. Sau khi nhận diện như vậy, nếu ưu tiên nhận diện thọ và quán minh sát các danh pháp thì gọi là tu tập thọ tùy quán niệm xứ. Mẫu quán gồm:

(a) Vật; (b) cảnh; (c) thọ, tức tất cả danh pháp có thọ đứng đầu.

(a) Vật — sinh diệt — vô thường; (b) cảnh — sinh diệt — vô thường; (c) thọ — sinh diệt — vô thường.

Theo cách ấy, trong mỗi nhóm tâm thuộc lộ đã nhận diện theo từng xứ và môn, và trong các nhóm tâm hữu phần đến mức mình có thể,


<a id="M09-body-P167"></a>
## Quán thọ, tâm và pháp
Miến / Burmese 167

hãy quán ba mục ấy. Khi quán như vậy, như đã trình bày trong các bảng của phần đề mục danh, hãy quán xuyên suốt cả hàng, từ hướng ngũ môn đến na cảnh của lộ ý môn. Trong từng nhóm tâm:

(a) Quán riêng sắc làm vật nương; (b) quán riêng sắc làm cảnh; (c) quán riêng thọ, tức các danh pháp có thọ đứng đầu.

Hãy nhìn cho thấy rõ sinh diệt và quán là vô thường. Cũng quán tương tự khi áp dụng đặc tướng khổ và vô ngã. Hãy quán cả ba thời và cả hai dòng tương tục. Hãy mở rộng quán tùy theo sức tuệ.

3. Trong ba cách nhận diện đề mục danh, nếu ưu tiên tâm biết cảnh, tức thức, rồi sau khi nhận diện danh pháp thì quán minh sát, gọi là tu tập tâm tùy quán niệm xứ. Mẫu quán gồm:

(a) Vật; (b) cảnh; (c) thức, tức nhận diện và quán minh sát tất cả danh pháp có tâm biết cảnh, tức thức, đứng đầu.

4. Khi quán minh sát danh pháp, nếu ưu tiên xúc (cetanā), nhận diện các danh pháp rồi tu tập minh sát, gọi là tu tập pháp tùy quán niệm xứ. Mẫu quán gồm:

(a) Vật; (b) cảnh; (c) xúc, tức tất cả các danh pháp có xúc đứng đầu.


<a id="M09-body-P168"></a>
## Các cách phân loại trong pháp tùy quán
Miến / Burmese 168

Hãy quán minh sát các pháp này bằng cách lần lượt áp dụng ba đặc tướng.

Một cách khác, khi chia các pháp sắc và danh thành hai phần theo phương pháp danh sắc và quán minh sát, thì sau khi quán minh sát sắc pháp, lúc quán danh pháp, nếu nhận diện danh pháp với thọ đứng đầu rồi quán minh sát, đó là thọ tùy quán niệm xứ. Nếu nhận diện danh pháp với tâm biết cảnh, tức thức, đứng đầu rồi quán minh sát, đó là tâm tùy quán niệm xứ. Nếu nhận diện danh pháp với xúc đứng đầu rồi quán minh sát, đó là pháp tùy quán niệm xứ. Lại nữa:

1. Chia danh sắc thành 5 phần theo phương pháp năm uẩn;

2. Chia danh sắc thành 12 phần theo phương pháp mười hai xứ;

3. Chia danh sắc thành 18 phần theo phương pháp mười tám giới;

4. Chia danh sắc theo 12 chi, theo phương pháp duyên khởi;

5. Theo phương pháp năm triền cái;

6. Theo phương pháp bảy giác chi;

7. Chia thành hai phần là khổ đế và tập đế, theo phương pháp thuyết về các đế.

Khi quán minh sát bằng những cách như vậy, cũng gọi là tu tập chính pháp tùy quán niệm xứ.

Cách quán ở phần oai nghi và phần tỉnh giác

Cách nhận diện năm uẩn, tức sắc pháp và danh pháp, trong phần oai nghi gồm đi, đứng, ngồi, nằm, và trong các mục tỉnh giác khác nhau như tiến tới, lui lại, co và duỗi,


<a id="M09-body-P169"></a>
## Quán các uẩn trong oai nghi và tỉnh giác
Miến / Burmese 169

đã trình bày ở phần đề mục danh v.v. Hãy nhận diện trở lại chính năm uẩn ấy, tức sắc pháp và danh pháp:

1. Hoặc chia thành hai phần theo phương pháp danh và sắc;

2. Hoặc chia thành năm phần theo phương pháp năm uẩn;

3. Hoặc chia thành mười hai phần theo phương pháp mười hai xứ;

4. Hoặc chia thành mười tám phần theo phương pháp mười tám giới;

5. Hoặc chia thành mười hai chi theo phương pháp duyên khởi.

Hãy quán minh sát bằng những cách như vậy. Nếu quán minh sát theo phương pháp chia thành danh và sắc:

1. Quán riêng sắc; 2. quán riêng danh; 3. quán gộp sắc với danh.

Hãy lần lượt áp dụng ba đặc tướng mà quán minh sát. Hãy quán cả ba thời và cả hai dòng tương tục. Sau khi nhìn thấy sinh diệt của danh sắc đến hiện tại sát-na trong năm uẩn, tức sắc pháp và danh pháp, có mặt trong từng mục oai nghi như đi, và từng mục tỉnh giác, ở cả ba thời quá khứ, vị lai, hiện tại và cả hai dòng tương tục bên trong và bên ngoài, hãy áp dụng các đặc tướng để quán minh sát. Khi đã có thể làm vậy, hãy tiếp tục quán minh sát theo phương pháp thứ nhất về duyên khởi:

1. Quán cách các quả như hành sinh do các nhân như vô minh sinh;

2. Quán cách các quả như hành diệt do các nhân như vô minh diệt;


<a id="M09-body-P170"></a>
## Kết thúc chương tuệ sinh diệt
Miến / Burmese 170

3. Quán cách các quả như hành sinh do các nhân như vô minh sinh và cách các quả như hành diệt do các nhân như vô minh diệt. Dùng tuệ nhìn cho thấy rõ tính sinh diệt của cả hai, các nhân và các quả, rồi lần lượt áp dụng ba đặc tướng và quán minh sát theo từng trường hợp. Hãy quán cả ba thời và cả hai dòng tương tục.

Sau khi quán nhiều lần như vậy, khi thích hợp cũng hãy quán tính bất tịnh của các pháp hữu vi danh sắc ấy. Sau khi quán thành thạo cả ba đặc tướng, có thể ưu tiên quán một đặc tướng mình ưa thích. Trong các phương pháp như phương pháp danh sắc và phương pháp năm uẩn cũng vậy, hãy ưu tiên đối tượng mình ưa thích và quán đi quán lại nhiều lần.

Hết chương Tuệ sinh diệt.


<a id="M09-body-P171"></a>
## Chương Tuệ hoại diệt
Miến / Burmese 171

Tiến đến tuệ hoại diệt

Khi quán minh sát các pháp hữu vi một cách thuần thục trong cả bốn oai nghi, các tuệ tu tập trước và sau nối tiếp nhau. Vì vậy, tuệ minh sát trở nên rất mạnh, có năng lực, sắc bén, tinh tế, thuần thục và ngày càng trong sạch. Khi tuệ minh sát đã trở nên sắc bén, tinh tế, thuần thục và trong sạch như vậy, nếu không còn tác ý đến sự sinh của các pháp hữu vi ấy mà chỉ chuyên chú tác ý đến sự diệt:

Ñāṇe tikkhe vahante saṅkhāresu lahuṃ upaṭṭhahantesu uppādaṃ vā ṭhitiṃ vā pavattaṃ vā nimittaṃ vā na sampāpuṇāti. Khayavayabhedanirodheyeva sati santiṭṭhati. (Vism. 2, 277.)

Na sampāpuṇātīti aggahaṇato. (Mahāṭī. 2, 439.)

1. Uppāda — sự sinh khởi của các pháp hữu vi, tức phương diện sinh.

2. Ṭhiti — sự trụ của các pháp hữu vi, tức phương diện trụ.

3. Nimitta — tướng của các pháp hữu vi, như nhóm sắc.

4. Pavatta — upādinnakapavatta, tức do các pháp nhân sinh,


<a id="M09-body-P172"></a>
## Chỉ lấy sự hoại diệt làm cảnh
Miến / Burmese 172

nên các pháp quả sinh.

Vì không tác ý đến các mục ấy, tuệ minh sát không còn đạt đến chúng. Các tuệ minh sát tu tập trước đó hỗ trợ mạnh mẽ các tuệ minh sát về sau bằng năng lực duyên y chỉ mạnh (upanissaya). Niệm đi cùng các tuệ về sau đã nhận được năng lực đặc biệt ấy an trụ vững chắc chỉ nơi tính tận, diệt, tan rã và chấm dứt của các pháp hữu vi. (Lời này nêu niệm để nói đến tuệ.) Khi ấy:

1. Aniccaṃ khayaṭṭhena — lấy sự tận, diệt, tan rã và chấm dứt của các pháp hữu vi làm cảnh, dùng tuệ nhìn cho thấy rõ và quán «vô thường, vô thường».

2. Dukkhaṃ bhayaṭṭhena — vì các pháp hữu vi cứ tận, diệt, tan rã, chấm dứt và biến mất, hãy lấy tính đáng sợ và hiểm nguy ấy làm cảnh, dùng tuệ nhìn cho thấy rõ và quán «khổ, khổ».

3. Anattā asārakaṭṭhena — lấy việc các pháp hữu vi không có tự ngã làm cốt lõi vững chắc làm cảnh, dùng tuệ nhìn cho thấy rõ và quán «vô ngã, vô ngã».

4. Khi thích hợp, cũng quán tính bất tịnh.

Điều cần lưu ý

Khi chỉ lấy sự diệt của các pháp hữu vi làm cảnh và áp dụng đặc tướng để quán minh sát như vậy, hãy thấy sự hoại diệt của các pháp hữu vi nhanh đến mức mình có thể. Còn khi áp dụng đặc tướng để quán minh sát là vô thường, hay là khổ, hay là vô ngã, hãy quán tương đối chậm.


<a id="M09-body-P173"></a>
## Khi các nhóm sắc biến mất
Miến / Burmese 173

Hãy thấy sự hoại diệt của nhiều lộ tâm, hay nhiều nhóm tâm, hay nhiều sắc pháp theo nhiều sát-na, nhanh đến mức mình có thể. Không cần rượt theo và áp dụng đặc tướng vô thường cho từng sự diệt mà mình thấy được ở mỗi nhóm tâm và mỗi sát-na sắc. Hãy lấy sự diệt của nhiều nhóm tâm và của sắc trong nhiều sát-na làm cảnh, rồi áp dụng đặc tướng tương đối chậm, chẳng hạn «vô thường, vô thường». Cũng làm như vậy với khổ và vô ngã. Nghĩa là hãy quán để thấy thật nhanh chính sự diệt của các pháp hữu vi. Riêng việc áp dụng đặc tướng thì quán tương đối chậm và thong thả. Hãy quán đi quán lại nhiều lần trong cả ba thời và cả hai dòng tương tục, dùng phương pháp danh sắc, phương pháp năm uẩn, v.v.

Các nhóm sắc đã biến mất

Nimittanti saṅkhāranimittaṃ, yaṃ saṅkhārānaṃ samūhādighanavasena, santatiparicchedena ca saviggahānaṃ viya upaṭṭhānaṃ, taṃ saṅkhāranimittaṃ. (Mahāṭī. 2, 439.)

Từ chương Kiến thanh tịnh, phần tuệ phân định danh sắc, người mới hành thiền đã tu tập minh sát, dùng tuệ đập tan các khối sắc và khối danh (rūpaghana và nāmaghana) để thấy các sắc pháp và danh pháp. Nay vị ấy đã đến chương Tuệ hoại diệt. Trước khi đạt tuệ hoại diệt, ở từng chương, vị ấy vẫn còn thấy:

1. Uppāda — vẫn thấy sự sinh, tính xuất hiện của các pháp hữu vi, tức danh sắc hữu vi làm nhân và danh sắc hữu vi làm quả.

2. Ṭhiti — vẫn thấy tính trụ tạm thời, tức tính già, của các pháp hữu vi ấy.


<a id="M09-body-P174"></a>
## Từ tướng của các hành đến tuệ hoại diệt
Miến / Burmese 174

3. Pavatta — vẫn thấy các pháp có tính diễn tiến của đời sống, gọi là upādinnakapavatta (Mahāṭī. 2, 439) hay bhavapavatti (Mahāṭī. 2, 447), tức sự hiện hữu của quả do sự hiện hữu của các nhân.

4. Nimitta — tuy đã dùng tuệ phá vỡ các khối sắc và khối danh gọi là rūpaghana và nāmaghana, và đang tu tập để tuệ thấy đạt đến chân đế, đôi khi vẫn còn một số nhóm sắc và nhóm danh mà tuệ chưa theo kịp, chưa thấu suốt. Đó là do các nhóm sắc và nhóm danh sinh khởi cực kỳ nhiều và cực kỳ nhanh. Trong các nhóm sắc và nhóm danh mà tuệ chưa theo kịp, chưa thấu suốt, những khối và cụm danh sắc như khối do tập hợp và khối do phận sự chưa vỡ. Vì vậy, vẫn còn thấy chúng theo từng nhóm sắc và nhóm danh, tức từng khối và từng cụm rất nhỏ. Đây là thấy tướng, các dấu hiệu làm chỗ nương cho các pháp hữu vi.

Tuy nhiên, khi đạt đến chương Tuệ hoại diệt này, vì tuệ minh sát đã trở nên cực kỳ sắc bén, tinh tế và trong sạch, các pháp hữu vi hiện ra hết sức nhanh chóng trong tuệ của người mới hành thiền:

1. Uppāda — tuệ không theo kịp để nắm bắt tính sinh, tính xuất hiện của các pháp hữu vi.

2. Ṭhiti — tuệ không theo kịp để nắm bắt tính trụ, tức tính già, của các pháp hữu vi.

3. Pavatta — sự hiện hữu và sinh khởi của các uẩn quả như thức, danh sắc, sáu xứ, xúc và thọ do sự hiện hữu và sinh khởi của các nhân như vô minh, ái, thủ, hành và nghiệp,


<a id="M09-body-P175"></a>
## Vì sao sự sinh, trụ và tướng không còn hiện rõ
Miến / Burmese 175

gọi là bhavapavatti, tức tính diễn tiến của đời sống, cũng là điều tuệ không theo kịp để nắm bắt. Vì sao?

Na sampāpuṇātīti aggahaṇato (Mahāṭī. 2, 439). Vì tuệ minh sát của người mới hành thiền không còn lấy sinh khởi, tức uppāda, làm cảnh, mà chỉ lấy riêng sự tan rã và diệt làm cảnh, tuệ không thấy sự sinh của các pháp hữu vi ấy mà chỉ thấy sự diệt. Vì vậy, tuệ không còn đạt đến tính sinh, tính xuất hiện hay tính trụ của các pháp hữu vi làm nhân và làm quả. Tuệ chỉ thể nhập và an trụ vững chắc nơi tính tịch diệt và tan rã, tức khaṇikanirodha, của các pháp hữu vi làm nhân và làm quả, những pháp đang tận, tan rã, diệt và biến mất ở từng sát-na. Vì không lấy sự sinh làm cảnh, tuệ minh sát cũng không còn đạt đến sự xuất hiện của nhân và sự xuất hiện của quả, tức tính sinh. Vì vậy, tuệ minh sát cũng không còn đạt đến upādinnakapavatta, tức tính sinh theo duyên (paccayato udayadassana), trong đó quả hiện hữu vì nhân hiện hữu.

4. Nimitta — Lại nữa, ở chương Tuệ hoại diệt, vì tuệ minh sát của người mới hành thiền đã trở nên hết sức sắc bén và tinh tế, vị ấy không còn thấy các khối và cụm sắc mà khối do tập hợp hay khối do phận sự vẫn chưa vỡ. Các hạt nhóm sắc, những khối và cụm nhỏ nhất, dường như có một hình thể hiện hữu do tính liên tục có nhân, và các nhóm danh cũng vậy, được gọi là tướng của các pháp hữu vi vì chúng là dấu hiệu để nhận ra các pháp hữu vi. Tuệ minh sát không còn thấy các tướng của các pháp hữu vi ấy. Bởi tuệ tùy quán hoại diệt chỉ thấy những sắc pháp và danh pháp riêng biệt đang tận, diệt, tan rã, biến mất và chấm dứt,


<a id="M09-body-P176"></a>
## Thấy rõ các pháp chân đế đang hoại diệt
Miến / Burmese 176

tức đang đi đến sự diệt trong từng sát-na. Tuy tuệ minh sát không thấy các khối và cụm gọi là nhóm sắc và nhóm danh, người mới hành thiền ở chương Tuệ hoại diệt này thường thấy các sắc pháp chân đế và danh pháp chân đế hết sức trong sáng và rõ rệt, khác với các chương tuệ trước. Đây chính là đặt chân vào phạm vi của các pháp chân đế riêng biệt.

Bấy giờ, khi đang thấy các pháp hữu vi đã đạt đến mức này tan rã và hoại diệt cực kỳ nhanh chóng, hiền giả hãy quán trong cả ba thời và cả hai dòng tương tục: 1. riêng sắc pháp, 2. riêng danh pháp, 3. sắc và danh cùng nhau.

Hãy lần lượt áp dụng ba đặc tướng và quán minh sát thuần thục. Tương tự, theo phương pháp năm uẩn, hãy tách từng uẩn trong năm thủ uẩn hiện hữu theo mười một phương diện, như quá khứ, vị lai, hiện tại, bên trong, bên ngoài v.v., rồi lần lượt áp dụng ba đặc tướng và quán minh sát thuần thục.

[Ghi chú — Hãy lưu ý rằng lời này không có nghĩa là các pháp hữu vi chỉ sinh khởi cực kỳ nhanh khi đạt đến chương Tuệ hoại diệt. Tính sát-na của các pháp hữu vi là chúng có thể sinh và diệt nhiều koṭi lần chỉ trong một cái chớp mắt, một tia chớp hay một cái búng tay. Khi các tuệ minh sát chưa sắc bén và tinh tế, người ta chưa biết và chưa thấy tính chất vốn có ấy của các pháp hữu vi.


<a id="M09-body-P177"></a>
## Minh sát trở lại chính tuệ đang quán
Miến / Burmese 177

Nay, khi đã đến phần Tuệ hoại diệt, các tuệ minh sát trở nên sắc bén và tinh tế, nên bằng tuệ minh sát người ta biết và thấy các pháp hữu vi tan rã và hoại diệt cực kỳ nhanh chóng. Đó là ý của lời này. Lại nữa, người mới hành thiền chỉ vì không tác ý đến sinh, trụ, diễn tiến và tướng của các pháp hữu vi ấy nên tuệ không theo kịp để nắm bắt chúng. Theo lời này, cũng hãy ghi nhớ rằng nếu tác ý thì vẫn có thể nắm bắt chúng. Kinh điển Udāna (77) cũng ghi lại rằng sau khi thành Phật, Đức Phật vẫn có thể tu tập và quán xét các pháp như hành sinh do vô minh, thức sinh do hành v.v. Các vị trưởng lão dòng Sakya đã ghi lại điều ấy.]

Dùng minh sát quán trở lại chính tuệ đang quán minh sát, tức paṭivipassanā

Ñātañca ñāṇañca ubhopi vipassati. (Vism. 2, 278.)

Khi người mới hành thiền dùng tuệ minh sát chỉ thấy riêng sự hoại diệt của các pháp hữu vi như vậy, hãy quán minh sát cả hai loại pháp gọi là ñāta và ñāṇa: các pháp hữu vi gọi là ñāta, tức sắc pháp và danh pháp làm nhân và làm quả trong cả ba thời và cả hai dòng tương tục, là những gì được tuệ minh sát quán và biết; và tuệ minh sát đang quán các pháp ñāta ấy, gọi là ñāṇa. Tuệ đang quán minh sát gọi là ñāṇa cũng nằm trong dòng lộ tâm tốc hành thiện qua ý môn. Na cảnh


<a id="M09-body-P178"></a>
## Mẫu quán cảnh và tuệ quán
Miến / Burmese 178

có thể sinh hoặc không sinh. Tuy nhiên, ở giai đoạn này, vì đã gần với tuệ minh sát mạnh như tuệ yếm ly (nibbidāñāṇa), nên thường không có na cảnh.

Hướng ý môn | Tốc hành (7 lần) | Na cảnh hữu nhân / na cảnh vô nhân (2 lần)
12 | 34/33 | 34/33 / 12/11

Hiền giả hãy quán minh sát cả tuệ minh sát đang quán ấy, tức dòng lộ tâm tốc hành thiện qua ý môn, bằng cách lần lượt áp dụng ba đặc tướng.

Một vài mẫu quán

1. Quán sắc: sắc diệt, vô thường. Tuệ quán cũng diệt, vô thường.

2. Quán danh: danh diệt, vô thường. Tuệ quán cũng diệt, vô thường.

(Quán khổ và vô ngã theo cùng cách.)

Khi quán như vậy: 1. lúc quán bên trong; 2. lúc quán bên ngoài; trong đó lại có 3. lúc quán sắc pháp; 4. lúc quán danh pháp; 5. lúc quán các pháp nhân; 6. lúc quán các pháp quả.

Hãy lần lượt áp dụng ba đặc tướng mà quán minh sát. Cũng hãy đổi sang quá khứ và vị lai rồi quán minh sát theo cùng cách. Tương tự, theo phương pháp năm uẩn, chia thành năm phần và quán minh sát cả các thủ uẩn hiện hữu theo mười một phương diện. Ở phần này, mẫu quán năm uẩn trong Anattalakkhaṇasutta là một cách quán hết sức quý báu để tuệ minh sát của hiền giả chín muồi thật nhanh.


<a id="M09-body-P179"></a>
## Sức thấy sự hoại diệt
Miến / Burmese 179

Khi quán minh sát các pháp nhân và các pháp quả, ở chương Tuệ hoại diệt này, vì không tác ý đến tính upādinnakapavatta, tức sự hiện hữu của quả do sự hiện hữu của nhân, nên vị ấy không thấy tính ấy. Tuy nhiên, vị ấy đã quán thường xuyên và đã biết, đã thấy bằng tuệ minh sát tính upādinnakapavatta ở các chương Tuệ liễu tri duyên, Tuệ thẩm sát và Tuệ sinh diệt. Vì vậy, ngay trong chương Tuệ hoại diệt này, nếu dùng tuệ minh sát bao quát và lấy các nhân như vô minh, các quả như hành làm cảnh, thì vẫn dễ dàng biết và thấy chúng. Dùng tuệ minh sát, vị ấy cũng có thể thấy tính hoại diệt của các nhân và quả ấy.

Sức thấy sự hoại diệt

Người mới hành thiền lần đầu tu tập tuệ tùy quán hoại diệt và mới đến phần tuệ tùy quán hoại diệt, khi tuệ này chưa chín muồi, sẽ chưa phải cứ ngồi thiền là lập tức luôn chỉ thấy sự diệt của các pháp hữu vi. Trước khi đạt tuệ hoại diệt, ở đầu buổi quán vẫn thấy cả sinh lẫn diệt ở mức tương đối. Khi quán minh sát, đến lúc tuệ trở nên sắc bén và tinh tế thì không còn thấy sự sinh của các pháp hữu vi mà chỉ thấy sự diệt. Chỉ đến khi tuệ hoại diệt đạt đỉnh cao, người ấy mới luôn dùng tuệ thấy riêng sự diệt của các pháp hữu vi. (Mahāṭī. 2, 441.)

Tato pana pubbabhāge anekākāravokārā anupassanā icchitabbā. (Mahāṭī. 2, 441.)

Để tuệ hoại diệt chín muồi, trước khi đạt đỉnh cao của tuệ ấy,


<a id="M09-body-P180"></a>
## Có thể ưu tiên quán điều mình ưa thích
Miến / Burmese 180

ở giai đoạn đầu cần tu tập minh sát theo nhiều phương pháp. (Mahāṭī. 2, 441.)

Có thể ưu tiên quán điều mình ưa thích

Ở chương Tuệ hoại diệt này, khi quán minh sát sự diệt của các pháp hữu vi, nếu quán minh sát sắc pháp thuận lợi hơn thì có thể ưu tiên quán sắc pháp. Nếu quán minh sát danh pháp thuận lợi hơn thì cũng có thể ưu tiên quán minh sát danh pháp. Chỉ nên làm như vậy sau khi đã quán minh sát nhiều lần cho thành thạo các mẫu quán. Lại nữa, nếu sức thấy sự diệt trong các danh pháp đã mạnh và các mẫu quán đã đầy đủ, thì nếu muốn có thể chỉ ưu tiên quán minh sát các danh pháp thuộc nhóm tốt trong các lộ tốc hành thiện. Trong đó cũng hãy ưu tiên quán các danh pháp ở các lộ tốc hành thiện qua ý môn. Cũng trong đó, nếu hiền giả là hành giả lấy thiền chỉ làm cỗ xe thì hãy ưu tiên quán minh sát các danh pháp thiền hiện diện trong các lộ tâm nhập thiền. Đối với ba đặc tướng cũng vậy, sau khi đã quán thành thạo cả ba, có thể ưu tiên quán đặc tướng mình ưa thích và quán thuận lợi hơn. Cũng có thể dùng các mẫu quán vật + cảnh + thọ, vật + cảnh + thức, và vật + cảnh + xúc để quán minh sát, kể cả sự hoại diệt của tuệ đang quán. Mẫu quán:

1. Quán vật: vật diệt, vô thường. Tuệ quán cũng diệt, vô thường.

2. Quán cảnh: cảnh diệt, vô thường. Tuệ quán cũng diệt, vô thường.

3. Quán thọ: thọ diệt, vô thường. Tuệ quán cũng diệt, vô thường.

Với các mẫu vật + cảnh + thức và vật + cảnh + xúc cũng hãy quán tiếp theo cùng cách. Khi áp dụng đặc tướng khổ và vô ngã cũng làm tương tự.


<a id="M09-body-P181"></a>
## Quán sự tan rã và chuyển sang niệm hơi thở
Miến / Burmese 181

Hãy quán. Quán cho đủ cả sáu môn. Quán cả hai dòng tương tục, bên trong và bên ngoài. Quán cả ba thời.

Đối với các cách quán theo oai nghi và tỉnh giác, cũng hãy lấy sự tan rã của các hành hiện hữu trong từng khoảnh khắc của từng oai nghi và từng hoạt động tỉnh giác làm cảnh để quán minh sát.

Đối với các chi của duyên khởi, cũng hãy chỉ lấy sự tan rã của chúng làm cảnh, áp dụng các đặc tướng và quán minh sát. Khi quán như vậy, hãy lấy riêng sự tan rã làm cảnh để quán minh sát, sau khi gác lại quan hệ nhân quả như sự sinh khởi của hành do vô minh v.v. Quán cả ba thời và cả hai dòng tương tục. Đôi khi trở lại quán bằng minh sát chính tuệ đang quán. Đó là minh sát đáp lại (paṭivipassanā).

Từ giai đoạn này cho đến khi đạt Thánh đạo, ở các giai đoạn tuệ hành giả cần quán minh sát sâu rộng: dùng tuệ minh sát thấy sự tan rã của riêng các hành gồm danh, sắc, nhân và quả hiện hữu trong ba thời quá khứ, tương lai và hiện tại, trong hai dòng tương tục bên trong và bên ngoài, và đôi khi thấy sự tan rã của riêng tuệ minh sát đang quán. Hãy lần lượt áp dụng ba đặc tướng.

Khi quán như vậy, các pháp danh thuộc thiền cũng nằm trong số các pháp danh. Đặc biệt, chúng bao gồm cả bốn tầng thiền niệm hơi thở. Nếu có thể quán minh sát sâu rộng bốn tầng thiền ấy đến mức tuệ tan rã, thì những cách quán trong bốn bộ bốn về niệm hơi thở do Đức Phật dạy cũng được bao hàm. Tuy vậy, vì những người tuệ còn non, các bộ bốn ấy sẽ được trình bày vắn tắt như sau.


<a id="M09-body-P182"></a>
## Niệm hơi thở — Bộ bốn thứ nhất
Miến / Burmese 182

1. Dīghaṃ vā assasanto “dīghaṃ assasāmī”ti pajānāti. Dīghaṃ vā passasanto “dīghaṃ passasāmī”ti pajānāti.

2. Rassaṃ vā assasanto “rassaṃ assasāmī”ti pajānāti. Rassaṃ vā passasanto “rassaṃ passasāmī”ti pajānāti.

3. “Sabbakāyapaṭisaṃvedī assasissāmī”ti sikkhati. “Sabbakāyapaṭisaṃvedī passasissāmī”ti sikkhati.

4. “Passambhayaṃ kāyasaṅkhāraṃ assasissāmī”ti sikkhati. “Passambhayaṃ kāyasaṅkhāraṃ passasissāmī”ti sikkhati. (M. 1, 70.)

1. Khi thở vào dài, biết rõ «Tôi đang thở vào dài». Khi thở ra dài, biết rõ «Tôi đang thở ra dài».

2. Khi thở vào ngắn, biết rõ «Tôi đang thở vào ngắn». Khi thở ra ngắn, biết rõ «Tôi đang thở ra ngắn». (M. 1, 70.)

3. Tập như sau: «Tôi sẽ thở vào, biết rõ toàn bộ hơi thở vào, từ đầu, giữa đến cuối». Tập như sau: «Tôi sẽ thở ra, biết rõ toàn bộ hơi thở ra, từ đầu, giữa đến cuối».

4. Tập như sau: «Tôi sẽ thở vào, làm lắng dịu thân hành gọi là hơi thở vào thô». «Tôi sẽ thở ra, làm lắng dịu thân hành


<a id="M09-body-P183"></a>
## Bộ bốn thứ nhất và chuẩn bị quán danh sắc
Miến / Burmese 183

gọi là hơi thở ra thô». (M. 1, 70.)

Trong bộ bốn thứ nhất này: 1. Dīgha là dài, tức độ dài của hơi thở vào và hơi thở ra. 2. Rassa là ngắn, tức độ ngắn của hơi thở vào và hơi thở ra. 3. Sabbakāya là toàn bộ, tức toàn bộ đầu, giữa và cuối của hơi thở vào và hơi thở ra. 4. Passambhayaṃ là tập làm cho lắng dịu, vi tế và an tịnh.

Việc thực hành bộ bốn niệm hơi thở thứ nhất đã được trình bày đầy đủ trong phần đề mục thiền chỉ, đến khi hơi thở lắng dịu và đạt tứ thiền. Bây giờ, đối với các thiện nhân đã thực hành đúng bộ bốn niệm hơi thở thứ nhất cho đến tứ thiền, các cách quán trong bộ bốn thứ hai v.v. sẽ được trình bày vắn tắt tiếp theo.

Khi các thiện nhân đã luyện định tứ thiền niệm hơi thở mình đạt được cho đến khi thuần thục năm pháp làm chủ, hãy lấy tứ thiền niệm hơi thở làm nền cho minh sát. Nghĩa là, mỗi lần ngồi thiền, trước hết hãy nhập thiền ấy. Khi xuất thiền:

1. Rūpapariggaha — nhận diện các pháp sắc. 2. Arūpapariggaha — nhận diện các pháp danh. 3. Rūpārūpapariggaha — nhận diện danh sắc. 4. Nāmarūpavavatthāna — phân định danh và sắc,


<a id="M09-body-P184"></a>
## Niệm hơi thở — Bộ bốn thứ hai
Miến / Burmese 184

5. Paccayapariggaha — nhận diện các nhân của danh sắc hiện tại. 6. Addhānapariggaha — nhận diện các nhân của danh sắc quá khứ và tương lai.

Sau khi tuần tự thực hiện các công việc ấy, khi đã có thể quán minh sát sâu rộng danh sắc cùng với các nhân bằng tuệ thẩm sát, tuệ sinh diệt và tuệ tan rã, hãy tiếp tục thực tập các cách quán thuộc bộ bốn thứ hai và các bộ tiếp theo ở dưới.

Niệm hơi thở — Bộ bốn thứ hai

1. “Pītipaṭisaṃvedī assasissāmī”ti sikkhati. “Pītipaṭisaṃvedī passasissāmī”ti sikkhati. 2. Sukhapaṭisaṃvedī, pe. 3. Cittasaṅkhārapaṭisaṃvedī, pe. 4. Passambhayaṃ cittasaṅkhāraṃ, pe. (Saṃ. 3, 279. Vi. 1, 78.)

1. Tập như sau: «Tôi sẽ thở vào, biết rõ hỷ». Tập như sau: «Tôi sẽ thở ra, biết rõ hỷ». 2. Biết rõ lạc, pe. 3. Biết rõ tâm hành, pe. 4. Làm lắng dịu tâm hành, pe.

1. Lấy tợ tướng niệm hơi thở làm cảnh, nhập sơ thiền và nhị thiền có hỷ. Khi hành giả nhập thiền chứng, vì đạt được thiền nên đối với tợ tướng niệm hơi thở


<a id="M09-body-P185"></a>
## Biết rõ hỷ trong thiền chỉ và minh sát
Miến / Burmese 185

mà mình đang biết rõ, hành giả lấy cảnh làm căn cứ và biết rõ hỷ của thiền. Khi đang thở và biết rõ hỷ của thiền như vậy, gọi là biết rõ hỷ theo phương diện cảnh. Hãy thở trong khi biết rõ hỷ như vậy. (Đây là phần thiền chỉ.) (Vism. 1, 279.)

Tuệ thấu rõ các pháp chân đế đến mức chân đế, đúng như thực tính của chúng, được gọi là vô si (asammoha). Hành giả hãy nhập sơ thiền niệm hơi thở. Khi xuất thiền, hãy dùng tuệ thấy sự tan rã và biến mất hoàn toàn của hỷ đi cùng thiền ấy, hoặc của tất cả các pháp danh của thiền bằng cách lấy hỷ làm chủ yếu. Hãy lần lượt áp dụng ba đặc tướng và quán xét bằng minh sát. Tương tự, hãy nhập nhị thiền. Khi xuất thiền, hãy dùng tuệ thấy sự tan rã, hủy hoại và biến mất hoàn toàn của hỷ đi cùng nhị thiền, hoặc của tất cả các pháp danh của thiền bằng cách lấy hỷ làm chủ yếu. Hãy lần lượt áp dụng ba đặc tướng và quán xét bằng minh sát. Trong lúc quán minh sát, vì thấu rõ đặc tướng riêng và đặc tướng chung của hỷ ấy, hoặc của các pháp danh của thiền đi cùng hỷ, hành giả biết rõ hỷ theo phương diện vô si, tức theo phương diện không mê lầm. Hãy thở trong khi biết rõ như vậy. (Đây là phần minh sát.) (Vism. 1, 279.)

2. Trong phần thiền chỉ, khi lần lượt nhập riêng sơ thiền, nhị thiền và tam thiền và thở, thì trong phần minh sát,


<a id="M09-body-P186"></a>
## Biết rõ lạc và làm lắng dịu tâm hành
Miến / Burmese 186

khi thở và lần lượt quán minh sát lạc đi cùng từng thiền ấy, hoặc các pháp danh của thiền bằng cách lấy lạc làm chủ yếu, lấy sự tan rã của chúng làm cảnh, thì gọi là thở trong khi biết rõ lạc. Hãy thở trong khi biết rõ lạc theo cách ấy. (Vism. 1, 280.)

3. Trong phần thiền chỉ, khi tuần tự nhập riêng cả bốn tầng thiền niệm hơi thở và thở, thì trong phần minh sát, khi thở và quán minh sát hai pháp thọ và tưởng gọi là tâm hành, hoặc thọ đi cùng tưởng, hoặc tất cả các pháp danh của thiền bằng cách lấy thọ làm chủ yếu, lấy sự tan rã của chúng làm cảnh, thì gọi là thở trong khi biết rõ tâm hành. Hãy thở trong khi biết rõ tâm hành như vậy. Hãy tập để có thể thở như vậy. (Vism. 1, 280.)

4. Trong phần thiền chỉ, khi tuần tự nhập riêng từng tầng trong bốn tầng thiền niệm hơi thở và thở, gọi là thở trong khi làm lắng dịu và chấm dứt các tâm hành thô. Trong phần minh sát, hãy lần lượt nhập từng thiền ấy. Mỗi lần xuất khỏi một thiền, nhận diện các pháp danh của thiền ấy, lấy thọ làm chủ yếu. Khi quán minh sát lấy làm cảnh tính hoàn toàn tan rã, hủy hoại, biến mất và chấm dứt của chúng, tức khaya, vaya, bheda và nirodha, gọi là thở trong khi làm lắng dịu và chấm dứt các tâm hành thô. Hãy tập để có thể thở như vậy. (Vism. 1, 280.)


<a id="M09-body-P187"></a>
## Niệm hơi thở — Bộ bốn thứ ba
Miến / Burmese 187

Trong pītipaṭisaṃvedī, hỷ được nêu đứng đầu để chỉ thọ. Trong sukhapaṭisaṃvedī, đó là lạc thọ. Trong các bước về tâm hành, hai pháp tưởng và thọ được gọi là tâm hành, nhưng lời dạy lấy thọ đi cùng tưởng làm chủ yếu. Vì vậy, hãy hiểu rằng Đức Phật đã dạy bộ bốn thứ hai theo phương pháp quán thọ (vedanānupassanā). (Vism. 1, 280.)

Niệm hơi thở — Bộ bốn thứ ba

1. “Cittapaṭisaṃvedī assasissāmī”ti sikkhati. “Cittapaṭisaṃvedī passasissāmī”ti sikkhati. 2. Abhippamodayaṃ cittaṃ, pe. 3. Samādahaṃ cittaṃ, pe. 4. Vimocayaṃ cittaṃ, pe. (Saṃ. 3, 279. Vi. 1, 78.)

1. Tập như sau: «Tôi sẽ thở vào, biết rõ tâm thiền». Tập như sau: «Tôi sẽ thở ra, biết rõ tâm thiền». 2. Làm tâm hết sức hân hoan, phấn chấn và vui mừng, pe. 3. Đặt tâm vững vàng, quân bình trên cảnh, pe. 4. Giải thoát tâm khỏi các pháp đối nghịch, pe.

1. Trong phần thiền chỉ, hãy lần lượt nhập từng tầng trong bốn tầng thiền niệm hơi thở và thở. Trong phần minh sát, hãy lần lượt nhập mỗi thiền ấy. Mỗi lần xuất thiền, hãy thấy sự tan rã của tâm thiền ấy, hoặc của tất cả các pháp danh của thiền bằng cách lấy tâm thiền làm chủ yếu,


<a id="M09-body-P188"></a>
## Biết rõ tâm và làm tâm hân hoan
Miến / Burmese 188

rồi thở trong khi quán minh sát, thì gọi là thở trong khi biết rõ tâm thiền. Hãy tập để có thể thở như vậy. (Vism. 1, 280.)

2. Trong phần thiền chỉ, hãy nhập sơ thiền niệm hơi thở có hỷ và thở. Hãy nhập nhị thiền niệm hơi thở có hỷ và thở. Khi nhập các thiền ấy, vì có hỷ đi cùng tâm thiền nên tâm thiền hết sức hân hoan, phấn chấn và vui mừng. Hãy thở trong khi dùng hỷ của thiền như vậy làm cho tâm thiền hết sức hân hoan, phấn chấn và vui mừng. Hãy tập để có thể thở như vậy.

Trong phần minh sát, hãy nhập sơ thiền niệm hơi thở có hỷ. Khi xuất sơ thiền, hãy quán minh sát để thấy sự tan rã của hỷ đi cùng thiền ấy, hoặc của tất cả các pháp danh của thiền bằng cách lấy hỷ làm chủ yếu. Hãy nhập nhị thiền niệm hơi thở có hỷ. Khi xuất thiền, hãy quán minh sát để thấy sự tan rã của hỷ đi cùng thiền ấy, hoặc của tất cả các pháp danh của nhị thiền bằng cách lấy hỷ làm chủ yếu. Trong lúc quán minh sát, vì lấy hỷ đi cùng thiền làm cảnh, tâm minh sát đang quán hỷ ấy cũng hết sức hân hoan, phấn chấn và vui mừng. Hãy tập để có thể thở trong khi làm tâm hết sức hân hoan, phấn chấn và vui mừng như vậy. Hãy thở như vậy. (Vism. 1, 280–281.)

Hãy hiểu điều ấy như khi gặp một người bạn thân thiết, vui vẻ mà mình rất quý mến, thì niềm vui cũng nở rộ trong dòng tâm tương tục của chính mình, người gặp bạn ấy.


<a id="M09-body-P189"></a>
## Định tâm trong thiền chỉ và minh sát
Miến / Burmese 189

3. Samādahaṃ cittaṃ — Thở trong khi đặt tâm vững vàng. Ở đây cũng có hai phần, thiền chỉ và minh sát. Trong phần thiền chỉ, khi nhập sơ thiền niệm hơi thở và thở, khi nhập nhị thiền và thở, khi nhập tam thiền và thở, khi nhập tứ thiền và thở, gọi là thở trong khi đặt tâm thiền vững vàng, quân bình trên cảnh là tợ tướng niệm hơi thở hết sức trong sáng, rực rỡ, vốn là cảnh của các thiền ấy. Hãy tập để có thể thở như vậy. Hãy thở như vậy. (Vism. 1, 281.)

[Ghi chú — Trong khi nhập tứ thiền niệm hơi thở, không có hơi thở. Vậy tại sao vẫn chỉ dẫn rằng hãy nhập tứ thiền niệm hơi thở và thở trong khi đặt tâm thiền vững vàng trên cảnh là tợ tướng niệm hơi thở? Câu trả lời như sau: «Assāsapassāse nissāya uppannanimittampettha assāsapassāsasāmaññameva vuttaṃ.» (Mahāṭī. 1, 139.) Theo giải thích này của Phụ chú giải, tợ tướng niệm hơi thở sinh nương vào hơi thở vào và hơi thở ra cũng được gọi chung là niệm hơi thở. Do đó, lấy tợ tướng niệm hơi thở làm cảnh cũng được gọi là lấy chính hơi thở vào và hơi thở ra làm cảnh. Vì thế Chú giải đã giải thích theo cách trên.] Trong phần minh sát có đoạn như sau:

Tāni vā pana jhānāni samāpajjitvā vuṭṭhāya jhānasampayuttaṃ cittaṃ khayato vayato sammasato vipassanākkhaṇe lakkhaṇapaṭivedhena uppajjati khaṇikacittekaggatā. Evaṃ uppannāya khaṇikacittekaggatāya vasenāpi ārammaṇe cittaṃ samaṃ ādahanto samaṃ ṭhapento “samādahaṃ


<a id="M09-body-P190"></a>
## Định sát-na trong minh sát
Miến / Burmese 190

cittaṃ assasissāmi passasissāmīti sikkhatī”ti vuccati. (Vism. 1, 281.)

Khaṇikacittekaggatāti khaṇamattatthitiko samādhi. Sopi hi ārammaṇe nirantaraṃ ekākārena pavattamāno paṭipakkhena anabhibhūto appito viya cittaṃ niccalaṃ ṭhapeti. Tena vuttaṃ “evaṃ uppannāyā”tiādi. (Mahāṭī. 1, 142.)

Hãy nhập sơ thiền niệm hơi thở. Khi xuất thiền, hãy thấy sự tan rã của tâm đi cùng sơ thiền ấy, hoặc của tất cả các pháp danh của thiền bằng cách lấy tâm thiền làm chủ yếu, rồi quán minh sát. Khi quán như vậy, vào lúc minh sát, hành giả thấu rõ các đặc tướng riêng và đặc tướng chung của tâm thiền ấy, hoặc của các pháp danh của thiền đi cùng tâm ấy. Vì hành giả thấu rõ từng sát-na tâm, tâm tu tập minh sát an trụ vững vàng trên phương diện vô thường, khổ hoặc vô ngã của các hành gọi là pháp thuộc thiền. Định đi cùng tuệ minh sát đang an trụ vững vàng như vậy được gọi là nhất tâm sát-na (khaṇikacittekaggatā), tức định sát-na (khaṇikasamādhi). Nhờ định sát-na ấy, hãy thở trong khi đặt tâm tu tập minh sát một cách quân bình, vững vàng trên một trong các phương diện vô thường, khổ hay vô ngã của các hành thuộc thiền đã được nhận diện với tâm thiền làm chủ yếu. Hãy tập để có thể thở như vậy. Đối với nhị thiền và các thiền tiếp theo cũng theo cách ấy. (Vism. 1, 281. Mahāṭī. 1, 142.)


<a id="M09-body-P191"></a>
## Lưu ý về định sát-na và giải thoát tâm
Miến / Burmese 191

Một điều cần đặc biệt lưu ý

Ở đây, sau khi nhập từng thiền niệm hơi thở và xuất thiền, lúc quán minh sát các hành thuộc thiền, gọi là các pháp thuộc thiền, với tâm thiền làm chủ yếu, định minh sát an trụ vững chắc trên một phương diện như tính vô thường của các hành ấy được gọi là nhất tâm sát-na (khaṇikacittekaggatā), tức định sát-na (khaṇikasamādhi). Hãy lưu ý điểm này. Hãy ghi nhận mức độ cao của định sát-na được nói đến trong phần minh sát.

4. Vimocayaṃ cittaṃ — Hãy thở trong khi giải thoát tâm khỏi các pháp đối nghịch. Ở đây cũng có hai phần, thiền chỉ và minh sát. Trong phần thiền chỉ, hãy thở trong khi nhập các thiền ấy, giải thoát tâm khỏi các triền cái bằng sơ thiền, khỏi tầm và tứ bằng nhị thiền, khỏi hỷ bằng tam thiền, và khỏi lạc và khổ bằng tứ thiền. Hãy tập, nỗ lực và tu tập nhiều để có thể thở như vậy. (Vism. 1, 281.)

Trong phần minh sát, hãy nhập sơ thiền niệm hơi thở. Sau khi xuất thiền, dùng tuệ minh sát thấy tính tiêu hoại và diệt mất (khaya, vaya) của tâm thiền đi cùng sơ thiền ấy, tức của tất cả các pháp danh của sơ thiền với tâm thiền làm chủ yếu. Hãy áp dụng các đặc tướng và quán minh sát. Tương tự:

Nhập nhị thiền. Pe.

Nhập tam thiền. Pe.

Nhập tứ thiền. Sau khi xuất thiền ấy, đối với tâm thiền đi cùng tứ thiền, tức đối với tất cả các pháp danh của tứ thiền với tâm thiền làm chủ yếu,


<a id="M09-body-P192"></a>
## Giải thoát tâm bằng các phép quán minh sát
Miến / Burmese 192

hãy dùng tuệ minh sát thấy tính tiêu hoại và diệt mất (khaya, vaya) của chúng. Hãy áp dụng các đặc tướng và quán minh sát.

Hành giả giải thoát tâm và thở: bằng quán vô thường (aniccānupassanā), giải thoát khỏi tưởng thường. Bằng quán khổ (dukkhānupassanā), giải thoát khỏi tưởng lạc. Bằng quán vô ngã (anattānupassanā), giải thoát khỏi tưởng ngã. Nhờ áp dụng ba đặc tướng và quán minh sát như vậy, bằng quán yếm ly (nibbidānupassanā), tức phương diện nhàm chán, xa lìa các hành, giải thoát khỏi sự ưa thích và say đắm các hành một cách vui sướng. Nhờ nhiều lần áp dụng các đặc tướng và quán giai đoạn tan rã (bhaṅga) của các hành, bằng quán ly tham (virāgānupassanā), tức phương diện không còn say đắm các hành, giải thoát khỏi tham ái bám víu vào các hành. Bằng quán diệt (nirodhānupassanā), quán giai đoạn chấm dứt của các hành, giải thoát khỏi tập khởi. Nhờ nhiều lần áp dụng các đặc tướng vào giai đoạn tan rã (bhaṅga) của các hành và quán minh sát, bằng quán xả ly (paṭinissaggānupassanā), tức phương diện đoạn trừ phiền não bằng cách thay thế từng phần và hướng đến Niết-bàn bằng sự hướng tâm về đó, giải thoát tâm khỏi sự chấp các hành là thường v.v. Khi có thể thở như vậy, gọi là thở trong khi giải thoát tâm khỏi các pháp đối nghịch. Hãy tập, nỗ lực và tu tập nhiều để có thể thở như vậy. (Vism. 1, 281.)

Hãy hiểu rằng Đức Phật đã dạy bộ bốn thứ ba này theo phương diện quán tâm (cittānupassanā). (Vism. 1, 281.)


<a id="M09-body-P193"></a>
## Niệm hơi thở — Bộ bốn thứ tư
Miến / Burmese 193

1. “Aniccānupassī assasissāmī”ti sikkhati. “Aniccānupassī passasissāmī”ti sikkhati. 2. Virāgānupassī, pe. 3. Nirodhānupassī, pe. 4. Paṭinissaggānupassī, pe.

1. Tập như sau: «Tôi sẽ thở vào trong khi thường xuyên quán đi quán lại các hành là vô thường». Tập như sau: «Tôi sẽ thở ra trong khi thường xuyên quán đi quán lại các hành là vô thường».

2. Thường xuyên quán đi quán lại giai đoạn tan rã của các hành và Niết-bàn, nơi ly tham, tức quán ly tham (virāgānupassanā). Pe.

3. Thường xuyên quán đi quán lại sự chấm dứt của các hành trong từng sát-na, tức giai đoạn tan rã trong từng sát-na, và Niết-bàn, nơi chấm dứt, tức quán diệt (nirodhānupassanā). Pe.

4. Tuệ minh sát có thể xả bỏ phiền não bằng cách thay thế từng phần. Tuệ Thánh đạo có thể xả bỏ phiền não dứt hẳn bằng cách đoạn tận. Tập như sau: «Tôi sẽ thở vào, thường xuyên quán đi quán lại giai đoạn tan rã của các hành và Niết-bàn, nơi các hành chấm dứt và được xả bỏ, để thành tựu hai tuệ ấy». Pe. Tập như vậy với hơi thở ra. (Saṃ. 3, 279. Vi. 1, 78.)

Aniccanti pañcakkhandhā. (Vism. 1, 281.)

1. Năm uẩn bị chấp thủ, cùng với các nhân của chúng, hiện hữu dưới mười một phương diện là quá khứ, tương lai, hiện tại, bên trong, bên ngoài, thô, tế, thấp kém, cao quý, xa và gần,


<a id="M09-body-P194"></a>
## Quán vô thường, ly tham, diệt và xả ly
Miến / Burmese 194

là các pháp vô thường. Năm uẩn ấy bao gồm các pháp danh của thiền và các hành tạp (pakiṇṇakasaṅkhāra), tức các hành của danh, sắc và pháp gọi là những hành được kết hợp. Theo cách giảng về các sự thật, đó chính là các pháp thuộc khổ đế và tập đế. Tuệ minh sát thường xuyên quán đi quán lại các hành ấy là vô thường gọi là tuệ quán vô thường. Hãy thở trong khi đầy đủ tuệ quán vô thường ấy, tức hãy tập để có thể thở như vậy.

2–3–4. Những tuệ minh sát bậc cao, bắt đầu bằng tuệ quán tan rã, có thể làm cho phiền não phai đi, chấm dứt và được xả bỏ bằng cách thay thế từng phần. Chúng cũng có thể hướng về và đi vào chiều hướng Niết-bàn, vì có thể nghiêng về Niết-bàn. Do vậy chúng được gọi là tuệ quán ly tham, tuệ quán diệt và tuệ quán xả ly.

Tuệ Thánh đạo làm cho phiền não phai đi, chấm dứt và được xả bỏ dứt hẳn bằng cách đoạn tận. Vì lấy Niết-bàn làm cảnh nên tuệ ấy cũng hướng về và đi vào chiều hướng Niết-bàn. Do vậy, tuệ ấy cũng được gọi là tuệ quán ly tham, tuệ quán diệt và tuệ quán xả ly.

Hãy thở trong khi thành tựu tuệ quán ly tham, tuệ quán diệt và tuệ quán xả ly ấy. Nghĩa là, hãy thở trong khi quán minh sát, lấy sự tan rã của các hành làm cảnh. Hãy thở trong khi lấy Niết-bàn, nơi các hành chấm dứt, làm cảnh. Hãy tập để có thể thở như vậy. (Xem Vism. 1, 281–282.)


<a id="M09-body-P195"></a>
## Phạm vi thực hành của bốn bộ bốn
Miến / Burmese 195

Đức Phật đã dạy bộ bốn niệm hơi thở thứ tư này theo phương diện thuần minh sát. Ba bộ bốn trước được Đức Phật dạy theo phương diện thiền chỉ và minh sát. (Vism. 1, 282.)

Yasmā panettha ādimeva catukkaṃ ādikammikassa kammaṭṭhānavasena vuttaṃ, uttarāni pana tīṇi catukkāni ettha pattajjhānassa vedanācittadhammānupassanāvasena vuttāni. (Vism. 1, 269.)

Đức Phật dạy bộ bốn thứ nhất theo phương diện đề mục thiền chỉ cho người mới bắt đầu thực hành đề mục niệm hơi thở. Đó chính là niệm xứ quán thân. Đối với người hành thiền đã đạt thiền trong bộ bốn thứ nhất này, Đức Phật dạy ba bộ bốn là bộ thứ hai, thứ ba và thứ tư theo phương diện niệm xứ quán thọ, niệm xứ quán tâm và niệm xứ quán pháp. (Vism. 1, 269.)

Theo các giải thích này của Chú giải, phải nỗ lực đạt thiền trong bộ bốn thứ nhất rồi mới tuần tự chuyển sang bộ bốn thứ hai, bộ bốn thứ ba và bộ bốn thứ tư. Trong bộ bốn thứ tư, Đức Phật chỉ dẫn quán minh sát cả các hành danh sắc gọi là các hành tạp (pakiṇṇakasaṅkhāra), ngoài các pháp danh của thiền. Vì thế, các thiện nhân hãy quán minh sát tất cả các hành gọi là khổ đế và tập đế.

Đối với đề mục niệm hơi thở này, trong bốn bộ bốn như Đức Phật đã dạy, có mười sáu cách cho hơi thở vào và mười sáu cách cho hơi thở ra. Khi có thể thực hành đầy đủ cả ba mươi hai phương diện này,


<a id="M09-body-P196"></a>
## Lợi ích của niệm hơi thở
Miến / Burmese 196

nếu biết cách thở như Đức Phật đã dạy, có thể đạt được những lợi ích sau.

Lợi ích và công đức. Ānāpānassati, bhikkhave, bhāvitā bahulīkatā cattāro satipaṭṭhāne paripūreti. Cattāro satipaṭṭhānā bhāvitā bahulīkatā satta bojjhaṅge paripūrenti. Satta bojjhaṅgā bhāvitā bahulīkatā vijjāvimuttiṃ paripūrenti. (Ma. 3.124.)

Này các tỳ-khưu… Niệm hơi thở, được tu tập đầy đủ theo 32 phương diện và thực hành nhiều lần, làm viên mãn bốn niệm xứ. Bốn niệm xứ, được tu tập đầy đủ và thực hành nhiều lần, làm viên mãn bảy giác chi cao quý. Bảy giác chi cao quý, được tu tập đầy đủ và thực hành nhiều lần, làm viên mãn hai pháp là minh và giải thoát: minh là bốn tuệ Thánh đạo, giải thoát là bốn tuệ Thánh quả. (Ma. 3.124.)

Mong thiện nhân nỗ lực tu tập và thực hành để trở thành người biết cách thở theo ý Đức Phật, bậc có lòng đại bi.

Hết chương Tuệ hoại diệt (bhaṅgañāṇa).


<a id="M09-body-P197"></a>
## Từ tuệ hiện khởi là đáng sợ đến tuệ hành xả
Miến / Burmese 197

Hành giả nhiều lần tu tập tuệ quán hoại diệt, lấy sự diệt từng sát-na (khaṇikanirodha), tức sự tan rã và biến mất hoàn toàn của mọi pháp hành hiệp thế thuộc ba cõi, trong quá khứ, vị lai, hiện tại, nội và ngoại, làm cảnh. Khi tuệ quán hoại diệt đã đạt mức cao nhất, thấy sự hoại diệt của các pháp hành liên tục và rõ ràng, cả các pháp hành trong dòng tương tục của hành giả lẫn sự sinh khởi của những pháp ấy trong ba cõi đều hiện ra như bị sự hoại diệt không ngừng bức bách, gây khổ và nguy hại. Bởi tính khổ ấy hiện quá rõ, ngay cả các cõi sắc và vô sắc vốn được cho là an tĩnh, an lạc cũng hiện ra với tính khổ đáng sợ. Trí ấy là tuệ hiện khởi là đáng sợ (bhayatupaṭṭhānañāṇa).

Lại nữa, tuệ minh sát nhiều lần thấy các khuyết điểm của các pháp hành trong ba thời, hai dòng tương tục và ba cõi, tức tính vô thường, khổ, vô ngã, biến đổi và hoại diệt. Trí ấy là tuệ quán nguy hại (ādīnavānupassanāñāṇa).


<a id="M09-body-P198"></a>
## Tuệ quán nhàm chán, tuệ muốn thoát khỏi và tuệ quán xét lại
Miến / Burmese 198

Khi nhiều lần thấy những khuyết điểm như thế, tuệ minh sát sinh khởi với sự chán lìa mọi pháp hành trong ba thời và ba cõi. Trí ấy là tuệ quán nhàm chán (nibbidānupassanāñāṇa).

Trong dòng tâm của người nam hay người nữ hành thiền đã chán lìa như thế, không còn vui thích dù chỉ một pháp hành trong các pháp hành thuộc ba thời và ba cõi. Họ muốn thoát khỏi tất cả các pháp hành. Tuệ minh sát sinh với tâm muốn thoát khỏi mọi pháp hành ấy là tuệ muốn thoát khỏi (muñcitukamyatāñāṇa).

Với tâm muốn thoát khỏi mọi pháp hành, lại dùng tuệ minh sát phân biệt và nhận diện tất cả các pháp hành, quán chúng là vô thường, quán là khổ, quán là vô ngã, quán là bất tịnh. Tuệ minh sát quán như thế là tuệ quán xét lại (paṭisaṅkhānupassanāñāṇa). Ở giai đoạn này cũng có thể quán lại theo bốn mươi cách tu, tức bốn mươi cách quán theo đuôi -to, đã trình bày ở phần Tuệ quán theo nhóm. (Xem Visuddhimagga về các cách quán khác.)

Khi đã phân biệt và nhiều lần quán minh sát các pháp hành trong ba thời và ba cõi, luân phiên nội và ngoại, sắc và danh, nhân và quả, vô thường, khổ, vô ngã và bất tịnh, thì sự hoại diệt của các pháp hành ấy hiện rõ và hết sức nhanh chóng trong tuệ minh sát…


<a id="M09-body-P199"></a>
## Tâm minh sát an trú trên sự hoại diệt
Miến / Burmese 199

…Sự hoại diệt dường như dày đặc hơn. Hãy tiếp tục quán minh sát chính tính hoại diệt ấy, luân phiên đặt dưới ba đặc tướng.

Khi có thể quán như thế, dần dần tâm tu tập minh sát đạt đến mức quân bình và thản nhiên đối với các pháp hành, không còn lo sợ hay mong mỏi chúng. Tâm tu tập minh sát an trú vững vàng trên cảnh hoại diệt của chính các pháp hành ấy.

Khi tâm tu tập đã vững, các lộ tâm ngũ môn nhận biết năm cảnh là sắc, thanh, hương, vị và xúc không còn sinh. Phía các danh pháp làm cảnh và phía tuệ minh sát đang quán đều thường chỉ còn các lộ tốc hành qua ý môn. Lúc ấy:

Trong khi quán minh sát luân phiên nội và ngoại, sắc và danh, và lần lượt áp dụng ba đặc tướng:

Nếu khi quán nội mà tâm tu tập minh sát an trú vững trên cảnh các pháp hành nội, hãy tiếp tục chỉ quán các pháp hành nội. Nếu khi quán ngoại mà tâm tu tập minh sát an trú vững trên cảnh các pháp hành ngoại, hãy tiếp tục chỉ quán các pháp hành ngoại. Nếu cứ đổi qua đổi lại giữa nội và ngoại, định minh sát có thể tan mất.

Cũng vậy, nếu khi quán minh sát sắc pháp, tâm tu tập minh sát an trú trên các sắc hành ấy, tức cảnh hoại diệt của các sắc hành ấy…


<a id="M09-body-P200"></a>
## Con đường cần đi với niệm vững mạnh
Miến / Burmese 200

…hãy tiếp tục quán minh sát chính các sắc pháp ấy. Nếu khi quán minh sát danh pháp, tâm tu tập minh sát an trú vững trên các danh hành ấy, tức cảnh hoại diệt của các danh hành ấy, hãy tiếp tục quán minh sát chính các danh pháp ấy. Nếu lúc này cứ đổi qua đổi lại giữa sắc và danh, định minh sát có thể tan mất.

Ở giai đoạn này cần đặc biệt nỗ lực với niệm để cân bằng tín với tuệ và tinh tấn với định. Chỉ khi năm căn là tín, tinh tấn, niệm, định và tuệ quân bình mới có thể đạt đến tuệ Thánh đạo và tuệ Thánh quả.

Khi đang lấy sự hoại diệt của danh pháp làm cảnh và quán minh sát bằng cách luân phiên đặt dưới ba đặc tướng, nếu chưa đạt xả quân bình đối với sự hoại diệt của các pháp hành, dù cách quán đã thành thục từ một lúc trước, hãy ưu tiên quán danh pháp thuộc tốc hành thiện dục giới. Nếu thiện nhân là người lấy thiền chỉ làm cỗ xe, ở giai đoạn này có thể ưu tiên quán danh pháp thuộc thiền, tức các pháp thiền thiện trong tâm nhập thiền. Trong ba đặc tướng, đặc biệt ưu tiên đặt chúng dưới đặc tướng vô ngã mà quán minh sát.

Trong khi quán như thế, tâm tu tập minh sát sẽ an trú vững trên cảnh hoại diệt của các pháp hành. Khi ấy…


<a id="M09-body-P201"></a>
## Ưu tiên cảnh và đặc tướng thấy rõ
Miến / Burmese 201

…hành giả không còn nghe tiếng động bên ngoài. Khi không còn nghe tiếng động, nếu tâm tu tập minh sát an trú vững vàng, bất động trên cảnh hoại diệt của các pháp hành, thì sức tu tập minh sát đã trở nên đặc biệt mạnh.

Ở giai đoạn ấy, như đã giải thích trên, hãy quán thử lúc nội, lúc ngoại. Nếu tâm tu tập vững ở nội, hãy quán nội. Nếu tâm tu tập vững ở ngoại, hãy quán ngoại. Nếu tâm tu tập vững nơi sắc pháp, hãy quán sắc pháp. Nếu tâm tu tập vững nơi danh pháp, hãy quán danh pháp. Hãy ưu tiên đặc tướng mình thích hợp.

Khi quán như thế, một số hành giả thích quán cả danh và sắc cùng nhau hơn. Một số thích quán riêng sắc hơn. Một số thích quán riêng danh hơn. Một số thích quán là vô thường hơn, một số thích quán là khổ hơn, và một số thích quán là vô ngã hơn.

Hãy quán các pháp hành mình quán rõ hơn và áp dụng đặc tướng thấy rõ hơn để quán minh sát. Khi quán như thế, một số hành giả có thể hoàn toàn không thấy sự hoại diệt của sắc pháp mà chỉ thấy sự hoại diệt của danh pháp. Khi ấy, chỉ cần đặt sự hoại diệt của danh pháp dưới đặc tướng mà quán. Đừng cố tìm sự hoại diệt của sắc pháp chưa thấy để quán.


<a id="M09-body-P202"></a>
## Quán danh pháp và thành tựu xả
Miến / Burmese 202

Lúc ấy, đối với người lấy thuần minh sát làm cỗ xe, các danh pháp đang diệt thường chỉ là các lộ tốc hành qua ý môn đang quán minh sát và các tâm hữu phần. Hãy dùng tâm sau quán tâm trước, tức dùng tâm minh sát sau quán tâm minh sát trước.

Nếu là người lấy thiền chỉ làm cỗ xe, các danh pháp đang diệt thường chỉ gồm các danh pháp trong tâm nhập thiền và nhóm danh pháp thuộc tốc hành minh sát. Lúc ấy hãy tiếp tục nhiều lần đặt dưới đặc tướng và quán minh sát cả các danh pháp thiền đang được ưu tiên quán lẫn các danh pháp tốc hành minh sát đang quán. Ở giai đoạn này, người lấy thiền chỉ làm cỗ xe thường tiến triển tốt hơn nếu quán danh pháp thiền mình ưa thích và ưu tiên đặc tướng vô ngã.

Một số hành giả vẫn thấy sự hoại diệt của cả danh và sắc. Khi ấy, dù quán luân phiên sắc và danh hay quán cả hai cùng nhau, chỉ lấy sự hoại diệt làm cảnh và tiếp tục quán minh sát, ưu tiên đặc tướng mình thích hợp. Thỉnh thoảng cũng quay lại quán minh sát chính trí đang quán.

Khi quán minh sát theo nhiều cách như thế, xả quân bình đối với các pháp hành trong ba cõi dục, sắc và vô sắc sẽ an trú vững vàng. Tính ghê tởm, bất tịnh của các pháp hành cũng hiện rõ vững vàng.

Bhayañca nandiñca vippahāya sabbasaṅkhāresu udāsīno hoti majjhatto. (Visuddhi. 2.294.)


<a id="M09-body-P203"></a>
## Tuệ hành xả
Miến / Burmese 203

Do thấy rõ khuyết điểm của các pháp hành, hành giả muốn thoát khỏi chúng. Khi đang quán minh sát bằng cách đặt sự hoại diệt của các pháp hành dưới từng đặc tướng, hành giả không còn thấy một pháp hành nào có thể chấp là “ta, của ta”. Do đó:

1. Từ bỏ một cực đoan là sợ hãi các pháp hành (bhaya).

2. Từ bỏ một cực đoan là thích thú và mong cầu các pháp hành (nandi).

Sau khi bỏ hai cực đoan này, sự thản nhiên và quân bình đối với tất cả các pháp hành xuất hiện. Trí này của hành giả là tuệ hành xả (saṅkhārupekkhāñāṇa).

Hết chương Tuệ hành xả.


<a id="M09-body-P204"></a>
## Tiến đến Tri kiến thanh tịnh
Miến / Burmese 204

Tiến đến Tri kiến thanh tịnh (ñāṇadassanavisuddhi)


<a id="M09-body-P205"></a>
## Từ tuệ hành xả đến tuệ Thánh đạo
Miến / Burmese 205

Tiến đến Tri kiến thanh tịnh. Từ tuệ hành xả đến tuệ Thánh đạo.

Khi tuệ hành xả chín muồi và thật sự biết được pháp cao quý Nibbāna là tịch tịnh, là giới không sinh không diệt vì vắng bặt các pháp hành danh sắc, tâm buông bỏ tính sinh khởi của mọi pháp hành, không còn thấy sự hoại diệt của chúng và hướng thẳng vào Nibbāna, giới tịch tịnh, nơi các pháp hành vắng bặt và lắng dịu, không sinh không diệt. (Visuddhi. 2.294.)

Bao lâu tuệ hành xả chưa thực sự thấy pháp cao quý Nibbāna, giới tịch diệt, theo tính an tịnh (santisukha), tức an lạc tịch tịnh, thì tuệ hành xả chưa chín muồi. Trong lúc ấy chỉ các pháp hành còn là cảnh, nghĩa là trí vẫn chỉ sinh khởi khi lấy sự hoại diệt của các pháp hành làm cảnh. (Visuddhi. 2.295.)

Khi ấy, để tuệ hành xả chín muồi, hãy quán:

1. Khi thì các sắc pháp.

2. Khi thì các danh pháp.

3. Khi thì nội.

4. Khi thì ngoại.


<a id="M09-body-P206"></a>
## Làm chín muồi tuệ hành xả
Miến / Burmese 206

5. Khi thì đặt dưới đặc tướng vô thường.

6. Khi thì đặt dưới đặc tướng khổ.

7. Khi thì đặt dưới đặc tướng vô ngã. Hãy nhiều lần quán minh sát.

8. Khi thì các pháp làm nhân.

9. Khi thì các pháp làm quả. Cũng hãy nhiều lần quán minh sát, luân phiên đặt dưới ba đặc tướng. Quán tương tự đối với quá khứ và vị lai. Lại quán minh sát theo cách phân năm uẩn.

Nếu hành giả lấy thiền chỉ làm cỗ xe, hãy trở lại quán minh sát, ưu tiên các danh pháp trong thiền chứng mình ưa thích, và trong ba đặc tướng hãy ưu tiên đặc tướng vô ngã. Đặc biệt ưu tiên quán các danh pháp tứ thiền bằng cách đặt dưới đặc tướng vô ngã. Thỉnh thoảng cũng trở lại quán minh sát chính trí đang quán, tức danh pháp tốc hành minh sát. Khi tuệ hành xả đã chín muồi:

1. Từ tính hoại diệt của các pháp hành gọi là pavatta, tức sự tiếp diễn,

2. Trí sẽ chuyển sang tính không sinh không diệt, gọi là appavatta, tức sự không tiếp diễn.

Nếu vẫn chưa thể đạt đến đó, hãy thử nỗ lực tu minh sát quán từng pháp (anupadadhamma-vipassanā). Chẳng hạn, hãy nhập sơ thiền. Khi xuất sơ thiền, nhận diện toàn bộ 34 danh pháp sơ thiền. Hãy quán minh sát từng danh pháp thiền bằng cách đặt từng pháp dưới một đặc tướng. Quán luân phiên nội và ngoại. Tương tự, đối với các tầng thiền đã đạt cho đến thiền phi tưởng phi phi tưởng xứ…


<a id="M09-body-P207"></a>
## Quán từng pháp và thấy thế gian là trống không
Miến / Burmese 207

…hãy quán minh sát các tầng thiền theo phương pháp quán từng pháp. Hãy quán đủ ba đặc tướng. Cũng hãy quán danh pháp dục giới và sắc pháp theo phương pháp minh sát quán từng pháp. Khi quán sắc pháp theo phương pháp này, hãy quán minh sát từng giới chân đế, bắt đầu từ địa giới, trong mỗi nhóm sắc, như nhóm mười sắc nhãn, bằng cách đặt từng pháp dưới một đặc tướng. Hãy quán minh sát từng sắc pháp có ở sáu môn và bốn mươi hai phần thân, không bỏ sót pháp nào. Quán luân phiên nội và ngoại.

[Các vị đệ tử không thể quán minh sát từng danh pháp có trong thiền chứng phi tưởng phi phi tưởng xứ theo phương pháp quán từng pháp. Các vị chỉ có thể quán minh sát theo phương pháp thẩm sát theo nhóm (kalāpasammasana). Vì vậy, hãy bỏ qua tầng thiền ấy khi quán theo phương pháp quán từng pháp.]

Cũng có thể đạt đến trí đạo và trí quả bằng phương pháp minh sát quán từng pháp này. Nếu vẫn chưa đạt, hãy trở lại quán minh sát theo phương pháp thẩm sát theo nhóm như đã nêu, bắt đầu từ tuệ quán theo nhóm đến tuệ hành xả. Có thể thành tựu tùy theo sức ba-la-mật.

Hãy nhìn cho thấy sự trống không.

Suññato lokaṃ avekkhassu, Mogharāja sadā sato. Attānudiṭṭhiṃ ūhacca, evaṃ maccutaro siyā. Evaṃ lokaṃ avekkhantaṃ, maccurājā na passati. (Khu. 1.448.)


<a id="M09-body-P208"></a>
## Người mà vua Chết không thể thấy
Miến / Burmese 208

Mogharāja: Này thiện nam tử Mogharāja. Sadā: ban ngày hay ban đêm, bất cứ lúc nào, thường xuyên. Sato: có niệm vững vàng về bốn niệm xứ. Attānudiṭṭhiṃ: thân kiến (sakkāyadiṭṭhi), tức ngã kiến đã quen xem các pháp hành là tự ngã. Ūhacca: hãy nhổ bỏ bằng các tuệ minh sát như tuệ phân biệt danh sắc và tuệ phân biệt duyên. Lokaṃ: thế giới các pháp hành danh sắc. Suññato: theo tính trống không, không có cốt lõi thường, lạc, ngã hay tịnh. Avekkhassu: hãy dùng tuệ nhãn minh sát nhìn đi nhìn lại và tu tập thẩm sát. Evaṃ: khi đã tu tập thẩm sát theo cách ấy. Maccutaro: người có thể vượt qua vua Chết, kẻ cai trị ba mươi mốt cõi. Siyā: sẽ trở thành như vậy. Evaṃ: theo tính trống không như thế. Lokaṃ: thế giới các pháp hành danh sắc. Avekkhantaṃ: người đang dùng tuệ nhãn minh sát nhìn đi nhìn lại và tu tập thẩm sát. Maccurājā: vua Chết, kẻ cai trị ba mươi mốt cõi. Na passati: không bao giờ thấy được.

Người mà vua Chết không thể thấy. Theo lời dạy trên, nếu thiện nhân biết quán thế giới các pháp hành bằng tuệ minh sát để thấy là trống không, thì có thể trở thành người mà vua Chết không thấy được. Có thể chứng ngộ Nibbāna cao quý, bất tử, bằng tuệ Thánh đạo và tuệ Thánh quả.

Có thể chuyển từ pavatta sang appavatta, từ lĩnh vực sinh khởi sang lĩnh vực không sinh khởi. Hãy tập trú trong lĩnh vực không sinh không diệt, cũng gọi là lĩnh vực tận cùng của sinh diệt, hay lĩnh vực tận diệt, theo thời lượng…


<a id="M09-body-P209"></a>
## Năm phép phản khán và lời kết
Miến / Burmese 209

…đã nguyện trước. Hãy tập phân định thời lượng và trú trong đó mỗi khi muốn.

1. Phản khán đạo.

2. Phản khán quả.

3. Phản khán Nibbāna.

4. Phản khán các phiền não đã đoạn trừ.

5. Phản khán các phiền não chưa đoạn trừ.

Hãy học từ các bậc thầy và thực hành năm phép phản khán (paccavekkhaṇa) ấy.

Nếu vẫn chưa thỏa đáng, hãy kiên nhẫn kiểm tra bằng nhiều cách, nhiều lần, qua nhiều ngày, nhiều tháng, nhiều năm, xem trong dòng tương tục của mình các phiền não đáng lẽ đã hết có thật sự hết chưa. Chớ vội đi đến kết luận chắc chắn.

Cũng cần kiểm tra nhiều lần xem trí biết Bốn Sự Thật đã vững chắc hay chưa. Cần nhiều lần đến tham vấn những vị thầy lớn thông thạo cả pháp học và pháp hành.

Thiền sư Pa-Auk Tawya
Tu viện Cittala Taung
Pa-Auk Tawya
Niên lịch Miến Điện 1367


<a id="M09-index-P001"></a>
## Miến 210 — trang trắng
Chỉ mục / Index - Miến / Burmese 210


<a id="M09-index-P002"></a>
## Chỉ mục theo thứ tự chữ cái
Chỉ mục / Index - Miến / Burmese 211

Đề mục theo thứ tự chữ cái | Trang
Đề mục theo thứ tự chữ cái | Trang

[အ]

Lợi ích và công đức — 196

Sáu loại tạm thời — 98

Chỉ những pháp dễ nhận diện — 92

Là tai họa (aghato) — 77

Là gốc tai họa (aghamūlato) — 83

Kết luận của Chú giải — 22

Những lời của Chú giải và Phụ chú giải — 39

Giải thích của Chú giải Aṭṭhasālinī — 12

Không có sự che chở (atāṇato) — 81

Quá khứ, vị lai, hiện tại, bên trong, bên ngoài — 112

Quá khứ, hiện tại, vị lai — 48

Người nghèo túng tột bậc — 85

Điểm đặc biệt cần lưu ý — 191

Hiện tại theo đời (addhāpaccuppanna) — 44

Pháp hiện tại theo đời — 147

Là không bền (addhuvato) — 72

Kiến văn do thực hành (adhigamasuta) — 131

Tướng thiền chỉ gọi là adhicitta — 153

Thắng giải (adhimokkha), tức tín — 159

Là vô ngã (anattato) — 89

Ánh sáng vô ngã — 22

Mẫu quán theo Kinh Đặc tướng Vô ngã — 51

Năm phương diện của đặc tướng vô ngã — 89

Hãy quán là vô ngã — 172

Cho đến vô lượng thế giới — 36

Các loại bệnh — 80

Là vô thường (aniccato) — 69

Lý do là vô thường, khổ, vô ngã — 92

Mười phương diện của đặc tướng vô thường — 69

Hãy quán là vô thường — 172

Tuệ tùy quán vô thường — 194

Phương pháp minh sát theo thứ tự — 25

Cách tu tập minh sát theo thứ tự — 206

Bốn phép tùy quán liên hệ với bốn niệm xứ như thế nào — 166

Hành không do chấp thủ (anupādinnakasaṅkhāra) — 39

Diệt không sinh trở lại (anuppādanirodha) — 119

Các hiểm họa — 81


<a id="M09-index-P003"></a>
## Chỉ mục theo thứ tự chữ cái
Chỉ mục / Index - Miến / Burmese 212

Đề mục theo thứ tự chữ cái | Trang
Đề mục theo thứ tự chữ cái | Trang

Kinh Aparijānana — 12

Bốn pháp vô lượng (appamaññā) — 5

Sức thấy sự hoại diệt — 179

Chỗ bắt đầu quán (abhinivesa) — 14

Vì sao cần hiện rõ thêm? — 154

Chẳng phải Thánh quả — 155

Chẳng phải Thánh đạo — 155

Có thể đạt đến Thánh đạo — 24

Không thể đạt Thánh đạo — 19

Cách quán theo bảy cách quán danh (arūpasattaka) — 100

Một chìa khóa quan trọng — 31

Không có nơi ẩn náu (aleṇato) — 82

Đức Bồ-tát học nơi các vị thầy — 22

Bất tịnh vô thức (aviññāṇaka-asubha), tức bất tịnh tử thi — 61

Pháp gọi là không si — 185

Tính không si — 137

Không có chỗ quy y (asaraṇato) — 82

Không có cốt lõi (asārakato) — 73

Tu tập bất tịnh — 57

[အာ]

Kiến văn do nghe học (āgamasuta) — 131

Cách quán sắc từ lúc nhận lấy đến lúc đặt xuống (ādānanikkheparūpa) — 95

Là mối bất lợi (ādīnavato) — 84

Tùy quán bất lợi (ādīnavānupassanā) — 58

Tuệ tùy quán bất lợi — 197

Hơi thở, nhóm bốn thứ tư — 193

Hơi thở, nhóm bốn thứ ba — 187

Hơi thở, nhóm bốn thứ hai — 184

Hơi thở, nhóm bốn thứ nhất — 182

Là chứng bệnh (ābādhato) — 79

Người mới bắt đầu minh sát — 149, 150

Sáu cảnh — 3

Cách quán sắc do vật thực sinh — 98

Hãy quán minh sát tất cả — 129

[က]

Cách quán ở phần oai nghi và tỉnh giác — 168

[ဣ]

Là hiểm họa (ītito) — 81

[ဥ]

Cách quán sắc do nhiệt độ sinh — 98


<a id="M09-index-P004"></a>
## Chỉ mục theo thứ tự chữ cái
Chỉ mục / Index - Miến / Burmese 213

Đề mục theo thứ tự chữ cái | Trang
Đề mục theo thứ tự chữ cái | Trang

Cách tu tập chi tiết tuệ sinh diệt — 113

Chương Tuệ sinh diệt — 110

Tiến trình thực hành minh sát sinh diệt — 147

Thấy sinh diệt của sắc uẩn — 123

Tính trung lập — 161, 203

Các cấu uế của minh sát (upakkilesa) — 149, 156

Sự hiện diện (upaṭṭhāna), tức niệm — 160

Là tai ách (upaddavato) — 80

Là tai ương (upasaggato) — 81

Sự diễn tiến của pháp do chấp thủ (upādinnakapavatta) — 171

Có tính não (upāyāsadhammato) — 87

Xả (upekkhā), gồm xả minh sát và xả hướng tâm — 160

Diệt của pháp đã sinh (uppādanirodha) — 119

Sinh (uppāda) — 171

Các loại tai ách — 80, 82

Hỷ nâng bổng (ubbegāpīti) — 157

[ဧ]

Phương pháp đồng nhất (ekatta) — 103, 140

[ဩ]

Hỷ từng đợt (okkantikāpīti) — 157

Ánh sáng (obhāsa) — 151

Thô (oḷārika) — 51

Các sắc thô (oḷārika) v.v. — 54

Thô, tế, hạ liệt, cao quý, xa, gần — 54

[က]

Cách quán sắc do nghiệp sinh — 99

Cách quán theo nhóm (kalāpa), tức quán gộp — 101

Minh sát theo phương pháp thẩm sát theo nhóm — 2

Thẩm sát theo nhóm và minh sát theo thứ tự — 24

Thân tùy quán niệm xứ — 169

Cách tu tập để vượt qua — 163

Hãy ưu tiên quán đặc tướng mình ưa thích — 41

[ခ]

Thấy sinh theo sát-na (khaṇato udayadassana) — 134, 136, 142

Thấy sinh diệt theo sát-na (khaṇato udayabbayadassana) — 135, 139, 145

Thấy diệt theo sát-na (khaṇato vayadassana) — 135, 136


<a id="M09-index-P005"></a>
## Chỉ mục theo thứ tự chữ cái
Chỉ mục / Index - Miến / Burmese 214

Đề mục theo thứ tự chữ cái | Trang
Đề mục theo thứ tự chữ cái | Trang

Cách quán theo sát-na — 105

Diệt theo sát-na (khaṇikanirodha) — 175

Hỷ chớp nhoáng (khaṇikāpīti) — 157

Chánh tạng Tương ưng Uẩn (Khandhavagga Saṃyutta) — 28

Ngôi nhà lớn của các uẩn — 59

Năm uẩn — 3

Phương pháp năm uẩn — 44, 111

Tiểu hỷ (khuddakāpīti) — 157

[ဂ]

Là ung nhọt (gaṇḍato) — 78

Kinh Girimānanda — 57

[စ]

Mẫu quán thọ uẩn thuộc nhãn thức — 122, 124

Là dao động (calato) — 71

Thức ăn, mồi nhử (āmisa) — 86

Tâm hành (cittasaṅkhāra) — 186

Cách quán sắc do tâm sinh — 99

Sáu loại tư (cetanā) — 4

[ဆ]

Nguồn gốc của sự khốn khổ — 84

[ဇ]

Có tính sinh, có tính già, có tính bệnh (jātidhammato, jarādhammato, byādhidhammato) — 87

[ဉ]

Tuệ minh sát gọi là ñāṇa — 177

Ñāṇa, tức tuệ minh sát, hướng đến chương Tri kiến thanh tịnh — 157

Các pháp hữu vi gọi là ñāta — 177

[ဌ]

Trụ (ṭhiti) — 171

[တ]

Làm cạn kiệt sự ưa thích do ái (taṇhānikanti) — 107

Sáu loại ái — 4

Tuệ minh sát còn non (taruṇavipassanāñāṇa) — 149

Là rỗng (tucchato) — 91

Bài pháp Teparivaṭṭadhamma — 2

Bốn mươi mẫu quán với hậu tố -to — 69

Cờ phướn và Đức Phật — 109

Lời nói sai lệch đang rao truyền — 24


<a id="M09-index-P006"></a>
## Chỉ mục theo vần Miến
Chỉ mục / Index - Miến / Burmese 215

[ထ]

Một điểm đặc biệt — 66

Bắt đầu từ chỗ rõ ràng, dễ quán — 10

Một loại ung nhọt nhô cao — 78

[ဒ]

Diṭṭhiugghāṭana — cách quán để nhổ bỏ kiến — 106

Tâm thắng trí thiên nhãn — 152

Dukkhato — là khổ — 75

Hai mươi lăm phương diện của đặc tướng khổ — 75

Hãy quán là khổ — 172

Dūra — xa — 51

Sáu môn — 3

[ဓ]

Cách quán sắc theo tính tự nhiên của pháp (dhammatā) — 100

Sáu loại pháp — 3

Quán pháp niệm xứ — 167

Sáu giới — 4

[န]

Minh sát theo phương pháp suy rộng (nayavipassanā) — 2

Nikantipariyādāna — cách quán để dứt sự ưa thích do ái, để nó không sinh khởi — 107

Nikanti — sự ưa thích minh sát — 163

Nibbidānupassanā — quán nhàm chán — 192

Tuệ quán nhàm chán (nibbidānupassanāñāṇa) — 198

Kinh Nimitta — 152

Tuệ quán sự diệt (nirodhānupassanāñāṇa) — 194

Bốn phương pháp hiện rõ thế nào — 140

Cách quán minh sát các danh pháp — 39

Có thể ưu tiên quán theo một trong hai cách mình ưa thích — 180

Minh sát theo phương pháp suy rộng với hai trăm (= 200) cách phân tích — 93

[ပ]

Đã là người thuần thục — 108

Paggaha — tinh tấn — 159

Chú giải Kinh Pacalāyamāna — 153

Paccayato udayadassana — thấy sự sinh theo duyên — 134, 139, 140, 144

Paccayato udayabbayadassana — thấy sinh diệt theo duyên — 134, 135, 136, 143

Paccayato vayadassana — thấy sự diệt theo duyên — 134, 136, 139

Vị bà-la-môn Pañcaggadāyaka và vợ — 56

Có thể làm viên mãn sự tu tập tuệ — 94


<a id="M09-index-P007"></a>
## Chỉ mục theo vần Miến
Chỉ mục / Index - Miến / Burmese 216

Cái gọi là chế định (paññatti) — 37

Chi duyên khởi — 25, 112

Các chi duyên khởi — 66

Phương pháp duyên khởi thứ nhất — 130

Các pháp duyên khởi hiện rõ thế nào — 139

Tuệ quán xả bỏ (paṭinissaggānupassanāñāṇa) — 194

Phần thanh tịnh do tri kiến về đạo lộ hành trì — tuệ minh sát bậc cao — 165

Cách quán theo trình tự — 105

Minh sát lại (paṭivipassanā) — 177

Tuệ quán xét lại (paṭisaṅkhānupassanāñāṇa) — 198

Thức uẩn lúc tái tục — 117

Thọ uẩn lúc tái tục — 115

Hành uẩn lúc tái tục (= tư) — 116

Hành uẩn lúc tái tục (= 34 trừ thọ, tưởng và thức, còn 31) — 116

Tưởng uẩn lúc tái tục — 115

Paṇīta — cao quý — 51

Sắc do tâm cao quý sinh — 159

Pabhaṅguto — là dễ tan vỡ — 71

Parato — là xa lạ — 90

Năm cách phân định (pariggaha) — 10

Paridevadhammato — là pháp phải bi — 87

Palokato — là tan rã — 71

Passaddhi — an tịnh minh sát — 158

Pīti — hỷ minh sát — 157

Các thiện phàm phu — 127

Đạo sơ phần (pubbabhāgamagga) — 1

Niệm các đời trước — 30

Căn nhà năm uẩn đầy giòi bọ — 59

[ဖ]

Pharaṇāpīti — hỷ lan tỏa — 157

Sáu xúc — 3

Kinh Pheṇapiṇḍūpama — 59

Đấng sáng tạo — 145

[ဗ]

Phạm thiên Baka — 43

[ဘ]

Phần tuệ hoại diệt (bhaṅgañāṇa) — 171

Tiến đến tuệ hoại diệt — 171

Từ tuệ kinh sợ đến tuệ hành xả — 197


<a id="M09-index-P008"></a>
## Chỉ mục theo vần Miến
Chỉ mục / Index - Miến / Burmese 217

Tuệ hiện khởi là đáng sợ (bhayatupaṭṭhānañāṇa) — 197

Bhayato — là đáng sợ — 80

Tính sinh khởi của hữu — 175

Chín loại hữu lớn — 4

Sự tiếp diễn của hữu (bhavapavatti) — 175

Sự sinh khởi của hữu — 84

Ý giới trong sáng của hữu phần — 32

Nơi nương tựa để tránh hiểm họa — 82

Các loại hiểm họa — 81

[မ]

Tâm ý thức — 152

Maraṇadhammato — là pháp phải chết (maccu) — 73

Các sắc pháp không thích hợp để quán — 36

Kinh Đại Niệm Xứ (Mahāsatipaṭṭhāna) — 113

Đại trưởng lão A-la-hán Mahāsīva — 61

Mānaugghāṭana — cách quán để nhổ bỏ mạn — 106

Mārāmisato — là mồi của Māra — 85

Tuệ muốn thoát khỏi (muñcitukamyatāñāṇa) — 198

Kinh Meghiya — 27

Thức ăn và vật nuốt của năm Māra — 87

Mũi tên và ngạnh tên — 79

[ယ]

Yamaka — cách quán theo cặp — 104

Bệnh khó chữa — 77

[ရ]

Những kết quả có thể đạt được — 134

Rittato — là trống rỗng — 90

Sắc uẩn — 114

Cách quán sắc uẩn — 120

Cách quán minh sát theo bảy phương diện về sắc (rūpasattaka) — 95

Cảnh sắc — sắc giới màu sắc — 150

Rogato — như bệnh — 77

Các nhóm sắc đã biến mất — 173

Quan điểm về sự chấm dứt của sắc và danh — 37

Phương pháp hai nhóm sắc và danh cùng phương pháp năm uẩn — 111

Hãy quán cả sắc và danh cùng nhau — 47

Tính bất tịnh của sắc chân đế — 60

Một số ví dụ về đối tượng quán — 68, 178

Phương pháp và trình tự quán — 63

Tâm minh sát trước và tâm minh sát sau — 102


<a id="M09-index-P009"></a>
## Chỉ mục theo vần Miến
Chỉ mục / Index - Miến / Burmese 218

Người mà Tử thần không thể thấy — 208

Những điểm giải thích — 126

[လ]

Năm đặc tính hiện rõ thế nào — 144

Ba đặc tướng — 20

Một loại kẻ giết người — 83

Những kẻ giết người — 83

Đạo đế hiệp thế — năm chi đạo hiệp thế — 137

Điều cốt yếu cần ghi nhớ — 20

Những quy định cần tuân theo — 12

Các việc cần thực hiện — 184

Cách trở lại con đường đúng — 156

[ဝ]

Vadhakato — như kẻ sát hại — 83

Vayadhammānupassī — quán tính hoại diệt — 132

Vayadhammānupassī — vayadassana — cách quán riêng sự diệt — 118

Cách quán sắc theo các giai đoạn tuổi đời (vayovuḍḍhatthagama) — 95, 96

Như vũ khí kim cương — 157

Sáu loại tứ — 4

Kinh Vijaya — 62

Minh (vijjā) — 196

Sáu thức — 3

Sáu loại tầm — 4

Vipariṇāmadhammato — là pháp phải biến đổi — 72

Định sát-na của minh sát — 138

Ánh sáng của tuệ minh sát — 154

Đối tượng được tuệ minh sát quán — 3

Tuệ minh sát và thắng trí — 28

Lộ tốc hành ý môn minh sát — 103

Cái gọi là minh sát — 49

Lại quán minh sát chính tuệ đang quán minh sát — 177

Vibhavato — là tiêu hoại — 73

Giải thoát (vimutti) — 196

Tuệ quán ly tham (virāgānupassanāñāṇa) — 194

Minh sát dẫn đến xuất khởi (vuṭṭhānagāminīvipassanā) — 16

Quán thọ niệm xứ — 170

Sáu thọ — 4

[သ]

Saṅkhatato — là hữu vi — 73


<a id="M09-index-P010"></a>
## Chỉ mục theo vần Miến
Chỉ mục / Index - Miến / Burmese 219

Tính tự nhiên của các hành (dhammatā) — 176

Sẽ xuất khỏi các hành — 21

Khổ của các hành — 76

Tướng của các hành — 171, 175

Hành và nghiệp hữu — 128

Từ tuệ hành xả đến tuệ Thánh đạo — 205

Bốn Thánh đế hiện rõ thế nào — 135

Sáu tưởng — 4

Con đường phải đi với niệm vững chắc — 200

Điều cần lưu ý — 8, 172

Các pháp hiện tại theo tương tục (santatipaccuppanna) — 147

Santika — gần — 51

Tính an lạc tịch tịnh — 205

Hành giả lấy thiền chỉ làm cỗ xe — 41

Samudayadhammānupassī — quán tính sinh khởi — 132

Samudayadhammānupassī — udayadassana — cách quán riêng sự sinh — 113

Samudayavayadhammānupassī — quán tính sinh và diệt — 133

Samudayavayadhammānupassī — udayavayadassana — cách quán sinh và diệt — 122

Phần tuệ quán theo nhóm (sammasanañāṇa) — người đang thực hành đúng đắn — 150

Sallato — như mũi tên — 79

Bất tịnh có thức — 57

Sāsavato — là còn lậu hoặc — 85

Ba chi đạo thuộc giới — 138

Sukha — lạc minh sát — 159

Sukhuma — tế — 51, 54

Hãy quán cho đến khi thấy tính rỗng không — 207

Suññato — là rỗng không — 89

Suññato và anattato — là rỗng không và vô ngã — 89

Phương pháp theo kinh — 69

Hành giả lấy minh sát thuần túy làm cỗ xe — 35

Hố nghĩa địa — 59

Người xa lạ bên ngoài — 91

Sokadhammato — là pháp phải sầu — 87

Saṅkilesikadhammato — là pháp dẫn đến ô nhiễm — 88

Để nâng đỡ ba loại chúng sinh — 5

Hãy phân định rồi bắt đầu quán minh sát từ chỗ dễ quán — 35

[ဟ]

Hīna — hạ liệt — 51
