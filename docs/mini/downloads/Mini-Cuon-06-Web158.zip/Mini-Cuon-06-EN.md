# Nibbānagāminipaṭipadā · Mini · Cuốn 6 / Volume 6
Dependent Origination — B
Pa-Auk Tawya Sayadaw
English

## Mục lục / Contents

- [Front and back cover](#M06-cover-P001)
- [Title page](#M06-front-P001)
- [The gift of Dhamma and aspiration](#M06-front-P002)
- [Table of contents — က](#M06-front-P003)
- [Table of contents — ခ](#M06-front-P004)
- [Table of contents — ဂ](#M06-front-P005)
- [Table of contents — ဃ](#M06-front-P006)
- [Table of contents — င](#M06-front-P007)
- [Table of contents — စ](#M06-front-P008)
- [Part 1 · Analysis of dependent origination according to the Discourses](#M06-body-P001)
- [Formations, consciousness, mentality-materiality, the six bases, contact, and feeling](#M06-body-P002)
- [Craving, clinging, becoming, birth, and aging and death](#M06-body-P003)
- [Death, sorrow, lamentation, pain, grief, and despair](#M06-body-P004)
- [End of the Pāli passage and explanation for memorization](#M06-body-P005)
- [Explanation of the factors of dependent origination for memorization](#M06-body-P006)
- [Ignorance and formations](#M06-body-P007)
- [Meritorious, demeritorious, and imperturbable formations](#M06-body-P008)
- [Bodily, verbal, and mental formations, and the kinds of consciousness](#M06-body-P009)
- [Consciousness as condition for mentality-materiality](#M06-body-P010)
- [Mentality-materiality as condition for the six bases, and the six bases as condition for contact](#M06-body-P011)
- [Contact as condition for feeling, and feeling as condition for craving](#M06-body-P012)
- [Craving as condition for clinging, and clinging as condition for becoming](#M06-body-P013)
- [Kamma-becoming and rebirth-becoming](#M06-body-P014)
- [Nine kinds of rebirth-becoming and the meaning of birth](#M06-body-P015)
- [Explanation of aging and death](#M06-body-P016)
- [Aging and death conditioned by birth, and the meaning of sorrow](#M06-body-P017)
- [Explanation of lamentation and bodily pain](#M06-body-P018)
- [Explanation of mental distress and anguish](#M06-body-P019)
- [Conclusion of the explanation according to the Discourses](#M06-body-P020)
- [What is the teaching of dependent origination?](#M06-body-P021)
- [Dependent origination and the Middle Way](#M06-body-P022)
- [What is the Middle Way leading to Nibbāna?](#M06-body-P023)
- [The Middle Way and suffering in the course of existence](#M06-body-P024)
- [Conditioning and conditioned phenomena](#M06-body-P025)
- [Multiple causes and multiple effects](#M06-body-P026)
- [Why the Buddha singles out individual causes and effects](#M06-body-P027)
- [Ignorance as the principal, evident, and distinctive cause](#M06-body-P028)
- [Three reasons for singling out a cause](#M06-body-P029)
- [Explanation of the term Paṭiccasamuppāda](#M06-body-P030)
- [Arising together and arising through proper conditions](#M06-body-P031)
- [Concurrence of conditions and arising together](#M06-body-P032)
- [Applying the name of the effect to the cause](#M06-body-P033)
- [The concurrence of causes and their joint support of effects](#M06-body-P034)
- [Further explanation of conditions that assist together](#M06-body-P035)
- [Effects are connected to all their respective causes](#M06-body-P036)
- [Causes facing one another and effects arising together](#M06-body-P037)
- [The third explanation in the Visuddhimagga](#M06-body-P038)
- [The supporting causes must all be present](#M06-body-P039)
- [Groups of materiality and mentality](#M06-body-P040)
- [The two meanings of saṃ in samuppāda](#M06-body-P041)
- [Five groups of causes that support formations](#M06-body-P042)
- [The collection of effects arises at the same time](#M06-body-P043)
- [Benefits of the teaching on dependent origination](#M06-body-P044)
- [The three rounds of defilements, kamma, and results](#M06-body-P045)
- [Eternalism and the doctrine of no cause](#M06-body-P046)
- [The doctrines of a wrong cause and an overriding ruler](#M06-body-P047)
- [Direct knowledge and the abandoning of wrong doctrines](#M06-body-P048)
- [Annihilationism, denial of results, and denial of the efficacy of action](#M06-body-P049)
- [Denial of kamma and its results](#M06-body-P050)
- [Seeing cause and effect across the three periods](#M06-body-P051)
- [The two words that make up Paṭiccasamuppāda](#M06-body-P052)
- [Further explanation of the Middle Way](#M06-body-P053)
- [The eight factors of the Noble Path](#M06-body-P054)
- [The Middle Way, and the doer and experiencer](#M06-body-P055)
- [Past kamma and results in the present life](#M06-body-P056)
- [Seeing cause and effect without finding a self](#M06-body-P057)
- [Doer and experiencer as conventional expressions](#M06-body-P058)
- [Kamma and result in the same continuity](#M06-body-P059)
- [Continuity and common usage](#M06-body-P060)
- [Using names without taking them as ultimate](#M06-body-P061)
- [Staying within the scope of convention](#M06-body-P062)
- [Four benefits of clearly seeing dependent origination](#M06-body-P063)
- [Part 2](#M06-body-P064)
- [The twelve factors of dependent origination and the three periods](#M06-body-P065)
- [The three periods and causal links](#M06-body-P066)
- [The third link and the four groups](#M06-body-P067)
- [Twenty aspects and a way of discerning to know beforehand](#M06-body-P068)
- [Discerning arising and passing away by condition and by moment](#M06-body-P069)
- [Discerning dissolution and the knowledge that discerns](#M06-body-P070)
- [Distinguishing ignorance and formations in each continuity](#M06-body-P071)
- [Ignorance conditions formations and the mind-door process](#M06-body-P072)
- [Formations condition consciousness](#M06-body-P073)
- [The power of formations and the arising of resultant consciousness](#M06-body-P074)
- [The kinds of resultant consciousness to discern](#M06-body-P075)
- [Examples for discerning resultant consciousness outside a process and in the eye-door process](#M06-body-P076)
- [Resultant consciousness in the six series, and consciousness conditioning mentality-materiality](#M06-body-P077)
- [Resultant and non-resultant consciousness, and three kinds of conditioning consciousness](#M06-body-P078)
- [Kamma-consciousness is formative consciousness](#M06-body-P079)
- [Resultant mentality-materiality and process-free examples](#M06-body-P080)
- [Resultant mentality-materiality in the eye-door process](#M06-body-P081)
- [Accumulating formations and kamma-becoming](#M06-body-P082)
- [Distinguishing formations and kamma-becoming. Examples of conascent consciousness](#M06-body-P083)
- [How to take conascent mentality-materiality and consciousness within a process](#M06-body-P084)
- [Death consciousness, five-door adverting and sense-consciousness](#M06-body-P085)
- [Mentality-materiality of receiving through registration](#M06-body-P086)
- [Supporting passages and five cases of mentality-materiality conditioning the six bases](#M06-body-P087)
- [How mentality conditions the mind base](#M06-body-P088)
- [The mind base from receiving to mind-door adverting](#M06-body-P089)
- [Mentality conditioning the mind base and the material bases](#M06-body-P090)
- [Cases of postnascence condition](#M06-body-P091)
- [Postnascence condition and the supporting characteristic](#M06-body-P092)
- [Later mentality sustains earlier materiality](#M06-body-P093)
- [A pattern for discerning the eye base separately](#M06-body-P094)
- [A pattern for discerning the eye base separately, continued](#M06-body-P095)
- [A pattern for discerning the five material bases together](#M06-body-P096)
- [Materiality conditioning a material base within the same group](#M06-body-P097)
- [Nutriment supporting the material bases, and materiality supporting the mind base](#M06-body-P098)
- [The material bases on which the mind base depends](#M06-body-P099)
- [Examples of material bases and the mind base, from life-continuum to receiving](#M06-body-P100)
- [Examples of material bases and the mind base, from investigating to registration](#M06-body-P101)
- [Mentality and materiality jointly conditioning the mind base](#M06-body-P102)
- [Examples of mentality-materiality conditioning the mind base](#M06-body-P103)
- [Applying the pattern to the six kinds of cognitive process](#M06-body-P104)
- [The six bases condition contact](#M06-body-P105)
- [The six internal and six external bases](#M06-body-P106)
- [Conditions for rebirth-linking mind-contact](#M06-body-P107)
- [Rebirth-linking objects and mind-contact in five-door adverting](#M06-body-P108)
- [Mind-contact in five-door adverting and eye-contact](#M06-body-P109)
- [Contact in the eye-door process, through the first impulsion](#M06-body-P110)
- [Mind-contact in registration and mind-door adverting](#M06-body-P111)
- [Consciousnesses to discern in the same process](#M06-body-P112)
- [Contact conditions feeling, and the six kinds of feeling](#M06-body-P113)
- [The scope of feeling conditioned by eye-contact](#M06-body-P114)
- [Feeling in the eye-door process](#M06-body-P115)
- [In what sense does eye-contact condition feeling at five-door adverting?](#M06-body-P116)
- [Six examples of contact conditioning feeling and the definition of mind-contact](#M06-body-P117)
- [Mind-contact and feeling conditioning craving](#M06-body-P118)
- [Craving for sensual pleasures, becoming and non-becoming](#M06-body-P119)
- [Resultant feeling supports craving by decisive support condition](#M06-body-P120)
- [Looking toward future existence and examples of feeling conditioning craving](#M06-body-P121)
- [Craving for mental objects and the case of Arahants](#M06-body-P122)
- [Craving does not arise in Arahants, and craving conditions clinging](#M06-body-P123)
- [The four kinds of clinging](#M06-body-P124)
- [An example of craving conditioning clinging when aspiring to a future life](#M06-body-P125)
- [A way of discerning the three kinds of craving separately](#M06-body-P126)
- [Clinging to a doctrine of self and the cognitive processes of craving and clinging](#M06-body-P127)
- [A point to note, and clinging conditioning becoming](#M06-body-P128)
- [Kamma-becoming, rebirth-becoming, and a point to note](#M06-body-P129)
- [Knowledge of discerning conditions and discernment directed to a future life](#M06-body-P130)
- [A concise pattern of discernment for memorization](#M06-body-P131)
- [Examples of becoming and the mind-door process with impulsions](#M06-body-P132)
- [Jhāna kamma-becoming and becoming conditioning birth](#M06-body-P133)
- [Discerning birth and a question about kamma-becoming](#M06-body-P134)
- [Kamma distinguishes beings](#M06-body-P135)
- [Birth conditioning aging and death in conventional and ultimate terms](#M06-body-P136)
- [Birth conditioning sorrow, lamentation, pain, grief and despair](#M06-body-P137)
- [Table 1 — Taking the present life as the center](#M06-body-P138)
- [Table 2 — Taking the first past life as the center](#M06-body-P139)
- [Table 3 — Taking the first future life as the center](#M06-body-P140)
- [Cognitive processes of sorrow, lamentation, pain, grief and despair](#M06-body-P141)
- [Four ways of teaching dependent origination](#M06-body-P142)
- [From middle to end](#M06-body-P143)
- [From end to beginning](#M06-body-P144)
- [From middle to beginning](#M06-body-P145)
- [Craving as the source of the four nutriments](#M06-body-P146)
- [Discerning dependent origination in forward order, the second method](#M06-body-P147)
- [Feeling and attachment](#M06-body-P148)
- [Discernment starting from the six sense bases or feeling](#M06-body-P149)
- [Connecting cause and result in successive pairs of lives](#M06-body-P150)
- [Discerning dependent origination in reverse order, the first method](#M06-body-P151)
- [Discerning three lives in reverse order](#M06-body-P152)
- [Discerning in reverse order from middle to beginning. The four nutriments](#M06-body-P153)
- [Nutriments of the round of results and other nutriments](#M06-body-P154)
- [Kamma-born and non-kamma-born nutriments](#M06-body-P155)
- [Physical nutriment and nutritive essence](#M06-body-P156)
- [Temperature-born nutritive essence](#M06-body-P157)
- [The functions of the four nutriments](#M06-body-P158)
- [Mental volition and consciousness as nutriment](#M06-body-P159)
- [Nutriment in the specific and general senses](#M06-body-P160)
- [Nutriment sustains the material body](#M06-body-P161)
- [Two ways in which nutriment supports](#M06-body-P162)
- [Discernment beginning from the four nutriments in the round of results](#M06-body-P163)
- [Discernment beginning from the four nutriments in the round of kamma](#M06-body-P164)
- [Another explanation](#M06-body-P165)
- [The three periods in discernment from nutriment](#M06-body-P166)
- [Two reasons for teaching in four ways](#M06-body-P167)
- [Why the Buddha taught from ignorance to aging and death](#M06-body-P168)
- [Why the Buddha taught from the middle to the end and from the end back to the beginning](#M06-body-P169)
- [The great diamond-like insight knowledge](#M06-body-P170)
- [From the four nutriments back to ignorance](#M06-body-P171)
- [The Buddha’s words on the depth of dependent origination](#M06-body-P172)
- [Closing words and colophon](#M06-body-P173)
- [Index — Burmese page 174](#M06-index-P001)
- [Index — Burmese page 175](#M06-index-P002)
- [Index — Burmese page 176](#M06-index-P003)
- [Index — Burmese page 177](#M06-index-P004)
- [Index — Burmese page 178](#M06-index-P005)
- [Index — Burmese page 179](#M06-index-P006)
- [Index — Burmese page 180](#M06-index-P007)
- [Index — Burmese page 181](#M06-index-P008)

<a id="M06-cover-P001"></a>
## Front and back cover
Bìa / Cover

Nibbānagāminipaṭipadā — The Practice Leading to Nibbāna (Abridged), Volume 6. Dependent Origination (Paṭiccasamuppāda) — B. Pa-Auk Tawya Sayadaw.

Words of blessing (Āsīsakathā) by the venerable Sayadaw of Pyay

Comparing the various works, from the Yojanā and the ṭīkās to the Madhu and Gaṇṭhi,
he expounds the wheel of dependent origination, so profound and hard to see.
Tracing it turn by turn and link by link, he distinguishes its parts with care.
He brings to light the meaning so hard to fathom,
setting it forth and resolving it clearly and accurately.

Like fine butter blended with sweet palm syrup,
smooth, fragrant and rich in sweetness,
he sets it before the reader to taste.
Whoever tastes this book as one tastes nectar
is cleansed of wrong views and doubts within,
and can speak clearly of mentality, materiality and ultimate reality.

Like one who stands firm in a contest of learning,
meeting a profound question and answering promptly and clearly, each answer correct,
true to the texts and reaching the essential point.
The great scholars marvel and offer praise,
and devas, humans and the assembled people pay their respects.
May the reader become a person of virtue and wisdom.

(Pyay, Visuddhimagga Nissaya, vol. 4, p. 267.)


<a id="M06-front-P001"></a>
## Title page
Đầu sách / Front matter - 1

Nibbānagāminipaṭipadā — The Practice Leading to Nibbāna (Abridged), Volume 6. Dependent Origination (Paṭiccasamuppāda) — B. Pa-Auk Tawya Sayadaw.


<a id="M06-front-P002"></a>
## The gift of Dhamma and aspiration
Đầu sách / Front matter - 2

Sabbadānaṃ dhammadānaṃ jināti.
Sabbarasaṃ dhammaraso jināti.
Sabbaratiṃ dhammarati jināti.
Taṇhakkhayo sabbadukkhaṃ jināti.

The gift of Dhamma surpasses every gift.
The taste of Dhamma surpasses every taste.
Delight in Dhamma surpasses every delight.
The destruction of craving overcomes all suffering.

Ciraṃ tiṭṭhatu saddhammo, dhamme hontu sagāravā.

May the Buddha’s dispensation endure for a long time. May all honour the three kinds of true Dhamma.


<a id="M06-front-P003"></a>
## Table of contents — က
Đầu sách / Front matter - 3

Namo tassa bhagavato arahato sammāsambuddhassa.

Dependent Origination — B. Table of contents.

Part 1 — 1

Pāli Analysis of Dependent Origination — Analysis according to the Discourses (Suttantabhājanīya) — 1

Meaning of the Pāli passage for memorization — 5

What is the teaching of dependent origination? — 21

The Middle Way (Majjhimā paṭipadā) — 22

What is the Middle Way leading to Nibbāna? — 23

What is dependent origination? — 24

Explanation of the term Paṭiccasamuppāda — 30

Explanation by another method — 33

Further explanation — 35

Groups of materiality and mentality (rūpakalāpa, nāmakalāpa) — 40

For arriving at a firm conclusion — 44

Benefits and advantages — 44

1. The word paṭicca — 44

2. The word samuppāda — 48

3. Paṭicca and samuppāda — 52

Further explanation — 1. The Middle Way — 53

2. The doer and the experiencer — 55

3. Common usage (janapadanirutti) — 60

4. Not overrunning conventional designation (samaññāya anatividhāvana) — 62


<a id="M06-front-P004"></a>
## Table of contents — ခ
Đầu sách / Front matter - 4

Part 2 — 65

The twelve factors of dependent origination — 65

Three periods — 65

Three links — 66

Four groups — 67

Twenty aspects — 68

A method of discernment to learn first — 68

Marking each part separately — 71

With ignorance as condition, formations — 72

Mind-door process — 72

With formations as condition, consciousness — 73

Consciousness — 74

Resultant consciousness as mind-consciousness — 75

Examples of discernment — Process-free consciousness — 76

Resultant consciousness in eye-door processes — 76

With consciousness as condition, mentality-materiality — 77

Kamma-consciousness is formative consciousness (abhisaṅkhāraviññāṇa) — 79

Mentality and materiality — 80

Some examples of discernment — 80

Eye-door process — Resultant mentality-materiality — 81

Formations and kamma-becoming are kamma — 81

1. Accumulating formations (āyūhanasaṅkhāra) — 82

How conascent mentality-materiality arises due to conascent consciousness — 83

With mentality-materiality as condition, the six sense bases — 87


<a id="M06-front-P005"></a>
## Table of contents — ဂ
Đầu sách / Front matter - 5

(a) How mentality conditions the mind base — 88

(b) How material bases arise due to the arising of mentality — 90

The supporting characteristic (upatthambhakasabhāva) — 92

(c) How material bases arise due to the arising of materiality — 97

(d) How the mind base arises due to the arising of materiality — 98

Some examples of discernment — 99

(e) How the mind base arises due to the arising of mentality-materiality — 102

Some examples of discernment — 103

Examples for practising this method of discernment — 104

With the six sense bases as condition, contact — 105

Some examples of discernment — Rebirth-linking mind-contact — 107

The associated mental-object base — 108

Mind-contact in five-door adverting (visible-object series) — 108, 109

Eye-contact is the contact associated with eye-consciousness — 109

Mind-contact in receiving (visible-object series) — 110

Mind-contact in investigating (visible-object series) — 110

Mind-contact in determining (visible-object series) — 110

Mind-contact in the first impulsion (visible-object series, wholesome impulsion) — 110

Mind-contact in the first registering consciousness (visible-object series) — 111

Mind-contact in mind-door adverting (visible object) — 111

With contact as condition, feeling — 113

Feeling born of eye-contact and feeling conditioned by eye-contact — 113

What is mind-contact? — 117

With feeling as condition, craving — 118

A statement concerning the future (anāgatavacīkatā) — 121


<a id="M06-front-P006"></a>
## Table of contents — ဃ
Đầu sách / Front matter - 6

Some examples of discernment — 121

Craving for mental objects — 122

In the continuity of the Arahants — 122

With craving as condition, clinging — 123

Clinging to sensual pleasures — 124

Clinging to views — 124

Clinging to rules and observances — 124

Clinging to a doctrine of self — 124

A way of discerning separately — An example — 126

Example cognitive processes for craving and clinging — 127

A point to note — 128

With clinging as condition, becoming — 128

One point to note — 129

A concise pattern of discernment for memorization — 131

Some examples of discernment — 132

The sequence of impulsion consciousness in the mind-door process — 132

With becoming as condition, birth — 133

A brief example of discernment — 134

A point for inquiry — 134

With birth as condition, aging and death — An example of discernment — 136

Sorrow, lamentation, pain, grief, and despair — 137

A brief example of discernment — 137

The sequence of cognitive processes for sorrow, lamentation, grief, and despair — 141

Four ways of teaching dependent origination — 142

From beginning to end — Dependent origination in forward order (1) — 142


<a id="M06-front-P007"></a>
## Table of contents — င
Đầu sách / Front matter - 7

From the middle to the end — Dependent origination in forward order (2) — 143

From end to beginning — Dependent origination in reverse order (1) — 144

From the middle to the beginning — Dependent origination in reverse order (2) — 145

Dependent origination in forward order — The second method (2) — 147

From end to beginning — Dependent origination in reverse order (1) — 151

Some examples of discernment — 152

From the middle to the beginning — Dependent origination in reverse order, the second method (2) — 153

The four kinds of nutriment — 153

Nutriment not born of kamma is non-kammically acquired nutriment (anupādiṇṇaka āhāra) — 155

Edible food (kabaḷīkāra āhāra) — 156

The powers of the four kinds of nutriment — 158

Edible food — 158

Contact as nutriment — 158

Mental volition as nutriment — 159

Consciousness as nutriment — 159

A summary point for discernment — 162

How to discern beginning with the four nutriments of the round of results — 163

How to discern beginning with the four nutriments of the round of kamma — 164

One way of explaining the meaning — 165

Why the Buddha taught in four ways — 166

Dependent origination in forward order — The first method (1) — 168

Dependent origination in forward order — The second method (2) — 169

Dependent origination in reverse order — The first method (1) — 169

Great diamond insight knowledge (Mahāvajiravipassanāñāṇa) — 170


<a id="M06-front-P008"></a>
## Table of contents — စ
Đầu sách / Front matter - 8

Dependent origination in reverse order — The second method (2) — 171

Concluding exhortation — 171


<a id="M06-body-P001"></a>
## Part 1 · Analysis of dependent origination according to the Discourses
Miến / Burmese 1

Namo tassa bhagavato arahato sammāsambuddhassa.

Dependent Origination (Paṭiccasamuppāda) — B. Part 1. Pāli Analysis of Dependent Origination — Analysis according to the Discourses (Suttantabhājanīya).

Avijjāpaccayā saṅkhārā, saṅkhārapaccayā viññāṇaṃ, viññāṇapaccayā nāmarūpaṃ, nāmarūpapaccayā saḷāyatanaṃ, saḷāyatanapaccayā phasso, phassapaccayā vedanā, vedanāpaccayā taṇhā, taṇhāpaccayā upādānaṃ, upādānapaccayā bhavo, bhavapaccayā jāti, jātipaccayā jarāmaraṇaṃ sokaparidevadukkhadomanassupāyāsā sambhavanti. Evametassa kevalassa dukkhakkhandhassa samudayo hoti.

With ignorance as condition, formations arise. With formations as condition, consciousness arises. With consciousness as condition, mentality-materiality arises. With mentality-materiality as condition, the six sense bases arise. With the six sense bases as condition, contact arises. With contact as condition, feeling arises. With feeling as condition, craving arises. With craving as condition, clinging arises. With clinging as condition, becoming arises. With becoming as condition, birth arises. With birth as condition, aging and death, sorrow, lamentation, pain, grief, and despair arise. Thus this whole mass of suffering originates.

Here, what is ignorance (avijjā)? Not knowing suffering, not knowing the origin of suffering, not knowing the cessation of suffering, and not knowing the way leading to the cessation of suffering. This is called ignorance.

Here, what are the formations conditioned by ignorance? Meritorious formation (puññābhisaṅkhāra), demeritorious formation (apuññābhisaṅkhāra), imperturbable formation (āneñjābhisaṅkhāra), bodily formation (kāyasaṅkhāra), verbal formation (vacīsaṅkhāra), and mental formation (cittasaṅkhāra).

Here, what is meritorious formation? Wholesome volition of the sense sphere and the fine-material sphere, consisting in giving, virtue, or development. This is called meritorious formation.


<a id="M06-body-P002"></a>
## Formations, consciousness, mentality-materiality, the six bases, contact, and feeling
Miến / Burmese 2

Here, what is demeritorious formation? Unwholesome volition of the sense sphere. This is called demeritorious formation.

Here, what is imperturbable formation? Wholesome volition of the immaterial sphere. This is called imperturbable formation.

Here, what is bodily formation? Bodily volition is bodily formation. Verbal volition is verbal formation. Mental volition is mental formation. These are called formations conditioned by ignorance.

Here, what is consciousness conditioned by formations? Eye-consciousness, ear-consciousness, nose-consciousness, tongue-consciousness, body-consciousness, and mind-consciousness. This is called consciousness conditioned by formations.

Here, what is mentality-materiality conditioned by consciousness? There is mentality and there is materiality. What is mentality? The feeling aggregate, perception aggregate, and formations aggregate. This is called mentality. What is materiality? The four great elements and materiality derived from them. This is called materiality. Thus there is this mentality and this materiality. This is called mentality-materiality conditioned by consciousness.

Here, what are the six sense bases conditioned by mentality-materiality? The eye base, ear base, nose base, tongue base, body base, and mind base. These are called the six sense bases conditioned by mentality-materiality.

Here, what is contact conditioned by the six sense bases? Eye-contact, ear-contact, nose-contact, tongue-contact, body-contact, and mind-contact. This is called contact conditioned by the six sense bases.

Here, what is feeling conditioned by contact? Feeling born of eye-contact, feeling born of ear-contact, feeling born of nose-contact, feeling born of tongue-contact, feeling born of body-contact, and feeling born of mind-contact. This is called feeling conditioned by contact.


<a id="M06-body-P003"></a>
## Craving, clinging, becoming, birth, and aging and death
Miến / Burmese 3

Here, what is craving conditioned by feeling? Craving for visible objects, sounds, odours, tastes, tangibles, and mental objects. This is called craving conditioned by feeling.

Here, what is clinging conditioned by craving? Clinging to sensual pleasures, clinging to views, clinging to rules and observances, and clinging to a doctrine of self. This is called clinging conditioned by craving.

Here, what is becoming conditioned by clinging? Becoming is twofold: kamma-becoming (kammabhava) and rebirth-becoming (upapattibhava). Here, what is kamma-becoming? Meritorious, demeritorious, and imperturbable formation. This is called kamma-becoming. All kamma leading to becoming is kamma-becoming.

Here, what is rebirth-becoming? Sense-sphere becoming, fine-material becoming, immaterial becoming, percipient becoming, non-percipient becoming, neither-percipient-nor-non-percipient becoming, one-aggregate becoming, four-aggregate becoming, and five-aggregate becoming. This is called rebirth-becoming. This is called becoming conditioned by clinging.

Here, what is birth conditioned by becoming? The birth, being born, descent, generation, manifestation of the aggregates, and acquisition of the bases of the various beings in their respective orders of beings. This is called birth conditioned by becoming.

Here, what are aging and death conditioned by birth? There is aging and there is death. Here, what is aging? The aging, agedness, broken teeth, grey hair, wrinkled skin, decline of the life span, and ripening of the faculties of the various beings in their respective orders of beings. This is called aging.

Here, what is death? The passing away, departure, breakup, disappearance, dying, death, and completion of the allotted time…


<a id="M06-body-P004"></a>
## Death, sorrow, lamentation, pain, grief, and despair
Miến / Burmese 4

… the breakup of the aggregates, the laying down of the body, and the cutting off of the life faculty of the various beings departing from their respective orders of beings. This is called death. Thus there is this aging and this death. These are called aging and death conditioned by birth.

Here, what is sorrow (soka)? When someone meets with loss of relatives, wealth, health, virtue, or view, or is affected by some loss or pain, there is their sorrow, sorrowing, state of sorrow, inner sorrow, inner anguish, burning of the mind, dejection, and dart of sorrow. This is called sorrow.

Here, what is lamentation (parideva)? When someone meets with loss of relatives, wealth, health, virtue, or view, or is affected by some loss or pain, there is their wailing, lamenting, crying out, weeping, state of wailing, state of lamenting, outcry, loud outcry, confused outcry, babbling, state of babbling, and babbled utterance. This is called lamentation.

Here, what is pain (dukkha)? Bodily discomfort, bodily pain, the unpleasant and painful experience born of body-contact, and the painful, unpleasant feeling born of body-contact. This is called pain.

Here, what is grief (domanassa)? Mental discomfort, mental pain, the unpleasant and painful experience born of mind-contact, and the painful, unpleasant feeling born of mind-contact. This is called grief.

Here, what is despair (upāyāsa)? When someone meets with loss of relatives, wealth, health, virtue, or view, or is affected by some loss…


<a id="M06-body-P005"></a>
## End of the Pāli passage and explanation for memorization
Miến / Burmese 5

… or pain, there is their distress, despair, state of distress, and state of despair. This is called despair.

“Thus this whole mass of suffering originates.” Thus this whole mass of suffering comes together, gathers, converges, and becomes manifest. Hence it is said: “Thus this whole mass of suffering originates.”

Source cited in the original: Abhidhamma, vol. 2, pp. 142–145. End of the analysis according to the Discourses (Suttantabhājanīya).

Meaning of the Pāli passage for memorization.

1. Avijjāpaccayā: because ignorance, the causal dhamma, is present, that is, not knowing and knowing wrongly about the Four Noble Truths. Saṅkhārā: formations that fashion and nurture the present life and future lives in saṃsāra. Sambhavanti: become manifest, arise.

2. Saṅkhārapaccayā: because formations that fashion and nurture the present life and future lives in saṃsāra are present as the causal dhamma. Viññāṇaṃ: kamma-consciousness (kammaviññāṇa), or resultant consciousness (vipākaviññāṇa). Sambhavati: becomes manifest, arises.

3. (a) Viññāṇapaccayā: because kamma-consciousness is present as the causal dhamma. Nāmarūpaṃ: resultant mental phenomena and material phenomena born of kamma. Sambhavati: becomes manifest, arises.

(b) Alternatively, viññāṇapaccayā: because resultant consciousness is present as the causal dhamma. Nāmarūpaṃ: the resultant mental factors…


<a id="M06-body-P006"></a>
## Explanation of the factors of dependent origination for memorization
Miến / Burmese 6

… and materiality born of resultant consciousness. Sambhavati: becomes manifest, arises.

4. Nāmarūpapaccayā: because that mentality-materiality is present as the causal dhamma. Saḷāyatanaṃ: the six internal sense bases. Sambhavati: becomes manifest, arises.

5. Saḷāyatanapaccayā: because those six internal sense bases are present as the causal dhamma. Phasso: the six kinds of contact. Sambhavati: becomes manifest, arises.

6. Phassapaccayā: because those six kinds of contact are present as the causal dhamma. Vedanā: the six kinds of feeling. Sambhavati: becomes manifest, arises.

7. Vedanāpaccayā: because those six kinds of feeling are present as the causal dhamma. Taṇhā: the six kinds of craving. Sambhavati: becomes manifest, arises.

8. Taṇhāpaccayā: because those six kinds of craving are present as the causal dhamma. Upādānaṃ: the four kinds of clinging. Sambhavati: becomes manifest, arises.

9. Upādānapaccayā: because those four kinds of clinging are present as the causal dhamma. Bhavo: kamma-becoming and rebirth-becoming. Sambhavati: becomes manifest, arises.

10. Bhavapaccayā: because that kamma-becoming is present as the causal dhamma. Jāti: the establishment of rebirth-linking, that is, the phenomenon of birth. Sambhavati: becomes manifest, arises.

11. Jātipaccayā: because birth, the establishment of rebirth-linking, is present as the causal dhamma. Jarāmaraṇaṃ: aging (jarā) and death…


<a id="M06-body-P007"></a>
## Ignorance and formations
Miến / Burmese 7

… (maraṇa). Sokaparidevadukkhadomanassupāyāsā means the phenomena of sorrow (soka), lamentation (parideva), bodily pain (dukkha), mental distress (domanassa), and intense anguish (upāyāsa). Sambhavanti means they become manifest and arise.

Evaṃ means thus. Kevalassa means wholly, unmixed with happiness. Etassa dukkhakkhandhassa means of this mass, this aggregate of suffering. Samudayo means the cause of arising, or, alternatively, the arising itself. Hoti means it appears, comes to be.

Tattha means in the Pāli passage “Avijjāpaccayā saṅkhārā.” Avijjā means ignorance. Katamā means what is it?

1. Dukkhe means with regard to the noble truth of suffering. Aññāṇaṃ means not knowing.

2. Dukkhasamudaye means with regard to the noble truth of the origin, the cause of suffering. Aññāṇaṃ means not knowing.

3. Dukkhanirodhe means with regard to the noble truth of cessation, the ending of suffering. Aññāṇaṃ means not knowing.

4. Dukkhanirodhagāminiyā paṭipadāya means with regard to the noble truth of the path, the pure and noble practice leading to Nibbāna, the ending of suffering. Aññāṇaṃ means not knowing.

Ayaṃ means this lack of knowledge. Avijjā means ignorance. Vuccati means is called.

Tattha means in that Pāli passage. Avijjāpaccayā saṅkhārā means the formations that arise due to ignorance as their cause. Katame means which formations? They are:

1. Puññābhisaṅkhāro is meritorious formation.


<a id="M06-body-P008"></a>
## Meritorious, demeritorious, and imperturbable formations
Miến / Burmese 8

2. Apuññābhisaṅkhāro is demeritorious formation.

3. Āneñjābhisaṅkhāro is imperturbable formation.

4. Kāyasaṅkhāro is bodily formation.

5. Vacīsaṅkhāro is verbal formation.

6. Cittasaṅkhāro is mental formation.

1. Tattha means among those formations. Puññābhisaṅkhāro means meritorious formation. Katamo means what is it? Dānamayā means accomplished through giving. Sīlamayā means accomplished through virtue. Bhāvanāmayā means accomplished through development, including preliminary development (parikammabhāvanā), access development (upacārabhāvanā), and insight development (vipassanābhāvanā). Kāmāvacarā means belonging to the sense sphere. Yā kusalā cetanā means such great wholesome volition. (Here the text refers specifically to insight development capable of producing becoming. The full range of insight kamma is wider.) Bhāvanāmayā means accomplished through serenity development (samathabhāvanā), or, alternatively, through absorption development (appanābhāvanā). Rūpāvacarā means belonging to the fine-material sphere. Yā kusalā cetanā means such fine-material wholesome volition. Atthi means there is. Ayaṃ means these sense-sphere and fine-material-sphere wholesome volitions. Puññābhisaṅkhāro vuccati means they are called meritorious formation. «Eight great wholesome consciousnesses and five fine-material wholesome consciousnesses, thirteen in all.»

2. Tattha means among those formations. Apuññābhisaṅkhāro means demeritorious formation. Katamo means what is it? Kāmāvacarā means belonging to the sense sphere. Yā akusalā cetanā means such unwholesome volition. Atthi means there is. Ayaṃ means this unwholesome volition. Apuññābhisaṅkhāro vuccati means it is called demeritorious formation.

3. Tattha means among those formations. Āneñjābhisaṅkhāro means imperturbable formation. Katamo means what is it? Arūpāvacarā means belonging to the immaterial sphere…


<a id="M06-body-P009"></a>
## Bodily, verbal, and mental formations, and the kinds of consciousness
Miến / Burmese 9

… Yā kusalā cetanā means such immaterial wholesome volition. Atthi means there is. Ayaṃ means this immaterial wholesome volition. Āneñjābhisaṅkhāro vuccati means it is called imperturbable formation.

4. Tattha means among those formations. Kāyasaṅkhāro means bodily formation. Katamo means what is it? Kāyasañcetanā means the eight wholesome sense-sphere volitions and twelve unwholesome volitions that arise at the body door. Kāyasaṅkhāro is the name for bodily formation. (8 + 12 = 20.)

5. Vacīsañcetanā means the eight wholesome sense-sphere volitions and twelve unwholesome volitions that arise at the speech door. Vacīsaṅkhāro is the name for verbal formation. (20.)

6. Manosañcetanā means the volitions that arise without producing either kind of material intimation, namely bodily intimation and verbal intimation. They are twelve unwholesome volitions, eight wholesome sense-sphere volitions, five fine-material wholesome volitions, and four immaterial wholesome volitions. Their total is one short of thirty. Cittasaṅkhāro is the name for mental formation. (29.)

Ime means these formations. Avijjāpaccayā saṅkhārā vuccanti means they are called the formations that arise due to ignorance as their cause.

Tattha means in that Pāli passage. Saṅkhārapaccayā viññāṇaṃ means consciousness that arises due to formations as its cause. Katamaṃ means what is it?

1. Cakkhuviññāṇaṃ means eye-consciousness.

2. Sotaviññāṇaṃ means ear-consciousness.

3. Ghānaviññāṇaṃ means nose-consciousness.

4. Jivhāviññāṇaṃ means tongue-consciousness.


<a id="M06-body-P010"></a>
## Consciousness as condition for mentality-materiality
Miến / Burmese 10

5. Kāyaviññāṇaṃ means body-consciousness.

6. Manoviññāṇaṃ means mind-consciousness.

Idaṃ means these six kinds of consciousness. Saṅkhārapaccayā viññāṇaṃ vuccati means they are called consciousness that arises due to formations as its cause.

Tattha means in that Pāli passage. Viññāṇapaccayā nāmarūpaṃ means mentality-materiality that arises due to consciousness as its cause. Katamaṃ means what is it?

1. Nāmaṃ means mentality. Atthi means there is.

2. Rūpaṃ means materiality. Atthi means there is.

Tattha means in that mentality-materiality. Nāmaṃ means mentality. Katamaṃ means what is it?

1. Vedanākkhandho means the feeling aggregate.

2. Saññākkhandho means the perception aggregate.

3. Saṅkhārakkhandho means the formations aggregate.

Idaṃ means these three aggregates. Nāmaṃ vuccati means they are called mentality.

Tattha means in that mentality-materiality. Rūpaṃ means materiality. Katamaṃ means what is it?

1. Cattāro mahābhūtā means all four great elements.

2. Catunnaṃ mahābhūtānaṃ refers to the four great elements. Upādāya rūpaṃ means the twenty-four kinds of materiality derived from them.

Idaṃ means these great elements and derived materiality. Rūpaṃ vuccati means they are called materiality.

Iti means thus. Idañca nāmaṃ means this mentality. Idañca rūpaṃ means this materiality. Idaṃ means this mentality-materiality. «Alternatively, idañca nāmaṃ means this mentality, idañca rūpaṃ means this materiality…


<a id="M06-body-P011"></a>
## Mentality-materiality as condition for the six bases, and the six bases as condition for contact
Miến / Burmese 11

… Atthi means there is. Idaṃ means this mentality-materiality.» Viññāṇapaccayā nāmarūpaṃ vuccati means it is called mentality-materiality that arises due to consciousness as its cause.

Tattha means in that Pāli passage. Nāmarūpapaccayā saḷāyatanaṃ means the six bases that arise due to mentality-materiality as their cause. Katamaṃ means what are they?

1. Cakkhāyatanaṃ means the eye base.

2. Sotāyatanaṃ means the ear base.

3. Ghānāyatanaṃ means the nose base.

4. Jivhāyatanaṃ means the tongue base.

5. Kāyāyatanaṃ means the body base.

6. Manāyatanaṃ means the mind base.

Idaṃ means these six bases. Nāmarūpapaccayā saḷāyatanaṃ vuccati means they are called the six bases that arise due to mentality-materiality as their cause.

Tattha means in that Pāli passage. Saḷāyatanapaccayā phasso means contact that arises due to the six bases as its cause. Katamo means what is it?

1. Cakkhusamphasso means eye-contact.

2. Sotasamphasso means ear-contact.

3. Ghānasamphasso means nose-contact.

4. Jivhāsamphasso means tongue-contact.

5. Kāyasamphasso means body-contact.

6. Manosamphasso means mind-contact.

Ayaṃ means these six kinds of contact. Saḷāyatanapaccayā phasso vuccati means they are called contact that arises due to the six bases as its cause…


<a id="M06-body-P012"></a>
## Contact as condition for feeling, and feeling as condition for craving
Miến / Burmese 12

… as the Pāli passage puts it.

Tattha means in that Pāli passage. Phassapaccayā vedanā means feeling that arises due to contact as its cause. Katamā means what is it?

1. Cakkhusamphassajā vedanā means feeling born of eye-contact.

2. Sotasamphassajā vedanā means feeling born of ear-contact.

3. Ghānasamphassajā vedanā means feeling born of nose-contact.

4. Jivhāsamphassajā vedanā means feeling born of tongue-contact.

5. Kāyasamphassajā vedanā means feeling born of body-contact.

6. Manosamphassajā vedanā means feeling born of mind-contact.

Ayaṃ means these six kinds of feeling. Phassapaccayā vedanā vuccati means they are called feeling that arises due to contact as its cause.

Tattha means in that Pāli passage. Vedanāpaccayā taṇhā means craving that arises due to feeling as its cause. Katamā means what is it?

1. Rūpataṇhā means craving that clings to and longs for visible objects.

2. Saddataṇhā means craving that clings to and longs for sounds.

3. Gandhataṇhā means craving that clings to and longs for odours.


<a id="M06-body-P013"></a>
## Craving as condition for clinging, and clinging as condition for becoming
Miến / Burmese 13

4. Rasataṇhā means craving that clings to and longs for tastes.

5. Phoṭṭhabbataṇhā means craving that clings to and longs for tangibles.

6. Dhammataṇhā means craving that clings to and longs for mental objects.

Ayaṃ means these six kinds of craving. Vedanāpaccayā taṇhā vuccati means they are called craving that arises due to feeling as its cause.

Tattha means in that Pāli passage. Taṇhāpaccayā upādānaṃ means clinging that arises due to craving as its cause. Katamaṃ means what is it?

1. Kāmupādānaṃ means clinging to sensual pleasures, holding fast to the strands of sensual pleasure.

2. Diṭṭhupādānaṃ means clinging to views, holding fast to erroneous opinions, that is, wrong view.

3. Sīlabbatupādānaṃ means clinging to rules and observances, holding fast to mistaken practices such as the ox observance and the dog observance.

4. Attavādupādānaṃ means clinging to a doctrine of self, holding fast to a view that posits a self.

Idaṃ means these four kinds of clinging. Taṇhāpaccayā upādānaṃ vuccati means they are called clinging that arises due to craving as its cause.

Tattha means in that Pāli passage. Upādānapaccayā bhavo means becoming that arises due to clinging as its cause. Katamo means what is it? Bhavo means becoming. Duvidhena means in two kinds. Atthi means there is.

1. Kammabhavo means kamma-becoming, becoming as the cause of arising. Atthi means there is.


<a id="M06-body-P014"></a>
## Kamma-becoming and rebirth-becoming
Miến / Burmese 14

2. Upapattibhavo means rebirth-becoming, becoming that has arisen. Atthi means there is.

Tattha means among those two kinds. Kammabhavo means kamma-becoming, becoming as the cause of arising. Katamo means what is it?

1. Puññābhisaṅkhāro is meritorious formation.

2. Apuññābhisaṅkhāro is demeritorious formation.

3. Āneñjābhisaṅkhāro is imperturbable formation.

Ayaṃ means these three kinds of formations. Kammabhavo vuccati means they are called kamma-becoming, becoming as the cause of arising. Sabbampi means all without exception. Bhavagāmikammaṃ is all kamma that leads to becoming. Kammabhavo is the name for kamma-becoming, becoming as the cause of arising.

Tattha means among those two kinds of becoming. Upapattibhavo means rebirth-becoming, becoming that has arisen. Katamo means what is it?

1. Kāmabhavo is sense-sphere becoming, comprising the eleven sense-sphere planes.

2. Rūpabhavo is fine-material becoming, comprising the sixteen fine-material planes.

3. Arūpabhavo is immaterial becoming, comprising the four immaterial planes.

4. Saññābhavo is percipient becoming. «Eleven sense-sphere planes, fifteen fine-material planes after excluding the non-percipient plane, and three immaterial planes after excluding the base of neither perception nor non-perception, making twenty-nine planes in all. It means becoming in which perception is present.»

5. Asaññābhavo is non-percipient becoming, the becoming of non-percipient beings.

6. Nevasaññānāsaññābhavo is becoming in which gross perception is absent and only very subtle, gentle perception is present. It is therefore described as neither percipient nor non-percipient…


<a id="M06-body-P015"></a>
## Nine kinds of rebirth-becoming and the meaning of birth
Miến / Burmese 15

… that is becoming with neither perception nor non-perception.

7. Ekavokārabhavo is one-aggregate becoming, in which there is only the materiality aggregate, in the non-percipient plane.

8. Catuvokārabhavo is four-aggregate becoming, in which there are only the four mental aggregates, in the four immaterial planes.

9. Pañcavokārabhavo is five-aggregate becoming. «Eleven sense-sphere planes and fifteen fine-material planes after excluding the non-percipient plane, twenty-six planes in all.»

Ayaṃ means these nine kinds of becoming. Upapattibhavo vuccati means they are called rebirth-becoming. Ayaṃ means this kamma-becoming and rebirth-becoming. Upādānapaccayā bhavo vuccati means they are called becoming that arises due to clinging as its cause.

Tattha means in that Pāli passage. Bhavapaccayā jāti means birth that arises due to becoming (kamma-becoming) as its cause. Katamā means what is it?

Tesaṃ tesaṃ sattānaṃ means of the various beings. Tamhi tamhi sattanikāye means in their respective orders of beings. Yā jāti is birth. Yā sañjāti is being born. Yā okkanti is descent into the mother's womb. Yā abhinibbatti is the appearance of a new being. Yo khandhānaṃ pātubhāvo is the clear manifestation of the aggregates. Yo āyatanānaṃ paṭilābho is the acquisition of the bases. Atthi means there is. Ayaṃ means this. Bhavapaccayā jāti vuccati means it is called birth that arises due to becoming as its cause.

Tattha means in that Pāli passage. Jātipaccayā jarāmaraṇaṃ means aging and death that arise due to…


<a id="M06-body-P016"></a>
## Explanation of aging and death
Miến / Burmese 16

… birth as their cause. Katamaṃ means what are they? Jarā means aging, the phenomenon of aging. Atthi means there is. Maraṇaṃ means death, the phenomenon of death. Atthi means there is. Tattha means among those two, aging and death. Jarā means aging. Katamā means what is it?

Tesaṃ tesaṃ sattānaṃ means of the various beings. Tamhi tamhi sattanikāye means in their respective orders of beings. Yā jarā is aging. Yā jīraṇatā is the state of growing old. Yaṃ khaṇḍiccaṃ is the state of having broken teeth. Yaṃ pāliccaṃ is the state of having grey hair. Yā valittacatā is the state of having wrinkled skin. Āyuno means of the life span. Yā saṃhāni is decline. Indriyānaṃ means of the faculties. Yo paripāko is ripening. Atthi means there is. Ayaṃ means this phenomenon. Jarā vuccati means it is called aging.

Tattha means among aging and death. Maraṇaṃ means death. Katamaṃ means what is it? Tesaṃ tesaṃ sattānaṃ means of the various beings. Tamhā tamhā sattanikāyā means from their respective orders of beings. Yā cuti is decease, or departure. Yā cavanatā is the state of passing away. Yo bhedo is breakup. Yaṃ antaradhānaṃ is disappearance. Yā maccu is death. Yaṃ maraṇaṃ is dying. Yā kālakiriyā is the ending of one's time. Yo khandhānaṃ bhedo is the breakup of the aggregates. Yo kaḷevarassa nikkhepo is the laying down of the body. Yo jīvitindriyassupacchedo is the cutting off of the life faculty. Atthi means there is. Idaṃ means this phenomenon…


<a id="M06-body-P017"></a>
## Aging and death conditioned by birth, and the meaning of sorrow
Miến / Burmese 17

… Maraṇaṃ vuccati means it is called death.

Ayañca jarā means this aging. Atthi means there is. Idañca maraṇaṃ means this death. Atthi means there is. Idaṃ means these two phenomena, aging and death. Jātipaccayā jarāmaraṇaṃ vuccati means they are called aging and death that arise due to birth as their cause.

Tattha means in that Pāli passage. Soko means sorrow. Katamo means what is it? Ñātibyasanena vā means through loss of relatives. Phuṭṭhassa means for the person affected by that loss. Bhogabyasanena vā means through loss of wealth. Phuṭṭhassa means for the person affected by that loss. Rogabyasanena vā means through the calamity of illness. Phuṭṭhassa means for the person affected by that calamity. Sīlabyasanena vā means through deterioration in virtue. Phuṭṭhassa means for the person affected by that deterioration. Diṭṭhibyasanena vā means through deterioration in view. Phuṭṭhassa means for the person affected by that deterioration. Aññataraññatarena means some particular one, any one of them. Byasanena means through a loss or calamity. Samannāgatassa means for the person undergoing it. Aññataraññatarena means some particular one, any one of them. Dukkhadhammena means through a painful phenomenon. Phuṭṭhassa means for the person affected by it.

Yo soko is sorrow. Yā socanā is sorrowing. Yaṃ socitattaṃ is the state of sorrowing. Yo antosoko is inner sorrow. Yo antoparisoko is oppressive inner sorrow. Yā cetaso parijjhāyanā is the tormenting burning of the mind. Yaṃ domanassaṃ is mental distress. Yaṃ sokasallaṃ is the deeply lodged dart called sorrow. Atthi means there is. Ayaṃ means this phenomenon…


<a id="M06-body-P018"></a>
## Explanation of lamentation and bodily pain
Miến / Burmese 18

… Soko vuccati means it is called sorrow.

Tattha means in that Pāli passage. Paridevo means lamentation. Katamo means what is it? Ñātibyasanena vā means through loss of relatives. Phuṭṭhassa means for the person affected by that loss. pe. Aññataraññatarena means any one of them. Dukkhadhammena means through a painful phenomenon. Phuṭṭhassa means for the person affected by it.

Yo ādevo is crying out. Yo paridevo is crying out again and again. Yā ādevanā is weeping aloud. Yā paridevanā is weeping aloud again and again. Yaṃ ādevitattaṃ is the state of crying out. Yaṃ paridevitattaṃ is the state of crying out again and again. Yā vācā is crying out in words, such as “my son, my daughter.” Yo palāpo is crying out repeatedly in words. Yo vippalāpo is crying out repeatedly in many different words. Yo lālappo is lamenting aloud again and again. Yā lālappanā is the act of lamenting aloud again and again. Yaṃ lālappitattaṃ is the state of lamenting aloud again and again. Atthi means there is. Ayaṃ means this phenomenon. Paridevo vuccati means it is called lamentation.

Tattha means in that Pāli passage. Dukkhaṃ means bodily pain. Katamaṃ means what is it? Kāyikaṃ means arising in the body. Asātaṃ means devoid of pleasantness. Yaṃ kāyikaṃ dukkhaṃ is bodily pain. Kāyasamphassajaṃ means born of body-contact. Asātaṃ means devoid of pleasantness. Yaṃ dukkhaṃ vedayitaṃ is the state of experiencing pain. Kāyasamphassajā means born of body-contact. Asātā means devoid of…


<a id="M06-body-P019"></a>
## Explanation of mental distress and anguish
Miến / Burmese 19

… pleasantness. Yā dukkhā vedanā means painful feeling. Atthi means there is. Idaṃ means this bodily painful feeling. Dukkhaṃ vuccati means it is called pain.

Tattha means in that Pāli passage. Domanassaṃ means mental distress. Katamaṃ means what is it? Cetasikaṃ means arising in the mind. Asātaṃ means devoid of pleasantness. Yaṃ cetasikaṃ dukkhaṃ is mental pain. Cetosamphassajaṃ means born of mental contact, that is, mind-contact. Asātaṃ means devoid of pleasantness. Yaṃ dukkhaṃ vedayitaṃ is the state of experiencing pain. Cetosamphassajā means born of mental contact, that is, mind-contact. Asātā means devoid of pleasantness. Yā dukkhā vedanā is painful feeling. Atthi means there is. Idaṃ means this mentally painful feeling, that is, the feeling of mental distress. Domanassaṃ vuccati means it is called mental distress.

Tattha means in that Pāli passage. Upāyāso means intense anguish. Katamo means what is it? Ñātibyasanena vā means through loss of relatives. Phuṭṭhassa means for the person affected by that loss. pe. Aññataraññatarena means any one of them. Dukkhadhammena means through a painful phenomenon. Phuṭṭhassa means for the person affected by it. Yo āyāso is mental distress. Yo upāyāso is intense mental distress. Yaṃ āyāsitattaṃ is the state of mental distress. Yaṃ upāyāsitattaṃ is the state of intense mental distress. Atthi means there is. Ayaṃ means this phenomenon. Upāyāso vuccati means it is called anguish.

Evametassa kevalassa dukkhakkhandhassa samudayo hotīti padassa means with regard to the expression “Evametassa kevalassa dukkhakkhandhassa samudayo hoti.” Attho means its intended sense. Evaṃ means thus…


<a id="M06-body-P020"></a>
## Conclusion of the explanation according to the Discourses
Miến / Burmese 20

… Veditabbo means it should be understood.

Iti means thus. Kevalassa means wholly, unmixed with happiness. Etassa dukkhakkhandhassa means of this mass, this aggregate of suffering. Samudayo is arising. Hoti means occurs. Iti means thus. Kevalassa means wholly, unmixed with happiness. Etassa dukkhakkhandhassa means of this mass, this aggregate of suffering. Saṅgati is coming together. Samāgamo is arriving together at one place. Samodhānaṃ is convergence. Pātubhāvo is clear manifestation. Hoti means occurs. Tena means therefore. Evametassa kevalassa dukkhakkhandhassa samudayo hotīti means it is therefore said: “Thus this whole mass of suffering originates.”

Suttantabhājanīyaṃ means the method of analysis according to the Discourses. Niṭṭhitaṃ means concluded.

Source cited in the original: Abhidhamma, vol. 2, pp. 142–145.

The foregoing is the Pāli Analysis of Dependent Origination together with its Burmese explanation. Good people who wish to practise the teaching on dependent origination systematically, to cultivate it diligently, and to know it clearly through understanding and penetration (anubodha, paṭivedha), through knowledge of understanding and knowledge of penetration (anubodhañāṇa, paṭivedhañāṇa), should memorize this beforehand, before beginning practice. Good people who have memorized this Pāli passage together with its meaning, please practise the first method of discerning dependent origination.


<a id="M06-body-P021"></a>
## What is the teaching of dependent origination?
Miến / Burmese 21

Even the Blessed One himself did not establish or create this teaching of dependent origination. Whether a Buddha appears or does not appear, this principle of dependent origination remains in effect. (Saṃyutta, vol. 1, p. 264, Paccayasutta.) Only when Buddhas appear do beings gain the opportunity to know this teaching through their disclosure and exposition. If a Buddha does not appear in the world, if a Buddha appears but people do not hear the teaching of dependent origination, or if, though they hear the teaching, they still hold fast to harmful wrong views such as eternalism and annihilationism, they cannot know and understand this principle of dependent origination.

This teaching of dependent origination is deep and appears deep, difficult to understand and appears difficult to understand. When Venerable Ānanda came and said that it was “easy to understand and shallow,” the Buddha restrained him: “Mā hevaṃ, Ānanda, avaca — Ānanda, do not say so.” However difficult to understand and profound dependent origination may be, until one knows it distinctly by knowledge of understanding and knowledge of penetration (anubodhañāṇa, paṭivedhañāṇa), one cannot pass beyond the suffering of the round of rebirths. (Dīgha, vol. 2, p. 47. Saṃyutta, vol. 1, p. 318.)

One who does not yet know this principle of dependent origination does not deserve to be called an ascetic or a brahmin. (Saṃyutta, vol. 1, p. 279.)

The Buddhas who have appeared, are appearing, and will appear, through distinctly knowing this teaching of dependent origination…


<a id="M06-body-P022"></a>
## Dependent origination and the Middle Way
Miến / Burmese 22

… attain Buddhahood. (Saṃyutta, vol. 1, pp. 246–252.)

For as long as beings do not distinctly know this teaching of dependent origination, they keep falling into one of the two abysses of eternalism and annihilationism and continue to undergo all kinds of suffering. Thus the Buddha repeatedly taught in the Nidānasaṃyutta that those who wish to escape the suffering of the round must strive to penetrate this teaching of dependent origination.

The Middle Way (Majjhimā paṭipadā)

1. Jarāmaraṇādīnaṃ dhammānaṃ paccayalakkhaṇo paṭiccasamuppādo.
2. Dukkhānubandhanaraso.
3. Kummaggapaccupaṭṭhāno. (Visuddhimagga, vol. 2, p. 149.)

Dependent origination is explained as follows:

1. Its characteristic is that of a condition, the capacity to support the arising of conditioned phenomena such as aging and death.

2. Its function is to keep suffering in the course of existence (pavattidukkha) going, with causes and effects linked and arising without interruption.

3. It appears to the meditator’s knowledge as the unbroken course of saṃsāra. Alternatively, it appears as a wrong road or a wrong turn that leads the meditator away from the Middle Way leading to Nibbāna.


<a id="M06-body-P023"></a>
## What is the Middle Way leading to Nibbāna?
Miến / Burmese 23

Tesaṃ tesaṃ paccayuppannadhammānaṃ sambhavato uppajjanato sassatocchedasaṅkhātaṃ antadvayaṃ anupagamma yathāsakaṃ paccayehi anurūpaphaluppatti idha majjhimā paṭipadāti adhippetā. (Mahāṭīkā, vol. 2, p. 236.)

When a meditator attains the two knowledges of discerning mentality-materiality (nāmarūpaparicchedañāṇa) and discerning conditions (paccayapariggahañāṇa), the meditator personally sees correctly and penetrates, with the wisdom of right view, the continuous causal arising of resultant phenomena such as formations in dependence on the concurrence of their respective causes such as ignorance.

When the meditator knows and sees in this way, that knowledge does not fall into the two extremes called eternalism and annihilationism. The meditator enters the Middle Way taught by the Buddha, which shows how each corresponding group of causes gives rise to effects consonant with those causes.

What is the Middle Way leading to Nibbāna?

When the meditator knows (1) the causal phenomena such as ignorance, (2) the resultant phenomena such as formations, and (3) the causal relationship between phenomena such as ignorance and their effects such as formations, the meditator examines those groups of causes and effects in light of the three characteristics and diligently develops insight into them. This is that path.

If insight is not developed in that way, or if the meditator is unable to discern in that way, those causes and effects go on uninterrupted, arising time and again…


<a id="M06-body-P024"></a>
## The Middle Way and suffering in the course of existence
Miến / Burmese 24

… and so continue. That course is called suffering in the course of existence (pavattidukkha). Causes and effects keep arising in that way. Striving to keep them arising is the wrong path (kummagga), a deviation from the Middle Way to Nibbāna, a wrong turning directly opposed to it. It serves only to extend the round of rebirths and the states of deprivation.

If a good person can subject the successive causes and effects such as ignorance and formations in the three periods, past, present and future, from the earlier past through to the end of the future, to the three characteristics and diligently develop insight, the attachments of craving, conceit and views that hold fast to those causes and effects as “I,” “mine,” and “my self” will disintegrate and be destroyed.

Thus developing insight in this manner is to proceed firmly along the Middle Way with the faculties endowed with strength and quality. If a good person can proceed well and diligently along that Middle Way without interruption, then one day, when the faculties mature and come together, that person will certainly reach the Nibbāna long aspired to.

What is dependent origination?

Paṭiccasamuppādoti paccayadhammā veditabbā. Paṭiccasamuppannā dhammāti paccayanibbattā dhammā. (Visuddhimagga, vol. 2, p. 148.)

Tehi tehi paccayehi nibbattā…


<a id="M06-body-P025"></a>
## Conditioning and conditioned phenomena
Miến / Burmese 25

… tathā paṭiccasamuppādā icceva phalavohārena vuttāti veditabbā. (Visuddhimagga, vol. 2, p. 152.)

Understand that causal phenomena such as ignorance are dependent origination (paṭiccasamuppāda). Understand that the effects, such as formations, arising due to causes such as ignorance are dependently arisen phenomena (paṭiccasamuppanna). (Visuddhimagga, vol. 2, p. 148.)

In “with ignorance as condition, formations” (avijjāpaccayā saṅkhārā), ignorance is the causal conditioning phenomenon and formations are the conditioned result. The causal phenomenon is called a conditioning phenomenon (paccayadhamma), and the resulting phenomenon is called a conditioned phenomenon (paccayuppannadhamma). In “with formations as condition, consciousness” (saṅkhārapaccayā viññāṇaṃ), formations are the causal conditioning phenomena and consciousness is the conditioned result. Understand the conditioning and conditioned phenomena in this way through birth and aging and death.

In the causal relationship between ignorance and formations, formations are the effect. In the causal relationship between formations and consciousness, formations are in turn the cause. Understand the causal and resultant roles of consciousness, mentality-materiality, and the subsequent factors in the same way.

In teaching that formations arise due to ignorance, and so on, the Buddha points out the principal cause and the principal effect by way of what is predominant. Ignorance has no power to arise on its own. The volition that constitutes formations likewise has no power to arise on its own. For that volition to arise in isolation due to ignorance alone…


<a id="M06-body-P026"></a>
## Multiple causes and multiple effects
Miến / Burmese 26

… there is no such power, and there is no natural law of arising in that way. In this world:

1. A single effect does not arise from a single cause.
2. Many effects do not arise from a single cause.
3. A single effect does not arise from many causes.
4. It is only from many causes that many effects arise. (Abhidhamma Commentary, vol. 2, p. 140. Visuddhimagga, vol. 2, pp. 173–174.)

A collection of many causal phenomena is called a group of conditioning phenomena (paccayadhammasamūha). A collection of many resultant phenomena is called a group of conditioned phenomena (paccayuppannadhammasamūha). The collection of many effects that arise due to that collection of many causes is also called dependent origination (paṭiccasamuppāda).

For example, (1) climate (utu), that is, heat and cold, (2) earth (paṭhavī), that is, the soil for planting, (3) seed (bīja), and (4) water (salila): only due to multiple causes such as these does the effect called a shoot arise. It consists of many nutriment-born material groups with colour, smell, taste and other material phenomena. In the same way, due to many causal phenomena…


<a id="M06-body-P027"></a>
## Why the Buddha singles out individual causes and effects
Miến / Burmese 27

… one sees a collection of many effects arise. Even so, in statements such as “with ignorance as condition, formations” and “with formations as condition, consciousness,” the Buddha taught by expressly identifying an individual cause and an individual effect. There is a purpose and a benefit to this way of teaching.

In explaining the Dhamma to his disciples, he may single out one cause or one effect: (1) because in some Pāli passages it is the principal cause, (2) because in some Pāli passages it is the evident cause, or (3) because in some Pāli passages it is the distinctive cause, one not shared with other phenomena.

He presents the teaching in a way consonant with his omniscient knowledge (sabbaññutañāṇa), which makes the exposition orderly and apt, and in a way suited to the preferences, temperaments, inclinations and dispositions of beings to be guided, such as humans, devas and brahmās, whether or not they can yet penetrate a meditation subject. (Abhidhamma Commentary, vol. 2, p. 140. Visuddhimagga, vol. 2, p. 174.)

For these three reasons, the teaching of dependent origination expressly identifies one cause and one effect…


<a id="M06-body-P028"></a>
## Ignorance as the principal, evident, and distinctive cause
Miến / Burmese 28

… Thus, although there are other causes of formations, that is, volition, such as the material base, object and conascent phenomena that assist its arising, the Buddha also taught as follows.

“Assādānupassino taṇhā pavaḍḍhati” means: Bhikkhus, craving grows in the continuity of one who repeatedly contemplates gratification in objects liable to become objects of fetters. (Saṃyutta, vol. 1, p. 311.) Again, “Avijjāsamudayā āsavasamudayo” means that with the arising of ignorance, the taints arise. (Majjhima, vol. 1, p. 68.)

These teachings show that phenomena such as craving, in addition to ignorance, act as causes of formations. Such phenomena as craving are indeed causes of formations. Among these causes, however, ignorance is the principal one.

“Avidvā bhikkhave avijjāgato puññābhisaṅkhārampi abhisaṅkharoti.” Bhikkhus, the one without knowledge, who does not know the true nature of ultimate phenomena and is overcome by ignorance, also generates meritorious formation. As such teachings show, ignorance is also an evident cause of formations.

Causes such as the material base, object and conascent phenomena are related to all mental phenomena in the planes of five aggregates. Ignorance is a distinctive cause of formations…


<a id="M06-body-P029"></a>
## Three reasons for singling out a cause
Miến / Burmese 29

… that is, a cause not shared with other phenomena. Because ignorance is a distinctive cause, not shared with other phenomena, and on account of the three grounds just stated, understand that the Buddha taught ignorance as the cause of formations.

The same explanation of why the Buddha singled out an individual cause and an individual effect also shows the purpose and benefit of that way of teaching in such cases as consciousness arising due to formations. (Abhidhamma Commentary, vol. 2, p. 140. Visuddhimagga, vol. 2, p. 174.)

These explanations from the commentaries are important records concerning the nature of phenomena. Accomplished meditators who actually develop and investigate insight so that their knowledge penetrates the powers of ultimate phenomena should pay them particular attention, respectfully receive them, and retain them.

The reason why the collection of many causes called the group of conditioning phenomena is also named dependent origination has already been explained: it is only because of that collection that the many effects called the group of conditioned phenomena come into being. The Visuddhimagga commentary, vol. 2, pp. 151–152, also explains why the resultant group called the group of conditioned phenomena, arising from the collection of causes, is called dependent origination. That explanation follows.


<a id="M06-body-P030"></a>
## Explanation of the term Paṭiccasamuppāda
Miến / Burmese 30

When collections of effects known as groups of conditioned phenomena are given the name dependent origination, the wise wish to analyse the word paṭiccasamuppāda in two ways, from two perspectives, and explain it in two senses.

Explanation of the term Paṭiccasamuppāda.

A meditator directs the course of knowledge toward the nature of dependent origination, namely the collection of effects produced by the power of a collection of causes. The meditator strives to penetrate that nature with knowledge and comes to know it. Directing knowledge toward and penetrating the nature of dependent origination in this way is for supramundane benefit and happiness, for attaining path and fruition knowledge, and for realizing Nibbāna. Thus the group of conditioned effects called dependent origination is worthy of the confidence of wise and good people and worthy of their directing knowledge toward it. For that reason the group of conditioned effects is termed paṭicca.

Further, when the collection of effects called the group of conditioned phenomena arises, not even one phenomenon or part of one arises singly, one by one. They arise only together, in groups, in collections. Therefore that group of effects is also called samuppāda. «Divide samuppāda into saṃ + uppāda. Saṃ means saha, that is, together, in one group or collection. Hence saha + uppāda = samuppāda, that is, saha uppajjatīti samuppādo, “it is samuppāda because it arises together.”»


<a id="M06-body-P031"></a>
## Arising together and arising through proper conditions
Miến / Burmese 31

Further, the collection of effects called the group of conditioned phenomena does not arise in the absence of causes, nor does it arise from an eternal, unsuitable creating cause. It arises only through proper, appropriate causes. «In this explanation, analyse it as sammā + uppāda = samuppāda, that is, sammā uppajjatīti samuppādo, “it is samuppāda because it arises properly.”» The phenomena do not arise singly, one by one, and they do not arise causelessly or without causes. Thus, in accordance with “Saha sammā ca uppajjatīti samuppādo,” it is called samuppāda.

Paṭicco ca so samuppādo cāti paṭiccasamuppādo. (Visuddhimagga, vol. 2, pp. 151–152.)

According to the commentary’s explanation, this is a collection of phenomena worthy of being approached and known by knowledge, a collection of those same phenomena arising together, and a collection of phenomena arising through appropriate causes. Therefore it is called paṭiccasamuppāda.

There is another explanation.

Api ca saha uppajjatīti samuppādo, paccayasāmaggiṃ pana paṭicca appaccakkhāyāti evampi paṭiccasamuppādo. (Visuddhimagga, vol. 2, p. 152.)
Saha uppajjatīti ekajjhaṃ uppajjati, antamaso aṭṭhannaṃ dhammānaṃ uppajjanato. (Mahāṭīkā, vol. 2, p. 234.)

The collection of effects called the group of conditioned phenomena arises only together as a group. On the side of materiality, in each material group there are at least eight ultimate material phenomena: earth, water, fire, air, colour, smell, taste and nutritive essence…


<a id="M06-body-P032"></a>
## Concurrence of conditions and arising together
Miến / Burmese 32

… only when those eight phenomena are combined can they arise together as one group. On the side of mentality, there are likewise at least eight ultimate mental phenomena: contact, feeling, perception, volition, one-pointedness, life faculty, attention and consciousness. Only when these eight phenomena are combined can they arise together as one group.

Thus the group of conditioned effects is called samuppāda because it arises together as one collection. Even as it arises together, it comes into being only by relying on the concurrence of its causes, depending on them and without dispensing with them. Hence it is termed paṭicca because it arises in dependence on the concurrence of causal phenomena, and samuppāda because it arises together as one group. On account of those two capacities it is called paṭiccasamuppāda.

Further, with regard to the group of conditioned effects such as formations, called dependent origination, the group of conditioning phenomena or causes such as ignorance is called paccaya, a condition or cause. Thus the group of conditioned effects such as formations is called tappaccayadhamma, phenomena that have those causal phenomena such as ignorance as their conditions. Because the group of conditioning phenomena, the group of causes such as ignorance, is the cause of the conditioned group called dependent origination, that causal group itself is also called dependent origination.

In ordinary usage, phlegm is what causes one to spit, and the lump of phlegm is called “that which is to be spat out.” In the Dispensation, the appearance of Buddhas is the cause of happiness…


<a id="M06-body-P033"></a>
## Applying the name of the effect to the cause
Miến / Burmese 33

… and so it is said, “Sukho buddhānaṃ uppādo,” the appearance of Buddhas is happiness. Likewise, understand that the group of causes such as ignorance, the group of causal or conditioning phenomena, is taught as dependent origination by the figurative application of the effect’s name to its cause (phalūpacāra). (Visuddhimagga, vol. 2, pp. 151–152.)

On this explanation, the name dependent origination, belonging to the conditioned group of effects, is transferred to the conditioning group, the group of causes. Thus the group of causes too is taught as dependent origination. Effects cannot dispense with their causes. Only when the causes are present can effects arise. It is in this sense of indispensability (avinābhāva) that the causal group is also said to be taught as dependent origination.

Explanation by another method.

The Visuddhimagga commentary, vol. 2, p. 152, gives a further explanation. In this explanation, the conditioning group, the group of causes, is explained as dependent origination.

In this method, divide paṭicca into paṭi + icca. Paṭi has the meaning abhimukhattha, facing toward. Icca has the meaning gammattha, going to. If it is asked what phenomenon faces toward and goes to what other phenomenon, the answer is the group of causes, the group of conditioning phenomena.


<a id="M06-body-P034"></a>
## The concurrence of causes and their joint support of effects
Miến / Burmese 34

Hetusamūho nāma paccayasāmaggī. (Mahāṭīkā, vol. 2, p. 234.) The group of causes is the concurrence of conditions. In other words, the group of causal phenomena that comes about through this concurrence is called hetusamūha, the group of causes.

Within that group of causes in concurrence, one causal phenomenon faces another, and the causes go toward and meet one another. Hence the Buddha teaches that group of causes as paṭicca. The concurring causal group called paṭicca can bring about a group of conditioned effects that arise together, in a collection, in groups and simultaneously. These effects do not arise separately one at a time, or in isolation from one another. Since it can produce that group of effects, the group of causes is also called samuppāda. (Divide samuppāda into saṃ + uppāda. Saṃ has the meaning saha, together.)

Because it has these two capacities, the concurring causal group called hetusamūha can cause the conditioned effects to arise simultaneously in groups and as a collection, rather than separately. The causes in that group face toward and go to one another. Thus it is called paṭiccasamuppāda. (This method likewise uses the analysis: paṭicco ca so samuppādo cāti paṭiccasamuppādo.)


<a id="M06-body-P035"></a>
## Further explanation of conditions that assist together
Miến / Burmese 35

In Pāli passages such as “with ignorance as condition, formations” (avijjāpaccayā saṅkhārā), the Buddha singles out one cause such as ignorance and gives it prominence to show the manifest arising of effects such as formations. This is indeed how he taught. Yet ignorance alone is not the sole cause of formations. When considered according to their actual nature, the following conditions also apply:

1. Conascent phenomena such as contact, feeling, perception and consciousness, arising together and associated in the same consciousness moment with the formation, namely volition.

2. Great elements and derived materiality together with the heart-base (hadayavatthu), the support on which those phenomena conascent with the formation arise.

3. Causal phenomena such as the object grasped and relied on by the phenomena conascent with the formation.

4. Wise attention (yonisomanasikāra) or unwise attention (ayonisomanasikāra) as a cause.

5. Causal phenomena accompanying ignorance, such as craving and clinging.

All these causes, to the extent applicable, are cooperating causes (sahakārīkāraṇa). When ignorance gives rise to formations, they act together with ignorance to bring about the effect called formations. The same applies when causes such as formations bring about effects such as consciousness. (Mahāṭīkā, vol. 2, p. 234.)


<a id="M06-body-P036"></a>
## Effects are connected to all their respective causes
Miến / Burmese 36

When causal phenomena such as ignorance give rise to effects such as formations, all the respective effects arise only in relation to all the effective causal phenomena in each case. They are connected to one another by the nature of causation. The effects do not relate to some of the causes in the group while being wholly unrelated and unconnected to other effective causes.

Thus the group of causes, which the Buddha indicates by giving prominence to one phenomenon such as ignorance, has the natural capacity to bring the effect to completion and make it arise. That effect is related to all the effective causes within the group and connected to them by the nature of causation.

Further, suppose that this effect had no relation to certain causes, that is, that it was not causally connected to some of them and only certain causes produced it. If that were so, the causes would have no nature of assisting one another. Without such mutual assistance, one cause could not face and approach another, and there would be no sense of paṭicca. The meaning would therefore be incomplete. Now the Buddha…


<a id="M06-body-P037"></a>
## Causes facing one another and effects arising together
Miến / Burmese 37

… teaches by giving prominence to individual phenomena such as ignorance, the entire group of causes relates to the entire group of respective effects taught by giving prominence to individual phenomena such as formations. Because there is this causal connection, the meaning of paṭicca is neither deficient nor diminished.

Thus, to show the manifest arising of effects such as formations, the Buddha gives prominence to causes such as ignorance. That group of causes is termed paṭicca because it can bring its corresponding effects to completion, because it is neither deficient nor diminished, and because among the constituents of the concurrence of conditions (paccayasāmaggī), such as contact, feeling, perception, volition and consciousness, each faces toward and approaches another.

That causal group (hetusamūha), called paṭicca, can produce the group of conditioned effects (paccayuppannadhammasamūha). These effects arise together, as a collection, simultaneously. Their arising in this way means they do not arise separately, one by one. Unlike the causes that assist one another, among those effects one does not assist or accommodate another. Thus they are called aññamañña-avinibbhogavattidhammā, phenomena that occur inseparably from one another. Thus the group of causes called paṭicca, by producing the group of conditioned effects that occur inseparably…


<a id="M06-body-P038"></a>
## The third explanation in the Visuddhimagga
Miến / Burmese 38

… is also called samuppāda. On account of these two capacities by which it is called paṭicca and samuppāda, the causal group such as ignorance is named dependent origination. (Include material phenomena among phenomena that arise inseparably.) (Visuddhimagga, vol. 2, p. 152. Mahāṭīkā, vol. 2, pp. 234–235.)

The Visuddhimagga commentary gives a third explanation.

Avijjādisīsena niddiṭṭhapaccayesu hi ye paccayā yaṃ saṅkhārādikaṃ dhammaṃ uppādenti, na te aññamaññaṃ apaṭicca aññamaññavekalle sati uppādetuṃ samatthā. Tasmā paṭicca samaṃ saha ca na ekekadesaṃ, nāpi pubbāparabhāvena ayaṃ paccayatā dhamme uppādetīti atthānusāravohārakusalena muninā evamidha bhāsitā, paṭiccasamuppādotveva bhāsitāti attho. (Visuddhimagga, vol. 2, p. 152.)

Paṭiccāti nissāya, sahakārīkāraṇaṃ laddhā. Samanti avisamaṃ, avekallena. Sahāti ekajjhaṃ. Dhammeti attano paccayuppannadhamme. Pe. Ekekadesanti phalasamudāyaṃ ekadesekadesato, bhāgaso ti attho. Pubbāparabhāvenāti paṭipāṭiyā. Sabbametaṃ rūpārūpakalāpuppādaṃ sandhāya vuttaṃ. (Mahāṭīkā, vol. 2, p. 235.)

Among the causal groups presented with individual causes such as ignorance at their head, the causal group such as ignorance can produce the group of effects such as formations. In producing effects thus, if the causes did not rely and depend on one another, they could not produce the group of effects such as formations. Together with ignorance…


<a id="M06-body-P039"></a>
## The supporting causes must all be present
Miến / Burmese 39

… there are the causes (a) supporting material base, (b) object, (c) conascent phenomena such as contact, feeling, perception, volition and consciousness, and (d) unwise attention. If a cause among them is lacking or does not arise, they cannot produce the collection of effects such as formations. Only when the causes rely upon one another and are all present can they produce the collection of effects such as formations.

Thus the causal group such as ignorance produces the group of effects such as formations only when (1) the causes rely on one another, (2) are present in full without deficiency or diminution, and (3) act together, simultaneously. In producing them thus, they do not produce merely a part, portion, or subset of the collection of effects, nor do they produce each effect in succession, one after another. Therefore the Fully Awakened Buddha, foremost among the wise and skilled in usage that accords with ultimate meaning, calls this nature of causal connection dependent origination. (Visuddhimagga, vol. 2, p. 152. Mahāṭīkā, vol. 2, p. 235.)

Sabbametaṃ rūpārūpakalāpuppādaṃ sandhāya vuttaṃ. (Mahāṭīkā, vol. 2, p. 235.)

All the foregoing is explained with reference to the arising in groups and collections of ultimate material and mental phenomena, the causes and effects, as groups of materiality and groups of mentality. (Mahāṭīkā, vol. 2, p. 235.)


<a id="M06-body-P040"></a>
## Groups of materiality and mentality
Miến / Burmese 40

Following the usage of the Visuddhimagga Mahāṭīkā, this book also uses (1) material group (rūpakalāpa) for a collection of eight, nine, ten or more ultimate material phenomena present together in one minute particle of materiality, of atomic size or, to put it another way, many times smaller than an atom; and (2) mental group (nāmakalāpa) for a collection of mental phenomena comprising consciousness and mental factors arising and associated in each consciousness moment.

In the third explanation above, analyse paṭiccasamuppāda as follows: Aññamaññaṃ paṭicca samaṃ saha ca paccayuppanne dhamme uppādetīti paṭiccasamuppādo.

The meaning is that the group of causes relies on one another and can produce the groups of effects fully, together and simultaneously, and so is called paṭiccasamuppāda. On this interpretation, only the causal group bears the name dependent origination in the primary sense. The conditioned groups of effects bear that name in the sense of indispensability (avinābhāva). A cause is called a cause because it can produce an effect. Thus a genuine cause cannot be separated from its effect. Likewise, a genuine effect cannot be separated from its cause. That inseparability is called avinābhāva…


<a id="M06-body-P041"></a>
## The two meanings of saṃ in samuppāda
Miến / Burmese 41

… Since this is a nature that wise and good people should know and understand, it is called naya, a method of explanation. Joining avinābhāva with naya gives avinābhāvanaya, the method of explanation by indispensability.

In the word paṭiccasamuppāda, divide samuppāda into saṃ + uppāda. Saṃ yields two meanings: samaṃ and saha.

1. Samaṃ means that when a causal group such as ignorance produces formations, it does not produce the formation, that is, volition, in isolation. It also produces, in full and without diminution, the consciousness and mental factors that ordinarily arise with formative volition, such as contact, feeling, perception and consciousness.

2. Saha means that when producing the consciousness and mental factors accompanying formative volition in this way, it does not produce them part by part or one by one, each after another, but produces them together, as one collection, at the same time.

In the group of phenomena such as formations brought about due to ignorance, however, the volition called formation is foremost. Thus, by the method of giving prominence to what is principal, the Buddha singles out formative volition and teaches: “Avijjāpaccayā saṅkhārā — with ignorance as condition, formations.”

When it is said that “ignorance produces formations,” ignorance alone cannot produce formations. There are also assisting causes that ordinarily work together with ignorance to bring formations into being. For formations to arise…


<a id="M06-body-P042"></a>
## Five groups of causes that support formations
Miến / Burmese 42

1. The material heart-base must arise beforehand and assist as a support. This is the power of base-prenascence dependence condition (vatthupurejātanissayapaccaya).

2. The object, the cause grasped and depended on by the formation, must also assist by the power of object condition (ārammaṇapaccaya).

3. The group of consciousness and mental factors such as contact, feeling, perception and consciousness that arises together and is associated with the formation in one consciousness moment must also assist by the power of conascence condition (sahajātapaccaya).

4. Unwise attention, which habitually attends to the object in a mistaken way as permanent, pleasant, self and beautiful, or wise attention, which habitually attends to it correctly as impermanent, suffering, not-self and unattractive, must also assist by the power of decisive support condition (upanissayapaccaya), a powerful support.

5. Craving and clinging accompanying ignorance must likewise assist by the power of decisive support condition, a powerful support.

Causes such as the material base, object, conascent phenomena, unwise or wise attention, craving and clinging are assisting causes that ordinarily produce formations together with ignorance. Only by depending on the concurrence of all these causes can ignorance produce formations. If a cause is missing, ignorance cannot make formations arise. Only when the causes depend on one another and are present in full can they produce the collection of effects such as formations.


<a id="M06-body-P043"></a>
## The collection of effects arises at the same time
Miến / Burmese 43

Further, in accordance with the regularity of ultimate mental phenomena, formative volition has no capacity to arise alone. It can arise only together with accompanying consciousness and mental factors such as contact, feeling, perception and consciousness. It can arise only in a group, as a group of wholesome or unwholesome formations.

Thus it is only when causes such as ignorance rely upon one another, concur without diminution, and work together simultaneously that the group of effects such as formations arises. They do not produce a mere part or subset, nor do they produce the effects one at a time in succession. The group of causes such as ignorance produces the entire group of effects such as formations, fully, evenly and without diminution, together as one group and simultaneously.

Because of the two capacities just described as paṭicca and samuppāda, the collection of causes that rely upon one another and produce the conditioned effects fully, together and simultaneously bears the name dependent origination in its primary sense. The group of effects bears that name by indispensability (avinābhāva). That is, the name dependent origination belonging to the causes is transferred to their effects by naming the effects after their cause (kāraṇūpacāra). This is the third explanation of paṭiccasamuppāda in the Visuddhimagga commentary. (Visuddhimagga, vol. 2, p. 152. Mahāṭīkā, vol. 2, p. 235.)


<a id="M06-body-P044"></a>
## Benefits of the teaching on dependent origination
Miến / Burmese 44

For arriving at a firm conclusion.

The word paṭiccasamuppāda is explained in such detail so that the meditator can accept the way of discerning causal relationships in dependent origination to be presented later. Why discern the consciousness and mental factors accompanying ignorance as well? Why discern the consciousness and mental factors accompanying formations, that is, volition, as well? The explanation forestalls such objections. If the understanding goes astray, the practice too can go astray. Pay attention to this.

Benefits and advantages.

In teaching dependent origination in the manner just explained, the Fully Awakened Buddha (1) uses the first word, paṭicca, to show clearly the absence and non-arising of doctrines such as eternalism, (2) uses the second word, samuppāda, to show clearly the overthrow of doctrines such as annihilationism, and (3) uses the compound paṭiccasamuppāda to show clearly the noble practice of the eight path factors called the Middle Way (majjhimā paṭipadā), beyond the two extremes of eternalism and annihilationism.

1. The word paṭicca.

Paṭiccasamuppāda comprises two words, paṭicca and samuppāda. Paṭicca indicates the concurrence of causal phenomena.


<a id="M06-body-P045"></a>
## The three rounds of defilements, kamma, and results
Miến / Burmese 45

In dependent origination there are three rounds: the round of defilements (kilesavaṭṭa), the round of kamma (kammavaṭṭa), and the round of results (vipākavaṭṭa). Ignorance, craving and clinging belong to the round of defilements. Formations and kamma-becoming, that is, kamma, belong to the round of kamma. Consciousness, mentality-materiality, the six bases, contact and feeling belong to the round of results.

Depending on the round of defilements, the round of kamma arises. Depending on the round of kamma, the round of results arises. Again, if one does not discern with insight in time and put an end to attachment to the five aggregates subject to clinging called the round of results, then in dependence on that round, ignorance, craving and clinging, called the round of defilements, arise again. Then, depending on the round of defilements, through generating and cultivating wholesome and unwholesome formations, formations and kamma, called the round of kamma, arise again.

Due to that round of kamma, in future lives the five aggregates subject to clinging, comprising consciousness, mentality-materiality, the six bases, contact and feeling and called the round of results, arise again. The Buddha teaches those five future aggregates under the names birth, aging and death. The three rounds thus continue without interruption, like a wheel in motion.

The first word paṭicca indicates the concurrence of the causes, the coming together of causal phenomena. Because the round of defilements, the round of kamma and the round of results arise in an unbroken succession like a turning wheel, through the concurrence and connection of causes, this word shows the absence of doctrines such as (1) eternalism (sassatavāda), (2) the doctrine of no cause (ahetuvāda)…


<a id="M06-body-P046"></a>
## Eternalism and the doctrine of no cause
Miến / Burmese 46

… (3) the doctrine of a wrong cause (visamahetuvāda), and (4) the doctrine of an overriding ruler (vasavattivāda). The word shows that these doctrines do not hold. Indeed, what meaning could the concurrence of a group of causes (paccayasāmaggī) have for doctrines such as eternalism, which reject genuine causes? The concurrence of the causes makes the effects arise together as a group. Hence doctrines rejecting genuine causes become meaningless. (Visuddhimagga, vol. 2, p. 153. Mahāṭīkā, vol. 2, p. 235.)

Eternalism (sassatavāda) is the doctrine that habitually asserts, holds and believes “sassato attā ca loko ca,” that the self and the world are eternal. It holds that the self has always endured from the past and moves from one life to another. Even when it changes to a new house of aggregates, the self does not disappear from one life to another, but always follows along and dwells in each new house. (Dīgha, vol. 1, p. 12.)

The doctrine of no cause (ahetuvāda): “Natthi hetu natthi paccayo sattānaṃ saṅkilesāya, ahetū appaccayā sattā saṅkilissanti. Natthi hetu natthi paccayo sattānaṃ visuddhiyā, ahetū appaccayā sattā visujjhanti.” (Dīgha, vol. 1, p. 50.) That is, there is no direct cause producing the defilement or purification of beings, and no supporting or sustaining condition. Without a cause, beings still become defiled or purified. The doctrine that directly denies causes in this manner…


<a id="M06-body-P047"></a>
## The doctrines of a wrong cause and an overriding ruler
Miến / Burmese 47

… habitually asserts, holds and believes that there is no cause, and is called the doctrine of no cause. By directly denying causal phenomena, it also indirectly denies their effects. This doctrine does not accept the power of causes to produce effects and rejects kamma and its results.

The doctrine of a wrong cause (visamahetuvāda) habitually asserts, holds and believes that the world comes into being through the power of primordial nature (pakati), atoms (aṇu), time (kāla), and the like. (Mahāṭīkā, vol. 2, p. 235.)

The doctrine of an overriding ruler (vasavattivāda) comprises the doctrines concerning Īsara, Purisa and Pajāpati. The doctrines concerning Purisa and Pajāpati are the same as that concerning Īsara, differing only in name. (Aṅguttara Subcommentary, vol. 3, p. 65.) It habitually asserts, holds and believes that there is a creator and ruler, Īsara, who creates the world and beings, and that the world and beings come into being according to his will. The created self is called jīva-attā, the living self, and the creator Īsara is called parama-attā, the supreme self. This doctrine likewise rejects kamma and its results. (Mahāṭīkā, vol. 2, p. 235.)

At times a meditator strives, with the knowledge of right view, personally to see and penetrate the causal relationship, the nature of dependent origination. Depending on the concurrence of causes, or in other words on the manifest arising of groups of causal phenomena in mutual dependence and concurrence…


<a id="M06-body-P048"></a>
## Direct knowledge and the abandoning of wrong doctrines
Miến / Burmese 48

… the meditator personally penetrates with direct knowledge (paccakkhañāṇa) the full, simultaneous arising of groups of effects together as one group. When the meditator sees and knows that the groups of effects arise fully, as one group, at one time, only in dependence on the manifest arising of mutually reliant and concurring groups of causes, wrong conceptions such as eternalism, the doctrine of no cause, the doctrine of a wrong cause, and the doctrine of an overriding ruler, which do not accept the presence of genuine causes, disappear from that meditator’s continuity.

In other words, the meditator’s knowledge that the collection of effects arises only in dependence on the concurrence of the collection of causes shows the absence of wrong doctrines rejecting genuine causes from the meditator’s continuity. If these doctrines do not occur in the continuity of one who penetrates the nature of conditions with knowledge, then their absence from the teaching of dependent origination itself, which directs the meditator in the practice of personally penetrating the nature of conditions with the knowledge of right view, can no longer be in doubt.

2. The word samuppāda.

The word samuppāda can indicate that the conditioned effects such as formations arise in full, as one group, at the same time…


<a id="M06-body-P049"></a>
## Annihilationism, denial of results, and denial of the efficacy of action
Miến / Burmese 49

… When causes concur, that is, when there is concurrence of conditions (paccayasāmaggī), conditioned effects such as formations become manifest. The word samuppāda thereby dismisses (1) annihilationism (ucchedavāda), (2) the doctrine denying results (natthikavāda), and (3) the doctrine denying the efficacy of action (akiriyavāda). Hence the second word samuppāda makes clear the exclusion of those views. Indeed, if collections of effects such as formations arise time and again through the power of earlier causes, where could those doctrines hold? Thus samuppāda shows that those views do not hold. (Visuddhimagga, vol. 2, p. 153.)

Annihilationism (ucchedavāda) habitually asserts, clings to and believes that the self is cut off when a being dies. “Life is only between the cradle and the coffin. Beyond the coffin there is nothing.” This is also the doctrine of modern leftists and some materialists who give weight only to scientific knowledge.

The doctrine denying results (natthikavāda): “Natthi dinnaṃ, natthi yiṭṭhaṃ, natthi hutaṃ, natthi sukatadukkaṭānaṃ kammānaṃ phalaṃ vipāko…” That is, there is no result of giving, no result of good and bad conduct, no result of good or bad deeds. The doctrine that thus directly denies the existence of effects is called natthikavāda. In directly denying effects, it also rejects the causes that have the power to produce them…


<a id="M06-body-P050"></a>
## Denial of kamma and its results
Miến / Burmese 50

… Thus this doctrine denying results is also a doctrine that does not accept kamma and its results.

The doctrine denying the efficacy of action (akiriyavāda): “Karoto kārayato, chindato chedāpayato, pe. na karīyati pāpaṃ.” That is, whether one does it oneself or has others do it, kills or has others kill, it does not count as doing evil or as an act that should or should not be done. This doctrine denies kamma as a cause in claiming that “even if one does good or evil, no action is accomplished, no act that should or should not be done is accomplished, neither good nor evil arises.” This is akiriyavāda.

Tattha kammaṃ paṭibāhantenāpi vipāko paṭibāhito hoti, vipākaṃ paṭibāhantenāpi kammaṃ paṭibāhitaṃ hoti. Iti sabbepete atthato ubhayappaṭibāhakā ahetukavādā ceva akiriyavādā ca natthikavādā ca honti. (Dīgha Commentary, vol. 1, p. 150.)

By rejecting kamma as cause, one also rejects its result. By rejecting the result, one also rejects kamma as cause. Therefore, in meaning, the doctrines of no cause, denial of the efficacy of action and denial of results all reject both kamma and its result. To say that there is no kamma as cause amounts to saying that there is no effect arising in dependence on that cause. To say that there is no effect amounts to saying that there is no cause capable of producing it.

If a meditator, in dependence on the concurrence of causal phenomena such as ignorance, that is, their manifest presence in concurrence, sees clearly the concurrence of effects such as formations…


<a id="M06-body-P051"></a>
## Seeing cause and effect across the three periods
Miến / Burmese 51

… and the manifest arising of those effects by direct knowledge, personally seeing and penetrating them, then in other words the meditator sees distinctly by direct knowledge:

1. The manifest arising in the present life of the effects consciousness, mentality-materiality, the six bases, contact and feeling, due to the causes ignorance, craving, clinging, formations and kamma generated and cultivated in the past.

2. The manifest arising in the future of the effects consciousness, mentality-materiality, the six bases, contact and feeling, due to the causes ignorance, craving, clinging, formations and kamma generated and cultivated in the present life.

3. Likewise, the manifest arising of the five effects in each relevant past life, due to the five causes generated and cultivated in the relevant past life.

4. If the meditator’s future lives are still apparent, the manifest arising of the five relevant future effects due to five relevant causes of the future, present, or past.

Then how could harmful wrong views such as annihilationism, denial of results and denial of the efficacy of action arise in the continuity of a meditator who personally penetrates by insight knowledge such as knowledge of discerning conditions (paccayapariggahañāṇa) how subsequent groups of effects arise repeatedly in causal continuity through dependence on prior causes? They no longer have an opportunity to arise. Likewise, in that teaching on dependent origination…


<a id="M06-body-P052"></a>
## The two words that make up Paṭiccasamuppāda
Miến / Burmese 52

… those harmful wrong views have no foothold either.

3. The words paṭicca and samuppāda.

The compound paṭiccasamuppāda joins the two words paṭicca and samuppāda. When causes such as ignorance concur, the groups of effects such as formations arise, and the causal succession continues without interruption, arising again and again. The compound indicates:

1. The noble practice of the eight path factors called the Middle Way (majjhimā paṭipadā).

2. The removal of harmful doctrines that hold “the very same person acts and experiences” or “one person acts and another experiences.”

3. The absence of misunderstanding and of clinging through craving or views to men, women, and other things named in common usage (janapadanirutti) as truly existing. Ordinary people use these terms without knowing ultimate materiality and mentality or the nature of their causal relationship.

4. Not going beyond the worldly conventional truth, that is, the names ordinarily used in the world.

In this way the term points out the Noble Path, the means leading to Nibbāna. (Visuddhimagga, vol. 2, p. 153.)


<a id="M06-body-P053"></a>
## Further explanation of the Middle Way
Miến / Burmese 53

1. The Middle Way (majjhimā paṭipadā). First the meditator strives to attain knowledge of discerning mentality-materiality and knowledge of discerning conditions. When the meditator personally penetrates by direct knowledge the nature of dependent origination, namely the uninterrupted recurrence of conditioned groups of materiality, mentality, causes and effects from earlier to later throughout past, present and future, from as far back as can be discerned to as far forward as can be discerned, that knowledge is right view.

The knowledge that penetrates materiality and mentality, the five aggregates subject to clinging, is right view. According to teachings such as “Saṅkhittena pañcupādānakkhandhā dukkhā” (Majjhima, vol. 1, p. 82), the five aggregates subject to clinging are phenomena belonging to the noble truth of suffering. The knowledge that penetrates those phenomena is right view that knows the noble truth of suffering, in accordance with “Dukkhe ñāṇaṃ.” (Majjhima, vol. 1, p. 88.)

In accordance with the Buddha’s teaching in the Titthāyatanasutta in the Tikanipāta of the Aṅguttara (vol. 1, p. 178), the knowledge that penetrates the nature of dependent origination, the causal connection between phenomena belonging to the noble truth of suffering and those belonging to the noble truth of its origin, is right view that knows the noble truth of the origin, in accordance with “Dukkhasamudaye ñāṇaṃ.” (Majjhima, vol. 1, p. 88.) (1)

The phenomena belonging to the noble truths of suffering and its origin are called conditioned phenomena. The nature of directing the mind toward the conditioned object comprising materiality, mentality, causes and effects, the phenomena belonging to the noble truths of suffering and its origin, and arising in association with right view that penetrates those phenomena, is right intention. (2)


<a id="M06-body-P054"></a>
## The eight factors of the Noble Path
Miến / Burmese 54

The nature of striving diligently to know the causal relationship of materiality and mentality, arising in association with that knowledge of right view, is right effort. (3)

The nature of repeatedly taking note of, discerning and investigating the conditioned phenomena comprising materiality, mentality, causes and effects, keeping the mind steady on that conditioned object, sinking into it like a slab of stone instead of floating like a gourd, is right mindfulness. (4)

The nature of the mind’s steadiness on the conditioned object comprising materiality, mentality, causes and effects, arising in association with that knowledge of right view, is right concentration, the concentration of insight. If a good person takes serenity as the vehicle, uses jhāna concentration as a basis for insight and then turns to insight, that foundational jhāna concentration is also right concentration, in accordance with the Buddha’s teaching in the Mahāsatipaṭṭhānasutta. (Majjhima, vol. 1, p. 89.) (5)

The virtue that the good person undertakes and guards before starting meditation consists of right speech, right action and right livelihood. (6, 7, 8.)

At the mundane stage, these three factors of virtue do not arise associated in the same consciousness moment as the right view, right intention, right effort, right mindfulness and right concentration that take the conditioned phenomena comprising materiality, mentality, causes and effects as their object, as explained above. This is because their objects differ.

Together they constitute the eight path factors, the Noble Path, the means leading to Nibbāna. Thus materiality…


<a id="M06-body-P055"></a>
## The Middle Way, and the doer and experiencer
Miến / Burmese 55

… and mentality are conditioned phenomena that arise in causal relationship. Personally penetrating that nature of dependent origination with the eye of wisdom is to walk the Noble Path, the means leading to Nibbāna, with the faculties endowed with strength and quality. It is also to make manifest the Noble Path and the Middle Way. In this exposition of dependent origination, the arising of effects corresponding to their respective groups of causes, without falling into the two extremes of eternalism and annihilationism, is meant by the Middle Way (majjhimā paṭipadā). (Mahāṭīkā, vol. 2, p. 236.)

Tesaṃ tesaṃ paccayuppannadhammānaṃ sambhavato uppajjanato sassatocchedasaṅkhātaṃ antadvayaṃ anupagamma yathāsakaṃ paccayehi anurūpaphaluppatti idha majjhimā paṭipadāti adhippetā. (Mahāṭīkā, vol. 2, p. 236.)

2. The doer and the experiencer. Of the two rounds, the round of kamma consists of wholesome or unwholesome phenomena. The round of results consists of resultant material and mental phenomena. Thus the wholesome or unwholesome round of kamma and the round of results have distinct characteristics. (See the section on the four aspects, beginning with characteristic.) The round of kamma is the cause, and the round of results is the effect. Thus their natures differ.

Further, the round of kamma and the round of results arise at different times. For a good person, the groups of process-free mental phenomena, namely rebirth-linking, life-continuum and death, as well as the groups of mental phenomena within cognitive processes, namely the five kinds of sense-consciousness, receiving, investigating…


<a id="M06-body-P056"></a>
## Past kamma and results in the present life
Miến / Burmese 56

… and resultant registering mental phenomena, together with materiality born of kamma from rebirth-linking through the course of a life, all belong to the round of results. The kamma that causes this round of results is generally kamma generated and cultivated in a past life. “Generally” is used because there are also deeds capable of giving results in the present life (diṭṭhadhammavedanīyakamma). Those deeds capable of giving results in the present life do not cause rebirth-linking in this life. They can give results only in the course of this life at the appropriate time.

Kammapaccayenāti anekānampi kappakoṭīnaṃ matthake attano phalaṃ uppādetuṃ samatthena nānakkhaṇikakammapaccayenāti attho. (Abhidhamma Commentary, vol. 3, p. 374.)

The past kamma capable of producing the round of results such as rebirth-linking mentality-materiality in this life may be kamma generated and cultivated in the first past life, in the second or other relevant past lives, or many millions of aeons ago. Given the opportunity, kamma generated and cultivated in a life preceding rebirth-linking in this life can produce the phenomena of the round of results, such as rebirth-linking, in this life.

Therefore the causal kamma called the round of kamma and the resultant materiality and mentality called the round of results do not arise at the same time. They arise at different times. Understand likewise for successive past and future lives. Further, even in the case of kamma giving results in the present life (diṭṭhadhammavedanīyakamma), the time of the causal kamma and that of the effects arising from it are separated by at least…


<a id="M06-body-P057"></a>
## Seeing cause and effect without finding a self
Miến / Burmese 57

… many consciousness moments.

Because the round of kamma and the round of results have different natures and arise at different times, the meditator who personally penetrates the nature of dependent origination, the causal connection between the two rounds, with right view can use the power of right view at the head of the mundane path factors to abandon the view that habitually asserts, holds and believes “So karoti, so paṭisaṃvedeti — the very same person acts and experiences.”

The meditator with the knowledge of right view knows that on the causal side, the round of kamma, there are only collections of conditioned phenomena, causal materiality and mentality. These collections of causal materiality and mentality arise and cease and are only collections of impermanent, suffering and not-self phenomena. On the side of the round of results, the meditator likewise knows there are only collections of conditioned phenomena, resultant materiality and mentality. These collections of materiality and mentality in the round of results also arise and cease and are only collections of impermanent, suffering and not-self phenomena.

When the meditator endowed with the knowledge of right view examines with the eye of wisdom the collections of conditioned phenomena called groups of causes and groups of effects, no doer, experiencer, person, being or self is found. By personal knowledge the meditator comes to the conclusion that there are only groups of conditioned causes and effects, arising in uninterrupted causal succession, again and again, in the nature of impermanence, suffering and not-self…


<a id="M06-body-P058"></a>
## Doer and experiencer as conventional expressions
Miến / Burmese 58

… and reaches that conclusion. In the continuity of someone whose right view enables such a conclusion, where could the eternalist view “the very same person acts and experiences” find a foothold?

The meditator knows the true nature of the matter: calling the arising of causal groups of materiality and mentality, the wholesome and unwholesome aggregates, kāraka, a doer, and calling the arising of resultant groups of materiality and mentality, the resultant aggregates, vedaka, an experiencer, is merely speech in terms of conventional truth. (Mahāṭīkā, vol. 2, p. 236.)

Further, formations and kamma called the round of kamma first arise manifestly in the continuity of materiality, mentality, causes and effects. The meditator personally penetrates that the round of results, the result of formations and kamma in the round of kamma, arises manifestly in that very continuity. Because the meditator sees this with right view, the meditator can abandon the doctrine that habitually asserts, believes and holds “Añño karoti, añño paṭisaṃvedeti — one acts and another experiences,” that the doer and the experiencer are different people, that this body does the deed in this life and another body will experience it in another life.

Khandhānañca paṭipāṭi, dhātuāyatanāna ca,
Abbocchinnaṃ vattamānā, saṃsāroti pavuccati. (Abhidhamma Commentary, vol. 2, p. 142.)

The continuity of materiality and mentality, the aggregates, bases and elements, in which causes and effects are connected and arise time and again without interruption, is called saṃsāra. Thus the meditator…


<a id="M06-body-P059"></a>
## Kamma and result in the same continuity
Miến / Burmese 59

… personally penetrates by direct knowledge the arising of the group of materiality and mentality in the round of results, the effect of kamma in the round of kamma, in the very continuity of materiality, mentality, causes and effects in which the round of kamma previously appeared. The right view of the meditator who sees thus can abandon the mistaken doctrine that one person acts and a different person experiences.

Na hi katassa vināso, akatassa vā abbhāgamo atthi. (Mahāṭīkā, vol. 2, p. 236.)

Indeed, kamma that has been done does not disappear, and kamma that has not been done cannot appear. (Mahāṭīkā, vol. 2, p. 236.) (Understand this as referring to kamma giving results in this life and in the next life, which can lapse before giving results, and kamma giving results in later lives, which retains the capacity to give results until final Nibbāna.)

Suppose that in a past life a good person generated and cultivated wholesome formative kamma while aspiring to become a bhikkhu able to serve the Dispensation. If in this life that person obtains the five resultant aggregates of a bhikkhu able to serve the Dispensation due to the very wholesome formative kamma cultivated in the past life, the following two streams:

1. The continuity of materiality and mentality in the past life when the person cultivated wholesome formative kamma and aspired to become a bhikkhu able to serve the Dispensation.

2. The continuity of materiality and mentality of the round of results, the life of a bhikkhu able to serve the Dispensation attained in the present life.

These two streams arise time and again, linked as cause and effect…


<a id="M06-body-P060"></a>
## Continuity and common usage
Miến / Burmese 60

… and in terms of the nature of that succession of materiality and mentality, they are one continuity. Yet that continuity of materiality and mentality does not proceed as permanent, pleasant and self. It proceeds only as impermanent, suffering and not-self.

It is true that the materiality and mentality at the time of producing kamma in the round of kamma arose and ceased. Because they arose and ceased, the materiality and mentality at the time of producing kamma in the round of kamma indeed differ from the fresh materiality and mentality that successively arise in the present life and are called the round of results arising due to that kamma. Yet in terms of the uninterrupted succession of materiality and mentality, in which the earlier and later are causally connected, the materiality and mentality at the time of producing kamma in a past life and the materiality and mentality called the round of results in this life belong to a single continuity. The right view that personally penetrates this nature can abandon and subdue the mistaken doctrine that the doer is one person and the experiencer another.

3. Common usage (janapadanirutti). Ordinary people have yet to see ultimate materiality and mentality or know their causal relationship, the nature of dependent origination, and call one another men, women, and similar names. This way of naming and speaking is called janapadanirutti. In those whose materiality and mentality have yet to be fully understood in terms of ultimate reality (apariññātavatthu), through attachment by craving, conceit and views, there is the mistaken apprehension “mine, I, my self,” “I, another, man, woman, person, being…


<a id="M06-body-P061"></a>
## Using names without taking them as ultimate
Miến / Burmese 61

… human, deva, brahmā.”

The wise and good person who has the clear vision of right view and personally penetrates by right view the causal relationship of material and mental phenomena, the nature of dependent origination, correctly understands as follows:

“On the basis of conditioned phenomena comprising materiality, mentality, causes and effects, which arise in mutual dependence according to their respective conditions, people assign names such as ‘I, another, man, woman, person, being, human, deva, brahmā.’ This is merely designation. In terms of ultimate nature, ‘I, another, man, woman, person, being, human, deva, brahmā’ and similar entities do not exist.”

Because the good person has the knowledge of right view that correctly understands in this way, the person’s continuity is free of the rigid clinging and mistaken apprehension “mine, I, my self,” “I, another, man, woman, person, being, human, deva, brahmā,” through craving, conceit and views.

Though free of that rigid clinging and mistaken apprehension, the person follows the ordinary speech and designations of people without knowledge of ultimate reality and uses names such as “I, another, man, woman, person, being, human, deva, brahmā.” The person does not speak in terms of their own view of ultimate reality, such as “Pañcakkhandhe ānentu — Let them bring the five aggregates. Nāmarūpaṃ āgacchatu — Let mentality-materiality come,” but uses “man,” “woman,” and similar names…


<a id="M06-body-P062"></a>
## Staying within the scope of convention
Miến / Burmese 62

… alone. Thus, although the person does not say “Let them bring the five aggregates. Let mentality-materiality come” in line with the ultimate view in their own continuity, the person still uses the conventional speech of those without knowledge of ultimate reality: “I, another, man, woman, person, being, human, deva, brahmā.” Though using these names, the person does not, through craving, conceit or views, make the mistake of those without knowledge of ultimate reality, who take men, women and such entities as truly existing.

This absence of mistaken apprehension in common speech is called the absence of misconception in janapadanirutti. It is a benefit that good and wise people with right view of the causal relationship between material and mental phenomena, the nature of dependent origination, can gain for themselves. (See Mahāṭīkā, vol. 2, p. 236.)

4. Not going beyond convention (samaññāya anatividhāvana). Though free of the mistaken apprehension in common speech just explained, the person still does not overstep the conventional worldly names used by ordinary people.

“Satto”ti hi vutte “ko ettha satto? Kiṃ rūpaṃ? Udāhu vedanādayo”ti vibhāgaṃ akatvā lokasamaññāvaseneva lokiyehi viya lokiyoyeva attho samaññaṃ avilaṅghantena voharitabbo. (Mahāṭīkā, vol. 2, p. 236.)

When people ordinarily say “beings,” the person does not analyse with the eye of ultimate knowledge: “What is a being here? Is it materiality or feeling and the rest?” The person uses conventional names such as “man, woman, person, being,” just as people without knowledge of ultimate reality do…


<a id="M06-body-P063"></a>
## Four benefits of clearly seeing dependent origination
Miến / Burmese 63

… and uses them with the ordinary meaning accepted by people in the world, as in such names as the female donor Visākhā and the male donor Anāthapiṇḍika, without going beyond those worldly conventional designations.

If those without the eye of wisdom that sees ultimate reality call the five aggregates a “man,” then good and wise people with right view of the nature of dependent origination likewise say “man.” If ordinary people call the five aggregates a “woman,” then good and wise people with right view of the nature of dependent origination likewise say “woman.” Understand the other terms in the same way. Such usage is precisely to stay within worldly conventional truth, that is, worldly designation.

These are the four benefits available to a meditator who personally penetrates with right view the causal relationship of material and mental phenomena, the nature of dependent origination:

1. Entering the Middle Way.

2. Being able to abandon the mistaken doctrines that “the very same person acts and experiences” and that “one person acts and another experiences.”

3. Avoiding mistaken apprehension in ordinary worldly speech (janapadanirutti).

4. Not going beyond worldly conventional truth. (See Visuddhimagga, vol. 2, p. 153. Mahāṭīkā, vol. 2, p. 235.)


<a id="M06-body-P064"></a>
## Part 2
Miến / Burmese 64

Part 2.


<a id="M06-body-P065"></a>
## The twelve factors of dependent origination and the three periods
Miến / Burmese 65

Part 2.

The twelve factors of dependent origination.

In the teaching of dependent origination in forward order, called the first method, there are some things to know in advance: twelve factors, three periods, three links, four groups, and twenty aspects. The twelve factors are as follows:

1. Ignorance (avijjā).
2. Formations (saṅkhāra).
3. Consciousness (viññāṇa).
4. Mentality-materiality (nāmarūpa).
5. The six bases (saḷāyatana).
6. Contact (phassa).
7. Feeling (vedanā).
8. Craving (taṇhā).
9. Clinging (upādāna).
10. Becoming (bhava).
11. Birth (jāti).
12. Aging and death (jarāmaraṇa).

The three periods.

If the present life is taken as the reference point, then (1) ignorance and formations belong to the group of phenomena of the past period; (2) consciousness, mentality-materiality, the six bases, contact, feeling, craving, clinging, and becoming, here kamma-becoming, belong to the group of the present period; (3) birth and aging and death belong to the group of the future period.

If the first past life is taken as the reference point, then (1) ignorance and formations belong to the group of phenomena of the second past life…


<a id="M06-body-P066"></a>
## The three periods and causal links
Miến / Burmese 66

… (2) consciousness, mentality-materiality, the six bases, contact, feeling, craving, clinging, and becoming, here kamma-becoming, belong to the group of phenomena of the first past life; (3) birth and aging and death belong to the group of the present period. Understand the successive past lives by following this method.

If the first future life is taken as the reference point, then (1) ignorance and formations belong to the group of phenomena of the present period; (2) consciousness, mentality-materiality, the six bases, contact, feeling, craving, clinging, and becoming, here kamma-becoming, belong to the group of the first future life; (3) birth and aging and death belong to the group of the second future life. Understand the successive future lives by following this method.

The three links.

The place where causal and resultant phenomena are linked is called a link.

1. Between formations, the past causal phenomena, and consciousness, the present resultant phenomenon, there is a link joining past cause and present effect.

2. Between feeling, the present resultant phenomenon, and craving, the present causal phenomenon, there is a link joining effect and cause…


<a id="M06-body-P067"></a>
## The third link and the four groups
Miến / Burmese 67

3. Between kamma-becoming, the present cause, and birth, the future effect, there is a link joining cause and effect.

Thus there are three links among the twelve factors of dependent origination. Apply the same method to understand successive past and future lives.

The four groups.

1. In the past group, when ignorance is taken, craving and clinging are also taken, since all three belong to the round of defilements. When formations are taken, kamma is also taken, since both belong to the round of kamma. Thus the five past causes are ignorance, craving, clinging, formations and kamma, that is, kamma-becoming. This is the group of past causes.

2. Consciousness, mentality-materiality, the six bases, contact and feeling are the five present effects arising due to the five past causes. This is the group of present effects.

3. Among present causes, when craving and clinging are taken, ignorance is also taken, since they belong to the same round of defilements. When kamma-becoming, that is, kamma, is taken, formations are also taken, since they belong to the same round of kamma. Thus the five present causes are ignorance, craving, clinging, formations and kamma. This is the group of present causes.

4. Birth is the group of rebirth-linking material and mental phenomena that will arise in the future due to the five present causes. In other words, it is the group of material and mental phenomena of the round of results, namely consciousness, mentality-materiality, the six bases, contact and feeling. This is the group of future effects.


<a id="M06-body-P068"></a>
## Twenty aspects and a way of discerning to know beforehand
Miến / Burmese 68

The twenty aspects comprise (1) five past causes, (2) five present effects, (3) five present causes and (4) five future effects. These make twenty aspects in all. Understand the same for successive past and future lives.

A way of discerning to know beforehand.

At the stage of knowledge of discerning conditions (paccayapariggahañāṇa), discern causes and effects in this way: due to the arising of ignorance, formations arise. Ignorance is the cause and formations are the effect. Discern the other causes and effects in the same way.

At the stages of comprehension knowledge (sammasanañāṇa) and the later phase of knowledge of arising and passing away (udayabbayañāṇa), subject the twelve factors of dependent origination to the three characteristics and take their arising and passing away as the object of discernment. For example: due to the arising of ignorance, formations arise. Ignorance arises and passes away, and is impermanent (suffering, not-self). Formations arise and pass away, and are impermanent (suffering, not-self). Discern the remaining factors in the same way.


<a id="M06-body-P069"></a>
## Discerning arising and passing away by condition and by moment
Miến / Burmese 69

In the early phase of knowledge of arising and passing away, the detailed method subjects the factors of dependent origination to the three characteristics as follows:

1. Seeing arising by condition (paccayato udayadassana): discern how the effect arises due to the arising of the cause. Due to the arising of ignorance, formations arise. Due to the arising of formations, consciousness arises. Discern in that way.

2. Seeing passing away by condition (paccayato vayadassana): discern how the effect ceases due to the cessation of the cause. Due to the cessation of ignorance, formations cease. Due to the cessation of formations, consciousness ceases. Discern in that way.

3. Seeing arising by moment (khaṇato udayadassana): when discerning arising by moment, take only the arising of the factors of dependent origination as the object. Discern individually the arising of ignorance, the arising of formations, and that of the remaining factors.

4. Seeing passing away by moment (khaṇato vayadassana): when discerning passing away by moment, take only the passing away of the factors of dependent origination as the object. Discern the passing away, that is, cessation, of ignorance, formations, and the remaining factors.

5. When discerning arising and passing away by condition together with arising and passing away by moment (paccayato udayabbayadassana and khaṇato udayabbayadassana), discern: due to the arising of ignorance, formations arise. Due to the cessation of ignorance, formations cease. Ignorance arises and passes away, and is impermanent. Formations arise and pass away, and are impermanent. Discern in that way.

At the stage of dissolution knowledge (bhaṅgañāṇa), the meditator attends so that knowledge sees only the dissolution of the factors of dependent origination and then discerns them in light of the three characteristics…


<a id="M06-body-P070"></a>
## Discerning dissolution and the knowledge that discerns
Miến / Burmese 70

… At the higher stages of insight beginning with dissolution knowledge, the meditator no longer attends to the manifest arising of effects due to the manifest arising of causes, called the occurrence of what is acquired through kamma (upādiṇṇakapavatta). Discern in turn under the three characteristics, taking only the dissolution of the factors of dependent origination as the object: ignorance dissolves again and again, and is impermanent (suffering, not-self). Formations dissolve again and again, and are impermanent (suffering, not-self).

When discerning in this way, and knowledge quickly sees the dissolution of the factors, when that dissolution readily appears in the meditator’s knowledge, discern: ignorance dissolves again and again, and is impermanent (suffering, not-self). The discerning knowledge dissolves again and again, and is impermanent (suffering, not-self). Formations dissolve again and again, and are impermanent (suffering, not-self). The discerning knowledge dissolves again and again, and is impermanent (suffering, not-self). Discern in that way.

In discerning thus, discern each cause and effect, such as ignorance and formations, with the associated phenomena, according to each cognitive process that arose, is arising or will arise, and also discern the knowledge that discerns. Use knowledge to break apart each mass of materiality and mentality, dispelling the appearance of materiality and mentality as solid masses so that knowledge reaches ultimate reality.


<a id="M06-body-P071"></a>
## Distinguishing ignorance and formations in each continuity
Miến / Burmese 71

Each being has their own ignorance, formations and the corresponding phenomena. The ignorance and formations of one person differ from those of another. One person may generate and cultivate formative kamma while surrounded by ignorance, craving and clinging to becoming male. Another may generate and cultivate formative kamma while surrounded by ignorance, craving and clinging to becoming female. Thus the ignorance is different.

In one person, kamma of giving may give results, in another, kamma of virtue, and in another, kamma of development. Even within giving, kamma of offering food may give results in one person and kamma of offering flowers in another. Thus each person’s ignorance and formations are different. Even in one’s own continuity of materiality and mentality, ignorance and formations generally differ from life to life. Differences occur according to each case.

Therefore discern with knowledge the ignorance, formations and remaining phenomena that arose, are arising, or will arise in one’s own continuity of materiality and mentality. This text presents the pattern “due to the arising of ignorance, formations arise.” The method for finding ignorance, craving, clinging, formations and kamma was fully presented in the fifth method of dependent origination. The procedure for finding them is therefore not repeated here, and the text continues with the way of discerning. Take this pattern as a basis and discern as previously instructed in the sections on knowledge of discerning conditions, knowledge of arising and passing away, and the other knowledges.


<a id="M06-body-P072"></a>
## Ignorance conditions formations and the mind-door process
Miến / Burmese 72

Avijjāpaccayā saṅkhārā — due to the arising of ignorance, formations arise.

Discern with knowledge the round of kamma, the formations (kamma) generated and cultivated in a past life, arising due to the round of defilements, ignorance (craving and clinging) cultivated in that very past life. Due to the arising of ignorance, formations arise. Ignorance is the cause and formations are the effect. Discern causes and effects in that way. In the past, ignorance and formations generally arose in the following cognitive process.

Mind-door process.
Phenomenon | Mind-door adverting | Impulsion (7 times) | Registration (2 times)
Ignorance | 12 | 20 | 12/34/…
Formations | 12 | 34 | 34/12/…

Ignorance generally arises in a greed group associated with wrong view, with all twenty mental phenomena. Sometimes it arises with equanimous feeling and without joy, with nineteen. Sometimes with sloth and torpor there are twenty-two or twenty-one. These are four kinds of greed-rooted consciousness associated with wrong view. Sometimes it also occurs in the greed group with conceit, in the four kinds dissociated from wrong view. Registration may or may not occur. If it occurs when impulsion is associated with joy, registration is generally associated with joy too. When impulsion is dissociated from joy, registration is generally likewise dissociated from joy. Rooted or rootless registration may occur as appropriate. Understand the same for formations…


<a id="M06-body-P073"></a>
## Formations condition consciousness
Miến / Burmese 73

… Here human formations are singled out as the example. In those formations, knowledge and joy are associated as appropriate. As shown for the individual impulsion moments in the tables in the section on the meditation subject of mentality, the counts can be 34, 33, 33 or 32 as appropriate. Registration may or may not occur. When discerning with insight, see arising and passing away in each of the cognitive processes just shown on both the causal and the resultant sides, and discern them under the three characteristics. Let each compact mass break apart and let knowledge penetrate ultimate reality. Since the five-door processes cannot give rebirth-linking results and can only give results in the course of existence, only one mind-door process is presented here.

Saṅkhārapaccayā viññāṇaṃ — due to the arising of formations, resultant consciousness arises. (Abhidhamma, vol. 1, p. 116.)

In saying that formations arise due to ignorance and consciousness arises due to formations, the intended meaning is that the natural powers of ignorance and formations are present, the sense of atthi, “there is.” Ignorance and formations are generally separated by many consciousness moments and many cognitive processes. Sometimes ignorance and unwholesome formations also arise together and are associated in a single consciousness moment in the same process.

However, wholesome formations capable of producing wholesome resultant consciousness such as the rebirth-linking consciousness of people now alive can be separated from that result by many cognitive processes. Similarly, when resultant consciousnesses arise due to formations, the formations and the resultant consciousnesses…


<a id="M06-body-P074"></a>
## The power of formations and the arising of resultant consciousness
Miến / Burmese 74

… can be separated by a lifetime. Hence, when the effects manifest as arising, presence and dissolution (uppāda, ṭhiti, bhaṅga), the causes are no longer present as arising, present and dissolving. Ignorance and formations can still produce the results even when they are no longer present in that way. To say that the corresponding effects arise because ignorance and formations arose means these phenomena have the natural capacity to produce their corresponding effects, that is, “existence” in the sense of atthibhāva.

That natural capacity is precisely the kammic power of the group of wholesome formations surrounded by ignorance, craving and clinging. (This is said specifically with reference to humans.) The main point concerning that capacity is that kamma was generated and cultivated. Wholesome and unwholesome formations can act as causes of their respective effects because they have been generated and cultivated. Whether they are still present as arising, presence and dissolution is not the main point.

Kāmāvacaraṃ kusalaṃ kammaṃ katattā upacitattā vipākaṃ cakkhuviññāṇaṃ uppannaṃ hoti. (Abhidhamma, vol. 1, p. 104.) Because wholesome sense-sphere kamma has been done and accumulated, wholesome resultant eye-consciousness arises. (Abhidhamma, vol. 1, p. 104.)

Consciousness. Because formations, the generating and cultivating of present existence and existence in saṃsāra, have been present, the six kinds of resultant consciousness, eye-consciousness, ear-consciousness, nose-consciousness, tongue-consciousness, body-consciousness and mind-consciousness…


<a id="M06-body-P075"></a>
## The kinds of resultant consciousness to discern
Miến / Burmese 75

… all manifest.

Resultant consciousness and resultant mind-consciousness. The scope of resultant consciousness includes both the five kinds of sense-consciousness and resultant mind-consciousness. Resultant mind-consciousness comprises the process-free consciousnesses of rebirth-linking, life-continuum and death. It also comprises the within-process consciousnesses of receiving, investigating and resultant registration.

The five kinds of sense-consciousness, receiving, investigating and rootless registration each have wholesome-resultant and unwholesome-resultant varieties. Great resultant registration is only wholesome-resultant. The five kinds of sense-consciousness, receiving, investigating and registration that are wholesome or unwholesome results arise in the ordered sequence of consciousness called a process, according to the regularity of consciousness (cittaniyāma). Discern according to that sequence so that knowledge sees the causal relationship, discerns cause and effect, and develops insight.

In discernment by process, functional consciousnesses such as five-door adverting, determining and mind-door adverting, together with wholesome and unwholesome impulsions, also occur within the same cognitive processes as those resultant consciousnesses. Thus it is blameless to include the wholesome, unwholesome and functional consciousnesses in insight discernment so that none of the ultimate phenomena arising in the process is omitted.

When discerning the consciousnesses causally related to formations, take only the resultant consciousnesses specified above. Discern with knowledge the causal relationship between formations and resultant consciousnesses in all six series, from the visible-object series to the mental-object series, following the tables in the section on the meditation subject of mentality…


<a id="M06-body-P076"></a>
## Examples for discerning resultant consciousness outside a process and in the eye-door process
Miến / Burmese 76

… Discern so that knowledge sees clearly, identifying the causal and resultant phenomena in full. However, among the resultant consciousnesses of the five senses, receiving, investigating and registration, some may arise due to the kamma capable of producing rebirth-linking consciousness and some may not. Bear this in mind when discerning. In each series, discern all resultant consciousnesses in processes with wholesome and with unwholesome impulsions. Here only a few short patterns are given to illustrate the way of discerning cause and effect.

Examples of discernment — process-free consciousness.

1. Due to the arising of formations (= 34), rebirth-linking consciousness arises. Formations (= 34) are the cause and rebirth-linking consciousness is the effect.
2. Due to the arising of formations (= 34), life-continuum consciousness arises. Formations (= 34) are the cause and life-continuum consciousness is the effect.
3. Due to the arising of formations (= 34), death consciousness arises. Formations (= 34) are the cause and death consciousness is the effect.

Resultant consciousnesses in the eye-door process.

1. Due to the arising of formations (= 34), eye-consciousness arises. Formations (= 34) are the cause and eye-consciousness is the effect.
2. Due to the arising of formations (= 34), receiving consciousness arises. Formations (= 34) are the cause and receiving consciousness is the effect.
3. Due to the arising of formations (= 34), investigating consciousness arises. Formations (= 34) are the cause and investigating consciousness is the effect.


<a id="M06-body-P077"></a>
## Resultant consciousness in the six series, and consciousness conditioning mentality-materiality
Miến / Burmese 77

4. Due to the arising of formations (= 34), registration consciousness arises. Formations (= 34) are the cause and registration consciousness is the effect.

«Note. When discerning registration, discern the two occurrences in the eye-door process and the two occurrences in the mind-door process that takes that same visible object. In the eye-door process, as shown in the tables in the section on the meditation subject of mentality, discern all resultant consciousnesses in every row. Discern all processes with wholesome impulsions and all processes with unwholesome impulsions.

In the sound series, discern ear-consciousness, receiving, investigating and resultant registration. In the odour series, discern nose-consciousness, receiving, investigating and resultant registration. In the taste series, discern tongue-consciousness, receiving, investigating and resultant registration. In the tangible-object series, discern body-consciousness, receiving, investigating and resultant registration. In the mental-object series, discern the resultant registration consciousnesses. Following this pattern, discern them all.

At the insight stage, the five-door adverting at the beginning of a five-door process, the mind-door adverting at the beginning of a mind-door process, and the determining consciousness and impulsions in the middle of the processes containing those resultant consciousnesses may also be included. Including them so as not to omit any ultimate phenomena is blameless.»

Viññāṇapaccayā nāmarūpaṃ — with consciousness as condition, mentality-materiality.

Yaṃ nāmarūpaṃ hetu viññāṇaṃ, taṃ vipākāvipākabhedato dvidhā mataṃ. (Abhidhamma Commentary, vol. 2, p. 163. Visuddhimagga, vol. 2, p. 194.) Due to the arising of consciousness, mentality-materiality arises.


<a id="M06-body-P078"></a>
## Resultant and non-resultant consciousness, and three kinds of conditioning consciousness
Miến / Burmese 78

Here consciousness as a cause of mentality-materiality is of two kinds: (1) resultant consciousness and (2) non-resultant consciousness. Rebirth-linking, life-continuum, death, the five kinds of sense-consciousness, receiving, investigating and registration are resultant consciousnesses. Wholesome, unwholesome and functional consciousnesses are non-resultant. Wholesome and unwholesome consciousness are called formative consciousness (abhisaṅkhāraviññāṇa), or kamma-consciousness (kammaviññāṇa), because they fashion new existence in various ways. (Abhidhamma Commentary, vol. 2, p. 163. Visuddhimagga, vol. 2, p. 195. Mahāṭīkā, vol. 2, p. 319.)

In another classification, resultant and non-resultant consciousnesses are called kamma-consciousness, conascent consciousness and postnascent consciousness. (Mūlaṭīkā, vol. 2, p. 115.)

The wholesome and unwholesome consciousnesses termed meritorious, demeritorious and imperturbable formations, generated and cultivated in past lives in saṃsāra, are called kamma-consciousness.

The wholesome, unwholesome, resultant and functional consciousnesses arising from rebirth-linking throughout a life, capable of producing mentality as mental factors and consciousness-born materiality, and arising at the same time as the mentality-materiality that is their effect, are termed conascent consciousness because cause and effect arise simultaneously. Of these, the five pairs of sense-consciousness are conascent consciousnesses that can produce only mentality as mental factors and cannot produce consciousness-born materiality.

The wholesome, unwholesome, resultant and functional consciousnesses that support the material phenomena that arose together with earlier consciousnesses, sustaining them firmly until the end of their life span by the power of postnascence condition (pacchājātapaccaya)…


<a id="M06-body-P079"></a>
## Kamma-consciousness is formative consciousness
Miến / Burmese 79

… are called postnascent consciousness. Kamma-consciousness and postnascent consciousness are also called non-conascent consciousness because their causes and effects do not arise simultaneously. Since the example for discerning kamma-consciousness follows on from the section on formations, it is presented first.

Kamma-consciousness is formative consciousness. Wholesome or unwholesome consciousness associated with formative kamma generated and cultivated in a past life is called kamma-consciousness. In particular, the consciousness included in the causal group of thirty-four mental phenomena of formations shown above under “formations condition consciousness” is also called kamma-consciousness, or formative consciousness. In this section give priority to discerning kamma-consciousness, that is, formative consciousness.

Wholesome or unwholesome consciousness arising together and associated in one consciousness moment with present formative kamma being generated and cultivated with a future life in view is also kamma-consciousness, or formative consciousness.

One can discern cause and effect with direct knowledge and develop insight in both cases: (1) past kamma-consciousness produces present resultant rebirth-linking mentality-materiality, namely resultant consciousness, mental factors and kamma-born materiality; (2) present kamma-consciousness produces future resultant rebirth-linking mentality-materiality, called birth, namely resultant consciousness, mental factors and kamma-born materiality. This section, however, teaches discernment with direct knowledge of present resultant mentality-materiality arising due to past kamma-consciousness.


<a id="M06-body-P080"></a>
## Resultant mentality-materiality and process-free examples
Miến / Burmese 80

Mentality and materiality. When only kamma-consciousness is taken as consciousness on the causal side, as above, on the resultant side the mentality in resultant mentality-materiality includes both the group of mental factors and the corresponding resultant consciousness. This is because only past kamma-consciousness is taken as causal consciousness, and because that resultant consciousness manifests due to that very past kamma-consciousness.

As for materiality, take directly only kamma-born materiality. Yet since these kinds of materiality are inseparable in terms of avinābhāva, there is no fault in discerning with insight also the consciousness-born, temperature-born and nutriment-born materiality seen along with kamma-born materiality. When discerning cause and effect specifically, discern only the causal relationship with kamma-born materiality. According to this explanation the way of discerning is as follows.

Some examples of discernment.

1. Due to the arising of past kamma-consciousness, rebirth-linking mentality-materiality arises. Past kamma-consciousness is the cause and rebirth-linking mentality-materiality is the effect.
2. Due to the arising of past kamma-consciousness, life-continuum mentality-materiality arises. Past kamma-consciousness is the cause and life-continuum mentality-materiality is the effect.
3. Due to the arising of past kamma-consciousness, death mentality-materiality arises. Past kamma-consciousness is the cause and death mentality-materiality is the effect.


<a id="M06-body-P081"></a>
## Resultant mentality-materiality in the eye-door process
Miến / Burmese 81

1. Due to the arising of past kamma-consciousness, eye-consciousness mentality-materiality arises. Past kamma-consciousness is the cause and eye-consciousness mentality-materiality is the effect.
2. Due to the arising of past kamma-consciousness, receiving mentality-materiality arises. Past kamma-consciousness is the cause and receiving mentality-materiality is the effect.
3. Due to the arising of past kamma-consciousness, investigating mentality-materiality arises. Past kamma-consciousness is the cause and investigating mentality-materiality is the effect.
4. Due to the arising of past kamma-consciousness, registration mentality-materiality arises. Past kamma-consciousness is the cause and registration mentality-materiality is the effect.

«Note. Follow the pattern to discern the arising of resultant mentality-materiality in ear-consciousness, receiving, investigating, registration and the remaining cases. When developing insight, it is blameless to include adverting, determining and impulsions. When discerning cause and effect specifically, discern so that knowledge clearly sees the causal relationship between past kamma-consciousness and resultant mentality-materiality. Discern all six series in full. In each series discern all resultant mentality-materiality in every row.»

Formations and kamma-becoming are kamma.

As explained in the section on the fifth method of dependent origination, when discerning cause and effect, resultant mental phenomena and kamma-born materiality arise due to the kammic power of formations generated and cultivated while surrounded by ignorance, craving and clinging. That power is the power of kamma of a different moment (nānakkhaṇikakamma)…


<a id="M06-body-P082"></a>
## Accumulating formations and kamma-becoming
Miến / Burmese 82

… Discern with knowledge how kamma-born materiality and resultant mental phenomena arise, and discern the causes and effects. In developing insight, the kammic power itself cannot be subjected to the three characteristics for discernment. Thus give particular attention to formations and kamma-becoming, that is, kamma, which can be discerned with insight.

Āyūhanā saṅkhārāti taṃ kammaṃ karoto purimacetanāyo. Yathā “dānaṃ dassāmī”ti cittaṃ uppādetvā māsampi saṃvaccharampi dānūpakaraṇāni sajjentassa uppannā purimacetanāyo. Paṭiggāhakānaṃ pana hatthe dakkhiṇaṃ patiṭṭhāpayato cetanā bhavoti vuccati. Ekāvajjanesu vā chasu javanesu cetanā āyūhanasaṅkhārā nāma, sattamā cetanā bhavo. Yā kāci vā pana cetanā bhavo, taṃsampayuttā āyūhanasaṅkhārā nāma. (Abhidhamma Commentary, vol. 2, pp. 182–183.)

1. Accumulating formations are the prior volitions (purimacetanā, also called pubbacetanā) that arise while one is generating and cultivating that kamma before the deed is complete. For example, one forms the intention “I will give a gift” and spends a month or a year preparing the gift and the requisites for giving. The volitions arising in that person’s continuity during preparation are called prior volitions. The volition when placing the gift in the recipient’s hand is called kamma-becoming.

2. Alternatively, while generating and cultivating a good or bad deed, many wholesome or unwholesome impulsion processes occur. Each impulsion process includes one adverting consciousness. Among the seven impulsions in each of those processes with one adverting consciousness…


<a id="M06-body-P083"></a>
## Distinguishing formations and kamma-becoming. Examples of conascent consciousness
Miến / Burmese 83

… volition associated with the first six impulsions is called formation. Volition associated with the seventh impulsion is called kamma-becoming.

3. Alternatively, in each impulsion moment the associated phenomena, consciousness and mental factors accompanying wholesome or unwholesome volition, are called formations. Any wholesome or unwholesome volition is called kamma-becoming.

According to these distinctions, discern fully with insight every ultimate phenomenon in each moment of the mind-door processes headed by ignorance, craving and clinging and those comprising formations and kamma. When discerned in this way, both formations and kamma-becoming have been discerned with insight. Thus subject formations and kamma-becoming, that is, kamma, to the three characteristics according to these distinctions.

Remember that kammic power itself, called the power of kamma of a different moment and treated under kamma condition, cannot be discerned with insight. The formations and kamma-becoming just described are the source of that power and can be discerned with insight.

Conascent mentality-materiality arising due to conascent consciousness.

1. Due to the arising of rebirth-linking consciousness, rebirth-linking mentality-materiality arises. Rebirth-linking consciousness is the cause and rebirth-linking mentality-materiality is the effect. Mentality is the thirty-three mental factors associated with rebirth-linking consciousness. Materiality is the thirty kamma-born material phenomena.

2. Due to the arising of life-continuum consciousness, life-continuum mentality-materiality arises. Life-continuum consciousness is the cause and life-continuum mentality-materiality is the effect.


<a id="M06-body-P084"></a>
## How to take conascent mentality-materiality and consciousness within a process
Miến / Burmese 84

«Note. For mentality, take only the mental factors arising together and associated with the relevant life-continuum consciousness in one consciousness moment. For materiality, take as primary the consciousness-born materiality produced by that life-continuum consciousness. Discern in this way. At the insight stage, it is blameless to include kamma-born, temperature-born and nutriment-born materiality arising or persisting simultaneously with that consciousness-born materiality. In discerning cause and effect, see the causal connection between the relevant consciousness and consciousness-born materiality, and discern the causes and effects. Understand similarly for consciousnesses within a process.

Among consciousnesses within a process, resultant consciousness means only the five kinds of sense-consciousness, receiving, investigating and resultant registration. Conascent consciousness includes not only resultant consciousness but also five-door adverting, determining, impulsion and mind-door adverting, that is, the corresponding functional and impulsion consciousnesses.

Among the factors of dependent origination, consciousness, mentality-materiality, the six bases, contact and feeling are only resultant phenomena according to the discourse method. (Mahāṭīkā, vol. 2, p. 323.) Yet among these results, the five kinds of sense-consciousness, receiving and investigating cannot arise without five-door adverting, and registration cannot arise without impulsion. Therefore, to omit no ultimate phenomenon, it is possible to include five-door adverting, determining, impulsion and mind-door adverting, even when discerning cause and effect. There is no fault if one understands that those consciousnesses are not part of the round of results. As to whether death consciousness produces consciousness-born materiality, the treatises offer differing accounts.»


<a id="M06-body-P085"></a>
## Death consciousness, five-door adverting and sense-consciousness
Miến / Burmese 85

3. Due to the arising of death consciousness, death mentality (+ materiality) arises. Death consciousness is the cause and death mentality (+ materiality) is the effect.

• Due to the arising of five-door adverting consciousness, five-door adverting mentality + materiality arises. Five-door adverting consciousness is the cause and five-door adverting mentality + materiality is the effect.

4. Due to the arising of eye-consciousness, its mentality arises. Eye-consciousness is the cause and eye-consciousness mentality is the effect. Mentality consists of the seven associated mental factors. Alternatively, due to the arising of eye-consciousness, mentality + materiality at eye-consciousness arises. Eye-consciousness is the cause and mentality + materiality at eye-consciousness is the effect.

«Discern in the same way with ear-, nose-, tongue- and body-consciousness. Mentality consists of the seven associated mental factors. As to materiality, because the five kinds of sense-consciousness such as eye-consciousness do not produce consciousness-born materiality, take the kamma-born materiality present at the moment of eye-consciousness or the relevant sense-consciousness as materiality. Take that kamma-born materiality as the primary object of discernment. In insight discernment there is no fault in including kamma-born, temperature-born and nutriment-born materiality then arising and consciousness-born materiality produced by preceding consciousnesses and then at the stage of presence. Understand the same in each case.»

5. Due to the arising of receiving consciousness, receiving mentality + materiality arises…


<a id="M06-body-P086"></a>
## Mentality-materiality of receiving through registration
Miến / Burmese 86

… Receiving consciousness is the cause and receiving mentality + materiality is the effect.

«Mentality consists of the ten mental factors associated with receiving consciousness. Materiality is the consciousness-born materiality produced by receiving. At the insight stage, it is blameless to include kamma-born, temperature-born and nutriment-born materiality arising in the three submoments of receiving consciousness. In later consciousnesses in the process, such as investigating, take the associated mental factors as mentality as appropriate. Understand the way of taking materiality similarly.»

6. Due to the arising of investigating consciousness, investigating mentality + materiality arises. Investigating consciousness is the cause and investigating mentality + materiality is the effect.

• Due to the arising of determining consciousness, determining mentality + materiality arises. Determining consciousness is the cause and determining mentality + materiality is the effect.

• Due to the arising of impulsion consciousness, impulsion mentality + materiality arises. Impulsion consciousness is the cause and impulsion mentality + materiality is the effect.

7. Due to the arising of registration consciousness, registration mentality + materiality arises. Registration consciousness is the cause and registration mentality + materiality is the effect.

• Due to the arising of mind-door adverting consciousness, mind-door adverting mentality + materiality arises. Mind-door adverting consciousness is the cause and mind-door adverting mentality + materiality is the effect.


<a id="M06-body-P087"></a>
## Supporting passages and five cases of mentality-materiality conditioning the six bases
Miến / Burmese 87

Understand similarly for impulsion and registration. Discern each consciousness moment in full as presented in the tables in the section on the meditation subject of mentality. The passages in the texts supporting these patterns of discernment are as follows:

Nāmarūpassa yaṃ hetu, viññāṇaṃ taṃ dvidhā mataṃ.
Vipākamavipākañca, yuttameva yato idaṃ. (Abhidhamma Commentary, vol. 2, p. 163.)

Sahajātaviññāṇapaccayā nāmarūpaṃ, kammaviññāṇapaccayā ca nāmarūpaṃ yathāsambhavaṃ yojetabbaṃ. (Mūlaṭīkā, vol. 2, p. 115.)

Kammaviññāṇapaccayā vipākacittappavattikāle vipākanāmañca kammasamuṭṭhānarūpañca vasena. Sahajātaviññāṇapaccayā pana itaracittappavattikālepi vipāke vipākanāmavasena, cittasamuṭṭhānarūpavasena ca nāmarūpassa sambhavo dassetabboti āha “sahajāta, pe, yojetabban”ti. (Anuṭīkā, vol. 2, p. 128.)

Nāmarūpapaccayā saḷāyatanaṃ — due to the arising of mentality-materiality, the six bases arise.

This section has five cases: (a) the arising of mentality gives rise to the mind base, (b) the arising of mentality gives rise to the material bases, (c) the arising of materiality gives rise to the material bases, (d) the arising of materiality gives rise to the mind base, and (e) the arising of mentality and materiality gives rise to the mind base.


<a id="M06-body-P088"></a>
## How mentality conditions the mind base
Miến / Burmese 88

(a) How mentality supports the mind base. Due to the arising of mentality, the mind base arises.

Here, for mentality take only the mental factors associated with the relevant mind base. This section concerns how mentality in the form of mental factors supports its associated consciousness, the mind base.

1. Due to the arising of rebirth-linking mentality (= 33), rebirth-linking mind base arises. Rebirth-linking mentality (= 33) is the cause and rebirth-linking mind base is the effect.

2. Due to the arising of life-continuum mentality (= 33), life-continuum mind base arises. Life-continuum mentality (= 33) is the cause and life-continuum mind base is the effect.

3. Due to the arising of death mentality (= 33), death mind base arises. Death mentality (= 33) is the cause and death mind base is the effect.

«Here three-rooted rebirth-linking, life-continuum and death are presented as examples.»

• Due to the arising of five-door adverting mentality (= 10), five-door adverting mind base arises. Five-door adverting mentality (= 10) is the cause and five-door adverting mind base is the effect.

4. Due to the arising of eye-consciousness mentality (= 7), the eye-consciousness mind base arises. Eye-consciousness mentality (= 7) is the cause, and the eye-consciousness mind base…


<a id="M06-body-P089"></a>
## The mind base from receiving to mind-door adverting
Miến / Burmese 89

… is the effect.

5. Due to the arising of receiving mentality (= 10), receiving mind base arises. Receiving mentality (= 10) is the cause and receiving mind base is the effect.

6. Due to the arising of investigating mentality (= 11), investigating mind base arises. Investigating mentality (= 11) is the cause and investigating mind base is the effect.

• Due to the arising of determining mentality (= 11), determining mind base arises. Determining mentality (= 11) is the cause and determining mind base is the effect.

• Due to the arising of impulsion mentality (= ), impulsion mind base arises. Impulsion mentality (= ) is the cause and impulsion mind base is the effect.

7. Due to the arising of registration mentality (= ), registration mind base arises. Registration mentality (= ) is the cause and registration mind base is the effect.

• Due to the arising of mind-door adverting mentality (= 11), mind-door adverting mind base arises. Mind-door adverting mentality (= 11) is the cause and mind-door adverting mind base is the effect.

«See the tables in the section on the meditation subject of mentality to understand how to take the associated mental factors as mentality at investigating, impulsion and registration. As for the good group with wholesome impulsions…


<a id="M06-body-P090"></a>
## Mentality conditioning the mind base and the material bases
Miến / Burmese 90

… and the bad group with unwholesome impulsions, discern them in full. Discern all six doors. In discerning thus, one may leave out five-door adverting, determining, impulsion and mind-door adverting, as they do not belong to the round of results. Yet there is no fault in including them so as to omit no ultimate phenomena, provided one understands that they are outside the round of results. Discern the ear-door and the other cognitive processes following the same pattern.

Also note that in the planes of five aggregates those mental phenomena, the mental factors, can support their associated consciousness, the mind base, in arising only when there is the corresponding material base as a support, such as the heart-base.»

(b) Due to the arising of mentality, the material bases arise.

Pacchājātā cittacetasikā dhammā purejātassa imassa kāyassa pacchājātapaccayena paccayo. (Paṭṭhāna, vol. 1, p. 7.)

That is, the group of mental phenomena comprising eighty-five consciousnesses, excluding the four immaterial resultant consciousnesses, and fifty-two mental factors, arising later, supports the material body produced by four sources that arose at the preceding consciousness moment in that same continuity, by the power of postnascence condition. (Paṭṭhāna, vol. 1, p. 7.)

According to that teaching, when mentality consisting of consciousness and mental factors supports the material bases, understand that the material effect arises earlier and the mental cause arises later. Generally, except at rebirth-linking, the resultant material phenomena arise with the earlier consciousness moment, while the causal mentality is the group of mental phenomena in the subsequent consciousness moment.


<a id="M06-body-P091"></a>
## Cases of postnascence condition
Miến / Burmese 91

Therefore first remember the following outline.

1. The mental aggregates of the first life-continuum, as the conditioning phenomena, support by postnascence condition the body produced by one source, namely kamma-born materiality, that arose with the rebirth-linking mental aggregates and has reached presence. Alternatively, they support the body produced by two sources, kamma and temperature.

2. Subsequent life-continuum mental aggregates, beginning with the second life-continuum, support by postnascence condition the body produced by three sources, namely materiality born of kamma, consciousness and temperature, which arose with the earlier life-continuum mental aggregates beginning with the first life-continuum and has reached presence.

3. Once nutriment-born materiality has arisen, the later mental aggregates of consciousness and mental factors support by postnascence condition the body produced by four sources, namely materiality born of kamma, consciousness, temperature and nutriment, which arose together with earlier consciousness and has reached presence.

4. In the continuity of a sense-sphere being, the subsequent mental aggregates of adverting support by postnascence condition the body produced by four sources, namely materiality born of kamma, consciousness, temperature and nutriment, which arose with the fifteenth life-continuum consciousness after rebirth-linking and has reached presence. (In the continuity of a fine-material-sphere being, the later mental aggregates of adverting support by postnascence condition the body produced by three sources, kamma, consciousness and temperature.)

5. For the body produced by four sources (or three), which arose with five-door adverting and has reached presence, the mental aggregates of the subsequent sense-consciousness…


<a id="M06-body-P092"></a>
## Postnascence condition and the supporting characteristic
Miến / Burmese 92

… support it by the power of postnascence condition.

6. The later mental aggregates of receiving support by postnascence condition the body that arose with sense-consciousness and has reached presence. In the fine-material sphere this is a body produced by two sources, kamma and temperature. In the sense sphere it is a body produced by three sources, kamma, temperature and nutriment.

7. The later mental aggregates of investigating support by postnascence condition the body that arose with the mental aggregates of receiving and has reached presence. In the fine-material sphere it is a body produced by three sources, kamma, consciousness and temperature. In the sense sphere it is a body produced by four sources, kamma, consciousness, temperature and nutriment.

«Following this pattern, later groups of mental aggregates consisting of consciousness and mental factors support by postnascence condition the materiality produced by four sources that arose together with earlier consciousnesses.»

The supporting characteristic (upatthambhakasabhāva).

Purejātānaṃ rūpadhammānaṃ upatthambhakatthe upakārako arūpadhammo pacchājātapaccayo, gijjhapotakasarīrānaṃ āhārāsācetanā viya. (Visuddhimagga, vol. 2, p. 169.)

When the mother vulture flies off to find food, the chicks expect, “When mother comes back, we will eat.” That expectation is craving and desire for food. The volition associated with that longing is mental volition as nutriment (manosañcetanāhāra). That nutriment is present in the chicks’ bodies at that time. The present volition hoping for food supports by postnascence condition the continuity of materiality produced by four sources that arose earlier and is at the stage of presence…


<a id="M06-body-P093"></a>
## Later mentality sustains earlier materiality
Miến / Burmese 93

… so the chicks’ bodies can persist without breaking down.

Just as in that example, trace back from the group of mental phenomena at the consciousness moment capable of acting as a condition in the continuity of a sense-sphere or fine-material-sphere being. The groups of mental phenomena in later consciousness moments support the material body produced by four or three sources that arose together with earlier consciousness moments and reached presence. They assist by the power of sustenance (upatthambhaka), enabling those material phenomena to remain firm and persist until dissolution. The mental group that can assist through this sustenance is called the postnascence condition. In postnascence condition the cause is mentality that arises later and the effect is materiality that arose together with an earlier consciousness moment. Of cause and effect, the cause arises later and the effect earlier.

In this account of material bases arising due to mentality, take both consciousness and mental factors of the relevant later consciousness moment on the causal side. On the resultant side, take the eye, ear, nose, tongue and body bases that can act as effects, that arose with the earlier consciousness moment and have reached presence when the relevant later causal consciousness arises. All five material bases can arise at the stages of arising, presence and dissolution of each consciousness moment, as long as the force of kamma…


<a id="M06-body-P094"></a>
## A pattern for discerning the eye base separately
Miến / Burmese 94

… is not exhausted. To avoid confusion in understanding, one may discern separately or together. One pattern of discerning separately is presented here.

1. Due to the arising of vibrating life-continuum mentality, the eye base arises. Vibrating life-continuum mentality is the cause and the eye base is the effect.

(This is the eye base that arose together with the past life-continuum.)

2. Due to the arising of arrested life-continuum mentality, the eye base arises. Arrested life-continuum mentality is the cause and the eye base is the effect.

(This is the eye base that arose together with the vibrating life-continuum.)

3. Due to the arising of five-door adverting mentality, the eye base arises. Five-door adverting mentality is the cause and the eye base is the effect.

(This is the eye base that arose together with the arrested life-continuum.)

4. Due to the arising of eye-consciousness mentality, the eye base arises. Eye-consciousness mentality is the cause and the eye base is the effect.

(This is the eye base that arose together with five-door adverting. Discern similarly for ear-consciousness mentality and the remaining cases.)

5. Due to the arising of receiving mentality, the eye base arises. Receiving mentality is the cause and the eye base is the effect.

(This is the eye base that arose together with eye-consciousness, or with one of the five kinds of sense-consciousness in the relevant case.)


<a id="M06-body-P095"></a>
## A pattern for discerning the eye base separately, continued
Miến / Burmese 95

6. Due to the arising of investigating mentality, the eye base arises. Investigating mentality is the cause and the eye base is the effect.

(This is the eye base that arose together with receiving.)

7. Due to the arising of determining mentality, the eye base arises. Determining mentality is the cause and the eye base is the effect.

(This is the eye base that arose together with investigating.)

8. Due to the arising of first impulsion mentality, the eye base arises. First impulsion mentality is the cause and the eye base is the effect.

(This is the eye base that arose together with determining.)

9. Due to the arising of second impulsion mentality, the eye base arises. Second impulsion mentality is the cause and the eye base is the effect.

(This is the eye base that arose together with the first impulsion.)

Understand in this way how later groups of consciousness and mental factors support the eye base that arose with earlier consciousnesses. Following the tables in the section on the meditation subject of mentality, discern each consciousness moment in all six types of process, beginning with the eye-door process. Discern the ear base and other bases in the same way. If wishing to discern all five material bases together, beginning with the eye base, discern as follows.


<a id="M06-body-P096"></a>
## A pattern for discerning the five material bases together
Miến / Burmese 96

1. Due to the arising of vibrating life-continuum mentality, the five material bases arises. Vibrating life-continuum mentality is the cause and the five material bases is the effect.

(These are the eye, ear, nose, tongue and body bases that arose together with the past life-continuum.)

2. Due to the arising of arrested life-continuum mentality, the five material bases arises. Arrested life-continuum mentality is the cause and the five material bases is the effect.

(These are the five material bases that arose together with the vibrating life-continuum.)

3. Due to the arising of five-door adverting mentality, the five material bases arises. Five-door adverting mentality is the cause and the five material bases is the effect.

(These are the five material bases that arose together with the arrested life-continuum.)

4. Due to the arising of eye-consciousness mentality, the five material bases arises. Eye-consciousness mentality is the cause and the five material bases is the effect.

(These are the five material bases that arose together with five-door adverting.)

In this way, regarding the material bases that arose together with earlier consciousnesses…


<a id="M06-body-P097"></a>
## Materiality conditioning a material base within the same group
Miến / Burmese 97

… understand how later groups of consciousness and mental factors support the five material bases by postnascence condition. Discern each consciousness moment fully at all six doors.

(c) Due to the arising of materiality, the material bases arise. This section explains how materiality included in conditioning mentality-materiality supports the material bases included in the six bases.

(1) In the eye decad (cakkhudasakakalāpa):

(a) Due to the arising of the four great elements of the same group, the eye base of the same group arises. The four great elements of the same group is the cause and the eye base of the same group is the effect.

(b) Due to the arising of the material life faculty of the same group, the eye base of the same group arises. The material life faculty of the same group is the cause and the eye base of the same group is the effect.

(c) Due to the arising of the nutritive essence of the same group, the eye base of the same group arises. The nutritive essence of the same group is the cause and the eye base of the same group is the effect.

Continue to discern in the same way how (a) the four great elements, (b) the material life faculty and (c) nutritive essence in each respective group support the ear, nose, tongue and body bases. The great elements in a group support the material base in that group by the power of sustenance. The material life faculty in the same group supports by the power of maintenance…


<a id="M06-body-P098"></a>
## Nutriment supporting the material bases, and materiality supporting the mind base
Miến / Burmese 98

… and the nutritive essence in the same group supports by the power of sustenance. Understand that this nutritive essence can support the material base in the same group only when aided by the kamma-born digestive fire and nutriment-born nutritive essence.

As explained in the section on the meditation subject of materiality, the nutritive essence in temperature-born materiality containing nutritive essence, namely edible food (kabaḷīkārāhāra) normally chewed, swallowed and eaten, produces further new material groups containing nutritive essence when supported by the kamma-born digestive fire. Because those material phenomena arise from nutritive essence, they are called nutriment-born materiality.

When nutriment-born nutritive essence in that materiality, with the assistance of the kamma-born digestive fire, in turn supports nutritive essence born of kamma, consciousness or temperature and nutriment-born nutritive essence in other groups, those respective kinds of nutritive essence produce new material groups. In this way material bases such as the eye base are firmly sustained. The nutritive essence thus supported includes kamma-born nutritive essence in kamma-born groups such as the eye decad. Discern those natures with knowledge and discern according to the patterns above. Discern likewise for the ear base, pe, the body base.

(d) Due to the arising of materiality, the mind base arises. In the planes of five aggregates (pañcavokārabhūmi), which include the human plane, the respective groups of mental phenomena can arise only when a material base supports them. Without that supporting material base, they cannot arise. See this nature with knowledge and then discern according to the examples below. Further, when the mind base…


<a id="M06-body-P099"></a>
## The material bases on which the mind base depends
Miến / Burmese 99

… that is, consciousness, arises, there are also inseparable associated mental factors. Those mental factors can arise together with the mind base only by depending on the relevant material base. Thus it is blameless to include the associated mental factors while taking the mind base as primary.

Among these, the five kinds of sense-consciousness are mind bases arising only in dependence on the respective material bases such as the eye-base. They depend on the respective material bases such as the eye-base that arose simultaneously with the past life-continuum. Rebirth-linking consciousness, a mind base, arises in dependence on the heart-base arising together with it. Death consciousness as mind base depends on the heart-base that arose with the seventeenth consciousness counting back from death. Generally, later life-continuum consciousnesses arise in dependence on heart-base materiality that arose with the preceding consciousnesses.

Similarly, the mind bases called mind element and mind-consciousness element, apart from the five kinds of sense-consciousness, arise in dependence on the heart-base that arose with their preceding consciousness moment. At the insight stage, however, in terms of the method of inseparability (avinābhāva), it is blameless to include the materiality born of four sources arising with the supporting material bases such as the eye- and heart-bases, such as groups of fifty-four or forty-four material phenomena.

Some examples of discernment.

1. Due to the arising of the heart-base supporting rebirth-linking, the rebirth-linking mind base arises. The heart-base supporting rebirth-linking is the cause and the rebirth-linking mind base is the effect.


<a id="M06-body-P100"></a>
## Examples of material bases and the mind base, from life-continuum to receiving
Miến / Burmese 100

2. Due to the arising of the heart-base supporting life-continuum, the life-continuum mind base arises. The heart-base supporting life-continuum is the cause and the life-continuum mind base is the effect.

(This is the heart-base that arose together with the consciousness moment preceding the life-continuum being discerned.)

3. Due to the arising of the heart-base supporting death consciousness, the death mind base arises. The heart-base supporting death consciousness is the cause and the death mind base is the effect.

(This is the heart-base that arose with the seventeenth consciousness counting back from death consciousness.)

4. Due to the arising of heart-base materiality, the five-door adverting mind base arises. Heart-base materiality is the cause and the five-door adverting mind base is the effect.

(This is the heart-base materiality that arose simultaneously with the arrested life-continuum.)

5. Due to the arising of eye-base materiality, the eye-consciousness mind base arises. Eye-base materiality is the cause and the eye-consciousness mind base is the effect.

(This is the eye-base materiality in the middle of its life span, which arose simultaneously with the past life-continuum.)

6. Due to the arising of heart-base materiality, the receiving mind base arises. Heart-base materiality is the cause and the receiving mind base is the effect.

(This is the heart-base materiality that arose with eye-consciousness or with the relevant sense-consciousness.)


<a id="M06-body-P101"></a>
## Examples of material bases and the mind base, from investigating to registration
Miến / Burmese 101

7. Due to the arising of heart-base materiality, the investigating mind base arises. Heart-base materiality is the cause and the investigating mind base is the effect.

(This is the heart-base materiality that arose with receiving.)

8. Due to the arising of heart-base materiality, the determining mind base arises. Heart-base materiality is the cause and the determining mind base is the effect.

(This is the heart-base materiality that arose with investigating.)

9. Due to the arising of heart-base materiality, the first impulsion mind base arises. Heart-base materiality is the cause and the first impulsion mind base is the effect.

(This is the heart-base materiality that arose with determining.)

10. Due to the arising of heart-base materiality, the second impulsion mind base arises. Heart-base materiality is the cause and the second impulsion mind base is the effect.

(This is the heart-base materiality that arose with the first impulsion.) pe.

11. Due to the arising of heart-base materiality, the first registration mind base arises. Heart-base materiality is the cause and the first registration mind base is the effect.

(This is the heart-base materiality that arose with the seventh impulsion. Understand this as a general account.)

12. Due to the arising of heart-base materiality, the second registration mind base arises. Heart-base materiality is the cause and the second registration mind base is the effect.

(This is the heart-base materiality that arose with the first registration.)


<a id="M06-body-P102"></a>
## Mentality and materiality jointly conditioning the mind base
Miến / Burmese 102

13. Due to the arising of heart-base materiality, the mind-door adverting mind base arises. Heart-base materiality is the cause and the mind-door adverting mind base is the effect.

(This is the heart-base materiality that arose with the immediately preceding life-continuum, the arrested life-continuum.)

These examples suffice as a pattern. Discern each consciousness moment in a process according to the tables in the section on the meditation subject of mentality. Discern all six doors. At each door discern all processes with wholesome and unwholesome impulsions.

(e) Due to the arising of mentality-materiality, the mind base arises.

For mentality, take only the mental factors associated with the relevant consciousness. For materiality, following the explanation above, take as primary the respective material base supporting that group of mental phenomena in that consciousness moment, and also take the material phenomena inseparable from it, such as groups of fifty-four or forty-four material phenomena. Discern the following examples so that knowledge sees how that mentality and materiality support the relevant consciousness, the mind base.

The causal mentality, the mental factors, and the resultant mind base are associated phenomena arising together in one consciousness moment. The supporting material base generally arises before the resultant mind base, as explained above. At rebirth-linking, that material base is conascent.


<a id="M06-body-P103"></a>
## Examples of mentality-materiality conditioning the mind base
Miến / Burmese 103

1. Due to the arising of rebirth-linking mentality-materiality, the rebirth-linking mind base arises. Rebirth-linking mentality-materiality is the cause and the rebirth-linking mind base is the effect.

2. Due to the arising of life-continuum mentality-materiality, the life-continuum mind base arises. Life-continuum mentality-materiality is the cause and the life-continuum mind base is the effect.

(Discern death consciousness according to a similar pattern.)

3. Due to the arising of five-door adverting mentality-materiality, the five-door adverting mind base arises. Five-door adverting mentality-materiality is the cause and the five-door adverting mind base is the effect.

4. Due to the arising of eye-consciousness mentality-materiality, the eye-consciousness mind base arises. Eye-consciousness mentality-materiality is the cause and the eye-consciousness mind base is the effect.

5. Due to the arising of receiving mentality-materiality, the receiving mind base arises. Receiving mentality-materiality is the cause and the receiving mind base is the effect.

6. Due to the arising of investigating mentality-materiality, the investigating mind base arises. Investigating mentality-materiality is the cause and the investigating mind base is the effect.

7. Due to the arising of determining mentality-materiality, the determining mind base arises. Determining mentality-materiality is the cause and the determining mind base is the effect.


<a id="M06-body-P104"></a>
## Applying the pattern to the six kinds of cognitive process
Miến / Burmese 104

8. Due to the arising of first impulsion mentality-materiality, the first impulsion mind base arises. First impulsion mentality-materiality is the cause and the first impulsion mind base is the effect.

(Discern the second and later impulsions by following this pattern.)

9. Due to the arising of first registration mentality-materiality, the first registration mind base arises. First registration mentality-materiality is the cause and the first registration mind base is the effect.

(Discern the second registration by following this pattern.)

10. Due to the arising of mind-door adverting mentality-materiality, the mind-door adverting mind base arises. Mind-door adverting mentality-materiality is the cause and the mind-door adverting mind base is the effect.

Examples for practising this method of discernment.

«In the eye-door and mind-door processes that take visible form as object, discern each consciousness moment according to the tables in the section on the meditation subject of mentality. Discern in the same way the sequence of ear-door consciousnesses taking sound as object, and the remaining processes. In all six kinds of process, discern all processes with wholesome and unwholesome impulsions. Five-door adverting, determining, impulsion and mind-door adverting are included to leave no ultimate phenomenon out.»


<a id="M06-body-P105"></a>
## The six bases condition contact
Miến / Burmese 105

Saḷāyatanapaccayā phasso — due to the arising of the six bases, contact arises.

In brief, there are six kinds of contact: eye-contact (cakkhusamphassa), ear-contact (sotasamphassa), nose-contact (ghānasamphassa), tongue-contact (jivhāsamphassa), body-contact (kāyasamphassa) and mind-contact (manosamphassa). Of these, contact associated with rebirth-linking, life-continuum, death, five-door adverting, receiving, investigating, determining, impulsion, registration and mind-door adverting is all called mind-contact.

“Upādiṇṇakapavattikathā ayaṃ”ti sakasantatipariyāpanneva paccaye paccayuppanne ca dīpenti. (Abhidhamma Commentary, vol. 2, p. 168. Visuddhimagga, vol. 2, p. 199.)

According to those commentaries, the teaching of dependent origination in the analysis according to the Discourses concerns the course of what is acquired through kamma (upādiṇṇakapavattikathā). It sets out how the round of results arises due to kamma generated and cultivated while surrounded by ignorance, craving and clinging. Therefore the teachers set out the effective causes and effects within one’s own continuity of materiality and mentality. (Abhidhamma Commentary, vol. 2, p. 168. Visuddhimagga, vol. 2, p. 199.)

Ye tāva ācariyā Mahāvihāravāsino va yathā viññāṇaṃ evaṃ nāmarūpaṃ saḷāyatanaṃ phassaṃ vedanañca, paccayaṃ paccayuppannañca sasantatipariyāpannaṃ dīpentā vipākameva icchanti. (Mahāṭīkā, vol. 2, p. 323.)

In setting out cause and effect in the dependent origination factors of consciousness, mentality-materiality, the six bases, contact and feeling, the teachers of the Mahāvihāra intend to show effective causes and effects in one’s own continuity and take only the phenomena of the round of results. (Mahāṭīkā, vol. 2, p. 323.)


<a id="M06-body-P106"></a>
## The six internal and six external bases
Miến / Burmese 106

In the Pāli Analysis of the Abhidhamma (vol. 2, pp. 145–187), “chaḷāyatanapaccayā phasso” is taught in the sense that due to the arising of the sixth base, the mind base, mind-contact arises. That Pāli passage is taught with reference to how contact arises due to the mind base in the immaterial planes, that is, how mind-contact arises. Thus remember saḷāyatana as the six bases in the planes of five aggregates, and chaḷāyatana as the sixth base in the immaterial planes.

Here take all twelve bases: the six internal bases (ajjhattikāyatana) are the eye, ear, nose, tongue, body and mind bases; the six external bases (bāhirāyatana) are the visible-form, sound, odour, taste, tangible-object and mental-object bases. These internal and external bases are fields of activity in which consciousness and mental factors can develop and extend.

When the eye base, eye-sensitivity, meets and encounters the visible-form base, the visible object, if the object is desirable one may smile and the process may grow, and if the object is undesirable one may frown and the process may grow. Thus the eye base and visible-form base are fields of activity that enable the consciousnesses and mental factors in eye-door and mind-door processes taking visible form as object to develop further. Understand the other cases in the same way.

Among those twelve bases, the mental-object base comprises (a) fifty-two mental factors and (b) sixteen kinds of subtle materiality. All mental factors associated with the relevant consciousness are also called the mental-object base. Since heart-base materiality is included in the subtle materiality, the heart-base is also called the mental-object base. The mental factors associated with the relevant consciousness…


<a id="M06-body-P107"></a>
## Conditions for rebirth-linking mind-contact
Miến / Burmese 107

… especially the mental factors associated with the relevant contact, are called the associated mental-object base (sampayuttadhammāyatana). Consciousness is called the mind base.

Some examples of discernment. Rebirth-linking mind-contact is contact associated with rebirth-linking consciousness.

1. Due to the arising of the heart-base, a mental-object base, rebirth-linking mind-contact arises. The heart-base, a mental-object base is the cause and rebirth-linking mind-contact is the effect.

2. Due to the arising of the external base, one of the three objects kamma, kamma sign, or destination sign, rebirth-linking mind-contact arises. The external base is the cause and rebirth-linking mind-contact is the effect.

3. Due to the arising of rebirth-linking consciousness, the mind base, rebirth-linking mind-contact arises. Rebirth-linking consciousness, the mind base is the cause and rebirth-linking mind-contact is the effect.

4. Due to the arising of the associated mental-object base (= 32), rebirth-linking mind-contact arises. The associated mental-object base (= 32) is the cause and rebirth-linking mind-contact is the effect.

Rebirth-linking mind-contact is itself a mental phenomenon. According to the regularity of mental phenomena, in the planes of five aggregates it can arise only if there is a material base as a support. Moreover, because contact has the nature of contacting an object, it can arise only if there is an object to contact…


<a id="M06-body-P108"></a>
## Rebirth-linking objects and mind-contact in five-door adverting
Miến / Burmese 108

… In the absence of an object to contact, contact cannot arise. The object of that rebirth-linking mental group is one of three: kamma, a kamma sign, or a destination sign. That object can be one of the six kinds of object as appropriate. If the object is kamma, then for humans it is wholesome volition, and that wholesome volition belongs to the mental-object base. If wishing to discern that mental-object base separately, replace item 2 with the following:

2. Due to the arising of the kamma object, a mental-object base, rebirth-linking mind-contact arises. The kamma object, a mental-object base is the cause and rebirth-linking mind-contact is the effect.

The associated mental-object base. In three-rooted rebirth-linking with joy there are thirty-three mental factors associated with rebirth-linking consciousness. They include contact, which is rebirth-linking mind-contact. Rebirth-linking consciousness is the mind base. When resultant contact is excluded from the thirty-three mental factors, thirty-two remain. Those mental factors make up the mental-object base, the associated mental-object base. Understand similarly in each case. Following the pattern of rebirth-linking mind-contact, discern life-continuum mind-contact and death mind-contact.

Mind-contact in five-door adverting in the visible-object series.

1. Due to the arising of the heart-base, a mental-object base, mind-contact in five-door adverting arises. The heart-base, a mental-object base is the cause and mind-contact in five-door adverting is the effect.


<a id="M06-body-P109"></a>
## Mind-contact in five-door adverting and eye-contact
Miến / Burmese 109

2. Due to the arising of the visible-form base, the visible object, mind-contact in five-door adverting arises. The visible-form base, the visible object is the cause and mind-contact in five-door adverting is the effect.

3. Due to the arising of the five-door adverting mind base, mind-contact in five-door adverting arises. The five-door adverting mind base is the cause and mind-contact in five-door adverting is the effect.

4. Due to the arising of the associated mental-object base (= 9), mind-contact in five-door adverting arises. The associated mental-object base (= 9) is the cause and mind-contact in five-door adverting is the effect.

«Note. For brevity, the mind-contact of five-door adverting just described is given again in abbreviated form below. Though the text is abbreviated, when discerning, discern as in the full pattern above. Remember the same for eye-contact and the other kinds of contact.»

Mind-contact in five-door adverting in the visible-object series.
1. The heart-base, a mental-object base …
2. The visible-form base (= visible object) …
3. The five-door adverting mind base …
4. The associated mental-object base (= 9) …

Eye-contact is the contact associated with eye-consciousness.
1. The eye base (= eye-base materiality) …
2. The visible-form base (= visible object) …


<a id="M06-body-P110"></a>
## Contact in the eye-door process, through the first impulsion
Miến / Burmese 110

3. The eye-consciousness mind base …
4. The associated mental-object base (= 6) …

Mind-contact in receiving in the visible-object series.
1. The heart-base, a mental-object base …
2. The visible-form base …
3. The receiving mind base …
4. The associated mental-object base (= 9) …

Mind-contact in investigating in the visible-object series.
1. The heart-base, a mental-object base …
2. The visible-form base …
3. The investigating mind base …
4. The associated mental-object base (= 9 or 10) …

Mind-contact in determining in the visible-object series.
1. The heart-base, a mental-object base …
2. The visible-form base …
3. The determining mind base …
4. The associated mental-object base (= 10) …

Mind-contact in the first impulsion in the visible-object series, in the case of wholesome impulsion.
1. The heart-base, a mental-object base …
2. The visible-form base …
3. The first impulsion mind base …
4. The associated mental-object base (= 32) …


<a id="M06-body-P111"></a>
## Mind-contact in registration and mind-door adverting
Miến / Burmese 111

«Follow the pattern to discern the remaining impulsions, beginning with the second, and the remaining processes of wholesome and unwholesome impulsions. Discern all seven impulsions in full.»

Mind-contact in the first registration in the visible-object series.
1. The heart-base, a mental-object base …
2. The visible-form base …
3. The registration mind base …
4. The associated mental-object base (= 32) …

«When the other registration consciousnesses arise, such as great resultant registration, rootless wholesome-resultant registration and unwholesome-resultant registration, discern in the same way. Only the number of mental factors in the associated mental-object base varies.»

Mind-contact in mind-door adverting taking visible form as object.
1. The heart-base, a mental-object base …
2. The visible-form base …
3. The mind-door adverting mind base …
4. The associated mental-object base (= 10) …

Note. In this visible-object series, discern all processes with wholesome and unwholesome impulsions according to the tables in the section on the meditation subject of mentality. When discerning this way, the number of mental factors in investigating, impulsion and registration varies according to the tables. Thus in the associated mental-object base, the mental factors remaining after excluding contact…


<a id="M06-body-P112"></a>
## Consciousnesses to discern in the same process
Miến / Burmese 112

… take all of them as appropriate. For ear-door and mind-door processes taking sound, substitute the sound base, namely the sound object, for the visible-form base, and proceed similarly for other objects. Discern according to the pattern.

Five-door adverting, mind-door adverting, determining and impulsion do not belong to the round of results. They are included solely so that no ultimate phenomenon is omitted.

The resultant mental aggregates of sense-consciousness, receiving, investigating and registration in a five-door process cannot arise separately without prior five-door adverting. Registration in a mind-door process likewise cannot arise without mind-door adverting. Registration ordinarily arises only after impulsion, so without impulsion there is no registration. Impulsion does not arise in a five-door process without determining, or in a mind-door process without mind-door adverting.

Thus, when the resultant mental phenomena of sense-consciousness, receiving, investigating and registration arise, adverting, determining and impulsion are ordinarily present in the same process. When discerning those resultant mental phenomena, there is no fault in including adverting, determining and impulsion so that no ultimate phenomenon is omitted. In insight discernment, breaking up the appearance of compactness so that knowledge penetrates ultimate reality is especially important.


<a id="M06-body-P113"></a>
## Contact conditions feeling, and the six kinds of feeling
Miến / Burmese 113

Phassapaccayā vedanā — due to the arising of contact, feeling arises.

Tattha katamā phassapaccayā vedanā? Cakkhusamphassajā vedanā, sotasamphassajā vedanā, ghānasamphassajā vedanā, jivhāsamphassajā vedanā, kāyasamphassajā vedanā, manosamphassajā vedanā. Ayaṃ vuccati phassapaccayā vedanā. (Abhidhamma, vol. 2, p. 143.)

1. Cakkhusamphassajā vedanā is feeling born of eye-contact.
2. Sotasamphassajā vedanā is feeling born of ear-contact.
3. Ghānasamphassajā vedanā is feeling born of nose-contact.
4. Jivhāsamphassajā vedanā is feeling born of tongue-contact.
5. Kāyasamphassajā vedanā is feeling born of body-contact.
6. Manosamphassajā vedanā is feeling born of mind-contact.

Thus six kinds of feeling arise due to six kinds of contact. Here a good person should know the distinction between “feeling born of eye-contact” and “feeling conditioned by eye-contact,” and the corresponding cases.

Feeling born of eye-contact and feeling conditioned by eye-contact.

Cakkhusamphassajā vedanā, pe, atthi kusalā, atthi akusalā, atthi abyākatā. (Abhidhamma, vol. 2, p. 16.)

Cakkhusamphassapaccayā vedanākkhandho atthi kusalo, atthi akusalo, atthi abyākato. (Abhidhamma, vol. 2, p. 25.)

Cakkhusamphassajā vedanā, pe, manosamphassajā vedanāti etaṃ “cakkhusamphassajā vedanā atthi kusalā, atthi akusalā, atthi…


<a id="M06-body-P114"></a>
## The scope of feeling conditioned by eye-contact
Miến / Burmese 114

… abyākatā”ti evaṃ Vibhaṅge āgatattā cakkhudvārādīsu pavattānaṃ kusalākusalābyākatavedanānaṃ “Sāriputtatthero, Mantāṇiputtatthero”ti evamādīsu mātito nāmaṃ viya mātusadisavatthuto nāmaṃ. Vacanattho panettha cakkhusamphassahetu jātā vedanā cakkhusamphassajā vedanāti. Esa nayo sabbattha. (Majjhima Commentary, vol. 1, p. 225. Saṃyutta Commentary, vol. 2, p. 15.)

In the statement “the feeling aggregate conditioned by eye-contact,” understand “there is wholesome feeling” by way of the eight wholesome sense-sphere consciousnesses, “there is unwholesome feeling” by way of the twelve unwholesome consciousnesses, and “there is indeterminate feeling” by way of the three mind elements, three rootless mind-consciousness elements, eight great resultant consciousnesses and ten sense-sphere functional consciousnesses.

Here the eight wholesome and twelve unwholesome consciousnesses are taken by way of impulsion. The functional mind element is taken by way of adverting, the two resultant mind elements by receiving, the three resultant mind-consciousness elements by investigating and registration, the rootless functional mind-consciousness element by determining, the eight great resultant consciousnesses by registration and the nine functional consciousnesses by impulsion. The same method applies to the ear, nose, tongue and body doors. (Abhidhamma Commentary, vol. 2, p. 36.)

“One feels with eye-contact as condition” refers to feeling arising in receiving, investigating, determining and impulsion, with eye-contact as its root condition. As for feeling associated with eye-consciousness itself, there is no need to state it separately. The same method applies to feeling conditioned by ear-contact and the remaining cases. (Saṃyutta Commentary, vol. 3, p. 5.)

According to the Pāli and commentarial passages above, taking eye-contact associated with eye-consciousness as cause, the following consciousnesses arise…


<a id="M06-body-P115"></a>
## Feeling in the eye-door process
Miến / Burmese 115

1. Five-door adverting.
2. Eye-consciousness.
3. Receiving.
4. Investigating.
5. Determining.
6. (a) Wholesome sense-sphere impulsion, (b) unwholesome impulsion, (c) functional sense-sphere impulsion.
7. Registration.

All feeling associated with those wholesome, unwholesome and indeterminate consciousnesses, namely resultant and functional consciousnesses, is called feeling born of eye-contact and feeling conditioned by eye-contact. Understand similarly for feeling born of ear-contact, feeling conditioned by ear-contact and the remaining cases.

Kiriyāmanodhātu āvajjanavasena labbhati. (Abhidhamma Commentary, vol. 2, p. 36.)

Thus feeling associated with five-door adverting is also explained as arising due to eye-contact. Remember that this is one way of speaking about causality. The feeling associated with five-door adverting arises earlier. Only after the group of five-door adverting mental phenomena accompanying that feeling has ceased can eye-contact associated with eye-consciousness arise. The effect arises earlier and the cause later. The later eye-contact associated with eye-consciousness supports the feeling associated with the earlier five-door adverting.

This seems to fall under postnascence condition. Yet, as explained in the section “mentality-materiality conditions the six bases,” in postnascence condition the conditioning phenomenon is mental and the conditioned phenomenon is material. Here…


<a id="M06-body-P116"></a>
## In what sense does eye-contact condition feeling at five-door adverting?
Miến / Burmese 116

… both the cause and the effect are mental phenomena. Thus this case does not fall under postnascence condition either.

Yet five-door adverting that attends to a visible object can arise only in the continuity of someone with eye-sensitivity, where eye-contact can arise. In the continuity of someone lacking eye-sensitivity, where eye-contact cannot arise, five-door adverting that attends to a visible object also has no opportunity to arise. This is because a person lacking eye-sensitivity has no opportunity for an entire eye-door process to arise. In this way of speaking about causality, it is appropriate to say that feeling associated with five-door adverting arises due to eye-contact. Understand similarly when ear-contact and the other contacts support feeling associated with five-door adverting.

On this explanation, feeling born of eye-contact comprises all feeling in an eye-door process and all feeling in a subsequent mind-door process taking that very visible object. All these feelings are called feeling born of eye-contact. Discern with knowledge each feeling arising due to eye-contact as shown in the tables in the section on the meditation subject of mentality, then discern at least one item in each row according to the pattern below. Discern likewise for feeling born of ear-contact and the other contacts.

1. Due to the arising of eye-contact, feeling born of eye-contact arises. Eye-contact is the cause and feeling born of eye-contact is the effect.


<a id="M06-body-P117"></a>
## Six examples of contact conditioning feeling and the definition of mind-contact
Miến / Burmese 117

2. Due to the arising of ear-contact, feeling born of ear-contact arises. Ear-contact is the cause and feeling born of ear-contact is the effect.

3. Due to the arising of nose-contact, feeling born of nose-contact arises. Nose-contact is the cause and feeling born of nose-contact is the effect.

4. Due to the arising of tongue-contact, feeling born of tongue-contact arises. Tongue-contact is the cause and feeling born of tongue-contact is the effect.

5. Due to the arising of body-contact, feeling born of body-contact arises. Body-contact is the cause and feeling born of body-contact is the effect.

6. Due to the arising of mind-contact, feeling born of mind-contact arises. Mind-contact is the cause and feeling born of mind-contact is the effect.

What is mind-contact?

Manosamphassajāti bhavaṅgasahajāto samphasso. Vedayitanti sahāvajjanavedanāya javanavedanā. Bhavaṅgasampayuttāya pana vattabbameva natthi. (Saṃyutta Commentary, vol. 3, p. 5.)

According to the commentaries above, the contact associated with life-continuum before the mind-door process is mind-contact. The feeling associated with mind-door adverting, impulsion and registration, when present, within the mind-door process is feeling born of mind-contact. Feeling associated with life-continuum is itself also feeling born of mind-contact. Due to mind-contact in an earlier life-continuum, feeling born of mind-contact in a later life-continuum…


<a id="M06-body-P118"></a>
## Mind-contact and feeling conditioning craving
Miến / Burmese 118

… can also arise. Remember that due to mind-contact conascent with life-continuum, feeling born of mind-contact conascent with life-continuum can also arise. Since mind-door processes can take all six kinds of object, discern in this way for all six.

The contact associated with life-continuum, together with mind-door adverting, is also explained as mind-contact. (Saṃyutta Commentary, vol. 3, p. 5.) Due to that mind-contact, feelings born of mind-contact associated with impulsion and registration, when present, arise. Discern them so that knowledge sees clearly.

Vedanāpaccayā taṇhā — due to the arising of feeling, craving arises.

The six kinds of craving arising due to six kinds of feeling are craving for visible form, sound, odour, taste, tangible objects and mental objects. (Abhidhamma, vol. 2, p. 143.)

According to how it arises, each kind of craving in turn has three forms: craving for sensual pleasures, craving for becoming, and craving for non-becoming. When craving for visible form arises with intense delight in the visible object that appears at the eye door, by the power of sensual desire (kāmacchanda), that is, strong delight in a sensual object (vatthukāma), it is called craving for sensual pleasures.

At times craving for visible form arises together with the eternalist view that the very visible object is permanent and exists at all times…


<a id="M06-body-P119"></a>
## Craving for sensual pleasures, becoming and non-becoming
Miến / Burmese 119

… In that case it is called craving for becoming. Greed arising together with eternalism is called craving for becoming.

At other times craving for visible form arises together with the annihilationist view that the very visible object will perish at death. In that case it is called craving for non-becoming. Greed arising together with annihilationism is called craving for non-becoming. Understand the same with craving for sound and the other kinds. (Abhidhamma Commentary, vol. 2, pp. 170–171. Visuddhimagga, vol. 2, p. 202.)

Craving for becoming (bhavataṇhā). Whether in regard to a visible form, a sound or any other object, the view that takes it to be a self and holds “that self is permanent,” namely eternalism, is called becoming. Craving arising together with that view is called craving for becoming. (Bhavatīti bhavo. Bhavoti pavattā diṭṭhi bhavadiṭṭhi. Bhavena sahagatā taṇhā bhavataṇhā.)

Craving for non-becoming (vibhavataṇhā). Na bhavatīti vibhavo. Vibhavoti pavattā diṭṭhi vibhavadiṭṭhi. Vibhavena sahagatā taṇhā vibhavataṇhā. The view that takes any of the six objects as a self and holds “that self is not permanent and is cut off at death,” namely annihilationism, is called non-becoming. Craving arising with that view is called craving for non-becoming.

Yasmā vātiādinā na kevalaṃ vipākasukhavedanā eva, tissopi pana vedanā vipākā visesena taṇhāya upanissayapaccayā, avisesena itarā cāti dasseti. (Mūlaṭīkā, vol. 2, p. 120.)

Kammaphalābhipatthanāvasena sattā kammāni āyūhantīti sātisayaṃ taṇhāya vipākavedanā upanissayo, na tathā itarāti āha “vipākā visesena, pe, avisesena itarā cā”ti. Itarāti avipākāti attho. (Anuṭīkā, vol. 2, p. 132.)


<a id="M06-body-P120"></a>
## Resultant feeling supports craving by decisive support condition
Miến / Burmese 120

Out of a strong aspiration for the results of kamma, beings generate and cultivate kamma. Therefore the commentaries and subcommentaries above explain that resultant feelings associated with the five kinds of sense-consciousness, receiving, investigating and registration in such processes as the eye-door process give special support to craving, that is, greed in greed-rooted consciousnesses, by the powerful force of decisive support condition. Feelings at adverting, determining and impulsion assist by decisive support condition only in a general way.

According to this explanation, remember that feeling as cause and craving as effect may arise within one process or in different processes. On the causal side, for feeling born of eye-contact, take as appropriate the feelings associated with the individual moments of the eye-door process and those associated with the individual moments of the subsequent mind-door processes taking the very same visible object, as causes of craving for visible form, that is, longing and attachment for that object. Understand likewise for feeling born of ear-contact as cause of craving for sound and the other cases.

Since resultant feeling is taken as primary on the causal side, note that feeling as cause and craving as effect generally do not arise in the same moment. They may be separated by one or many consciousness moments, or by many cognitive processes.


<a id="M06-body-P121"></a>
## Looking toward future existence and examples of feeling conditioning craving
Miến / Burmese 121

The account of the future round (anāgatavaṭṭakathā). As this section shows the operation of the round of rebirths, it concerns what the meditator is generating and cultivating in their own continuity with a future life in view. Thus take as primary how craving that longs for and clings to the aggregates, existence and objects of a new future life arises due to feelings being experienced while looking forward to that new life.

That craving, together with the clinging and kamma-becoming to be explained later, belongs to the present causes, ignorance, craving, clinging, formations and kamma, being generated and cultivated with a view to a future life that may be obtained before realizing Nibbāna. Thus let the good person take as primary and discern (ignorance), craving, clinging, (formations) and kamma being cultivated for their future life.

Some examples of discernment.

1. Due to the arising of feeling born of eye-contact, craving for visible form arises. Feeling born of eye-contact is the cause and craving for visible form is the effect.

2. Due to the arising of feeling born of ear-contact, craving for sound arises. Feeling born of ear-contact is the cause and craving for sound is the effect.

3. Due to the arising of feeling born of nose-contact, craving for odour arises. Feeling born of nose-contact is the cause and craving for odour is the effect.


<a id="M06-body-P122"></a>
## Craving for mental objects and the case of Arahants
Miến / Burmese 122

4. Due to the arising of feeling born of tongue-contact, craving for taste arises. Feeling born of tongue-contact is the cause and craving for taste is the effect.

5. Due to the arising of feeling born of body-contact, craving for tangible objects arises. Feeling born of body-contact is the cause and craving for tangible objects is the effect.

6. Due to the arising of feeling born of mind-contact, craving for mental objects arises. Feeling born of mind-contact is the cause and craving for mental objects is the effect.

Craving for mental objects is craving that longs for and clings to consciousness, mental factors, material phenomena other than the five objects of visible form, sound, odour, taste and touch, and various conceptual objects.

Discern at least one item in each row of the tables in the section on the meditation subject of mentality. Discern in the same way at all six doors.

In the continuity of Arahants.

Vedanāpaccayā cāpi, yasmā nānusayaṃ vinā;
Hoti tasmā na sā hoti, brāhmaṇo vusīmato. (Abhidhamma Commentary, vol. 2, p. 171. Visuddhimagga, vol. 2, p. 203.)

Ca adds a further point. Yasmā means for what reason. Vedanāpaccayā means feeling is present as a condition. Samānāpi means even though present. Anusayaṃ means a latent tendency, dormant because it has not yet been abandoned by the Noble Path…


<a id="M06-body-P123"></a>
## Craving does not arise in Arahants, and craving conditions clinging
Miến / Burmese 123

… Vinā means without. Taṇhā means craving that longs for and clings to existences and objects. Na hoti means it cannot manifest in the mental continuity as arisen craving (pariyuṭṭhāna). Tasmā means therefore. Vusīmato refers to one who has lived the holy life of the Noble Path, the sublime practice. Brāhmaṇo refers to the Arahant who has washed away unwholesome deeds. Sā means that craving. Na hoti means it can no longer appear in the form of arising, presence and dissolution in that continuity.

If it is said “whenever feeling is present as a cause, craving arises,” the question may arise whether craving also arises due to feeling in an Arahant’s continuity. This is why the commentaries give the stanza above, beginning “vedanāpaccayā cāpi.” Where feeling conditions craving, craving can manifest, arise, persist and dissolve only in someone in whose aggregate continuity craving is still dormant as a latent tendency.

In the continuity of materiality and mentality of Arahants, who have practised the supreme practice of developing the Noble Path and uprooted the latent tendency to craving, craving cannot arise due to feeling. (Abhidhamma Commentary, vol. 2, p. 171. Visuddhimagga, vol. 2, p. 203.)

Taṇhāpaccayā upādānaṃ — due to the arising of craving, clinging arises. There are four kinds of clinging: clinging to sensual pleasures, to views, to rules and observances, and to a doctrine of self.


<a id="M06-body-P124"></a>
## The four kinds of clinging
Miến / Burmese 124

1. Clinging to sensual pleasures (kāmupādāna). Craving that longs for and clings to the five strands of sensual pleasure is called craving for sensual pleasures. Earlier sensual craving supports the later craving by powerful decisive support condition, making it firm. That later sensual craving is called clinging to sensual pleasures.

2. Clinging to views (diṭṭhupādāna). Apart from clinging to rules and observances and to a doctrine of self, wrong views that later come to cling firmly and intensely to erroneous doctrines, such as denial of results, denial of causes and denial of the efficacy of action, rejecting kamma and its results, are called clinging to views.

3. Clinging to rules and observances (sīlabbatupādāna). The rigid wrong view that mistakenly holds that following the conduct and habits of oxen or dogs, and similar practices, can purify one of defilements and free one from suffering in the round of rebirths is called clinging to rules and observances.

4. Clinging to a doctrine of self (attavādupādāna). The view that clings firmly to a doctrine asserting a self, a living entity, soul, essence, consciousness or enduring self, is called clinging to a doctrine of self. In terms of its nature, it is the mental factor of wrong view. Such doctrines posit a creator, the supreme self (parama-attā), and a created living self (jīva-attā). They take one of the five aggregates or all five as self. This is also called identity view (sakkāyadiṭṭhi) or self-view (attadiṭṭhi).


<a id="M06-body-P125"></a>
## An example of craving conditioning clinging when aspiring to a future life
Miến / Burmese 125

In this section, the good person should pay particular attention to discerning how clinging arises due to craving in the round of defilements being cultivated with a future life as its aim. Suppose the good person wishes to live as a Dhamma-teaching deva and cultivates the rounds of defilements and kamma with that aim. Discern how clinging to sensual pleasures arises based on sensual craving for the insentient sensual objects that would be obtained in that life. In other words, discern how clinging to the life of a Dhamma-teaching deva arises based on sensual craving for that very life.

1. Due to the arising of craving for sensual pleasures, clinging to sensual pleasures arises. Craving for sensual pleasures is the cause and clinging to sensual pleasures is the effect.

Alternatively, taking it that “the Dhamma-teaching deva really exists” is a kind of identity view. In some cases, clinging to a self in accordance with worldly names and conventional usage is also called a kind of identity view. If, based on that identity view, craving for becoming arises together with self-view, longing for the life of a Dhamma-teaching deva and taking it as “I am a Dhamma-teaching deva,” discern how clinging to a doctrine of self or clinging to views arises due to that craving for becoming.

2. Due to the arising of craving for becoming, clinging to a doctrine of self arises. Craving for becoming is the cause and clinging to a doctrine of self is the effect.

Or…


<a id="M06-body-P126"></a>
## A way of discerning the three kinds of craving separately
Miến / Burmese 126

Due to the arising of craving for becoming, clinging to views arises. Craving for becoming is the cause and clinging to views is the effect.

A way of discerning separately — an example.

(a) Craving for visible form arising with intense delight in the very visible object that would be obtained in the life of a Dhamma-teaching deva is called craving for sensual pleasures.

(b) Craving for visible form arising together with the eternalist view that the very visible object “is permanent and always exists” is called craving for becoming.

(c) Craving for visible form arising together with the annihilationist view that the very visible object “will be cut off and perish at death” is called craving for non-becoming.

Thus craving for visible form has three forms: craving for sensual pleasures, for becoming and for non-becoming. Craving for sound, pe, craving for mental objects, each likewise has three forms.

1. Due to the arising of craving for visible form as sensual craving, clinging to sensual pleasures arises. Craving for visible form as sensual craving is the cause and clinging to sensual pleasures is the effect.

2. Due to the arising of craving for visible form as craving for becoming, clinging to views arises (eternalism). That craving is the cause and clinging to views is the effect.

3. Due to the arising of craving for visible form as craving for non-becoming, clinging to views arises (annihilationism). That craving is the cause and clinging to views is the effect.

In another explanation, craving for becoming accompanied by eternalism and craving for non-becoming accompanied by annihilationism, with regard to a doctrine of self…


<a id="M06-body-P127"></a>
## Clinging to a doctrine of self and the cognitive processes of craving and clinging
Miến / Burmese 127

… are forms of craving that arise by taking that very visible object and similar objects as self. Therefore one can also discern as follows.

1. Due to the arising of craving for visible form as craving for becoming, clinging to a doctrine of self arises. Craving for visible form as craving for becoming is the cause and clinging to a doctrine of self is the effect.

2. Due to the arising of craving for visible form as craving for non-becoming, clinging to a doctrine of self arises. Craving for visible form as craving for non-becoming is the cause and clinging to a doctrine of self is the effect.

Following this pattern, discern craving for sound, odour, taste, tangible objects and mental objects. If a good person aspires in the future to become a bhikkhu able to serve the Dispensation and cultivates the perfections, discern likewise following the above example of kamma for a Dhamma-teaching deva. Clinging to rules and observances, however, very rarely arises in the continuity of a good disciple of the Buddha.

Cognitive processes of craving and clinging.
Phenomenon | Mind-door adverting | Impulsion (7 times) | Registration (2 times)
Craving for visible form as sensual craving | 12 | 20 | 12/11/34/33
Clinging | 12 | 20 | 〃

Sometimes impulsion and registration dissociated from joy can also arise. Examine carefully the round of defilements being cultivated for a future life.


<a id="M06-body-P128"></a>
## A point to note, and clinging conditioning becoming
Miến / Burmese 128

In the continuity of a good person attaining knowledge of discerning mentality-materiality and knowledge of discerning conditions in this life, clinging to views, to rules and observances, and to a doctrine of self are very unlikely to arise. Clinging to sensual pleasures is more likely to arise. Thus it can suffice to discern one pattern of clinging to sensual pleasures arising due to craving.

Yet in the round of rebirths with no discernible beginning, there is probably no defilement or kind of clinging that has never arisen in a being’s continuity of materiality and mentality. Thus, when discerning how past effects arise due to past causes, discern and contemplate the kinds of view and clinging arising due to craving just as they arose in that life.

Upādānapaccayā bhavo — due to the arising of clinging, becoming arises.

Becoming is of two kinds: (1) kamma-becoming (kammabhava) and (2) rebirth-becoming (upapattibhava). Kamma-becoming is the cause of arising. Rebirth-becoming is arising, the nature of the aggregates coming into being.

Wholesome or unwholesome kamma now being generated and cultivated with a future life in view is called kamma-becoming, becoming as the cause of arising. Due to that wholesome or unwholesome kamma…


<a id="M06-body-P129"></a>
## Kamma-becoming, rebirth-becoming, and a point to note
Miến / Burmese 129

… the four resultant mental aggregates and kamma-born materiality will arise. This is rebirth-becoming, becoming as arising, the nature of arising.

Meritorious, demeritorious and imperturbable formations, namely formations or kamma now generated and cultivated in order to obtain rebirth-becoming as future resultant mental aggregates and kamma-born materiality, are called kamma-becoming. Discern how these two kinds of becoming arise on the basis of (ignorance, craving and) clinging. For kamma-becoming, focus on the group of wholesome mental phenomena headed by wholesome volition that one is cultivating for the future.

One can also discern a group of unwholesome volitions that has arisen before. In dependence on craving for misconduct, clinging to that misconduct arises. In dependence on clinging, one commits unwholesome actions, that is, unwholesome formations arise. Due to that unwholesome kamma, namely kamma-becoming, the five aggregates called rebirth-becoming arise in a future state of deprivation. One can discern in that way. However, according to the passages below, this is very unlikely.

A point to note.

Evaṃ saṅkhāre sallakkhetvā ṭhito pana bhikkhu dasabalassa sāsane mūlaṃ otarati nāma hoti, patiṭṭhaṃ laddhā nāma, cūḷasotāpanno nāma hoti niyatagatikoti. (Abhidhamma Commentary, vol. 2, p. 242.)

Iminā pana ñāṇena samannāgato vipassako Buddhasāsane laddhassāso laddhapatiṭṭho niyatagatikā cūḷasotāpanno nāma hoti. (Visuddhimagga, vol. 2, p. 240.)


<a id="M06-body-P130"></a>
## Knowledge of discerning conditions and discernment directed to a future life
Miến / Burmese 130

A meditating bhikkhu whose understanding has reached knowledge of discerning conditions and who clearly distinguishes materiality, mentality, causes and effects has become firmly rooted in the Dispensation of the Buddha, endowed with ten bodily powers and ten powers of knowledge. The bhikkhu has gained a footing and assurance. By discerning the conditioned phenomena of materiality, mentality, causes and effects with knowledge of discerning conditions, the bhikkhu attains purification by overcoming doubt (kaṅkhāvitaraṇavisuddhi) and has become rooted in the Buddha’s Dispensation. Having gained that footing and a definite course toward a good destination, the bhikkhu is called a lesser stream-enterer (cūḷasotāpanna), having reached that stage.

According to the above commentaries, one who has attained the stage of a lesser stream-enterer through knowledge of discerning conditions is far from falling back into a state of deprivation in the account of the future round. Therefore discern causes and effects in connection with wholesome formations that can arise.

Similarly, for a meditator who has discerned to this stage, clinging to views, to rules and observances, and to a doctrine of self are very rare. Clinging to sensual pleasures is more likely to arise. Attachment to the five aggregates of a future life, such as that of a bhikkhu or a Dhamma-teaching deva, or to the six future objects, is clinging to sensual pleasures. Discern with knowledge how kamma-becoming and rebirth-becoming arise due to that clinging.


<a id="M06-body-P131"></a>
## A concise pattern of discernment for memorization
Miến / Burmese 131

Since this section discerns ignorance, craving, clinging, formations and kamma being cultivated for a future life, the good person may take as the object of discernment one particular case of (ignorance), craving, clinging, (formations) and kamma that one is cultivating while clinging to a new life. That is enough. The meaning is to select one memorable and satisfying deed among the many deliberately cultivated with that new life in view.

1. The mistaken perception of a future life as a bhikkhu or a Dhamma-teaching deva is ignorance.
2. Longing for and attachment to that life is craving.
3. Holding firmly to that life due to craving is clinging, namely clinging to sensual pleasures.
4. Giving, virtue or development generated and cultivated on the basis of that clinging is formations.
5. Kamma is kamma-becoming. (This refers to kammic power.)

The five aggregates in the life of a bhikkhu or a Dhamma-teaching deva that will be obtained due to that kamma-becoming are rebirth-becoming, that is, future birth.

If the good person takes serenity as the vehicle and has attained jhāna, develop the preferred attainment among the jhānas already attained to the inferior, middling or superior grade. While aspiring or inclining the mind toward Brahmā existence and the Brahmā aggregates appropriate to that jhāna and grade, discern ignorance, craving…


<a id="M06-body-P132"></a>
## Examples of becoming and the mind-door process with impulsions
Miến / Burmese 132

… clinging, formations (jhāna) and kamma, and likewise discern the Brahmā existence and the Brahmā aggregates to be obtained due to them. If the future course of saṃsāra is still apparent to the good person, they will see rebirth-becoming as Brahmā existence and the Brahmā aggregates.

Ignorance, craving, clinging, formations and kamma differ from one meditator to another. Following the examples of the lives of a bhikkhu and a Dhamma-teaching deva given above, discern according to one’s own aspirations, inclinations and aims.

Some examples of discernment.

1. Due to the arising of clinging to sensual pleasures, kamma-becoming arises. Clinging to sensual pleasures is the cause and kamma-becoming is the effect.

2. Due to the arising of kamma-becoming, rebirth-becoming arises. Kamma-becoming is the cause and rebirth-becoming is the effect.

Mind-door cognitive process with impulsions.
Phenomenon | Mind-door adverting | Impulsion (7 times) | Registration (2 times)
1. Clinging to sensual pleasures | 12 | 20 | 12/34
2. Kamma-becoming (wholesome) | 12 | 34 | 34/12

3. Rebirth-becoming is the future aggregates arising due to that kamma-becoming.

The table takes only wholesome kamma-becoming as an example. However, in all three periods, discern wholesome or unwholesome kamma-becoming as it arose, is arising or will arise in one’s own continuity of materiality and mentality. If it is jhāna kamma-becoming…


<a id="M06-body-P133"></a>
## Jhāna kamma-becoming and becoming conditioning birth
Miến / Burmese 133

… understand as follows: (1) first-jhāna kamma-becoming = 34, (2) second-jhāna kamma-becoming = 32, (3) third-jhāna kamma-becoming = 31, (4) fourth-jhāna kamma-becoming = 31, (5) immaterial-jhāna kamma-becoming = 31. (According to the fourfold division of jhāna.)

Bhavapaccayā jāti — due to the arising of (kamma-)becoming, birth arises.

Bhavoti panettha kammabhavova adhippeto. So hi jātiyā paccayo, na upapattibhavo. (Abhidhamma Commentary, vol. 2, p. 178. Visuddhimagga, vol. 2, p. 210.)

In “with becoming as condition, birth,” becoming means only kamma-becoming, which has the power to produce birth. That kamma-becoming alone is the actual cause of birth. Rebirth-becoming is not the actual cause of birth. (Abhidhamma Commentary, vol. 2, p. 178. Visuddhimagga, vol. 2, p. 210.)

Upapattibhavuppattiyeva jātīti āha “na upapattibhavo”ti. (Mahāṭīkā, vol. 2, p. 334.)

The very arising of rebirth-becoming is birth. Thus the commentary says “rebirth-becoming is not the actual cause of birth.” (Mahāṭīkā, vol. 2, p. 334.) Thus for birth, take the initial arising of the five future aggregates called rebirth-becoming…


<a id="M06-body-P134"></a>
## Discerning birth and a question about kamma-becoming
Miến / Burmese 134

… that is, take the five rebirth-linking aggregates arising at the beginning.

If the good person sees with knowledge that birth in a future Brahmā existence is attained due to the kamma-becoming of the fourth jhāna of the white kasiṇa, and can discern cause and effect, then see with knowledge that the five aggregates in that Brahmā existence do not include nose-, tongue- or body-sensitivity, or sex materiality. Thus there are no nose, tongue, body or sex decads. Bear this in mind when discerning.

A brief example of discernment.

1. Due to the arising of kamma-becoming, birth arises. Kamma-becoming is the cause and birth is the effect.

A point for inquiry.

Question. How can one know that kamma-becoming is the cause of birth?

Answer. Even when causes external to one’s continuity are seen to be alike, beings are seen to differ in being inferior or superior, beautiful or not beautiful. Observing those differences, one can know that kamma-becoming is the cause of birth. Even when external causes, such as the reproductive substances of the parents and nutriment, are seen to be alike…


<a id="M06-body-P135"></a>
## Kamma distinguishes beings
Miến / Burmese 135

… differences such as being inferior or superior, beautiful or not beautiful, are found even among beings sharing the same womb.

Those differences do not arise causelessly. Why? Because they do not occur at all times or in the continuity of every being. Nor can a cause other than kamma-becoming account for them, because within the internal continuity of beings born due to kamma-becoming there is no other cause to account for those distinctions. Thus the differences of inferiority and superiority, beauty and lack of beauty, show that there is kamma-becoming as a cause. Kamma is the distinctive cause of those differences. Therefore the Buddha taught in the Shorter Discourse on the Analysis of Kamma (Cūḷakammavibhaṅgasutta):

Kammaṃ satte vibhajati yadidaṃ hīnapaṇītatāya. (Majjhima, vol. 3, p. 244.) That is, kamma distinguishes beings as inferior or superior. (Majjhima, vol. 3, p. 244.)

Thus one can know that kamma-becoming is the cause of birth. (Abhidhamma Commentary, vol. 2, pp. 178–179. Visuddhimagga, vol. 2, p. 210.)


<a id="M06-body-P136"></a>
## Birth conditioning aging and death in conventional and ultimate terms
Miến / Burmese 136

Jātipaccayā jarāmaraṇaṃ — due to birth, aging and death arise.

An example of discernment.

1. Due to the arising of birth, aging and death arises. Birth is the cause and aging and death is the effect.

One can discern in two ways, according to conventional truth and ultimate truth. If discerning by conventional truth, discern with knowledge how, due to birth, the establishment of rebirth-linking in a life, aging and death arise. That is, discern future birth, aging and death.

If discerning by ultimate truth, take (1) material phenomena arising throughout a future life and (2) mental phenomena arising according to each base and door, as well as process-free rebirth-linking, life-continuum and death mentality. In that materiality and mentality, (1) arising (uppāda) is birth, (2) presence (ṭhiti) is aging, and (3) dissolution (bhaṅga) is death. Discern with knowledge the arising, presence and dissolution of that materiality and mentality throughout a future life…


<a id="M06-body-P137"></a>
## Birth conditioning sorrow, lamentation, pain, grief and despair
Miến / Burmese 137

1. Due to the arising of birth, aging and death arises. Birth is the cause and aging and death is the effect.

One can also discern in this way. Here too the phenomena of the round of results are primary.

Sorrow, lamentation, pain, grief and despair.

Only in the continuity of someone subject to birth can sorrow, lamentation, pain, grief and despair arise when they encounter a loss such as the loss of relatives (ñātibyasana). Yet these phenomena do not invariably arise in everyone who has been born. In the continuity of noble ones who have abandoned those defilements, though there is birth, sorrow and the others cannot arise. (Bodily pain alone can still arise as appropriate.) Thus sorrow and the others are called non-invariable consequences of birth. Discern with knowledge how they arise in the continuity of those in whom they may arise in the future.

A brief example of discernment.

1. Due to the arising of birth, sorrow arises. Birth is the cause and sorrow is the effect.

pe.

2. Due to the arising of birth, despair arises. Birth is the cause and despair is the effect.

(Understand the examples for lamentation, pain and grief, and discern in the same way.)


<a id="M06-body-P138"></a>
## Table 1 — Taking the present life as the center
Miến / Burmese 138

Table 1 — Taking the present life as the center
Three links | Twelve factors | Twenty aspects | Four groups | Three periods
 | Ignorance | = Ignorance + craving + clinging | Past causes | Past
 | Formations | = Formations + kamma |  | 
Link 1 | Consciousness | 1. Consciousness | Present results | Present
 | Mentality-materiality | 2. Mentality-materiality |  | 
 | Six sense bases | 3. Six sense bases |  | 
 | Contact | 4. Contact |  | 
 | Feeling | 5. Feeling |  | 
Link 2 | Craving | = Ignorance + craving + clinging | Present causes | 
 | Clinging |  |  | 
 | Becoming | = Kamma-becoming = formations + kamma |  | 
Link 3 | Birth | (Rebirth-becoming) = consciousness + mentality-materiality + six sense bases + contact + feeling | Future results | Future
 | Aging and death |  |  |


<a id="M06-body-P139"></a>
## Table 2 — Taking the first past life as the center
Miến / Burmese 139

Table 2 — Taking the first past life as the center
Three links | Twelve factors | Twenty aspects | Four groups | Three periods
 | Ignorance | = Ignorance + craving + clinging | Second past life causes | Second past life
 | Formations | = Formations + kamma |  | 
Link 1 | Consciousness | 1. Consciousness | First past life results | First past life
 | Mentality-materiality | 2. Mentality-materiality |  | 
 | Six sense bases | 3. Six sense bases |  | 
 | Contact | 4. Contact |  | 
 | Feeling | 5. Feeling |  | 
Link 2 | Craving | = Ignorance + craving + clinging | First past life causes | 
 | Clinging |  |  | 
 | Becoming | = Kamma-becoming = formations + kamma |  | 
Link 3 | Birth | (Rebirth-becoming) = consciousness + mentality-materiality + six sense bases + contact + feeling | Present results | Present
 | Aging and death |  |  |

Understand the successive past lives in saṃsāra in the same way. Discern three interrelated lives.


<a id="M06-body-P140"></a>
## Table 3 — Taking the first future life as the center
Miến / Burmese 140

Table 3 — Taking the first future life as the center
Three links | Twelve factors | Twenty aspects | Four groups | Three periods
 | Ignorance | = Ignorance + craving + clinging | Present causes | Present
 | Formations | = Formations = kamma |  | 
Link 1 | Consciousness | 1. Consciousness | First future life results | First future life
 | Mentality-materiality | 2. Mentality-materiality |  | 
 | Six sense bases | 3. Six sense bases |  | 
 | Contact | 4. Contact |  | 
 | Feeling | 5. Feeling |  | 
Link 2 | Craving | = Ignorance + craving + clinging | First future life causes | 
 | Clinging |  |  | 
 | Becoming | = Kamma-becoming = formations + kamma |  | 
Link 3 | Birth | (Rebirth-becoming) = consciousness + mentality-materiality + six sense bases + contact + feeling | Second future life results | Second future life
 | Aging and death |  |  |

Understand the successive future lives in saṃsāra in the same way. Discern three successive lives at a time as far into the future as possible.


<a id="M06-body-P141"></a>
## Cognitive processes of sorrow, lamentation, pain, grief and despair
Miến / Burmese 141

Cognitive processes of sorrow, lamentation, grief and despair. Mind-door process with impulsion.
Mind-door process with impulsion | Mind-door adverting | Impulsion (7 times) | Registration (2 times)
Sorrow, pe, despair | 12 | 18 (hatred group) | 11/33/32

Pain. In precise terms, pain here is painful feeling associated with rootless unwholesome-resultant body consciousness accompanied by pain. The cognitive process is a body-door process with impulsion. Depending on the force of wise or unwise attention, wholesome or unwholesome impulsions may arise as appropriate.

Sorrow, lamentation, grief and despair are groups of hatred-rooted impulsions. Only one example of a mind-door process is shown here. Five-door processes can also occur in the same way, but intense sorrow and similar states occur only at the mind door. Registration may occur in some cases and may be absent in others. When registration follows a run of hatred-rooted impulsions, only equanimous registration can occur. Alternatively, an adventitious life-continuum (āgantukabhavaṅga) may intervene.

The discernment of dependent origination by the first method, presented so far, takes the present life as its center. Following this model, one may also take a past life as the center and discern successive past lives, or take a future life as the center and discern successive future lives. Link three lives at a time and discern the causes and their results clearly.

This concludes the first method, called the teaching on dependent origination in forward order (anulomapaṭiccasamuppāda).


<a id="M06-body-P142"></a>
## Four ways of teaching dependent origination
Miến / Burmese 142

Just as four men cut and pulled a creeper, the Buddha taught dependent origination in four ways: (1) from beginning to end, (2) from middle to end, (3) from end to beginning, and (4) from middle to beginning.

1. From beginning to end — the teaching on dependent origination in forward order (1).

In the forest, one of the four men cutting creepers first sees the root. He cuts the creeper at its root, pulls it out all the way to the tip, and carries it away to use for tying or binding. In the same way the Buddha taught:

“Iti kho, bhikkhave, avijjāpaccayā saṅkhārā … pe … jātipaccayā jarāmaraṇaṃ.” Thus, bhikkhus, with ignorance as condition, formations arise … pe … with birth as condition, aging and death arise. (M I 328.)

Thus he taught dependent origination from ignorance at the beginning through to aging and death at the end. (Abhidhamma Commentary II 124. Visuddhimagga II 154.)


<a id="M06-body-P143"></a>
## From middle to end
Miến / Burmese 143

2. From middle to end — the teaching on dependent origination in forward order (2).

Another of the four first sees the middle of the creeper. He cuts it in the middle, pulls the upper part all the way to the tip, and carries it away to use for tying or binding. In the same way the Buddha taught:

“Tañca taṃ vedanaṃ abhinandato abhivadato ajjhosāya tiṭṭhato uppajjati nandī. Yā vedanāsu nandī tadupādānaṃ. Tassupādānapaccayā bhavo, bhavapaccayā jāti, jātipaccayā jarāmaraṇaṃ.” (M I 333. S II 13.)

In the continuity of one who thoroughly delights in that feeling, welcomes it as “excellent, excellent,” and remains fastened to it, delight arises. Delight in feelings is clinging. With clinging as condition, becoming arises. With becoming as condition, birth arises. With birth as condition, aging and death arise. (M I 333. S II 13.)

Thus he taught dependent origination from feeling in the middle to aging and death at the end. (Abhidhamma Commentary II 124. Visuddhimagga II 154–155.)


<a id="M06-body-P144"></a>
## From end to beginning
Miến / Burmese 144

3. From end to beginning — the teaching on dependent origination in reverse order (1).

Another of the four first sees the tip of the creeper. He takes hold of the tip, follows it back to the root, and pulls out the entire creeper to use for tying or binding. In the same way the Buddha taught:

“It has been said, ‘With birth as condition, there is aging and death.’ Bhikkhus, is there aging and death with birth as condition, or is there not? How do you understand this?” “Venerable sir, with birth as condition there is aging and death. This is how we understand it: ‘With birth as condition, there is aging and death.’”

“It has been said, ‘With becoming as condition, there is birth … pe … with ignorance as condition, there are formations.’ Bhikkhus, are there formations with ignorance as condition, or are there not? How do you understand this?” “Venerable sir, with ignorance as condition there are formations. This is how we understand it: ‘With ignorance as condition, there are formations.’” (M I 328.)

The Buddha said: “I have said that aging and death occur with birth as condition. Bhikkhus … is there aging and death with birth as condition? How do you understand this?” The disciples replied: “Venerable sir … there is aging and death with birth as condition. We understand that aging and death occur with birth as condition.”


<a id="M06-body-P145"></a>
## From middle to beginning
Miến / Burmese 145

The Buddha said: “I have said that with becoming as condition there is birth … pe … and with ignorance as condition there are formations. Bhikkhus … are there formations with ignorance as condition? How do you understand this?”

The disciples replied: “Venerable sir … there are formations with ignorance as condition. We understand that formations occur with ignorance as condition.” (M I 328.)

Thus he taught dependent origination from aging and death at the end back to ignorance at the beginning. (Abhidhamma Commentary II 124. Visuddhimagga II 155.)

4. From middle to beginning — the teaching on dependent origination in reverse order (2).

Another of the four first sees the middle of the creeper. He cuts it in the middle, follows the lower part down to the root, and pulls it away to use for tying or binding. In the same way the Buddha taught:

“Bhikkhus, what is the source of these four nutriments, what is their origin, from what are they born, and from what do they spring? These four nutriments have craving as their source, craving as their origin, they are born of craving and spring from craving. And what, bhikkhus, is the source of craving? Feeling … contact … the six sense bases … mentality-materiality … consciousness … formations…”


<a id="M06-body-P146"></a>
## Craving as the source of the four nutriments
Miến / Burmese 146

“… what is their source? … pe … Formations have ignorance as their source, ignorance as their origin, are born of ignorance and spring from ignorance.” (S I 253.)

Bhikkhus … what is the source of these four nutriments? When supporting conditions such as destination, endowment, time and effort (gati, upadhi, kāla, payoga) come together, what is the cause of their arising? From what are they born? From what do they first spring?

The four nutriments have craving as their source. When supporting conditions such as destination, endowment, time and effort come together, they have craving as the cause of their arising. They are born of craving and first spring from craving.

Craving … pe … feeling, contact, the six sense bases, mentality-materiality, consciousness … pe …

What is the source of formations? When supporting conditions such as destination, endowment, time and effort come together, what is the cause of their arising? From what are they born? From what do they first spring?

Formations have ignorance as their source. When supporting conditions such as destination, endowment, time and effort come together, they have ignorance as the cause of their arising. They are born of ignorance and first spring from ignorance. (S I 253.)


<a id="M06-body-P147"></a>
## Discerning dependent origination in forward order, the second method
Miến / Burmese 147

Thus he taught dependent origination from the middle, that is, from the four nutriments, kamma-becoming or craving, back to ignorance at the beginning. (Abhidhamma Commentary II 124–125. Visuddhimagga II 154–155.)

Of these four ways of teaching dependent origination, the first forward method, from ignorance at the beginning to aging and death at the end, has already been presented in this book. The second forward method, from middle to end, follows.

2. The teaching on dependent origination in forward order, the second method (2).

“Bhikkhus, when that boy grows up and his faculties mature, he enjoys himself, provided and endowed with the five strands of sensual pleasure: sights cognizable by the eye that are wished for, desired, agreeable, pleasing, connected with sensuality and provocative of lust, sounds cognizable by the ear, odors cognizable by the nose, tastes cognizable by the tongue, and tangibles cognizable by the body that are wished for, desired, agreeable, pleasing, connected with sensuality and provocative of lust.”

“On seeing a sight with the eye, he lusts after a pleasing sight and becomes hostile toward a displeasing one. He dwells without mindfulness of the body established, with a limited mind. He does not understand as it actually is that liberation of mind and liberation by wisdom in which those evil unwholesome phenomena cease without remainder. Given over in this way to favoring and opposing, whatever feeling he feels, pleasant, painful, or neither painful nor pleasant, he delights in it, welcomes it, and remains fastened to it.”


<a id="M06-body-P148"></a>
## Feeling and attachment
Miến / Burmese 148

“When he delights in that feeling, welcomes it and remains fastened to it, delight arises. Delight in feelings is clinging. With that clinging as condition there is becoming, with becoming as condition there is birth, and with birth as condition aging and death, sorrow, lamentation, pain, grief and despair come to be. Such is the arising of this whole mass of suffering.” (M I 333.)

Bhikkhus … when the boy grows up and his faculties mature, he enjoys the five strands of sensual pleasure. They are sights known by eye-consciousness, sounds known by ear-consciousness, odors known by nose-consciousness, tastes known by tongue-consciousness and tangibles known by body-consciousness. These objects are wished for, desired, agreeable, pleasing, connected with sensuality and provocative of lust. Fully provided with all five strands, he revels in them.

When he sees a sight with the eye, he lusts after a pleasing sight and becomes hostile toward an unpleasing one. He lives with a limited mind and without mindfulness of the body established. Nor does he know as they actually are liberation of mind and liberation by wisdom, namely the liberated consciousness and wisdom of arahant fruition, in which the arisen unwholesome phenomena cease without remainder. Given over to favoring through lust and opposing through hatred, he experiences whatever feeling occurs, pleasant, painful or neither painful nor pleasant. He delights in the feeling, welcomes it as “excellent, excellent,” and remains fastened to it. Because he delights in it, welcomes it and remains fastened to it…


<a id="M06-body-P149"></a>
## Discernment starting from the six sense bases or feeling
Miến / Burmese 149

… delight and lust arise in his continuity. Delight and lust toward feelings is grasping, that is, clinging. With clinging as condition, becoming arises in his continuity. With becoming as condition, birth arises. With birth as condition, aging and death, sorrow, lamentation, pain, grief and despair arise and grow. Thus this entire mass of suffering, unmixed with happiness, arises and grows. (M I 333, Mahātaṇhāsaṅkhaya Sutta.)

(The same applies at the ear door and the other doors.)

In line with the teaching above, one may discern this presentation of dependent origination (1) starting from the six sense bases or (2) starting from feeling. This corresponds to the first method of discernment in forward order, from the section on the six sense bases through the section on aging and death.

1. The six sense bases, contact, feeling, (ignorance), craving, clinging and becoming, namely kamma-becoming (formations), belong to the present life.
2. Birth, aging and death belong to the first future life.

If the course of saṃsāra into the future still appears clearly:

1. The six sense bases, contact, feeling, (ignorance), craving, clinging and becoming, namely kamma-becoming (formations), belong to the first future life.
2. Birth, aging and death belong to the second future life.

In this way, understand the successive future lives as far as the end of saṃsāra. One can then turn to discern the course of saṃsāra into the past.


<a id="M06-body-P150"></a>
## Connecting cause and result in successive pairs of lives
Miến / Burmese 150

1. The six sense bases, contact, feeling, (ignorance), craving, clinging and becoming, namely kamma-becoming (formations), belong to the first past life.
2. Birth, aging and death belong to the present life.

1. The six sense bases, contact, feeling, (ignorance), craving, clinging and becoming, namely kamma-becoming (formations), belong to the second past life.
2. Birth, aging and death belong to the first past life.

1. The six sense bases, contact, feeling, (ignorance), craving, clinging and becoming, namely kamma-becoming (formations), belong to the third past life.
2. Birth, aging and death belong to the second past life.

Direct knowledge in this way toward the successive lives of saṃsāra in the past. This is discernment linking lives two at a time. If one can distinguish and discern in this way from the successive past lives up to the final future life, one can see how this corresponds to the first method of dependent origination. For birth is the arising of consciousness, mentality-materiality, the six sense bases, contact and feeling. Ignorance is included with craving and clinging, and formations are included in kamma-becoming. Put another way, craving, clinging and becoming comprise ignorance, craving, clinging, formations and kamma.

Thus a good person already proficient in the first forward method and in the fifth method of discerning dependent origination presented in Part (a) will find this second forward method easy to practice.


<a id="M06-body-P151"></a>
## Discerning dependent origination in reverse order, the first method
Miến / Burmese 151

3. From end to beginning — the teaching on dependent origination in reverse order (1).

This teaching proceeds in reverse order, from aging and death at the end back to ignorance at the beginning. In that reverse sequence:

1. Aging and death.
2. Birth.
These two phenomena belong to the future period.

3. Becoming.
4. Clinging.
5. Craving.
6. Feeling.
7. Contact.
8. The six sense bases.
9. Mentality-materiality.
10. Consciousness.
These phenomena belong to the present period.

11. Formations.
12. Ignorance.
These phenomena belong to the past period.

If one wishes to continue discerning into the future, one may discern as follows. Aging and death and birth belong to the second future period…


<a id="M06-body-P152"></a>
## Discerning three lives in reverse order
Miến / Burmese 152

Becoming, clinging, craving, feeling, contact, the six sense bases, mentality-materiality and consciousness belong to the first future period.

Formations and ignorance belong to the present period.

In this way, connect causes with their results and distinguish the causes and results as far as the end of the future. Then one can direct knowledge back toward the past course of saṃsāra:

Aging and death and birth belong to the present period.

Becoming, clinging, craving, feeling, contact, the six sense bases, mentality-materiality and consciousness belong to the first past period.

Formations and ignorance belong to the second past period.

Directing knowledge in this way toward the successive past lives in saṃsāra, distinguish causes and results as far as one's ability extends. This is discerning causes and results by tracing their links across three lives at a time. For one proficient in the first forward method, this discernment is also easy, since it consists in distinguishing them in reverse order.

Some examples of discernment.

Let the good person see with knowledge how aging and death arise because of birth, and distinguish cause and result as follows:

Because there is birth, there is aging and death. Birth is the cause, aging and death are the result.

Then look with knowledge at how birth arises because of kamma-becoming…


<a id="M06-body-P153"></a>
## Discerning in reverse order from middle to beginning. The four nutriments
Miến / Burmese 153

… and distinguish cause and result as follows. Because kamma-becoming arises, there is birth. Kamma-becoming is the cause, birth is the result. In this way discern in reverse order back to ignorance at the beginning.

4. From middle to beginning — the teaching on dependent origination in reverse order, the second method (2).

Four nutriments.

In explaining this method of discernment, the commentaries quote the Āhāra Sutta in the Nidānavagga of the Saṃyutta Nikāya. In that discourse, the Buddha taught dependent origination in reverse order from the four nutriments in the middle back to ignorance at the beginning. The four nutriments are therefore explained first:

1. Physical nutriment (kabaḷīkārāhāra) is food, coarse or fine, taken in mouthfuls or morsels. Even what need not be formed into a morsel is included with what is taken in morsels.

2. Contact as nutriment (phassāhāra) is nutriment in the sense of meeting the object.

3. Mental volition as nutriment (manosañcetanāhāra) is nutriment in the sense of impelling the mind.

4. Consciousness as nutriment (viññāṇāhāra) is nutriment in the sense of cognizing distinctly.

These are the four kinds of nutriment.

“The passage beginning ‘The four nutriments have craving as their source’ was stated with reference to contact and the others at rebirth-linking and during the course of life in the round of results, and to nutritive essence originating from kamma…”


<a id="M06-body-P154"></a>
## Nutriments of the round of results and other nutriments
Miến / Burmese 154

“… The other nutriments also have the foregoing meaning as their basis. Since they do not exist in the absence of craving as their source, they too can rightly be said to have craving as their source.” (Mūlaṭīkā II 85. Mahāṭīkā II 243.)

The four nutriments of the round of results, arising at rebirth-linking and in the course of life, are:

1. Contact as nutriment is contact associated with resultant consciousness.
2. Mental volition as nutriment is volition associated with resultant consciousness.
3. Consciousness as nutriment is resultant consciousness.
4. Physical nutriment is the kamma-born nutritive essence in the material groups produced by kamma.

It was with reference to those four that the Buddha taught the passage beginning “cattāro āhārā taṇhānidānā,” that is, these four nutriments have craving as their source. When referring to the four nutriments of the round of results, the statement has a meaning to be understood directly (nītattha).

Other nutriments, not produced by kamma, likewise often support through the force of decisive support (upanissaya), sustaining the continuity of suffering in saṃsāra, where the rounds of defilement, kamma and results turn without interruption. When craving as their source is absent, these nutriments cannot exist or arise in this sense either. Thus it is also appropriate to say that they have craving as their source. (Mūlaṭīkā II 85. Mahāṭīkā II 243.)


<a id="M06-body-P155"></a>
## Kamma-born and non-kamma-born nutriments
Miến / Burmese 155

Non-kamma-born nutriment (akammaja āhāra) is nutriment not taken up by kamma (anupādiṇṇaka āhāra).

“Whether these beings chew or do not chew, eat or do not eat, from rebirth-linking consciousness onward there is co-arisen kamma-born nutritive essence. It sustains them up to the seventh day. This is to be understood as physical nutriment taken up by kamma. Contact and the other nutriments are understood as taken up by kamma when they belong to results in the three planes, and as not taken up when they belong to wholesome, unwholesome or functional states in the three planes. The supramundane are spoken of by conventional usage.” (Saṃyutta Commentary II 23–24.)

“‘Co-arisen from rebirth-linking consciousness onward’ is a statement of the characteristic. It establishes that the nutritive essence included in kamma-born materiality exists in uninterrupted continuity. ‘Up to the seventh’ means that, from the day it arises through the seventh day, it sustains the material continuity by keeping the succession connected. ‘This very’ means the kamma-born nutritive essence. The nutritive essence that arises dependent on kamma-born essence is to be understood as nutriment not taken up by kamma, since it is not itself kamma-born.” (Saṃyutta Ṭīkā II 27.)

According to the explanations of the commentaries and subcommentaries above, the four nutriments in the round of results are nutriments taken up by kamma (upādiṇṇaka). The four nutriments not taken up by kamma, or non-kamma-born, are:

1. Contact as nutriment is contact associated with wholesome, unwholesome and functional consciousness.
2. Mental volition as nutriment is wholesome, unwholesome and functional volition.
3. Consciousness as nutriment is wholesome, unwholesome and functional consciousness.
4. Physical nutriment is nutritive essence produced by consciousness, temperature and nutriment.


<a id="M06-body-P156"></a>
## Physical nutriment and nutritive essence
Miến / Burmese 156

These four nutriments are non-kamma-born, that is, not taken up by kamma. They too are capable of sustaining suffering in the round of saṃsāra. In the absence of craving as their source, they cannot exist or arise in this sense. Therefore, in the sense that requires interpretation (neyyattha), it is also appropriate to say that they have craving as their source.

Physical nutriment (kabaḷīkārāhāra).

The nutriment-born nutritive essence is included in the nutritive essence not taken up by kamma described above. Understand that nutriment-born nutritive essence includes all four kinds:

1. Nutriment-born nutritive essence conditioned by kamma-born nutritive essence.
2. Nutriment-born nutritive essence conditioned by consciousness-born nutritive essence.
3. Nutriment-born nutritive essence conditioned by temperature-born nutritive essence.
4. Nutriment-born nutritive essence conditioned by nutriment-born nutritive essence.

A brief further explanation follows. The elders of old rendered kabaḷīkārāhāra as “nutriment as if formed into morsels or mouthfuls, even when there is no need to form it into morsels or mouthfuls.” This rendering carries a very deep meaning.

Material phenomena, or ultimate phenomena in general, do not move from one place to another. Once they arise, they immediately cease and dissolve where they arose. As for the nutriment that beings eat, such as rice, whether in a pot, bowl or plate, or in the mouth, throat or stomach…


<a id="M06-body-P157"></a>
## Temperature-born nutritive essence
Miến / Burmese 157

… or in the intestines as newly ingested food, it is simply an aggregate of temperature-born materiality with nutritive essence as the eighth constituent (utuja-ojaṭṭhamaka). These material phenomena arise continuously because of the fire element, also called temperature, in each material group. According to the nature of ultimate phenomena, they perish immediately after arising. The materiality present while chewing is one set, that present while swallowing another, and that present as newly ingested food yet another.

These ultimate phenomena do not last long enough to travel from plate to mouth, from mouth to throat, or from throat to stomach. Nor do they last long enough to form rice into a morsel and eat it. Yet as long as the supporting force of the fire element in the temperature-born groups called food is unspent, fresh temperature-born groups continue to arise in succession, one following another. Hence the elders rendered it “nutriment as if formed into morsels or mouthfuls, even when there is no need to form it into morsels or mouthfuls.”

When supported by the digestive fire element in the life nonads, the temperature-born nutritive essence in the groups of newly ingested food, called physical nutriment, generates fresh groups with nutritive essence as their eighth constituent. That digestive fire element is called kamma-born stomach fire and can digest the food in the abdomen. The materiality produced by that temperature-born nutritive essence is nutriment-born materiality. The nutritive essence in each such group is nutriment-born nutritive essence. When supported by the kamma-born stomach fire and that nutriment-born essence…


<a id="M06-body-P158"></a>
## The functions of the four nutriments
Miến / Burmese 158

… each of the kamma-born, consciousness-born, temperature-born and nutriment-born nutritive essences in the material groups in turn generates fresh groups with nutritive essence as the eighth constituent. These are nutriment-born materiality produced by the respective kinds of nutritive essence. The nutritive essence they contain is also nutriment-born. The case of nutriment-born essence supported by nutriment-born essence has already been stated.

1. Physical nutriment sustains, that is, produces materiality with nutritive essence as the eighth constituent.
2. Contact as nutriment sustains, that is, produces the three kinds of feeling.
3. Mental volition as nutriment sustains, that is, produces the three kinds of becoming.
4. Consciousness as nutriment sustains, that is, produces rebirth-linking mentality-materiality.

1. As explained above, physical nutriment sustains materiality by producing materiality with nutritive essence as the eighth constituent.

2. Contact as nutriment sustains pleasant feeling only when contact capable of producing pleasant feeling becomes manifest. It sustains painful feeling only when contact capable of producing painful feeling becomes manifest. It sustains equanimous feeling only when contact capable of producing equanimous feeling becomes manifest. Here “sustains” means “produces.” (Saṃyutta Commentary II 24.)


<a id="M06-body-P159"></a>
## Mental volition and consciousness as nutriment
Miến / Burmese 159

3. Mental volition as nutriment. Kamma capable of leading to sense-sphere becoming sustains, that is, produces it. Kamma capable of leading to fine-material and immaterial becoming sustains, that is, produces the kind of becoming corresponding to that kamma. Thus mental volition as nutriment sustains, that is, produces the three kinds of becoming. (Saṃyutta Commentary II 24.)

4. Consciousness as nutriment. At the rebirth-linking moment, consciousness sustains, that is, produces the associated mental aggregates and kamma-born materiality by the force of such conditions as conascence. (Saṃyutta Commentary II 24.)

“Ettha ca “manosañcetanā tayo bhave āharatī”ti sāsavakusalākusalacetanāva vuttā. “Viññāṇaṃ paṭisandhināmarūpaṃ āharatī”ti paṭisandhiviññāṇameva vuttaṃ. Avisesena pana taṃsampayuttataṃsamuṭṭhānadhammānaṃ āharaṇatopete “āhārā”ti veditabbā.”
In the statement “mental volition nourishes the three kinds of becoming,” only wholesome and unwholesome volition subject to the taints is intended. In “consciousness nourishes rebirth-linking mentality-materiality,” only rebirth-linking consciousness is intended. In the broader sense they are called nutriment because they nourish the associated phenomena and phenomena originating from them. (Saṃyutta Commentary II 25.)

“Sāsavakusalākusalacetanāva vuttā visesapaccayabhāvadassanatthena. Tenāha “avisesena panā”tiādi. Paṭisandhiviññāṇameva vuttanti etthāpi eseva nayo. Yathā taṃ taṃ phalaṃ visesato paccayatāya etesaṃ āhārattho, evaṃ avisesatopīti dassetuṃ “avisesenā”tiādi vuttaṃ.”
The first statement singles out wholesome and unwholesome volition subject to the taints to show their distinctive role as conditions. The second similarly singles out rebirth-linking consciousness. The words “in the broader sense” show that they also function as nutriment through conditioning their respective results. (Saṃyutta Subcommentary II 28–29.)

Understand that the statement that mental volition as nutriment sustains, that is, produces the three kinds of becoming refers specifically to wholesome and unwholesome volition that is an object of the taints capable of keeping the round of saṃsāra going…


<a id="M06-body-P160"></a>
## Nutriment in the specific and general senses
Miến / Burmese 160

… because they are distinctive causes that keep the round of saṃsāra going. In the general sense, all volition, whether wholesome, unwholesome or indeterminate, is a cause capable of producing the associated mental phenomena and consciousness-born materiality.

“Viññāṇaṃ paṭisandhināmarūpaṃ āharati” means that consciousness sustains, that is, produces rebirth-linking mentality-materiality. Here only rebirth-linking consciousness is specifically meant. In the general sense, consciousness is called nutriment because it sustains both the co-arisen associated phenomena and the corresponding consciousness-born materiality. (Saṃyutta Commentary II 25.)

1. Of the four nutriments, physical nutriment, that is, nutritive essence from the four origins, performs its function as nutriment, the function of sustaining, by supporting materiality of the four origins through producing fresh groups with nutritive essence as the eighth constituent.

2. Contact as nutriment performs its function as nutriment, sustaining feeling, only when it performs the function of contacting the object. Then it can produce feeling.

3. Mental volition as nutriment can perform the function of sustaining, that is, producing the three kinds of becoming only when it impels the mind and exerts enough force to link cause and result so that the result can arise.


<a id="M06-body-P161"></a>
## Nutriment sustains the material body
Miến / Burmese 161

4. By distinctly cognizing the object, consciousness, specifically rebirth-linking consciousness, can perform the function of nutriment by the power that manifests the aggregates and establishes rebirth, producing associated phenomena and kamma-born materiality, or consciousness-born materiality. (Saṃyutta Commentary II 25.)

1. When physical nutriment supports materiality of the four origins by producing materiality with nutritive essence as the eighth constituent, it is a cause for the continuance of beings because it keeps the material body going in uninterrupted succession. The body is indeed produced by kamma, yet if firmly supported by physical nutriment it can last for eighty or a hundred years, until the end of its lifespan. A child is born of its mother, yet can live long only if nursed and cared for by a wet nurse. Like a house that does not collapse when braced by a timber prop, the material body stands firm in dependence on nutriment. (Saṃyutta Commentary II 25.)

Thus physical nutriment performs its function by supporting materiality of the four origins. It conditions two material continuities: materiality originating from nutriment and materiality taken up by kamma, that is, kamma-born materiality. It supports kamma-born materiality through sustaining power (anupālakasatti), and nutriment-born materiality through directly productive power (janakasatti).

2. When contact as nutriment meets an object that provides the basis for pleasant feeling and other feelings…


<a id="M06-body-P162"></a>
## Two ways in which nutriment supports
Miến / Burmese 162

… it is a cause of the continuance of beings by producing pleasant feeling and other feelings.

3. When mental volition as nutriment builds up kamma by the force of wholesome and unwholesome kamma, it is a cause for the continuance of beings because it produces the underlying cause of becoming.

4. When consciousness as nutriment distinctly cognizes the object, it is a cause for the continuance of beings because it produces mentality-materiality. (Saṃyutta Commentary II 25.)

“Upādiṇṇarūpasantatiyā upatthambhaneneva utucittajarūpasantatīnampi upatthambhanaṃ siddhanti “dve rūpasantatiyo”ti vuttaṃ. Upatthambhanameva sandhāya “anupālako hutvā”ti ca vuttaṃ.”
When the continuity of materiality taken up by kamma is supported, the continuities of materiality born of temperature and consciousness are also supported. Hence the phrase “two material continuities.” “Acting as a sustainer” refers to support. Sustaining safeguards the body and keeps it in existence. (Saṃyutta Subcommentary II 29.)

The commentary above explains that physical nutriment supports materiality taken up by kamma, that is, kamma-born materiality, by sustaining power and nutriment-born materiality by productive power. Support of the kamma-born continuity also accomplishes support of the temperature-born and consciousness-born continuities. The explanation therefore shows how physical nutriment supports the two material continuities, the kamma-born and the nutriment-born, by the force of nutriment condition. The commentary refers to sustaining power specifically with the sense of support (upatthambhana). Only keeping the whole material body in existence, maintaining and guarding it, is termed sustaining (anupālanā). (Saṃyutta Subcommentary II 29.)

The essential point for discernment. (1) The four nutriments in the round of results…


<a id="M06-body-P163"></a>
## Discernment beginning from the four nutriments in the round of results
Miến / Burmese 163

… and (2) the four nutriments in the round of kamma. There are thus two ways of identifying the phenomena called nutriment.

The method of identifying the four nutriments of the round of results is explained in the commentary on the Āhāra Sutta (Saṃyutta Commentary II 27). The method of identifying the four nutriments of the round of kamma is also explained. (Saṃyutta Commentary II 24. Mūlaṭīkā II 86. Mahāṭīkā II 245.) To discern beginning with the four nutriments of the round of results, start with the four resultant phenomena at rebirth-linking as below. One may also discern in the same way beginning with resultant phenomena that arise throughout a lifetime.

If one took rebirth with joyful three-rooted consciousness, there are thirty-four mental phenomena and thirty kamma-born material phenomena at the moment of rebirth-linking. The four nutriments then are:

1. Physical nutriment is the kamma-born nutritive essence in the thirty kamma-born material phenomena.
2. Contact as nutriment is contact associated with rebirth-linking consciousness.
3. Mental volition as nutriment is volition associated with rebirth-linking consciousness.
4. Consciousness as nutriment is rebirth-linking consciousness.

Begin by distinguishing and discerning these four nutriments. Divided according to period, the discernment is as follows. (1) The four nutriments, those of the round of results, belong to the present. (2) Becoming, clinging, craving, feeling, contact, the six sense bases, mentality-materiality and consciousness belong to the first past life…


<a id="M06-body-P164"></a>
## Discernment beginning from the four nutriments in the round of kamma
Miến / Burmese 164

(3) Formations and ignorance belong to the second past life. Continue discerning successive past and future lives, distinguishing causes and results three lives at a time. One may also follow the same pattern beginning with the other four nutriments of the round of results.

To discern from the four nutriments of the round of kamma, start with the phenomena of that round that you yourself are cultivating for the future course of saṃsāra. For example, if you are cultivating much wholesome kamma with the aspiration to become a bhikkhu able to realize arahant fruition in the future, choose one readily discernible wholesome kamma. As that kamma is cultivated, the four nutriments arise as follows:

1. Physical nutriment is the individual nutritive essences of four origins among the fifty-four material phenomena of four origins in the heart when that kamma is performed. Put another way, it is the individual nutritive essences of four origins in the body.

2. Contact in that group of wholesome mental phenomena is contact as nutriment.
3. Volition is mental volition as nutriment.
4. The knowing consciousness, that is, wholesome consciousness, is consciousness as nutriment (that is, kamma consciousness…).


<a id="M06-body-P165"></a>
## Another explanation
Miến / Burmese 165

… kamma consciousness. Begin by distinguishing these four nutriments. Contact, volition and consciousness here belong to the group of wholesome formations known as kamma-becoming in the round of kamma.

1. Kamma-becoming, represented by the four nutriments, together with clinging, craving, (ignorance), feeling, contact, the six sense bases, mentality-materiality and consciousness (resultant consciousness), are present phenomena.
2. Formations and ignorance are phenomena of the first past life.
Apply this method to understand successive past and future lives.

“Alternatively, the nutriments to be generated by craving belong to the future period, craving and the others to the present, and formations and ignorance to the past.” (Mūlaṭīkā II 86. Mahāṭīkā II 244–245.)

Understand “four nutriments” (cattāro āhārā) in the Āhāra Sutta as the four nutriments arising at rebirth-linking in a future life. They will be produced by the craving cultivated in the present life, that is, by kamma encompassed by ignorance, craving and clinging. If that future rebirth-linking is joyful and three-rooted, it includes thirty-four rebirth-linking mental phenomena. Take as object the rebirth-linking moment of the future bhikkhu life to which you aspire, in which arahant fruition can be attained. Among the phenomena of that future rebirth-linking…


<a id="M06-body-P166"></a>
## The three periods in discernment from nutriment
Miến / Burmese 166

1. The kamma-born nutritive essence in kamma-born materiality is physical nutriment.
2. Contact associated with rebirth-linking consciousness is contact as nutriment.
3. Volition associated with rebirth-linking consciousness is mental volition as nutriment.
4. Rebirth-linking consciousness is consciousness as nutriment.

1. These four nutriments are phenomena of the future period.
2. Craving and the other phenomena that are causes of those four future nutriments, namely kamma-becoming, clinging, craving, feeling, contact, the six sense bases, mentality-materiality and consciousness, are phenomena of the present period.
3. Formations and ignorance are phenomena of the past period.

This interpretation includes all three periods: future, present and past. In this discernment, proceed in reverse order from the four nutriments of future rebirth-linking, distinguishing the relationship between result and cause step by step back to ignorance belonging to the past.

Why the teaching was given in four ways.

Question. Why did the Buddha present dependent origination in four different ways?

Answer. (1) Because the teaching on dependent origination is excellent and well presented in every respect…


<a id="M06-body-P167"></a>
## Two reasons for teaching in four ways
Miến / Burmese 167

… and (2) because the Buddha himself had attained omniscient knowledge and exceptional knowledge of teaching, through which he could make the teaching clear and distinguished. For these two reasons he taught dependent origination in four ways. (Visuddhimagga II 155. Abhidhamma Commentary II 125.)

The teaching on dependent origination is excellent in every respect. If a practitioner hears one of these four presentations and strives to practice accordingly, that person can penetrate the noble path, the phenomenon called what is to be rightly known. In other words, that person can penetrate the nature of dependent origination, which is to be rightly known.

Moreover, the Buddha possesses the four kinds of knowledge of intrepidity and the four kinds of analytical knowledge (paṭisambhidā). He attained mastery of four kinds of profundity:

1. Profundity of the teaching (dhammagambhīra) is the depth of the Pāli teaching.
2. Profundity of meaning (atthagambhīra) is the depth of the meaning of that Pāli teaching.
3. Profundity of exposition (desanāgambhīra) is the depth of the exposition adorned with many modes of expression and methods.
4. Profundity of penetration (paṭivedhagambhīra) is the depth of knowledge that penetrates the profound causal relationships of dependent origination…


<a id="M06-body-P168"></a>
## Why the Buddha taught from ignorance to aging and death
Miến / Burmese 168

… Having gained a firm footing in those four kinds of depth, he attained omniscient knowledge, through which the teaching is clear and distinguished. Having attained omniscient knowledge, the Buddha was able to teach the Dhamma by various methods. (Visuddhimagga II 155. Abhidhamma Commentary II 125.)

1. The first teaching of dependent origination in forward order (1).

The Blessed One in particular taught dependent origination in forward order from ignorance to aging and death. He repeatedly surveyed the innumerable beings susceptible to training who were bewildered about the distinctive condition that should be distinguished and known. It is the unbroken continuance of saṃsāra, in which causes such as ignorance relate to results such as formations, and the succession goes on without interruption.

(a) To show how the suffering of the round proceeds: owing to the appropriate causes starting with ignorance in each person's own continuity, the results starting with formations arise.
(b) To show the sequence in which the three rounds arise: the round of defilements, the round of kamma and the round of results…


<a id="M06-body-P169"></a>
## Why the Buddha taught from the middle to the end and from the end back to the beginning
Miến / Burmese 169

… Understand that he gave this teaching for these benefits. (Visuddhimagga II 155. Abhidhamma Commentary II 125.)

The second teaching of dependent origination in forward order (2).

This forward presentation begins in the middle, with craving arising conditioned by feeling, and goes as far as aging and death at the end. In the present life there are consciousness, mentality-materiality, the six sense bases, contact and feeling. Disciples have yet to see for themselves with the wisdom of right view how, from the arising of the causal phenomena, ignorance, craving, clinging, formations and kamma-becoming, the phenomena of the future period arise. Because those causes are present, he could point them out as evident causes here and now. He taught in order to show clearly how present causes relate to future results and how causal succession leads into the future period. (Visuddhimagga II 156. Abhidhamma Commentary II 125.)

3. The first teaching of dependent origination in reverse order (1).

The reverse presentation of dependent origination proceeds backward from aging and death at the end to ignorance at the beginning.

“How sorely these beings have fallen into suffering and hardship. They must be born, that is, take rebirth, they must age, they must die, and again they must pass away and again be born…”


<a id="M06-body-P170"></a>
## The great diamond-like insight knowledge
Miến / Burmese 170

… In this way beings fall into suffering and hardship. After entering the attainment of great compassion, he surveyed them repeatedly. He taught dependent origination in reverse order to show clearly the causes, beginning with birth, of the sufferings of the round, beginning with aging and death. He had personally known those causes with penetrating insight developed in sequence while still a Bodhisatta, before attaining the knowledge of the arahant path and omniscient knowledge. (Visuddhimagga II 155–156. Abhidhamma Commentary II 125.)

The great diamond-like insight knowledge (mahāvajiravipassanāñāṇa). While still a Bodhisatta intent on Buddhahood, during the day under the sāla trees on the full moon of Vesākha, the day on which he would become a Buddha, and in the last watch toward dawn, he used knowledge to collect the individual instances of ignorance in the continuities of beings throughout a trillion world systems, world system by world system, into a single group. He successively brought that group under the three characteristics, a turn as impermanent, a turn as suffering and a turn as non-self, discerning it repeatedly with insight.

Likewise, he collected the individual formations into one group, the individual instances of consciousness into another, and so collected the twelve factors of dependent origination into twelve groups and repeatedly discerned them with insight. This is the great diamond-like insight knowledge. Having penetrated them in this way, he clearly pointed out the causes such as birth of the sufferings of the round such as aging and death. For this benefit, the reverse teaching of dependent origination…


<a id="M06-body-P171"></a>
## From the four nutriments back to ignorance
Miến / Burmese 171

… was given. (For the great diamond-like insight knowledge, see the Majjhima Subcommentary III 275 onward.)

4. The second teaching of dependent origination in reverse order (2).

The Āhāra Sutta presents the second reverse method, going back from the middle, the four nutriments, or, put another way, from craving, to ignorance at the beginning. He distinguished the source of each kind of nutriment in turn so that the disciples exerting themselves in meditation could establish it in their knowledge. In sequence he led the Āhāra Sutta teaching back into the past, to ignorance and formations that had arisen in the past. Then, starting from ignorance in the past period, he showed clearly the sequence connecting causes and results. For this benefit he gave the teaching. (Visuddhimagga II 156. Abhidhamma Commentary II 125.)

Closing exhortation.

Dependent origination, the causal relationship called the wheel of becoming, shows how the wheel of saṃsāra turns. Its depth makes it difficult to gain a footing in it. Its particular connections are thickly interwoven like a thicket, making it difficult to cross and to understand.

That turning wheel of saṃsāra, the wheel of becoming, constantly presses and torments like a wheel of lightning, tangled and entwined. Unless one wields the sword of wisdom sharpened on the whetstone of noble concentration…


<a id="M06-body-P172"></a>
## The Buddha’s words on the depth of dependent origination
Miến / Burmese 172

… unless one breaks through with that sword sharpened to a keen edge, that is, unless one personally penetrates it with knowledge of understanding (anubodhañāṇa) and knowledge of penetration (paṭivedhañāṇa), there has never been anyone who could escape the great peril of suffering in the round of saṃsāra, even in a dream.

Indeed, the Buddha taught these words:

“Ānanda … this dependent origination, this causal relationship, is profound and appears profound. Ānanda … through failing to understand dependent origination properly with the full understanding of the known (ñātapariññā), and failing to penetrate it with full understanding by scrutiny (tīraṇapariññā) and by abandoning (pahānapariññā), these beings become like tangled thread, like a bird’s nest, and like tangled muñja and babbaja grasses. They do not escape the states of loss, bad destinations, places of downfall, and the round of saṃsāra.” (D II 47.)

Thus the Buddha taught. Therefore, one who practices wisely for one’s own welfare and happiness and for that of others should set other undertakings aside and strive to fulfill the knowledge of understanding and penetration of the nature of dependent origination, the relationship of cause and result.

In the Buddha’s dispensation, the wise good person should discern the very profound nature of dependent origination, with the various powers and circumstances through which causal phenomena support the arising of resultant phenomena…


<a id="M06-body-P173"></a>
## Closing words and colophon
Miến / Burmese 173

… By exerting oneself properly in this way one can gain a firm footing through knowledge. With the proper effort through which one gains such a footing, be endowed at all times with mindfulness and clear comprehension and exert yourself in practice again and again. (Visuddhimagga II 221. Abhidhamma Commentary II 189.)

Pa-Auk Tawya Sayadaw
Cittala Hill Monastery
Pa-Auk Forest
Myanmar Era 1367.


<a id="M06-index-P001"></a>
## Index — Burmese page 174
Chỉ mục / Index - Miến / Burmese 174

[Blank page in the index PDF.]


<a id="M06-index-P002"></a>
## Index — Burmese page 175
Chỉ mục / Index - Miến / Burmese 175

Alphabetical index of points worth remembering, in Burmese order

[အ]

Non-kamma-born nutriment = nutriment not taken up by kamma — 155

Doctrine of non-action (akiriyavāda) — 50

Benefits and merits — 44

Beginning to end, forward dependent origination (1) — 142

What is called a link — 66

Three links — 66

End to beginning, reverse dependent origination (1) — 151

End to beginning, teaching dependent origination in reverse (1) — 144

Clinging to a doctrine of self (attavādupādāna) — 124

Three periods — 65

Commentary on the future round — 121

Sustaining power (anupālakasatti) — 161

What is called sustaining (anupālanā) — 162

Forward dependent origination, second method (2) — 147, 169

Forward dependent origination, first method (1) — 168

Imperturbable formations (āneñjābhisaṅkhāra) — 8

What is called consciousness of kamma formations (abhisaṅkhāraviññāṇa) — 78

Original source (pabhava) — 146

Spontaneously arisen beings (opapātika) — 135

The noble path — 55

The practice of the middle way — 55

From the middle back to the beginning

Middle to beginning, reverse dependent origination (2) — 145

Middle to end, forward dependent origination (2) — 143

Four groups — 67

Ignorance conditions formations — 72

What ignorance is — 7

The method of inseparability (avinābhāva) — 41

Doctrine of causelessness (ahetuvāda) — 47


<a id="M06-index-P003"></a>
## Index — Burmese page 176
Chỉ mục / Index - Miến / Burmese 176

[အာ]

Imperturbable formations (āneñjābhisaṅkhāra) — 8

The six sense bases (āyatana) — 11

Accumulation of formations (āyūhanasaṅkhāra) — 82

The four nutriments — 153

Functions of the four nutriments — 158

Four kinds of nutriment-born nutritive essence — 156

What is called nutriment-born materiality — 98

What nutriment is — 156

[ဥ …]

Annihilationism (ucchedavāda) — 49

Later part of knowledge of rise and fall (udayabbayañāṇa) — 68

Initial part of knowledge of rise and fall (udayabbayañāṇa) — 69

Supporting quality (upatthambhaka) — 92

Rebirth-becoming (upapattibhava) — 129

Clinging conditions becoming — 128

Four kinds of clinging — 13

What despair is — 19

What aging (jarā) is — 16

[က]

Physical nutriment — 156

Physical nutriment — 158

Kamma-becoming — 14, 128

Kamma consciousness = consciousness of kamma formations — 79

Kamma consciousness — 78

Discernment from the four nutriments in the round of kamma — 164

Craving for sensuality — 122

Clinging to sensuality — 124

What is called clinging to sensuality — 128

What bodily formations are — 9

Nine kinds of becoming — 15

One’s own — 71

Pāli meaning to keep in mind — 5

Discernment to understand beforehand — 68

[ခ]

Taking a shortcut or losing the way — 24

Like a cord binding the feet — 172

Twenty aspects — 68

One way to divide the phenomena for discernment, an example — 126

[စ]

Eye-door process, resultant mentality-materiality — 81


<a id="M06-index-P004"></a>
## Index — Burmese page 177
Chỉ mục / Index - Miến / Burmese 177

Eye-door process, resultant consciousnesses — 76

Eye-contact is contact associated with eye-consciousness — 109

Feeling born of eye-contact and feeling conditioned by eye-contact — 113

Like a bird’s nest — 172

Mental formations (cittasaṅkhāra) — 9

The lesser stream-enterer — 130

Sorrow as grief in the mind — 17

[ဇ]

Productive power (janakasatti) — 161

Regional usage (janapadanirutti) — 60

What is called regional usage — 60

Birth conditions aging and death, an example of discernment — 136

What birth is — 67

[တ]

Cognitive process patterns for craving and clinging — 127

Craving conditions clinging — 123

Six kinds of craving — 13

The phenomenon that conditions that very phenomenon (tappaccayadhamma) — 32

Closing exhortation — 171

Another explanation — 165

[ထ]

Further explanation — 35, 53

[ဒ]

Clinging to views — 124

What is called clinging to views — 128

What pain is — 18

What grief is — 19

[ဓ]

Craving for mental objects — 122

What craving for mental objects is — 126

[န]

Nihilism (natthikavāda) — 49

Mentality-materiality conditions the six sense bases — 87

The middle way leading to Nibbāna — 23

Meaning requiring interpretation (neyyattha) — 156

Another explanation — 33


<a id="M06-index-P005"></a>
## Index — Burmese page 178
Chỉ mục / Index - Miến / Burmese 178

Patterns for discernment — 104

How mentality conditions the mind base — 88

How the material sense bases arise conditioned by mentality — 90

Mentality and materiality — 80

How the mind base arises conditioned by mentality-materiality — 102

What mentality-materiality is — 10

[ပ]

What is called a conditioning phenomenon (paccayadhamma) — 26

What is called a conditionally arisen phenomenon (paccayuppannadhamma) — 26

What is called a condition (paccaya) — 32

Five-door adverting, mind-contact with a visible object — 108, 109

Meaning of paṭicca — 44

What is called paṭicca — 30

Dependently arisen phenomena (paṭiccasamuppanna) — 25

The two terms paṭicca and samuppāda — 52

The twelve factors of dependent origination — 65

Explanation of the term paṭiccasamuppāda — 30

What the teaching of dependent origination is — 21

Four ways of teaching dependent origination — 142

What is called dependent origination — 31

Pāli on the cycle of dependent origination, analysis according to the discourses (suttantabhājanīya) — 1

What dependent origination is — 24

Reverse dependent origination, second method (2) — 153, 171

Reverse dependent origination, first method (1) — 169

Analytical knowledge (paṭisambhidāñāṇa) — 167

Aspiring volition (paṭṭhāpakacetanā) — 82

Mind-contact of the first impulsion, visible object, wholesome impulsion — 110

Mind-contact of the first registration, visible object — 111

What lamentation is — 18

What is called suffering during the course of life (pavattidukkha) — 24

What meritorious formations (puññābhisaṅkhāra) are — 8

Projection equipment and its fittings — 106


<a id="M06-index-P006"></a>
## Index — Burmese page 179
Chỉ mục / Index - Miến / Burmese 179

The doer and the experiencer — 55

[ဖ]

Contact conditions feeling — 113

Six kinds of contact — 11

Contact as nutriment — 158

[ဘ]

Craving for becoming — 123

Becoming conditions birth — 133

[မ]

The middle way — 53

The path of the middle way — 22

Mind-door process — 72

Mind-contact associated with mind-door adverting, visible object — 111

Series of mind-door processes with impulsion — 132

Mental volition as nutriment — 92, 159

What is called mind-contact — 105

What mind-contact is — 117

What death is — 16

The Greater Discourse on the Destruction of Craving (Mahātaṇhāsaṅkhaya Sutta) — 149

Great diamond-like insight knowledge — 170

The great dangers of wrong view — 52

A point for inquiry — 134

Like a wheel of lightning — 171

[ယ]

The four men — 142

[ရ]

Like a wheel — 45

In the continuity of arahants — 122

Material groups and mental groups — 40

How the mind base arises conditioned by materiality — 98

How the material sense bases arise conditioned by materiality — 97

Brief examples of discernment — 134, 137

Some examples of discernment — 80, 99, 103, 121, 132, 152

Example of discernment, mind-contact at rebirth-linking — 107

Examples of discernment, process-free consciousness — 76

The essential point for discernment — 162


<a id="M06-index-P007"></a>
## Index — Burmese page 180
Chỉ mục / Index - Miến / Burmese 180

[လ]

A pattern of discernment to keep in mind — 131

Why the teaching was given in four ways — 166

Conventional truth of the world (lokasammutisacca) — 63

[ဝ]

Verbal formations — 9

Doctrine of an almighty ruler (vasavattivāda) — 47

Various doctrines — 46

Consciousness conditions mentality-materiality — 77

Consciousness as nutriment — 159

Consciousness — 74

Six kinds of consciousness — 10

Discernment from the four nutriments in the round of results — 163

Resultant consciousness = mind-consciousness — 75

Six kinds of resultant consciousness — 74

Craving for non-becoming — 123

Doctrine of a disparate cause (visamahetuvāda) — 47

Mind-contact associated with restlessness, visible object — 110

Feeling conditions craving — 118

Six kinds of feeling — 12

Six kinds of feeling — 113

The three rounds — 45

[သ]

Formations and kamma-becoming are kamma — 81

Formations condition consciousness — 73

Becoming with perception — 14

A point to note — 128

One point to note — 129

What a being is — 62

Mind-contact associated with doubt, visible object — 110

Records on phenomena with intrinsic natures — 29

What intrinsic causal capacity is — 74

Conditions for acceptance — 44

Samaññā anatidhāvanaṃ, not overstepping conventional usage — 62

The term samuppāda — 48

Also called samuppāda — 30

Meaning of saṃ — 41

Mind-contact in the greed group associated with wrong view, visible object — 110

Base of the associated phenomena — 108

Right view — 53

Right effort — 54


<a id="M06-index-P008"></a>
## Index — Burmese page 181
Chỉ mục / Index - Miến / Burmese 181

Right intention — 53

Right mindfulness — 54

Right concentration — 54

What is called going astray — 32

Eternalism (sassatavāda) — 46

Meaning of saha — 41

How co-arisen mentality-materiality arises conditioned by co-arisen consciousness — 83

Co-arisen consciousness — 78

The six sense bases condition contact — 105

Clinging to rules and observances — 124

What is called clinging to rules and observances — 128

Sorrow, lamentation, pain, grief and despair — 137

Cognitive processes of sorrow, lamentation, grief and despair — 141

[ဟ]

Group of causes (hetusamūha) — 34
