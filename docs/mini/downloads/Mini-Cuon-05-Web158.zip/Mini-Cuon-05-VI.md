# Nibbānagāminipaṭipadā · Mini · Cuốn 5 / Volume 5
Phần Duyên khởi (Paṭiccasamuppāda) — A
Pa-Auk Tawya Sayadaw
Việt

## Mục lục / Contents

- [Bìa trước và bìa sau](#M05-cover-P001)
- [Trang nhan đề](#M05-front-P001)
- [Pháp thí và lời nguyện](#M05-front-P002)
- [Mục lục — trang đầu](#M05-front-P003)
- [Mục lục — ခ](#M05-front-P004)
- [Mục lục — ဂ](#M05-front-P005)
- [Mục lục — ဃ](#M05-front-P006)
- [Mục lục — င](#M05-front-P007)
- [Mục lục — စ](#M05-front-P008)
- [Mục lục — ဆ](#M05-front-P009)
- [Phần 1. Lời tuyên bố trong Kinh Đại Duyên](#M05-body-P001)
- [Bốn cách quán Duyên khởi và lời Tôn giả Ānanda](#M05-body-P002)
- [Duyên khởi sâu xa và ba loại liễu tri](#M05-body-P003)
- [Phá vỡ bánh xe hữu bằng lưỡi gươm trí tuệ](#M05-body-P004)
- [Vì sao Duyên khởi hiện rõ đối với Tôn giả Ānanda?](#M05-body-P005)
- [Các trợ duyên đời trước và sự nương nơi bến lành](#M05-body-P006)
- [Học pháp nơi bậc thầy và thành tựu Nhập lưu](#M05-body-P007)
- [Tự mình thấy mối liên hệ nhân quả](#M05-body-P008)
- [Sự đa văn và trí phân định danh sắc](#M05-body-P009)
- [Tài sản nghe học](#M05-body-P010)
- [Trí nắm bắt các duyên và ba loại liễu tri hiệp thế](#M05-body-P011)
- [Liễu tri bằng nhận biết, thẩm sát và đoạn trừ](#M05-body-P012)
- [Ba loại liễu tri siêu thế](#M05-body-P013)
- [Liễu tri bằng thẩm sát ở tầng siêu thế](#M05-body-P014)
- [Hiểu theo nhờ trí sinh khởi nhiều lần](#M05-body-P015)
- [Phận sự của Thánh đạo và sự trực tiếp thấy các duyên](#M05-body-P016)
- [Tóm lược Duyên khởi theo phương pháp thứ năm](#M05-body-P017)
- [Năm nhân quá khứ và năm quả hiện tại](#M05-body-P018)
- [Năm nhân hiện tại và năm quả tương lai](#M05-body-P019)
- [Năm nhân và năm quả qua ba thời](#M05-body-P020)
- [Tập đế được trình bày theo năm cách](#M05-body-P021)
- [Chuỗi Duyên khởi và Thánh đế về nguồn gốc khổ](#M05-body-P022)
- [Ái nào là nguồn gốc của khổ hiện tại?](#M05-body-P023)
- [Phân biệt hành và nghiệp hữu](#M05-body-P024)
- [Tư, hành và sức mạnh của nghiệp duyên](#M05-body-P025)
- [Nghiệp khác sát-na và thời điểm trổ quả](#M05-body-P026)
- [Vì sao gọi là nghiệp duyên khác sát-na?](#M05-body-P027)
- [Duyên quá khứ và thời gian tích lũy ba-la-mật](#M05-body-P028)
- [Suy luận và trực chứng](#M05-body-P029)
- [Biết bốn Thánh đế đúng như thật](#M05-body-P030)
- [Hai đế thuộc luân hồi và hai đế thoát luân hồi](#M05-body-P031)
- [Điều kiện để chấm dứt khổ](#M05-body-P032)
- [Nỗ lực trực chứng bốn Thánh đế](#M05-body-P033)
- [Để đạt trí nắm bắt các duyên](#M05-body-P034)
- [Nghiệp riêng, quả riêng, và hai cách biết quá khứ](#M05-body-P035)
- [Nhớ lại đời trước theo Kinh Khajjanīya](#M05-body-P036)
- [Các đối tượng của thắng trí nhớ đời trước](#M05-body-P037)
- [Quán các uẩn quá khứ bằng tuệ minh sát](#M05-body-P038)
- [Phần 2. Một trình tự tìm các nhân](#M05-body-P039)
- [Quán các quả trước khi tìm nhân](#M05-body-P040)
- [Danh sắc quá khứ, hiện tại và tương lai](#M05-body-P041)
- [Bốn cách thuyết Duyên khởi](#M05-body-P042)
- [Chiều nghịch và phương pháp thứ năm](#M05-body-P043)
- [Lần từ giữa về đầu và nguyên tắc nhiều nhân nhiều quả](#M05-body-P044)
- [Vì sao bài pháp có khi chỉ nêu một nhân?](#M05-body-P045)
- [Quán cả những pháp tương ưng](#M05-body-P046)
- [Dùng định và ánh sáng để quán danh sắc](#M05-body-P047)
- [Các cách tiếp tục tìm nhân quá khứ](#M05-body-P048)
- [Phát nguyện và quán danh sắc trước khi ngồi thiền](#M05-body-P049)
- [Quán danh sắc vừa qua đối với người lấy thiền chỉ làm cỗ xe](#M05-body-P050)
- [Vòng phiền não và vòng nghiệp](#M05-body-P051)
- [Ba pháp thuộc vòng phiền não](#M05-body-P052)
- [Hai pháp thuộc vòng nghiệp](#M05-body-P053)
- [Sức nghiệp và trường hợp phát nguyện cõi phạm thiên](#M05-body-P054)
- [Trình tự thực hành khi thấy một hình ảnh](#M05-body-P055)
- [Lần về danh sắc quá khứ từng bước](#M05-body-P056)
- [Từ tái tục đến sát-na cận tử của đời trước](#M05-body-P057)
- [Tìm cảnh cận tử và lần về nghiệp làm nhân](#M05-body-P058)
- [Khi hình ảnh người sắp chết hoặc thi thể hiện ra](#M05-body-P059)
- [Tìm đối tượng của tốc hành cận tử](#M05-body-P060)
- [Tìm dòng tâm lúc tạo nghiệp](#M05-body-P061)
- [Năm nhân trong lời nguyện của công chúa Sumanā](#M05-body-P062)
- [Năm nhân trong lời nguyện của Anojādevī](#M05-body-P063)
- [Quả của lời nguyện Anojā và chuyện hoàng hậu Subhaddā](#M05-body-P064)
- [Hai voi cái và duyên của việc cúng dường](#M05-body-P065)
- [Sự bố thí hội đủ duyên và lời nguyện của Cūḷasubhaddā](#M05-body-P066)
- [Lời nguyện trả oán và năm pháp làm nhân](#M05-body-P067)
- [Voi chúa Chaddanta và người thợ săn Soṇuttara](#M05-body-P068)
- [Một ví dụ của hành giả](#M05-body-P069)
- [Phân biệt nhân quả và một ví dụ khác](#M05-body-P070)
- [Nghiệp minh sát và lời nguyện](#M05-body-P071)
- [Nghiệp minh sát có thể cho quả tái tục](#M05-body-P072)
- [Miến 73](#M05-body-P073)
- [Miến 74](#M05-body-P074)
- [Miến 75](#M05-body-P075)
- [Miến 76](#M05-body-P076)
- [Miến 77](#M05-body-P077)
- [Miến 78](#M05-body-P078)
- [Hai pháp thuộc nghiệp luân](#M05-body-P079)
- [Miến 80](#M05-body-P080)
- [Phần tuệ phân biệt nhân duyên](#M05-body-P081)
- [Miến 82](#M05-body-P082)
- [Miến 83](#M05-body-P083)
- [Sự thay đổi của tướng](#M05-body-P084)
- [Cách quán các pháp nhân và quả](#M05-body-P085)
- [Điểm chính cần ghi nhớ](#M05-body-P086)
- [Sắc uẩn](#M05-body-P087)
- [Bốn danh uẩn](#M05-body-P088)
- [Miến 89](#M05-body-P089)
- [Bốn phương pháp — 1. Phương pháp đồng nhất](#M05-body-P090)
- [Miến 91](#M05-body-P091)
- [Đặc tính của đời quá khứ](#M05-body-P092)
- [Ánh sáng rộng và mạnh khi quán đời trước](#M05-body-P093)
- [Miến 94](#M05-body-P094)
- [Miến 95](#M05-body-P095)
- [Khi thấy ba hoặc bốn người](#M05-body-P096)
- [Miến 97](#M05-body-P097)
- [Đoạn kiến và thường kiến](#M05-body-P098)
- [Miến 99](#M05-body-P099)
- [2. Phương pháp sai biệt](#M05-body-P100)
- [Miến 101](#M05-body-P101)
- [Miến 102](#M05-body-P102)
- [3. Phương pháp vô tác giả](#M05-body-P103)
- [Miến 104](#M05-body-P104)
- [Miến 105](#M05-body-P105)
- [4. Phương pháp tính quy luật](#M05-body-P106)
- [Thuyết định mệnh](#M05-body-P107)
- [Miến 108](#M05-body-P108)
- [Phần 3. Thực hành quán theo phương pháp năm uẩn](#M05-body-P109)
- [Cách nhóm thành năm uẩn](#M05-body-P110)
- [Năm thủ uẩn](#M05-body-P111)
- [Năm uẩn ở sát-na tái tục](#M05-body-P112)
- [Miến 113](#M05-body-P113)
- [Cách quán nhân nối với quả](#M05-body-P114)
- [Sắc uẩn tái tục](#M05-body-P115)
- [Miến 116](#M05-body-P116)
- [Thọ uẩn tái tục](#M05-body-P117)
- [Cách trình bày tóm tắt](#M05-body-P118)
- [Tái tục — Thọ uẩn](#M05-body-P119)
- [Miến 120](#M05-body-P120)
- [Vật và cảnh](#M05-body-P121)
- [Cảnh và xúc](#M05-body-P122)
- [Miến 123](#M05-body-P123)
- [Tái tục — Tưởng uẩn](#M05-body-P124)
- [Tái tục — Hành uẩn, cách thứ nhất](#M05-body-P125)
- [Tái tục — Hành uẩn, cách thứ hai](#M05-body-P126)
- [Tái tục — Thức uẩn](#M05-body-P127)
- [Miến 128](#M05-body-P128)
- [Năm uẩn hữu phần](#M05-body-P129)
- [Hữu phần — Sắc uẩn](#M05-body-P130)
- [Hữu phần — Thọ uẩn](#M05-body-P131)
- [Hữu phần — Tưởng uẩn và hành uẩn](#M05-body-P132)
- [Hữu phần — Hành uẩn và thức uẩn](#M05-body-P133)
- [Hướng ngũ môn — Sắc uẩn](#M05-body-P134)
- [Hướng ngũ môn — Thọ uẩn và tưởng uẩn](#M05-body-P135)
- [Hướng ngũ môn — Hành uẩn](#M05-body-P136)
- [Hướng ngũ môn — Thức uẩn](#M05-body-P137)
- [Nhãn thức — Sắc uẩn và thọ uẩn](#M05-body-P138)
- [Nhãn thức — Các nhân của thọ uẩn](#M05-body-P139)
- [Nhãn thức — Ánh sáng và tưởng uẩn](#M05-body-P140)
- [Nhãn thức — Hành uẩn và thức uẩn](#M05-body-P141)
- [Năm uẩn ở tâm tiếp thọ](#M05-body-P142)
- [Tiếp thọ — Thọ uẩn, tưởng uẩn và hành uẩn](#M05-body-P143)
- [Tiếp thọ — Hành uẩn và thức uẩn](#M05-body-P144)
- [Năm uẩn ở tâm suy đạc](#M05-body-P145)
- [Suy đạc — Thọ uẩn và tưởng uẩn](#M05-body-P146)
- [Suy đạc — Hành uẩn](#M05-body-P147)
- [Suy đạc — Thức uẩn và năm uẩn ở tâm xác định](#M05-body-P148)
- [Xác định — Thọ uẩn và tưởng uẩn](#M05-body-P149)
- [Xác định — Hành uẩn](#M05-body-P150)
- [Xác định — Thức uẩn và tác ý dẫn đầu tốc hành](#M05-body-P151)
- [Tác ý dẫn đầu tốc hành và năm uẩn ở tốc hành thiện thứ nhất](#M05-body-P152)
- [Tốc hành đại thiện thứ nhất — Thọ uẩn](#M05-body-P153)
- [Tốc hành đại thiện thứ nhất — Tưởng uẩn và hành uẩn](#M05-body-P154)
- [Tốc hành đại thiện thứ nhất — Hành uẩn và thức uẩn](#M05-body-P155)
- [Số danh pháp và duyên vô gián](#M05-body-P156)
- [Tốc hành đại thiện thứ hai — Thọ uẩn](#M05-body-P157)
- [Năm uẩn ở tâm đăng ký](#M05-body-P158)
- [Tâm đăng ký đại quả thứ nhất — Thọ, tưởng và hành uẩn](#M05-body-P159)
- [Tâm đăng ký đại quả thứ nhất — Thức uẩn](#M05-body-P160)
- [Số danh pháp ở tâm đăng ký và lộ ý môn](#M05-body-P161)
- [Hướng ý môn và tốc hành đại thiện thứ nhất](#M05-body-P162)
- [Tốc hành đại thiện thứ nhất và thứ hai trong lộ ý môn](#M05-body-P163)
- [Giải thích về nhãn xúc và ý xúc](#M05-body-P164)
- [Nhãn xúc làm duyên cho bốn danh uẩn](#M05-body-P165)
- [Ý xúc trong lộ ý môn](#M05-body-P166)
- [Năm uẩn ở tốc hành tham hợp tà kiến](#M05-body-P167)
- [Tốc hành tham hợp tà kiến thứ nhất — Thọ uẩn và thức uẩn](#M05-body-P168)
- [Tốc hành tham hợp tà kiến thứ hai](#M05-body-P169)
- [Thức uẩn và lưu ý khi chuyển sang cảnh khác](#M05-body-P170)
- [Cảnh thinh và những điểm thay đổi theo cảnh](#M05-body-P171)
- [Cảnh thinh — Thọ uẩn của nhĩ thức](#M05-body-P172)
- [Giới hư không và hành uẩn của tâm tiếp thâu](#M05-body-P173)
- [Cảnh thinh — Hành uẩn và thức uẩn của tâm tiếp thâu](#M05-body-P174)
- [Cảnh thinh — Thức uẩn của tâm tiếp thâu và thọ uẩn của tâm suy đạc](#M05-body-P175)
- [Từ cảnh thinh sang cảnh hương](#M05-body-P176)
- [Cảnh hương — Thọ uẩn của tỷ thức](#M05-body-P177)
- [Giới gió và tâm tiếp thâu trong lộ cảnh hương](#M05-body-P178)
- [Cảnh hương — Thọ uẩn của tâm suy đạc](#M05-body-P179)
- [Cảnh vị — Thọ uẩn của tâm hướng ngũ môn và thiệt thức](#M05-body-P180)
- [Giới nước và tâm tiếp thâu trong lộ cảnh vị](#M05-body-P181)
- [Cảnh vị và cảnh xúc — Thọ uẩn](#M05-body-P182)
- [Cảnh xúc — Thọ uẩn của thân thức và giới đất](#M05-body-P183)
- [Cảnh xúc — Giới đất và tâm tiếp thâu](#M05-body-P184)
- [Cảnh xúc và cảnh pháp — Thọ uẩn](#M05-body-P185)
- [Cảnh pháp — Thọ uẩn của tốc hành thứ nhất và thứ hai](#M05-body-P186)
- [Lộ chứng sơ thiền với tợ tướng hơi thở](#M05-body-P187)
- [Tợ tướng thiền chỉ và sắc pháp làm cảnh](#M05-body-P188)
- [Từng nghiệp và từng phần quả](#M05-body-P189)
- [Quán bên ngoài và qua nhiều đời](#M05-body-P190)
- [Hạt giống hạnh và hạt giống minh](#M05-body-P191)
- [Nhân vô gián của hữu phần](#M05-body-P192)
- [Đạt đến tuệ liễu tri bằng nhận biết](#M05-body-P193)
- [Nhân và quả trong ba thời](#M05-body-P194)
- [Bén rễ trong Giáo pháp](#M05-body-P195)
- [Các duyên thích hợp và cách quán trong oai nghi](#M05-body-P196)
- [Lời nguyện cuối cuốn](#M05-body-P197)
- [Chỉ mục — Miến 198](#M05-index-P001)
- [Chỉ mục theo thứ tự chữ cái Miến — 199](#M05-index-P002)
- [Chỉ mục theo thứ tự chữ cái Miến — 200](#M05-index-P003)
- [Chỉ mục theo thứ tự chữ cái Miến — 201](#M05-index-P004)
- [Chỉ mục theo thứ tự chữ cái Miến — 202](#M05-index-P005)
- [Chỉ mục theo thứ tự chữ cái Miến — 203](#M05-index-P006)
- [Chỉ mục theo thứ tự chữ cái Miến — 204](#M05-index-P007)
- [Chỉ mục theo thứ tự chữ cái Miến — 205](#M05-index-P008)
- [Chỉ mục theo thứ tự chữ cái Miến — 206](#M05-index-P009)
- [Chỉ mục theo thứ tự chữ cái Miến — 207](#M05-index-P010)

<a id="M05-cover-P001"></a>
## Bìa trước và bìa sau
Bìa / Cover

Nibbānagāminipaṭipadā — Đường đến Niết-bàn (bản lược), Cuốn 5. Phần Duyên khởi (Paṭiccasamuppāda) — A. Thiền sư Pa-Auk Tawya.

Pháp Duyên khởi

Đức Phật không lập ra hay tạo nên quy luật Duyên khởi này. Dù chư Phật xuất hiện hay không xuất hiện, quy luật ấy vẫn tồn tại. Chỉ khi chư Phật xuất hiện, nhờ các Ngài khai thị và thuyết giảng, chúng sinh mới có dịp biết đến pháp này. Nếu Đức Phật không xuất hiện, hoặc có xuất hiện mà người ta không được nghe pháp, hoặc đã nghe mà vẫn chấp chặt những tà kiến như thường kiến và đoạn kiến, thì họ không thể hiểu được quy luật Duyên khởi này.

Pháp Duyên khởi sâu xa, có vẻ sâu xa, khó hiểu, có vẻ khó hiểu. Khi Tôn giả Ānanda nói pháp ấy dễ hiểu và nông cạn, Đức Phật ngăn lại: “Mā hevaṃ, Ānanda … Này Ānanda, chớ nói như vậy.” Dù pháp này khó hiểu và sâu xa đến đâu, ai chưa biết rõ Duyên khởi thì không thể thoát khỏi khổ luân hồi. Ai chưa biết pháp này thì chưa xứng đáng được gọi là sa-môn hay bà-la-môn.

Chư Phật đã xuất hiện, đang xuất hiện và sẽ xuất hiện thành tựu Phật quả nhờ biết rõ pháp Duyên khởi. Chừng nào chúng sinh còn chưa biết rõ pháp này, họ còn rơi vào một trong hai vực sâu là thường kiến và đoạn kiến, và còn phải chịu mọi nỗi khổ. Vì vậy, trong Nidānasaṃyutta, Đức Phật dạy rằng ai muốn thoát khỏi khổ luân hồi phải nỗ lực thấu hiểu pháp Duyên khởi này. (Theo bản nissaya của Nidānavaggasaṃyutta.)


<a id="M05-front-P001"></a>
## Trang nhan đề
Đầu sách / Front matter - 1

Nibbānagāminipaṭipadā — Đường đến Niết-bàn (bản lược), Cuốn 5. Phần Duyên khởi (Paṭiccasamuppāda) — A. Thiền sư Pa-Auk Tawya.


<a id="M05-front-P002"></a>
## Pháp thí và lời nguyện
Đầu sách / Front matter - 2

Sabbadānaṃ dhammadānaṃ jināti.
Sabbarasaṃ dhammaraso jināti.
Sabbaratiṃ dhammarati jināti.
Taṇhakkhayo sabbadukkhaṃ jināti.

Pháp thí thắng mọi sự bố thí.
Vị Pháp thắng mọi vị.
Niềm vui trong Pháp thắng mọi niềm vui.
Ái diệt thắng mọi khổ.

Ciraṃ tiṭṭhatu saddhammo, dhamme hontu sagāravā.

Nguyện giáo pháp của Đức Phật tồn tại lâu dài. Nguyện mọi người kính trọng ba loại Chánh pháp.


<a id="M05-front-P003"></a>
## Mục lục — trang đầu
Đầu sách / Front matter - 3

Namo tassa bhagavato arahato sammāsambuddhassa.

Phần Duyên khởi (Paṭiccasamuppāda) — A. Mục lục.

Phần 1 — 1

Lời tuyên bố trong Kinh Đại Duyên — 1

Thế nào là bậc Nhập lưu? — 5

Quy ước gọi tên theo nghĩa có trước (pubbūpacārasammuti) — 5

Chủ trương của ngoại đạo — 6

Sotāpannatā — sự thành tựu Nhập lưu — 7

Bahussutabhāva — sự đa văn — 8

Thế nào là người đa văn? — 9

Ba loại liễu tri hiệp thế — 11

Ba loại liễu tri siêu thế — 13

Hiểu và thấu triệt (anubodha và paṭivedha) — 14

Tóm lược Duyên khởi theo phương pháp thứ năm để ghi nhớ — 17

Thế nào là sự thật về nguồn gốc khổ? — 21

Nhân ấy có từ khi nào? — 23

Hành và nghiệp hữu — 24

Sức mạnh của nghiệp duyên — 25

Suy luận và trực chứng — 29

Trích Kinh Nhà Có Nóc Nhọn (Kūṭāgārasutta) — 31

Để đạt tuệ phân biệt nhân duyên (paccayapariggahañāṇa) — 34

Thắng trí và minh sát — 35


<a id="M05-front-P004"></a>
## Mục lục — ခ
Đầu sách / Front matter - 4

Đề mục — Trang

Phần 2 — 39

Một trình tự tìm các pháp nhân — 39

Cách Đức Phật thuyết pháp Duyên khởi — 42

Bốn cách thuyết giảng — 42

Một điểm cần lưu ý trước — 44

Hãy hướng trí về quá khứ để xem — 46

Nếu là hành giả lấy thiền chỉ làm cỗ xe — 50

Vòng phiền não và vòng nghiệp — 51

Ba pháp thuộc vòng phiền não — 52

Hai pháp thuộc vòng nghiệp — 53

Trường hợp phát nguyện thứ hai — cõi Phạm thiên — 54

Việc cần thực hành khi hình ảnh sắc hiện ra — 55

Lần về cận tử quá khứ — 57

Cách tìm cảnh nghiệp — 60

Lời nguyện trước kia của công chúa Sumanā — 61

Lời nguyện của Anojādevī — 63

Hoàng hậu Subhaddā — 64

Một ví dụ của hành giả — 69

Một ví dụ khác — 70

Vòng phiền não và vòng nghiệp — 75

Ba pháp thuộc vòng phiền não — 77

Hai pháp thuộc vòng nghiệp — 79

Phần tuệ phân biệt nhân duyên — 81

Sự thay đổi của tướng — 84


<a id="M05-front-P005"></a>
## Mục lục — ဂ
Đầu sách / Front matter - 5

Đề mục — Trang

Cách quán các pháp nhân và quả — 85

Điểm chính cần ghi nhớ trước — 86

Sắc uẩn — 87

Bốn danh uẩn — 88

Bốn phương pháp — 1. Phương pháp đồng nhất — 90

Sức chi phối của tập khí quá khứ — 92

Có vẻ khó, và quả thật là khó. Có vẻ sâu, và quả thật là sâu — 93

Khi thấy được ba hoặc bốn đời — 96

Đoạn kiến và thường kiến — 98

2. Phương pháp sai biệt — 100

3. Phương pháp vô tác giả — 103

4. Phương pháp tính quy luật — 106

Thuyết định mệnh — 107

Phần 3 — 109

Thực hành quán theo năm uẩn — 109

Điểm đặc biệt cần lưu ý — 109

Cách phân thành năm uẩn — 110

Năm uẩn tái tục ở sát-na đầu của phôi kalala — 112

Cách quán các pháp bằng cách nối nhân với quả — 114

Sắc uẩn tái tục — 115

Tái tục — Thọ uẩn — 117

Giải thích — 1. Vật — 119

2. Cảnh — 120


<a id="M05-front-P006"></a>
## Mục lục — ဃ
Đầu sách / Front matter - 6

Đề mục — Trang

3. Xúc — 122

Tái tục — Tưởng uẩn — 124

Tái tục — Hành uẩn — 125

Tái tục — Thức uẩn — 127

Năm uẩn của hữu phần — 129

Hữu phần — Sắc uẩn — 130

Hữu phần — Thọ uẩn — 131

Hữu phần — Tưởng uẩn — 132

Hữu phần — Hành uẩn — 132

Hữu phần — Thức uẩn — 133

Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm hướng ngũ môn — 133

Hướng ngũ môn — Sắc uẩn — 134

Hướng ngũ môn — Thọ uẩn — 135

Hướng ngũ môn — Tưởng uẩn — 135

Hướng ngũ môn — Hành uẩn (tư, cách thứ nhất) — 136

Hướng ngũ môn — Hành uẩn (tám tâm sở, cách thứ hai) — 136

Hướng ngũ môn — Thức uẩn — 137

Lộ cảnh sắc, tức màu sắc — Năm uẩn của nhãn thức, tức tâm thấy — 137

Nhãn thức — Sắc uẩn — 138

Nhãn thức — Thọ uẩn — 138

Tác ý dẫn đầu lộ tâm (vīthipaṭipādakamanasikāra) — 139

Ánh sáng — 140

Nhãn thức — Tưởng uẩn — 140

Nhãn thức — Hành uẩn — 141

Nhãn thức — Thức uẩn — 141


<a id="M05-front-P007"></a>
## Mục lục — င
Đầu sách / Front matter - 7

Đề mục — Trang

Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm tiếp thâu — 142

Tiếp thâu — Thọ uẩn — 142

Tiếp thâu — Tưởng uẩn — 143

Tiếp thâu — Hành uẩn — 143

Tiếp thâu — Thức uẩn — 144

Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm suy đạc — 145

Suy đạc — Thọ uẩn — 145

Suy đạc — Tưởng uẩn — 146

Suy đạc — Hành uẩn — 147

Suy đạc — Thức uẩn — 148

Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm xác định — 148

Xác định — Thọ uẩn — 149

Xác định — Tưởng uẩn — 149

Xác định — Hành uẩn — 150

Xác định — Thức uẩn — 151

Tác ý dẫn đầu tốc hành (javanapaṭipādakamanasikāra) — 151

Lộ cảnh sắc, tức màu sắc — Năm uẩn ở tốc hành thiện thứ nhất — 152

Tốc hành đại thiện thứ nhất — Thọ uẩn — 153

Tốc hành đại thiện thứ nhất — Tưởng uẩn — 154

Tốc hành đại thiện thứ nhất — Hành uẩn — 154

Tốc hành đại thiện thứ nhất — Thức uẩn — 155

Tốc hành đại thiện thứ hai — Thọ uẩn — 157

Lộ cảnh sắc, tức màu sắc — Năm uẩn ở tâm đăng ký — 158

Tâm đăng ký đại quả thứ nhất — Thọ uẩn — 158

Tâm đăng ký đại quả thứ nhất — Thức uẩn — 160


<a id="M05-front-P008"></a>
## Mục lục — စ
Đầu sách / Front matter - 8

Đề mục — Trang

Các lộ ý môn lấy cảnh sắc làm đối tượng — 161

Hướng ý môn — Thọ uẩn — 162

Tốc hành đại thiện thứ nhất — Thọ uẩn — 162

Tốc hành đại thiện thứ hai — Thọ uẩn — 163

Giải thích về nhãn xúc và ý xúc — 164

Lộ cảnh sắc, tức màu sắc — Năm uẩn ở tốc hành tham hợp tà kiến — 167

Tốc hành tham hợp tà kiến thứ nhất — Thọ uẩn và thức uẩn (lộ nhãn môn) — 168

Tốc hành tham hợp tà kiến thứ hai — Thọ uẩn (lộ nhãn môn) — 169

Tốc hành tham hợp tà kiến thứ hai — Thức uẩn (lộ nhãn môn) — 169

Điểm cần lưu ý — 170

Một số điểm thay đổi — 171

Lộ cảnh thinh, tức âm thanh — Hướng ngũ môn — Thọ uẩn — 171

Lộ cảnh thinh, tức âm thanh — Nhĩ thức, tức tâm nghe — Thọ uẩn — 172

Khoảng trống (ākāsa) — 173

Lộ cảnh thinh, tức âm thanh — Tiếp thâu — Hành uẩn (cách thứ hai) — 173

Lộ cảnh thinh, tức âm thanh — Tiếp thâu — Thức uẩn — 174

Lộ cảnh thinh, tức âm thanh — Suy đạc — Thọ uẩn — 175

Lộ cảnh hương, tức mùi — Hướng ngũ môn — Thọ uẩn — 176

Lộ cảnh hương, tức mùi — Tỷ thức — Thọ uẩn — 177

Giới gió — 178

Lộ cảnh hương, tức mùi — Tiếp thâu — Thọ uẩn — 178

Lộ cảnh hương, tức mùi — Suy đạc — Thọ uẩn — 179

Lộ cảnh vị — Hướng ngũ môn — Thọ uẩn — 180

Lộ cảnh vị — Thiệt thức — Thọ uẩn — 180


<a id="M05-front-P009"></a>
## Mục lục — ဆ
Đầu sách / Front matter - 9

Đề mục — Trang

Giới nước — 181

Lộ cảnh vị — Tiếp thâu — Thọ uẩn — 181

Lộ cảnh vị — Suy đạc — Thọ uẩn — 182

Lộ cảnh xúc — Hướng ngũ môn — Thọ uẩn — 182

Lộ cảnh xúc — Thân thức — Thọ uẩn — 183

Giới đất — 183

Lộ cảnh xúc — Tiếp thâu — Thọ uẩn — 184

Lộ cảnh xúc — Suy đạc — Thọ uẩn — 185

Lộ cảnh pháp — Lộ tốc hành thiện lấy nhãn tịnh sắc làm cảnh — 185

Tốc hành thứ nhất — Thọ uẩn (lộ ý môn) — 185

Tốc hành thứ hai — Thọ uẩn — 186

Lộ cảnh pháp — Lộ chứng sơ thiền lấy tợ tướng hơi thở làm cảnh — 187

Tốc hành thứ nhất — Thọ uẩn — 187

Lộ cảnh pháp — Sắc pháp làm cảnh — 188

Từng phần, từng trường hợp — 189

Bên ngoài, nhiều đời quá khứ và nhiều đời vị lai — 190

Hạt giống hạnh và hạt giống minh — 191

Nhân vô gián của hữu phần — 192

Đạt đến tuệ liễu tri bằng nhận biết — 193

Bén rễ đến mức không thể lìa Giáo pháp — 195

Cách quán trong các oai nghi và khi tỉnh giác — 196

❂ ❂ ❂


<a id="M05-body-P001"></a>
## Phần 1. Lời tuyên bố trong Kinh Đại Duyên
Miến / Burmese 1

Nibbānagāminipaṭipadā — Đường đến Niết-bàn (bản lược), Cuốn 5. Phần Duyên khởi (Paṭiccasamuppāda) — A.

Namo tassa bhagavato arahato sammāsambuddhassa.

Phần 1. Lời tuyên bố trong Kinh Đại Duyên (Mahānidānasutta).

Thuở ấy Đức Phật trú tại xứ Kuru, lấy thị trấn Kammāsadhamma làm nơi khất thực. Hôm ấy, trước khi Đức Phật thuyết Kinh Đại Duyên, Tôn giả Ānanda đi đến chỗ nghỉ ban ngày, ngồi xuống và nhập quả định Nhập lưu. Khi thời gian đã định trôi qua, Tôn giả xuất khỏi quả định Nhập lưu và hướng tâm đến pháp Duyên khởi, còn gọi là các duyên (paccayākāra). Tôn giả Ānanda quán theo các cách sau:

1. Từ vô minh đến già chết, theo chiều thuận của Duyên khởi (anuloma).
2. Từ già chết đến vô minh, theo chiều nghịch của Duyên khởi (paṭiloma).


<a id="M05-body-P002"></a>
## Bốn cách quán Duyên khởi và lời Tôn giả Ānanda
Miến / Burmese 2

3. Từ hai đầu vào giữa, theo chiều thuận và nghịch của Duyên khởi.
4. Từ giữa ra hai đầu, theo chiều thuận và nghịch của Duyên khởi.

Tôn giả lần lượt tu tập minh sát trên từng chi trong mười hai chi Duyên khởi theo cả bốn cách ấy, như người ta vạch từng đường lên mặt đất. Khi Tôn giả Ānanda tu tập minh sát như vậy, mối liên hệ nhân quả của Duyên khởi, còn gọi là các duyên (paccayākāra), hiện rõ trong trí của Tôn giả.

Tôn giả nghĩ rằng nếu đem điều này trình lên Đức Phật, mình có thể được nghe một bài pháp hay. Chiều hôm ấy, Tôn giả đến chỗ Đức Phật, đảnh lễ, ngồi sang một bên và thưa:

“Bạch Đức Thế Tôn, thật kỳ diệu! Bạch Đức Thế Tôn, thật chưa từng có! Pháp Duyên khởi này thật sâu xa và hiện ra sâu xa. Vậy mà đối với con, pháp ấy dường như hết sức dễ hiểu, bạch Đức Thế Tôn.”

Khi ấy Đức Phật thuyết Kinh Đại Duyên cho Tôn giả Ānanda. Sau đây là đoạn trích từ kinh ấy.


<a id="M05-body-P003"></a>
## Duyên khởi sâu xa và ba loại liễu tri
Miến / Burmese 3

Mā hevaṃ, Ānanda, avaca, mā hevaṃ, Ānanda, avaca. Gambhīro cāyaṃ, Ānanda, paṭiccasamuppādo gambhīrāvabhāso ca. Etassa, Ānanda, dhammassa ananubodhā appaṭivedhā evamayaṃ pajā tantākulakajātā kulagaṇṭhikajātā muñjapabbajabhūtā apāyaṃ duggatiṃ vinipātaṃ saṃsāraṃ nātivattati. (Dīgha, tập 2, tr. 47.)

Ananubodhāti ñātapariññāvasena ananubujjhanā. Appaṭivedhāti tīraṇapahānapariññāvasena appaṭivijjhanā. (Chú giải Dīgha, tập 2, tr. 85.)

“Này Ānanda, chớ nói như vậy. Này Ānanda, chớ nói như vậy. Mối liên hệ nhân quả này, tức pháp Duyên khởi, thật sâu xa. Vì sâu xa nên pháp ấy cũng hiện ra sâu xa.”

“Này Ānanda, vì không hiểu và không thấu triệt mối liên hệ nhân quả ấy bằng ba loại tuệ liễu tri là liễu tri bằng nhận biết (ñātapariññā), liễu tri bằng thẩm sát (tīraṇapariññā) và liễu tri bằng đoạn trừ (pahānapariññā), chúng sinh trong cuộc luân hồi dài lâu này rối như cuộn chỉ, thắt nút như một búi sợi, đan chằng chịt như cỏ muñja và pabbaja. Họ không thể vượt qua vòng luân hồi nơi các cõi khổ, ác thú và đọa xứ, là chỗ đến của người làm ác, nơi thiếu sự an vui và chịu suy tổn. Họ cũng không thể vượt qua vòng luân hồi ở các thiện thú ngoài những cõi khổ ấy.” (Dīgha, tập 2, tr. 47.)

Dựa vào lời dạy trên, các vị chú giải sư lại đưa ra nhận định như sau.


<a id="M05-body-P004"></a>
## Phá vỡ bánh xe hữu bằng lưỡi gươm trí tuệ
Miến / Burmese 4

Ñāṇāsinā samādhipavarasilāya sunisitena —
Bhavacakkamapadāletvā, asanivicakkamiva niccanimmathaṃ.
Saṃsārabhayamatīto, na koci supinantarepyatthi.
(Chú giải Abhidhamma, tập 2, tr. 189. Thanh tịnh đạo, tập 2, tr. 221.)

Lưỡi gươm trí tuệ được mài sắc trên đá mài quý là định. Bánh xe hữu, tức mối liên hệ nhân quả của Duyên khởi trong luân hồi, không ngừng nghiền ép và hành hạ chúng sinh như một bánh xe sấm sét. Nếu chưa dùng lưỡi gươm ấy phá vỡ bánh xe hữu thì chưa từng có ai vượt qua được hiểm họa lớn của khổ luân hồi, dù chỉ trong giấc mộng. (Chú giải Abhidhamma, tập 2, tr. 189. Thanh tịnh đạo, tập 2, tr. 221.)

Theo câu Pāli và lời chú giải trên, thiện nhân mong cầu Chân pháp, mong đạt pháp cao quý là sự an lạc Niết-bàn, phải nỗ lực biết rõ mối liên hệ nhân quả của Duyên khởi bằng ba loại tuệ liễu tri: liễu tri bằng nhận biết (ñātapariññā), gọi là hiểu theo (anubodha), và liễu tri bằng thẩm sát (tīraṇapariññā) cùng liễu tri bằng đoạn trừ (pahānapariññā), gọi là thấu triệt (paṭivedha). Chính Đức Phật đã dạy rằng vì chưa nhiều lần biết rõ bằng sự hiểu theo, và chưa tự mình xuyên thấu bằng sự thấu triệt cho đến sát-na đạo và quả, nên chúng sinh chưa vượt thoát luân hồi. Vì vậy, muốn thoát luân hồi, phải nỗ lực để biết sâu bằng cả sự hiểu theo lẫn sự thấu triệt. Đây là việc cần gắng sức để tự mình biết rõ. Chỉ dựa vào lời thầy rồi lần mò thì…


<a id="M05-body-P005"></a>
## Vì sao Duyên khởi hiện rõ đối với Tôn giả Ānanda?
Miến / Burmese 5

…hãy hiểu rằng việc này không thể thành tựu theo cách ấy.

Thế nào là bậc Nhập lưu?

Mối liên hệ nhân quả của Duyên khởi sâu xa, hiện ra sâu xa, khó hiểu và có vẻ khó hiểu. Vậy do đâu pháp ấy hiện ra trong trí Tôn giả Ānanda “dễ hiểu như thể nông cạn”? Câu trả lời như sau.

Therassa hi catūhi kāraṇehi gambhīropi paṭiccasamuppādo uttānoti upaṭṭhāsi. Katamehi catūhi? Pubbūpanissayasampattiyā, titthavāsena, sotāpannatāya, bahussutabhāvenāti. (Chú giải Dīgha, tập 2, tr. 78.)

Do bốn duyên sau, mối liên hệ nhân quả của Duyên khởi, dù sâu xa và khó hiểu, đã hiện rõ trong trí Tôn giả Ānanda:
1. Pubbūpanissayasampatti — có đầy đủ các ba-la-mật đã vun bồi trong những đời trước.
2. Titthavāsa — thường xuyên nương gần những bến lành trong giáo pháp.
3. Sotāpannatā — đã thành tựu Nhập lưu.
4. Bahussutabhāva — đã nghe học nhiều.

Chính do bốn duyên này mà mối liên hệ nhân quả của Duyên khởi, vốn sâu xa và khó hiểu…


<a id="M05-body-P006"></a>
## Các trợ duyên đời trước và sự nương nơi bến lành
Miến / Burmese 6

…hiện rõ trong trí Tôn giả Ānanda.

1. Pubbūpanissayasampatti. Trong giáo pháp của Đức Phật Padumuttara, Tôn giả Ānanda đã phát nguyện và vun bồi ba-la-mật trong một trăm nghìn kiếp để đạt địa vị bậc nhất trong năm phương diện. Tất cả các ba-la-mật đã tích lũy qua nhiều đời, hướng đến tuệ giác của một vị đại đệ tử có thể đạt năm địa vị bậc nhất, nay đã đầy đủ trong dòng tương tục của Tôn giả. Đây là một duyên.

2. Titthavāsa. Những bến lành để đi đến Niết-bàn được gọi là tittha. Đức Phật Chánh Đẳng Giác và các vị đại đệ tử bậc nhất có thể chỉ dẫn đúng đắn con đường đi đến Niết-bàn trong giáo pháp, nên các Ngài được gọi bằng tên tittha vì giống như những bến tốt để sang bờ bên kia, tức Niết-bàn. Sống gần và nương tựa những bậc thầy như thế gọi là titthavāsa. Tôn giả Ānanda cũng đầy đủ phẩm chất này.

Dù ở gần Đức Phật hay ở gần các đại đệ tử bậc nhất như Tôn giả Sāriputta, Mahāmoggallāna, Mahākoṭṭhita và Mahāpanthaka, Tôn giả Ānanda thực hành các việc sau trước những bậc thầy cao quý ấy:
(a) Uggaha — học văn bản Pāli.
(b) Savana — nghe giải nghĩa văn bản Pāli, tức nghe chú giải (atthakathā hoặc aṭṭhakathā).


<a id="M05-body-P007"></a>
## Học pháp nơi bậc thầy và thành tựu Nhập lưu
Miến / Burmese 7

(c) Paripucchā — hỏi thêm về ý nghĩa và chú giải của những điểm sâu xa, khó hiểu.
(d) Dhāraṇā — ghi nhớ văn bản Pāli cũng như ý nghĩa trong chú giải, giữ thuộc lòng.

Như vậy, Tôn giả đã học có hệ thống các bản Pāli và chú giải về Duyên khởi, ghi nhớ đến mức thuộc lòng. Cũng vì duyên này, pháp Duyên khởi, dù sâu xa và khó hiểu, đã hiện rõ trong trí Tôn giả Ānanda như một điều dễ hiểu. (Chú giải Dīgha, tập 2, tr. 83.)

3. Sotāpannatā — sự thành tựu Nhập lưu.

Sotāpannānañca nāma paccayākāro uttānakova hutvā upaṭṭhāti. Ayañca āyasmā sotāpanno. (Chú giải Dīgha, tập 2, tr. 83.)

Sotāpannānañca … pe … upaṭṭhāti tattha sammohaviddhaṃsanena. “Yaṃ kiñci samudayadhammaṃ, sabbaṃ taṃ nirodhadhamman”ti attapaccakkhavasena upaṭṭhānato. (Phụ chú giải Dīgha, tập 2, tr. 84.)

Mối liên hệ nhân quả của Duyên khởi, còn gọi là các duyên (paccayākāra), hiện rõ trong dòng tương tục của một bậc Nhập lưu chân thật. Bởi đạo Nhập lưu đã phá tan si mê che lấp sự thấy biết mối liên hệ nhân quả gọi là sự thật về nguồn gốc khổ, nên vị ấy tự mình trực chứng rằng: “Bất cứ pháp nào có tính sinh khởi, tất cả đều có tính đoạn diệt.” Do vậy, trong trí vị ấy…


<a id="M05-body-P008"></a>
## Tự mình thấy mối liên hệ nhân quả
Miến / Burmese 8

…mối liên hệ ấy hiện rõ. Tôn giả Ānanda đã thành tựu Nhập lưu. Do đó, mối liên hệ nhân quả của Duyên khởi hiện rõ trong trí Tôn giả.

Nếu một thiện nhân tự cho mình là bậc Nhập lưu, hãy tự xét xem mình đã trực tiếp thấu suốt mối liên hệ nhân quả của Duyên khởi bằng trí chánh kiến hay chưa. Hãy tự hỏi như sau.

Do các nhân đã vun bồi trong quá khứ là vô minh, ái, thủ, hành và nghiệp, các quả hiện tại là thức, danh sắc, sáu xứ, xúc và thọ hiện khởi như thế nào? Do vô minh, ái, thủ, hành và nghiệp được vun bồi trong hiện tại, các quả là thức, danh sắc, sáu xứ, xúc và thọ sẽ hiện khởi trong tương lai như thế nào?

Hãy tự hỏi xem mình đã trực tiếp thấu suốt những điều ấy bằng trí chánh kiến chưa. Nếu vẫn chỉ dò theo lời thầy, câu trả lời đã rõ. Hãy tự kết luận rằng mình chưa phải là bậc Nhập lưu chân thật mà Đức Phật nói đến. Vì các bậc thánh là những đệ tử chân thật của Đức Phật đã tự mình trực tiếp thấu suốt mối liên hệ nhân quả của Duyên khởi bằng trí chánh kiến.

4. Bahussutabhāva — sự đa văn.

Bahussutānañca catuhatthe ovarake padīpe jalamāne mañcapīṭha…


<a id="M05-body-P009"></a>
## Sự đa văn và trí phân định danh sắc
Miến / Burmese 9

…viya nāmarūpaparicchedo pākaṭo hoti. Ayañca āyasmā bahussutānaṃ aggo hoti. Bahussutānubhāvenapissa gambhīropi paccayākāro uttānako viya upaṭṭhāsi. (Chú giải Dīgha, tập 2, tr. 83.)

Nāmarūpaparicchedoti saha paccayena nāmarūpassa paricchijja avabodho. (Phụ chú giải Dīgha, tập 2, tr. 84.)

Khi thắp đèn trong căn phòng rộng bốn khuỷu tay, giường và ghế trong phòng hiện ra rõ ràng. Cũng vậy, trong trí người đa văn, sự phân định rành rẽ danh sắc cùng các duyên, tức trí phân định danh sắc và trí nắm bắt các duyên, hiện ra rõ ràng. Tôn giả Ānanda lại là vị đứng đầu trong các vị tỳ-khưu đa văn. Do sức của sự đa văn ấy, mối liên hệ nhân quả của Duyên khởi, dù sâu xa và khó hiểu, hiện rõ trong trí Tôn giả như một điều dễ hiểu. (Chú giải Dīgha, tập 2, tr. 83. Phụ chú giải Dīgha, tập 2, tr. 84.)

Thế nào là người đa văn?

Katamañca, bhikkhave, sutadhanaṃ? Idha, bhikkhave, ariyasāvako bahussuto hoti sutadharo sutasannicayo. Ye te dhammā ādikalyāṇā majjhekalyāṇā pariyosānakalyāṇā sātthaṃ sabyañjanaṃ kevalaparipuṇṇaṃ parisuddhaṃ brahmacariyaṃ abhivadanti, tathārūpāssa dhammā bahussutā honti dhātā vacasā paricitā manasānupekkhitā…


<a id="M05-body-P010"></a>
## Tài sản nghe học
Miến / Burmese 10

…diṭṭhiyā suppaṭividdhā. Idaṃ vuccati, bhikkhave, sutadhanaṃ. (Aṅguttara, tập 2, tr. 399.)

Diṭṭhiyā suppaṭividdhāti atthato ca kāraṇato ca paññāya suṭṭhu paṭividdhā, paccakkhaṃ katā. (Chú giải Aṅguttara, tập 2, tr. 364.)

Suppaṭividdhāti nijjaṭaṃ niggumbaṃ katvā suṭṭhu yāthāvato paṭividdhā. (Phụ chú giải Aṅguttara, tập 2, tr. 362.)

“Này các tỳ-khưu, thế nào là tài sản nghe học?”

“Này các tỳ-khưu, ở đây, vị thánh đệ tử trong giáo pháp này, tức đệ tử của Ta, bậc đã thành tựu thánh quả, đã nghe học nhiều, ghi nhớ và tích lũy những điều đã nghe. Vị ấy nghe học nhiều những lời dạy tốt đẹp ở đầu, với sự thực hành giới, tốt đẹp ở giữa, với sự thực hành định, và tốt đẹp ở cuối, với sự thực hành tuệ. Những lời dạy ấy trình bày đời sống phạm hạnh đầy đủ cả nghĩa lẫn lời, hoàn toàn viên mãn và thanh tịnh, tức sự thực hành giới, định, tuệ trong giáo pháp, hay sự thực hành thánh đạo gồm tám chi. Vị ấy ghi nhớ các lời dạy ấy, quen thuộc qua việc tụng đọc, suy xét ý nghĩa trong tâm, và tự mình trực tiếp thấu suốt đúng như thật bằng tuệ chánh kiến, cả về ý nghĩa lẫn nguyên do. Này các tỳ-khưu, đó gọi là tài sản nghe học.” (Aṅguttara, tập 2, tr. 399.)

Theo những lời dạy ấy, một thiện nhân đa văn có cả sự học từ truyền thừa (āgamasuta) lẫn sự học do chứng nghiệm (adhigamasuta), tức có cả điều đã nghe lẫn điều đã trực thấy. Vị ấy đã có trí phân định danh sắc và trí…


<a id="M05-body-P011"></a>
## Trí nắm bắt các duyên và ba loại liễu tri hiệp thế
Miến / Burmese 11

…nắm bắt các duyên. Người đa văn đã tự mình trực tiếp thấu suốt các sắc pháp và danh pháp thuộc năm thủ uẩn, gọi là khổ đế, bằng trí chánh kiến đến mức thấy chúng là pháp chân đế. Vị ấy cũng đã tự mình trực tiếp thấu suốt các nhân gọi là tập đế bằng trí chánh kiến. Vì vậy, trong dòng tương tục của vị ấy, mối liên hệ nhân quả của Duyên khởi hiện rõ.

Vì vậy, để trở thành một bậc thánh như bậc Nhập lưu và để vượt thoát khổ luân hồi, thiện nhân cần nỗ lực tự mình trực tiếp thấu suốt mối liên hệ nhân quả của Duyên khởi bằng trí chánh kiến. Cần cố gắng biết rõ pháp ấy bằng cả ba loại tuệ liễu tri. Có hai nhóm liễu tri, hiệp thế và siêu thế. Có ba loại liễu tri hiệp thế và ba loại liễu tri siêu thế.

Ba loại liễu tri hiệp thế

1. Liễu tri bằng nhận biết (ñātapariññā). Nếu hành giả có thể dùng trí để phân định và quán đặc tính, phận sự, sự hiện khởi và nhân gần của từng chi Duyên khởi—vô minh, hành, thức, danh sắc, sáu xứ, xúc, thọ, ái, thủ, hữu, sinh, già chết—thì trí ấy là trí phân định danh sắc.


<a id="M05-body-P012"></a>
## Liễu tri bằng nhận biết, thẩm sát và đoạn trừ
Miến / Burmese 12

Khi tự mình trực tiếp thấu suốt mối liên hệ nhân quả như do vô minh có hành, do hành có thức, do thức có danh sắc, trí ấy là trí nắm bắt các duyên. Trí phân định danh sắc và trí nắm bắt các duyên, cả hai gọi là liễu tri bằng nhận biết (ñātapariññā). Chúng giúp biết rõ và phân biệt minh bạch các pháp hành sẽ làm cảnh cho tuệ minh sát. Vì vậy gọi là liễu tri bằng nhận biết.

2. Liễu tri bằng thẩm sát (tīraṇapariññā). Khi quán bằng trí tướng vô thường, tướng khổ và tướng vô ngã của mười hai chi Duyên khởi như vô minh và hành, hai trí là tuệ thẩm sát (sammasanañāṇa) và tuệ sinh diệt (udayabbayañāṇa), có khả năng phân định các tướng ấy, được gọi là liễu tri bằng thẩm sát. Chúng thẩm sát và phân định các chi Duyên khởi theo tướng vô thường, khổ và vô ngã.

3. Liễu tri bằng đoạn trừ (pahānapariññā). Khi quán bằng trí mặt hoại diệt của các chi Duyên khởi, các tuệ minh sát từ tuệ hoại diệt (bhaṅgañāṇa) trở lên đoạn trừ bằng sức đối trị từng phần những phiền não có thể được đoạn trừ theo cách ấy, đồng thời thấy rõ các chi Duyên khởi đã được biết theo các tướng vô thường, khổ và vô ngã. Vì vậy gọi là liễu tri bằng đoạn trừ. Trên đây là ba loại liễu tri hiệp thế.


<a id="M05-body-P013"></a>
## Ba loại liễu tri siêu thế
Miến / Burmese 13

Ba loại liễu tri siêu thế

1. Ở chặng cuối của các tuệ minh sát, tức các tuệ liễu tri hiệp thế, Thánh đạo lấy Niết-bàn làm cảnh và sinh khởi. Thánh đạo nhổ tận gốc các phiền não có thể đoạn trừ ở tầng đạo ấy, đồng thời thấu suốt rõ ràng Niết-bàn, chân lý cần được chứng biết. Vì vậy, trước hết Thánh đạo được gọi là liễu tri bằng đoạn trừ (pahānapariññā).

2. Bằng sự thấu triệt đối tượng (ārammaṇapaṭivedha), Thánh đạo trực tiếp thấu suốt chân lý cần được chứng biết là Niết-bàn. Đồng thời, Thánh đạo nhổ tận gốc si mê che lấp sự biết rõ bốn Thánh đế. Do si mê che lấp đã bị nhổ tận gốc, sự biết bốn đế được hoàn tất ngay cùng lúc. Biết các Thánh đế theo phận sự như vậy gọi là thấu triệt bằng cách hết mê mờ (asammohapaṭivedha). Ở đây Thánh đạo biết diệt đế bằng sự thấu triệt đối tượng, và biết khổ đế, tập đế, đạo đế bằng sự thấu triệt do hết mê mờ. Như vậy Thánh đạo hoàn tất việc biết các chi Duyên khởi thuộc khổ đế và mối liên hệ nhân quả của các chi ấy thuộc tập đế. Vì phận sự này, Thánh đạo cũng được gọi là liễu tri bằng nhận biết (ñātapariññā).


<a id="M05-body-P014"></a>
## Liễu tri bằng thẩm sát ở tầng siêu thế
Miến / Burmese 14

3. Thánh đạo cũng nhổ tận gốc si mê che lấp sự biết rõ các tướng vô thường, khổ và vô ngã của các pháp thuộc khổ đế và tập đế. Vì vậy, phận sự thẩm sát và phân định các tướng vô thường, khổ và vô ngã của danh sắc và các nhân duyên, tức của các pháp thuộc hai đế ấy, cũng được hoàn tất. Vì phận sự này, Thánh đạo được gọi là liễu tri bằng thẩm sát (tīraṇapariññā). Trên đây là ba loại liễu tri siêu thế.

Chỉ khi tự mình trực tiếp thấu suốt mối liên hệ nhân quả của Duyên khởi bằng liễu tri hiệp thế và liễu tri siêu thế thì mới có thể nói đến sự hiểu theo và thấu triệt (anubodha và paṭivedha). Chỉ khi biết sâu pháp Duyên khởi bằng sự hiểu theo và thấu triệt như vậy mới có thể hoàn toàn vượt qua nỗi khổ lớn của luân hồi. Đó là ý nghĩa cốt yếu của đoạn trích Kinh Đại Duyên ở trên.

Hiểu theo và thấu triệt (anubodha và paṭivedha)

Ananubodhāti ñātapariññāvasena ananubujjhanā. Appaṭivedhāti tīraṇapahānapariññāvasena appaṭivijjhanā. (Chú giải Dīgha, tập 2, tr. 85.)

Nāmarūpaparicchedo, tassa ca paccayapariggaho na paṭhamābhinivesamattena hoti, atha kho tattha aparāparaṃ ñāṇuppattisaṅkhātena anu anu bujjhanena. Tadubhayābhāvaṃ pana dassento “ñātapariññāvasena ananubujjhanā”ti āha. Niccasaññādīnaṃ pajahanavasena vattamānā…


<a id="M05-body-P015"></a>
## Hiểu theo nhờ trí sinh khởi nhiều lần
Miến / Burmese 15

…vipassanā dhamme ca paṭivijjhati eva nāma hoti paṭipakkhavikkhambhanena tikkhavisadabhāvāpattito. Tadadhiṭṭhānabhūtā ca tīraṇapariññā, ariyamaggo ca pariññāpahānābhisamayavasena pavattiyā tīraṇapahānapariññāsaṅgaho cāti tadubhayapaṭivedhābhāvaṃ dassento “tīraṇa … pe … appaṭivijjhanā”ti āha. (Phụ chú giải Dīgha, tập 2, tr. 89–90.)

Hãy đọc lại ba loại liễu tri hiệp thế và ba loại liễu tri siêu thế đã giải thích ở trên. Lời chú giải và phụ chú giải này nói rõ rằng khi chưa thực sự thấy và hiểu rõ các pháp Duyên khởi bằng ba loại liễu tri hiệp thế và ba loại liễu tri siêu thế thì chưa có được sự hiểu theo và thấu triệt.

Trí phân định danh sắc phân biệt sắc pháp và danh pháp. Trí nắm bắt các duyên phân biệt các nhân, các quả và mối liên hệ nhân quả giữa chúng. Theo lời phụ chú giải “anu anu bujjhanena”, tức hiểu đi hiểu lại, cả hai loại trí này không thành tựu chỉ bằng một lần biết mà phải được tu tập nhiều lần, hết lần này đến lần khác, cho đến khi thành tựu. Vì vậy, trí phân định danh sắc và trí nắm bắt các duyên gọi là sự hiểu theo (anubodha). Biết bằng trí hiểu theo gọi là hiểu theo (anubodhi). Đây là liễu tri bằng nhận biết.

Lại nữa, biết bằng tuệ liễu tri qua thẩm sát và đoạn trừ gọi là thấu triệt (paṭivedha). Các tuệ minh sát có thể đoạn trừ bằng sức đối trị từng phần các phiền não như tưởng thường, nhưng không thể nhổ tận gốc chúng để chúng vĩnh viễn không sinh lại. Do khả năng đoạn trừ từng phần ấy, các tuệ này được gọi là liễu tri bằng đoạn trừ…


<a id="M05-body-P016"></a>
## Phận sự của Thánh đạo và sự trực tiếp thấy các duyên
Miến / Burmese 16

…(pahānapariññā). Tương tự, bằng sự thấu triệt do hết mê mờ (asammohapaṭivedha), Thánh đạo thấu suốt danh sắc và mối liên hệ nhân quả, tức các pháp thuộc khổ đế và tập đế, cũng như các tướng vô thường, khổ và vô ngã của chúng. Vì các phận sự được thực hiện qua sự thấu triệt do hết mê mờ ấy, Thánh đạo được gọi là liễu tri bằng nhận biết và liễu tri bằng thẩm sát. Riêng Thánh đạo có thể đoạn trừ tận gốc phiền não một cách vĩnh viễn, nên được gọi là liễu tri bằng đoạn trừ theo nghĩa chính. Vì vậy, biết thấu suốt danh sắc thuộc khổ đế và mối liên hệ nhân quả của Duyên khởi thuộc tập đế bằng liễu tri qua thẩm sát và đoạn trừ, cho đến khi đạt sát-na đạo và quả, được gọi là thấu triệt (paṭivedha).

Trong ba thời quá khứ, tương lai và hiện tại, hành giả phân định bằng trí các sắc và danh trong từng nhóm sắc và nhóm danh thuộc các chi Duyên khởi như vô minh và hành, rồi tự mình trực tiếp thấu suốt chúng bằng trí chánh kiến đến mức biết chúng là pháp chân đế. Hành giả cũng tự mình trực tiếp thấu suốt bằng trí chánh kiến mối liên hệ nhân quả giữa những nhân như vô minh và những quả như hành. Hai loại biết này gọi là hiểu theo (anubodhi). Còn tự mình trực tiếp thấu suốt bằng trí chánh kiến các tướng vô thường, khổ, vô ngã của các chi Duyên khởi ấy, cho đến khi đạt sát-na đạo và quả…


<a id="M05-body-P017"></a>
## Tóm lược Duyên khởi theo phương pháp thứ năm
Miến / Burmese 17

…gọi là thấu triệt (paṭivedha). Nếu thiện nhân chưa tự mình trực tiếp biết đúng như thật các pháp Duyên khởi bằng hai loại biết là hiểu theo và thấu triệt, thì không thể vượt thoát khổ luân hồi bằng bất cứ cách nào. Chỉ khi biết như vậy mới có thể vượt thoát khổ luân hồi. Vì thế, thiện nhân muốn hoàn toàn vượt qua nỗi khổ lớn của vòng luân hồi phải gắng sức biết các pháp Duyên khởi bằng sự hiểu theo và thấu triệt. Để giúp nỗ lực tu tập như vậy, sau đây trình bày trước phương pháp thực hành gọi là phương pháp thứ năm về Duyên khởi.

Tóm lược Duyên khởi theo phương pháp thứ năm để ghi nhớ

1. Purimakammabhavasmiṃ moho avijjā, āyūhanā saṅkhārā, nikanti taṇhā, upagamanaṃ upādānaṃ, cetanā bhavo. Ime pañca dhammā purimakammabhavasmiṃ idha paṭisandhiyā paccayā.

2. Idha paṭisandhi viññāṇaṃ, okkanti nāmarūpaṃ, pasādo āyatanaṃ, phuṭṭho phasso, vedayitaṃ vedanā. Ime pañca dhammā idhupapattibhavasmiṃ purekatassa kammassa paccayā.

3. Idha paripakkattā āyatanānaṃ moho avijjā, āyūhanā saṅkhārā, nikanti taṇhā, upagamanaṃ upādānaṃ, cetanā bhavo. Ime pañca dhammā idha kammabhavasmiṃ āyatiṃ paṭisandhiyā paccayā.

4. Āyatiṃ paṭisandhi viññāṇaṃ, okkanti nāmarūpaṃ, pasādo āyatanaṃ, phuṭṭho phasso, vedayitaṃ vedanā. Ime pañca dhammā āyatiṃ…


<a id="M05-body-P018"></a>
## Năm nhân quá khứ và năm quả hiện tại
Miến / Burmese 18

…upapattibhavasmiṃ idha katassa kammassa paccayā. (Paṭisambhidāmagga, tr. 50–51.)

1. Khi tạo dựng nghiệp hữu trong một đời quá khứ đã qua:
(a) Sự mê mờ, tức si, được gọi là vô minh.
(b) Sự nỗ lực tạo tác và tích lũy nghiệp được gọi là hành.
(c) Sự ham muốn và mê đắm hữu được gọi là ái.
(d) Sự nắm giữ chắc chắn được gọi là thủ.
(e) Tư tác thúc đẩy hành động được gọi là hữu.

Năm pháp đã sinh khởi khi tạo dựng nghiệp hữu trong đời quá khứ ấy là các nhân của sự tái tục trong đời hiện tại này.

2. Trong đời hiện tại này:
(a) Pháp tái tục có tướng nối kết đời này với đời kia, tức nối kết các uẩn của đời này với các uẩn của đời kia, gọi là thức.
(b) Các pháp sinh khởi như thể đi vào bụng mẹ gọi là danh sắc.
(c) Sự trong suốt của các đại chủng gọi là xứ.
(d) Tính chất tiếp xúc gọi là xúc.
(e) Tính chất cảm nhận gọi là thọ.

Năm pháp thuộc vòng quả trong đời hiện tại này là những quả sinh khởi do nghiệp đã được tạo tác và tích lũy khi xây dựng nghiệp hữu trong đời quá khứ.


<a id="M05-body-P019"></a>
## Năm nhân hiện tại và năm quả tương lai
Miến / Burmese 19

3. Trong đời hiện tại này, do các xứ đã chín muồi, những pháp sau sinh khởi:
(a) Mê mờ, tức si, gọi là vô minh.
(b) Nỗ lực tạo tác và tích lũy nghiệp gọi là hành.
(c) Mong muốn và mê đắm hữu gọi là ái.
(d) Nắm giữ chắc chắn gọi là thủ.
(e) Tư thúc đẩy hành động gọi là hữu.

Năm pháp làm nhân ấy, sinh trong nghiệp hữu hiện tại, là các nhân của sự tái tục trong tương lai.

4. Trong tương lai:
(a) Pháp tái tục có tướng nối kết đời này với đời kia, tức nối kết các uẩn của đời này với các uẩn của đời kia, gọi là thức.
(b) Các pháp sinh khởi như thể đi vào bụng mẹ gọi là danh sắc.
(c) Sự trong suốt của các đại chủng gọi là xứ.
(d) Tính chất tiếp xúc gọi là xúc.
(e) Tính chất cảm nhận gọi là thọ.

Năm pháp sinh trong sinh hữu tương lai ấy là quả do nghiệp đã tạo tác và tích lũy trong đời hiện tại làm nhân. (Paṭisambhidāmagga, tr. 50–51.)

Dựa vào đoạn Pāli trong Paṭisambhidāmagga đã nêu trên, các vị chú giải sư giải thích tóm tắt để dễ ghi nhớ như sau.


<a id="M05-body-P020"></a>
## Năm nhân và năm quả qua ba thời
Miến / Burmese 20

Atīte hetavo pañca, idāni phalapañcakaṃ.
Idāni hetavo pañca, āyatiṃ phalapañcakaṃ.
(Chú giải Abhidhamma, tập 2, tr. 182. Thanh tịnh đạo, tập 2, tr. 214.)

1. Do năm nhân quá khứ đã được tạo tác và vun bồi là vô minh, ái, thủ, hành và nghiệp, năm quả hiện tại trong đời này hiện khởi là thức, danh sắc, sáu xứ, xúc và thọ.

2. Do năm nhân hiện tại được tạo tác và vun bồi trong đời này là vô minh, ái, thủ, hành và nghiệp, năm quả tương lai hiện khởi trong đời sau là thức, danh sắc, sáu xứ, xúc và thọ. (Chú giải Abhidhamma, tập 2, tr. 182. Thanh tịnh đạo, tập 2, tr. 214.)

Thiện hữu muốn vượt thoát hãy nỗ lực tự mình trực tiếp thấu suốt bằng trí chánh kiến cách năm quả hiện tại hiện khởi do năm nhân quá khứ, và cách năm quả tương lai hiện khởi do năm nhân hiện tại. Chỉ khi ấy mới có thể vượt hẳn qua nỗi khổ lớn của luân hồi.

Ở đây các nhân là tập đế và các quả là khổ đế. Vì vậy, thiện hữu muốn vượt thoát phải nỗ lực tự mình trực tiếp thấu suốt bằng trí chánh kiến cách khổ đế hiện tại phát sinh do tập đế đã tạo tác, vun bồi trong quá khứ, và cách khổ đế tương lai phát sinh do tập đế được tạo tác, vun bồi trong hiện tại.


<a id="M05-body-P021"></a>
## Tập đế được trình bày theo năm cách
Miến / Burmese 21

Trong Pāli Abhidhamma Vibhaṅga (Abhidhamma, tập 2, tr. 112–118), Đức Phật dạy về tập đế theo năm cách:
1. Ái là tập đế.
2. Ái và tất cả phiền não đi cùng ái là tập đế.
3. Tất cả pháp bất thiện là tập đế.
4. Tất cả pháp bất thiện và ba căn thiện là vô tham, vô sân, vô si làm cảnh cho các pháp hữu lậu khiến luân hồi tiếp diễn là tập đế.
5. Tất cả nghiệp thiện làm cảnh cho các pháp hữu lậu khiến luân hồi tiếp diễn, cùng tất cả nghiệp bất thiện, là tập đế.

Vì Đức Phật đã phân tích tập đế theo năm cách như vậy, các vị chú giải sư trong Sammohavinodanī giải thích như sau.

Tattha yasmā kusalākusalakammaṃ avisesena samudayasaccanti saccavibhaṅge vuttaṃ. (Chú giải Abhidhamma, tập 2, tr. 185.)

Trong phần Phân tích các đế, Đức Phật dạy chung rằng tất cả nghiệp thiện và bất thiện là tập đế, không giới hạn ở tư hoặc những pháp tương ưng với tư. (Chú giải Abhidhamma, tập 2, tr. 185.)

Lại nữa, trong Kinh Titthāyatanasutta thuộc chương Ba pháp của Aṅguttara, Đức Phật dạy về tập đế như sau.


<a id="M05-body-P022"></a>
## Chuỗi Duyên khởi và Thánh đế về nguồn gốc khổ
Miến / Burmese 22

Katamañca, bhikkhave, dukkhasamudayaṃ ariyasaccaṃ? Avijjāpaccayā saṅkhārā, saṅkhārapaccayā viññāṇaṃ, viññāṇapaccayā nāmarūpaṃ, nāmarūpapaccayā saḷāyatanaṃ, saḷāyatanapaccayā phasso, phassapaccayā vedanā, vedanāpaccayā taṇhā, taṇhāpaccayā upādānaṃ, upādānapaccayā bhavo, bhavapaccayā jāti, jātipaccayā jarāmaraṇaṃ sokaparidevadukkhadomanassupāyāsā sambhavanti. Evametassa kevalassa dukkhakkhandhassa samudayo hoti. Idaṃ vuccati, bhikkhave, dukkhasamudayaṃ ariyasaccaṃ. (Aṅguttara, tập 1, tr. 178.)

Này các tỳ-khưu, thế nào là Thánh đế về nguồn gốc khổ?
1. Do vô minh sinh, hành sinh.
2. Do hành sinh, thức sinh.
3. Do thức sinh, danh sắc sinh.
4. Do danh sắc sinh, sáu xứ sinh.
5. Do sáu xứ sinh, xúc sinh.
6. Do xúc sinh, thọ sinh.
7. Do thọ sinh, ái sinh.
8. Do ái sinh, thủ sinh.
9. Do thủ sinh, hữu sinh.
10. Do hữu sinh, sinh sinh.
11. Do sinh, già chết, sầu, bi, khổ, ưu và não hiện khởi.

Như vậy, nguyên nhân sinh khởi của toàn bộ khối khổ không có chút an lạc này, nói cách khác, sự sinh khởi của toàn bộ khối khổ, hiện rõ. Này các tỳ-khưu, mối liên hệ nhân quả của Duyên khởi này là Thánh đế về nguồn gốc khổ…


<a id="M05-body-P023"></a>
## Ái nào là nguồn gốc của khổ hiện tại?
Miến / Burmese 23

…được gọi như vậy. (Aṅguttara, tập 1, tr. 178.)

Trong Kinh Titthāyatana, Đức Phật gọi toàn bộ mối liên hệ nhân quả giữa các nhân và các quả là tập đế.

Ái ấy từ khi nào?

Đức Phật quả có dạy rằng ái là tập đế. Nhưng cần suy xét kỹ ái được gọi là tập đế, tức nhân gốc của các pháp thuộc khổ đế hiện tại, là ái sinh khởi từ khi nào.

Rūpārūpaṃ panetaṃ hoti dukkhasaccaṃ, taṃsamuṭṭhāpikā purimataṇhā samudayasaccaṃ. (Chú giải Abhidhamma, tập 2, tr. 68–69.)

Danh và sắc là năm uẩn. Năm uẩn ấy là khổ đế. Ái đã được tạo tác và vun bồi từ trước, làm sinh khởi khổ đế ấy, là tập đế. (Chú giải Abhidhamma, tập 2, tr. 68–69.)

Theo lời giải thích trên, hãy hiểu rằng ái gọi là tập đế, nhân gốc thật sự của năm thủ uẩn thuộc khổ đế hiện có trong dòng tương tục của thiện hữu, là ái đã được tạo tác và vun bồi trong những đời trước.

Lời giải thích của chú giải này phù hợp với lời Đức Phật dạy và phù hợp với ý nghĩa đoạn Pāli Paṭisambhidāmagga đã nêu trên. Khi tạo tác và vun bồi nghiệp gọi là nghiệp hữu…


<a id="M05-body-P024"></a>
## Phân biệt hành và nghiệp hữu
Miến / Burmese 24

…si, tức sự biết sai, sinh trong đời quá khứ xa xưa gọi là vô minh. Những pháp nỗ lực làm cho nghiệp sinh khởi là hành. Mê đắm hữu và cảnh tương ứng, tức nikanti, là ái. Tâm tiến đến và bám lấy hữu hay cảnh ấy là thủ. Tư thiện hay tư bất thiện là hữu. Năm pháp sinh khởi khi tạo tác, vun bồi nghiệp hữu trong đời quá khứ ấy là các nhân của tái tục trong đời hiện tại này. Đối với loài người, chúng là các nhân của năm uẩn tái tục. (Paṭisambhidāmagga, tr. 50.)

Ý chính của đoạn Pāli này là hành và nghiệp đã được tạo tác dưới sự chi phối của vô minh, ái và thủ trong đời quá khứ khi vun bồi nghiệp trước kia chính là nhân gốc của năm uẩn tái tục hiện tại, tức các uẩn quả. Ở đây, hãy hiểu cách phân định hành với nghiệp hữu, tức nghiệp, qua ví dụ về một việc bố thí.

1. Trong khi chuẩn bị làm một việc bố thí thiện, các tư trước khi trao vật thí là hành. Tư thiết lập vật thí trong tay người nhận, tức tư buông xả (muñcanacetanā), là nghiệp hữu.

2. Theo cách khác, trong các lộ tâm tốc hành qua ý môn sinh khi tạo tác và vun bồi một nghiệp, các tư ở sáu tốc hành đầu trong bảy tốc hành được gọi là hành nỗ lực (āyūhanasaṅkhāra), tức những nhân nỗ lực khiến nghiệp sinh khởi. Còn tư ở tốc hành thứ bảy…


<a id="M05-body-P025"></a>
## Tư, hành và sức mạnh của nghiệp duyên
Miến / Burmese 25

…là tư ở tốc hành thứ bảy, gọi là nghiệp hữu.

3. Theo cách khác, tư trong một sát-na tốc hành khi tạo tác và vun bồi một nghiệp được gọi là nghiệp hữu. Tâm và các tâm sở đồng sinh, tức các pháp tương ưng với tư ấy, được gọi là hành nỗ lực (āyūhanasaṅkhāra). (Chú giải Abhidhamma, tập 2, tr. 182–183.)

Sức mạnh của nghiệp duyên

Kusalākusalaṃ kammaṃ vipākānaṃ khandhānaṃ kaṭattā ca rūpānaṃ kammapaccayena paccayo. (Paṭṭhāna, tập 1, tr. 7.)

Kammapaccayenāti anekampi kappakoṭīnaṃ matthake attano phalaṃ uppādetuṃ samatthena nānakkhaṇikakammapaccayenāti attho. Kusalākusalañhi kammaṃ attano pavattikkhaṇe phalaṃ na deti. Yadi dadeyya, yaṃ manusso devalokūpagaṃ kusalaṃ kammaṃ karoti, taṃānubhāvena tasmiṃyeva khaṇe devo bhaveyya. Yasmiṃ pana khaṇe taṃ kataṃ, tato aññasmiṃ khaṇe avijjamānampi kevalaṃ kaṭattāyeva diṭṭheva dhamme upapajje vā apare vā pariyāye avasesapaccayasamāyoge sati phalaṃ uppādeti, niruddhāpi purimasippādikiriyā viya kālantare pacchimasippādikiriyāya. Tasmā nānakkhaṇikakammapaccayoti vuccati. (Chú giải Abhidhamma, tập 3, tr. 374.)

Thiện hữu hãy xét năm nhân của các uẩn quả hiện tại, lấy nghiệp làm điểm chính. Hãy lưu ý nghiệp ấy được vô minh, ái và thủ bao quanh. Trong phần nói về nghiệp duyên, Đức Phật dạy như sau.

Nghiệp thiện và nghiệp bất thiện trợ duyên cho các uẩn quả và cho các sắc do nghiệp đã làm mà sinh…


<a id="M05-body-P026"></a>
## Nghiệp khác sát-na và thời điểm trổ quả
Miến / Burmese 26

…bằng sức của nghiệp duyên. (Paṭṭhāna, tập 1, tr. 7.)

“Bằng sức của nghiệp duyên” có nghĩa như sau. Dù đã trải qua nhiều koṭi kiếp, nghiệp đã tạo tác và tích lũy vẫn trợ duyên bằng sức của nghiệp duyên khác sát-na (nānakkhaṇikakammapaccaya), có khả năng làm sinh quả của nó. “Nghiệp khác sát-na” chỉ duyên mà thời điểm của nhân nghiệp và thời điểm quả sinh khởi khác nhau.

Nghiệp thiện và nghiệp bất thiện không cho quả ngay trong sát-na nó đang diễn ra. Nếu nó có khả năng cho quả ngay khi đang diễn ra, khi một người tạo nghiệp thiện đưa đến cõi trời thì người ấy sẽ lập tức thành một vị trời. Nhưng sự việc không diễn ra như vậy.

Khi một nghiệp được tạo do ước muốn, sau sát-na tạo nghiệp ấy, nghiệp không còn hiện hữu như một pháp hiện tại. Tuy vậy, chính vì nghiệp ấy đã được làm, khi hội đủ các duyên còn lại thì quả có thể sinh trong đời hiện tại nếu đó là nghiệp cho quả hiện đời (diṭṭhadhammavedanīyakamma), trong đời thứ hai kế tiếp nếu là nghiệp cho quả đời kế (upapajjavedanīyakamma), hoặc trong một đời thích hợp từ đời thứ ba trở đi nếu là nghiệp cho quả các đời sau (aparāpariyavedanīyakamma). Các duyên thích hợp gồm sự thành tựu hay bất lợi về cảnh giới tái sinh, thân tướng, thời kỳ và nỗ lực, tùy theo nghiệp thiện hay bất thiện.


<a id="M05-body-P027"></a>
## Vì sao gọi là nghiệp duyên khác sát-na?
Miến / Burmese 27

Như việc học nghề trước đây, dù đã chấm dứt, vẫn làm nền và trợ giúp cho việc thực hành nghề về sau khi đến lúc thích hợp, tư gọi là nghiệp cũng vậy. Tư trợ duyên cho quả sinh vào một thời điểm sau khi nghiệp đã được tạo tác và tích lũy. Vì thế gọi là nghiệp duyên khác sát-na, tức tư sinh ở sát-na khác với sát-na quả được cho. (Chú giải Abhidhamma, tập 3, tr. 374.)

Sức làm cho quả sinh khởi của tư đã được tạo tác, vun bồi từ đời quá khứ xa xưa hay từ nhiều koṭi kiếp, dù tư ấy không còn hiện hữu như một pháp hiện tại, gọi là sức nghiệp (kammasatti). Thiện hữu hãy suy xét điều này, lấy sức nghiệp làm điểm chính.

Nếu nghiệp cho quả ngay khi đang được tạo, như đã giải thích trong chú giải, khi một người tạo nghiệp thiện đưa đến cõi trời thì ngay lúc tạo nghiệp người ấy phải thành một vị trời. Điều ấy không xảy ra. Cũng vậy, nếu một người muốn đạt tuổi trưởng thành và tạo nghiệp để thành người nam hay người nữ mười sáu tuổi, thì ngay khi tạo nghiệp ấy người đó phải thành người mười sáu tuổi. Điều ấy cũng không xảy ra. Nếu quả sinh như vậy thì thế gian sẽ không có người già, người bệnh hay người chết. Vì sao? Vì mọi người sẽ làm việc thiện rồi cầu cho mình khỏi già, khỏi bệnh, khỏi chết. Nói gọn, trên đời cũng sẽ không còn người xấu…


<a id="M05-body-P028"></a>
## Duyên quá khứ và thời gian tích lũy ba-la-mật
Miến / Burmese 28

…vì mọi người sẽ làm việc thiện rồi cầu trở thành người đứng đầu thế gian, như vị vua Chuyển luân. Ngay cả nghiệp có khả năng cho quả trong đời hiện tại (diṭṭhadhammavedanīyakamma) cũng chỉ cho quả sau một khoảng thời gian kể từ lúc tạo nghiệp. Các nghiệp khác lại không như thế.

Vì vậy, khi suy xét năm nhân quá khứ mà lấy nghiệp làm điểm chính, thiện hữu có thể chấp nhận rằng các pháp thuộc khổ đế của đời này hiện khởi do tập đế đã được tạo tác, vun bồi trong quá khứ. Nếu thiện hữu không thể chấp nhận rằng năm uẩn tái tục và các pháp thuộc khổ đế trong đời hiện tại hiện khởi do nghiệp, gọi là tập đế, đã được vun bồi từ trước, thì hãy suy xét vì sao các vị Bồ-tát Chánh Đẳng Giác phải vun bồi ba-la-mật để thành tựu tuệ giác của một vị Phật Chánh Đẳng Giác trong bốn a-tăng-kỳ và một trăm nghìn kiếp.

Hãy suy xét tương tự đối với vị hướng đến tuệ giác Độc Giác trong hai a-tăng-kỳ và một trăm nghìn kiếp, vị hướng đến tuệ giác của thượng thủ đệ tử trong một a-tăng-kỳ và một trăm nghìn kiếp, và vị hướng đến tuệ giác của đại đệ tử trong một trăm nghìn kiếp. Liệu các vị ấy có cần phải vun bồi ba-la-mật suốt thời gian đó hay không? Hãy suy xét lại. Chỉ vì không chấp nhận rằng tập đế đã được tạo tác trong quá khứ…


<a id="M05-body-P029"></a>
## Suy luận và trực chứng
Miến / Burmese 29

…làm cho các pháp thuộc vòng quả, tức khổ đế, hiện khởi rõ ràng trong đời này.

Suy luận và trực chứng (anumāna và paccakkha)

Giả sử thiện hữu chấp nhận rằng: “Quá khứ đã diệt, nay không còn. Tương lai chưa đến, nên chưa hiện khởi. Vì vậy, hành giả chỉ có thể quán quá khứ và tương lai bằng cách suy đoán, tức bằng suy luận.”

Tương tự, giả sử vị ấy chấp nhận rằng hành giả chỉ có thể quán bằng suy luận cách năm quả hiện tại phát sinh do năm nhân quá khứ, và cách năm quả tương lai phát sinh do năm nhân hiện tại.

Nếu chấp nhận như vậy, thì hàm ý rằng các bậc thánh, đặc biệt các vị đại thánh đệ tử đứng đầu là Tôn giả Ānanda và các vị khác, cũng chỉ biết mối liên hệ nhân quả của Duyên khởi và cách khổ đế sinh do tập đế bằng suy luận. Đó là hệ quả của cách nói ấy. Tuy nhiên, trong các bài kinh do Đức Phật thuyết và trong các chú giải, có lời như sau.

Idha, bhikkhave, bhikkhu “idaṃ dukkhan”ti yathābhūtaṃ pajānāti, “ayaṃ dukkhasamudayo”ti yathābhūtaṃ pajānāti, “ayaṃ dukkhanirodho”ti yathābhūtaṃ pajānāti, “ayaṃ dukkhanirodhagāminī paṭipadā”ti yathābhūtaṃ pajānāti. (Majjhima, tập 1, tr. 82.)


<a id="M05-body-P030"></a>
## Biết bốn Thánh đế đúng như thật
Miến / Burmese 30

Này các tỳ-khưu, ở đây, vị tỳ-khưu hành thiền trong giáo pháp này biết phân minh, đúng như thật và không sai lệch: “Đây là Thánh đế về khổ.” Vị ấy biết phân minh, đúng như thật và không sai lệch: “Đây là Thánh đế về nguyên nhân sinh khổ.” Vị ấy biết phân minh, đúng như thật và không sai lệch: “Đây là Thánh đế về sự diệt khổ.” Vị ấy biết phân minh, đúng như thật và không sai lệch: “Đây là Thánh đế về con đường dẫn đến Niết-bàn, nơi khổ chấm dứt.” (Majjhima, tập 1, tr. 82.)

Trong những bài kinh như vậy, các bậc thánh được nói là tự mình trực tiếp thấu suốt bốn Thánh đế đúng như thật bằng tuệ chánh kiến. Các bài kinh ấy không nói rằng các vị chỉ biết bằng cách suy đoán, tức bằng suy luận.

“Ayaṃ lokiyo, ayaṃ lokuttaro”ti ariyaṃ aṭṭhaṅgikaṃ maggaṃ yathābhūtaṃ na pajānāti, ajānanto lokiyamagge abhinivisitvā lokuttaraṃ nibbattetuṃ na sakkoti. (Chú giải Majjhima, tập 2, tr. 165.)

Nếu hành giả không biết phân minh, đúng như thật và không sai lệch bằng tuệ chánh kiến rằng “đây là đạo đế hiệp thế, đây là Thánh đế về đạo siêu thế”, tức con đường cao quý gồm tám chi, thì vị ấy không thể đặt minh sát vào đạo đế hiệp thế, hay tu tập đạo đế hiệp thế, để làm sinh khởi Thánh đế về đạo siêu thế. (Chú giải Majjhima, tập 2, tr. 165.)

Chỉ khi hành giả tự mình trực tiếp thấu suốt bằng tuệ chánh kiến đúng như thật cả các pháp thuộc khổ đế và tập đế, lẫn cách khổ đế sinh do tập đế…


<a id="M05-body-P031"></a>
## Hai đế thuộc luân hồi và hai đế thoát luân hồi
Miến / Burmese 31

…thì mới có thể đặt các pháp thuộc khổ đế và tập đế dưới ba đặc tướng mà tu tập đề mục minh sát. Nỗ lực tu tập như vậy chính là tu tập đạo đế. Chỉ khi tu tập đạo đế hiệp thế mới có thể đạt đạo đế siêu thế và diệt đế siêu thế. Hãy đọc phần giải thích của chú giải sau đây.

Tattha purimāni dve saccāni vaṭṭaṃ, pacchimāni vivaṭṭaṃ. Tesu bhikkhuno vaṭṭe kammaṭṭhānābhiniveso hoti, vivaṭṭe natthi abhiniveso. (Chú giải Abhidhamma, tập 2, tr. 109.)

Trong bốn đế ấy, hai đế đầu là khổ đế và tập đế thuộc luân hồi. Hai đế sau là diệt đế và đạo đế thuộc phần thoát luân hồi. Trong hai nhóm ấy, vị tỳ-khưu hành thiền đặt đề mục minh sát vào các đế thuộc luân hồi. Vị ấy không đặt đề mục minh sát vào các đế thuộc phần thoát luân hồi. Ở đây đạo đế thuộc phần thoát luân hồi là đạo đế siêu thế.

Theo lời giải thích của chú giải này, hành giả tu tập đề mục minh sát trên hai đế hiệp thế là khổ đế và tập đế. Chỉ khi có thể quán sát và tu tập minh sát thấu đáo trên hai đế hiệp thế này thì hai đế siêu thế mới có thể hiện khởi rõ ràng. Nếu chưa biết cả bốn đế thì điều gì có thể xảy ra?

Trích Kinh Nhà Có Nóc Nhọn (Kūṭāgārasutta)

Yo ca kho, bhikkhave, evaṃ vadeyya: “Ahaṃ dukkhaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca, dukkhasamudayaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca…


<a id="M05-body-P032"></a>
## Điều kiện để chấm dứt khổ
Miến / Burmese 32

…dukkhanirodhaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca, dukkhanirodhagāminiṃ paṭipadaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca sammā dukkhassantaṃ karissāmī”ti, netaṃ ṭhānaṃ vijjati. (Saṃyutta, tập 3, tr. 394.)

Yo ca kho, bhikkhave, evaṃ vadeyya: “Ahaṃ dukkhaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca, dukkhasamudayaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca, dukkhanirodhaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca, dukkhanirodhagāminiṃ paṭipadaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca sammā dukkhassantaṃ karissāmī”ti, ṭhānametaṃ vijjati. (Saṃyutta, tập 3, tr. 394.)

Này các tỳ-khưu, giả sử có người nói: “Tôi sẽ hoàn toàn chấm dứt khổ luân hồi dù chưa tự mình trực tiếp thấu suốt đúng như thật, không sai lệch, bằng tuệ chánh kiến, Thánh đế về khổ, Thánh đế về nguyên nhân sinh khổ, Thánh đế về sự diệt khổ và Thánh đế về con đường dẫn đến Niết-bàn, nơi khổ chấm dứt.” Người ấy nói như vậy thì không có trường hợp lời nói ấy có thể thành sự thật. (Saṃyutta, tập 3, tr. 394.)

Này các tỳ-khưu, giả sử có người nói: “Sau khi tự mình trực tiếp thấu suốt đúng như thật, không sai lệch, bằng tuệ chánh kiến, Thánh đế về khổ và Thánh đế về nguyên nhân sinh khổ…


<a id="M05-body-P033"></a>
## Nỗ lực trực chứng bốn Thánh đế
Miến / Burmese 33

…và sau khi tự mình trực tiếp thấu suốt đúng như thật, không sai lệch, bằng tuệ chánh kiến, Thánh đế về sự diệt khổ và Thánh đế về con đường dẫn đến Niết-bàn, nơi khổ chấm dứt, tôi sẽ hoàn toàn chấm dứt khổ luân hồi.” Người ấy nói như vậy thì có trường hợp lời nói ấy có thể thành sự thật. (Saṃyutta, tập 3, tr. 394–395.)

Theo những lời dạy này, để chấm dứt hẳn nỗi khổ lớn của luân hồi và hoàn toàn thoát khỏi nỗi khổ ấy, thiện hữu phải gắng sức tự mình trực tiếp thấu suốt bốn đế bằng tuệ chánh kiến. Khi gắng sức như vậy, trước hết phải cố gắng biết rõ các pháp thuộc khổ đế và tập đế, cách khổ đế sinh do tập đế, và các tướng vô thường, khổ, vô ngã của các pháp thuộc hai đế ấy. Chỉ khi đó, ở chặng cuối của các tuệ minh sát đã chín muồi, hai đế siêu thế là diệt đế và đạo đế mới có thể hiện khởi. Vì thế, để trực tiếp thấu suốt cả bốn đế bằng con mắt tuệ chánh kiến, thiện hữu hãy ghi nhớ rằng phải nỗ lực biết rõ từng mối liên hệ nhân quả của Duyên khởi bằng ba loại tuệ liễu tri.


<a id="M05-body-P034"></a>
## Để đạt trí nắm bắt các duyên
Miến / Burmese 34

Vipassakena pana kammassa ca vipākassa ca ekadesato jānitabbaṃ. (Thanh tịnh đạo, tập 2, tr. 237.)

Ekadesato jānitabbaṃ, anavasesato jānituṃ na sakkā avisayattā. Sabbena sabbaṃ ajānane paccayapariggaho na paripūrati. (Đại phụ chú giải Thanh tịnh đạo, tập 2, tr. 380.)

Người đang nỗ lực tu tập đề mục minh sát cần biết một phần những sai biệt của các nghiệp, chẳng hạn nghiệp có sức hay không có sức, và những sai biệt của quả, chẳng hạn quả thấp kém hay cao quý. Biết nghiệp và quả của nghiệp một cách toàn diện, không sót gì, vượt ngoài phạm vi của các vị đệ tử. Đó là phạm vi của chư Phật Chánh Đẳng Giác có trí toàn giác. Tuy nhiên, nếu hoàn toàn không biết gì về nghiệp và quả của nghiệp, thì trí nắm bắt các duyên không thể viên mãn. (Thanh tịnh đạo, tập 2, tr. 237. Đại phụ chú giải Thanh tịnh đạo, tập 2, tr. 380.)

Vì hoàn toàn không biết nghiệp và quả của nghiệp thì không thể có trí nắm bắt các duyên, nên để đạt trí ấy, thiện hữu phải nỗ lực biết nghiệp và quả của nghiệp ít nhất một phần. Ở đây, trí nắm bắt các duyên cũng chính là trí biết cách khổ đế sinh do tập đế.

Thiện hữu có thể đã biết hoặc đã nghe rằng Đức Phật có ba mươi hai tướng của bậc đại nhân. Trong số ấy, mỗi tướng…


<a id="M05-body-P035"></a>
## Nghiệp riêng, quả riêng, và hai cách biết quá khứ
Miến / Burmese 35

…có nghiệp tương ứng riêng đã cho quả. Tướng đỉnh đầu, tướng răng và tướng lưỡi đều do nghiệp riêng tương ứng mà có. Nghiệp làm nhân và tướng làm quả được phân biệt như vậy. Tương tự, trong một đời, những quả tốt và xấu một người gặp có rất nhiều loại. Quả tốt do nghiệp thiện, quả xấu do nghiệp bất thiện. Các loại quả tốt khác nhau có những nghiệp thiện tương ứng làm chúng sinh khởi. Các loại quả xấu khác nhau cũng có những nghiệp bất thiện tương ứng làm chúng sinh khởi. Các vị đệ tử không thể biết hết từng loại nghiệp và từng loại quả. Các vị chỉ có thể biết một phần.

Thắng trí và minh sát

Các bản văn có nói rằng với túc mạng minh, tức thắng trí nhớ lại đời trước (pubbenivāsānussati-abhiññā), có thể quán quá khứ. Các bản văn cũng nói rằng với trí biết tương lai (anāgataṃsañāṇa), một phương diện của thắng trí thiên nhãn, có thể quán tương lai. Những điều ấy dễ được chấp nhận. Nhưng người ta không muốn chấp nhận rằng bằng tuệ minh sát cũng có thể quán các uẩn quá khứ và tương lai. Về khả năng quán các thủ uẩn quá khứ và tương lai bằng tuệ minh sát, lời Phật trong Pāli và lời giải thích của chú giải như sau.


<a id="M05-body-P036"></a>
## Nhớ lại đời trước theo Kinh Khajjanīya
Miến / Burmese 36

Ye hi keci, bhikkhave, samaṇā vā brāhmaṇā vā anekavihitaṃ pubbenivāsaṃ anussaramānā anussaranti, sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataraṃ. (Saṃyutta, tập 2, tr. 71. Khajjanīyasutta.)

Pubbenivāsanti na idaṃ abhiññāvasena anussaraṇaṃ sandhāya vuttaṃ. Vipassanāvasena pana pubbenivāsaṃ anussaraṇe samaṇabrāhmaṇe sandhāyetaṃ vuttaṃ. Tenevāha “sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataran”ti. Abhiññāvasena hi samanussarantassa khandhāpi upādānakkhandhāpi khandhapaṭibaddhāpi paññattipi ārammaṇaṃ hotiyeva. Rūpaṃyeva anussaratīti evaṃ hi anussaraṇena na aññaṃ kiñci sattaṃ vā puggalaṃ vā anussarati, atīte pana niruddhaṃ rūpakkhandhameva anussarati. Vedanādīsupi eseva nayo. (Chú giải Saṃyutta, tập 2, tr. 266.)

Này các tỳ-khưu, bất cứ sa-môn hay bà-la-môn nào nhớ lại nhiều đời sống trước và lần theo dòng các uẩn ấy bằng trí, nếu có nhớ lại được thì họ nhớ lại theo dòng ấy bằng trí. Tất cả những sa-môn và bà-la-môn nhớ lại được như vậy đều nhớ lại năm thủ uẩn, hoặc một uẩn trong năm thủ uẩn ấy. (Saṃyutta, tập 2, tr. 71.)

Trong đoạn Pāli này, Đức Phật dùng chữ pubbenivāsa, “đời sống trước”, với ý chỉ sự nhớ lại bằng cách dùng trí lần theo dòng các uẩn. Ý ở đây là các sa-môn và bà-la-môn dùng tuệ minh sát để lần theo dòng các uẩn của những đời trước và nhớ lại…


<a id="M05-body-P037"></a>
## Các đối tượng của thắng trí nhớ đời trước
Miến / Burmese 37

…nên Đức Phật dùng chữ pubbenivāsa theo ý ấy. Chính vì vậy, Ngài nói tiếp như sau.

Sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataraṃ.

Tất cả những sa-môn và bà-la-môn ấy đều có thể dùng trí lần theo và nhớ lại năm thủ uẩn. Họ cũng có thể dùng trí lần theo và nhớ lại riêng một uẩn trong năm thủ uẩn ấy. (Saṃyutta, tập 2, tr. 71.)

Đức Phật đã dạy như vậy. Lý do là thế này. Đối với các sa-môn và bà-la-môn dùng sức thắng trí nhớ đời trước để lần theo dòng các uẩn của những đời trước, các cảnh của thắng trí ấy có bốn loại:
1. Năm uẩn, kể cả các pháp siêu thế.
2. Năm thủ uẩn, trong đó không có các pháp siêu thế.
3. Những gì liên hệ với các uẩn, như dòng họ, sắc diện, thức ăn, vui và khổ.
4. Các tên gọi, tức những chế định khác nhau.

Đức Phật không nói ở đây rằng người ta có thể dùng trí lần theo và nhớ lại cả bốn loại cảnh ấy. Ngài chỉ nói rằng họ có thể dùng trí lần theo và nhớ lại năm thủ uẩn hay một uẩn trong số đó. Vì thế, ở đây Đức Phật có ý nói đến sự dùng trí lần theo và nhớ lại dòng các uẩn của những đời trước…


<a id="M05-body-P038"></a>
## Quán các uẩn quá khứ bằng tuệ minh sát
Miến / Burmese 38

…bằng tuệ minh sát. Khi dùng tuệ minh sát lần theo và nhớ lại dòng các uẩn của những đời trước như vậy, hành giả không lần theo và nhớ lại một cá nhân, chúng sinh hay con người nào. Hành giả có thể dùng tuệ minh sát lần theo và nhớ lại sắc, thọ, tưởng, hành và thức đã diệt trong quá khứ. Ý ở đây là như vậy. (Saṃyutta, tập 2, tr. 71. Chú giải Saṃyutta, tập 2, tr. 266.)

Trên đây là một đoạn trong lời dạy trực tiếp của Đức Phật cùng lời giải thích của chú giải, cho thấy sự khác biệt giữa thắng trí nhớ đời trước và tuệ minh sát, và làm căn cứ cho việc dùng tuệ minh sát để quán quá khứ và tương lai.

Ở đây, thiện hữu cũng nên suy xét thêm rằng các vị A-la-hán thuộc hạng thuần quán (sukkhavipassaka), tức lấy thuần minh sát làm cỗ xe (suddhavipassanāyānika), cũng đã tự mình trực tiếp thấu suốt bốn Thánh đế bằng tuệ chánh kiến. Thiện hữu hãy nỗ lực để đi đúng theo lời dạy chân thật trong giáo pháp của Đức Phật.


<a id="M05-body-P039"></a>
## Phần 2. Một trình tự tìm các nhân
Miến / Burmese 39

Paccayapariggahe paññā dhammaṭṭhitiñāṇaṃ. (Paṭisambhidāmagga, tr. 1.)

“Nāmarūpavavatthāne ñāṇan”ti avatvā eva kasmā “dhammaṭṭhitiñāṇan”ti vuttanti ce? Paccayapariggaheneva paccayasamuppannapariggahitattā siddhattaṃ. Paccayasamuppanne hi apariggahite paccayapariggaho na sakkā hoti kātuṃ. Tasmā dhammaṭṭhitiñāṇaggahaṇeneva tassa hetubhūtaṃ pubbe siddhaṃ nāmarūpavavatthānañāṇaṃ vuttameva hotīti veditabbaṃ. (Chú giải Paṭisambhidāmagga, tập 1, tr. 18.)

Các nhân có khả năng làm cho các quả hiện khởi. Vì năng lực ấy hiện hữu nên nói các nhân có thể nâng đỡ các quả. Do các quả tồn tại và sinh khởi nhờ các nhân, những nhân ấy là chỗ đứng của các quả, gọi là dhammaṭṭhiti. Trí thấu suốt các nhân làm chỗ đứng cho các quả ấy gọi là trí biết sự tồn tại của các pháp do duyên (dhammaṭṭhitiñāṇa).

Nếu hỏi vì sao ở đây nói trí biết sự tồn tại của các pháp do duyên, mà không nói trí phân định danh sắc (nāmarūpavavatthānañāṇa)…


<a id="M05-body-P040"></a>
## Quán các quả trước khi tìm nhân
Miến / Burmese 40

…thì câu trả lời như sau.

Quán được các nhân hàm ý rằng việc quán các quả đã thành tựu. Quả thật, khi chưa quán các quả, không thể tiến hành quán các nhân. Tuy nhân thực sự có khả năng sinh quả, chỉ khi phân định và quán bằng trí những quả sinh do nhân ấy mới có thể biết rằng nhân đó có khả năng sinh quả. Vì thế, khi trực tiếp nêu trí biết sự tồn tại của các pháp do duyên, cũng đã nêu trí phân định danh sắc, vốn là nhân gốc của trí ấy và đã thành tựu từ trước. Hãy hiểu như vậy. (Chú giải Paṭisambhidāmagga, tập 1, tr. 18.)

Theo lời giải thích của chú giải này, hành giả muốn phân định bằng trí và quán các nhân (paccayapariggaha) phải cố gắng trước hết quán và phân định sắc pháp, danh pháp làm quả, tức các pháp được trợ (paccayasamuppanna). Đây gọi là trí phân định danh sắc (nāmarūpavavatthānañāṇa). Ý chính như sau. Khi hành giả muốn phân định và quán các nhân quá khứ, cần quán cả sắc pháp và danh pháp hiện tại, tức các pháp được trợ hiện khởi do các nhân quá khứ, lẫn sắc pháp và danh pháp quá khứ được trợ, vốn là nơi nương của các nhân quá khứ ấy…


<a id="M05-body-P041"></a>
## Danh sắc quá khứ, hiện tại và tương lai
Miến / Burmese 41

…và đã phân định chúng bằng trí. Lại nữa, nếu hành giả muốn phân định và dùng tuệ quán xem năm quả tương lai, tức danh sắc được trợ, sinh do năm nhân hiện tại, thì cần quán và phân định cả danh sắc hiện tại là nơi nương của các nhân hiện tại như vô minh, ái, thủ, hành và nghiệp, lẫn danh sắc tương lai là năm quả sẽ hiện khởi do các nhân hiện tại.

Năm quả hiện tại là một phần trong năm uẩn hiện tại. Năm nhân hiện tại cũng là một phần trong năm uẩn hiện tại. Tương tự, năm nhân quá khứ là một phần trong năm uẩn quá khứ và năm quả tương lai là một phần trong năm uẩn tương lai. Vì vậy, khi đã quán có hệ thống năm uẩn quá khứ, năm uẩn hiện tại và năm uẩn tương lai đến mức biết chúng là pháp chân đế, hành giả có thể dễ dàng quán những phần tương ứng là năm nhân quá khứ, năm quả hiện tại, năm nhân hiện tại và năm quả tương lai.

Nói cách khác, hành giả có thể dễ dàng quán và dùng trí phân định cách năm quả hiện tại hiện khởi do năm nhân quá khứ, và cách năm quả tương lai hiện khởi do năm nhân hiện tại. Hãy hiểu tương tự đối với các đời quá khứ nối tiếp và các đời tương lai nối tiếp. Vì vậy, trước khi quán xem các quả sinh do các nhân như thế nào, thiện hữu…


<a id="M05-body-P042"></a>
## Bốn cách thuyết Duyên khởi
Miến / Burmese 42

…hãy ghi nhớ trước hai điểm là phải quán năm uẩn quá khứ, năm uẩn hiện tại và năm uẩn tương lai. Pháp Duyên khởi là mối liên hệ nhân quả giữa các pháp sắc và danh được trợ, vốn tồn tại trong ba thời quá khứ, tương lai và hiện tại.

Bốn cách thuyết pháp Duyên khởi

Trong Thanh tịnh đạo (tập 2, tr. 154–155) và phần giải về Duyên khởi trong Sammohavinodanī (Chú giải Abhidhamma, tập 2, tr. 124–125), các vị giải thích rõ rằng có bốn cách thuyết Duyên khởi, dùng ví dụ bốn cách nắm một dây leo (vallihārakanaya).

1. Do vô minh có hành. Cứ như vậy, bài pháp được thuyết tiếp đến cách già chết sinh do sinh. Đây là cách thuyết Duyên khởi theo chiều thuận (anuloma), từ đầu đến cuối.

2. Bắt đầu từ thọ ở giữa, Đức Phật thuyết mối liên hệ giữa nhân và quả đến cách sinh có do hữu. Đây cũng là một cách thuyết Duyên khởi theo chiều thuận, từ giữa đến cuối.


<a id="M05-body-P043"></a>
## Chiều nghịch và phương pháp thứ năm
Miến / Burmese 43

3. Cũng có cách thuyết ngược, bắt đầu từ già chết do sinh làm nhân, rồi đi ngược đến hành do vô minh làm nhân. Đây là cách thuyết Duyên khởi theo chiều nghịch (paṭiloma), từ cuối về đầu.

4. Bốn loại vật thực sinh do ái. Ái sinh do thọ. Cứ như vậy, Đức Phật thuyết đến hành sinh do vô minh. Đây cũng là một cách thuyết Duyên khởi theo chiều nghịch, từ giữa về đầu.

Trên đây là bốn cách thuyết Duyên khởi. Lại có một cách trong Pāli Paṭisambhidāmagga.

5. Bản văn Duyên khởi ấy trình bày cách năm quả hiện tại hiện khởi do năm nhân quá khứ và cách năm quả tương lai hiện khởi do năm nhân hiện tại.

Cách quán các nhân và các quả thành từng nhóm, như có trong Paṭisambhidāmagga, được gọi trong sách này là phương pháp thứ năm của Duyên khởi. Cách thứ năm dễ dạy cho một số hành giả còn yếu về trí căn bản của Abhidhamma.

Trong năm cách thuyết Duyên khởi này, thiện hữu có thể tìm các nhân và các quả bằng cách thuyết mình ưa thích. Trong các cách ấy, ở đây sẽ lấy cách thứ năm làm chính để trình bày cách quán mối liên hệ nhân quả…


<a id="M05-body-P044"></a>
## Lần từ giữa về đầu và nguyên tắc nhiều nhân nhiều quả
Miến / Burmese 44

…giữa nhân và quả. Trong phần bắt đầu tìm các nhân, dùng cách đi từ giữa về đầu.

Khi lần từ giữa về phía đầu để tìm các nhân, theo lời giải thích của Chú giải Paṭisambhidāmagga đã nêu ở trên, hành giả nào đã quán trước dòng năm uẩn liên tục từ năm uẩn hiện tại cho đến năm uẩn quá khứ sẽ thấy việc này dễ dàng hơn. Vì vậy, hãy quán năm uẩn, tức danh và sắc, từ năm uẩn hiện tại đến năm uẩn quá khứ. Để làm việc ấy, ở đây dựa vào cách quán dòng các uẩn quá khứ trong phần nói về thắng trí nhớ đời trước của Thanh tịnh đạo.

Sau khi quán dòng năm uẩn liên tục từ năm uẩn hiện tại đến năm uẩn quá khứ, hành giả cần lần theo và dùng tuệ quán xem năm uẩn hiện tại, tức các pháp quả, hiện khởi do năm nhân quá khứ cùng sinh trong năm uẩn quá khứ. Khi đã quán Duyên khởi thành công theo phương pháp thứ năm và có thể nối nhân với quả, các cách khác, như phương pháp thứ nhất của Duyên khởi, cũng trở nên rõ ràng và dễ hiểu đối với thiện hữu.

Một điểm cần biết trước

1. Ekato hi kāraṇato na idha kiñci ekaṃ phalamatthi.
2. Na anekaṃ.
3. Nāpi anekehi kāraṇehi ekaṃ.


<a id="M05-body-P045"></a>
## Vì sao bài pháp có khi chỉ nêu một nhân?
Miến / Burmese 45

4. Anekehi pana kāraṇehi anekameva hoti. (Chú giải Abhidhamma, tập 2, tr. 140. Thanh tịnh đạo, tập 2, tr. 174.)

1. Trong thế gian này, không có một quả đơn lẻ nào sinh do một nhân đơn lẻ.
2. Cũng không có nhiều quả sinh do một nhân đơn lẻ.
3. Cũng không có một quả đơn lẻ sinh do nhiều nhân.
4. Nói đúng theo thực tế, chỉ có nhiều quả sinh do nhiều nhân. (Chú giải Abhidhamma, tập 2, tr. 140. Thanh tịnh đạo, tập 2, tr. 174.)

Trong bài pháp, Đức Phật có khi nêu một nhân hay một quả vì đó là yếu tố chính (padhāna), vì đó là yếu tố nổi bật (pākaṭa), hoặc vì đó là yếu tố riêng biệt (asādhāraṇa). Ngài nêu như vậy theo trí toàn giác, nhân để trình bày bài pháp cho rõ đẹp, và theo căn tính của chúng sinh có thể được giáo hóa, tức những người, chư thiên và phạm thiên có thể được dẫn dắt. (Chú giải Abhidhamma, tập 2, tr. 140. Thanh tịnh đạo, tập 2, tr. 174.)


<a id="M05-body-P046"></a>
## Quán cả những pháp tương ưng
Miến / Burmese 46

Theo lời giải thích trên, vì một yếu tố là chính, nổi bật hay riêng biệt, Đức Phật có thể lấy một nhân hoặc một quả như vô minh làm tiêu biểu khi thuyết pháp. Ngài làm như vậy theo trí toàn giác, nhờ đó có thể trình bày bài pháp cho rõ đẹp, và phù hợp với sở thích, căn tính và khuynh hướng của những người có thể được dẫn dắt. Tuy nhiên, một quả không thể sinh do một nhân đơn lẻ, nhiều quả không thể sinh do một nhân đơn lẻ, và một quả không thể sinh do nhiều nhân. Điều có thật là nhiều quả sinh do nhiều nhân.

Không nên chấp rằng chỉ một pháp vô minh làm cho một mình hành sinh, rằng chỉ một mình sáu xứ làm cho một mình xúc sinh, hay rằng chỉ một xúc làm cho một thọ sinh. Hãy hiểu rằng nhiều quả sinh do nhiều nhân. Chỉ quán riêng từng pháp vô minh, xúc hay thọ là chưa đủ. Hãy ghi nhớ rằng cần quán cả những pháp tương ưng với vô minh, xúc và thọ ấy. Hãy hiểu tương tự đối với những chỗ khác.

Thử hướng trí về quá khứ

Trước hết hãy tuần tự thiết lập định. Luân phiên quán nhiều lần danh sắc bên trong và bên ngoài, trong dòng tương tục của mình và của người khác. Đặc biệt, đối với phần bên ngoài…


<a id="M05-body-P047"></a>
## Dùng định và ánh sáng để quán danh sắc
Miến / Burmese 47

…hãy ưu tiên quán danh sắc theo từng nhóm chúng sinh ở tuyến cảnh pháp, gọi là tuyến số 6. Đối với nhiều hành giả, khi thường xuyên và nhiều lần ưu tiên quán như vậy, sức của ánh sáng ngày càng mạnh. Hãy nhiều lần luân phiên quán danh sắc bên trong và bên ngoài. Trước khi tìm các nhân duyên, chính Đức Phật đã chỉ dạy trong Kinh Đại Niệm Xứ rằng phải quán danh sắc bên trong và bên ngoài. Điều này đã được giải thích trong phần đề mục thiền về danh trước đây. Đặc biệt, hành giả chưa thể quán danh sắc bên ngoài sẽ rất khó quán danh sắc quá khứ, vì quán danh sắc quá khứ có cùng tính chất với quán danh sắc bên ngoài.

Khi đã quán danh sắc bên trong và bên ngoài, sáu loại sắc trong suốt của chính mình, tức sắc trong suốt của mắt, tai, mũi, lưỡi, thân và ý môn, ngày càng hiện rõ trong trí. Nhờ trí đang quán danh sắc bên trong và bên ngoài ấy, ánh sáng cũng ngày càng mạnh. Khi ấy hãy thử xem các sắc pháp và danh pháp này đang hiện hữu do những nhân nào. Với tâm muốn biết các nhân, hãy hướng tâm về quá khứ. Hãy hướng trí về đó. Khi ánh sáng phát sinh nhờ trí ấy soi sáng chung quanh, nhiều hành giả nhận thấy ánh sáng dần dần chiếu rõ về phía đối tượng họ chú ý.


<a id="M05-body-P048"></a>
## Các cách tiếp tục tìm nhân quá khứ
Miến / Burmese 48

Hãy dùng ánh sáng của trí ấy chiếu về phía các nhân quá khứ để tìm chúng. Có khi một hành và nghiệp thiện đã được tạo tác, vun bồi trong quá khứ, làm nhân gốc cho danh sắc quả hiện tại, sẽ hiện ra. Đây là cách được nêu trong các chú giải. (Chú giải Abhidhamma, tập 2, tr. 241. Chú giải Majjhima, tập 1, tr. 281.)

Nếu thử tìm các nhân quá khứ bằng cách này mà chưa thành công, hãy dựa vào cách trong phần nói về thắng trí nhớ đời trước của Thanh tịnh đạo. Bắt đầu từ danh sắc đã sinh trong lần ngồi thiền gần nhất, lùi từng bước về quá khứ và thử quán danh sắc. Đây là cách nhiều hành giả đã thực hành thành công.

Nếu cách này cũng chưa thành công và vẫn chưa tìm được các nhân quá khứ, hãy thử dùng cách quán mối liên hệ nhân quả từ giữa về đầu, bắt đầu với bốn loại vật thực. Tuy nhiên, hành giả tìm các nhân bằng cách ấy cần thông thạo cách thuyết Duyên khởi.

Sau đây sẽ lần lượt trình bày cách dựa vào phương pháp trong phần nói về thắng trí nhớ đời trước, bắt đầu từ danh sắc đã sinh trong lần ngồi thiền gần nhất, để quán danh sắc quá khứ và tìm ra mối liên hệ nhân quả bằng cách quán.

Thiện hữu trước khi ngồi thiền hãy cúng dường Đức Phật bằng đèn, nước hay hoa, rồi phát nguyện như sau…


<a id="M05-body-P049"></a>
## Phát nguyện và quán danh sắc trước khi ngồi thiền
Miến / Burmese 49

Sau đó, hãy nguyện được sinh vào đời sống mà thiện hữu ưa thích, chẳng hạn đời sống của một vị tỳ-khưu hoặc đời sống của một người nữ, nếu còn phải lưu chuyển trong luân hồi trước khi đạt Niết-bàn. Vì nghiệp thiện còn dẫn đến luân hồi (vaṭṭanissita) thuộc tập đế, thiện hữu sẽ có thể dễ dàng tìm thấy cách khổ đế sinh do tập đế ấy. Nhờ vậy có thể tạo một nghiệp thiện còn dẫn đến luân hồi để quan sát. Hãy lưu ý và ghi nhớ dòng tâm đã sinh trong khi tạo nghiệp và phát nguyện.

Sau đó, tại nơi ngồi thiền, hãy thiết lập định theo từng bậc và quán danh sắc cả bên trong lẫn bên ngoài. Đặc biệt, hãy ưu tiên quán dòng tâm lộ tốc hành thiện thuộc tuyến cảnh pháp. Nếu là người lấy thiền chỉ làm cỗ xe, ở đây trước hết hãy ưu tiên quán các danh pháp thiền. Khi ánh sáng đã rất mạnh, hãy thử quán các danh pháp vừa sinh khi cử động trước lúc ngồi thiền, như dòng tâm cúng hoa, đèn hay nước, dòng tâm nguyện đời sống tỳ-khưu hay đời sống người nữ, và dòng tâm nguyện đạt Niết-bàn.

Khi muốn quán những danh pháp ấy, trước hết hãy quán 54 sắc cùng với sắc ý vật, là chỗ nương của chúng ở tim. Để quán những sắc ấy, trước hết hãy quán bốn đại trong thân lúc đang phát nguyện và làm việc thiện. Đặc biệt, hãy quán bốn đại ở vùng tim lúc ấy. Khi gặp các nhóm sắc (rūpakalāpa), hãy quán 54 sắc, kể cả sắc ý vật…


<a id="M05-body-P050"></a>
## Quán danh sắc vừa qua đối với người lấy thiền chỉ làm cỗ xe
Miến / Burmese 50

…rồi tiếp tục quán tâm hữu phần trong sáng sinh nương sắc ý vật ấy. Khi đã quán ý môn, tức hữu phần trong sáng, hãy lần tới lui trong dòng hữu phần và tiếp tục quán các danh pháp gọi là dòng tâm lộ, sinh xen giữa các tâm hữu phần. Khi đã quán các danh pháp ấy, hãy nhiều lần xem kỹ chúng có khớp với dòng tâm thật sự đã sinh trước khi ngồi thiền hay không. Nếu thấy chúng khớp, thì việc quán danh sắc quá khứ gần nhất, lúc còn cử động trước khi ngồi, đã thành công.

Trường hợp người lấy thiền chỉ làm cỗ xe

Nếu một thiện hữu lấy thiền chỉ làm cỗ xe và mong được an lạc nơi cõi phạm thiên, hãy theo nguyện vọng của mình mà nỗ lực tu tập để chứng một thiền chứng có thể đưa đến cõi phạm thiên tương ứng, như sơ thiền, nhị thiền hoặc một tầng thiền khác. Nếu đã thật sự chứng tầng thiền ấy, hãy nhập tầng thiền đó một lần. Ngay trước hoặc sau khi nhập thiền, hãy nguyện được sinh vào cõi phạm thiên tương ứng. Hoặc hãy quyết định về sự sinh ấy trong tâm. Sự phát nguyện hay quyết định trong tâm là sự tạo tác, vun bồi vòng phiền não do vô minh, ái và thủ dẫn đầu. Việc nhiều lần nhập thiền là sự tạo tác, vun bồi vòng nghiệp gồm hành và nghiệp.

Sau đó, thiện hữu hãy lần lượt quay lại quán cả danh pháp thuộc vòng phiền não và vòng nghiệp, cùng những sắc làm chỗ nương cho các danh pháp ấy…


<a id="M05-body-P051"></a>
## Vòng phiền não và vòng nghiệp
Miến / Burmese 51

…Nếu quán được danh sắc ấy thì việc quán danh sắc quá khứ gần nhất đã thành công. Khi quán danh sắc quá khứ như vậy, hãy nhớ ưu tiên quán sắc ý vật về phía sắc, và hữu phần trong sáng ở ý môn về phía danh.

Vòng phiền não và vòng nghiệp

Hãy giải thích thêm về vô minh, ái, thủ, hành và nghiệp đã nêu trên, là những pháp khiến luân hồi tiếp diễn. Vô minh, ái và thủ thuộc vòng phiền não. Hành và nghiệp thuộc vòng nghiệp. Vô minh không có sức sinh riêng lẻ. Ái và thủ cũng vậy. Chúng chỉ có khả năng sinh theo nhóm. Trong sự phát nguyện nói trên, ái đạt đến mức có thể khiến đời sống được mong cầu thành tựu thì được gọi là thủ.

Avijjāsamudayā āsavasamudayo. (Majjhima, tập 1, tr. 65.)
Āsavasamudayā avijjāsamudayo. (Majjhima, tập 1, tr. 65.)

Theo các lời dạy ấy, do vô minh làm nhân mà các lậu hoặc sinh khởi, và do các lậu hoặc làm nhân mà vô minh sinh khởi. Vô minh và các lậu hoặc là những pháp trợ duyên cho nhau. Trong các lậu hoặc có cả những pháp vô minh, ái và thủ. Do đó, trong vòng phiền não, vô minh cùng ái và thủ có thể cùng sinh trong một lộ tâm ý môn, hoặc cũng có thể sinh ở những lộ khác nhau. Trong phần Duyên khởi này, thông thường…


<a id="M05-body-P052"></a>
## Ba pháp thuộc vòng phiền não
Miến / Burmese 52

…chúng thường sinh trong nhóm tham hợp tà kiến. Hiếm khi chúng sinh trong nhóm tham đi cùng mạn. Hành có thể là hữu trợ hoặc vô trợ, tùy trường hợp. Ở đây lấy tâm căn tham thọ hỷ, hợp tà kiến, vô trợ làm ví dụ và ghi số 20. Tương tự, các pháp thuộc vòng nghiệp, gọi là hành và nghiệp, cũng chỉ sinh theo nhóm, không có sức sinh riêng lẻ. Ở đây lấy tâm đại thiện thọ hỷ, hợp trí, vô trợ làm ví dụ và ghi số 34. Tuy nhiên, vòng phiền não và vòng nghiệp có thể khác nhau tùy từng người và từng trường hợp. Hãy hiểu như vậy.

Ba pháp thuộc vòng phiền não

Khi cúng hoa, đèn hay nước lên Đức Phật rồi phát nguyện đời sống tỳ-khưu, ba pháp thuộc vòng phiền não là như sau:
1. Vô minh (20) — tính chất biết sai rằng có một vị tỳ-khưu.
2. Ái (20) — tính chất ham muốn và mê đắm đời sống tỳ-khưu.
3. Thủ (20) — tính chất tâm tiến đến và bám lấy đời sống tỳ-khưu.

Nếu thiện hữu là người nữ và phát nguyện đời sống người nữ, ba pháp thuộc vòng phiền não là như sau:
1. Vô minh (20) — tính chất biết sai rằng có một người nữ.
2. Ái (20) — tính chất ham muốn và mê đắm đời sống người nữ.
3. Thủ (20) — tính chất tâm tiến đến và bám lấy đời sống người nữ.

Ở đây số 20 chỉ cho toàn bộ nhóm tham hợp tà kiến trong mỗi sát-na tốc hành…


<a id="M05-body-P053"></a>
## Hai pháp thuộc vòng nghiệp
Miến / Burmese 53

…Các danh pháp trong những nhóm 19, 22 hoặc 21 cũng có thể sinh tùy trường hợp. Cần xét kỹ đúng theo cách chúng đã sinh, đang sinh hoặc sẽ sinh nơi mình.

Hai pháp thuộc vòng nghiệp

4. Hành (34) — nhóm tư thiện trong khi cúng hoa, đèn hay nước lên Đức Phật. Ở đây là tâm đại thiện thọ hỷ, hợp trí, vô trợ.
5. Nghiệp — sức nghiệp của hành (34) ấy.

Vô minh, ái và thủ, gọi chung là vòng phiền não, thường sinh trong một lộ ý môn với bảy sát-na tốc hành. Đôi khi cũng có thể sinh với cảnh nghiệp là danh sắc ở đời sống tỳ-khưu hay đời sống người nữ mà mình đã phát nguyện. Ở đây lấy nhóm tham hợp tà kiến có đủ 20 danh pháp trong từng sát-na tốc hành làm ví dụ.

Các pháp thuộc vòng nghiệp, gọi là hành và nghiệp, cũng nằm trong dòng tâm lộ tốc hành đại thiện qua ý môn. Mỗi tốc hành có thể có một trong hai loại hợp trí hay ly trí. Ở đây lấy tốc hành đại thiện thọ hỷ, hợp trí, vô trợ với 34 danh pháp làm ví dụ. Cần quán đúng theo cách các pháp ấy sinh trong dòng danh sắc của mình khi vun bồi nghiệp. Tốc hành thiện có thể là thọ hỷ hay thọ xả, hợp trí hay ly trí, hữu trợ hay vô trợ, tùy trường hợp.


<a id="M05-body-P054"></a>
## Sức nghiệp và trường hợp phát nguyện cõi phạm thiên
Miến / Burmese 54

Những tư thiện ở tốc hành, tức các pháp thuộc nhóm hành ấy, đều là pháp vô thường. Hết tuổi thọ sinh, trụ và diệt, chúng liền hoại diệt. Tuy nhiên, trước khi hoại diệt, chúng đã đặt trong dòng danh sắc sức nghiệp có thể làm sinh đời sống tỳ-khưu hay đời sống người nữ đã mong cầu vào một đời tương lai. Chúng khác với các danh pháp quả và danh pháp duy tác, vốn hoại diệt mà không để lại sức nghiệp như vậy. Chính sức làm sinh quả ấy được gọi là nghiệp, tức sức của nghiệp duyên khác sát-na (nānakkhaṇikakammapaccaya). Sau đây tiếp tục trình bày sự phát nguyện thứ hai, tức phát nguyện cõi phạm thiên.

Trường hợp phát nguyện thứ hai: cõi phạm thiên

1. Vô minh (20) — tính chất biết sai rằng có một vị phạm thiên.
2. Ái (20) — tính chất ham muốn và mê đắm đời sống phạm thiên ấy.
3. Thủ (20) — tính chất tâm tiến đến và bám lấy đời sống phạm thiên ấy.
4. Hành (31) — nhóm tư thiện của tứ thiền đã được tạo tác, vun bồi với nguyện vọng sinh vào đời sống phạm thiên.
5. Nghiệp — sức nghiệp của hành (31) ấy.

Trong vòng phiền não gồm vô minh, ái và thủ, nhóm tham hợp tà kiến có đủ 20 danh pháp. Trong hành thuộc tứ thiền có 31 danh pháp. Đây đều là các dòng tâm lộ tốc hành qua ý môn.

Nếu thiện hữu có thể nhận diện và quán các danh pháp thuộc vòng phiền não và vòng nghiệp sinh trong lần cử động vừa qua, dùng trí phá vỡ khối tưởng về danh để biết đến mức danh chân đế…


<a id="M05-body-P055"></a>
## Trình tự thực hành khi thấy một hình ảnh
Miến / Burmese 55

…thì đã thành công trong việc quán danh sắc quá khứ gần nhất.

Trình tự thực hành khi thấy một hình ảnh

Giả sử thiện hữu đang luân phiên quán danh sắc bên trong và bên ngoài, và nhờ trí phân định danh sắc mà ánh sáng trở nên rất mạnh. Nếu dùng ánh sáng ấy để hướng đến danh sắc trong lần cử động gần nhất, hình ảnh một người đang phát nguyện trước khi ngồi thiền có thể hiện ra. Đó là thấy dưới ánh sáng. Trước hết hãy quán bốn đại nơi hình ảnh ấy, hướng trí để thấy bốn đại. Hãy xem hình ảnh ấy như danh sắc bên ngoài và hướng đến bốn đại như khi tìm danh sắc bên ngoài. Người đã quán danh sắc bên ngoài đến mức sắc chân đế sẽ không gặp nhiều khó khăn.

Chẳng bao lâu sẽ thấy những hạt nhóm sắc. Hãy tiếp tục quán các sắc chân đế trong các nhóm ấy theo sáu cửa và 42 phần của thân. Đặc biệt, hãy ưu tiên quán 54 sắc trong vùng tim, trong đó ưu tiên sắc ý vật. Tiếp tục quán tâm hữu phần trong sáng, tức ý môn, sinh nương sắc ý vật. Rồi, giữa những tâm hữu phần trong sáng ấy, hãy tiếp tục quán các danh pháp sinh nương sắc ý vật…


<a id="M05-body-P056"></a>
## Lần về danh sắc quá khứ từng bước
Miến / Burmese 56

…Hãy tiếp tục quán dòng các danh pháp. Sau khi quán như vậy, hãy xem xét lại thật kỹ xem dòng danh pháp đã quán có đúng là dòng danh pháp thật sự đã sinh khi phát nguyện hay không. Nếu chúng khớp hoàn toàn, thì việc quán danh sắc quá khứ gần nhất đã thành công.

Khi đã thành công như vậy, dần dần hướng trí về quá khứ, quán từng bước danh sắc buổi sáng nay, danh sắc hôm qua, tháng trước, năm trước và cứ thế, thật tỉ mỉ. Nếu xen vào đó hiện ra những hình ảnh đang làm thiện, đang làm bất thiện, đang vui, đang không vui, đang mừng hay đang buồn, hãy quán bốn đại trong các hình ảnh ấy rồi tiếp tục quán danh sắc theo cách đã nêu ở trên.

Hãy dần dần tiếp tục quán danh sắc cho đến khi vào bụng mẹ. Quán được càng tỉ mỉ thì càng tốt. Khi làm vậy, nhiều hành giả thấy các hình ảnh của mình dần dần trẻ lại. Nhưng ở đây hình ảnh không phải là điều chính. Danh sắc mới là điều chính. Ngay cả khi không thấy hình ảnh, nếu thấy được danh sắc chân đế cho đến khi vào bụng mẹ thì càng tốt.


<a id="M05-body-P057"></a>
## Từ tái tục đến sát-na cận tử của đời trước
Miến / Burmese 57

Đối với loài người, ở sát-na tái tục khi vào bụng mẹ có ba loại nhóm sắc: nhóm mười sắc ý vật, nhóm mười sắc thân và nhóm mười sắc tính. Tính theo loại sắc, có 30 sắc. Chỉ có ba loại nhóm, gồm 30 loại sắc, nhưng mỗi loại có thể có nhiều nhóm. Điều đó tùy vào nghiệp đang cho quả. Về phía danh, nếu là người tái tục bằng tâm thọ hỷ thì có 34 danh pháp đại quả thọ hỷ, hợp trí. Hãy quán danh sắc ấy cho đến khi tuệ nhãn trở nên trong sáng. Khi có thể quán cho đến mức biết chân đế bằng tuệ nhãn trong sáng, hãy suy xét và phân định như sau.

So “idaṃ nāmarūpaṃ na ahetu na appaccayā nibbattaṃ, sahetu sappaccayā nibbattaṃ. Ko panassa hetu, ko pana paccayo”ti upaparikkhanto “avijjāpaccayā, taṇhāpaccayā, kammapaccayā, āhārapaccayā cā”ti tassa paccayaṃ vavatthapetvā “atītepi paccayā ceva paccayasamuppannadhammā ca, anāgatepi etarahipi paccayā ceva paccayasamuppannadhammā ca. Tato uddhaṃ satto vā puggalo vā natthi, suddhasaṅkhārapuñjo evā”ti tīsu addhāsu kaṅkhaṃ vitarati. Ayaṃ pana vipassanāsaṅkhārasallakkhaṇañātapariññā nāma. (Chú giải Abhidhamma, tập 2, tr. 241–242.)

Hành giả hãy suy xét và dùng trí phân định như sau: “Danh sắc này không sinh khi thiếu nhân trực tiếp làm nó hiện khởi, hay thiếu duyên nâng đỡ nó…”


<a id="M05-body-P058"></a>
## Tìm cảnh cận tử và lần về nghiệp làm nhân
Miến / Burmese 58

“…Danh sắc chỉ sinh khi có nhân trực tiếp làm nó hiện khởi và có duyên nâng đỡ nó. Nhân trực tiếp ấy là gì? Duyên nâng đỡ ấy là gì?” Khi hướng trí về quá khứ để suy xét như vậy, hành giả thường bắt đầu thấy cả danh sắc sinh vào thời cận tử của đời trước lẫn một trong ba cảnh làm đối tượng cho danh pháp cận tử: nghiệp, nghiệp tướng hoặc thú tướng.

Nếu có thể quán danh sắc lúc cận tử thì việc gặp một trong ba cảnh là nghiệp, nghiệp tướng hoặc thú tướng của các danh pháp ấy trở nên rất dễ. Đừng quên rằng tướng cận tử ấy là tướng hiện ra do sức của nghiệp sắp cho quả. Vì vậy, khi tìm được tướng ấy thì có thể chắc rằng mình sẽ tìm được hành và nghiệp là nhân gốc của những uẩn quả, như năm uẩn tái tục hiện tại. Khi đã gặp hành và nghiệp, hãy tiếp tục tìm vô minh, ái và thủ bao quanh chúng.

Khi thiện hữu dùng trí suy xét các nhân quá khứ và quán danh sắc vào thời cận tử…


<a id="M05-body-P059"></a>
## Khi hình ảnh người sắp chết hoặc thi thể hiện ra
Miến / Burmese 59

…mà chưa thấy danh sắc ấy, nếu thấy hình ảnh một người đang chết hoặc hình ảnh cận tử, hãy bắt đầu quán bốn đại trong thân đang chết ấy. Khi thấy những hạt nhóm sắc, hãy dùng trí phân tích các nhóm sắc ấy rồi tiếp tục quán sắc chân đế do thời tiết sinh, gồm tám sắc.

Nói rằng trong thi thể có các nhóm tám sắc do thời tiết sinh là nói theo trường hợp thông thường. Bởi ngay khi ấy, hành giả đôi khi có thể thấy lẫn những hạt nhóm sắc của một số sinh vật còn sống nương ở thi thể. Vì vậy, một số hành giả thấy lẫn các nhóm sắc trong suốt và không trong suốt trong thi thể ấy. Những sinh vật ấy ít nhất cũng có các nhóm sắc trong suốt, tức nhóm mười sắc thân. Trong chính thi thể chỉ có các nhóm tám sắc không trong suốt do thời tiết sinh.

Sau khi quán sắc pháp trong thi thể ấy, thiện hữu hãy hướng sự chú ý về quá khứ, lùi từng bước và thử quán danh sắc cận tử trước khi chết. Nếu có thể quán danh sắc cận tử, hãy tiếp tục quán đối tượng của các tốc hành hiện khởi lúc cận tử. Nếu chưa thành công, hãy quán sắc ý vật lúc cận tử cho đến khi thấy rõ. Sau đó, tiếp tục quán tâm hữu phần trong sáng, tức ý môn, sinh nương sắc ý vật ấy. Nếu có thể quán tâm hữu phần trong sáng ấy thì hãy tiếp tục quán danh sắc cận tử trước khi chết…


<a id="M05-body-P060"></a>
## Tìm đối tượng của tốc hành cận tử
Miến / Burmese 60

…Hãy tiếp tục quán những tâm hữu phần trong sáng thường lặp đi lặp lại không ngừng trong thời gian ấy. Hãy xét tới lui cả khoảng trước khi chết và khoảng sau của thời cận tử. Khi quán được các tâm hữu phần trong sáng ấy, hành giả có thể tìm thấy và quán một trong ba tướng hiện ở ý môn là nghiệp, nghiệp tướng hay thú tướng, làm đối tượng cho tốc hành cận tử. Khi khảo sát các hành giả đã thành thạo, thấy số người có cảnh nghiệp và nghiệp tướng hiện ra thì nhiều, còn số người có thú tướng hiện ra thì rất ít.

Nếu tướng hiện vào thời cận tử là cảnh nghiệp, thì theo lời giải thích bằng cụm abhinavakaraṇavasena trong Abhidhammatthasaṅgaha, phần Ngoài lộ tâm, tr. 90, đó là tướng hiện do sức của một việc thiện đang được làm lại như mới. Cần quay lại quán danh sắc đã sinh vào thời điểm làm việc thiện ấy.

Cách tìm cảnh nghiệp

Trước hết, hãy quán bốn đại nơi hình ảnh đang làm việc thiện ấy. Khi thấy các nhóm sắc, hãy phân tích chúng và quán sắc pháp cho đến mức sắc chân đế. Đặc biệt, hãy ưu tiên quán 54 sắc trong vùng tim, kể cả sắc ý vật, đã sinh khi làm việc thiện ấy. Sau đó quán riêng sắc ý vật, rồi tiếp tục quán tâm hữu phần trong sáng, tức ý môn, sinh nương sắc ý vật. Tiếp theo, giữa những tâm hữu phần ấy…


<a id="M05-body-P061"></a>
## Tìm dòng tâm lúc tạo nghiệp
Miến / Burmese 61

…hãy tiếp tục quán những nhóm danh pháp sinh xen vào trong lúc làm việc thiện ấy. Khi quán như vậy, hãy nhìn kỹ những danh pháp sinh trước, trong và sau khi làm việc thiện. Hãy hướng trí để thấy rõ việc thiện thuộc loại nào đang được làm và dòng tâm lộ tốc hành đại thiện qua ý môn thuộc loại nào đang sinh.

Nếu quán tới lui nhiều lần, hành giả sẽ tìm thấy nhóm vô minh, ái và thủ liên hệ với mục đích và ý hướng khi làm việc thiện, cũng như các hành và nghiệp là dòng tâm lộ tốc hành thiện thuộc loại nào đang hiện khởi. Nói cách khác, hành giả sẽ tìm thấy vòng phiền não và vòng nghiệp, tức hành và nghiệp thiện được vô minh, ái và thủ bao quanh. Hãy lưu ý rằng ở đây chỉ tách riêng để nói về hành và nghiệp thiện vì hành và nghiệp làm phát sinh đời sống và các uẩn của con người là hành và nghiệp thiện.

Lời nguyện trước kia của công chúa Sumanā

Để hiểu sâu hơn về vô minh, ái, thủ, hành và nghiệp, sau đây trình bày một lần phát nguyện trước kia của công chúa Sumanā, con gái nổi tiếng của vua Kosala. Khi Đức Phật Vipassī xuất hiện, sau khi dâng lên Tăng chúng do Đức Phật Vipassī đứng đầu vòng hoa lài và vật thực, người nữ thiện lành ấy đã phát nguyện như sau.


<a id="M05-body-P062"></a>
## Năm nhân trong lời nguyện của công chúa Sumanā
Miến / Burmese 62

Bhavābhavābhinibbattiyaṃ me sati paritassanajīvitaṃ nāma mā hotu. Ayaṃ sumanamālā viya nibbattanibbattaṭṭhāne piyāva homi, nāmena ca sumanāyeva. (Chú giải Aṅguttara, tập 3, tr. 13–14.)

“Nếu con còn sinh vào đời này đời khác, lớn hay nhỏ, nguyện con không phải sống trong lo lắng, mong cầu và khốn khó để nuôi mạng. Trong mỗi đời được sinh ra, nguyện con là người nữ được mọi người yêu mến, như vòng hoa lài quý này. Nguyện tên con cũng là Sumanā.” (Chú giải Aṅguttara, tập 3, tr. 13–14.)

Khi xét việc thiện và lời nguyện ấy, có thể thấy đầy đủ cả vòng phiền não và vòng nghiệp:
1. Vô minh — tính chất biết sai rằng có một người nữ tên Sumanā, được mọi người yêu mến và sống không lo lắng, thiếu thốn về sinh kế.
2. Ái — tính chất ham muốn và mê đắm đời sống người nữ ấy.
3. Thủ — tính chất tâm tiến đến và bám lấy đời sống người nữ ấy.
4. Hành — nhóm tư thiện khi cúng vòng hoa lài và vật thực lên Tăng chúng do Đức Phật Vipassī đứng đầu.
5. Nghiệp — sức nghiệp của nhóm tư thiện thuộc hành ấy.

Năm pháp làm nhân ấy là các nhân của năm uẩn tái tục và các uẩn quả khác của công chúa Sumanā, con gái vua Kosala. (Xem Chú giải Aṅguttara, tập 3, tr. 13–14.)


<a id="M05-body-P063"></a>
## Năm nhân trong lời nguyện của Anojādevī
Miến / Burmese 63

Vào thời Đức Phật Kassapa, một nghìn gia đình thợ dệt, dẫn đầu bởi những người về sau là Tôn giả Mahākappina và trưởng lão ni Anojā, đã xây dựng một ngôi tinh xá lớn, lộng lẫy rồi cúng dường Tăng chúng do Đức Phật đứng đầu. Trong buổi cúng dường ấy, người nữ thiện lành về sau là Anojādevī, tức trưởng lão ni Anojā, đặt một bộ y trị giá một nghìn đồng, có màu hoa anoja, lên một mâm đầy hoa anoja, rồi đặt dưới chân Đức Phật Kassapa để cúng dường. Khi ấy bà phát nguyện như sau.

Bhante, nibbattanibbattaṭṭhāne anojapupphavaṇṇameva me sarīraṃ hotu, Anojā eva ca me nāmaṃ hotu. (Chú giải Dhammapada, tập 1, tr. 353.)

“Bạch Đức Thế Tôn, trong mỗi đời được sinh ra, nguyện thân con có màu như hoa anoja. Nguyện tên con cũng là Anojā.” (Chú giải Dhammapada, tập 1, tr. 353.)

1. Vô minh — tính chất biết sai rằng có một người nữ tên Anojā, mang màu hoa anoja.
2. Ái — tính chất ham muốn và mê đắm đời sống người nữ ấy.
3. Thủ — tính chất tâm tiến đến và bám lấy đời sống người nữ ấy.
4. Hành — nhóm tư thiện khi cúng dường tinh xá, hoa và y.
5. Nghiệp — sức nghiệp của nhóm tư thiện thuộc hành ấy.


<a id="M05-body-P064"></a>
## Quả của lời nguyện Anojā và chuyện hoàng hậu Subhaddā
Miến / Burmese 64

Nhờ việc thiện ấy, bà sinh làm Anojādevī, tức vị trưởng lão ni Anojā về sau, một người nữ có nước da như màu hoa anoja. Năm pháp làm nhân kể trên là các nhân của năm uẩn tái tục và một số pháp thuộc vòng quả của bà. Khi vô minh, ái và thủ còn bao quanh và trợ lực, hành và nghiệp làm sinh các quả tương ứng. Đó là một bức tranh đã được vẽ từ thời Đức Phật Kassapa.

Hoàng hậu Subhaddā

Một thuở, Đức Phật đang ngồi trên pháp tọa thuyết pháp tại Jetavana ở Sāvatthī. Một vị tỳ-khưu-ni trẻ nhìn thân Đức Phật, đầy đủ mười thân lực và mười trí lực, với sắc thân cao quý hiện rõ nhờ năng lực của những ba-la-mật và việc thiện vô lượng. Vị ấy tự hỏi trong khi lưu chuyển trong luân hồi mình đã từng hầu hạ dưới chân bậc cao quý này hay chưa.

Ngay lúc ấy, trong dòng tâm của vị tỳ-khưu-ni trẻ, trí nhớ đời trước sinh khởi, có thể lần ngược và nhớ lại câu chuyện đau lòng trong kiếp trước. Nhìn lại bằng trí ấy, vị ấy nhớ rõ chuyện đau lòng khi làm Cūḷasubhaddā, bạn đời của voi chúa Chaddanta, rồi bật khóc lớn. Đức Phật liền thuyết cho hội chúng nghe chuyện tiền thân voi chúa Chaddanta…


<a id="M05-body-P065"></a>
## Hai voi cái và duyên của việc cúng dường
Miến / Burmese 65

…Voi chúa Chaddanta có hai bạn đời là Cūḷasubhaddā và Mahāsubhaddā. Vị tỳ-khưu-ni trẻ ấy chính là Cūḷasubhaddā khi xưa.

Một ngày nọ, voi chúa Chaddanta cùng đàn voi đi vào khu rừng cây sāla đang nở hoa. Khi voi chúa làm rung cây, cành và lá khô rơi trên mình Cūḷasubhaddā đang đứng đầu gió, còn phấn hoa và cánh hoa rơi trên mình Mahāsubhaddā đang đứng cuối gió. Cūḷasubhaddā bất bình về việc ấy. Một ngày khác, khi đàn voi chơi dưới nước ở hồ Chaddanta, một con voi hái được một đóa sen paduma lớn gọi là sattuddhaya và dâng lên voi chúa. Voi chúa dùng vòi nâng đóa sen, rũ phấn hoa lên mình Mahāsubhaddā rồi trao đóa sen cho nàng. Cūḷasubhaddā cũng không hài lòng về việc ấy. Do hai việc này, Cūḷasubhaddā sinh lòng oán hận đối với Bồ-tát là voi chúa Chaddanta.

Khi ấy hơn tám nghìn con voi, đứng đầu là Chaddanta, có cơ hội cúng dường trái cây, vật thực và những thứ tương tự đến năm trăm vị Phật Độc Giác. Đây là một cơ hội tốt hiếm có. Đàn voi do Chaddanta đứng đầu cũng đầy đủ giới thanh tịnh. Vì vậy sự bố thí của họ hội đủ năm yếu tố sau.

1. Người bố thí có giới.
2. Vật thí được tìm kiếm bằng phương tiện chân chánh.
3. Tâm có niềm tin trong sáng.


<a id="M05-body-P066"></a>
## Sự bố thí hội đủ duyên và lời nguyện của Cūḷasubhaddā
Miến / Burmese 66

4. Có niềm tin vững chắc vào nghiệp và quả của nghiệp.
5. Những người nhận cũng có giới thanh tịnh.

Sự bố thí hội đủ năm yếu tố ấy. Hãy xem Kinh Phân biệt cúng dường (Dakkhiṇāvibhaṅgasutta). Đây là loại bố thí có sức đem lại nhiều quả tốt đẹp, lớn lao. Theo lời dạy “Ijjhati, bhikkhave, sīlavato cetopaṇidhi visuddhattā” (Aṅguttara Nikāya, tập 3, tr. 71), vì giới trong sạch nên sự bố thí ấy có thể làm thành tựu những điều tâm mong nguyện. Cūḷasubhaddā hiểu rằng đây là một cơ hội tốt lớn lao. Vì vậy, sau khi cúng trái cây của mình đến các vị Phật Độc Giác, nàng phát nguyện như sau.

“Bhante, ito cavitvā Maddarājakule nibbattitvā Subhaddā nāma rājakaññā hutvā vayappattā Bārāṇasirañño aggamahesibhāvaṃ patvā tassa piyā manāpā taṃ attano ruciṃ kāretuṃ samatthā hutvā taṃ ācikkhitvā ekaṃ luddakaṃ pesetvā imaṃ hatthiṃ visapītena sallena vijjhāpetvā jīvitakkhayaṃ pāpetvā chabbaṇṇaraṃsiṃ vissajjente yamakadante āharāpetuṃ samatthā homi.” (Chú giải Jātaka, tập 5, tr. 40)

1. Bạch các ngài, sau khi chết ở đây, nguyện tôi được sinh trong hoàng tộc Madda.
2. Nguyện tôi là công chúa tên Subhaddā trong hoàng tộc ấy.
3. Khi đến tuổi trưởng thành, nguyện tôi được làm chánh hậu của vua xứ Kāsi.
4. Nguyện tôi là hoàng hậu được vị vua xứ Kāsi ấy yêu quý và tin cậy.


<a id="M05-body-P067"></a>
## Lời nguyện trả oán và năm pháp làm nhân
Miến / Burmese 67

5. Nguyện tôi có thể khiến vua xứ Kāsi làm theo ý muốn của tôi.
6. Nguyện tôi có thể thuyết phục vua xứ Kāsi sai một người thợ săn đến giết voi chúa Chaddanta bằng mũi tên tẩm độc.
7. Nguyện tôi có thể sai người mang về cặp ngà của voi chúa, tỏa hào quang sáu màu.

Đó là lời nguyện của Cūḷasubhaddā, vị hoàng hậu về sau.
1. Vô minh — tính chất biết sai rằng có một chánh hậu tên Subhaddā, có đủ những khả năng nói trên.
2. Ái — tính chất ham muốn và mê đắm đời sống hoàng hậu ấy.
3. Thủ — tính chất tâm tiến đến và bám lấy đời sống ấy.
4. Hành — nhóm hành thiện khi cúng trái cây và vật thực đến các vị Phật Độc Giác.
5. Nghiệp — sức nghiệp của nhóm hành thiện ấy.

Năm pháp làm nhân ấy đã đầy đủ. Đó là loại nghiệp chưa bị Thánh đạo phá bỏ và dứt trừ ngay tại nơi nó đã được vun bồi. Đúng như nàng đã phát nguyện, sau khi chết trong đời voi, nàng sinh làm công chúa Subhaddā của xứ Madda. Nàng trở thành chánh hậu của vua xứ Kāsi và đạt địa vị cao nhất trong số mười sáu nghìn cung nữ.


<a id="M05-body-P068"></a>
## Voi chúa Chaddanta và người thợ săn Soṇuttara
Miến / Burmese 68

Đến đây đáng lẽ nàng đã mãn nguyện. Nhưng hoàng hậu vẫn không mãn nguyện. Dù đã thành chánh hậu, nàng vẫn không yên cho đến khi giết được Chaddanta, dù vị ấy chỉ là một con vật sống trong rừng. Sức nghiệp đã vun bồi trong quá khứ tiếp tục thúc đẩy nàng, khiến nàng không thể thôi ý định giết. Đó là sức của hành và nghiệp còn được vô minh, ái và thủ bao quanh. Cuối cùng nàng sai người thợ săn Soṇuttara đi và lấy được cặp ngà của voi chúa Chaddanta. Cảnh tượng đau lòng ấy diễn ra như sau.

“Evarūpaṃ sobhaggappattaṃ vāraṇaṃ visapītena sallena jīvitakkhayaṃ pāpetvā ime dante chinditvā Sonuttaro āgato”ti mahāsattaṃ anussarantī sokaṃ uppādetvā adhivāsetuṃ nāsakkhi. Athassā tatheva hadayaṃ phali, taṃ divasameva kālamakāsi. (Chú giải Jātaka, tập 5, tr. 56)

Khi người thợ săn Soṇuttara dâng cặp ngà tuyệt đẹp, chiếu sáng sáu màu, hoàng hậu Subhaddā nâng chúng đặt vào lòng và nhìn chúng. Nàng tưởng như trông thấy người chồng yêu quý đời trước và nhớ đến đức hạnh của Bồ-tát: “Vị voi chúa có hình dáng và tầm vóc như thế, nay đã bị mũi tên tẩm độc bắn đến chết. Người thợ săn Soṇuttara đã cắt ngà của vị ấy và đem về.” Khi nhìn cặp ngà và nhớ đến những đức hạnh của Bồ-tát, nàng sinh sầu muộn vì xa lìa người yêu quý. Nỗi sầu mạnh đến mức ngay hôm ấy tim nàng vỡ ra và nàng qua đời. (Chú giải Jātaka, tập 5, tr. 56.)


<a id="M05-body-P069"></a>
## Một ví dụ của hành giả
Miến / Burmese 69

Trong đời làm hoàng hậu Subhaddā, bà đã có một lần tái sinh và một lần chết. Nay, trong đời làm tỳ-khưu-ni, bà lại tái sinh lần thứ hai. Vì thế, người thiện nên hết sức thận trọng khi tạo nghiệp. Đến đây, có lẽ đã có thể hiểu khá rõ về vô minh, ái, thủ, hành và nghiệp.

Để hiểu rõ hơn, xin nêu thêm một ví dụ của hành giả. Khi chú tâm tìm đối tượng của lộ cận tử trong đời trước rồi quán danh sắc, hành giả thấy nghiệp tướng hiện rõ trong tâm ngay trước lộ cận tử đời trước, đó là đang dâng trái cây cúng dường một vị tăng. Lại dựa vào bốn đại trong dòng thân tâm lúc dâng trái cây để tiếp tục quán danh sắc, hành giả thấy các lộ tâm phát nguyện trở thành một phụ nữ ở thành phố lớn, có học vấn hiện đại, do chán cảnh quê nghèo khổ và thất học. Hành giả cũng thấy các lộ tâm thuộc nhóm tư thiện khi dâng trái cây. Trong đó có các pháp sau.

1. Vô minh (avijjā, 20) là nhận lầm rằng có một phụ nữ thành thị có học vấn hiện đại.
2. Ái (taṇhā, 20) là ham muốn, dính mắc vào đời sống của người nữ ấy.
3. Thủ (upādāna, 20) là sự bám chặt của tâm vào đời sống của người nữ ấy.


<a id="M05-body-P070"></a>
## Phân biệt nhân quả và một ví dụ khác
Miến / Burmese 70

4. Hành (saṅkhāra, 34) là nhóm tư thiện khi dâng trái cây cúng dường vị tăng.
5. Nghiệp (kamma) là năng lực tạo quả của hành ấy (34).

Ở đây, 20 là 20 danh pháp thuộc nhóm tham và tà kiến, hiện hữu trong những tâm tốc hành tham của lộ ý môn thuộc phiền não luân. Số 34 là các tâm sở cùng với tâm trong những tâm tốc hành thiện của lộ ý môn khi dâng trái cây, tức các danh pháp thuộc nhóm tín và tuệ.

Trong đời này, hành giả ấy đã trở thành một phụ nữ thành thị có học vấn hiện đại. Khi tự mình quán mối liên hệ nhân quả, hành giả thấy bằng chánh kiến rằng năng lực tạo quả của nghiệp thiện dâng trái cây đã làm duyên cho năm uẩn tái tục và các uẩn quả trong đời sống hiện tại. Tuệ thấy xuyên suốt mối liên hệ giữa các pháp nhân và các pháp quả như vậy là tuệ phân biệt nhân duyên (paccayapariggahañāṇa), tức tuệ phân biệt các pháp làm nhân. Để hiểu rõ và sáng tỏ hơn, hãy xem thêm ví dụ dưới đây.

Một nữ hành giả dò tìm đối tượng lúc cận tử của đời trước. Khi lần lượt khảo sát lui về từ lúc cận tử đến trước lúc chết, bà thấy các nghiệp dưới đây hiện ra quanh thời điểm trước khi chết.


<a id="M05-body-P071"></a>
## Nghiệp minh sát và lời nguyện
Miến / Burmese 71

1. Một nghiệp tặng sách.
2. Một nghiệp chỉ dạy Pháp.
3. Một nghiệp tác ý đến Pháp.
4. Một nghiệp thuyết Pháp.

Bốn nghiệp ấy đều lần lượt hiện ra. Khi khảo sát nhiều lần xem nghiệp nào đã làm sinh khởi năm uẩn tái tục và các pháp quả trong đời sống hiện tại, bà thấy chính nghiệp tác ý đến Pháp đang cho quả. Việc tác ý đến Pháp ấy là đối tượng nghiệp hiện ra lúc cận tử. Khi lại khảo sát xem mình đang tác ý đến những pháp nào, bà thấy đó là nghiệp minh sát, đang quán sát và thẩm xét các pháp chân đế danh sắc theo ba đặc tướng. Hãy phân biệt rõ đến mức thành thạo mối liên hệ nhân quả giữa nghiệp minh sát ấy và năm uẩn tái tục trong hiện tại. Khi lại khảo sát vì sao nghiệp minh sát ấy làm sinh khởi tái tục, bà thấy lúc tu tập minh sát, mỗi khi vừa tu tập xong đề mục minh sát, bà thường nguyện như sau.

1. Nguyện được sinh làm người.
2. Nguyện được xuất gia.
3. Nguyện gặp được Giáo pháp.

Đó là ba điều mà nữ hành giả thường nguyện mỗi khi ngồi thiền.
1. Vô minh (avijjā, 20) là nhận lầm rằng có người, vị tỳ-khưu và người được gặp Giáo pháp.


<a id="M05-body-P072"></a>
## Nghiệp minh sát có thể cho quả tái tục
Miến / Burmese 72

2. Ái (taṇhā, 20) là sự ham muốn, dính mắc vào đời sống ấy.
3. Thủ (upādāna, 20) là sự bám chặt của tâm vào đời sống ấy.
4. Hành (saṅkhāra, 34) là nhóm hành thiện minh sát.
5. Nghiệp (kamma) là năng lực tạo quả của hành ấy (34).

Như vậy đã đủ năm pháp làm nhân. Có thể hỏi liệu các nghiệp minh sát này có thể cho quả tái tục và những quả tương tự như trong ví dụ vừa nêu hay không. Câu trả lời là có thể cho quả.

“No ce, bhikkhave, ceteti, no ce pakappeti, atha ce anuseti, ārammaṇametaṃ hoti viññāṇassa ṭhitiyā.” (Saṃyutta Nikāya, tập 1, tr. 295, Cetanāsutta)

No ce bhikkhave cetetīti iminā tebhūmakacetanāya appavattanakkhaṇo vutto. No ce pakappetīti iminā taṇhādiṭṭhikappānaṃ appavattanakkhaṇo. Atha ce anusetīti iminā tebhūmakavipākesu parittakiriyāsu rūpeti ettha appahīnakoṭiyā anusayo gahito. Ārammaṇametaṃ hotīti anusaye sati kammaviññāṇassa uppattiyā avāritattā etaṃ anusayajātaṃ paccayova hoti. (Chú giải Saṃyutta, tập 2, tr. 66.)

“Này các tỳ-khưu, nếu không có tư” nói đến lúc tư thuộc ba cõi không vận hành. “Nếu không hoạch định” nói đến lúc sự hoạch định do ái và kiến không vận hành. “Nhưng nếu còn tiềm phục” nói đến tùy miên theo nghĩa chưa được đoạn trừ đối với các pháp quả thuộc ba cõi, các pháp duy tác dục giới và sắc. “Điều ấy là đối tượng” nghĩa là khi còn tùy miên thì sự sinh khởi của nghiệp thức chưa bị ngăn chặn, nên tùy miên ấy làm duyên.

Ettha ca “no ce bhikkhave ceteti no ce pakappeti, atha ce anusetī”ti evaṃ bhagavatā dutiyanaye pubbabhāge bhavanibbattakakusalākusalāyūhanaṃ, pakappanañca vināpi bhavesu diṭṭhādīnavassa yogino anusayapaccayā vipassanācetanāpi paṭisandhijanakā hotīti dassanatthaṃ kusalākusalassa appavatti cepi tadā vijjamānatebhūmakavipākādidhammesu appahīnakoṭiyā anusayitakilesapaccayā bhavavaṭṭassa kammaviññāṇassa patiṭṭhitatā hotīti dassanatthañca vuttaṃ. (Phụ chú giải Saṃyutta, tập 2, tr. 83.)

Trong cách trình bày thứ hai, Đức Thế Tôn nói như vậy để chỉ rõ rằng ngay cả khi hành giả đã thấy sự nguy hại trong các hữu và trước đó không tích lũy thiện hay bất thiện làm sinh hữu, cũng không hoạch định, tư minh sát vẫn có thể sinh tái tục do tùy miên làm duyên. Ngài cũng chỉ rõ rằng dù thiện và bất thiện không vận hành vào lúc ấy, nghiệp thức thuộc vòng hữu vẫn được thiết lập do các phiền não tiềm phục làm duyên, vì chúng chưa được đoạn trừ đối với các pháp đang hiện hữu, như quả thuộc ba cõi.


<a id="M05-body-P073"></a>
## Miến 73
Miến / Burmese 73

Này các tỳ-khưu… Dù không ra sức làm khởi lên tư thiện hay tư bất thiện khiến vòng luân hồi tiếp tục, và cũng không hoạch định hay tưởng nghĩ cùng với ái và kiến, chẳng hạn “nguyện được làm người, nguyện được làm chư thiên”, khuynh hướng tùy miên vẫn còn hiện hữu vì chưa được Thánh đạo đoạn trừ. Chính sự hiện hữu của khuynh hướng tùy miên ấy là nhân cho nghiệp thức có khả năng cho quả tái tục được thiết lập trong một đời sống mới về sau. (Saṃyutta Nikāya, tập 1, tr. 295.)

Khi khuynh hướng tùy miên còn hiện hữu vì chưa được Thánh đạo đoạn trừ, nó không thể ngăn sự sinh khởi của nghiệp thức có khả năng cho quả tái tục trong một đời sống mới về sau. Vì vậy chính sự còn hiện hữu của khuynh hướng tùy miên là nhân cho nghiệp thức được thiết lập. (Chú giải Saṃyutta, tập 2, tr. 66.)

Trong Cetanāsutta, Đức Phật thuyết ba trường hợp sau.
1. Thiện và bất thiện thuộc vòng luân hồi, đi cùng với ái và kiến hoặc đang sinh khởi.
2. Thiện và bất thiện hướng ra khỏi vòng luân hồi, không tương ưng với ái và kiến, hoặc tư thuộc ba cõi trong trường hợp tư ấy không sinh khởi.
3. Các tâm duy tác sinh trong dòng danh sắc của các bậc A-la-hán đã đoạn trừ tùy miên, chẳng hạn các tâm khi bố thí, trì giới, tu thiền chỉ và minh sát.


<a id="M05-body-P074"></a>
## Miến 74
Miến / Burmese 74

Đức Phật đã thuyết theo ba cách như vậy. Trong cách thứ hai, tức mục 2 đã dịch ở trên, trước và sau khi hành minh sát, hành giả không ra sức tạo thiện hay bất thiện có khả năng làm sinh hữu. Hành giả cũng không hoạch định hay tưởng nghĩ với ái và kiến theo kiểu “nguyện được làm nam, nguyện được làm nữ, nguyện được làm người, nguyện được làm chư thiên”. Hành giả thấy sự nguy hại trong các hữu. Đối với hành giả như vậy, vì khuynh hướng tùy miên vẫn còn trong dòng danh sắc, tư minh sát đi cùng tuệ minh sát vẫn có khả năng làm sinh tái tục. Để làm rõ ý nghĩa ấy, Đức Phật đã thuyết theo cách thứ hai.

Nghiệp minh sát là loại nghiệp làm cạn kiệt những nghiệp khiến vòng luân hồi tiếp tục. Khi các tuệ minh sát liên tục sinh khởi, thiện và bất thiện khiến vòng luân hồi tiếp tục không có cơ hội sinh khởi. Tuy nhiên, ngay lúc tuệ minh sát sinh, các phiền não tùy miên vẫn còn tiềm phục, vì Thánh đạo chưa đoạn trừ chúng đối với các pháp đang hiện hữu trong dòng danh sắc của hành giả, gồm các pháp quả thuộc ba cõi, các pháp duy tác dục giới và sắc. Chính vì các phiền não tùy miên vẫn còn hiện hữu mà nghiệp thức có khả năng làm sinh tái tục trong một đời sống mới về sau được thiết lập. Sự nguy hại ấy vẫn hiện hữu. Để làm rõ ý nghĩa ấy, Đức Phật đã thuyết theo cách thứ hai. (Phụ chú giải Saṃyutta, tập 2, tr. 83.)

Ở hành giả được nêu làm ví dụ trên, phần nhiều cả trước lẫn sau khi hành minh sát, ta thấy có sự bao quanh của các khuynh hướng tùy miên…


<a id="M05-body-P075"></a>
## Miến 75
Miến / Burmese 75

…và cả ái và kiến. Nếu nghiệp minh sát của người thiện vẫn còn khuynh hướng tùy miên có thể cho quả tái tục, thì nghiệp minh sát của người vừa còn khuynh hướng tùy miên vừa có ái và kiến bao quanh cũng có thể cho quả tái tục. Điều này cũng phù hợp với Sotānugatasutta trong Phẩm Bốn pháp của Tăng chi bộ (Tăng chi bộ, tập 1, tr. 504–507). Liên quan đến hành giả ấy, có một điểm đáng ghi nhớ. Dù các tuệ minh sát đã sinh trong đời trước, hành giả hoàn toàn chưa thấy duyên khởi. Do đó, các tuệ minh sát sinh trong đời trước ấy chưa đủ mạnh để trợ giúp bằng năng lực của duyên y chỉ mạnh cho đến khi Thánh đạo hiển hiện. Trường hợp này giống như Trưởng lão Channa, người từng lầm nhận mình là Channa, người đánh xe. (Xem Channasutta, Tương ưng bộ, tập 2, tr. 108.)

Phiền não luân và nghiệp luân

Xin giải thích thêm đôi chút về phiền não luân và nghiệp luân. Tâm và các tâm sở được gọi là phiền não luân và nghiệp luân không có khả năng sinh riêng lẻ. Chúng chỉ có thể sinh cùng các pháp tương ưng. Ngay cả khi sinh cùng các pháp tương ưng, chúng chỉ có thể sinh theo quy luật của tâm, tức theo lộ tâm. Chúng không thể chệch khỏi trình tự thông thường ấy, đảo ngược hay sinh tùy tiện theo ý muốn. Lại nữa, phiền não luân và nghiệp luân có khả năng cho quả tái tục chỉ thuộc về các tốc hành ý môn. Tốc hành ngũ môn chỉ có thể làm sinh quả trong thời bình nhật…


<a id="M05-body-P076"></a>
## Miến 76
Miến / Burmese 76

…chúng không thể cho quả tái tục. Tốc hành ý môn có khả năng cho cả hai loại quả, quả tái tục và quả trong thời bình nhật. Ở đây, để hiểu rõ, xin giải thích bằng một ví dụ nữa.

Khi hướng đến và tìm đối tượng của lộ cận tử đời trước, giả sử cảnh nghiệp dâng vật thực cúng dường bảo tháp hiện ra. Hãy tiếp tục quán các lộ tốc hành thiện trong khi dâng vật thực ấy. Hãy tiếp tục quán cả những lộ tốc hành ý môn do vô minh, ái và thủ dẫn đầu, bao quanh thiện nghiệp ấy. Dù chưa quán thành công, hoặc dù chỉ thấy hình ảnh dâng vật thực, ngay lúc ấy hãy bắt đầu quán bốn đại trong hình ảnh người đang dâng vật thực đó. Sau đó hãy tiếp tục quán các sắc pháp và danh pháp sinh trong khi dâng vật thực. Hãy đặc biệt chú trọng quán sắc ý vật và ý môn, tức hữu phần trong sáng. Trong số các hữu phần trong sáng ấy, hãy nhiều lần quán đi quán lại những hữu phần làm ý môn có mặt ngay trước và trong lúc dâng vật thực đến bảo tháp. Rồi tiếp tục quán các lộ tốc hành ý môn xen giữa những hữu phần làm ý môn ấy, cả lộ tâm đang dâng vật thực lẫn lộ tâm đang phát nguyện. Trong các lộ tâm ấy, cần tìm cho ra phiền não luân, tức vô minh, ái và thủ, cùng nghiệp luân, tức hành và nghiệp.


<a id="M05-body-P077"></a>
## Miến 77
Miến / Burmese 77

Để hiểu rõ, xin nêu một ví dụ. Giả sử hành giả phát nguyện “Nguyện tôi trở thành một vị tỳ-khưu có thể chứng đạt Niết-bàn” hoặc “Nguyện tôi trở thành một người nữ có thể chứng đạt Niết-bàn”.

Ba pháp thuộc phiền não luân

1. Vô minh là tính chất nhận lầm có một vị tỳ-khưu hoặc một người nữ có thể chứng đạt Niết-bàn.
2. Ái là tính chất ham muốn, đắm nhiễm vào đời sống của một vị tỳ-khưu hoặc một người nữ có thể chứng đạt Niết-bàn.
3. Thủ là tính chất tâm hướng đến và bám chặt lấy đời sống của một vị tỳ-khưu hoặc một người nữ có thể chứng đạt Niết-bàn.

Vô minh, ái và thủ này là phiền não luân. Các pháp vô minh, ái và thủ được gọi là phiền não luân không có khả năng tự sinh riêng lẻ. Chúng chỉ có thể sinh theo lộ tâm, cùng với những tâm và tâm sở tương ưng như xúc, thọ, tưởng, tư và thức. Nói chung, nhóm tham và kiến có đủ 20 danh pháp. Khi không có hỷ thì đôi lúc có 19 danh pháp. Chúng có thể sinh hữu trợ hoặc vô trợ tùy trường hợp. Chúng cũng có thể sinh cùng thọ xả tùy trường hợp. Đôi khi có nhóm tham và mạn. Đôi khi cũng có thể có nhóm tâm căn tham thiếu cả kiến lẫn mạn. Xét theo trình tự lộ tâm, thông thường một tâm hướng ý môn được theo sau bởi bảy tốc hành. Tâm đồng sở duyên có khi sinh, có khi không. Khi tâm tham ái đối với danh sắc trong đời sống tỳ-khưu mà mình mong cầu, hoặc…


<a id="M05-body-P078"></a>
## Miến 78
Miến / Burmese 78

…danh sắc trong đời sống người nữ mà mình mong cầu, có cơ hội cho tâm đồng sở duyên sinh. Tâm ấy có thể sinh.

1. Trong tâm hướng ý môn có 12 danh pháp.
2. Trong mỗi tốc hành, nếu là nhóm tham và kiến, có 20 danh pháp.
3. Nếu đồng sở duyên sinh, trong mỗi sát-na đồng sở duyên có 34, 33, 33, 32, 12 hoặc 11 danh pháp tùy trường hợp.

Có thể sinh theo từng trường hợp như vậy. Trong các nhóm danh pháp ấy có những thành phần sau.

1. Thọ là thọ uẩn (vedanākkhandha), tức nhóm các pháp thọ.
2. Tưởng là tưởng uẩn (saññākkhandha), tức nhóm các pháp tưởng.
3. Các tâm sở còn lại là hành uẩn (saṅkhārakkhandha), tức nhóm các pháp hành.
4. Tâm hay thức biết là thức uẩn (viññāṇakkhandha), tức nhóm các pháp thức có tính chất biết.

Vì vậy các danh pháp ấy chính là bốn danh uẩn. Sắc ý vật là chỗ nương của các danh pháp ấy, cùng các loại sắc đồng sinh với ý vật, gồm 54 sắc pháp, là sắc uẩn. Các sắc do tâm sinh cũng có thể được tính vào tùy trường hợp. Cộng lại, một sắc uẩn và bốn danh uẩn thành năm uẩn.

1. Năm uẩn ở sát-na hướng ý môn.
2. Năm uẩn ở mỗi sát-na tốc hành.
3. Năm uẩn ở mỗi sát-na đồng sở duyên.

Các nhóm ấy phân biệt như vậy. Tùy trường hợp, đồng sở duyên có thể là tâm đại quả, tâm quả thiện vô nhân hoặc tâm quả bất thiện vô nhân. Vì vậy các con số 34, 33, 33, 32…


<a id="M05-body-P079"></a>
## Hai pháp thuộc nghiệp luân
Miến / Burmese 79

…12 và 11 được nêu riêng như vậy. Người thiện hãy tự mình khảo sát.

Để quán vô minh, ái và thủ thuộc phiền não luân, tức những pháp bao quanh hành và nghiệp đã được vun bồi trong đời trước và thuộc các nhân quá khứ, người thiện cần biết quán danh và sắc trong hiện tại. Hãy vận dụng trí để phân tích từng nhóm sắc và từng nhóm danh, cho đến khi thấy các pháp chân đế và có thể quán năm uẩn ấy theo cách vừa trình bày. Theo thứ tự các tuệ, đây chính là tuệ phân biệt danh sắc (nāmarūpaparicchedañāṇa), tức tuệ xác định danh sắc (nāmarūpavavatthānañāṇa).

Hai pháp thuộc nghiệp luân

Khi dâng vật thực cúng dường bảo tháp tôn quý, tức cúng dường Đức Phật, có thể xảy ra những trường hợp sau.
1. Lấy Đức Phật, bậc thọ nhận, làm đối tượng thì các lộ tốc hành thiện có thể sinh.
2. Lấy vật thí, tức vật thực, làm đối tượng thì các lộ tốc hành thiện cũng có thể sinh.
3. Lấy các tư thiện trước đó trong khi dâng cúng làm đối tượng thì những tư thiện về sau, tức các lộ tốc hành thiện, cũng có thể sinh.

Hãy chú tâm quán rõ xem các lộ tốc hành thiện nào sinh trong khi dâng vật thực. Nếu các tốc hành thiện ấy sinh cùng thọ hỷ và tương ưng với trí, thì trong mỗi tốc hành có 34 danh pháp, gồm tâm và các tâm sở. Chúng thuộc nhóm tín và tuệ. Xét theo trình tự lộ tâm…


<a id="M05-body-P080"></a>
## Miến 80
Miến / Burmese 80

…có một sát-na hướng ý môn, bảy sát-na tốc hành và hai sát-na đồng sở duyên. Đồng sở duyên có khi sinh và có khi không.

1. Ở sát-na hướng ý môn có 12 danh pháp.
2. Ở mỗi sát-na tốc hành có 34 danh pháp.
3. Ở mỗi sát-na đồng sở duyên có 34, 33, 33, 32, 12, 11 hoặc 11 danh pháp.

Các nhóm danh pháp ấy là bốn danh uẩn trong từng trường hợp. Các sắc pháp có ở ý vật, chỗ nương của các danh pháp ấy, là sắc uẩn. Do đó có năm uẩn ở sát-na hướng ý môn, năm uẩn ở mỗi sát-na tốc hành và năm uẩn ở mỗi sát-na đồng sở duyên.

Các uẩn sinh theo từng trường hợp như vậy. Trí thấy, biết, quán và phân biệt năm uẩn ấy, theo thứ tự các tuệ, chính là tuệ phân biệt danh sắc (nāmarūpaparicchedañāṇa), tức tuệ xác định danh sắc (nāmarūpavavatthānañāṇa). Năm uẩn thuộc phiền não luân và năm uẩn thuộc nghiệp luân là những uẩn làm nhân cho một số nhóm năm uẩn quả, như tái tục, hữu phần và tử, trong đời hiện tại, dù là đời sống tỳ-khưu hay đời sống người nữ.

Trong các nhóm năm uẩn nói trên, 34 danh pháp có trong mỗi tốc hành thiện được gọi là hành vì chúng tạo tác cho năm uẩn, tức danh và sắc của đời sống tỳ-khưu hoặc đời sống người nữ mà mình mong cầu, có thể sinh khởi…


<a id="M05-body-P081"></a>
## Phần tuệ phân biệt nhân duyên
Miến / Burmese 81

…Chúng là các pháp nhân thúc đẩy một đời sống sinh khởi.

Các pháp hành ấy là vô thường, nên khi sinh rồi chúng diệt. Tuy nhiên, ngay cả khi diệt, chúng không biến mất mà không để lại một năng lực nào trong dòng danh sắc như các uẩn vô ký thuộc quả và duy tác. Chúng để lại trong dòng danh sắc năng lực nghiệp có thể làm sinh năm uẩn của đời sống tỳ-khưu hoặc đời sống người nữ có thể chứng đạt Niết-bàn mà mình mong cầu, rồi mới diệt. Năng lực nghiệp ấy chính là nghiệp.

Phần tuệ phân biệt nhân duyên

Sau khi người thiện tìm thấy các nhân vô minh, ái, thủ, hành và nghiệp đã được tạo dựng từ đời trước như vậy, hãy đối chiếu nghiệp, tức năng lực ấy, với 30 sắc do nghiệp sinh có ở giai đoạn giọt dịch kalala lúc tái tục của mình. Hãy khảo sát nhiều lần xem các sắc do nghiệp sinh lúc tái tục có sinh do nghiệp đó hay không. Hãy quán cho đến khi hiểu được hai bên có liên hệ theo tính chất nhân quả hay không. Cũng như có thể quán rõ tâm và sắc do tâm sinh liên hệ với nhau theo nhân quả hay không, hãy chuyên chú quán rõ nghiệp và sắc do nghiệp sinh có liên hệ nhân quả với nhau hay không.

Nếu chúng thật sự liên hệ với nhau theo nhân quả, chính hành giả sẽ thấy rõ bằng trí tuệ chánh kiến rằng các sắc do nghiệp sinh đang sinh nối tiếp do nghiệp ấy…


<a id="M05-body-P082"></a>
## Miến 82
Miến / Burmese 82

…Cũng như thấy sắc do tâm sinh đang sinh nối tiếp vì tâm, hành giả sẽ thấy sắc do nghiệp sinh đang sinh nối tiếp vì nghiệp.

Nếu nghiệp đã tìm được và các sắc do nghiệp sinh, kể cả sắc do nghiệp sinh lúc tái tục, không liên hệ với nhau theo nhân quả, tức nếu không thấy bằng tuệ rằng các sắc do nghiệp sinh ấy sinh do nghiệp kia, thì cần tìm thêm một nghiệp khác đang cho quả. Hãy quay lại tìm các đối tượng hiện ra trong hữu phần làm ý môn trong sáng khi cận tử, lúc lộ cận tử đang diễn ra. Hãy nhìn tiến về phía trước, rồi lùi lại về phía lộ cận tử. Cứ tìm đi tìm lại như vậy. Phải tìm ra một nghiệp thực sự đang cho quả.

Ở một số hành giả, gần lúc chết, hai hay ba nghiệp hoặc nhiều hơn hiện ra nối tiếp không dứt trong hữu phần làm ý môn trong sáng. Các nghiệp có thể cho quả hiện ra lẫn lộn. Giống như khi mở cổng chuồng có nhiều bò bị nhốt, đàn bò trong chuồng chen lấn từng nhóm để thoát ra lúc trời sáng, các nghiệp của một số người gần chết cũng xuất hiện lẫn lộn như vậy. Giống như con bò đực khỏe nhất trong chuồng chen qua những con khác và ra khỏi chuồng trước tiên, trong số nhiều nghiệp hiện ra chen nhau gần lúc chết, nghiệp mạnh nhất cuối cùng có cơ hội cho quả và cho quả trước. Chính nghiệp sắp cho quả ấy là đối tượng cuối cùng của lộ cận tử. Nói theo cách khác, một trong ba đối tượng xuất hiện do năng lực của nghiệp sắp cho quả ấy, tức nghiệp, nghiệp tướng hoặc thú tướng, trở thành đối tượng của lộ cận tử.


<a id="M05-body-P083"></a>
## Miến 83
Miến / Burmese 83

Khi nhiều nghiệp hiện ra gần lúc chết như vậy, cần tìm cho ra đối tượng của lộ cận tử. Từ đối tượng ấy, hãy tìm vô minh, ái, thủ, hành và nghiệp theo phương pháp trước.

Khi nhiều nghiệp hiện ra không ngớt và lẫn lộn vào lúc cận tử, nếu một nghiệp trong số ấy là nghiệp sinh (janakakamma), trực tiếp làm sinh quả, những nghiệp khác có thể là nghiệp trợ (upatthambhakakamma), có tác dụng nâng đỡ nghiệp sinh ấy. Khi nhìn lại để tìm đối tượng hiện ra trong hữu phần làm ý môn trong sáng gần lúc chết ở đời trước, hành giả có thể lướt qua đối tượng của lộ cận tử và chú tâm trước vào các đối tượng hiện ra trong hữu phần trong sáng ngay trước lộ cận tử hoặc ít lâu trước đó. Khi quán vượt qua như vậy, có thể gặp trước một nghiệp trợ, tức nghiệp có tác dụng nâng đỡ. Nếu nghiệp đó thực sự là nghiệp trợ, hãy khảo sát nhiều lần xem có liên hệ nhân quả giữa nghiệp ấy và sắc do nghiệp sinh lúc tái tục hay không. Có thể thấy giữa chúng không có mối liên hệ ấy, sắc do nghiệp sinh không sinh trực tiếp từ nghiệp đó. Nếu gặp trước nghiệp sinh có thể trực tiếp làm sinh các sắc do nghiệp sinh, kể cả sắc do nghiệp sinh lúc tái tục, thì khi dùng tuệ quán xem chúng có liên hệ nhân quả hay không, tức các sắc ấy có sinh do nghiệp đó hay không, sẽ thấy chúng thực sự có liên hệ nhân quả.

Vì vậy, khi tìm nghiệp quá khứ, hành giả có thể gặp nghiệp trợ có tác dụng nâng đỡ trước, hoặc có thể gặp nghiệp sinh trước. Đó là do quán vượt qua đối tượng. Vì thế cần khảo sát nhiều lần…


<a id="M05-body-P084"></a>
## Sự thay đổi của tướng
Miến / Burmese 84

…và đối chiếu để biết chính xác có liên hệ nhân quả hay không. Khi đã thấy rõ, hãy chú tâm cho đến khi nắm được đối tượng của lộ cận tử cuối cùng, lộ sinh gần tâm tử nhất trong đời trước. Tướng làm đối tượng ấy xuất hiện do năng lực của nghiệp sắp cho quả. Vì thế khi tìm nghiệp ấy, hãy khảo sát và đối chiếu để biết chính xác đối tượng tìm được là nghiệp, nghiệp tướng hay thú tướng.

Sự thay đổi của tướng

Trước khi đến lộ cận tử, các nghiệp hiện ra vào khoảng gần lúc chết, hoặc nghiệp, nghiệp tướng và thú tướng, đôi khi có thể thay đổi tùy theo các nhân như tác ý như lý và tác ý không như lý. Hãy nhớ trường hợp người cha của Trưởng lão Soṇa, vị sống ở tu viện rừng Acela dưới chân núi Soṇa. Ban đầu, trong dòng tâm của người cha hiện ra tướng địa ngục. Theo sự thu xếp của người con là Trưởng lão Soṇa, ông chuyển sang lấy tướng dâng hoa cúng dường bảo tháp làm đối tượng. Vì thế, tướng cõi trời, tướng thiên cung và tướng các thiên nữ hiện ra. (Xem Chú giải Abhidhamma, tập 2, tr. 420–421.) Qua trường hợp ấy, cần ghi nhớ rằng các tướng hiện ra khoảng gần lúc chết, trước lộ cận tử, cũng có thể thay đổi tùy theo tác ý sai, tức tác ý không như lý, hay tác ý đúng, tức tác ý như lý.

Cũng vì các tướng có thể thay đổi như vậy nên khi hành giả khảo sát tìm các nhân quá khứ, trong sự quán sát bằng tuệ…


<a id="M05-body-P085"></a>
## Cách quán các pháp nhân và quả
Miến / Burmese 85

…đôi khi nghiệp trợ có tác dụng nâng đỡ hiện ra trước nghiệp sinh trực tiếp làm sinh quả. Đôi khi, khi nhìn lại để tìm các nhân quá khứ, hành giả quán lướt qua đối tượng của lộ cận tử, sang những đối tượng của dòng danh pháp trước thời điểm ấy. Trong những trường hợp như vậy cũng có thể gặp nghiệp trợ trước rồi khảo sát lại mới gặp nghiệp sinh. Mặt khác, vào khoảng gần lúc chết trước lộ cận tử, các đối tượng có thể có nhiều loại. Đôi khi chính đối tượng của lộ cận tử hiện ra từ khá lâu trước đó. Chẳng hạn, khi cư sĩ Dhammika sắp mất, tướng sáu cỗ xe từ sáu cõi trời hiện ra. Trong sáu cỗ xe, khi cư sĩ Dhammika chọn cõi trời Tusita, cuối cùng chỉ còn cỗ xe của cõi Tusita hiện ra trong lộ cận tử. (Chú giải Dhammapada, tập 1, tr. 83–85.)

Cách quán các pháp nhân và quả

Dựa vào tướng hiện ra gần lúc chết như vậy để nhìn lại và tìm các nhân quá khứ. Giả sử đối tượng hiện rõ trong lộ cận tử là tướng dâng vật thực cúng dường bảo tháp, như đã nêu trên. Hãy tìm vô minh, ái, thủ, hành và nghiệp trong dòng danh sắc lúc đang dâng vật thực như đã giải thích. Rồi khảo sát xem năng lực nghiệp ấy và 30 sắc pháp vào sát-na giọt dịch kalala có liên hệ nhân quả…


<a id="M05-body-P086"></a>
## Điểm chính cần ghi nhớ
Miến / Burmese 86

…hay không. Hãy lần lượt nhìn nhân rồi nhìn quả, nhiều lần đối chiếu tính chất liên hệ nhân quả giữa các pháp nhân và các pháp quả. Tâm và sắc do tâm sinh liên hệ nhân quả với nhau thế nào, cũng hãy quán hai bên là pháp nhân gọi là nghiệp và pháp quả gọi là sắc do nghiệp sinh như thế ấy. Nếu thấy chúng liên hệ với nhau theo nhân quả, hãy quán các pháp nhân và các pháp quả theo cách dưới đây.

Do vô minh (20) sinh nên sắc do nghiệp sinh lúc tái tục sinh. Vô minh (20) là pháp nhân. Sắc uẩn lúc tái tục là pháp quả.

Cứ như vậy, hãy nối pháp nhân với pháp quả và dùng tuệ quán cho đến khi thấy mối liên hệ nhân quả giữa chúng. Hãy quán các pháp nhân và các pháp quả như trên, tức dùng tuệ phân biệt chúng. Khi quán được như vậy thì gọi là tuệ phân biệt nhân duyên (paccayapariggahañāṇa), tức tuệ có thể quán các pháp nhân.

Điểm chính cần ghi nhớ

Các nhân quá khứ của năm uẩn quả thuộc quả luân là vô minh, ái, thủ, hành và nghiệp. Trong đó, các nhân quá khứ của sắc uẩn là vô minh, ái, thủ, hành và nghiệp. Các nhân hiện tại là tâm, thời tiết và vật thực. Các nhân quá khứ của bốn danh uẩn quả cũng là vô minh, ái, thủ, hành và nghiệp. Các nhân hiện tại…


<a id="M05-body-P087"></a>
## Sắc uẩn
Miến / Burmese 87

…là các nhân như vật, cảnh và xúc. Có thể ghi nhớ theo cách khác như sau.

Sắc uẩn

1. Các nhân của sắc do nghiệp sinh, phần thuộc về quả trong sắc uẩn, là vô minh, ái, thủ, hành và nghiệp. Đó là các nhân quá khứ.

2. Nhân của sắc do tâm sinh là tâm sinh nương sắc ý vật.

3. Nhân của sắc do thời tiết sinh là hỏa đại, tức thời tiết, của sắc đã đạt đến sát-na trụ và hiện diện trong hầu hết các nhóm sắc. [Ghi chú của nguyên tác. Như đã giải thích ở phần đề mục thiền sắc, hỏa đại, tức thời tiết, có trong các nhóm sắc như nhóm mười sắc có thần kinh nhãn và các nhóm sắc do nghiệp, tâm, thời tiết và vật thực sinh làm sinh các nhóm sắc nối tiếp. Hỏa đại, tức thời tiết, trong nhóm sắc cuối cùng không làm sinh sắc do thời tiết sinh. Vì vậy dùng chữ “hiện diện trong hầu hết các nhóm sắc”.]

4. Nhân của sắc do vật thực sinh là dưỡng chất, gồm dưỡng chất do nghiệp, do tâm, do thời tiết và do vật thực sinh. [Ghi chú của nguyên tác. Khi dưỡng chất do thời tiết sinh trong thức ăn đã ăn được lửa tiêu hóa do nghiệp sinh nâng đỡ, nó làm sinh các nhóm sắc mới có dưỡng chất do vật thực sinh. Khi dưỡng chất ấy được dưỡng chất có trong các nhóm sắc nâng đỡ…


<a id="M05-body-P088"></a>
## Bốn danh uẩn
Miến / Burmese 88

…dưỡng chất do nghiệp, tâm và thời tiết sinh, cùng dưỡng chất do vật thực sinh thuộc các thế hệ tiếp theo, lần lượt làm sinh các nhóm sắc có dưỡng chất do vật thực sinh. Hãy xem lại toàn bộ điều này trong phần đề mục thiền sắc. Khi được dưỡng chất trong các nhóm sắc nâng đỡ, dưỡng chất trong những nhóm sắc do vật thực sinh thuộc các thế hệ tiếp theo cũng lại làm sinh các nhóm sắc mới do dưỡng chất sinh. Do đó, trong phần nói về các nhân của sắc do vật thực sinh có nêu cả dưỡng chất do vật thực sinh, cùng với dưỡng chất do nghiệp, tâm và thời tiết sinh.]

Bốn danh uẩn

Các nhân quá khứ của hai loại danh pháp quả sau đều là vô minh, ái, thủ, hành và nghiệp. Một là bốn danh uẩn quả thuộc tâm ngoài lộ, tức tái tục, hữu phần và tử. Hai là bốn danh uẩn quả trong lộ tâm, gồm năm thức như nhãn thức, cùng tâm tiếp thọ, suy đạc và đồng sở duyên. Các nhân hiện tại của những danh pháp ấy là các nhân như vật, cảnh và xúc.

1. Vật là sắc làm chỗ nương. Trong cõi có năm uẩn, nếu không có sắc làm chỗ nương thì các danh pháp ấy không thể sinh.
2. Cảnh. Chỉ khi một cảnh thích hợp hiện ra, đến đúng môn tương ứng, thì các danh pháp ấy mới có thể sinh. Phải có cảnh để biết thì mới có sự biết. Hãy hiểu theo cách ấy.


<a id="M05-body-P089"></a>
## Miến 89
Miến / Burmese 89

3. Xúc. Các pháp tương ưng như xúc, nói cách khác là bốn danh uẩn, phải trợ lẫn nhau bằng năng lực của các duyên như câu sinh, hỗ tương, y chỉ, hiện hữu và bất ly thì những danh pháp ấy mới có thể sinh. Để một uẩn sinh, ba danh uẩn còn lại phải trợ cho nó. Trong các uẩn ấy, xúc là một nhân chính nổi bật đối với việc tiếp nhận cảnh.

Điều cần lưu ý. Các thức quả trong thời bình nhật, như ngũ thức, tiếp thọ, suy đạc và đồng sở duyên, có thể sinh do chính nghiệp sinh trực tiếp làm sinh các tâm ngoài lộ là tái tục, hữu phần và tử. Chúng cũng có thể sinh do những nghiệp sinh khác làm sinh các quả trong thời bình nhật. Nghiệp ấy có thể là thiện hay bất thiện. Do nghiệp thiện sinh ngũ thức, tiếp thọ, suy đạc và đồng sở duyên là quả thiện. Do nghiệp bất thiện sinh ngũ thức, tiếp thọ, suy đạc và đồng sở duyên là quả bất thiện. Quả thiện sinh khi gặp cảnh khả ái, quả bất thiện sinh khi gặp cảnh bất khả ái. Dù các vị đệ tử không thể biết hết nghiệp và quả của nghiệp, họ vẫn cần biết được một phần. Cần lưu ý để khảo sát các nhân này cả khi quán năm uẩn quá khứ lẫn khi tìm các nhân quá khứ.

Lại nữa, tâm hướng ngũ môn và tâm xác định trong lộ ngũ môn, cùng tâm hướng ý môn trong lộ ý môn, cả ba đều là tâm duy tác. Chúng chỉ làm nhiệm vụ hướng đến và xác định cảnh đã hiện ra. Khi môn và cảnh gặp nhau…


<a id="M05-body-P090"></a>
## Bốn phương pháp — 1. Phương pháp đồng nhất
Miến / Burmese 90

…chỉ các tâm duy tác ấy hiện khởi. Do đó chúng không phải là danh pháp sinh do các nhân quá khứ. Chúng là nhóm danh pháp sinh chỉ do những nhân hiện tại như vật, cảnh và xúc. Vì thế những danh pháp này không có nhân quá khứ. Chúng chỉ có các nhân hiện tại như vật, cảnh và xúc.

Cũng vậy, các tốc hành thiện chỉ sinh do các nhân như vật, cảnh, xúc và tác ý như lý. Các tốc hành bất thiện cũng chỉ sinh do các nhân như vật, cảnh, xúc và tác ý không như lý. Các nhóm danh pháp ấy không phải là danh pháp sinh từ các nhân quá khứ. Vì vậy hãy ghi nhớ rằng các nhóm danh pháp tốc hành thiện và bất thiện không có nhân quá khứ. Chúng chỉ có các nhân hiện tại.

Bốn phương pháp — 1. Phương pháp đồng nhất

Khi hành giả quán duyên khởi, cần hiểu rõ bốn phương pháp rất quan trọng là phương pháp đồng nhất (ekattanaya), sai biệt (nānattanaya), vô tác giả (abyāpāranaya) và tính quy luật (evaṃdhammatānaya). Hãy quán để hiểu chúng trong khi quán tính chất duyên khởi và mối liên hệ nhân quả. Phương pháp đồng nhất là như sau.

1. Danh sắc quá khứ trong đó các nhân quá khứ được vun bồi.
2. Danh sắc đang sinh từng lúc từ tái tục hiện tại đến lúc quán các nhân trong hiện tại, hoặc, khi đã bước sang phần minh sát, đến lúc quán minh sát…


<a id="M05-body-P091"></a>
## Miến 91
Miến / Burmese 91

3. Danh sắc tương lai sẽ sinh từ lúc hiện đang quán duyên khởi, tức mối liên hệ nhân quả, cho đến lúc chấm dứt trong tương lai, nếu vẫn chưa có thể tu tập đến quả vị A-la-hán nên tương lai ấy còn hiện hữu. Nói cách khác, danh sắc quá khứ, hiện tại và tương lai lần lượt đã hiện hữu, đang hiện hữu và sẽ hiện hữu trong ba đời, đời quá khứ, đời hiện tại và đời tương lai.

Cần thấy bằng tuệ các danh sắc đã hiện hữu, đang hiện hữu và sẽ hiện hữu trong ba thời quá khứ, hiện tại và tương lai ấy như một dòng nối tiếp, xét theo dòng danh sắc. Dòng danh sắc ấy là một dòng vô thường, một dòng sinh rồi diệt.

Nói rõ hơn đôi chút, nếu hành giả chú tâm quán hữu phần làm ý môn trong sáng vào lúc vun bồi việc thiện trong đời quá khứ làm nhân đưa đến đời người hiện nay, rồi quán hữu phần làm ý môn trong sáng hiện tại, sẽ thấy, như sợi chỉ được kéo thành một đường, rằng xét theo dòng tương tục, chúng tiếp nối thành một dãy, một mạch, một chuỗi, thành một dòng sinh diệt. Hãy quán bằng tuệ cho đến khi hiểu rõ điều đó. Hữu phần là tâm sinh thường xuyên nhất trong một đời. Vì vậy ở đây lấy hữu phần làm chính để giải thích cho dễ hiểu. Sabhāvo vāyaṃ…


<a id="M05-body-P092"></a>
## Đặc tính của đời quá khứ
Miến / Burmese 92

…cittassa paṇḍaratā. (Mūlaṭīkā, tập 1, tr. 125.) Theo lời Phụ chú giải gốc, dù các tâm sở bất thiện ô nhiễm, mọi tâm vẫn có tính trong sáng. Do đó, sự trong sáng của hữu phần và sự trong sáng của các tâm trong lộ xen giữa các hữu phần, tức sự trong sáng của mọi tâm, là sự trong sáng theo bản tính. Người thiện hãy dùng tuệ quán cho thấy rằng dòng danh pháp trong sáng ấy sinh nối tiếp thành một dãy, một mạch, một chuỗi. Cũng theo cách ấy, hãy tiếp tục dùng tuệ quán cho thấy dòng sắc pháp sinh nối tiếp thành một dãy, một mạch, một chuỗi.

Đặc tính của đời quá khứ

Hãy quán kỹ xem hữu phần làm ý môn trong sáng thuộc về dòng danh sắc đang làm việc thiện trong đời quá khứ, hay dòng danh pháp ấy, có phải là hữu phần làm ý môn trong sáng của chính mình, hay là dòng danh pháp của chính mình hay không. Nếu đúng là hữu phần làm ý môn trong sáng hoặc dòng danh pháp của mình, hành giả có thể dễ dàng hiểu rõ là hữu phần làm ý môn trong sáng và dòng danh pháp của chính mình. Cũng vậy, hành giả có thể dễ dàng hiểu rõ đó là dòng sắc của chính mình. Sở dĩ như vậy là vì dòng danh pháp và dòng sắc pháp tiếp nối thành một dãy, một mạch, một chuỗi, một dòng.

Khi nhìn lại dòng danh sắc quá khứ như vậy, một số hành giả nhận rằng “tâm tính của mình trong đời quá khứ…


<a id="M05-body-P093"></a>
## Ánh sáng rộng và mạnh khi quán đời trước
Miến / Burmese 93

…phần lớn giống với tâm tính hiện nay”. Đó chính là do các tập khí tương tự, hợp nhau, đi theo. Tu tập thiền chỉ và minh sát là để thay các tập khí xấu bằng các tập khí tốt và nỗ lực làm cho những tập khí tốt sinh khởi liên tục. Khi các tập khí xấu đã được nhổ tận gốc và chỉ các tập khí tốt vận hành trọn vẹn, công việc tu tập của hành giả đã đạt đến chỗ cao nhất.

Có vẻ khó, và quả thật là khó.
Có vẻ sâu, và quả thật là sâu.

Khi quán danh sắc từ quá khứ đến hiện tại hoặc quán các nhân quá khứ theo cách ấy, sau khi quán danh sắc của đời hiện tại ngược đến tái tục, hành giả hướng tuệ về quá khứ để tìm các nhân. Có khi không thấy danh sắc nào, chỉ thấy một khối ánh sáng sáng rực, rất mạnh, rất lớn và trải rộng. Lúc đó, nếu thiếu kiến thức đã học, hành giả có thể đứng lại, không biết cách tiến tiếp. Những hành giả như vậy phần lớn là người từ cõi trời hoặc cõi Phạm thiên sinh xuống. Cần khảo sát cẩn thận xem có đúng hay không. Phần lớn những hành giả gặp khó khăn như vậy, trong lúc quán danh sắc nội phần và ngoại phần…


<a id="M05-body-P094"></a>
## Miến 94
Miến / Burmese 94

…trong hai loại dòng tương tục, nội phần và ngoại phần, đã chỉ quán chung mà chưa chú trọng riêng danh sắc trong dòng tương tục của chư thiên và trong dòng tương tục của Phạm thiên. Vì thế, khi gặp khối ánh sáng lớn và trải rộng như vậy, họ không biết cách quán danh sắc hiện hữu trong đó. Chư thiên có phước càng lớn thì ánh sáng thân thể càng rực rỡ. Ánh sáng thân thể của Phạm thiên còn rực rỡ hơn ánh sáng thân thể chư thiên. Thân chư thiên to lớn, thân Phạm thiên còn to lớn hơn. Sắc pháp của chư thiên cực kỳ vi tế, sắc pháp của Phạm thiên còn vi tế hơn sắc pháp của chư thiên. Người khi quán danh sắc ngoại phần chỉ quán chung mà chưa chú tâm khảo sát danh sắc chư thiên và Phạm thiên có thể gặp khó khăn khi quán các sắc pháp hết sức vi tế như vậy.

Khi gặp khó khăn như vậy, hãy quán lại danh sắc nội phần và ngoại phần. Hãy đặc biệt chú trọng quán sắc pháp của chư thiên. Khi quán thành công, hãy hướng tuệ đến các cõi trời và tiếp tục quán các sắc pháp vi tế trong dòng tương tục của chư thiên ở từng tầng trời. Hãy quán một lượt nội phần rồi một lượt ngoại phần. Sau đó hãy chuyển sang quán các sắc pháp trong dòng tương tục của Phạm thiên. Sắc pháp của Phạm thiên hết sức vi tế. Vì thế hãy nhiều lần thiết lập lại định và nhiều lần…


<a id="M05-body-P095"></a>
## Miến 95
Miến / Burmese 95

…quán. Có thể thành công. Khi đã có thể nhiều lần quán sắc pháp nội phần và ngoại phần đến tận cõi Phạm thiên như vậy, hãy đặc biệt tiếp tục quán để hiểu rõ trong dòng tương tục của Phạm thiên không có nhóm mười sắc có thần kinh tỷ, nhóm mười sắc có thần kinh thiệt, nhóm mười sắc có thần kinh thân và nhóm mười sắc giới tính. Khi thành công, hãy tiếp tục quán các danh pháp.

Trong dòng tương tục của chư thiên, cũng như trong dòng tương tục của người, các nhóm sắc do nghiệp, tâm và vật thực sinh có thể hiện diện đầy đủ. Trong dòng tương tục của Phạm thiên, các nhóm sắc không thể hiện diện đầy đủ tất cả. Đó là sự khác nhau về các nhóm sắc giữa chư thiên và Phạm thiên. Khi đã có thể chuyển sang quán danh sắc của chư thiên và Phạm thiên ngoại phần, hãy bắt đầu quán bốn đại trong khối ánh sáng rất lớn và trải rộng đã gặp khi tìm các nhân quá khứ. Khi thấy những hạt nhỏ là các nhóm sắc, hãy phân tích những nhóm sắc ấy đến tận chân đế. Khi quán sắc chân đế như vậy, nếu khối ánh sáng đó thuộc đời sống chư thiên, hành giả sẽ thấy các nhóm sắc đầy đủ như đã giải thích trên. Nếu khối ánh sáng thuộc đời sống Phạm thiên thì trong các sắc do nghiệp sinh sẽ không tìm thấy một số loại, như đã nêu. Khi đã có thể quán sắc pháp, hãy tiếp tục quán sắc ý vật, hữu phần trong sáng tức ý môn, và những danh pháp sinh lấy ý môn ấy làm cửa và nương trên sắc ý vật ấy. Lại tiếp tục quán trong số những danh pháp ấy các nhóm do vô minh, ái và thủ dẫn đầu…


<a id="M05-body-P096"></a>
## Khi thấy ba hoặc bốn người
Miến / Burmese 96

…tức các nhóm danh pháp trong lộ ý môn thuộc phiền não luân, cùng các nhóm danh pháp trong lộ ý môn thuộc nghiệp luân, tức hành và nghiệp. Khi quán như vậy, hãy dùng tuệ phân biệt và quán cho biết rằng dòng danh sắc đời trước và dòng danh sắc hiện tại tiếp nối thành một dãy, một mạch, một chuỗi, một dòng. Khi biết như vậy, gọi là biết phương pháp đồng nhất.

Khi thấy ba hoặc bốn người

Đôi khi, khi tìm các nhân quá khứ, một số hành giả thấy trong cảnh làm việc thiện ở đời trước có ba hoặc bốn người đang làm việc thiện. Nếu thấy như vậy, hãy bắt đầu quán bốn đại trong dòng tương tục của từng người, hết người này đến người khác. Trước tiên hãy quán bốn đại trong dòng tương tục của một người. Khi thấy các hạt nhóm sắc, tiếp tục quán các sắc chân đế. Sau đó tiếp tục quán danh pháp. Rồi tiếp tục quán danh sắc của một người khác theo cách tương tự. Kế đó lại tiếp tục quán danh sắc của người tiếp theo theo cách tương tự. Trong các dòng danh sắc ấy, dòng danh sắc nào thấy được là nối với danh sắc hiện tại của mình thành một dãy, một mạch, một chuỗi, một dòng, thì đó chính là dòng danh sắc của mình.

Trong khi quán như vậy, nếu còn chưa chắc, hãy chú tâm riêng vào hữu phần làm ý môn trong sáng của từng người…


<a id="M05-body-P097"></a>
## Miến 97
Miến / Burmese 97

…mà quán. Hành giả thường có thể dễ dàng biết đó có phải là hữu phần làm ý môn trong sáng của mình hay không. Sở dĩ như vậy là vì khi chính mình thấy rõ bằng con mắt trí tuệ chánh kiến rằng hữu phần làm ý môn trong sáng hiện tại và hữu phần làm ý môn trong sáng đời trước hợp thành một dãy, một mạch, một chuỗi, một dòng xét theo dòng danh pháp, hành giả dễ dàng thấy rõ rằng hữu phần làm ý môn trong sáng đời trước ấy chính là của mình. Nếu chú tâm quán hữu phần làm ý môn trong sáng trong quá khứ mà nó không phải là hữu phần làm ý môn trong sáng của mình đang quán, hành giả cũng có thể dễ dàng thấy rằng nó không phải của mình. Sở dĩ như vậy là vì hai dòng danh pháp không tiếp nối với nhau. Nếu danh sắc quá khứ không phải dòng danh sắc của mình, hành giả có thể tự mình thấy rằng dòng danh sắc của người khác ấy trong quá khứ và dòng danh sắc hiện tại của mình không đến thành một dãy, một mạch, một chuỗi, một dòng, mà là hai dòng không tiếp nối với nhau.

Dòng danh sắc của mình trong quá khứ và dòng danh sắc của mình hiện tại tiếp nối trước sau, lần lượt sinh, thành một dãy, một mạch, một chuỗi, một dòng. Khi hành giả tự mình thấy rõ điều này bằng trí tuệ chánh kiến…


<a id="M05-body-P098"></a>
## Đoạn kiến và thường kiến
Miến / Burmese 98

…thì do thấy rõ bằng trí tuệ chánh kiến rằng dòng danh sắc ấy tiếp nối trước sau và sinh nối tiếp như một dãy, một mạch, một chuỗi, một dòng, gọi là biết phương pháp đồng nhất. Cũng hãy hiểu theo cách ấy khi quán để chính mình thấy rõ bằng trí tuệ chánh kiến rằng dòng danh sắc hiện tại và dòng danh sắc tương lai nối nhau trước sau, lần lượt sinh thành một dãy, một mạch, một chuỗi, một dòng.

Đoạn kiến và thường kiến

Tattha avijjāpaccayā saṅkhārā, saṅkhārapaccayā viññāṇanti evaṃ bījassa aṅkurādibhāvena rukkhabhāvappatti viya santānānupacchedo ekattanayo nāma. Yaṃ sammā passanto hetuphalasambandhena pavattamānassa santānassa anupacchedāvabodhato ucchedadiṭṭhiṃ pajahati. Micchā passanto hetuphalasambandhena pavattamānassa santānānupacchedassa ekattaggahaṇato sassatadiṭṭhiṃ upādiyati. (Chú giải Abhidhamma, tập 2, tr. 188. Visuddhimagga, tập 2, tr. 220.)

Từ hạt giống nảy ra mầm, từ mầm ấy sinh ra lá. Từ hạt giống ấy, rễ, thân, cành, lá non và lá già lần lượt xuất hiện không gián đoạn. Hạt giống trở thành cây. Nó xuất hiện dưới dạng cây. Vì vậy, khi hạt giống và cây nối thành một dãy, dòng tương tục không đứt. Khi dòng tương tục không đứt, có thể nói là “cùng một dòng”. Cũng như thế…


<a id="M05-body-P099"></a>
## Miến 99
Miến / Burmese 99

Do vô minh, hành sinh. Do hành, thức sinh. Cứ như vậy, khi nhân và quả tiếp nối thành một dãy, một dòng tương tục không gián đoạn, cách hiểu đó là “một dòng” được gọi là phương pháp đồng nhất.

Khi thấy biết phương pháp đồng nhất đúng đắn, tuệ thấu suốt sự không gián đoạn của dòng danh sắc sinh nối tiếp trong quan hệ nhân quả, chẳng hạn các nhân quá khứ với các quả hiện tại, và các nhân hiện tại với các quả tương lai. Nhờ thấy biết như vậy, có thể đoạn trừ kiến chấp và sự bám chặt vào đoạn kiến cho rằng “đời sống chỉ có từ lúc sinh đến lúc chết, chết là hết, sau khi chết chẳng còn gì”. Nếu không thấy sự liên hệ nhân quả ấy mà thấy sai lầm, thì thường kiến cũng có thể sinh khởi.

Pháp nhân và pháp quả khác nhau xét theo tự tính chân đế của pháp nhân và tự tính chân đế của pháp quả. Tuy nhiên, dù chúng khác nhau theo tự tính chân đế, xét về mặt pháp nhân cũng như xét về mặt pháp quả, chúng liên kết với nhau theo tính chất nhân quả. Chính sự tiếp nối ấy ở đây được gọi là santānānupaccheda, tức sự không gián đoạn của dòng tương tục. Vì dòng danh sắc không gián đoạn như vậy, nghiệp đã tạo trong dòng danh sắc nào thì quả chỉ sinh trong chính dòng danh sắc ấy. Hãy ghi nhớ rằng nghiệp đã tạo không thể mất đi, và nghiệp chưa tạo cũng không thể tiến đến cho quả.


<a id="M05-body-P100"></a>
## 2. Phương pháp sai biệt
Miến / Burmese 100

Cái thấy sai lầm ở đây sinh do không khảo sát và không thấy sự sai khác giữa các pháp nhân và quả đang sinh nối tiếp và liên hệ với nhau theo nhân quả. Người ấy xem các pháp nhân và các pháp quả là cùng một thứ, rồi chấp sự không gián đoạn của dòng danh sắc sinh nối tiếp theo nhân quả là một thực thể duy nhất không sai khác. Vì không thấy vô thường, khổ và vô ngã nơi danh sắc nhân và danh sắc quả, người ấy hiểu theo nghĩa thường còn và theo nghĩa tự ngã rằng “Tadeva viññāṇaṃ sandhāvati saṃsarati”, chính thức ấy chạy từ đời này sang đời kia, từ đời kia sang đời nọ, rồi nhiều lần lưu chuyển trong cùng một đời. Chấp dòng danh sắc là một thực thể duy nhất theo cách ấy chính là thường kiến. Nếu hiểu sai phương pháp đồng nhất thì đã nắm chặt thường kiến. (Chú giải Abhidhamma, tập 2, tr. 188. Visuddhimagga, tập 2, tr. 220. Mūlaṭīkā, tập 2, tr. 131. Mahāṭīkā, tập 2, tr. 347.)

2. Phương pháp sai biệt

Avijjādīnaṃ pana yathāsakalakkhaṇavavatthānaṃ nānattanayo nāma. Yaṃ sammā passanto navanavānaṃ uppādadassanato sassatadiṭṭhiṃ pajahati. Micchā passanto ekasantānapatitassa bhinnasantānasseva nānattaggahaṇato ucchedadiṭṭhiṃ upādiyati. (Chú giải Abhidhamma, tập 2, tr. 188. Visuddhimagga, tập 2, tr. 220.)

Theo phương pháp đồng nhất, các pháp liên hệ nhân quả hiện ra thành một dòng tương tục…


<a id="M05-body-P101"></a>
## Miến 101
Miến / Burmese 101

…Nhận rõ từng đặc tính riêng của các pháp nhân và quả đang sinh trong dòng ấy, như vô minh, hành, thức, danh sắc, sáu xứ, xúc, thọ, ái, thủ, hữu, sinh, già và chết, được gọi là phương pháp sai biệt. Để quán theo phương pháp này, phải dùng tuệ phá tan khối tưởng về danh sắc, gồm khối do tương tục, do tập hợp, do chức năng và do đối tượng. Hãy quán các chi duyên khởi đúng từng trường hợp theo đặc tính, chức năng, biểu hiện và nhân gần, cho đến khi tuệ thấy chân đế.

Danh sắc quá khứ, hiện tại và tương lai quả thật nối nhau thành một dòng tương tục. Tuy vậy, hãy quán để thấy từng nhóm sắc và từng nhóm tâm riêng biệt, phá tan khối do tương tục. Các pháp như vô minh ấy lại chỉ sinh thành nhóm sắc hoặc nhóm danh. Hãy dùng tuệ phân tích từng pháp chân đế trong mỗi nhóm sắc hoặc nhóm danh: đây là địa đại, đây là thủy đại, đây là hỏa đại, đây là phong đại, v.v., hoặc đây là xúc, đây là thọ, đây là tưởng, đây là tư, đây là thức, v.v. Hãy quán để phá tan khối do tập hợp của sắc và khối do tập hợp của danh. Cũng hãy quán để phá tan khối do chức năng, tức chức năng của sắc và chức năng của danh. Vì thế, khi người thiện biết quán các chi duyên khởi đúng từng trường hợp theo đặc tính, chức năng, biểu hiện và nhân gần, gọi là biết phương pháp sai biệt.


<a id="M05-body-P102"></a>
## Miến 102
Miến / Burmese 102

Khi thấy đúng phương pháp sai biệt ấy, hành giả tự mình thấy rõ bằng trí tuệ chánh kiến rằng các pháp chân đế mới liên tục sinh lên, lần lượt nối nhau theo nhân quả. Vì tự mình thấy rõ bằng trí tuệ chánh kiến rằng các pháp nhân và các pháp quả có tự tính và đặc tính khác nhau, hành giả có thể đoạn trừ thường kiến chấp rằng “tự ngã không chấm dứt khi chết”.

Nếu không thấy đúng phương pháp sai biệt ấy, có thể thấy sai lầm. Người ấy bám chặt vào các danh sắc riêng biệt đang sinh trong cùng một dòng danh sắc như thể chúng thuộc các dòng khác nhau. Dòng các uẩn danh sắc, tuy qua những đời khác nhau, chỉ là một dòng tiếp nối. Từ đời ẩn sĩ Sumedha cho đến đời Đức Phật Gotama, dòng danh sắc vẫn chỉ là một dòng tiếp nối. Mặc dù vậy, có người không thể hiểu là “cùng một dòng tương tục” và cho rằng chúng sinh chết trong đời này là một người, chúng sinh sinh trong đời sau lại là một người khác, như thể có những dòng tương tục riêng biệt. Hiểu như vậy là đã nắm chặt đoạn kiến rằng “chúng sinh chết là hết”. Nếu hiểu như thể có các dòng tương tục riêng biệt, rằng “người làm thiện hay bất thiện là một người, người nhận quả tốt hay xấu lại là người khác, thân này do người đời này làm, thân kia do người đời kia chịu”, thì đã nắm chặt đoạn kiến. (Chú giải Abhidhamma, tập 2, tr. 188. Visuddhimagga, tập 2, tr. 220. Mūlaṭīkā, tập 2, tr. 132. Mahāṭīkā, tập 2, tr. 347–348.)


<a id="M05-body-P103"></a>
## 3. Phương pháp vô tác giả
Miến / Burmese 103

3. Phương pháp vô tác giả

Avijjāya saṅkhārā mayā uppādetabbā, saṅkhārānaṃ vā viññāṇaṃ amhehīti evamādibyāpārābhāvo abyāpāranayo nāma. Yaṃ sammā passanto kārakassa abhāvāvabodhato attadiṭṭhiṃ pajahati. Micchā passanto yo asatipi byāpāre avijjādīnaṃ sabhāvaniyamasiddho hetubhāvo, tassa aggahaṇato akiriyadiṭṭhiṃ upādiyati. (Chú giải Abhidhamma, tập 2, tr. 188. Visuddhimagga, tập 2, tr. 220.)

Về phía các pháp nhân, không có sự chủ động lo liệu rằng mình sẽ làm cho các pháp quả sinh khởi. Về phía các pháp quả, cũng không có sự chủ động lo liệu rằng “khi các pháp nhân hiện hữu thì chúng ta, những pháp quả, sẽ hiện hữu”.

Trong vô minh không có sự chủ động lo liệu “ta sẽ làm sinh các hành”. Trong các hành cũng không có sự chủ động lo liệu “chúng ta sẽ làm sinh thức”. Tính chất không có sự chủ động lo liệu nơi các pháp như vô minh và hành được gọi là phương pháp vô tác giả.

Khi quán đề mục duyên khởi, hành giả phải quán và tu tập để thấy đúng phương pháp vô tác giả này. Thấy đúng là thấy rằng “các pháp như vô minh và hành là nirīha, không có sự cố gắng, nỗ lực làm sinh pháp quả. Chúng là nijjīva, không phải một sinh mạng có khả năng nỗ lực như vậy. Chúng là dhammatā, chỉ có tính quy luật tự nhiên là có thể làm sinh pháp quả tương ứng”…


<a id="M05-body-P104"></a>
## Miến 104
Miến / Burmese 104

…Người thấy như vậy được gọi là sammā passanto, người thấy đúng đắn, người có chánh kiến. Sự thấy biết như vậy gọi là thấy đúng.

Khi hành giả tự mình thấy rõ phương pháp vô tác giả ấy bằng trí tuệ chánh kiến, có thể đoạn trừ ngã kiến chấp rằng có một tự ngã tối thượng tác động và sáng tạo, hoặc một sinh mạng, một tự ngã chịu sự tác động và sáng tạo ấy. Sở dĩ như vậy là vì hành giả tự mình thấy rõ bằng trí tuệ chánh kiến rằng trong các pháp nhân không có sự chủ động lo liệu làm sinh các pháp quả.

Nếu thấy sai phương pháp vô tác giả này, dù các pháp nhân không có sự chủ động lo liệu làm sinh các pháp quả, chúng vẫn hiện hữu với tính chất là pháp nhân, thành tựu theo quy luật tự nhiên, có thể làm sinh các pháp quả như hành. Do không thể chấp nhận tính chất ấy, người ấy có thể chấp tà kiến vô tác (akiriyadiṭṭhi), cho rằng “dù có hành động thì hành động ấy là vô hiệu”.

Quy luật tự nhiên (sabhāvaniyama) là tính quy luật của sự sinh khởi. Cùng với cụm sắc kết hợp, hỏa đại gọi là lửa hướng lên trên, nên ngọn lửa vươn lên. Cùng với cụm sắc kết hợp, gió có tính trương giãn, nên căng ra. Những cách sinh khởi như vậy là quy luật tự nhiên, là tính chất sinh khởi…


<a id="M05-body-P105"></a>
## Miến 105
Miến / Burmese 105

…tức diễn tiến thông thường. Cũng tương tự như vậy, khi các pháp nhân như vô minh hiện hữu, các pháp quả như hành hiện khởi. Khi các pháp nhân như vô minh không hiện hữu, các pháp quả như hành cũng không hiện khởi. Nói cách khác, khi các pháp nhân là vô minh, ái, thủ, hành và nghiệp hiện hữu, các pháp quả là thức, danh sắc, sáu xứ, xúc và thọ hiện khởi. Khi các pháp nhân là vô minh, ái, thủ, hành và nghiệp không hiện hữu, các pháp quả là thức, danh sắc, sáu xứ, xúc và thọ cũng không hiện khởi. Đây gọi là sabhāvaniyamasiddhahetubhāva, tính chất làm nhân được thành tựu theo quy luật sinh khởi tự nhiên. Nếu không chấp nhận rằng các pháp nhân như vô minh có năng lực thành tựu theo quy luật sinh khởi tự nhiên để làm sinh các pháp quả như hành…

Kassaci kattuno abhāvā na kāci kiriyā phalappavattinī. (Mahāṭīkā, tập 2, tr. 348.)

…thì có thể sinh một loại tà kiến vô tác, bác bỏ nghiệp và quả của nghiệp. Kiến ấy cho rằng vì không có một người hay một pháp nào đóng vai trò tác giả nên bất cứ hành động nào bằng thân, khẩu hay ý cũng không liên hệ với quả, tức không cho quả. Theo kiến ấy, không có hành động bằng thân, khẩu hay ý nào liên hệ với quả. (Chú giải Abhidhamma, tập 2, tr. 188. Visuddhimagga, tập 2, tr. 220. Mahāṭīkā, tập 2, tr. 348.)


<a id="M05-body-P106"></a>
## 4. Phương pháp tính quy luật
Miến / Burmese 106

4. Phương pháp tính quy luật

Avijjādīhi pana kāraṇehi saṅkhārādīnaṃyeva sambhavo khīrādīhi dadhiādīnaṃ viya, na aññesanti ayaṃ evaṃdhammatānayo nāma. Yaṃ sammā passanto paccayānurūpato phalāvabodhā ahetukadiṭṭhiṃ akiriyadiṭṭhiñca pajahati. Micchā passanto paccayānurūpaṃ phalappavattiṃ aggahetvā yato kutoci yassa kassaci asambhavaggahaṇato ahetukadiṭṭhiñceva niyatavādañca upādiyati. (Chú giải Abhidhamma, tập 2, tr. 188–189. Visuddhimagga, tập 2, tr. 220–221.)

Cũng như từ sữa chỉ sinh sữa đông và những thứ tương tự, khi các pháp quả sinh từ các pháp nhân như vô minh thì chỉ các pháp quả như hành, phù hợp với các pháp nhân ấy, mới sinh. Quả khác, không phù hợp với nhân, không sinh. Nói cách khác, khi có quả sinh do các pháp nhân là vô minh, ái, thủ, hành và nghiệp, chỉ những pháp quả phù hợp với các nhân ấy, tức thức, danh sắc, sáu xứ, xúc và thọ, mới sinh. Bất kỳ quả nào khác không phù hợp với nhân đều không thể sinh. Đây gọi là phương pháp tính quy luật. Khi thấy đúng phương pháp này, do tự mình thấy rõ bằng trí tuệ chánh kiến rằng quả sinh phù hợp với nhân, hành giả có thể đoạn trừ vô nhân kiến, vốn chấp rằng không có nhân, và vô tác kiến, vốn chấp rằng dù làm thiện hay bất thiện thì hành động ấy cũng vô hiệu. Nói cách khác, có thể đoạn trừ hai tà kiến này, vốn bác bỏ quả sinh do nhân, tức bác bỏ cả nhân lẫn quả.


<a id="M05-body-P107"></a>
## Thuyết định mệnh
Miến / Burmese 107

Người thấy sai có thể hiểu phương pháp tính quy luật ấy một cách sai lầm. Sự thấy sai diễn ra như thế này. Nếu một quả bất kỳ có thể sinh từ một nhân bất kỳ thì chẳng có lý do gì sữa đông và bơ không thể sinh từ nước. Nhưng chúng không thể sinh như vậy. Vì thế, người ấy đi đến chỗ chấp chặt một cách tùy tiện rằng không quả nào có thể sinh từ bất cứ nhân nào, tức chấp thuyết vô nhân.

Do hiểu sai như vậy, người ấy không nắm được rằng quả sinh phù hợp với pháp nhân. Vì không thể nắm và chấp nhận rằng một quả nhất định sinh từ một nhân nhất định, người ấy đã nắm chặt vô nhân kiến hoặc thuyết định mệnh.

Thuyết định mệnh (niyatavāda) là một học thuyết bác bỏ sự hiện hữu của nghiệp và quả của nghiệp, cho rằng các quả tốt xấu của chúng sinh đã được ấn định sẵn. Nếu hỏi lại “Nếu không có nhân như vậy, do nhân nào mà chúng sinh và các vật hiện ra trước mắt lại sinh khởi?”, người theo thuyết vô nhân sẽ nói “Do định mệnh”, tức đã ấn định sẵn rằng đến thời điểm nào sẽ thành người, thành chư thiên hay thành loại súc sinh nào đó. Học thuyết ấy được gọi là thuyết định mệnh. (Xem lời Makkhali Gosāla trong Sāmaññaphalasutta để biết chi tiết.) (Chú giải Abhidhamma, tập 2, tr. 188–189. Visuddhimagga, tập 2, tr. 220–221. Mūlaṭīkā, tập 2, tr. 132. Mahāṭīkā, tập 2, tr. 348.)

Vì vậy, người thiện hãy tự mình, bằng trí tuệ chánh kiến, thấu suốt tính chất duyên khởi, tức mối liên hệ nhân quả…


<a id="M05-body-P108"></a>
## Miến 108
Miến / Burmese 108

…và thấy biết trực tiếp. Hãy trân trọng tiếp nhận và ghi nhớ rằng sự thấy biết trực tiếp ấy là vũ khí tốt nhất để đoạn trừ, phá tan các loại tà thuyết, lời dạy sai lạc và tà kiến.

❂ ❂ ❂


<a id="M05-body-P109"></a>
## Phần 3. Thực hành quán theo phương pháp năm uẩn
Miến / Burmese 109

Điều cần đặc biệt lưu ý

1. Đối tượng của lộ cận tử trong đời trước.
2. Đối tượng của nhóm danh pháp tái tục trong đời hiện tại.
3. Đối tượng của hữu phần trong sáng làm ý môn, tức nhóm danh pháp hữu phần trong đời hiện tại.
4. Đối tượng của nhóm danh pháp tử sẽ sinh trong đời hiện tại.

Cả bốn phải có cùng đối tượng. Vì hành giả chưa quán được tương lai, hãy tự mình dùng tuệ chú tâm so sánh và quán kỹ xem đối tượng của ba mục 1–3 có giống nhau không. Lại nữa, số lượng tâm và tâm sở trong ba loại tâm tái tục, hữu phần và tử phải giống nhau. Hãy chú tâm khảo sát kỹ. Hãy quán đi quán lại. Lúc này hành giả hẳn đã có thể quán hữu phần trong sáng làm ý môn. Nếu chưa thể, hãy quán kỹ lại các danh pháp tái tục. Sau khi danh pháp tái tục đã diệt và trước khi các tâm trong lộ sinh, hãy tiếp tục quán các tâm và tâm sở sinh liên tiếp trong khoảng ấy…


<a id="M05-body-P110"></a>
## Cách nhóm thành năm uẩn
Miến / Burmese 110

…tức các nhóm danh pháp ấy. Để dòng tâm của một đời không gián đoạn, vào lúc các tâm trong lộ không sinh, chính các tâm làm nền cho đời sống tiếp tục sinh. Đó là các tâm hữu phần. Khi đã hiểu, hãy tiếp tục quán những danh pháp hữu phần sinh xen giữa các lộ tâm ngay trong hiện tại. Có thể thành công.

Cách nhóm thành năm uẩn

Khi theo phương pháp thứ năm của duyên khởi để quán các pháp nhân và các pháp quả trong mối liên hệ nhân quả, hãy nhóm thành năm uẩn trong từng nhóm tâm. Theo phương pháp năm uẩn ấy, hãy dùng tuệ thấy mối liên hệ giữa nhân và quả rồi quán các pháp nhân và các pháp quả. Trong khi quán, hãy phân biệt các tâm ngoài lộ với các tâm trong lộ. Tâm tái tục, hữu phần và tử là các tâm ngoài lộ, ở ngoài dòng tâm trong lộ. Với những tâm ngoài lộ ấy cũng hãy nhóm thành năm uẩn, dùng tuệ thấy tính chất liên hệ nhân quả của từng uẩn rồi quán các pháp nhân và các pháp quả. Tương tự, đối với tâm trong lộ, hãy nhóm thành năm uẩn trong từng nhóm tâm, dùng tuệ thấy tính chất liên hệ nhân quả của từng uẩn rồi quán các pháp nhân và các pháp quả. Ở đây “uẩn” có nghĩa là nhóm.

1. Các sắc pháp được xét theo mười một phương diện là quá khứ, tương lai, hiện tại, bên trong, bên ngoài, thô, tế, hạ liệt, cao quý, xa, gần. Chúng làm đối tượng cho các lậu hoặc và là những pháp có thể bị ái và kiến chấp là “tôi, của tôi”…


<a id="M05-body-P111"></a>
## Năm thủ uẩn
Miến / Burmese 111

…Nhóm các sắc pháp ấy gọi là sắc thủ uẩn.

2. Các pháp thọ được xét theo mười một phương diện là quá khứ, tương lai, hiện tại, bên trong, bên ngoài, thô, tế, hạ liệt, cao quý, xa, gần. Chúng làm đối tượng cho các lậu hoặc và có thể bị ái và kiến chấp là “tôi, của tôi”. Nhóm các pháp thọ ấy gọi là thọ thủ uẩn.
3. Quá khứ, pe. Nhóm các pháp tưởng gọi là tưởng thủ uẩn.
4. Quá khứ, pe. Nhóm các tâm sở thuộc hành gọi là hành thủ uẩn.
5. Quá khứ, pe. Nhóm tâm biết, tức các pháp thức, gọi là thức thủ uẩn. (Tương ưng bộ, tập 2, tr. 39, Khandhasutta.)

Trong mười một phương diện ấy, một số từ có nghĩa như sau.
1. Oḷārika: pháp thô.
2. Sukhuma: pháp vi tế.
3. Hīna: pháp hạ liệt.
4. Paṇīta: pháp cao quý.
5. Dūra: pháp xa.
6. Santika: pháp gần.

Hãy ghi nhớ nghĩa của các từ như vậy. Trong từng nhóm tâm, vốn là một phần của mười một phương diện này, có thể kể năm uẩn khi tính cả sắc vật nương và sắc làm cảnh. Trong mỗi nhóm tâm…


<a id="M05-body-P112"></a>
## Năm uẩn ở sát-na tái tục
Miến / Burmese 112

1. Sắc vật nương và sắc làm cảnh gọi là sắc uẩn.
2. Thọ thuộc nhóm tâm ấy gọi là thọ uẩn.
3. Tưởng gọi là tưởng uẩn.
4. Tất cả các tâm sở còn lại ngoài thọ, tưởng và thức gọi là hành uẩn.
5. Tâm biết, tức thức, gọi là thức uẩn.

Trong hành uẩn, số tâm sở còn lại ngoài thọ, tưởng và thức có thể từ 5 đến 32. Dù có bao nhiêu, hãy ghi nhớ rằng toàn bộ nhóm tâm sở còn lại gọi là hành uẩn. Khi hiểu cách phân định năm uẩn như trên, cũng sẽ hiểu cách nhóm thành năm uẩn trong từng nhóm tâm được trình bày tiếp theo. Lại nữa, vì từng uẩn trong năm uẩn ấy có các nhân tương ứng riêng, hãy dùng tuệ thấy mối liên hệ nhân quả giữa các nhân ấy và các quả tương ứng, rồi quán pháp nhân và pháp quả theo mối liên hệ ấy.

Sát-na giọt dịch kalala hình thành — Năm uẩn tái tục

Khi giọt dịch kalala hình thành vào sát-na tái tục: 1. Ba loại nhóm sắc là nhóm mười sắc có ý vật, nhóm mười sắc có thần kinh thân và nhóm mười sắc giới tính, gồm 30 sắc pháp, gọi là sắc uẩn.


<a id="M05-body-P113"></a>
## Miến 113
Miến / Burmese 113

2. Trong 34 danh pháp tái tục, thọ gọi là thọ uẩn.
3. Trong 34 danh pháp tái tục, tưởng gọi là tưởng uẩn.
4. Trong 34 danh pháp tái tục, tư gọi là hành uẩn theo cách thứ nhất. Trong 34 danh pháp tái tục, 31 tâm sở còn lại ngoài thọ, tưởng và thức gọi là hành uẩn theo cách thứ hai.
5. Trong 34 danh pháp tái tục, tâm biết, tức thức, gọi là thức uẩn.

Năm uẩn tái tục nêu trên chỉ áp dụng cho người có ba nhân, tái tục với thọ hỷ. Nếu là người có ba nhân tái tục với thọ xả, do không có hỷ nên có 33 danh pháp. Với người có hai nhân thì lần lượt có 33 hoặc 32 danh pháp. Sở dĩ trình bày hành uẩn theo hai cách là vì trong Khandhavagga của Chánh tạng, khi thuyết hành uẩn theo cách kinh, Đức Phật nêu tư làm chính. Vì thế, cách thứ nhất lấy riêng tư làm chính để trình bày hành uẩn. Mặt khác, nếu chỉ lấy tư làm hành uẩn thì trong một nhóm tâm…

…các tâm sở còn lại ngoài thọ, tưởng và tư sẽ nằm ngoài năm uẩn. Lại có thể hỏi các tâm sở còn lại ấy có các nhân tương ứng hay không. Đặc biệt đối với xúc…


<a id="M05-body-P114"></a>
## Cách quán nhân nối với quả
Miến / Burmese 114

1. Phassasamudayā vedanāsamudayo.
2. Phassasamudayā saññāsamudayo.
3. Phassasamudayā saṅkhārasamudayo. (Tương ưng bộ, tập 2, tr. 51–52.)

Theo những lời dạy này, xúc là nhân của thọ uẩn, tưởng uẩn và hành uẩn. Lại có thể hỏi xúc ấy có nhân hay không. Vì muốn cho biết rằng xúc cùng các tâm sở còn lại đều có các nhân tương ứng, và vì muốn trình bày đầy đủ các pháp chân đế, nên hành uẩn cũng được trình bày theo cách thứ hai. Hãy ghi nhớ tương tự ở những chỗ khác.

Cách quán nhân nối với quả

Trước tiên, trong các nhân quá khứ mà thiện hữu hành thiền đã tự tìm thấy, hãy quán cho hiểu rõ vì sao hai pháp thuộc nghiệp luân, hành và nghiệp, sinh do phiền não luân gồm vô minh, ái và thủ. Sau đó dùng tuệ quán cho thấy sắc uẩn tái tục thuộc quả luân sinh trong mối liên hệ nhân quả do năng lực nghiệp thuộc hành và nghiệp. Khi dùng tuệ thấy nghiệp nhân và sắc do nghiệp sinh lúc tái tục là quả, nói cách khác, thấy hành và nghiệp được vô minh, ái và thủ bao quanh là nhân, còn sắc do nghiệp sinh lúc tái tục là quả, hãy bắt đầu quán các pháp nhân và các pháp quả theo cách sau.


<a id="M05-body-P115"></a>
## Sắc uẩn tái tục
Miến / Burmese 115

1. Do vô minh (20) sinh nên sắc do nghiệp sinh lúc tái tục sinh. Vô minh (20) là pháp nhân. Sắc do nghiệp sinh lúc tái tục là pháp quả.

2. Do ái (20) sinh nên sắc do nghiệp sinh lúc tái tục sinh. Ái (20) là pháp nhân. Sắc do nghiệp sinh lúc tái tục là pháp quả.

3. Do thủ (20) sinh nên sắc do nghiệp sinh lúc tái tục sinh. Thủ (20) là pháp nhân. Sắc do nghiệp sinh lúc tái tục là pháp quả.

4. Do hành (34) sinh nên sắc do nghiệp sinh lúc tái tục sinh. Hành (34) là pháp nhân. Sắc do nghiệp sinh lúc tái tục là pháp quả.

5. Do nghiệp, tức năng lực nghiệp của hành (34) sinh nên sắc do nghiệp sinh lúc tái tục sinh. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Sắc do nghiệp sinh lúc tái tục là pháp quả.

Hãy nối nhân với quả như vậy rồi quán các pháp nhân và các pháp quả. Hãy thực hành quán.

Ghi chú. Số 20 của vô minh, ái và thủ chỉ các danh pháp thuộc nhóm tham và kiến trong mỗi tốc hành tham của lộ ý môn thuộc phiền não luân. Số 34 của hành và nghiệp chỉ 34 danh pháp thuộc nhóm tín và tuệ trong mỗi tốc hành đại thiện của lộ ý môn thuộc nghiệp luân.


<a id="M05-body-P116"></a>
## Miến 116
Miến / Burmese 116

Nếu thiện hữu vun bồi nghiệp với thọ xả, hành và nghiệp ấy đi cùng thọ xả. Vì không có hỷ nên có 33 danh pháp. Những người có thể quán các pháp nhân và quả của danh sắc, phân định bằng tuệ và tu tập quán như vậy nói chung là người có ba nhân. Vì vậy ở đây trình bày người có ba nhân làm mẫu. Đối với người có hai nhân, hãy hiểu là có 33 hoặc 32 danh pháp. Sắc do tâm sinh, do thời tiết sinh và do vật thực sinh chưa sinh ở sát-na sinh của tái tục. Chỉ sắc do nghiệp sinh bắt đầu sinh ở sát-na đó, nên ở đây ưu tiên trình bày cách nối các nhân với riêng sắc do nghiệp sinh và quán các pháp nhân, các pháp quả. Tuy nhiên, từ sát-na trụ của tái tục, hỏa đại, tức thời tiết, trong các sắc do nghiệp sinh đã đến sát-na trụ của sắc và có thể làm sinh các nhóm sắc mới do thời tiết sinh. Từ hữu phần thứ nhất sau tái tục, sắc do tâm sinh bắt đầu sinh. Từ lúc dưỡng chất trong thức ăn người mẹ ăn truyền đến thân của thai nhi, sắc do vật thực sinh bắt đầu sinh. Vì vậy, nếu hướng tuệ đến thời điểm tương ứng thì cũng có thể quán các sắc ấy.

Tương tự, trước hết hãy dùng tuệ quán cho thấy các pháp quả như thọ uẩn và các danh uẩn khác hiện hữu do các pháp nhân tương ứng hiện hữu. Khi chính mình thấy rõ bằng con mắt trí tuệ chánh kiến, hãy quán các pháp nhân và các pháp quả như sau.


<a id="M05-body-P117"></a>
## Thọ uẩn tái tục
Miến / Burmese 117

Năm nhân quá khứ

1. Do vô minh (20) sinh nên thọ uẩn tái tục sinh. Vô minh (20) là pháp nhân. Thọ uẩn tái tục là pháp quả.

2. Do ái (20) sinh nên thọ uẩn tái tục sinh. Ái (20) là pháp nhân. Thọ uẩn tái tục là pháp quả.

3. Do thủ (20) sinh nên thọ uẩn tái tục sinh. Thủ (20) là pháp nhân. Thọ uẩn tái tục là pháp quả.

4. Do hành (34) sinh nên thọ uẩn tái tục sinh. Hành (34) là pháp nhân. Thọ uẩn tái tục là pháp quả.

5. Do nghiệp, tức năng lực nghiệp của hành (34) sinh nên thọ uẩn tái tục sinh. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn tái tục là pháp quả.

Ba nhân hiện tại

6. Do vật, tức sắc ý vật (30), sinh nên thọ uẩn tái tục sinh. Vật, tức sắc ý vật (30), là pháp nhân. Thọ uẩn tái tục là pháp quả.
7. Do cảnh, tức cảnh nghiệp, sinh nên thọ uẩn tái tục sinh.


<a id="M05-body-P118"></a>
## Cách trình bày tóm tắt
Miến / Burmese 118

Cảnh, tức cảnh nghiệp, là pháp nhân. Thọ uẩn tái tục là pháp quả.
8. Do xúc (34 trừ thọ, còn 33) sinh nên thọ uẩn tái tục sinh. Xúc (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn tái tục là pháp quả.

Hãy quán các pháp nhân và pháp quả như vậy. Tuy nhiên, để văn bản gọn, từ đây lược câu “Do vô minh (20) sinh nên thọ uẩn tái tục sinh” và những câu tương tự, chỉ ghi “Vô minh (20) là pháp nhân. Thọ uẩn tái tục là pháp quả”, v.v. Khi thực hành quán các pháp nhân và quả, hãy quán theo cách đầy đủ nêu trên. Để nắm được cách làm, sau đây trình bày lại dưới dạng tóm tắt phép quán sắc uẩn và thọ uẩn đã nêu trên.

Tái tục — Sắc uẩn (sắc do nghiệp sinh, 30)

1. Vô minh (20) là pháp nhân. Sắc uẩn tái tục là pháp quả.

2. Ái (20) là pháp nhân. Sắc uẩn tái tục là pháp quả.

3. Thủ (20) là pháp nhân. Sắc uẩn tái tục là pháp quả.

4. Hành (34) là pháp nhân. Sắc uẩn tái tục là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34), là pháp nhân. Sắc uẩn tái tục…


<a id="M05-body-P119"></a>
## Tái tục — Thọ uẩn
Miến / Burmese 119

…là pháp quả.

Tái tục — Thọ uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Thọ uẩn tái tục là pháp quả.

2. Ái (20) là pháp nhân. Thọ uẩn tái tục là pháp quả.

3. Thủ (20) là pháp nhân. Thọ uẩn tái tục là pháp quả.

4. Hành (34) là pháp nhân. Thọ uẩn tái tục là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn tái tục là pháp quả.

Ba nhân hiện tại

6. Vật, tức sắc ý vật (30), là pháp nhân. Thọ uẩn tái tục là pháp quả.
7. Cảnh là pháp nhân. Thọ uẩn tái tục là pháp quả.
8. Xúc (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn tái tục là pháp quả.

Giải thích

1. Vật. Trong cõi có năm uẩn, các danh pháp chỉ có khả năng sinh khi có sắc vật nương. Nếu không có sắc vật nương…


<a id="M05-body-P120"></a>
## Miến 120
Miến / Burmese 120

…các danh pháp không có khả năng sinh. Vào sát-na tái tục, các danh pháp tái tục, gồm thọ uẩn tái tục, chỉ có thể sinh nương vào sắc ý vật sinh cùng với chúng. Nếu không có chỗ nương, chúng không thể sinh. Mặt khác, sắc ý vật cũng không thể sinh riêng lẻ, chỉ có thể sinh trong một nhóm sắc. Đặc biệt, nó chỉ có thể sinh khi nương vào bốn đại cùng nhóm, có khả năng trợ cho nó bằng các duyên như câu sinh. Nếu không có chỗ nương ấy thì nó không thể sinh. Hơn nữa, nhóm mười sắc có ý vật ở sát-na tái tục chỉ có thể sinh cùng với nhóm mười sắc có thần kinh thân và nhóm mười sắc giới tính. Vì thế, theo phương pháp kinh…

Vatthu nāma karajakāyo, pe. So atthato bhūtāni ceva upādārūpāni ca. (Chú giải Majjhima, tập 1, tr. 281.)

Nāmarūpavavatthānassa adhippetattā niravasesarūpapariggahassa dassanatthaṃ “vatthu nāma karajakāyo”ti āha. Na cakkhādīni chavatthūnīti. Karajakāyassa pana vatthubhāvasādhanatthaṃ “idañca pana me viññāṇaṃ ettha sitaṃ, ettha paṭibaddhan”ti suttaṃ ābhataṃ. (Mūlaṭīkā, tập 2, tr. 157.)

Vật là thân do vật chất tạo thành (karajakāya), pe. Xét theo pháp chân đế, thân ấy là các sắc đại chủng và sắc y sinh. (Chú giải Majjhima, tập 1, tr. 281.)

Theo các giải thích của Chú giải và Phụ chú giải, khi lấy sắc vật làm đối tượng thì cần tính cả các sắc đại chủng và sắc y sinh. Hãy quán và tu tập để phá khối do tập hợp của sắc và để tuệ thấy đến sắc chân đế. Vì vậy, sắc vật nương của thọ uẩn tái tục…


<a id="M05-body-P121"></a>
## Vật và cảnh
Miến / Burmese 121

…theo phương pháp Abhidhamma, chỉ nương vào một loại sắc là sắc ý vật, nên chỉ kể riêng sắc ý vật. Theo phương pháp kinh, phải kể làm sắc vật cả 30 sắc pháp cùng với sắc ý vật. Phương pháp kinh là phương pháp thực hành. Để phá khối và để tuệ thấy đến chân đế, hãy ưu tiên quán cả 30 sắc. Vì vậy, theo phương pháp kinh, hãy ghi nhớ rằng cả 30 sắc pháp cùng với sắc ý vật đều gọi là sắc vật. Hãy tự mình dùng con mắt trí tuệ chánh kiến quán cho thấy thọ uẩn tái tục chỉ có thể sinh khi có sắc vật ấy làm chỗ nương, rồi quán pháp nhân và pháp quả. Hãy ghi nhớ tương tự ở mọi chỗ. Theo lời giải thích ấy, hãy quán như sau.

Do vật, tức ý vật (30), sinh nên thọ uẩn tái tục sinh. Vật, tức ý vật (30), là pháp nhân. Thọ uẩn tái tục là pháp quả.

2. Cảnh. Đã giải thích rằng cảnh của danh pháp tái tục chính là cảnh của lộ cận tử đời trước. Thọ cảm nhận vị của cảnh ấy. Hãy dùng tuệ quán cho thấy và hiểu rõ rằng nếu không có cảnh để cảm nhận thì thọ không thể sinh. Trong ví dụ trên, cảnh dâng vật thực cúng dường Đức Phật chỉ được nêu làm mẫu để dễ hiểu. Nghiệp của các hành giả phần nhiều khác nhau. Với một số người, nghiệp bố thí đang cho quả. Với một số người, nghiệp trì giới đang cho quả. Với một số người…


<a id="M05-body-P122"></a>
## Cảnh và xúc
Miến / Burmese 122

…nghiệp tu tập đang cho quả. Trong nghiệp bố thí cũng có nhiều loại, như nghiệp dâng vật thực, nghiệp dâng y, v.v. Nghiệp trì giới cũng có nhiều loại, như giữ năm giới, tám giới, mười giới, v.v. Nghiệp tu tập cũng có nhiều loại, như tu kasiṇa, bất tịnh, niệm hơi thở, tâm từ và minh sát. Vì có thể có nhiều loại nghiệp như vậy, cảnh của lộ cận tử đời trước và cảnh của tái tục, hữu phần và tử trong đời hiện tại cũng có thể có nhiều loại. Sau khi dùng trí tuệ chánh kiến quán cho rõ cảnh của lộ cận tử đời trước và cảnh tái tục đời hiện tại, hãy dùng tuệ thấy rằng chỉ khi có cảnh để cảm nhận thì thọ mới sinh ở sát-na tái tục. Hãy quán pháp nhân và pháp quả như sau.

Do cảnh, tức cảnh nghiệp, sinh nên thọ uẩn tái tục sinh. Cảnh, tức cảnh nghiệp, là pháp nhân. Thọ uẩn tái tục là pháp quả.

3. Xúc. Phassasamudayā vedanāsamudayo: do xúc sinh nên thọ sinh. Hãy ghi nhớ rằng lời dạy này lấy xúc làm chính. Trong lời dạy Paṭṭhāna có nói như sau.

Cattāro khandhā arūpino aññamaññaṃ sahajātapaccayena paccayo. Cattāro khandhā arūpino aññamaññaṃ nissayapaccayena paccayo. (Paṭṭhāna, tập 1, tr. 5.)

Bốn danh uẩn trợ lẫn nhau bằng năng lực của duyên câu sinh và duyên y chỉ. (Paṭṭhāna, tập 1, tr. 5.) Lời dạy đầy đủ theo cách ấy. Các danh pháp nương nhau và trợ nhau như…


<a id="M05-body-P123"></a>
## Miến 123
Miến / Burmese 123

…“cù lao nương bãi bồi, bãi bồi nương cù lao”. Khi ăn một món, nhai kỹ thì nước vị tiết ra nhiều hơn và vị được cảm nhận rõ hơn. Cũng vậy, trong các danh pháp cùng sinh trong một nhóm tâm hay trong các danh pháp ở những nhóm tâm khác nhau, khi xúc tiếp cận cảnh, kết nối tâm biết với cảnh và chạm đến cảnh, thì vị của cảnh có thể được cảm nhận rõ hơn trong sự cảm nhận của thọ. Vì vậy lời dạy “do xúc nên thọ sinh” lấy xúc làm chính. Tuy vậy, một mình xúc không có khả năng sinh. Chỉ khi được các pháp tương ưng khác trợ bằng năng lực của các duyên như câu sinh và y chỉ, xúc mới có thể sinh cùng các pháp tương ưng ấy. Do đó, khi nói “do xúc”, hãy ghi nhớ rằng các pháp tương ưng khác cũng được kể vào.

Điểm cần ghi nhớ. Trong các pháp tương ưng có trong một nhóm tâm, khi một danh pháp là pháp quả, tức khi lấy một danh pháp làm quả mà quán, các danh pháp còn lại là pháp nhân. Hãy ghi nhớ điểm thiết yếu này. Có thể hiểu các danh uẩn còn lại bằng cách lấy thọ uẩn này làm mẫu. Cách các danh pháp trợ nhau giữa các nhóm tâm sẽ được nêu ở phần sau. Hành giả hãy dùng tuệ thấy cách các danh pháp trợ lẫn nhau. Nói cách khác, hãy thấy cách nhiều danh pháp như xúc trợ cho thọ, hay cách ba danh uẩn là tưởng uẩn, hành uẩn và thức uẩn trợ cho thọ uẩn bằng các duyên câu sinh…


<a id="M05-body-P124"></a>
## Tái tục — Tưởng uẩn
Miến / Burmese 124

…hỗ tương, y chỉ, v.v. Hãy dùng tuệ thấy cách các pháp ấy trợ nhau, nương nhau và liên hệ với nhau theo nhân quả. Hãy quán. Khi đã thấy bằng tuệ, hãy quán các pháp nhân và pháp quả như sau.

Do xúc (34 trừ thọ, còn 33) sinh nên thọ uẩn sinh. Xúc (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn là pháp quả.

Tái tục — Tưởng uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

2. Ái (20) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

3. Thủ (20) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

4. Hành (34) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

Ba nhân hiện tại

6. Vật (3 nhóm, 30 sắc) là pháp nhân. Tưởng uẩn tái tục là pháp quả.


<a id="M05-body-P125"></a>
## Tái tục — Hành uẩn, cách thứ nhất
Miến / Burmese 125

7. Cảnh (cảnh nghiệp) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

8. Xúc (34 trừ tưởng, còn 33) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

Tái tục — Hành uẩn (cách thứ nhất, lấy tư làm chính)

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Hành uẩn là pháp quả.

2. Ái (20) là pháp nhân. Hành uẩn là pháp quả.

3. Thủ (20) là pháp nhân. Hành uẩn là pháp quả.

4. Hành (34) là pháp nhân. Hành uẩn là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Hành uẩn là pháp quả.

Ba nhân hiện tại

6. Vật (3 nhóm, 30 sắc) là pháp nhân. Hành uẩn là pháp quả.

7. Cảnh (cảnh nghiệp) là pháp nhân. Hành uẩn là pháp quả.

8. Xúc (34 trừ tư, còn 33) là pháp nhân. Hành uẩn là pháp quả.

Ở đây, cách thứ nhất là cách lấy riêng tư làm chính khi nói đến hành uẩn. Để trình bày đầy đủ các pháp chân đế, xin nêu thêm một cách nữa.


<a id="M05-body-P126"></a>
## Tái tục — Hành uẩn, cách thứ hai
Miến / Burmese 126

Tái tục — Hành uẩn (cách thứ hai, kể 31 tâm sở)

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Hành uẩn là pháp quả.

2. Ái (20) là pháp nhân. Hành uẩn là pháp quả.

3. Thủ (20) là pháp nhân. Hành uẩn là pháp quả.

4. Hành (34) là pháp nhân. Hành uẩn là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Hành uẩn là pháp quả.

Ba nhân hiện tại

6. Vật (3 nhóm, 30 sắc) là pháp nhân. Hành uẩn là pháp quả.

7. Cảnh (cảnh nghiệp) là pháp nhân. Hành uẩn là pháp quả.

8. Ba danh uẩn còn lại là pháp nhân. Hành uẩn là pháp quả.

Ghi chú. Trong 34 danh pháp tái tục, trừ thọ, tưởng và thức, còn 31 tâm sở, do xúc và tư dẫn đầu. Theo cách thứ hai này, cả 31 tâm sở đều được gọi là hành uẩn và đứng về phía quả. Khi tìm các nhân hiện tại của hành uẩn do xúc và tư dẫn đầu, theo câu “Sesakkhandhā paccayā” (Visuddhimagga, tập 2, tr. 92), ba danh uẩn còn lại là thọ, tưởng và thức là các nhân. Chúng là các duyên gần nhất. Khi trình bày phép quán theo cách thứ hai này…


<a id="M05-body-P127"></a>
## Tái tục — Thức uẩn
Miến / Burmese 127

…vì có thể hỏi rằng nếu xúc là nhân của các danh uẩn thì chính xúc hoặc nhóm tâm sở còn lại gọi là hành uẩn có nhân hay không. Mục đích là quán cho đầy đủ các pháp nhân và pháp quả. Khi về sau trình bày phép quán hành uẩn theo hai cách, hãy ghi nhớ nguyên tắc tương tự.

Tái tục — Thức uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Thức uẩn tái tục là pháp quả.

2. Ái (20) là pháp nhân. Thức uẩn tái tục là pháp quả.

3. Thủ (20) là pháp nhân. Thức uẩn tái tục là pháp quả.

4. Hành (34) là pháp nhân. Thức uẩn tái tục là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thức uẩn tái tục là pháp quả.

Một nhân hiện tại

6. Danh và sắc là pháp nhân. Thức uẩn tái tục là pháp quả.

Danh là 33 tâm sở tương ưng. Sắc là sắc vật nương (3 nhóm, 30 sắc) và sắc làm cảnh.


<a id="M05-body-P128"></a>
## Miến 128
Miến / Burmese 128

Ghi chú. “Danh” là nhóm tâm sở tương ưng sinh cùng thức uẩn trong một nhóm tâm. Ở sát-na tái tục này, từ ấy chỉ 33 tâm sở tương ưng sinh cùng thức tái tục. Nếu thiện hữu tái tục với thọ xả, do không tương ưng với hỷ nên có 32 tâm sở được kể là danh pháp. “Sắc” là sắc vật nương và sắc làm cảnh. Trong ba loại cảnh của nhóm danh pháp tái tục là nghiệp, nghiệp tướng và thú tướng, khi cảnh thuộc loại sắc thì sắc làm cảnh là sắc ấy. Khi cảnh là tiếng, sắc làm cảnh là tiếng ấy. Hãy hiểu tương tự trong các trường hợp khác. Lại nữa, có lời dạy “Nāmarūpasamudayā viññāṇasamudayo” (Tương ưng bộ, tập 2, tr. 53), nghĩa là do danh sắc sinh nên thức sinh. Cũng có lời dạy “Viññāṇapaccayā nāmarūpaṃ” (Abhidhamma, tập 2, tr. 142), nghĩa là do thức làm duyên nên danh sắc sinh. Vì vậy, hãy ghi nhớ rằng thức và danh sắc là các pháp trợ lẫn nhau. Hành giả cần dùng tuệ thấy quan hệ nhân quả, thấy thức, tức thức uẩn, sinh do danh sắc, rồi quán các pháp nhân và pháp quả. Qua các lời giải thích này, hãy hiểu rằng các nhân được gọi là “vật, cảnh và xúc” và nhân được gọi là “danh sắc” chỉ khác nhau về cách nói, còn xét theo các pháp chân đế và tự tính thì giống nhau. Phép quán như sau.

Do danh sắc sinh nên thức uẩn tái tục sinh. Danh sắc là pháp nhân. Thức uẩn tái tục là pháp quả…


<a id="M05-body-P129"></a>
## Năm uẩn hữu phần
Miến / Burmese 129

Sau tái tục, hữu phần sinh 15 hoặc 16 lần. Sau những hữu phần ấy, các tâm trong lộ bắt đầu sinh, gồm một tâm hướng ý môn và bảy tốc hành tham có chức năng ưa thích hữu, tức các tốc hành tham đắm đời sống mới. Trong các tâm hữu phần, kể từ hữu phần đầu tiên, sắc do tâm sinh và sắc do thời tiết sinh xuất hiện. Vì sắc do thời tiết sinh bắt đầu từ sát-na trụ của tái tục, nó đương nhiên cũng có trong thời gian này. Sắc do vật thực sinh xuất hiện từ khi thức ăn do người mẹ ăn truyền vào thân của thai nhi. Do đó nếu muốn quán năm uẩn hữu phần ngay sau tái tục theo nhân quả, hãy quán theo phép quán năm uẩn hữu phần sẽ trình bày dưới đây, bỏ sắc do vật thực sinh. Hãy quán tâm hướng ý môn trong lộ tốc hành tham có chức năng ưa thích hữu theo phép quán năm uẩn của tâm hướng ý môn sẽ trình bày sau. Hãy quán năm uẩn trong các tốc hành tham có chức năng ưa thích hữu theo phép quán các tốc hành tham trong lộ ý môn sẽ trình bày sau. Bây giờ sẽ trình bày phép quán năm uẩn hữu phần đang sinh trong dòng tương tục của thiện hữu.

Năm uẩn hữu phần

1. Sáu nhóm sắc tại ý vật, chỗ nương của hữu phần hiện tại, gồm 54 sắc pháp, là sắc uẩn. Nếu cảnh của hữu phần là sắc pháp, hãy kể cả sắc pháp ấy.
2. Trong 34 danh pháp hữu phần, thọ gọi là thọ uẩn.


<a id="M05-body-P130"></a>
## Hữu phần — Sắc uẩn
Miến / Burmese 130

3. Trong 34 danh pháp hữu phần, tưởng gọi là tưởng uẩn.
4. Trong 34 danh pháp hữu phần, tư gọi là hành uẩn theo cách thứ nhất. Theo cách thứ hai, 31 tâm sở còn lại gọi là hành uẩn.
5. Trong 34 danh pháp hữu phần, tâm biết, tức thức, gọi là thức uẩn.

Hữu phần — Sắc uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Sắc uẩn hữu phần (sắc do nghiệp sinh) là pháp quả.

2. Ái (20) là pháp nhân. Sắc uẩn hữu phần (sắc do nghiệp sinh) là pháp quả.

3. Thủ (20) là pháp nhân. Sắc uẩn hữu phần (sắc do nghiệp sinh) là pháp quả.

4. Hành (34) là pháp nhân. Sắc uẩn hữu phần (sắc do nghiệp sinh) là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Sắc uẩn hữu phần (sắc do nghiệp sinh) là pháp quả.

Ba nhân hiện tại

6. Tâm là pháp nhân. Sắc uẩn hữu phần (sắc do tâm sinh) là pháp quả.


<a id="M05-body-P131"></a>
## Hữu phần — Thọ uẩn
Miến / Burmese 131

7. Thời tiết là pháp nhân. Sắc uẩn hữu phần (sắc do thời tiết sinh) là pháp quả.

8. Vật thực là pháp nhân. Sắc uẩn hữu phần (sắc do vật thực sinh) là pháp quả.

Hữu phần — Thọ uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

2. Ái (20) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

3. Thủ (20) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

4. Hành (34) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

Ba nhân hiện tại

6. Vật (6 nhóm, 54 sắc) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

7. Cảnh (cảnh nghiệp) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

8. Xúc.

(a) Ý xúc của hữu phần trước (34) là pháp nhân. Thọ uẩn hữu phần là pháp quả.


<a id="M05-body-P132"></a>
## Hữu phần — Tưởng uẩn và hành uẩn
Miến / Burmese 132

(b) Ý xúc của hữu phần sau (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

Ghi chú. Ý xúc của hữu phần trước (34) thuộc sát-na hữu phần ngay trước hữu phần đang được quán. Đó là nhân theo duyên vô gián. Ý xúc của hữu phần sau thuộc chính hữu phần đang được quán. Khi thọ uẩn đứng về phía quả thì trừ thọ ấy, còn 34 trừ thọ, tức 33. Hãy ghi nhớ tương tự đối với tưởng uẩn hữu phần, v.v.

Hữu phần — Tưởng uẩn

1–7. Hoàn toàn giống như đối với thọ uẩn.
8. Xúc.

(a) Ý xúc của hữu phần trước (34) là pháp nhân. Tưởng uẩn hữu phần là pháp quả.

(b) Ý xúc của hữu phần sau (34 trừ tưởng, còn 33) là pháp nhân. Tưởng uẩn hữu phần là pháp quả.

Hữu phần — Hành uẩn (tư, cách thứ nhất)

1–7. Hoàn toàn giống như đối với thọ uẩn.
8. Xúc.

(a) Ý xúc của hữu phần trước (34) là pháp nhân. Hành uẩn hữu phần là pháp quả.

(b) Ý xúc của hữu phần sau (34 trừ tư, còn 33) là pháp nhân. Hành uẩn hữu phần là pháp quả.


<a id="M05-body-P133"></a>
## Hữu phần — Hành uẩn và thức uẩn
Miến / Burmese 133

Hữu phần — Hành uẩn (kể 31 tâm sở, cách thứ hai)

1–7. Hoàn toàn giống như đối với thọ uẩn.
8. Xúc.

(a) Ý xúc của hữu phần trước (34) là pháp nhân. Hành uẩn hữu phần là pháp quả.

(b) Ba danh uẩn còn lại là pháp nhân. Hành uẩn hữu phần là pháp quả.

Hữu phần — Thức uẩn

1–5. Năm nhân quá khứ giống như đối với thọ uẩn.

Hai nhân hiện tại

6. Ý xúc của hữu phần trước (34) là pháp nhân. Thức uẩn hữu phần là pháp quả.

7. Danh và sắc là pháp nhân. Thức uẩn hữu phần là pháp quả.

Danh là 33 tâm sở tương ưng. Sắc là sắc vật nương và sắc làm cảnh.

Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tâm hướng ngũ môn

1. 54 sắc pháp ở ý vật, chỗ nương của tâm hướng ngũ môn, và cảnh sắc là sắc uẩn.
2. Thọ trong 11 danh pháp của tâm hướng ngũ môn là thọ uẩn.
3. Tưởng trong 11 danh pháp của tâm hướng ngũ môn là tưởng uẩn.


<a id="M05-body-P134"></a>
## Hướng ngũ môn — Sắc uẩn
Miến / Burmese 134

4. Tư trong 11 danh pháp của tâm hướng ngũ môn là hành uẩn theo cách thứ nhất. Tám tâm sở còn lại trong 11 danh pháp của tâm hướng ngũ môn là hành uẩn theo cách thứ hai.
5. Tâm biết, tức thức, trong 11 danh pháp của tâm hướng ngũ môn là thức uẩn.

Hướng ngũ môn, tức hướng đến cảnh — Sắc uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

2. Ái (20) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

3. Thủ (20) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

4. Hành (34) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

Ba nhân hiện tại

6. Tâm là pháp nhân. Sắc uẩn do tâm sinh là pháp quả.

7. Thời tiết là pháp nhân. Sắc uẩn do thời tiết sinh là pháp quả.

8. Vật thực là pháp nhân. Sắc uẩn do vật thực sinh là pháp quả.


<a id="M05-body-P135"></a>
## Hướng ngũ môn — Thọ uẩn và tưởng uẩn
Miến / Burmese 135

Hướng ngũ môn — Thọ uẩn

Ba nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

3. Xúc.

(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

(b) Ý xúc của tâm hướng ngũ môn (11 trừ thọ, còn 10) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

Hướng ngũ môn — Tưởng uẩn

Ba nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Tưởng uẩn của tâm hướng ngũ môn là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Tưởng uẩn của tâm hướng ngũ môn là pháp quả.

3. Xúc.

(a) Ý xúc của hữu phần (34) là pháp nhân. Tưởng uẩn của tâm hướng ngũ môn là pháp quả.

(b) Ý xúc của tâm hướng ngũ môn (11 trừ tưởng, còn 10) là pháp…


<a id="M05-body-P136"></a>
## Hướng ngũ môn — Hành uẩn
Miến / Burmese 136

…nhân. Tưởng uẩn của tâm hướng ngũ môn là pháp quả.

Hướng ngũ môn — Hành uẩn (tư, cách thứ nhất)

Ba nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

3. Xúc.

(a) Ý xúc của hữu phần (34) là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

(b) Ý xúc của tâm hướng ngũ môn (11 trừ tư, còn 10) là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

Hướng ngũ môn — Hành uẩn (tám tâm sở, cách thứ hai)

Ba nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

3. Xúc.

(a) Ý xúc của hữu phần (34) là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.


<a id="M05-body-P137"></a>
## Hướng ngũ môn — Thức uẩn
Miến / Burmese 137

(b) Ba danh uẩn còn lại là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

Hướng ngũ môn — Thức uẩn

Hai nhân hiện tại

1. Ý xúc của hữu phần (34) là pháp nhân. Thức uẩn của tâm hướng ngũ môn là pháp quả.

2. Danh và sắc là pháp nhân. Thức uẩn của tâm hướng ngũ môn là pháp quả.

Danh là 10 tâm sở tương ưng. Sắc là ý vật (54 sắc) và cảnh sắc.

Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở nhãn thức, tức sự thấy

1. Nhãn vật (sáu nhóm sắc làm chỗ nương, gồm 54 sắc) và cảnh sắc là sắc uẩn.
2. Thọ trong tám danh pháp nhãn thức là thọ uẩn.
3. Tưởng trong tám danh pháp nhãn thức là tưởng uẩn.
4. Tư trong tám danh pháp nhãn thức là hành uẩn theo cách thứ nhất. Năm tâm sở còn lại trong tám danh pháp nhãn thức là hành uẩn theo cách thứ hai.
5. Tâm biết, tức thức, trong tám danh pháp nhãn thức là thức uẩn.


<a id="M05-body-P138"></a>
## Nhãn thức — Sắc uẩn và thọ uẩn
Miến / Burmese 138

Nhãn thức, tức sự thấy — Sắc uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

2. Ái (20) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

3. Thủ (20) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

4. Hành (34) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

Ba nhân hiện tại

6. Tâm là pháp nhân. Sắc uẩn do tâm sinh là pháp quả.

7. Thời tiết là pháp nhân. Sắc uẩn do thời tiết sinh là pháp quả.

8. Vật thực là pháp nhân. Sắc uẩn do vật thực sinh là pháp quả.

Nhãn thức, tức sự thấy — Thọ uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

2. Ái (20) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.


<a id="M05-body-P139"></a>
## Nhãn thức — Các nhân của thọ uẩn
Miến / Burmese 139

3. Thủ (20) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

4. Hành (34) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

Năm nhân hiện tại

6. Vật, tức nhãn vật (54 sắc) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

7. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

8. Nhãn xúc (8 trừ thọ, còn 7) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

9. Ánh sáng là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

10. Tác ý, tức tâm hướng ngũ môn (11) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

Tác ý (manasikāra). Ở đây, tác ý là sự hướng tâm đến cảnh, tức cảnh sắc, và chính là tâm hướng ngũ môn. Các vị luận sư gọi đó là tác ý dẫn đầu lộ tâm (vīthipaṭipādakamanasikāra). (Chú giải Abhidhamma, tập 1, tr. 177.) Đó là nhân căn bản của các tâm trong lộ, hướng đến cảnh để các tâm ấy sinh khởi.

Ánh sáng (āloka). Ánh sáng gồm (1) ánh trăng, (2) ánh mặt trời, (3) ánh lửa và (4) ánh sáng của tuệ, như được nêu trong…


<a id="M05-body-P140"></a>
## Nhãn thức — Ánh sáng và tưởng uẩn
Miến / Burmese 140

…Ābhāsutta thuộc Phẩm Bốn pháp của Chánh tạng và các bài kinh tương tự. Cả bốn loại ánh sáng đều được gọi là ánh sáng ở đây. Khi ngồi nhắm mắt và tác ý đến Pháp như lúc này, ánh sáng của tuệ đặc biệt quan trọng. Nếu không có ánh sáng của tuệ thì không thể thấy các nhóm sắc, màu của các nhóm sắc, các sắc chân đế và các danh pháp chân đế. Khi tuệ minh sát chưa sinh, hoặc khi chưa tác ý đến sự tu tập thiền chỉ và minh sát mạnh mẽ mà chỉ thấy cảnh sắc bằng mắt thịt thông thường, một trong ba thứ ánh sáng là ánh trăng, ánh mặt trời hoặc ánh lửa là nhân của các danh pháp nhãn thức. Chú giải Aṭṭhasālinī nêu bốn nhân của nhãn thức. (Chú giải Abhidhamma, tập 1, tr. 321.) Ở đó không kể thêm nhãn xúc làm nhân. Tuy nhiên, theo lời dạy “Phassasamudayā vedanāsamudayo”, nghĩa là do xúc sinh nên thọ sinh (Tương ưng bộ, tập 2, tr. 49), ở đây kể thêm nhãn xúc và nêu năm nhân hiện tại.

Nhãn thức, tức sự thấy — Tưởng uẩn

1–7, 9–10. Các nhân giống như đối với thọ uẩn.

8. Nhãn xúc (8 trừ tưởng, còn 7) là pháp nhân. Tưởng uẩn của nhãn thức là pháp quả.


<a id="M05-body-P141"></a>
## Nhãn thức — Hành uẩn và thức uẩn
Miến / Burmese 141

Nhãn thức, tức sự thấy — Hành uẩn (tư, cách thứ nhất)

1–7, 9–10. Các nhân giống như đối với thọ uẩn.

8. Nhãn xúc (8 trừ tư, còn 7) là pháp nhân. Hành uẩn của nhãn thức là pháp quả.

Nhãn thức, tức sự thấy — Hành uẩn (kể năm tâm sở, cách thứ hai)

1–7, 9–10. Các nhân giống như đối với thọ uẩn.

8. Ba danh uẩn còn lại là pháp nhân. Hành uẩn của nhãn thức là pháp quả.

Nhãn thức, tức sự thấy — Thức uẩn

1–5. Các nhân quá khứ giống như đối với thọ uẩn.

Ba nhân hiện tại

6. Danh và sắc là pháp nhân. Thức uẩn của nhãn thức là pháp quả.

7. Ánh sáng là pháp nhân. Thức uẩn của nhãn thức là pháp quả.

8. Tác ý, tức tâm hướng ngũ môn (11) là pháp nhân. Thức uẩn của nhãn thức là pháp quả.

Danh là bảy tâm sở tương ưng.


<a id="M05-body-P142"></a>
## Năm uẩn ở tâm tiếp thọ
Miến / Burmese 142

Sắc là sắc vật nương (54 sắc) và cảnh sắc. Trong bảy tâm sở tương ưng có xúc.

Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tâm tiếp thọ (sampaṭicchana)

1. 54 sắc pháp gồm sắc ý vật, chỗ nương của tâm tiếp thọ, và các sắc cùng với nó, cùng cảnh sắc, là sắc uẩn.

2. Thọ trong 11 danh pháp của tâm tiếp thọ là thọ uẩn.

3. Tưởng trong 11 danh pháp của tâm tiếp thọ là tưởng uẩn.

4. Tư trong 11 danh pháp của tâm tiếp thọ là hành uẩn theo cách thứ nhất. 8 tâm sở còn lại trong 11 danh pháp ấy là hành uẩn theo cách thứ hai.

5. Tâm biết, tức thức, trong 11 danh pháp của tâm tiếp thọ là thức uẩn.

Hãy quán sắc uẩn của tâm tiếp thọ theo cách quán sắc uẩn của tâm hướng ngũ môn.

Tiếp thọ — Thọ uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

2. Ái (20) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

3. Thủ (20) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.


<a id="M05-body-P143"></a>
## Tiếp thọ — Thọ uẩn, tưởng uẩn và hành uẩn
Miến / Burmese 143

4. Hành (34) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

Ba nhân hiện tại

6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

7. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

8(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

(b) Ý xúc của tâm tiếp thọ (10, tức 11 trừ thọ) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

Tiếp thọ — Tưởng uẩn

1–7. Hãy quán tương tự như đối với thọ uẩn.

8(a) Nhãn xúc (8) là pháp nhân. Tưởng uẩn của tâm tiếp thọ là pháp quả.

(b) Ý xúc của tâm tiếp thọ (10, tức 11 trừ tưởng) là pháp nhân. Tưởng uẩn của tâm tiếp thọ là pháp quả.

Tiếp thọ — Hành uẩn (tư, cách thứ nhất)

1–7. Hãy quán tương tự như đối với thọ uẩn.


<a id="M05-body-P144"></a>
## Tiếp thọ — Hành uẩn và thức uẩn
Miến / Burmese 144

8(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tâm tiếp thọ là pháp quả.

(b) Ý xúc của tâm tiếp thọ (10, tức 11 trừ tư) là pháp nhân. Hành uẩn của tâm tiếp thọ là pháp quả.

Tiếp thọ — Hành uẩn (tám tâm sở, cách thứ hai)

1–7. Hãy quán tương tự như đối với thọ uẩn.

8(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tâm tiếp thọ là pháp quả.

(b) Ba danh uẩn còn lại là pháp nhân. Hành uẩn của tâm tiếp thọ là pháp quả.

Tiếp thọ — Thức uẩn

1–5. Hãy quán các nhân quá khứ như đối với thọ uẩn.

6. Nhãn xúc (8) là pháp nhân. Thức uẩn của tâm tiếp thọ là pháp quả.

7. Danh và sắc ở tâm tiếp thọ là pháp nhân. Thức uẩn của tâm tiếp thọ là pháp quả.

Danh là mười tâm sở tương ưng với tâm tiếp thọ. Sắc là 54 sắc pháp gồm sắc ý vật và các sắc cùng với nó, cùng cảnh sắc.


<a id="M05-body-P145"></a>
## Năm uẩn ở tâm suy đạc
Miến / Burmese 145

Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tâm suy đạc (santīraṇa)

1. 54 sắc pháp gồm sắc ý vật, chỗ nương của tâm suy đạc, và các sắc cùng với nó, cùng cảnh sắc, là sắc uẩn.

2. Thọ trong 12 danh pháp của tâm suy đạc là thọ uẩn.

3. Tưởng trong 12 danh pháp của tâm suy đạc là tưởng uẩn.

4. Tư trong 12 danh pháp của tâm suy đạc là hành uẩn theo cách thứ nhất. 9 tâm sở còn lại trong 12 danh pháp ấy là hành uẩn theo cách thứ hai.

5. Tâm biết, tức thức, trong 12 danh pháp của tâm suy đạc là thức uẩn.

Ghi chú. Tâm suy đạc tương ưng với thọ hỷ có 12 danh pháp và có hỷ. Nếu tương ưng với thọ xả thì có 11 danh pháp và không có hỷ. Nếu tốc hành có hỷ thì tâm suy đạc cũng có thể có hỷ. Hãy quán sắc uẩn của tâm suy đạc theo cách quán sắc uẩn của tâm hướng ngũ môn.

Suy đạc — Thọ uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

2. Ái (20) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

3. Thủ (20) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.


<a id="M05-body-P146"></a>
## Suy đạc — Thọ uẩn và tưởng uẩn
Miến / Burmese 146

4. Hành (34) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

Ba nhân hiện tại

6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

7. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

8(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

(b) Ý xúc của tâm tiếp thọ (11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

(c) Ý xúc của tâm suy đạc (11, tức 12 trừ thọ) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

Suy đạc — Tưởng uẩn

1–7. Hoàn toàn giống như đối với thọ uẩn.

8(a) Nhãn xúc (8) là pháp nhân. Tưởng uẩn của tâm suy đạc là pháp quả.

(b) Ý xúc của tâm tiếp thọ (11) là pháp nhân. Tưởng uẩn của tâm suy đạc là pháp quả.


<a id="M05-body-P147"></a>
## Suy đạc — Hành uẩn
Miến / Burmese 147

(c) Ý xúc của tâm suy đạc (11 hoặc 10, tức 12 trừ tưởng còn 11, hoặc 11 trừ tưởng còn 10) là pháp nhân. Tưởng uẩn của tâm suy đạc là pháp quả.

Suy đạc — Hành uẩn (tư, cách thứ nhất)

1–7. Hoàn toàn giống như đối với thọ uẩn.

8(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tâm suy đạc là pháp quả.

(b) Ý xúc của tâm tiếp thọ (11) là pháp nhân. Hành uẩn của tâm suy đạc là pháp quả.

(c) Ý xúc của tâm suy đạc (11 hoặc 10, tức 12 trừ tư còn 11, hoặc 11 trừ tư còn 10) là pháp nhân. Hành uẩn của tâm suy đạc là pháp quả.

Suy đạc — Hành uẩn (chín hoặc tám tâm sở, cách thứ hai)

1–7. Hoàn toàn giống như đối với thọ uẩn.

8(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tâm suy đạc là pháp quả.

(b) Ý xúc của tâm tiếp thọ (11) là pháp nhân. Hành uẩn của tâm suy đạc là pháp quả.

(c) Ba danh uẩn còn lại là pháp nhân. Hành uẩn của tâm suy đạc là pháp quả.


<a id="M05-body-P148"></a>
## Suy đạc — Thức uẩn và năm uẩn ở tâm xác định
Miến / Burmese 148

Suy đạc — Thức uẩn

1–5. Hoàn toàn giống như đối với thọ uẩn.

6(a) Nhãn xúc (8) là pháp nhân. Thức uẩn của tâm suy đạc là pháp quả.

(b) Ý xúc của tâm tiếp thọ (11) là pháp nhân. Thức uẩn của tâm suy đạc là pháp quả.

7. Danh và sắc ở tâm suy đạc là pháp nhân. Thức uẩn của tâm suy đạc là pháp quả.

Danh là các tâm sở tương ưng, 11 nếu có thọ hỷ, 10 nếu có thọ xả. Sắc là 54 sắc gồm ý vật và các sắc cùng với nó, cùng cảnh sắc.

Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tâm xác định (voṭṭhapana)

1. 54 sắc pháp gồm sắc ý vật, chỗ nương của tâm xác định, và các sắc cùng với nó, cùng cảnh sắc, là sắc uẩn.

2. Thọ trong 12 danh pháp của tâm xác định là thọ uẩn.

3. Tưởng trong 12 danh pháp của tâm xác định là tưởng uẩn.

4. Tư trong 12 danh pháp của tâm xác định là hành uẩn theo cách thứ nhất. 9 tâm sở còn lại trong 12 danh pháp ấy là hành uẩn theo cách thứ hai.

5. Tâm biết, tức thức, trong 12 danh pháp của tâm xác định là thức uẩn.

Ghi chú. Hãy quán sắc uẩn của tâm xác định theo cách quán sắc uẩn của tâm hướng ngũ môn. Tâm xác định này chỉ là tâm duy tác (kiriyā)…


<a id="M05-body-P149"></a>
## Xác định — Thọ uẩn và tưởng uẩn
Miến / Burmese 149

…và không sinh do các nhân quá khứ. Do đó, cả bốn danh uẩn của tâm xác định không có nhân quá khứ. Chúng chỉ sinh do các nhân hiện tại, nên chỉ có các nhân hiện tại.

Xác định — Thọ uẩn

Ba nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm xác định là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tâm xác định là pháp quả.

3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tâm xác định là pháp quả.

(b) Ý xúc của tâm suy đạc (12 hoặc 11) là pháp nhân. Thọ uẩn của tâm xác định là pháp quả.

(c) Ý xúc của tâm xác định (12 trừ thọ, còn 11) là pháp nhân. Thọ uẩn của tâm xác định là pháp quả.

Xác định — Tưởng uẩn

Ba nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Tưởng uẩn của tâm xác định là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Tưởng uẩn của tâm xác định là pháp quả.


<a id="M05-body-P150"></a>
## Xác định — Hành uẩn
Miến / Burmese 150

3(a) Nhãn xúc (8) là pháp nhân. Tưởng uẩn của tâm xác định là pháp quả.

(b) Ý xúc của tâm suy đạc (12 hoặc 11) là pháp nhân. Tưởng uẩn của tâm xác định là pháp quả.

(c) Ý xúc của tâm xác định (12 trừ tưởng, còn 11) là pháp nhân. Tưởng uẩn của tâm xác định là pháp quả.

Xác định — Hành uẩn (tư, cách thứ nhất)

Ba nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

3(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

(b) Ý xúc của tâm suy đạc (12 hoặc 11) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

(c) Ý xúc của tâm xác định (12 trừ tư, còn 11) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

Xác định — Hành uẩn (chín tâm sở, cách thứ hai)

Ba nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.


<a id="M05-body-P151"></a>
## Xác định — Thức uẩn và tác ý dẫn đầu tốc hành
Miến / Burmese 151

2. Cảnh, tức cảnh sắc là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

3(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

(b) Ý xúc của tâm suy đạc (12 hoặc 11) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

(c) Ba danh uẩn còn lại là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

Xác định — Thức uẩn

Hai nhân hiện tại

1(a) Nhãn xúc (8) là pháp nhân. Thức uẩn của tâm xác định là pháp quả.

(b) Ý xúc của tâm suy đạc (12 hoặc 11) là pháp nhân. Thức uẩn của tâm xác định là pháp quả.

2. Danh và sắc ở tâm xác định là pháp nhân. Thức uẩn của tâm xác định là pháp quả.

Danh là 11 tâm sở tương ưng với tâm xác định. Sắc là 54 sắc gồm ý vật và các sắc cùng với nó, cùng cảnh sắc.

Tác ý dẫn đầu tốc hành (javanapaṭipādakamanasikāra)

Nếu tâm xác định này xác định cảnh là khả ái, bất khả ái, v.v., theo cách tác ý sai, tức tác ý không như lý, thì sau tâm xác định ấy các tốc hành bất thiện thích hợp…


<a id="M05-body-P152"></a>
## Tác ý dẫn đầu tốc hành và năm uẩn ở tốc hành thiện thứ nhất
Miến / Burmese 152

…sẽ sinh. Tuy nhiên, tâm xác định trong lộ ngũ môn không thật sự tự xác định cảnh là khả ái, bất khả ái, thường, lạc, ngã, đẹp, v.v. Các lộ ý môn trước đó đã nhiều lần xác định cảnh là khả ái, bất khả ái, thường, lạc, ngã, đẹp, v.v. Khi các lộ ngũ môn xuất hiện sau đó, các lộ ý môn trước trợ bằng năng lực của duyên y chỉ mạnh. Do vậy, tâm xác định trong các lộ ngũ môn sau sinh với cách thức như thể xác định cảnh là khả ái, bất khả ái, thường, lạc, ngã, đẹp, v.v. Đó là tác ý không như lý. Do tác ý không như lý làm nhân, các tốc hành bất thiện sinh sau tâm xác định ấy. Mặt khác, nếu tâm xác định sinh theo cách xác định cảnh là cảnh sắc, màu sắc, v.v., đó là tác ý như lý. Sau tâm xác định ấy, các tốc hành thiện sinh. Ở đây cũng hãy ghi nhớ rằng tâm xác định không thể tự mình phán định. Nó sinh như thể đang xác định. Vì vậy, tâm xác định ấy gọi là tác ý dẫn đầu tốc hành, tức sự tác ý đến cảnh làm nhân căn bản cho tốc hành. (Chú giải Abhidhamma, tập 1, tr. 177.) Ở đây sẽ trình bày trước cách quán quan hệ nhân quả trong các tốc hành thiện sinh do tác ý như lý.

Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tốc hành thiện thứ nhất

1. 54 sắc pháp gồm sắc ý vật, chỗ nương của tốc hành thiện thứ nhất, và các sắc cùng với nó, cùng cảnh sắc, là sắc uẩn.

2. Thọ trong 34 danh pháp của tốc hành thiện thứ nhất là thọ uẩn.


<a id="M05-body-P153"></a>
## Tốc hành đại thiện thứ nhất — Thọ uẩn
Miến / Burmese 153

3. Tưởng trong 34 danh pháp của tốc hành thứ nhất là tưởng uẩn.

4. Tư trong 34 danh pháp của tốc hành thứ nhất là hành uẩn theo cách thứ nhất. 31 tâm sở còn lại trong 34 danh pháp ấy là hành uẩn theo cách thứ hai.

5. Tâm biết, tức thức, trong 34 danh pháp của tốc hành thứ nhất là thức uẩn.

Ghi chú. Hãy quán sắc uẩn của tốc hành thiện thứ nhất nêu trên theo cách quán sắc uẩn của tâm hướng ngũ môn. Các danh pháp tốc hành không sinh do các nhân quá khứ, chỉ sinh do các nhân hiện tại. Vì thế các danh pháp tốc hành không có nhân quá khứ, chỉ có các nhân hiện tại.

Tốc hành đại thiện thứ nhất — Thọ uẩn

Bốn nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

(b) Ý xúc của tốc hành thứ nhất (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.


<a id="M05-body-P154"></a>
## Tốc hành đại thiện thứ nhất — Tưởng uẩn và hành uẩn
Miến / Burmese 154

Tốc hành đại thiện thứ nhất — Tưởng uẩn

Bốn nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Tưởng uẩn của tốc hành thứ nhất là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Tưởng uẩn của tốc hành thứ nhất là pháp quả.

3(a) Nhãn xúc (8) là pháp nhân. Tưởng uẩn của tốc hành thứ nhất là pháp quả.

(b) Ý xúc của tốc hành thứ nhất (34 trừ tưởng, còn 33) là pháp nhân. Tưởng uẩn của tốc hành thứ nhất là pháp quả.

4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Tưởng uẩn của tốc hành thứ nhất là pháp quả.

Tốc hành đại thiện thứ nhất — Hành uẩn (tư, cách thứ nhất)

Bốn nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

3(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

(b) Ý xúc của tốc hành thứ nhất (34 trừ tư, còn 33) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.


<a id="M05-body-P155"></a>
## Tốc hành đại thiện thứ nhất — Hành uẩn và thức uẩn
Miến / Burmese 155

4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

Tốc hành đại thiện thứ nhất — Hành uẩn (31 tâm sở, cách thứ hai)

Bốn nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

3(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

(b) Ba danh uẩn còn lại là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

Tốc hành đại thiện thứ nhất — Thức uẩn

Ba nhân hiện tại

1. Nhãn xúc (8) là pháp nhân. Thức uẩn của tốc hành thứ nhất là pháp quả.

2. Danh và sắc là pháp nhân. Thức uẩn của tốc hành thứ nhất là pháp quả.

3. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Thức uẩn của tốc hành thứ nhất là pháp quả.


<a id="M05-body-P156"></a>
## Số danh pháp và duyên vô gián
Miến / Burmese 156

Danh là 33 tâm sở tương ưng.

Sắc là 54 sắc gồm sắc ý vật làm chỗ nương và các sắc đi cùng nó, cùng cảnh sắc.

Ghi chú. Nếu tốc hành có thọ xả thì hỷ không tương ưng. Bớt một hỷ trong số 34 kể trên. Nếu trí không tương ưng thì bớt trí. Nếu cả trí lẫn hỷ đều không tương ưng thì bớt cả hai. Hãy ghi nhớ rằng trừ thọ, tưởng và thức, tất cả tâm sở còn lại, dù ít hay nhiều, đều gọi là hành uẩn. Mặt khác, từ tốc hành thứ hai trở đi, Đức Phật dạy trong Paṭṭhāna rằng “Purimā purimā kusalā dhammā pacchimānaṃ pacchimānaṃ kusalānaṃ dhammānaṃ anantarapaccayena paccayo.” (Paṭṭhāna 1, 3.) Vì vậy, mỗi tốc hành trước là nhân vô gián của tốc hành sau. Nói cách khác như sau.

Yesaṃ yesaṃ dhammānaṃ anantarā ye ye dhammā uppajjanti cittacetasikā dhammā, te te dhammā tesaṃ tesaṃ dhammānaṃ anantarapaccayena paccayo. (Paṭṭhāna 1, 3.)

Theo các lời dạy này, mỗi tâm trước là nhân vô gián của tâm sau, tức mỗi nhóm danh pháp trước là nhân vô gián của nhóm danh pháp sau. Hãy thêm nhân vô gián này khi quán tốc hành thứ hai trở đi và các tâm đăng ký. Có thể hỏi liệu tốc hành thứ nhất có nhân vô gián hay không. Có. Tâm xác định là nhân vô gián của tốc hành thứ nhất. Hãy nhớ rằng ở đây tâm xác định đã được nêu dưới tên tác ý như lý.


<a id="M05-body-P157"></a>
## Tốc hành đại thiện thứ hai — Thọ uẩn
Miến / Burmese 157

Ở đây lấy riêng thọ uẩn của tốc hành đại thiện thứ hai để nêu làm mẫu. Hãy dựa vào cách ấy để quán các danh uẩn còn lại và các tốc hành, tâm đăng ký còn lại. Trong mỗi sát-na tâm tốc hành và mỗi sát-na tâm đăng ký, hãy nhớ phân thành năm uẩn mà quán.

Tốc hành đại thiện thứ hai — Thọ uẩn

Bốn nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn là pháp quả.

3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn là pháp quả.

(b) Ý xúc của tốc hành thứ nhất (34) là pháp nhân. Thọ uẩn là pháp quả.

(c) Ý xúc của tốc hành thứ hai (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn là pháp quả.

4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Thọ uẩn là pháp quả.

1. Nhân vô gián của tốc hành thứ ba là tốc hành thứ hai.

2. Nhân vô gián của tốc hành thứ tư là tốc hành thứ ba.

3. Nhân vô gián của tốc hành thứ năm là tốc hành thứ tư.

4. Nhân vô gián của tốc hành thứ sáu là tốc hành thứ năm.

5. Nhân vô gián của tốc hành thứ bảy là tốc hành thứ sáu.

6. Nhân vô gián của tâm đăng ký thứ nhất là tốc hành thứ bảy.


<a id="M05-body-P158"></a>
## Năm uẩn ở tâm đăng ký
Miến / Burmese 158

7. Nhân vô gián của tâm đăng ký thứ hai là tâm đăng ký thứ nhất.

Dựa vào những trường hợp như vậy, hãy hiểu mục 3(b) trên đây.

Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tâm đăng ký

1. 54 sắc pháp gồm sắc ý vật, chỗ nương của tâm đăng ký đại quả, và các sắc cùng với nó, cùng cảnh sắc, là sắc uẩn.

2. Thọ trong 34 danh pháp của tâm đăng ký đại quả là thọ uẩn.

3. Tưởng trong 34 danh pháp của tâm đăng ký đại quả là tưởng uẩn.

4. Tư trong 34 danh pháp của tâm đăng ký đại quả là hành uẩn theo cách thứ nhất. 31 tâm sở còn lại trong 34 danh pháp ấy là hành uẩn theo cách thứ hai.

5. Tâm biết, tức thức, trong 34 danh pháp của tâm đăng ký đại quả là thức uẩn.

Hãy quán sắc uẩn của tâm đăng ký theo cách quán sắc uẩn của tâm hướng ngũ môn.

Tâm đăng ký đại quả thứ nhất — Thọ uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

2. Ái (20) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

3. Thủ (20) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.


<a id="M05-body-P159"></a>
## Tâm đăng ký đại quả thứ nhất — Thọ, tưởng và hành uẩn
Miến / Burmese 159

4. Hành (34) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

Ba nhân hiện tại

6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

7. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

8(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

(b) Ý xúc của tâm tốc hành thứ bảy (34) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

(c) Ý xúc của tâm đăng ký thứ nhất (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

Tưởng uẩn của tâm đăng ký thứ nhất. Mục 8(c), ý xúc của tâm đăng ký thứ nhất là 34 trừ tưởng, còn 33.

Hành uẩn của tâm đăng ký thứ nhất. Mục 8(c), ý xúc của tâm đăng ký thứ nhất là 34 trừ tư, còn 33. Đây là cách thứ nhất.

Hành uẩn của tâm đăng ký thứ nhất. Mục 8(c) là ba danh uẩn còn lại, tức thọ, tưởng và thức. Đây là cách thứ hai.

Chỉ khác ở các điểm này. Hãy quán theo cách đã nêu cho thọ uẩn.


<a id="M05-body-P160"></a>
## Tâm đăng ký đại quả thứ nhất — Thức uẩn
Miến / Burmese 160

Tâm đăng ký đại quả thứ nhất — Thức uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

2. Ái (20) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

3. Thủ (20) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

4. Hành (34) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

Hai nhân hiện tại

6(a) Nhãn xúc (8) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

(b) Ý xúc của tâm tốc hành thứ bảy (34) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

7. Danh và sắc ở tâm đăng ký thứ nhất là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

Danh là 33 tâm sở tương ưng.

Sắc là 54 sắc gồm sắc ý vật làm chỗ nương và các sắc đi cùng nó, cùng cảnh sắc.

Nếu tâm đăng ký đại quả có thọ xả thì hỷ không tương ưng, có 33 danh pháp. Nếu trí không tương ưng thì do thiếu trí…


<a id="M05-body-P161"></a>
## Số danh pháp ở tâm đăng ký và lộ ý môn
Miến / Burmese 161

…có 33 danh pháp. Nếu cả trí lẫn hỷ đều không tương ưng thì có 32 danh pháp. Số danh pháp khác nhau tùy theo thọ hỷ hay thọ xả và tương ưng trí hay ly trí. Trong cách thứ hai về hành uẩn, số tâm sở cũng tăng giảm theo số tâm sở hiện diện. Nếu tâm đăng ký là tâm suy đạc quả thiện vô nhân có thọ hỷ thì có 12 danh pháp. Nếu là tâm suy đạc quả thiện vô nhân có thọ xả thì có 11. Nếu là tâm suy đạc quả bất thiện vô nhân có thọ xả thì cũng có 11. Khi tâm đăng ký là vô nhân, số tâm sở trong hành uẩn chỉ thay đổi ở cách thứ hai. Hãy dựa theo mẫu mà quán. Vì tâm đăng ký thứ nhất là nhân vô gián của tâm đăng ký thứ hai, số danh pháp ở ý xúc trong mục 8(b) có thể thay đổi thích hợp thành 34, 33, 33, 32, 12, 11 hoặc 11. Hãy lưu ý và quán theo mẫu.

Các lộ ý môn lấy cảnh sắc làm đối tượng

Trên đây đã trình bày cách quán quan hệ nhân quả của năm uẩn trong mỗi sát-na tâm của lộ nhãn môn có tốc hành thiện. Hãy dùng chính phương pháp này để quán nhân và quả trong các nhóm danh pháp còn lại của các lộ nhãn môn có tốc hành thiện. Sau lộ nhãn môn, cách một số tâm hữu phần, các lộ ý môn tiếp tục sinh và lấy cùng cảnh sắc làm đối tượng. Hãy quán năm uẩn của hữu phần trong các lộ ấy theo cách đã nêu trước đây…


<a id="M05-body-P162"></a>
## Hướng ý môn và tốc hành đại thiện thứ nhất
Miến / Burmese 162

…đối với năm uẩn của hữu phần. Sau đây, thọ uẩn ở tâm hướng ý môn và ở các tốc hành được lấy riêng làm mẫu. Việc phân năm uẩn ở tâm hướng ý môn giống như ở tâm xác định. Cách phân năm uẩn ở các tốc hành và tâm đăng ký cũng giống như cách phân năm uẩn ở các tốc hành và tâm đăng ký của lộ nhãn môn.

Hướng ý môn — Thọ uẩn

Ba nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm hướng ý môn là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tâm hướng ý môn là pháp quả.

3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tâm hướng ý môn là pháp quả.

(b) Ý xúc của tâm hữu phần (34) là pháp nhân. Thọ uẩn của tâm hướng ý môn là pháp quả.

(c) Ý xúc của tâm hướng ý môn (12 trừ thọ, còn 11) là pháp nhân. Thọ uẩn của tâm hướng ý môn là pháp quả.

Tốc hành đại thiện thứ nhất — Thọ uẩn

Bốn nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.


<a id="M05-body-P163"></a>
## Tốc hành đại thiện thứ nhất và thứ hai trong lộ ý môn
Miến / Burmese 163

2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

(b) Ý xúc của tâm hữu phần (34) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

(c) Ý xúc của tâm tốc hành thứ nhất (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

Tốc hành đại thiện thứ hai — Thọ uẩn

Bốn nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

(b) Ý xúc của tâm hữu phần (34) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

(c) Ý xúc của tâm tốc hành thứ nhất (34) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

(d) Ý xúc của tốc hành thứ hai (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.


<a id="M05-body-P164"></a>
## Giải thích về nhãn xúc và ý xúc
Miến / Burmese 164

4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

Hãy dựa vào chính các phương pháp đã trình bày ở trên để quán các uẩn còn lại, cũng như các tốc hành và tâm đăng ký còn lại. Đến đây hẳn đã có thể hiểu cách quán.

Giải thích về nhãn xúc và ý xúc

Yampidaṃ cakkhusamphassapaccayā uppajjati vedayitaṃ sukhaṃ vā dukkhaṃ vā adukkhamasukhaṃ vā. (Saṃyutta 2, 248.)

Cakkhusamphassapaccayā uppajjati vedayitanti cakkhusamphassaṃ mūlapaccayaṃ katvā uppannā sampaṭicchana-santīraṇa-voṭṭhabbana-javanavedanā. Cakkhuviññāṇasampayuttāya pana vattabbameva natthi. Sotadvārādivedanāpaccayādīsupi eseva nayo. (Chú giải Saṃyutta 3, 5.)

Yampidaṃ manosamphassapaccayā uppajjati vedayitaṃ sukhaṃ vā dukkhaṃ vā adukkhamasukhaṃ vā. (Saṃyutta 2, 248.)

Manosamphassoti bhavaṅgasahajāto samphasso. Vedayitanti javanasahajātā vedanā. Sahāvajjanena bhavaṅgasahajātāpi vaṭṭatiyeva. (Chú giải Saṃyutta 3, 5.)

Yamidaṃ (yampidaṃ) cakkhusamphassapaccayā uppajjati vedanāgataṃ saññāgataṃ saṅkhāragataṃ viññāṇagataṃ. (Majjhima 3, 325.)

Yamidaṃ manosamphassapaccayā uppajjati vedanāgataṃ saññāgataṃ saṅkhāragataṃ viññāṇagataṃ. (Majjhima 3, 326.)

Sahāvajjanavedanāya javanavedanā “vedayitan”ti adhippetā.


<a id="M05-body-P165"></a>
## Nhãn xúc làm duyên cho bốn danh uẩn
Miến / Burmese 165

Bhavaṅgasampayuttāya pana vedanāya gahaṇe vattabbameva natthi. (Phụ chú giải Saṃyutta 2, 286.)

Theo các bản Pāli, chú giải và phụ chú giải nêu trên, thọ ở nhãn thức, tiếp thâu, suy đạc, xác định, tốc hành và đăng ký sinh do nhãn xúc, nên đều là thọ do nhãn xúc làm duyên. Theo Kinh Giáo Giới Rāhula Ngắn (Cūḷarāhulovādasutta), do nhãn xúc không chỉ có thọ sinh, mà “Yamidaṃ cakkhusamphassapaccayā uppajjati vedanāgataṃ saññāgataṃ saṅkhāragataṃ viññāṇagataṃ” (Majjhima 3, 326), cả bốn danh uẩn thọ, tưởng, hành và thức đều sinh. Vì vậy, hãy ghi nhớ rằng nhãn xúc tương ưng với nhãn thức trợ cho từng nhóm bốn danh uẩn ở nhãn thức, tiếp thâu, suy đạc, xác định, tốc hành và đăng ký sinh khởi.

Tuy nhiên, khi giải thích cách nhãn xúc trợ các nhóm danh pháp sinh do nó, chú giải chỉ nêu sự trợ giúp trong cùng một lộ, tức trong lộ nhãn môn. Tuy vậy, có lời Pāli sau đây.

“Cakkhusamphassapaccayā vedanākkhandho atthi anupādinno anupādāniyo asaṃkiliṭṭho asaṃkilesiko savitakkasavicāro.”

Dựa vào những lời Pāli như vậy, vị chú giải giải thích rằng không thể bác bỏ sự trợ giúp của nhãn xúc đối với các nhóm danh pháp ở lộ khác, tức ở những lộ tâm khác nhau, kể cả các nhóm danh pháp trong lộ ý môn tiếp tục lấy cảnh sắc làm đối tượng. Vị ấy còn giải thích rằng chú giải trình bày sự trợ giúp của nhãn xúc đối với các nhóm danh pháp trong cùng một lộ nhãn môn vì sự trợ giúp ấy là chắc chắn. (Mūlaṭīkā 2, 30.) Các hành giả…


<a id="M05-body-P166"></a>
## Ý xúc trong lộ ý môn
Miến / Burmese 166

…khi khảo sát phần lớn vẫn tán đồng lời giải thích của vị soạn Mūlaṭīkā. Hãy ghi nhớ cách tương tự đối với nhĩ xúc và các xúc khác khi chúng trợ cho các lộ ý môn lấy cùng cảnh thinh của lộ nhĩ môn và các cảnh tương ứng.

Ý xúc là xúc tương ưng với hữu phần rung động liền kề tâm hướng ý môn, đang trợ cho tâm hướng ý môn bằng năng lực duyên vô gián. Ý xúc ấy cũng trợ cho các nhóm danh pháp trong lộ ý môn, gồm hướng ý môn và tốc hành, cùng tâm đăng ký nếu có, sinh khởi. Trong lộ an chỉ, ý xúc ấy vẫn trợ cho sự sinh khởi của tâm hướng ý môn, các tốc hành cận định và các tốc hành an chỉ. Vì vậy, ở các nhóm danh pháp trong lộ ý môn tiếp tục lấy cảnh sắc, bản văn trình bày sự trợ giúp của nhãn xúc, ý xúc của hữu phần và ý xúc tương ưng đồng sinh. Từ tốc hành thứ hai trở đi, còn nêu các nhân ý xúc vô gián như tốc hành thứ nhất.

Vì vậy, thiện hữu hãy dùng trí thấy rõ sự trợ giúp của nhãn xúc, ý xúc vô gián và ý xúc đồng sinh tương ưng đối với các danh uẩn liên hệ trong các nhóm danh pháp ở lộ nhãn môn. Hãy cũng thấy rõ sự trợ giúp của nhãn xúc, ý xúc của hữu phần, ý xúc vô gián và ý xúc đồng sinh tương ưng trong các nhóm danh pháp ở lộ ý môn tiếp tục lấy chính cảnh sắc ấy. Hãy dùng trí thấy rõ mối quan hệ giữa các pháp nhân và pháp quả rồi quán các pháp nhân và pháp quả ấy. Ở đây, đối với các lộ nhãn môn và ý môn có tốc hành thiện lấy cảnh sắc…


<a id="M05-body-P167"></a>
## Năm uẩn ở tốc hành tham hợp tà kiến
Miến / Burmese 167

…phần trình bày cách quán nhân và quả theo năm uẩn trong từng sát-na tâm dừng tại đây. Sau đây sẽ trình bày tiếp cách quán nhân và quả theo năm uẩn trong mỗi sát-na của các lộ nhãn môn và ý môn có tốc hành bất thiện cũng lấy chính cảnh sắc ấy.

Trong các lộ nhãn môn và ý môn có tốc hành bất thiện sinh khi lấy cảnh sắc, hướng ngũ môn, nhãn thức, tiếp thâu, suy đạc, xác định, đăng ký, hữu phần, hướng ý môn và đăng ký đều theo mẫu quán của lộ có tốc hành thiện. Chỉ ở các tốc hành có một vài khác biệt, nên ở đây lấy nhóm tham hợp tà kiến gồm 20 danh pháp làm mẫu. Cũng như các nhóm danh pháp tốc hành thiện, các nhóm danh pháp tốc hành bất thiện không có nhân quá khứ, chỉ có nhân hiện tại.

Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tốc hành tham hợp tà kiến

1. 54 sắc pháp gồm sắc ý vật, chỗ nương của tốc hành tham hợp tà kiến, và các sắc cùng với nó, cùng cảnh sắc, là sắc uẩn.

2. Thọ trong 20 danh pháp của tốc hành tham hợp tà kiến là thọ uẩn.

3. Tưởng trong 20 danh pháp của tốc hành tham hợp tà kiến là tưởng uẩn.

4. Tư trong 20 danh pháp của tốc hành tham hợp tà kiến là hành uẩn theo cách thứ nhất. 17 tâm sở còn lại trong 20 danh pháp ấy là hành uẩn theo cách thứ hai.


<a id="M05-body-P168"></a>
## Tốc hành tham hợp tà kiến thứ nhất — Thọ uẩn và thức uẩn
Miến / Burmese 168

5. Tâm biết, tức thức, trong 20 danh pháp của tốc hành tham hợp tà kiến là thức uẩn.

Hãy quán sắc uẩn của tốc hành theo cách quán sắc uẩn của tâm hướng ngũ môn.

Tốc hành tham hợp tà kiến thứ nhất — Thọ uẩn (lộ nhãn môn)

Bốn nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

(b) Ý xúc của tốc hành thứ nhất (20 trừ thọ, còn 19) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

4. Tác ý không như lý, tức tâm xác định (12) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

Tốc hành tham hợp tà kiến thứ nhất — Thức uẩn (lộ nhãn môn)

Ba nhân hiện tại

1. Nhãn xúc (8) là pháp nhân. Thức uẩn của tốc hành thứ nhất là pháp quả.

2. Danh và sắc là pháp nhân. Thức uẩn của tốc hành thứ nhất là pháp quả.

3. Tác ý không như lý, tức tâm xác định (12), là pháp nhân…


<a id="M05-body-P169"></a>
## Tốc hành tham hợp tà kiến thứ hai
Miến / Burmese 169

…thức uẩn của tốc hành thứ nhất là pháp quả.

Danh là 19 tâm sở tương ưng.

Sắc là 54 sắc gồm sắc ý vật và các sắc đi cùng nó, cùng cảnh sắc.

Tốc hành tham hợp tà kiến thứ hai — Thọ uẩn (lộ nhãn môn)

Bốn nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

(b) Ý xúc của tâm tốc hành thứ nhất (20) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

(c) Ý xúc của tâm tốc hành thứ hai (20 trừ thọ, còn 19) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

4. Tác ý không như lý, tức tâm xác định (12) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

Tốc hành tham hợp tà kiến thứ hai — Thức uẩn (lộ nhãn môn)

Ba nhân hiện tại

1(a) Nhãn xúc (8) là pháp nhân. Thức uẩn của tốc hành thứ hai là pháp quả.

(b) Ý xúc của tốc hành thứ nhất (20) là pháp nhân…


<a id="M05-body-P170"></a>
## Thức uẩn và lưu ý khi chuyển sang cảnh khác
Miến / Burmese 170

…thức uẩn của tốc hành thứ hai là pháp quả.

2. Danh và sắc là pháp nhân. Thức uẩn của tốc hành thứ hai là pháp quả.

3. Tác ý không như lý, tức tâm xác định (12) là pháp nhân. Thức uẩn của tốc hành thứ hai là pháp quả.

Danh là 19 tâm sở tương ưng.

Sắc là 54 sắc gồm sắc ý vật và các sắc đi cùng nó, cùng cảnh sắc.

Điểm cần lưu ý

Với những mẫu trên, có thể hiểu cách quán các pháp nhân và pháp quả theo năm uẩn trong từng sát-na tâm của các lộ nhãn môn và ý môn có tốc hành bất thiện lấy cảnh sắc. Khi đã hiểu cách quán các pháp nhân và pháp quả theo năm uẩn trong từng sát-na của các lộ tốc hành thiện và bất thiện lấy cảnh sắc, hãy chuyển sang quán cảnh thinh và các cảnh khác. Ở mỗi sát-na tâm, hãy hiểu rõ số tâm sở tăng hay giảm tùy theo có nhiều hay ít tâm sở tương ưng. Hãy lưu ý rằng số tâm sở tương ưng trong một sát-na tâm làm thay đổi cả hành uẩn lẫn ý xúc đồng sinh. Nếu thiện hữu còn yếu về căn bản Abhidhamma hoặc chưa từng học phần căn bản ấy, cần nhờ thầy hướng dẫn. Vì vậy, ở đây chỉ trình bày một số điểm khác nhau.


<a id="M05-body-P171"></a>
## Cảnh thinh và những điểm thay đổi theo cảnh
Miến / Burmese 171

Một số điểm thay đổi

2. Trong lộ cảnh thinh, cảnh sắc được thay bằng cảnh thinh và nhãn xúc được thay bằng nhĩ xúc.

3. Trong lộ cảnh hương, cảnh là cảnh hương và xúc là tỷ xúc.

4. Trong lộ cảnh vị, cảnh là cảnh vị và xúc là thiệt xúc.

5. Trong lộ cảnh xúc, cảnh là cảnh xúc và xúc là thân xúc.

Lộ cảnh thinh, tức âm thanh — Hướng ngũ môn — Thọ uẩn

Ba nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

2. Cảnh, tức cảnh thinh là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

(b) Ý xúc của tâm hướng ngũ môn (11 trừ thọ, còn 10) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.


<a id="M05-body-P172"></a>
## Cảnh thinh — Thọ uẩn của nhĩ thức
Miến / Burmese 172

Đến đây hẳn có thể hiểu các danh uẩn còn lại. Từ đây chỉ nêu mẫu một hoặc hai uẩn trong một sát-na tâm. Khi thực hành, hãy quán đầy đủ cả năm uẩn trong từng sát-na tâm.

Lộ cảnh thinh, tức âm thanh — Thọ uẩn của nhĩ thức, tức tâm nghe

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

2. Ái (20) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

3. Thủ (20) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

4. Hành (34) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

Năm nhân hiện tại

6. Vật, tức sắc nhĩ vật (54) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

7. Cảnh, tức cảnh thinh là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

8. Nhĩ xúc (8 trừ thọ, còn 7) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.


<a id="M05-body-P173"></a>
## Giới hư không và hành uẩn của tâm tiếp thâu
Miến / Burmese 173

9. Giới hư không, tức khoảng trống ở giữa là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

10. Tác ý, tức tâm hướng ngũ môn (11) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

Giới hư không (ākāsadhātu). Giữa nhĩ tịnh sắc và cảnh thinh phải có một khoảng trống. Nhĩ thức chỉ có thể sinh khi nương giới hư không ấy. Thiếu giới hư không, nhĩ thức không thể sinh. Thật vậy, nơi người bịt lỗ tai hoặc có lỗ tai bị bịt, nhĩ thức không thể sinh. Vì vậy, giới hư không là một trong các nhân cho nhóm danh pháp nhĩ thức sinh khởi. (Chú giải Abhidhamma 2, 322.)

Lộ cảnh thinh — Tiếp thâu — Hành uẩn (cách thứ hai)

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

2. Ái (20) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

3. Thủ (20) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

4. Hành (34) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.


<a id="M05-body-P174"></a>
## Cảnh thinh — Hành uẩn và thức uẩn của tâm tiếp thâu
Miến / Burmese 174

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

Ba nhân hiện tại

6. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

7. Cảnh, tức cảnh thinh là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

8(a) Nhĩ xúc (8) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

(b) Ba danh uẩn còn lại là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

Lộ cảnh thinh — Tiếp thâu — Thức uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.

2. Ái (20) là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.

3. Thủ (20) là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.

4. Hành (34) là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.


<a id="M05-body-P175"></a>
## Cảnh thinh — Thức uẩn của tâm tiếp thâu và thọ uẩn của tâm suy đạc
Miến / Burmese 175

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.

Hai nhân hiện tại

6. Nhĩ xúc (8) là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.

7. Danh và sắc là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.

Danh là 10 tâm sở tương ưng.

Sắc là 54 sắc gồm sắc ý vật và các sắc đi cùng nó, cùng cảnh thinh.

Lộ cảnh thinh — Suy đạc — Thọ uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

2. Ái (20) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

3. Thủ (20) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

4. Hành (34) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.


<a id="M05-body-P176"></a>
## Từ cảnh thinh sang cảnh hương
Miến / Burmese 176

Ba nhân hiện tại

6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

7. Cảnh, tức cảnh thinh là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

8(a) Nhĩ xúc (8) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

(b) Ý xúc của tâm tiếp thâu (11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

(c) Ý xúc của tâm suy đạc (12 trừ thọ, còn 11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

Ở đây chỉ nêu mẫu đủ để hiểu. Với các mẫu trên, có thể hiểu cách quán cảnh thinh. Sau đây, ở lộ cảnh hương cũng chỉ nêu mẫu cách quán các pháp nhân và pháp quả theo năm uẩn trong từng sát-na tâm.

Lộ cảnh hương, tức mùi — Hướng ngũ môn — Thọ uẩn

Ba nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

2. Cảnh, tức cảnh hương là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.


<a id="M05-body-P177"></a>
## Cảnh hương — Thọ uẩn của tỷ thức
Miến / Burmese 177

3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

(b) Ý xúc của tâm hướng ngũ môn (10, tức 11 trừ thọ, còn 10) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

Lộ cảnh hương, tức mùi — Tỷ thức — Thọ uẩn

Năm nhân quá khứ

1. Vô minh (20) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

2. Ái (20) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

3. Thủ (20) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

4. Hành (34) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

Năm nhân hiện tại

6. Vật, tức sắc tỷ vật (54) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

7. Cảnh, tức cảnh hương là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.


<a id="M05-body-P178"></a>
## Giới gió và tâm tiếp thâu trong lộ cảnh hương
Miến / Burmese 178

8. Tỷ xúc (8 trừ thọ, còn 7) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

9. Giới gió là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

10. Tác ý, tức tâm hướng ngũ môn (11) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

Giới gió (vāyodhātu). Chỉ khi luồng gió có khả năng mang mùi, tức giới gió, đi vào khoang mũi, nơi có tỷ tịnh sắc, thì nhóm danh pháp cùng với tỷ thức mới có thể sinh và biết cùng một cảnh hương. Khi luồng gió mang mùi ấy, tức giới gió, vắng mặt, nhóm danh pháp tỷ thức cùng các pháp tương ưng không thể sinh. Vì vậy, giới gió là một nhân.

Lộ cảnh hương, tức mùi — Tiếp thâu — Thọ uẩn

1–5. Quán năm nhân quá khứ theo cùng mẫu.

Ba nhân hiện tại

6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

7. Cảnh, tức cảnh hương là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

8(a) Tỷ xúc (8) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.


<a id="M05-body-P179"></a>
## Cảnh hương — Thọ uẩn của tâm suy đạc
Miến / Burmese 179

(b) Ý xúc của tâm tiếp thâu (10, tức 11 trừ thọ, còn 10) là pháp nhân.

Lộ cảnh hương, tức mùi — Suy đạc — Thọ uẩn

1–5. Quán năm nhân quá khứ theo cùng mẫu.

Ba nhân hiện tại

6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

7. Cảnh, tức cảnh hương là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

8(a) Tỷ xúc (8) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

(b) Ý xúc của tâm tiếp thâu (11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

(c) Ý xúc của tâm suy đạc (11, tức 12 trừ thọ, còn 11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

Điểm đặc biệt cần ghi nhớ. Trong các nhân hiện tại của thức uẩn ở tỷ thức, tiếp thâu, suy đạc và các tâm khác, khi nhân được gọi là danh và sắc, về danh hãy lấy nhóm tâm sở tương ưng đồng sinh trong cùng một sát-na với thức uẩn tương ứng. Về sắc hãy lấy sắc vật làm chỗ nương và cảnh hương. Đối với các lộ còn lại cũng hãy lấy các tâm sở tương ưng, sắc vật làm chỗ nương và sắc cảnh tương ứng.


<a id="M05-body-P180"></a>
## Cảnh vị — Thọ uẩn của tâm hướng ngũ môn và thiệt thức
Miến / Burmese 180

Lộ cảnh vị — Hướng ngũ môn — Thọ uẩn

Ba nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

2. Cảnh, tức cảnh vị là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

(b) Ý xúc của tâm hướng ngũ môn (10, tức 11 trừ thọ, còn 10) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

Lộ cảnh vị — Thiệt thức — Thọ uẩn

1–5. Quán năm nhân quá khứ theo cùng mẫu.

Năm nhân hiện tại

6. Vật, tức sắc thiệt vật (54) là pháp nhân. Thọ uẩn của thiệt thức là pháp quả.

7. Cảnh, tức cảnh vị là pháp nhân. Thọ uẩn của thiệt thức là pháp quả.

8. Thiệt xúc (8 trừ thọ, còn 7) là pháp nhân. Thọ uẩn của thiệt thức là pháp quả.

9. Giới nước là pháp nhân. Thọ uẩn của thiệt thức là pháp quả.


<a id="M05-body-P181"></a>
## Giới nước và tâm tiếp thâu trong lộ cảnh vị
Miến / Burmese 181

10. Tác ý, tức tâm hướng ngũ môn (11) là pháp nhân. Thọ uẩn của thiệt thức là pháp quả.

Giới nước (āpodhātu). Chỉ khi có chất lỏng thuộc giới nước làm ướt lưỡi thì nhóm pháp gồm thiệt thức và các pháp tương ưng mới có thể sinh. Thiếu chất lỏng ấy thì nhóm pháp này không thể sinh. Ngay cả khi đặt thức ăn khô có thể nhai lên lưỡi của người có lưỡi khô, thiệt thức vẫn không sinh. (Chú giải Abhidhamma 1, 322.)

Trong các nhân hiện tại của thức uẩn ở thiệt thức và các tâm tiếp theo, về danh hãy lấy các tâm sở tương ưng thích hợp. Về sắc hãy lấy sắc vật làm chỗ nương và cảnh vị tương ứng.

Lộ cảnh vị — Tiếp thâu — Thọ uẩn

1–5. Quán năm nhân quá khứ theo cùng mẫu.

Ba nhân hiện tại

6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

7. Cảnh, tức cảnh vị là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

8(a) Thiệt xúc (8) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

(b) Ý xúc của tâm tiếp thâu (10, tức 11 trừ thọ, còn 10) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.


<a id="M05-body-P182"></a>
## Cảnh vị và cảnh xúc — Thọ uẩn
Miến / Burmese 182

Lộ cảnh vị — Suy đạc — Thọ uẩn

1–5. Quán năm nhân quá khứ theo cùng mẫu.

Ba nhân hiện tại

6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

7. Cảnh, tức cảnh vị là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

8(a) Thiệt xúc (8) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

(b) Ý xúc của tâm tiếp thâu (11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

(c) Ý xúc của tâm suy đạc (11, tức 12 trừ thọ, còn 11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

Lộ cảnh xúc — Hướng ngũ môn — Thọ uẩn

Ba nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

2. Cảnh, tức cảnh xúc là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

(b) Ý xúc của tâm hướng ngũ môn (10, tức 11 trừ thọ, còn 10)…


<a id="M05-body-P183"></a>
## Cảnh xúc — Thọ uẩn của thân thức và giới đất
Miến / Burmese 183

…là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

Lộ cảnh xúc — Thân thức — Thọ uẩn

1–5. Quán năm nhân quá khứ theo cùng mẫu.

Năm nhân hiện tại

6. Vật, tức sắc thân vật (44) là pháp nhân. Thọ uẩn của thân thức là pháp quả.

7. Cảnh, tức cảnh xúc là pháp nhân. Thọ uẩn của thân thức là pháp quả.

8. Thân xúc (8 trừ thọ, còn 7) là pháp nhân. Thọ uẩn của thân thức là pháp quả.

9. Giới đất là pháp nhân. Thọ uẩn của thân thức là pháp quả.

10. Tác ý, tức tâm hướng ngũ môn (11) là pháp nhân. Thọ uẩn của thân thức là pháp quả.

Giới đất (paṭhavīdhātu). Khi cảnh xúc đập trực tiếp vào thân tịnh sắc, tức sắc trong sáng của thân, nó tác động không những vào thân tịnh sắc mà còn vào các đại chủng cùng nhóm sắc làm duyên y chỉ cho thân tịnh sắc. Trong các đại chủng ấy, giới đất là nhân chính của thân tịnh sắc. Nhóm danh pháp thân thức chỉ có thể sinh khi nắm bắt được giới đất là nhân gốc của thân tịnh sắc. Thiếu giới đất ấy, nhóm danh pháp thân thức không thể sinh. Thật vậy…


<a id="M05-body-P184"></a>
## Cảnh xúc — Giới đất và tâm tiếp thâu
Miến / Burmese 184

…ở thân môn, các đại chủng bên ngoài gọi là cảnh xúc, tức đất, lửa và gió bên ngoài, trước hết đập thẳng vào thân tịnh sắc bên trong. Do va chạm ấy, chúng cũng tác động vào các đại chủng cùng nhóm sắc làm chỗ nương và làm nhân cho thân tịnh sắc. Vì vậy, giới đất là một nhân gốc cho nhóm danh pháp thân thức sinh khởi. (Chú giải Abhidhamma 1, 322.)

Trong các nhân hiện tại của thức uẩn ở thân thức, đối với nhân gọi là danh và sắc, về danh hãy lấy cả bảy tâm sở tương ưng với thân thức. Về sắc hãy lấy 44 sắc gồm sắc thân vật và các sắc đi cùng nó, cùng các sắc cảnh là đất, lửa và gió, gọi là cảnh xúc.

Lộ cảnh xúc — Tiếp thâu — Thọ uẩn

1–5. Quán năm nhân quá khứ theo cùng mẫu.

Ba nhân hiện tại

6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

7. Cảnh, tức cảnh xúc là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

8(a) Thân xúc (8) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

(b) Ý xúc của tâm tiếp thâu (10, tức 11 trừ thọ, còn 10) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.


<a id="M05-body-P185"></a>
## Cảnh xúc và cảnh pháp — Thọ uẩn
Miến / Burmese 185

Lộ cảnh xúc — Suy đạc — Thọ uẩn

1–5. Quán năm nhân quá khứ theo cùng mẫu.

Ba nhân hiện tại

6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

7. Cảnh, tức cảnh xúc là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

8(a) Thân xúc (8) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

(b) Ý xúc của tâm tiếp thâu (11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

(c) Ý xúc của tâm suy đạc (11 hoặc 10, tức 12 trừ thọ còn 11, hoặc 11 trừ thọ còn 10) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

Lộ cảnh pháp — Lộ tốc hành thiện lấy nhãn tịnh sắc làm cảnh

Tốc hành thứ nhất — Thọ uẩn (lộ ý môn)

Bốn nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

2. Cảnh, tức cảnh pháp, tức nhãn tịnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.


<a id="M05-body-P186"></a>
## Cảnh pháp — Thọ uẩn của tốc hành thứ nhất và thứ hai
Miến / Burmese 186

3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

(b) Ý xúc của tốc hành thứ nhất (33 (34 trừ thọ, còn 33)) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

4. Tác ý như lý, tức tâm hướng ý môn (12) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

Tốc hành thứ hai — Thọ uẩn

Bốn nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

2. Cảnh, tức cảnh pháp, tức nhãn tịnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

(b) Ý xúc của tốc hành thứ nhất (34) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

(c) Ý xúc của tốc hành thứ hai (33 (34 trừ thọ, còn 33)) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

4. Tác ý như lý, tức tâm hướng ý môn (12) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.


<a id="M05-body-P187"></a>
## Lộ chứng sơ thiền với tợ tướng hơi thở
Miến / Burmese 187

Lộ cảnh pháp — Lộ chứng sơ thiền (lấy tợ tướng hơi thở làm cảnh)

Tốc hành thứ nhất — Thọ uẩn

Bốn nhân hiện tại

1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

2. Cảnh, tức cảnh pháp, tức tợ tướng hơi thở là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

(b) Ý xúc của tốc hành thứ nhất (33) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

4. Tác ý như lý, tức tâm hướng ý môn (12) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

Lấy 34 danh pháp của tốc hành thứ nhất trừ thọ thì ý xúc của tốc hành thứ nhất gồm 33. Từ tốc hành thứ hai trở đi chỉ khác ở chỗ có thêm một nhân vô gián là các danh pháp ngay trước đó, như tốc hành thứ nhất.

Trong lộ chứng thiền này, đối với nhân danh và sắc của thức uẩn ở tốc hành, về sắc chỉ lấy 54 sắc gồm ý vật làm chỗ nương và các sắc đi cùng nó. Cảnh là tợ tướng hơi thở, một cảnh chế định. Với tợ tướng bộ xương hoặc tợ tướng biến xứ trắng…


<a id="M05-body-P188"></a>
## Tợ tướng thiền chỉ và sắc pháp làm cảnh
Miến / Burmese 188

…hoặc bất kỳ tướng thiền chỉ nào tương tự, hãy dùng trí thấy rõ mối quan hệ nhân quả của các danh pháp thiền sinh khởi khi lấy tướng ấy làm cảnh. Khi quán các nhân và quả, ở nhân gọi là cảnh, hãy thay bằng tợ tướng thiền chỉ mà chính nhóm danh pháp thiền mình đang quán lấy làm cảnh. Chẳng hạn, hãy thay bằng “cảnh tợ tướng biến xứ trắng” hay tên thích hợp khác. Có 34 danh pháp ở sơ thiền, 32 ở nhị thiền, 31 ở tam thiền, 31 ở tứ thiền và 31 ở mỗi tầng trong cả bốn thiền vô sắc. Vì vậy, hãy bớt số tâm sở thích hợp trong ý xúc ở tốc hành. Sau các tốc hành thiền an chỉ, tâm đăng ký không sinh.

Lộ cảnh pháp — Sắc pháp làm cảnh

Nếu quán một sắc pháp thuộc lộ cảnh pháp, chẳng hạn một trong năm sắc tịnh, tức các sắc trong sáng, hoặc một trong mười sáu sắc tế, thì khi có tác ý như lý, các tốc hành thiện sinh theo đó. Khi có tác ý không như lý, các tốc hành bất thiện sinh theo đó. Tác ý đến sắc pháp là vô thường, khổ, vô ngã hay bất tịnh là tác ý như lý. Tác ý đến nó như nhãn tịnh sắc hoặc một sắc pháp tương ứng cũng là tác ý như lý. Hãy xem cách tác ý không như lý sinh trong phần đề mục thiền về danh pháp. Điều này đã được trình bày trong phần sự sinh khởi của mười kiết sử. Các nhân còn lại vẫn giống như trên. Đến đây có thể hiểu cách quán quan hệ nhân quả ở các lộ tốc hành bất thiện. Nếu tâm đăng ký sinh, hãy quán theo mẫu quán tâm đăng ký đã trình bày trước đây.


<a id="M05-body-P189"></a>
## Từng nghiệp và từng phần quả
Miến / Burmese 189

Từng phần, từng trường hợp

Hãy phân thành năm uẩn ở từng sát-na tâm của các lộ tốc hành thiện và bất thiện trong cả sáu nhóm cảnh sắc, thinh, hương, vị, xúc và pháp. Hãy quán đầy đủ các pháp nhân và pháp quả bằng cách nối nhân với quả theo năm uẩn. Trong khi quán như vậy, hãy ghi nhớ lời sau.

Vipassakena pana kammantarañca vipākantarañca ekadesato jānitabbaṃ. (Visuddhimagga 2, 237.)

Theo lời giải thích ấy của Visuddhimagga, thiện hữu hãy tiếp tục quán để biết nghiệp và quả của nghiệp theo từng trường hợp, từng phần. Các thức quả trong thời bình nhật, như ngũ thức, tiếp thâu, suy đạc và đăng ký trong sáu loại lộ bắt đầu bằng lộ nhãn môn, có những nhân nghiệp khác nhau. Một số thức quả bình nhật sinh do chính nghiệp làm sinh các pháp quả tái tục, hữu phần và tử. Một số thức quả bình nhật sinh do nghiệp khác. Hãy xem mười hai loại quả Đức Phật đã nêu. Lưu ý mỗi loại quả có nghiệp riêng tương ứng. Vì vậy, thiện hữu hãy quán kỹ lại năm uẩn quá khứ. Khi quán như vậy, nếu nhận ra được một số nghiệp thiện hay bất thiện, hãy dùng trí thấy rõ…


<a id="M05-body-P190"></a>
## Quán bên ngoài và qua nhiều đời
Miến / Burmese 190

…các nghiệp ấy đem lại quả tốt hay quả xấu thế nào trong thời bình nhật của đời hiện tại như đời này, rồi quán bằng cách nối nhân với quả.

Bên ngoài, nhiều đời quá khứ và nhiều đời vị lai

Khi đã quán đầy đủ, trong cả sáu nhóm cảnh như trên, mối quan hệ nhân quả giữa năm nhân quá khứ và các quả hiện tại, hãy dựa theo cùng phương pháp ấy để quán các pháp nhân và quả bên ngoài. Riêng bên ngoài, hãy quán chung những gì giống nhau ở bên ngoài theo cách khái quát.

Nếu làm được, hãy hướng trí đến các đời quá khứ nối tiếp và quán nhân quả, chẳng hạn nhân ở đời quá khứ thứ hai với quả ở đời quá khứ thứ nhất, rồi nhân ở đời quá khứ thứ ba với quả ở đời quá khứ thứ hai. Khi quán như vậy, trong một đời quá khứ mà trước đó chưa từng quán danh sắc đến chân đế, hành giả không cần quán các danh pháp sinh khi lấy những sắc chân đế ấy làm cảnh hoặc các nhân liên hệ với những danh pháp đó. Tương tự, trong đời quá khứ chưa từng chứng thiền, không cần quán các danh pháp thiền hay những nhân liên hệ với chúng.

Tương tự, hãy quán các nhân hiện tại và quả vị lai bằng cách nối nhân với quả. Hãy hướng trí đến các đời vị lai nối tiếp…


<a id="M05-body-P191"></a>
## Hạt giống hạnh và hạt giống minh
Miến / Burmese 191

…cho đến tận cùng vị lai và quán các pháp nhân và quả trong khả năng của mình. Trong cả ba thời quá khứ, hiện tại và vị lai, hãy quán các pháp nhân và quả bên ngoài theo mẫu quán nhân và quả bên trong.

Hạt giống hạnh và hạt giống minh

Khi quán các pháp nhân và quả như vậy, hãy hướng trí thấy rõ và đặc biệt lưu ý những hạt giống sau đây đã được vun bồi, nuôi dưỡng và thực hành trong những đời quá khứ khác nhau với nguyện vọng hướng đến Niết Bàn.

1. Hạt giống hạnh là sự thực hành bố thí, giới và thiền chỉ.

2(a) Đã từng quán bốn đại.

(b) Đã từng quán sắc pháp đến chân đế.

(c) Đã từng quán danh pháp đến chân đế.

(d) Đã từng quán danh và sắc đến chân đế.

(e) Đã từng quán các pháp nhân và quả.

(f) Đã từng quán và xem xét bằng minh sát các hành, tức sắc, danh, nhân và quả, quy chúng vào ba đặc tướng. Đó là một số hạt giống minh, và cũng là một số hạt giống hạnh.

Hãy dùng trí thấy rõ cách các hạt giống hạnh và minh ấy lần lượt trợ nhau bằng năng lực nâng đỡ và năng lực trực tiếp sinh quả. Hãy quán các pháp nhân và quả.


<a id="M05-body-P192"></a>
## Nhân vô gián của hữu phần
Miến / Burmese 192

Nhân vô gián của hữu phần

Tâm sinh làm nhân cho sự tiếp nối của dòng tâm trong một đời, để dòng ấy không gián đoạn, gọi là hữu phần. Ở trên đã giải thích rằng hữu phần sinh do các nhân tương ứng, như vô minh, ái, thủ, hành, nghiệp, vật, cảnh và xúc. Vì hữu phần là loại tâm sinh thường xuyên nhất suốt một đời, các nhân vô gián của hữu phần cũng rất nhiều. Nói gọn để dễ ghi nhớ, sát-na tâm trước ngay sát tâm hữu phần đang được quán, tức sát-na sinh liền trước mà không có gián cách, chính là nhân vô gián của hữu phần ấy. Vì vậy, các pháp sau đây trợ bằng năng lực duyên vô gián.

1. Tâm tái tục trợ tâm hữu phần thứ nhất.

2. Tâm hữu phần thứ nhất trợ tâm hữu phần thứ hai.

3. Mỗi tâm hữu phần trước trợ tâm hữu phần kế tiếp.

4. Nếu hữu phần sinh sau tâm xác định, tâm xác định trợ hữu phần ấy.

5. Nếu hữu phần sinh sau tốc hành, tốc hành cuối trợ hữu phần ấy.

6. Nếu hữu phần sinh sau tâm đăng ký, tâm đăng ký thứ hai trợ hữu phần ấy.

Khi một hữu phần sinh tiếp sau hữu phần, mỗi hữu phần trước trợ hữu phần sau bằng năng lực duyên vô gián.


<a id="M05-body-P193"></a>
## Đạt đến tuệ liễu tri bằng nhận biết
Miến / Burmese 193

Đạt đến tuệ liễu tri bằng nhận biết (ñātapariññā)

So “idaṃ nāmarūpaṃ na ahetu appaccayā nibbattaṃ, sahetu sappaccayā nibbattaṃ. Ko pana hetu, ko pana paccayo”ti upaparikkhanto “avijjāpaccayā taṇhāpaccayā kammapaccayā āhārapaccayā cā”ti taṃ paccayaṃ vavatthapetvā “atītepi paccayā ceva paccayasamuppannā dhammā ca, anāgatepi etarahipi paccayā ceva paccayasamuppannā dhammā ca, tato uddhaṃ satto vā puggalo vā natthi, suddhasaṅkhārapuñjo evā”ti tīsu addhāsu kaṅkhaṃ vitarati. Ayaṃ pana vipassanāsaṅkhārasallakkhaṇā ñātapariññā nāma. (Chú giải Abhidhamma 2, 241–242.)

Hành giả đã quán đầy đủ năm uẩn, tức sắc pháp và danh pháp, theo các xứ và cửa trong cả sáu nhóm cảnh, dùng trí xét như sau. “Danh sắc này sinh khi có nhân trực tiếp làm sinh, tức nhân sản sinh, và khi có duyên nâng đỡ, tức nhân trợ giúp. Vậy nhân trực tiếp của danh sắc này là gì? Các duyên trợ là gì?” Khi xét như vậy, vị ấy phân định các nhân của danh sắc. “Danh sắc sinh do nhân gọi là vô minh, do nhân gọi là ái, do nhân gọi là nghiệp và do nhân gọi là vật thực.” Chẳng hạn, do vô minh sinh nên sắc do nghiệp sinh lúc tái tục, tức sắc uẩn, sinh…


<a id="M05-body-P194"></a>
## Nhân và quả trong ba thời
Miến / Burmese 194

…Vô minh là pháp nhân. Sắc do nghiệp sinh lúc tái tục, tức sắc uẩn, là pháp quả. Sau khi phân định như vậy, hành giả thấy rõ những điều sau.

1. Trong quá khứ cũng chỉ có các pháp nhân và các pháp quả.

2. Trong vị lai cũng chỉ có các pháp nhân và các pháp quả.

3. Trong hiện tại cũng chỉ có các pháp nhân và các pháp quả.

Ngoài các pháp nhân và quả ấy, không có người hay chúng sinh làm ra hoặc tạo tác, cũng không có người hay chúng sinh được làm ra hoặc được tạo tác. Không có đàn ông, đàn bà, người, chúng sinh, chư thiên, Phạm thiên, sinh mạng, linh hồn, thức hay tự ngã theo nghĩa một thực thể. Chỉ có những nhóm hành thuần túy gồm sắc pháp, danh pháp, các pháp nhân và các pháp quả. Khi tự mình thấu suốt và thấy rõ như vậy bằng trí chánh kiến, trí ấy có thể xóa bỏ hoài nghi và những suy nghĩ lầm lạc về ba thời quá khứ, vị lai và hiện tại. Trí ấy biết phân định rõ các hành sau đây, là cảnh được trí minh sát quán.

1. Sắc pháp.

2. Danh pháp.

3. Các pháp nhân.

4. Các pháp quả.

Trí phân định rõ các hành này gọi là tuệ liễu tri bằng nhận biết. (Chú giải Abhidhamma 2, 241–242.) Tuy nhiên, đến đây…


<a id="M05-body-P195"></a>
## Bén rễ trong Giáo pháp
Miến / Burmese 195

…công việc vẫn chưa xong. Còn phải cố gắng quán lại các hành là sắc, danh, nhân và quả theo đặc tính, phận sự, biểu hiện và nhân gần. Sau khi nỗ lực như vậy, công việc thực hành tiếp theo là như sau.

Bén rễ đến mức không thể lìa Giáo pháp

Evaṃ saṅkhāre sallakkhetvā ṭhito pana bhikkhu no dasabalassa sāsane mūlaṃ otaritvā ṭhito nāma hoti, patiṭṭhaṃ laddhā nāma, cūḷasotāpanno nāma hoti niyatagatikova. Tathārūpaṃ pana utusappāyaṃ puggalasappāyaṃ bhojanasappāyaṃ dhammassavanasappāyaṃ labhitvā ekāsane ekapallaṅkavaragato tīṇi lakkhaṇāni āropetvā vipassanāpaṭipāṭiyā saṅkhāre sammasanto arahattaṃ gaṇhāti. (Chú giải Abhidhamma 2, 242.)

Vị tỳ-kheo hành thiền đã phân định rõ sắc, danh, nhân và quả theo cách vừa nêu. Khi quán các hành ấy bằng tuệ phân biệt nhân duyên, vị ấy đạt đến thanh tịnh do vượt qua hoài nghi (kaṅkhāvitaraṇavisuddhi), tức có cái thấy trong sáng vượt qua hoài nghi. Vì thế, vị ấy đã bén rễ trong Giáo pháp của Đức Phật, bậc Thập Lực, đến mức không thể lìa Giáo pháp. Vị ấy đã có chỗ đứng trong Giáo pháp, được gọi là Tiểu Nhập Lưu (cūḷasotāpanna), có thiện thú chắc chắn. Các điều kiện thích hợp để có thể đạt quả A-la-hán gồm có những điều sau.

1. Utusappāya, thời tiết thích hợp.

2. Puggalasappāya, người thích hợp, như thiện hữu, bạn tốt và người thân tốt, thầy tốt và bạn đồng học tốt.


<a id="M05-body-P196"></a>
## Các duyên thích hợp và cách quán trong oai nghi
Miến / Burmese 196

3. Bhojanasappāya, vật thực thích hợp.

4. Dhammassavanasappāya, được nghe Pháp thích hợp.

Khi có được bốn điều kiện thích hợp này, vị ấy có thể trong một lần ngồi tại một chỗ, quán các hành theo ba đặc tướng và tuần tự xem xét chúng theo tiến trình tuệ minh sát, rồi đạt quả A-la-hán. (Chú giải Abhidhamma 2, 242.)

Cách quán trong các oai nghi và khi tỉnh giác

Thiện hữu đã thực hành tuần tự phần đề mục thiền chỉ, phần đề mục thiền về sắc pháp và phần đề mục thiền về danh pháp rồi mới sang phần Duyên khởi. Do vậy, thiện hữu đã biết quán năm uẩn, tức danh và sắc, theo các cách quán tương ứng với các oai nghi và với sự tỉnh giác. Đối với hành giả đã quán năm uẩn, tức danh và sắc, Đức Phật dạy cách tiếp tục thực hành như sau.

1. Samudayadhammānupassī vā kāyasmiṃ viharati.

2. Vayadhammānupassī vā kāyasmiṃ viharati.

3. Samudayavayadhammānupassī vā kāyasmiṃ viharati. (Majjhima 1, 71–72.)

Theo lời dạy này, thiện hữu hãy dùng trí thấy rõ mối quan hệ nhân quả của năm uẩn, tức các pháp danh và sắc, cả trong các oai nghi đi, đứng, ngồi, nằm và trong những hoạt động thực hành tỉnh giác. Hãy quán các pháp nhân và quả trong khả năng của mình.


<a id="M05-body-P197"></a>
## Lời nguyện cuối cuốn
Miến / Burmese 197

“Nguyện quý vị có thể nỗ lực tinh cần tu tập, trở thành bậc cao quý giữa loài người, bậc chư thiên giữa chư thiên.”

Pa-Auk Tawya Sayadaw

Tu viện Cittala

Rừng Pa-Auk Tawya

Năm 1367 theo lịch Miến Điện.


<a id="M05-index-P001"></a>
## Chỉ mục — Miến 198
Chỉ mục / Index - Miến / Burmese 198

[Trang này để trắng trong bản PDF nguồn.]


<a id="M05-index-P002"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 199
Chỉ mục / Index - Miến / Burmese 199

Chỉ mục theo thứ tự chữ cái Miến

အ

Kiến chấp vô tác dụng (akiriyadiṭṭhi) — 106

Vũ khí tốt nhất — 108

Nghiệp sắp cho quả — 82

Tóm lược để ghi nhớ — 19

Cách quán các pháp nhân và quả — 85

Một trình tự tìm các pháp nhân — 39

Cách quán các pháp bằng cách nối nhân với quả — 114

Một ví dụ khác — 70

Chấp ngã kiến — 104

Năm pháp nhân quá khứ — 20

Sức chi phối của tập khí quá khứ — 92

Lần về cận tử quá khứ — 57

Hãy hướng trí về quá khứ để xem — 46

Điểm đặc biệt cần lưu ý — 109

Nhân vô gián — 156

Năm pháp quả vị lai — 20

Nhân gần nhất (padaṭṭhāna) — 126

Trí hiểu biết (anubodhañāṇa) — 4

Hiểu và thấu triệt (anubodha và paṭivedha) — 14

Suy luận và trực chứng — 29

Lời nguyện của Anojādevī — 63

Phương pháp vô tác giả — 103

Thắng trí và minh sát — 35

Bản Pāli của Abhidhamma Vibhaṅga — 21

Ánh sáng màu sắc — 139

Trí của Tôn giả Ānanda — 2

Trưởng lão A-la-hán Soṇa — 84

Tính chất thấu triệt đúng đắn — 13

Chấp thuyết vô nhân — 107

Vô nhân kiến — 106, 107

Một số điểm thay đổi — 171

အာ

Khoảng trống (ākāsa) — 173


<a id="M05-index-P003"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 200
Chỉ mục / Index - Miến / Burmese 200

Giới hư không — 173

Giới nước — 181

Chất lỏng thuộc giới nước — 181

Kinh Ánh Sáng (Ābhāsutta) — 140

Hành tích lũy (āyūhanasaṅkhāra) — 25

Cảnh — 120

Ánh sáng — 140

Nhân của sắc do vật thực sinh — 87

Nghiệp nâng đỡ — 83

ဣ

Cách quán trong các oai nghi và khi tỉnh giác — 196

ဥ

Học hỏi (uggaha) — 6

Đoạn kiến và thường kiến — 98

ဧ

Phương pháp đồng nhất — 90, 99

Biết phương pháp đồng nhất — 98

Phương pháp tính quy luật — 106

က

Nghiệp làm cạn kiệt nghiệp — 74

Sức mạnh của nghiệp duyên — 25

Nghiệp hữu — 25

Hai pháp thuộc vòng nghiệp — 53, 79

Gọi là năng lực nghiệp — 27

Thân do vật chất tạo thành (karajakāya) — 120

Năm uẩn tái tục ở sát-na đầu của phôi kalala — 112

Sắc trong sáng của thân — 183

Vòng phiền não và vòng nghiệp — 51, 75

Ba pháp thuộc vòng phiền não — 52, 77

Trích Kinh Nhà Có Nóc Nhọn (Kūṭāgārasutta) — 31

Công chúa, con vua Kosala — 61

Cách tìm cảnh nghiệp — 60

Khi đã thấy biết đúng đắn — 106

Thấy biết đúng đắn — 104

Thế nào là thấy biết đúng đắn? — 103

Thai nhi còn nhỏ — 116


<a id="M05-index-P004"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 201
Chỉ mục / Index - Miến / Burmese 201

Cảnh tượng đau lòng — 68

Điểm chính cần ghi nhớ trước — 86

Một điểm cần lưu ý trước — 44

Cù lao nương bãi bồi, bãi bồi nương cù lao — 122

ခ

Cách phân thành năm uẩn — 110

Có vẻ khó, và quả thật là khó. Có vẻ sâu, và quả thật là sâu — 93

Hũ sữa chua — 99

ဂ

Lộ cảnh hương, tức mùi — Tỷ thức — Thọ uẩn — 177

Lộ cảnh hương, tức mùi — Hướng ngũ môn — Thọ uẩn — 176

Lộ cảnh hương, tức mùi — Suy đạc — Thọ uẩn — 179

Lộ cảnh hương, tức mùi — Tiếp thâu — Thọ uẩn — 178

စ

Nhãn thức — Sắc uẩn — 138

Nhãn thức — Thức uẩn — 141

Nhãn thức — Thọ uẩn — 138

Nhãn thức — Hành uẩn — 141

Nhãn thức — Tưởng uẩn — 140

Hạt giống hạnh và hạt giống minh — 191

Kinh Giáo Giới Rāhula Ngắn (Cūḷarāhulovādasutta) — 165

Lời nguyện của Cūḷasubhaddā — 67

Gọi là Tiểu Nhập Lưu — 195

Kinh Tư (Cetanāsutta) — 73

Năng lực nghiệp — 54

Chính năng lực nghiệp ấy là nghiệp — 54

ဆ

Chuyện voi chúa Chaddanta — 64

Lời nguyện — 71


<a id="M05-index-P005"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 202
Chỉ mục / Index - Miến / Burmese 202

ဇ

Nghiệp sản sinh (janakakamma) — 83

Tác ý dẫn đầu tốc hành (javanapaṭipādakamanasikāra) — 151

Trí nhớ đời trước (jātissarañāṇa) — 64

ဉ

Liễu tri bằng nhận biết — 11

Đạt đến tuệ liễu tri bằng nhận biết — 193

Gọi là liễu tri bằng nhận biết — 12, 194

Biết bằng liễu tri bằng nhận biết — 15

တ

Chính ái được gọi là thủ — 51

Chủ trương của ngoại đạo — 6

Kinh Các Xứ Của Ngoại Đạo (Titthāyatanasutta) — 21

Gọi là liễu tri bằng thẩm sát — 12

Từng phần, từng trường hợp — 189

Cùng một dòng, cùng một nhóm tâm — 123

ဒ

Nghiệp sẽ được cảm thọ ngay trong đời này — 28

Trường hợp phát nguyện thứ hai — cõi Phạm thiên — 54

Tốc hành thứ hai — Thọ uẩn — 186

Bốn cách thuyết giảng — 42

ဓ

Trí biết sự tồn tại của các pháp do duyên — 39

Một quy luật tự nhiên — 35

Lộ cảnh pháp — Lộ tốc hành thiện lấy nhãn tịnh sắc làm cảnh — 185

Lộ cảnh pháp — Lộ chứng sơ thiền lấy tợ tướng hơi thở làm cảnh — 187

Lộ cảnh pháp — Sắc pháp làm cảnh — 188

Cận sự nam Dhammika — 85

Ghi nhớ (dhāraṇā) — 7

န

Phương pháp sai biệt — 100

Nghiệp khác sát-na — 26

Tuệ phân biệt danh sắc — 11

Tuệ phân định danh sắc — 40

Sự thay đổi của tướng — 84

Thuyết định mệnh — 107

Thế nào là thuyết định mệnh? — 107

Bốn phương pháp — 90

Sắc pháp của chư thiên — 94

Dòng tương tục của chư thiên — 94


<a id="M05-index-P006"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 203
Chỉ mục / Index - Miến / Burmese 203

Bốn danh uẩn — 88

Thế nào là danh? — 128

Một con bò — 82

ပ

Tuệ phân biệt nhân duyên — 10

Để đạt tuệ phân biệt nhân duyên — 34

Phần tuệ phân biệt nhân duyên — 81

Thế nào là tuệ phân biệt nhân duyên? — 34

Pháp được trợ (paccayuppannadhamma) — 41

Gọi là pháp được trợ — 41

Năm pháp quả hiện tại — 20

Năm pháp nhân hiện tại — 20

Hướng ngũ môn — Sắc uẩn — 134

Hướng ngũ môn — Thức uẩn — 137

Hướng ngũ môn — Thọ uẩn — 135

Hướng ngũ môn — Hành uẩn (tư, cách thứ nhất) — 136

Hướng ngũ môn — Hành uẩn (tám tâm sở, cách thứ hai) — 136

Hướng ngũ môn — Tưởng uẩn — 135

Cảnh chế định — 187

Cách Đức Phật thuyết pháp Duyên khởi — 42

Tóm lược Duyên khởi theo phương pháp thứ năm để ghi nhớ — 17

Thế nào là quy luật Duyên khởi? — 42

Sắc uẩn tái tục — 115

Tái tục — Thức uẩn — 127

Tái tục — Thọ uẩn — 117

Tái tục — Hành uẩn — 125

Tái tục — Tưởng uẩn — 124

Tái tục là thức — 18

Tốc hành thứ nhất — Thọ uẩn — 187

Tốc hành thứ nhất — Thọ uẩn (lộ ý môn) — 185

Giới đất — 183

Ba loại trí liễu tri — 3

Hỏi thêm (paripucchā) — 7

Gọi là liễu tri bằng đoạn trừ — 12

Tư trước khi làm — 24

Quy ước gọi tên theo nghĩa có trước (pubbūpacārasammuti) — 5

Cảnh của thắng trí nhớ các đời trước — 37


<a id="M05-index-P007"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 204
Chỉ mục / Index - Miến / Burmese 204

Một bức tranh — 64

ဖ

Xúc — 122

Lộ cảnh xúc — Thân thức — Thọ uẩn — 183

Lộ cảnh xúc — Hướng ngũ môn — Thọ uẩn — 182

Lộ cảnh xúc — Suy đạc — Thọ uẩn — 185

Lộ cảnh xúc — Tiếp thâu — Thọ uẩn — 184

ဗ

Bên ngoài, nhiều đời quá khứ và nhiều đời vị lai — 190

Bahussutabhāva — sự đa văn — 8

Thế nào là người đa văn? — 9

Sắc pháp của chư Phạm thiên — 94

Dòng tương tục của chư Phạm thiên — 94

Vị từ cõi Phạm thiên tái sinh xuống đây — 93

ဘ

Nhân vô gián của hữu phần — 192

Năm uẩn của hữu phần — 129

Gọi là hữu phần — 192

Hữu phần — Sắc uẩn — 130

Hữu phần — Thức uẩn — 133

Hữu phần — Thọ uẩn — 131

Hữu phần — Hành uẩn — 132

Hữu phần — Tưởng uẩn — 132

Thế nào là hữu phần? — 91

Ái ấy có từ khi nào? — 23

မ

Tác ý dẫn đầu lộ tâm (vīthipaṭipādakamanasikāra) — 139

Thế nào là tác ý? — 139

Hướng ý môn — Thọ uẩn — 162

Tốc hành đại thiện thứ hai — Thọ uẩn — 157, 163

Tốc hành đại thiện thứ nhất — Thức uẩn — 155


<a id="M05-index-P008"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 205
Chỉ mục / Index - Miến / Burmese 205

Tốc hành đại thiện thứ nhất — Thọ uẩn — 153, 162

Tốc hành đại thiện thứ nhất — Hành uẩn — 154

Tốc hành đại thiện thứ nhất — Tưởng uẩn — 154

Lời tuyên bố trong Kinh Đại Duyên — 1

Tâm đăng ký đại quả thứ nhất — Thức uẩn — 160

Tâm đăng ký đại quả thứ nhất — Thọ uẩn — 158

Tư trong khi làm — 24

Hoàng hậu Subhaddā — 64

Hạt giống và cây — 98

Quy luật tự nhiên — 104

ယ

Một ví dụ của hành giả — 69

ရ

Lộ cảnh vị — Thiệt thức — Thọ uẩn — 180

Lộ cảnh vị — Hướng ngũ môn — Thọ uẩn — 180

Lộ cảnh vị — Suy đạc — Thọ uẩn — 182

Lộ cảnh vị — Tiếp thâu — Thọ uẩn — 181

Sắc uẩn — 87

Lộ cảnh sắc, tức màu sắc — Năm uẩn ở tốc hành thiện thứ nhất — 152

Lộ cảnh sắc, tức màu sắc — Năm uẩn của nhãn thức, tức tâm thấy — 137

Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm hướng ngũ môn — 133

Lộ cảnh sắc, tức màu sắc — Năm uẩn ở tâm đăng ký — 158

Lộ cảnh sắc, tức màu sắc — Năm uẩn ở tốc hành tham hợp tà kiến — 167

Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm xác định — 148

Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm suy đạc — 145

Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm tiếp thâu — 142


<a id="M05-index-P009"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 206
Chỉ mục / Index - Miến / Burmese 206

Các lộ ý môn lấy cảnh sắc làm đối tượng — 161

Sắc thủ uẩn — 111

Việc cần thực hành khi hình ảnh sắc hiện ra — 55

Giải thích về nhãn xúc và ý xúc — 164

Giải thích về vật — 119

လ

Tái tục của loài người — 57

Ba loại liễu tri hiệp thế — 11

Ba loại liễu tri siêu thế — 13

Tốc hành tham hợp tà kiến thứ hai — Thức uẩn (lộ nhãn môn) — 169

Tốc hành tham hợp tà kiến thứ hai — Thọ uẩn (lộ nhãn môn) — 169

ဝ

Nghiệp thiện đưa đến luân hồi — 49

Sự thật về vòng luân hồi — 31

Gọi là sắc vật — 121

Giới gió — 178

Dấu vết của tập khí — 93

Thức uẩn (lộ nhãn môn) — 168

Thức thủ uẩn — 111

Sự thật về sự thoát khỏi vòng luân hồi — 31

Tâm ngoài lộ — 88, 110

Xác định — Thức uẩn — 151

Xác định — Thọ uẩn — 149

Xác định — Hành uẩn — 150

Xác định — Tưởng uẩn — 149

Thọ thủ uẩn — 111

သ

Chỉ có những nhóm hành thuần túy — 194

Hành và nghiệp hữu — 24

Hành thủ uẩn — 111

Tưởng thủ uẩn — 111

Điểm cần lưu ý — 170

Lộ cảnh thinh, tức âm thanh — Hướng ngũ môn — Thọ uẩn — 171


<a id="M05-index-P010"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 207
Chỉ mục / Index - Miến / Burmese 207

Lộ cảnh thinh, tức âm thanh — Suy đạc — Thọ uẩn — 175

Lộ cảnh thinh, tức âm thanh — Tiếp thâu — Thức uẩn — 174

Lộ cảnh thinh, tức âm thanh — Tiếp thâu — Hành uẩn (cách thứ hai) — 173

Lộ cảnh thinh, tức âm thanh — Nhĩ thức, tức tâm nghe — Thọ uẩn — 172

Suy đạc — Thức uẩn — 148

Suy đạc — Thọ uẩn — 145

Suy đạc — Hành uẩn — 147

Suy đạc — Tưởng uẩn — 146

Hành giả lấy thiền chỉ làm cỗ xe — 50

Nếu là hành giả lấy thiền chỉ làm cỗ xe — 50

Thế nào là sự thật về nguồn gốc khổ? — 21

Tiếp thâu — Thức uẩn — 144

Tiếp thâu — Thọ uẩn — 142

Tiếp thâu — Hành uẩn — 143

Tiếp thâu — Tưởng uẩn — 143

Nghe học (savana) — 6

Bén rễ đến mức không thể lìa Giáo pháp — 195

Thế nào là sự thật được nghe (sutasacca)? — 10

Lời nguyện trước kia của công chúa Sumanā — 61

Bồ-tát khi sắp qua đời — 59

Sotāpannatā — sự thành tựu Nhập lưu — 7

Nếu tự cho mình là bậc Nhập lưu — 8

Thế nào là bậc Nhập lưu? — 5

Khi thấy được ba hoặc bốn đời — 96

ဟ

Sắc ý vật — 120

❂ ❂ ❂
