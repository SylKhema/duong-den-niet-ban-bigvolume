# Nibbānagāminipaṭipadā · Mini · Cuốn 5 / Volume 5
Dependent Origination — A
Pa-Auk Tawya Sayadaw
English

## Mục lục / Contents

- [Front and back cover](#M05-cover-P001)
- [Title page](#M05-front-P001)
- [The gift of Dhamma and aspiration](#M05-front-P002)
- [Contents — first page](#M05-front-P003)
- [Table of contents — ခ](#M05-front-P004)
- [Table of contents — ဂ](#M05-front-P005)
- [Table of contents — ဃ](#M05-front-P006)
- [Table of contents — င](#M05-front-P007)
- [Table of contents — စ](#M05-front-P008)
- [Table of contents — ဆ](#M05-front-P009)
- [Part 1. The declaration in the Mahānidāna Sutta](#M05-body-P001)
- [Four ways of discerning dependent origination and Ānanda’s statement](#M05-body-P002)
- [The depth of dependent origination and the three kinds of full understanding](#M05-body-P003)
- [Breaking the wheel of becoming with the sword of knowledge](#M05-body-P004)
- [Why dependent origination appeared plain to Venerable Ānanda](#M05-body-P005)
- [Former supporting conditions and living near a good ford](#M05-body-P006)
- [Learning from teachers and attaining stream-entry](#M05-body-P007)
- [Seeing the causal connection for oneself](#M05-body-P008)
- [Learning and the knowledge that distinguishes mentality and materiality](#M05-body-P009)
- [The wealth of learning](#M05-body-P010)
- [Knowledge that discerns conditions and the three kinds of mundane full understanding](#M05-body-P011)
- [Full understanding as knowing, investigation, and abandoning](#M05-body-P012)
- [Three kinds of supramundane full understanding](#M05-body-P013)
- [Supramundane full understanding as investigation](#M05-body-P014)
- [Understanding through the repeated arising of knowledge](#M05-body-P015)
- [Functions of the noble path and directly seeing conditions](#M05-body-P016)
- [A summary of dependent origination by the fifth method](#M05-body-P017)
- [Five past causes and five present results](#M05-body-P018)
- [Five present causes and five future results](#M05-body-P019)
- [Five causes and five results across the three periods](#M05-body-P020)
- [The truth of origin taught in five ways](#M05-body-P021)
- [The chain of dependent origination and the noble truth of the origin of suffering](#M05-body-P022)
- [Which craving is the origin of present suffering?](#M05-body-P023)
- [Distinguishing formations and kamma-becoming](#M05-body-P024)
- [Volition, formations, and the power of kamma condition](#M05-body-P025)
- [Asynchronous kamma and the time of ripening](#M05-body-P026)
- [Why it is called asynchronous kamma condition](#M05-body-P027)
- [Past conditions and the time needed to cultivate the perfections](#M05-body-P028)
- [Inference and direct experience](#M05-body-P029)
- [Knowing the four noble truths as they really are](#M05-body-P030)
- [Two truths of the round and two truths of release from the round](#M05-body-P031)
- [The condition for making an end of suffering](#M05-body-P032)
- [Striving to realize the four noble truths directly](#M05-body-P033)
- [To attain knowledge of discerning conditions](#M05-body-P034)
- [Distinct deeds, distinct results, and two ways of knowing the past](#M05-body-P035)
- [Recollecting former lives in the Khajjanīya Sutta](#M05-body-P036)
- [The objects of direct knowledge of former lives](#M05-body-P037)
- [Discerning past aggregates with insight knowledge](#M05-body-P038)
- [Part 2. A procedure for finding the causes](#M05-body-P039)
- [Apprehending results before looking for causes](#M05-body-P040)
- [Mentality and materiality in the past, present, and future](#M05-body-P041)
- [Four ways of teaching dependent origination](#M05-body-P042)
- [Reverse order and the fifth method](#M05-body-P043)
- [Tracing from the middle to the beginning and the principle of many causes and results](#M05-body-P044)
- [Why a teaching sometimes singles out one cause](#M05-body-P045)
- [Apprehending the associated phenomena as well](#M05-body-P046)
- [Using concentration and light to apprehend mentality and materiality](#M05-body-P047)
- [Further ways of looking for past causes](#M05-body-P048)
- [Making an aspiration and apprehending mentality and materiality before sitting](#M05-body-P049)
- [Apprehending recent mentality and materiality for a tranquillity practitioner](#M05-body-P050)
- [The rounds of defilements and kamma](#M05-body-P051)
- [Three phenomena in the round of defilements](#M05-body-P052)
- [Two phenomena in the round of kamma](#M05-body-P053)
- [Kammic power and the case of aspiring to a brahmā realm](#M05-body-P054)
- [Procedure when an image appears](#M05-body-P055)
- [Tracing back through past mentality and materiality step by step](#M05-body-P056)
- [From rebirth-linking to the death-proximate period of the preceding life](#M05-body-P057)
- [Finding the death-proximate object and tracing back to the causal kamma](#M05-body-P058)
- [When an image of a dying person or a corpse appears](#M05-body-P059)
- [Finding the object of death-proximate impulsion](#M05-body-P060)
- [Finding the succession of consciousness when kamma was made](#M05-body-P061)
- [Five causes in Princess Sumanā’s aspiration](#M05-body-P062)
- [Five causes in Anojādevī’s aspiration](#M05-body-P063)
- [The result of Anojā’s aspiration and the story of Queen Subhaddā](#M05-body-P064)
- [The two she-elephants and the circumstances of their offering](#M05-body-P065)
- [Giving with the requisite conditions and Cūḷasubhaddā’s aspiration](#M05-body-P066)
- [The aspiration for revenge and the five causal phenomena](#M05-body-P067)
- [Chaddanta and the hunter Soṇuttara](#M05-body-P068)
- [An example from a meditator](#M05-body-P069)
- [Discerning cause and effect, and another example](#M05-body-P070)
- [Insight kamma and aspirations](#M05-body-P071)
- [Insight kamma can give a rebirth result](#M05-body-P072)
- [Burmese page 73](#M05-body-P073)
- [Burmese page 74](#M05-body-P074)
- [Burmese page 75](#M05-body-P075)
- [Burmese page 76](#M05-body-P076)
- [Burmese page 77](#M05-body-P077)
- [Burmese page 78](#M05-body-P078)
- [Two phenomena in the round of kamma](#M05-body-P079)
- [Burmese page 80](#M05-body-P080)
- [Knowledge of discerning conditions](#M05-body-P081)
- [Burmese page 82](#M05-body-P082)
- [Burmese page 83](#M05-body-P083)
- [Changes in the sign](#M05-body-P084)
- [How to discern causes and effects](#M05-body-P085)
- [Main points to bear in mind](#M05-body-P086)
- [The materiality aggregate](#M05-body-P087)
- [The four mental aggregates](#M05-body-P088)
- [Burmese page 89](#M05-body-P089)
- [The four methods — 1. The method of identity](#M05-body-P090)
- [Burmese page 91](#M05-body-P091)
- [The distinguishing marks of the past](#M05-body-P092)
- [Broad, strong light when discerning a past life](#M05-body-P093)
- [Burmese page 94](#M05-body-P094)
- [Burmese page 95](#M05-body-P095)
- [When three or four people appear](#M05-body-P096)
- [Burmese page 97](#M05-body-P097)
- [Annihilationism and eternalism](#M05-body-P098)
- [Burmese page 99](#M05-body-P099)
- [2. The method of diversity](#M05-body-P100)
- [Burmese page 101](#M05-body-P101)
- [Burmese page 102](#M05-body-P102)
- [3. The method of non-agency](#M05-body-P103)
- [Burmese page 104](#M05-body-P104)
- [Burmese page 105](#M05-body-P105)
- [4. The method of regularity](#M05-body-P106)
- [The doctrine of fatalism](#M05-body-P107)
- [Burmese page 108](#M05-body-P108)
- [Part 3. Practical discernment by the five-aggregate method](#M05-body-P109)
- [How to group phenomena into five aggregates](#M05-body-P110)
- [The five aggregates subject to clinging](#M05-body-P111)
- [The five aggregates at the moment of rebirth-linking](#M05-body-P112)
- [Burmese page 113](#M05-body-P113)
- [How to discern causes in connection with their effects](#M05-body-P114)
- [The materiality aggregate at rebirth-linking](#M05-body-P115)
- [Burmese page 116](#M05-body-P116)
- [The feeling aggregate at rebirth-linking](#M05-body-P117)
- [The abbreviated presentation](#M05-body-P118)
- [Rebirth-linking — Feeling aggregate](#M05-body-P119)
- [Burmese page 120](#M05-body-P120)
- [Base and object](#M05-body-P121)
- [Object and contact](#M05-body-P122)
- [Burmese page 123](#M05-body-P123)
- [Rebirth-linking — Perception aggregate](#M05-body-P124)
- [Rebirth-linking — Formations aggregate, first method](#M05-body-P125)
- [Rebirth-linking — Formations aggregate, second method](#M05-body-P126)
- [Rebirth-linking — Consciousness aggregate](#M05-body-P127)
- [Burmese page 128](#M05-body-P128)
- [The five life-continuum aggregates](#M05-body-P129)
- [Life-continuum — Materiality aggregate](#M05-body-P130)
- [Life-continuum — Feeling aggregate](#M05-body-P131)
- [Life-continuum — Perception and formations aggregates](#M05-body-P132)
- [Life-continuum — Formations and consciousness aggregates](#M05-body-P133)
- [Five-door adverting — Materiality aggregate](#M05-body-P134)
- [Five-door adverting — Feeling and perception aggregates](#M05-body-P135)
- [Five-door adverting — Formations aggregate](#M05-body-P136)
- [Five-door adverting — Consciousness aggregate](#M05-body-P137)
- [Eye-consciousness — Materiality and feeling aggregates](#M05-body-P138)
- [Eye-consciousness — Causes of the feeling aggregate](#M05-body-P139)
- [Eye-consciousness — Light and the perception aggregate](#M05-body-P140)
- [Eye-consciousness — Formations and consciousness aggregates](#M05-body-P141)
- [The five aggregates at receiving](#M05-body-P142)
- [Receiving — Feeling, perception, and formations aggregates](#M05-body-P143)
- [Receiving — Formations and consciousness aggregates](#M05-body-P144)
- [The five aggregates at investigating](#M05-body-P145)
- [Investigating — Feeling and perception aggregates](#M05-body-P146)
- [Investigating — Formations aggregate](#M05-body-P147)
- [Investigating — Consciousness aggregate and the five aggregates at determining](#M05-body-P148)
- [Determining — Feeling and perception aggregates](#M05-body-P149)
- [Determining — Formations aggregate](#M05-body-P150)
- [Determining — Consciousness aggregate and attention leading to impulsion](#M05-body-P151)
- [Attention leading to impulsion and the five aggregates at the first wholesome impulsion](#M05-body-P152)
- [First great wholesome impulsion — Feeling aggregate](#M05-body-P153)
- [First great wholesome impulsion — Perception and formations aggregates](#M05-body-P154)
- [First great wholesome impulsion — Formations and consciousness aggregates](#M05-body-P155)
- [Counts of mental phenomena and proximity condition](#M05-body-P156)
- [Second great wholesome impulsion — Feeling aggregate](#M05-body-P157)
- [Five aggregates at registration](#M05-body-P158)
- [First great-resultant registration — Feeling, perception, and formations aggregates](#M05-body-P159)
- [First great-resultant registration — Consciousness aggregate](#M05-body-P160)
- [Counts at registration and the mind-door process](#M05-body-P161)
- [Mind-door adverting and first great wholesome impulsion](#M05-body-P162)
- [First and second great wholesome impulsions in the mind-door process](#M05-body-P163)
- [Explanation of eye-contact and mind-contact](#M05-body-P164)
- [Eye-contact conditions the four mental aggregates](#M05-body-P165)
- [Mind-contact in the mind-door process](#M05-body-P166)
- [Five aggregates at greed-rooted impulsion associated with wrong view](#M05-body-P167)
- [First greed-rooted impulsion associated with wrong view — Feeling and consciousness aggregates](#M05-body-P168)
- [Second greed-rooted impulsion associated with wrong view](#M05-body-P169)
- [Consciousness aggregate and a note on changing objects](#M05-body-P170)
- [Sound and the differences according to object](#M05-body-P171)
- [Sound — Feeling aggregate at ear-consciousness](#M05-body-P172)
- [Space element and formations aggregate at receiving](#M05-body-P173)
- [Sound — Formations and consciousness aggregates at receiving](#M05-body-P174)
- [Sound — Consciousness aggregate at receiving and feeling aggregate at investigating](#M05-body-P175)
- [From sound to odour](#M05-body-P176)
- [Odour — Feeling aggregate at nose-consciousness](#M05-body-P177)
- [Wind element and receiving in the odour-object process](#M05-body-P178)
- [Odour — Feeling aggregate at investigating](#M05-body-P179)
- [Taste — Feeling aggregate at five-door adverting and tongue-consciousness](#M05-body-P180)
- [Water element and receiving in the taste-object process](#M05-body-P181)
- [Taste and tangible objects — Feeling aggregate](#M05-body-P182)
- [Tangible objects — Feeling aggregate at body-consciousness and the earth element](#M05-body-P183)
- [Tangible objects — The earth element and receiving](#M05-body-P184)
- [Tangible and mental objects — Feeling aggregate](#M05-body-P185)
- [Mental objects — Feeling aggregate at the first and second impulsions](#M05-body-P186)
- [First-jhāna attainment process with the breath counterpart sign](#M05-body-P187)
- [Serenity counterpart signs and material phenomena as objects](#M05-body-P188)
- [Individual kammas and their particular results](#M05-body-P189)
- [Discernment externally and across successive lives](#M05-body-P190)
- [Seeds of conduct and seeds of knowledge](#M05-body-P191)
- [Proximity causes of the life-continuum](#M05-body-P192)
- [Reaching full understanding as the known](#M05-body-P193)
- [Causes and effects in the three periods](#M05-body-P194)
- [Taking root in the Dispensation](#M05-body-P195)
- [Suitable conditions and discernment in the postures](#M05-body-P196)
- [Closing aspiration](#M05-body-P197)
- [Index — Burmese page 198](#M05-index-P001)
- [Index in Burmese alphabetical order — 199](#M05-index-P002)
- [Index in Burmese alphabetical order — 200](#M05-index-P003)
- [Index in Burmese alphabetical order — 201](#M05-index-P004)
- [Index in Burmese alphabetical order — 202](#M05-index-P005)
- [Index in Burmese alphabetical order — 203](#M05-index-P006)
- [Index in Burmese alphabetical order — 204](#M05-index-P007)
- [Index in Burmese alphabetical order — 205](#M05-index-P008)
- [Index in Burmese alphabetical order — 206](#M05-index-P009)
- [Index in Burmese alphabetical order — 207](#M05-index-P010)

<a id="M05-cover-P001"></a>
## Front and back cover
Bìa / Cover

Nibbānagāminipaṭipadā — The Practice Leading to Nibbāna (Abridged), Volume 5. Dependent Origination (Paṭiccasamuppāda) — A. Pa-Auk Tawya Sayadaw.

The teaching of dependent origination

The Buddha did not establish or create this principle of dependent origination. Whether or not Buddhas arise, the principle still holds. Only when Buddhas arise and disclose and teach it do beings have the opportunity to know it. If a Buddha does not arise, if people do not hear the teaching when one arises, or if, even after hearing it, they cling to such wrong views as eternalism and annihilationism, they cannot understand this principle of dependent origination.

Dependent origination is deep and appears deep, difficult and appears difficult. When Venerable Ānanda said that it was easy and shallow, the Buddha restrained him: “Mā hevaṃ, Ānanda … Ānanda, do not say so.” However difficult and profound this teaching may be, one who has yet to know dependent origination clearly cannot escape the suffering of saṃsāra. One who has yet to know this teaching does not deserve to be called an ascetic or a brahmin.

The Buddhas of the past, present, and future attain Buddhahood through clearly knowing dependent origination. As long as beings have yet to know it clearly, they continue to fall into one of two abysses, eternalism and annihilationism, and undergo all kinds of suffering. Therefore, in the Nidānasaṃyutta the Buddha taught that anyone wishing to escape the suffering of saṃsāra must strive to penetrate this teaching of dependent origination. (From the nissaya of the Nidānavaggasaṃyutta.)


<a id="M05-front-P001"></a>
## Title page
Đầu sách / Front matter - 1

Nibbānagāminipaṭipadā — The Practice Leading to Nibbāna (Abridged), Volume 5. Dependent Origination (Paṭiccasamuppāda) — A. Pa-Auk Tawya Sayadaw.


<a id="M05-front-P002"></a>
## The gift of Dhamma and aspiration
Đầu sách / Front matter - 2

Sabbadānaṃ dhammadānaṃ jināti.
Sabbarasaṃ dhammaraso jināti.
Sabbaratiṃ dhammarati jināti.
Taṇhakkhayo sabbadukkhaṃ jināti.

The gift of Dhamma surpasses every gift.
The taste of Dhamma surpasses every taste.
Delight in Dhamma surpasses every delight.
The destruction of craving overcomes all suffering.

Ciraṃ tiṭṭhatu saddhammo, dhamme hontu sagāravā.

May the Buddha’s dispensation endure for a long time. May all honour the three kinds of true Dhamma.


<a id="M05-front-P003"></a>
## Contents — first page
Đầu sách / Front matter - 3

Namo tassa bhagavato arahato sammāsambuddhassa.

Dependent Origination (Paṭiccasamuppāda) — A. Contents.

Part 1 — 1

The declaration in the Great Discourse on Causation — 1

What is a stream-enterer? — 5

Conventional designation by anticipation (pubbūpacārasammuti) — 5

The doctrine of other sectarians — 6

Sotāpannatā — becoming a stream-enterer — 7

Bahussutabhāva — being learned — 8

What is a learned person? — 9

Three kinds of mundane full understanding — 11

Three kinds of supramundane full understanding — 13

Understanding and penetration (anubodha and paṭivedha) — 14

A summary of dependent origination by the fifth method for memorization — 17

What is the truth of the origin of suffering? — 21

When did that cause arise? — 23

Formations and kamma-becoming — 24

The power of kamma condition — 25

Inference and direct experience — 29

An excerpt from the Discourse on the Peaked House (Kūṭāgārasutta) — 31

To attain knowledge of discerning conditions (paccayapariggahañāṇa) — 34

Direct knowledge and insight — 35


<a id="M05-front-P004"></a>
## Table of contents — ခ
Đầu sách / Front matter - 4

Subject — Page

Part 2 — 39

A sequence for finding causes — 39

How the Buddha taught dependent origination — 42

Four ways of teaching — 42

A point to note beforehand — 44

Direct knowledge into the past — 46

For a practitioner whose vehicle is serenity — 50

The rounds of defilements and kamma — 51

The three factors in the round of defilements — 52

The two factors in the round of kamma — 53

Second aspiration — the Brahmā realm — 54

What to practise when an image of materiality appears — 55

Tracing back to the approach of death in the past — 57

How to find the kamma object — 60

Princess Sumanā’s former aspiration — 61

Anojādevī’s aspiration — 63

Queen Subhaddā — 64

An example from a practitioner — 69

Another example — 70

The rounds of defilements and kamma — 75

The three factors in the round of defilements — 77

The two factors in the round of kamma — 79

Knowledge of discerning causes and conditions — 81

Changes in the sign — 84


<a id="M05-front-P005"></a>
## Table of contents — ဂ
Đầu sách / Front matter - 5

Subject — Page

How to discern causes and effects — 85

The main point to remember beforehand — 86

The materiality aggregate — 87

The four mental aggregates — 88

Four methods — 1. The method of identity — 90

The influence of past habits — 92

It seems difficult and is difficult. It seems deep and is deep — 93

When three or four lives are seen — 96

Annihilationism and eternalism — 98

2. The method of diversity — 100

3. The method of non-agency — 103

4. The method of regularity — 106

Fatalism — 107

Part 3 — 109

Practical discernment by way of the five aggregates — 109

A particular point to note — 109

How to classify the five aggregates — 110

The five rebirth-linking aggregates at the first kalala moment — 112

How to discern by relating causes and effects — 114

The materiality aggregate at rebirth-linking — 115

Rebirth-linking — Feeling aggregate — 117

Explanation — 1. Base — 119

2. Object — 120


<a id="M05-front-P006"></a>
## Table of contents — ဃ
Đầu sách / Front matter - 6

Subject — Page

3. Contact — 122

Rebirth-linking — Perception aggregate — 124

Rebirth-linking — Formations aggregate — 125

Rebirth-linking — Consciousness aggregate — 127

The five aggregates at the life-continuum — 129

Life-continuum — Materiality aggregate — 130

Life-continuum — Feeling aggregate — 131

Life-continuum — Perception aggregate — 132

Life-continuum — Formations aggregate — 132

Life-continuum — Consciousness aggregate — 133

Visual-object process — Five aggregates at five-door adverting — 133

Five-door adverting — Materiality aggregate — 134

Five-door adverting — Feeling aggregate — 135

Five-door adverting — Perception aggregate — 135

Five-door adverting — Formations aggregate (volition, first method) — 136

Five-door adverting — Formations aggregate (eight mental factors, second method) — 136

Five-door adverting — Consciousness aggregate — 137

Visual-object process — Five aggregates at eye-consciousness, the consciousness that sees — 137

Eye-consciousness — Materiality aggregate — 138

Eye-consciousness — Feeling aggregate — 138

Attention that leads the cognitive process (vīthipaṭipādakamanasikāra) — 139

Light — 140

Eye-consciousness — Perception aggregate — 140

Eye-consciousness — Formations aggregate — 141

Eye-consciousness — Consciousness aggregate — 141


<a id="M05-front-P007"></a>
## Table of contents — င
Đầu sách / Front matter - 7

Subject — Page

Visual-object process — Five aggregates at receiving — 142

Receiving — Feeling aggregate — 142

Receiving — Perception aggregate — 143

Receiving — Formations aggregate — 143

Receiving — Consciousness aggregate — 144

Visual-object process — Five aggregates at investigating — 145

Investigating — Feeling aggregate — 145

Investigating — Perception aggregate — 146

Investigating — Formations aggregate — 147

Investigating — Consciousness aggregate — 148

Visual-object process — Five aggregates at determining — 148

Determining — Feeling aggregate — 149

Determining — Perception aggregate — 149

Determining — Formations aggregate — 150

Determining — Consciousness aggregate — 151

Attention that leads to impulsion (javanapaṭipādakamanasikāra) — 151

Visual-object process — Five aggregates at the first wholesome impulsion — 152

First great wholesome impulsion — Feeling aggregate — 153

First great wholesome impulsion — Perception aggregate — 154

First great wholesome impulsion — Formations aggregate — 154

First great wholesome impulsion — Consciousness aggregate — 155

Second great wholesome impulsion — Feeling aggregate — 157

Visual-object process — Five aggregates at registration — 158

First great-resultant registration — Feeling aggregate — 158

First great-resultant registration — Consciousness aggregate — 160


<a id="M05-front-P008"></a>
## Table of contents — စ
Đầu sách / Front matter - 8

Subject — Page

Mind-door processes taking a visual object — 161

Mind-door adverting — Feeling aggregate — 162

First great wholesome impulsion — Feeling aggregate — 162

Second great wholesome impulsion — Feeling aggregate — 163

Explanation of eye-contact and mind-contact — 164

Visual-object process — Five aggregates at greed-rooted impulsion associated with wrong view — 167

First greed-rooted impulsion associated with wrong view — Feeling and consciousness aggregates (eye-door process) — 168

Second greed-rooted impulsion associated with wrong view — Feeling aggregate (eye-door process) — 169

Second greed-rooted impulsion associated with wrong view — Consciousness aggregate (eye-door process) — 169

A point to note — 170

Some differences — 171

Sound-object process — Five-door adverting — Feeling aggregate — 171

Sound-object process — Ear-consciousness, the consciousness that hears — Feeling aggregate — 172

Space (ākāsa) — 173

Sound-object process — Receiving — Formations aggregate (second method) — 173

Sound-object process — Receiving — Consciousness aggregate — 174

Sound-object process — Investigating — Feeling aggregate — 175

Odour-object process — Five-door adverting — Feeling aggregate — 176

Odour-object process — Nose-consciousness — Feeling aggregate — 177

The wind element — 178

Odour-object process — Receiving — Feeling aggregate — 178

Odour-object process — Investigating — Feeling aggregate — 179

Taste-object process — Five-door adverting — Feeling aggregate — 180

Taste-object process — Tongue-consciousness — Feeling aggregate — 180


<a id="M05-front-P009"></a>
## Table of contents — ဆ
Đầu sách / Front matter - 9

Subject — Page

The water element — 181

Taste-object process — Receiving — Feeling aggregate — 181

Taste-object process — Investigating — Feeling aggregate — 182

Tangible-object process — Five-door adverting — Feeling aggregate — 182

Tangible-object process — Body-consciousness — Feeling aggregate — 183

The earth element — 183

Tangible-object process — Receiving — Feeling aggregate — 184

Tangible-object process — Investigating — Feeling aggregate — 185

Mental-object process — Wholesome impulsions taking eye-sensitivity as object — 185

First impulsion — Feeling aggregate (mind-door process) — 185

Second impulsion — Feeling aggregate — 186

Mental-object process — First-jhāna attainment taking the breath counterpart sign as object — 187

First impulsion — Feeling aggregate — 187

Mental-object process — Material phenomena as objects — 188

Each case individually — 189

Externally, across successive past and future lives — 190

Seeds of conduct and seeds of knowledge — 191

Proximity causes of the life-continuum — 192

Reaching full understanding as the known — 193

Taking root so as to be unable to leave the Dispensation — 195

Discernment in the postures and with clear comprehension — 196

❂ ❂ ❂


<a id="M05-body-P001"></a>
## Part 1. The declaration in the Mahānidāna Sutta
Miến / Burmese 1

Nibbānagāminipaṭipadā — The Practice Leading to Nibbāna (Abridged), Volume 5. Dependent Origination (Paṭiccasamuppāda) — A.

Namo tassa bhagavato arahato sammāsambuddhassa.

Part 1. The declaration in the Great Discourse on Causation (Mahānidānasutta).

At that time the Buddha was staying in the country of the Kurus, relying on the town of Kammāsadhamma for alms. On the day the Buddha was to give the Great Discourse on Causation, Venerable Ānanda went to his daytime retreat, sat down, and entered the fruition attainment of stream-entry. When the time he had determined elapsed, he emerged from that attainment and directed his mind to dependent origination, also called the pattern of conditions (paccayākāra). Venerable Ānanda discerned it in the following ways:

1. From ignorance to aging and death, in the forward order of dependent origination (anuloma).
2. From aging and death to ignorance, in the reverse order of dependent origination (paṭiloma).


<a id="M05-body-P002"></a>
## Four ways of discerning dependent origination and Ānanda’s statement
Miến / Burmese 2

3. From both ends toward the middle, in the forward and reverse orders of dependent origination.
4. From the middle toward both ends, in the forward and reverse orders of dependent origination.

He developed insight into each of the twelve factors of dependent origination in turn, using all four methods, as one might trace lines on the ground. As Venerable Ānanda developed insight in this way, the relation between cause and effect in dependent origination, also called the pattern of conditions (paccayākāra), became clear to his knowledge.

He thought that if he presented this to the Buddha, he might hear a fine discourse. That evening he went to the Buddha, paid homage, sat to one side, and said:

“It is wonderful, venerable sir! It is astonishing, venerable sir! This dependent origination is very deep and appears deep, yet to me it seems quite plain, venerable sir.”

The Buddha then taught the Great Discourse on Causation to Venerable Ānanda. The following passage is an excerpt from that discourse.


<a id="M05-body-P003"></a>
## The depth of dependent origination and the three kinds of full understanding
Miến / Burmese 3

Mā hevaṃ, Ānanda, avaca, mā hevaṃ, Ānanda, avaca. Gambhīro cāyaṃ, Ānanda, paṭiccasamuppādo gambhīrāvabhāso ca. Etassa, Ānanda, dhammassa ananubodhā appaṭivedhā evamayaṃ pajā tantākulakajātā kulagaṇṭhikajātā muñjapabbajabhūtā apāyaṃ duggatiṃ vinipātaṃ saṃsāraṃ nātivattati. (Dīgha, vol. 2, p. 47.)

Ananubodhāti ñātapariññāvasena ananubujjhanā. Appaṭivedhāti tīraṇapahānapariññāvasena appaṭivijjhanā. (Dīgha Commentary, vol. 2, p. 85.)

“Ānanda, do not say so. Ānanda, do not say so. This relation of cause and effect, the teaching of dependent origination, is deep. Because it is deep, it also appears deep.”

“Ānanda, because beings have not understood and penetrated that relation of cause and effect by the three kinds of full understanding—full understanding as knowing (ñātapariññā), as investigation (tīraṇapariññā), and as abandoning (pahānapariññā)—in this long round of rebirths they are tangled like a skein of thread, knotted like a bundle of fibres, and matted like muñja and pabbaja grasses. They cannot pass beyond the round of rebirths in the realms of misery, bad destinations, and states of downfall, where wrongdoers go, deprived of well-being and subject to ruin. They cannot pass beyond the round of rebirths in the good destinations outside those realms of misery either.” (Dīgha, vol. 2, p. 47.)

Drawing on the teaching above, the commentators then make the following determination.


<a id="M05-body-P004"></a>
## Breaking the wheel of becoming with the sword of knowledge
Miến / Burmese 4

Ñāṇāsinā samādhipavarasilāya sunisitena —
Bhavacakkamapadāletvā, asanivicakkamiva niccanimmathaṃ.
Saṃsārabhayamatīto, na koci supinantarepyatthi.
(Abhidhamma Commentary, vol. 2, p. 189. Visuddhimagga, vol. 2, p. 221.)

The sword of knowledge is honed on the excellent whetstone of concentration. The wheel of becoming, the causal connection of dependent origination within saṃsāra, continually grinds down and oppresses beings like a wheel of thunderbolts. Without breaking that wheel with this sword, no one has ever passed beyond the great danger of suffering in saṃsāra, even in a dream. (Abhidhamma Commentary, vol. 2, p. 189. Visuddhimagga, vol. 2, p. 221.)

In accordance with the Pāli and the commentary above, a good person who seeks the true Dhamma and aspires to the sublime peace of Nibbāna must strive to know the causal connection of dependent origination clearly through three kinds of full understanding: full understanding as knowing (ñātapariññā), called understanding (anubodha), and full understanding as investigation (tīraṇapariññā) and as abandoning (pahānapariññā), called penetration (paṭivedha). The Buddha himself taught that beings have yet to pass beyond saṃsāra because they have not repeatedly known it through understanding and have not personally penetrated it through to the moments of path and fruition. Those who wish to escape saṃsāra must therefore strive for deep knowledge through both understanding and penetration. This is a task that calls for effort to know it for oneself. As for feeling one’s way guided solely by a teacher’s words…


<a id="M05-body-P005"></a>
## Why dependent origination appeared plain to Venerable Ānanda
Miến / Burmese 5

…understand that this task cannot be accomplished in that way.

What is a stream-enterer?

The causal connection of dependent origination is deep and appears deep, difficult and appears difficult. Why, then, did it appear to Venerable Ānanda’s knowledge to be “easy to understand, as though shallow”? The answer is as follows.

Therassa hi catūhi kāraṇehi gambhīropi paṭiccasamuppādo uttānoti upaṭṭhāsi. Katamehi catūhi? Pubbūpanissayasampattiyā, titthavāsena, sotāpannatāya, bahussutabhāvenāti. (Dīgha Commentary, vol. 2, p. 78.)

For the following four reasons, the causal connection of dependent origination, though deep and difficult, appeared clear to Venerable Ānanda’s knowledge:
1. Pubbūpanissayasampatti — possessing the perfections cultivated in former lives.
2. Titthavāsa — continually living near the good fords in the dispensation.
3. Sotāpannatā — having become a stream-enterer.
4. Bahussutabhāva — being learned in the teachings.

It was owing to these four conditions that the causal connection of dependent origination, deep and difficult as it is…


<a id="M05-body-P006"></a>
## Former supporting conditions and living near a good ford
Miến / Burmese 6

…appeared clearly to Venerable Ānanda’s knowledge.

1. Pubbūpanissayasampatti. In the dispensation of Buddha Padumuttara, Venerable Ānanda made an aspiration and cultivated the perfections for a hundred thousand aeons in order to attain foremost rank in five respects. All the perfections accumulated through many lives for the great disciple’s awakening that would enable him to hold these five foremost ranks were now fulfilled in his continuity. This is one condition.

2. Titthavāsa. Good fords on the way to Nibbāna are called tittha. The Perfectly Awakened Buddha and his foremost great disciples can correctly show the way to Nibbāna within the dispensation. They are called tittha because they are like good fords for crossing to the farther shore, Nibbāna. Living near and relying on such teachers is called titthavāsa. Venerable Ānanda possessed this quality too.

Whether with the Buddha or with foremost great disciples such as Venerable Sāriputta, Mahāmoggallāna, Mahākoṭṭhita, and Mahāpanthaka, Venerable Ānanda practised the following in the presence of those eminent teachers:
(a) Uggaha — learning the Pāli text.
(b) Savana — listening to its meaning, that is, to the commentary (atthakathā or aṭṭhakathā).


<a id="M05-body-P007"></a>
## Learning from teachers and attaining stream-entry
Miến / Burmese 7

(c) Paripucchā — asking further about the meaning and commentary on profound and difficult points.
(d) Dhāraṇā — retaining both the Pāli text and its meaning in the commentary, keeping them in memory.

In this way he systematically learned the Pāli and commentaries on dependent origination and retained them in memory. For this reason too, dependent origination, though deep and difficult, appeared plainly to Venerable Ānanda’s knowledge as something easy to understand. (Dīgha Commentary, vol. 2, p. 83.)

3. Sotāpannatā — having become a stream-enterer.

Sotāpannānañca nāma paccayākāro uttānakova hutvā upaṭṭhāti. Ayañca āyasmā sotāpanno. (Dīgha Commentary, vol. 2, p. 83.)

Sotāpannānañca … pe … upaṭṭhāti tattha sammohaviddhaṃsanena. “Yaṃ kiñci samudayadhammaṃ, sabbaṃ taṃ nirodhadhamman”ti attapaccakkhavasena upaṭṭhānato. (Dīgha Subcommentary, vol. 2, p. 84.)

The causal connection of dependent origination, also called the pattern of conditions (paccayākāra), appears clearly in the continuity of a genuine stream-enterer. The path of stream-entry has dispelled the delusion that conceals knowledge of the causal connection called the truth of origin, so that one has directly realized for oneself: “Whatever is subject to arising is all subject to cessation.” Thus, in that person’s knowledge…


<a id="M05-body-P008"></a>
## Seeing the causal connection for oneself
Miến / Burmese 8

…that connection is clear. Venerable Ānanda had attained stream-entry. Thus the causal connection of dependent origination appeared clearly in his knowledge.

If a good person thinks they are a stream-enterer, let them examine whether they have directly penetrated the causal connection of dependent origination with the knowledge of right view. Let them ask themselves as follows.

How do the present results—consciousness, mentality-materiality, the six bases, contact, and feeling—arise due to the causes cultivated in the past, namely ignorance, craving, clinging, formations, and kamma? How will the results—consciousness, mentality-materiality, the six bases, contact, and feeling—arise in the future due to ignorance, craving, clinging, formations, and kamma cultivated in the present?

Ask whether you have directly penetrated these matters with the knowledge of right view. If you are still merely feeling your way by a teacher’s words, the answer is already clear. Conclude for yourself that you have yet to become a genuine stream-enterer of the kind the Buddha described. For the noble ones, the Buddha’s true disciples, have directly penetrated the causal connection of dependent origination for themselves with the knowledge of right view.

4. Bahussutabhāva — being learned.

Bahussutānañca catuhatthe ovarake padīpe jalamāne mañcapīṭha…


<a id="M05-body-P009"></a>
## Learning and the knowledge that distinguishes mentality and materiality
Miến / Burmese 9

…viya nāmarūpaparicchedo pākaṭo hoti. Ayañca āyasmā bahussutānaṃ aggo hoti. Bahussutānubhāvenapissa gambhīropi paccayākāro uttānako viya upaṭṭhāsi. (Dīgha Commentary, vol. 2, p. 83.)

Nāmarūpaparicchedoti saha paccayena nāmarūpassa paricchijja avabodho. (Dīgha Subcommentary, vol. 2, p. 84.)

When a lamp is lit in a room four cubits across, the bed and seat in the room can be seen clearly. Likewise, to a learned person the clear distinction of mentality and materiality together with their conditions becomes evident, through the knowledge that distinguishes mentality and materiality and the knowledge that discerns conditions. Venerable Ānanda was foremost among the learned bhikkhus. Through the power of that learning, the causal connection of dependent origination, deep and difficult though it is, appeared plainly to his knowledge as something easy to understand. (Dīgha Commentary, vol. 2, p. 83. Dīgha Subcommentary, vol. 2, p. 84.)

What is a learned person?

Katamañca, bhikkhave, sutadhanaṃ? Idha, bhikkhave, ariyasāvako bahussuto hoti sutadharo sutasannicayo. Ye te dhammā ādikalyāṇā majjhekalyāṇā pariyosānakalyāṇā sātthaṃ sabyañjanaṃ kevalaparipuṇṇaṃ parisuddhaṃ brahmacariyaṃ abhivadanti, tathārūpāssa dhammā bahussutā honti dhātā vacasā paricitā manasānupekkhitā…


<a id="M05-body-P010"></a>
## The wealth of learning
Miến / Burmese 10

…diṭṭhiyā suppaṭividdhā. Idaṃ vuccati, bhikkhave, sutadhanaṃ. (Aṅguttara, vol. 2, p. 399.)

Diṭṭhiyā suppaṭividdhāti atthato ca kāraṇato ca paññāya suṭṭhu paṭividdhā, paccakkhaṃ katā. (Aṅguttara Commentary, vol. 2, p. 364.)

Suppaṭividdhāti nijjaṭaṃ niggumbaṃ katvā suṭṭhu yāthāvato paṭividdhā. (Aṅguttara Subcommentary, vol. 2, p. 362.)

“Bhikkhus, what is the wealth of learning?”

“Bhikkhus, here a noble disciple in this dispensation, a disciple of mine who has become noble, has heard much, retains what has been heard, and accumulates it. The disciple has heard many teachings good in the beginning through the practice of virtue, good in the middle through the practice of concentration, and good in the end through the practice of wisdom. Those teachings set forth the holy life complete in meaning and expression, wholly fulfilled and pure: the practice of virtue, concentration, and wisdom in the dispensation, or the practice of the noble eightfold path. The disciple retains these teachings, grows familiar with them through recitation, considers their meaning in the mind, and personally penetrates them directly as they really are with the wisdom of right view, both in meaning and in reason. Bhikkhus, this is called the wealth of learning.” (Aṅguttara, vol. 2, p. 399.)

According to these teachings, a learned good person has both learning received through transmission (āgamasuta) and learning through attainment (adhigamasuta), encompassing what has been heard and what has been directly seen. Such a person already has the knowledge that distinguishes mentality and materiality and the knowledge…


<a id="M05-body-P011"></a>
## Knowledge that discerns conditions and the three kinds of mundane full understanding
Miến / Burmese 11

…that discerns conditions. A learned person has personally penetrated with the knowledge of right view the material and mental phenomena belonging to the five aggregates subject to clinging, called the truth of suffering, to the point of seeing them as ultimate realities. Such a person has also personally penetrated with the knowledge of right view the causes called the truth of origin. Thus the causal connection of dependent origination appears clearly in that person's continuity.

Therefore, to become a noble person such as a stream-enterer and to pass beyond the suffering of saṃsāra, a good person should strive to penetrate the causal connection of dependent origination directly with the knowledge of right view. One should endeavour to know it clearly through all three kinds of full understanding. Full understanding is of two classes, mundane and supramundane. There are three kinds of mundane and three kinds of supramundane full understanding.

Three kinds of mundane full understanding

1. Full understanding as knowing (ñātapariññā). If a meditator can distinguish and apprehend with knowledge the characteristic, function, manifestation, and proximate cause of each factor of dependent origination—ignorance, formations, consciousness, mentality-materiality, the six bases, contact, feeling, craving, clinging, becoming, birth, and aging and death—that knowledge distinguishes mentality and materiality.


<a id="M05-body-P012"></a>
## Full understanding as knowing, investigation, and abandoning
Miến / Burmese 12

When one personally penetrates causal connections such as formations arising due to ignorance, consciousness due to formations, and mentality-materiality due to consciousness, that knowledge discerns conditions. The knowledge that distinguishes mentality and materiality and the knowledge that discerns conditions are both called full understanding as knowing (ñātapariññā). They make it possible to know and clearly distinguish the formations that will become the objects of insight knowledge. Hence the name full understanding as knowing.

2. Full understanding as investigation (tīraṇapariññā). When one discerns with wisdom the characteristics of impermanence, suffering, and non-self in the twelve factors of dependent origination, beginning with ignorance and formations, the two knowledges capable of determining these characteristics are comprehension knowledge (sammasanañāṇa) and knowledge of arising and passing away (udayabbayañāṇa). They are called full understanding as investigation. They investigate and determine the factors of dependent origination in terms of impermanence, suffering, and non-self.

3. Full understanding as abandoning (pahānapariññā). When one discerns with wisdom the dissolution of the factors of dependent origination, the insight knowledges beginning with knowledge of dissolution (bhaṅgañāṇa) abandon by momentary opposition the defilements that can be abandoned in that way. At the same time they clearly see the known factors of dependent origination in terms of impermanence, suffering, and non-self. Hence the name full understanding as abandoning. These are the three kinds of mundane full understanding.


<a id="M05-body-P013"></a>
## Three kinds of supramundane full understanding
Miến / Burmese 13

Three kinds of supramundane full understanding

1. At the culmination of the insight knowledges, that is, the kinds of mundane full understanding, the noble path arises with Nibbāna as its object. The path eradicates the defilements that can be abandoned at that stage and clearly penetrates Nibbāna, the truth to be realized. Thus the noble path is first called full understanding as abandoning (pahānapariññā).

2. By penetration of the object (ārammaṇapaṭivedha), the noble path directly penetrates the truth to be realized, Nibbāna. At the same time, it eradicates the delusion that obscures clear knowledge of the four noble truths. Once this obscuring delusion is eradicated, knowledge of the four truths is accomplished at the same time. Knowing the noble truths in this way by function is called penetration through non-delusion (asammohapaṭivedha). Here the noble path knows the truth of cessation by penetration of the object, and knows the truths of suffering, origin, and the path by penetration through non-delusion. Thus the noble path accomplishes knowledge of the factors of dependent origination belonging to the truth of suffering, and of their causal connection belonging to the truth of origin. By virtue of this function the noble path is also called full understanding as knowing (ñātapariññā).


<a id="M05-body-P014"></a>
## Supramundane full understanding as investigation
Miến / Burmese 14

3. The noble path also eradicates the delusion that obscures clear knowledge of the characteristics of impermanence, suffering, and non-self in the phenomena belonging to the truths of suffering and origin. Thus it completes the function of investigating and determining these characteristics in mentality, materiality, and their conditions, the phenomena belonging to those two truths. In virtue of this function the noble path is also called full understanding as investigation (tīraṇapariññā). These are the three kinds of supramundane full understanding.

Understanding and penetration (anubodha and paṭivedha) apply when one has personally and directly penetrated the causal connection of dependent origination by mundane and supramundane full understanding. Only when one knows dependent origination deeply through such understanding and penetration can one fully pass beyond the great suffering of saṃsāra. This is the essential meaning of the passage quoted above from the Great Discourse on Causation.

Understanding and penetration (anubodha and paṭivedha)

Ananubodhāti ñātapariññāvasena ananubujjhanā. Appaṭivedhāti tīraṇapahānapariññāvasena appaṭivijjhanā. (Dīgha Commentary, vol. 2, p. 85.)

Nāmarūpaparicchedo, tassa ca paccayapariggaho na paṭhamābhinivesamattena hoti, atha kho tattha aparāparaṃ ñāṇuppattisaṅkhātena anu anu bujjhanena. Tadubhayābhāvaṃ pana dassento “ñātapariññāvasena ananubujjhanā”ti āha. Niccasaññādīnaṃ pajahanavasena vattamānā…


<a id="M05-body-P015"></a>
## Understanding through the repeated arising of knowledge
Miến / Burmese 15

…vipassanā dhamme ca paṭivijjhati eva nāma hoti paṭipakkhavikkhambhanena tikkhavisadabhāvāpattito. Tadadhiṭṭhānabhūtā ca tīraṇapariññā, ariyamaggo ca pariññāpahānābhisamayavasena pavattiyā tīraṇapahānapariññāsaṅgaho cāti tadubhayapaṭivedhābhāvaṃ dassento “tīraṇa … pe … appaṭivijjhanā”ti āha. (Dīgha Subcommentary, vol. 2, pp. 89–90.)

Read again the three kinds of mundane and the three kinds of supramundane full understanding explained above. The commentary and subcommentary make clear that understanding and penetration have yet to be attained so long as the phenomena of dependent origination have yet to be distinctly seen and known through the three mundane and the three supramundane kinds of full understanding.

The knowledge that distinguishes mentality and materiality distinguishes mental and material phenomena. The knowledge that discerns conditions distinguishes causes, effects, and the causal connection between them. The subcommentary says “anu anu bujjhanena”, by understanding repeatedly. These two kinds of knowledge are brought to completion through repeated cultivation, over and over. The knowledge that distinguishes mentality and materiality and the knowledge that discerns conditions are therefore called understanding (anubodha). Knowing through this knowledge is called understanding (anubodhi). This is full understanding as knowing.

Further, knowing through the wisdom of full understanding as investigation and abandoning is called penetration (paṭivedha). The insight knowledges can abandon such defilements as the perception of permanence by momentary opposition, but cannot uproot them so that they never arise again. On account of this capacity for abandoning by opposition, these knowledges are called full understanding as abandoning…


<a id="M05-body-P016"></a>
## Functions of the noble path and directly seeing conditions
Miến / Burmese 16

…(pahānapariññā). Likewise, through penetration by non-delusion (asammohapaṭivedha), the noble path penetrates mentality and materiality and their causal connection, the phenomena belonging to the truths of suffering and origin, as well as their characteristics of impermanence, suffering, and non-self. By virtue of these functions accomplished through penetration by non-delusion, the noble path is called full understanding as knowing and as investigation. The noble path alone can permanently uproot defilements, so it is called full understanding as abandoning in the primary sense. Thus penetrating mentality and materiality belonging to the truth of suffering and the causal connection of dependent origination belonging to the truth of origin through full understanding as investigation and abandoning, through to the moments of path and fruition, is called penetration (paṭivedha).

In the past, future, and present, the meditator distinguishes with knowledge the material and mental phenomena in each material and mental group belonging to the factors of dependent origination, such as ignorance and formations. One personally and directly penetrates them through the knowledge of right view, to the point of knowing them as ultimate realities. One also personally and directly penetrates through the knowledge of right view the causal connection between causes such as ignorance and effects such as formations. These two kinds of knowing are called understanding (anubodhi). To personally and directly penetrate with the knowledge of right view the characteristics of impermanence, suffering, and non-self in those factors of dependent origination, through to the moments of path and fruition…


<a id="M05-body-P017"></a>
## A summary of dependent origination by the fifth method
Miến / Burmese 17

…is called penetration (paṭivedha). As long as a good person has yet to know the phenomena of dependent origination personally, directly, and as they really are through understanding and penetration, there is no way to escape the suffering of saṃsāra. Only through knowing in this way can one escape that suffering. Therefore, a good person wishing to pass completely beyond the great suffering of the round of rebirths must strive to know dependent origination through understanding and penetration. To support such practice, the procedure called the fifth method of dependent origination is presented first below.

A summary of dependent origination by the fifth method for memorization

1. Purimakammabhavasmiṃ moho avijjā, āyūhanā saṅkhārā, nikanti taṇhā, upagamanaṃ upādānaṃ, cetanā bhavo. Ime pañca dhammā purimakammabhavasmiṃ idha paṭisandhiyā paccayā.

2. Idha paṭisandhi viññāṇaṃ, okkanti nāmarūpaṃ, pasādo āyatanaṃ, phuṭṭho phasso, vedayitaṃ vedanā. Ime pañca dhammā idhupapattibhavasmiṃ purekatassa kammassa paccayā.

3. Idha paripakkattā āyatanānaṃ moho avijjā, āyūhanā saṅkhārā, nikanti taṇhā, upagamanaṃ upādānaṃ, cetanā bhavo. Ime pañca dhammā idha kammabhavasmiṃ āyatiṃ paṭisandhiyā paccayā.

4. Āyatiṃ paṭisandhi viññāṇaṃ, okkanti nāmarūpaṃ, pasādo āyatanaṃ, phuṭṭho phasso, vedayitaṃ vedanā. Ime pañca dhammā āyatiṃ…


<a id="M05-body-P018"></a>
## Five past causes and five present results
Miến / Burmese 18

…upapattibhavasmiṃ idha katassa kammassa paccayā. (Paṭisambhidāmagga, pp. 50–51.)

1. When building up kamma-becoming in a past life:
(a) Confusion, that is, delusion, is called ignorance.
(b) Exertion in generating and accumulating kamma is called formations.
(c) Desire and longing for becoming are called craving.
(d) Holding on firmly is called clinging.
(e) The volition that prompts action is called becoming.

The five phenomena that arose while building up kamma-becoming in that past life are causes of rebirth-linking in this present life.

2. In this present life:
(a) The rebirth-linking phenomenon characterized by connecting one life to another, that is, the aggregates of one life to the aggregates of another, is called consciousness.
(b) The phenomena arising as though entering the mother’s womb are called mentality-materiality.
(c) The sensitivity of the great elements is called a sense base.
(d) The quality of coming into contact is called contact.
(e) The quality of experiencing is called feeling.

These five phenomena in the round of results in the present life are results that arise from kamma generated and accumulated while building up kamma-becoming in a past life.


<a id="M05-body-P019"></a>
## Five present causes and five future results
Miến / Burmese 19

3. In this present life, owing to the maturity of the sense bases, the following phenomena arise:
(a) Confusion, that is, delusion, is called ignorance.
(b) Exertion in generating and accumulating kamma is called formations.
(c) Desire and longing for becoming are called craving.
(d) Holding on firmly is called clinging.
(e) Volition that prompts action is called becoming.

These five causes, arising in present kamma-becoming, are causes of future rebirth-linking.

4. In the future:
(a) The rebirth-linking phenomenon characterized by connecting one life to another, that is, the aggregates of one life to the aggregates of another, is called consciousness.
(b) Phenomena arising as though entering the mother’s womb are called mentality-materiality.
(c) The sensitivity of the great elements is called a sense base.
(d) The quality of coming into contact is called contact.
(e) The quality of experiencing is called feeling.

These five phenomena arising in future rebirth-becoming are results caused by kamma generated and accumulated in the present life. (Paṭisambhidāmagga, pp. 50–51.)

On the basis of the Pāli passage from the Paṭisambhidāmagga quoted above, the commentators give the following summary for memorization.


<a id="M05-body-P020"></a>
## Five causes and five results across the three periods
Miến / Burmese 20

Atīte hetavo pañca, idāni phalapañcakaṃ.
Idāni hetavo pañca, āyatiṃ phalapañcakaṃ.
(Abhidhamma Commentary, vol. 2, p. 182. Visuddhimagga, vol. 2, p. 214.)

1. Owing to the five past causes generated and accumulated in the past, namely ignorance, craving, clinging, formations, and kamma, the five present results arise in this life: consciousness, mentality-materiality, the six bases, contact, and feeling.

2. Owing to the five present causes generated and accumulated in this life, namely ignorance, craving, clinging, formations, and kamma, the five future results arise in a future life: consciousness, mentality-materiality, the six bases, contact, and feeling. (Abhidhamma Commentary, vol. 2, p. 182. Visuddhimagga, vol. 2, p. 214.)

A good person who wishes to escape should strive to penetrate directly for themselves, with the knowledge of right view, how the five present results arise due to the five past causes and how the five future results arise due to the five present causes. Only then can one pass entirely beyond the great suffering of saṃsāra.

Here the causes are the truth of origin and the results are the truth of suffering. Therefore, a good person who wishes to escape should strive to penetrate directly for themselves, with the knowledge of right view, how the present truth of suffering arises due to the truth of origin accumulated in the past and how the future truth of suffering arises due to the truth of origin accumulated in the present.


<a id="M05-body-P021"></a>
## The truth of origin taught in five ways
Miến / Burmese 21

In the Pāli Abhidhamma Vibhaṅga (Abhidhamma, vol. 2, pp. 112–118), the Buddha taught the truth of origin in five ways:
1. Craving is the truth of origin.
2. Craving and all the defilements accompanying it are the truth of origin.
3. All unwholesome phenomena are the truth of origin.
4. All unwholesome phenomena and the three wholesome roots—non-greed, non-hatred, and non-delusion—that serve as objects for phenomena with taints that keep saṃsāra going are the truth of origin.
5. All wholesome kamma serving as an object for phenomena with taints that keep saṃsāra going, together with all unwholesome kamma, is the truth of origin.

Since the Buddha analyzed the truth of origin in these five ways, the commentators explain it as follows in the Sammohavinodanī.

Tattha yasmā kusalākusalakammaṃ avisesena samudayasaccanti saccavibhaṅge vuttaṃ. (Abhidhamma Commentary, vol. 2, p. 185.)

In the Analysis of the Truths, the Buddha taught in general that all wholesome and unwholesome kamma is the truth of origin, without restricting the statement to volition or the phenomena associated with volition. (Abhidhamma Commentary, vol. 2, p. 185.)

Again, in the Titthāyatanasutta of the Book of Threes in the Aṅguttara, the Buddha taught the truth of origin as follows.


<a id="M05-body-P022"></a>
## The chain of dependent origination and the noble truth of the origin of suffering
Miến / Burmese 22

Katamañca, bhikkhave, dukkhasamudayaṃ ariyasaccaṃ? Avijjāpaccayā saṅkhārā, saṅkhārapaccayā viññāṇaṃ, viññāṇapaccayā nāmarūpaṃ, nāmarūpapaccayā saḷāyatanaṃ, saḷāyatanapaccayā phasso, phassapaccayā vedanā, vedanāpaccayā taṇhā, taṇhāpaccayā upādānaṃ, upādānapaccayā bhavo, bhavapaccayā jāti, jātipaccayā jarāmaraṇaṃ sokaparidevadukkhadomanassupāyāsā sambhavanti. Evametassa kevalassa dukkhakkhandhassa samudayo hoti. Idaṃ vuccati, bhikkhave, dukkhasamudayaṃ ariyasaccaṃ. (Aṅguttara, vol. 1, p. 178.)

Bhikkhus, what is the noble truth of the origin of suffering?
1. With the arising of ignorance, formations arise.
2. With the arising of formations, consciousness arises.
3. With the arising of consciousness, mentality-materiality arises.
4. With the arising of mentality-materiality, the six bases arise.
5. With the arising of the six bases, contact arises.
6. With the arising of contact, feeling arises.
7. With the arising of feeling, craving arises.
8. With the arising of craving, clinging arises.
9. With the arising of clinging, becoming arises.
10. With the arising of becoming, birth arises.
11. With birth, aging and death, sorrow, lamentation, pain, grief, and despair arise.

In this way the origin of this whole mass of suffering, with no trace of ease, becomes evident. In other words, the entire mass of suffering arises. Bhikkhus, this causal connection of dependent origination is the noble truth of the origin of suffering…


<a id="M05-body-P023"></a>
## Which craving is the origin of present suffering?
Miến / Burmese 23

…it is called thus. (Aṅguttara, vol. 1, p. 178.)

In the Titthāyatana Sutta, the Buddha calls the whole causal connection between causes and results the truth of origin.

When did that craving arise?

The Buddha did indeed teach that craving is the truth of origin. But one should carefully consider when the craving called the truth of origin, the root cause of the present phenomena belonging to the truth of suffering, arose.

Rūpārūpaṃ panetaṃ hoti dukkhasaccaṃ, taṃsamuṭṭhāpikā purimataṇhā samudayasaccaṃ. (Abhidhamma Commentary, vol. 2, pp. 68–69.)

Mentality and materiality are the five aggregates. Those five aggregates are the truth of suffering. The craving generated and accumulated in the past that gives rise to that truth of suffering is the truth of origin. (Abhidhamma Commentary, vol. 2, pp. 68–69.)

According to the explanation above, understand that the craving called the truth of origin, the actual root cause of the five aggregates subject to clinging that now constitute the truth of suffering in a good person’s continuity, is craving generated and accumulated in past lives.

This explanation of the commentary accords with the Buddha’s teaching and with the meaning of the Pāli passage from the Paṭisambhidāmagga given above. When generating and accumulating the kamma called kamma-becoming…


<a id="M05-body-P024"></a>
## Distinguishing formations and kamma-becoming
Miến / Burmese 24

…delusion, the mistaken knowing that arose in a former life, is called ignorance. The phenomena that exert themselves to bring kamma into being are formations. Attachment to becoming and to its corresponding object, that is, nikanti, is craving. The mind’s going toward and holding to that becoming or object is clinging. Wholesome or unwholesome volition is becoming. The five phenomena that arose when generating and accumulating kamma-becoming in that past life are causes of rebirth-linking in this present life. For human beings, they are causes of the five rebirth-linking aggregates. (Paṭisambhidāmagga, p. 50.)

The point of this Pāli passage is that the formations and kamma generated under the influence of ignorance, craving, and clinging when past kamma was accumulated are the root causes of the five present rebirth-linking aggregates, the resultant aggregates. Here the distinction between formations and kamma-becoming, that is, kamma, can be understood through the example of an act of giving.

1. In preparing a wholesome act of giving, the volitions before handing over the gift are formations. The volition that places the gift in the recipient’s hands, the volition of relinquishing (muñcanacetanā), is kamma-becoming.

2. Alternatively, in the mind-door impulsion processes that arise while generating and accumulating an act of kamma, the volitions at the first six of the seven impulsions are called exertive formations (āyūhanasaṅkhāra), the exertive causes that bring kamma into being. The volition at the seventh impulsion…


<a id="M05-body-P025"></a>
## Volition, formations, and the power of kamma condition
Miến / Burmese 25

…is the volition at the seventh impulsion, called kamma-becoming.

3. Alternatively, the volition present in a moment of impulsion while generating and accumulating an act of kamma is called kamma-becoming. The consciousness and mental factors arising together with it, that is, the phenomena associated with that volition, are called exertive formations (āyūhanasaṅkhāra). (Abhidhamma Commentary, vol. 2, pp. 182–183.)

The power of kamma condition

Kusalākusalaṃ kammaṃ vipākānaṃ khandhānaṃ kaṭattā ca rūpānaṃ kammapaccayena paccayo. (Paṭṭhāna, vol. 1, p. 7.)

Kammapaccayenāti anekampi kappakoṭīnaṃ matthake attano phalaṃ uppādetuṃ samatthena nānakkhaṇikakammapaccayenāti attho. Kusalākusalañhi kammaṃ attano pavattikkhaṇe phalaṃ na deti. Yadi dadeyya, yaṃ manusso devalokūpagaṃ kusalaṃ kammaṃ karoti, taṃānubhāvena tasmiṃyeva khaṇe devo bhaveyya. Yasmiṃ pana khaṇe taṃ kataṃ, tato aññasmiṃ khaṇe avijjamānampi kevalaṃ kaṭattāyeva diṭṭheva dhamme upapajje vā apare vā pariyāye avasesapaccayasamāyoge sati phalaṃ uppādeti, niruddhāpi purimasippādikiriyā viya kālantare pacchimasippādikiriyāya. Tasmā nānakkhaṇikakammapaccayoti vuccati. (Abhidhamma Commentary, vol. 3, p. 374.)

Let the good person consider the five causes of the present resultant aggregates with kamma as the main point. Note that this kamma is surrounded by ignorance, craving, and clinging. In the section on kamma condition, the Buddha teaches as follows.

Wholesome and unwholesome kamma condition the resultant aggregates and the material phenomena that arise because kamma has been done…


<a id="M05-body-P026"></a>
## Asynchronous kamma and the time of ripening
Miến / Burmese 26

…by the power of kamma condition. (Paṭṭhāna, vol. 1, p. 7.)

“By the power of kamma condition” means the following. Even after many koṭis of aeons, kamma that was generated and accumulated can condition its own result through the power of asynchronous kamma condition (nānakkhaṇikakammapaccaya). “Asynchronous kamma” denotes a condition in which the time of the causal kamma differs from the time its result arises.

Wholesome and unwholesome kamma do not give their result in the very moment they are occurring. If kamma could give its result as it occurs, a person who did a wholesome deed leading to a heavenly realm would immediately become a deity. That is not how it happens.

When an act is performed with an intention, after the moment of doing it the kamma no longer exists as a present phenomenon. Yet because it was done, its result can arise when the remaining conditions come together. It may arise in the present life for kamma to be experienced here and now (diṭṭhadhammavedanīyakamma), in the next, second life for kamma to be experienced in the next rebirth (upapajjavedanīyakamma), or in a suitable life from the third onward for kamma to be experienced in subsequent lives (aparāpariyavedanīyakamma). The relevant conditions include favorable or unfavorable destination, bodily endowment, period, and effort, according to whether the kamma is wholesome or unwholesome.


<a id="M05-body-P027"></a>
## Why it is called asynchronous kamma condition
Miến / Burmese 27

Earlier training in a craft, though it has ceased, still provides a basis and support for practising that craft when the appropriate time comes. So it is with the volition called kamma. It conditions the arising of a result at a time after the kamma was generated and accumulated. Hence it is called asynchronous kamma condition, a volition that arose at a moment different from the moment at which it gives its result. (Abhidhamma Commentary, vol. 3, p. 374.)

The power to produce a result belonging to a volition generated and accumulated in a distant past life or many koṭis of aeons ago, even though that volition no longer exists as a present phenomenon, is called the power of kamma (kammasatti). Let the good person consider this with the power of kamma as the main point.

If kamma gave its result while it was being generated, as the commentary explains, a person doing a wholesome deed that leads to a heavenly realm would have to become a deity at the very time of doing it. That does not happen. Likewise, if a person wished to reach maturity and did kamma to become a sixteen-year-old man or woman, they would have to become sixteen at the very moment of doing that kamma. That does not happen either. If results arose in that way, there would be no old, sick, or dying people in the world. Why? Everyone would do good deeds and aspire to be free from aging, sickness, and death. In brief, there would also be no bad people in the world…


<a id="M05-body-P028"></a>
## Past conditions and the time needed to cultivate the perfections
Miến / Burmese 28

…because everyone would do good deeds and aspire to become a foremost person in the world, such as a wheel-turning monarch. Even kamma able to give a result in this life (diṭṭhadhammavedanīyakamma) gives that result only after some time has elapsed since the deed. Other kamma does not ripen in that way.

Therefore, when considering the five past causes with kamma as the main point, a good person can accept that the phenomena belonging to the truth of suffering in this life arise due to the truth of origin accumulated in the past. If one cannot accept that the five rebirth-linking aggregates and the phenomena belonging to the truth of suffering in this life arise due to previously accumulated kamma, called the truth of origin, then consider why a bodhisatta destined for perfect awakening has to cultivate the perfections for four incalculables and a hundred thousand aeons to attain the awakening of a perfectly awakened Buddha.

Consider likewise one aspiring to the awakening of a solitary Buddha for two incalculables and a hundred thousand aeons, one aspiring to the awakening of a chief disciple for one incalculable and a hundred thousand aeons, and one aspiring to the awakening of a great disciple for a hundred thousand aeons. Would they need to cultivate the perfections throughout those periods? Consider this again. It is precisely because of being unable to accept that the truth of origin accumulated in the past…


<a id="M05-body-P029"></a>
## Inference and direct experience
Miến / Burmese 29

…brings forth the phenomena of the round of results, the truth of suffering, clearly in this life.

Inference and direct experience (anumāna and paccakkha)

Suppose a good person accepts the following: “The past has ceased and no longer exists. The future has yet to arrive and has yet to arise. Therefore a meditator can discern the past and future only by conjecture, that is, by inference.”

Likewise, suppose one accepts that a meditator can discern only by inference how the five present results arise due to the five past causes and how the five future results arise due to the five present causes.

Accepting this would imply that the noble ones, especially such foremost great noble disciples as Venerable Ānanda, knew the causal connection of dependent origination and how suffering arises from its origin only by inference. That is the implication of the claim. The Buddha’s discourses and the commentaries say the following.

Idha, bhikkhave, bhikkhu “idaṃ dukkhan”ti yathābhūtaṃ pajānāti, “ayaṃ dukkhasamudayo”ti yathābhūtaṃ pajānāti, “ayaṃ dukkhanirodho”ti yathābhūtaṃ pajānāti, “ayaṃ dukkhanirodhagāminī paṭipadā”ti yathābhūtaṃ pajānāti. (Majjhima, vol. 1, p. 82.)


<a id="M05-body-P030"></a>
## Knowing the four noble truths as they really are
Miến / Burmese 30

Bhikkhus, here a meditating bhikkhu in this dispensation knows distinctly, as it really is and without distortion: “This is the noble truth of suffering.” The bhikkhu knows distinctly, as it really is and without distortion: “This is the noble truth of the origin of suffering.” The bhikkhu knows distinctly, as it really is and without distortion: “This is the noble truth of the cessation of suffering.” The bhikkhu knows distinctly, as it really is and without distortion: “This is the noble truth of the way to Nibbāna, where suffering ceases.” (Majjhima, vol. 1, p. 82.)

In such discourses, the noble ones are said to penetrate the four noble truths personally, directly, and as they really are through the wisdom of right view. The discourses do not say that the noble ones know them only by conjecture, that is, by inference.

“Ayaṃ lokiyo, ayaṃ lokuttaro”ti ariyaṃ aṭṭhaṅgikaṃ maggaṃ yathābhūtaṃ na pajānāti, ajānanto lokiyamagge abhinivisitvā lokuttaraṃ nibbattetuṃ na sakkoti. (Majjhima Commentary, vol. 2, p. 165.)

If a meditator fails to know distinctly, as it really is and without distortion through the wisdom of right view, “This is the mundane truth of the path, and this is the supramundane noble truth of the path,” that is, the noble path of eight factors, they cannot engage insight in the mundane truth of the path, or develop that mundane path so as to bring forth the supramundane noble truth of the path. (Majjhima Commentary, vol. 2, p. 165.)

Only when a meditator personally and directly penetrates with the wisdom of right view, as they really are, both the phenomena of the truths of suffering and origin and how the truth of suffering arises due to the truth of origin…


<a id="M05-body-P031"></a>
## Two truths of the round and two truths of release from the round
Miến / Burmese 31

…can one examine the phenomena of the truths of suffering and origin in terms of the three characteristics and develop the subject of insight meditation. Such effort in cultivation is the development of the truth of the path. Only by developing the mundane truth of the path can one reach the supramundane truths of the path and cessation. Read the following explanation from the commentary.

Tattha purimāni dve saccāni vaṭṭaṃ, pacchimāni vivaṭṭaṃ. Tesu bhikkhuno vaṭṭe kammaṭṭhānābhiniveso hoti, vivaṭṭe natthi abhiniveso. (Abhidhamma Commentary, vol. 2, p. 109.)

Of the four truths, the first two, suffering and origin, belong to the round. The last two, cessation and the path, belong to release from the round. Of these two groups, the meditating bhikkhu engages in insight meditation on the truths belonging to the round. The bhikkhu does not engage in insight meditation on the truths belonging to release from the round. Here the truth of the path belonging to release from the round means the supramundane truth of the path.

According to these commentarial explanations, a meditator develops the subject of insight meditation on the two mundane truths, suffering and origin. Only when one can discern and develop insight thoroughly into these two mundane truths can the two supramundane truths become manifest. What can happen if the four truths have yet to be known?

An excerpt from the Discourse on the Peaked House (Kūṭāgārasutta)

Yo ca kho, bhikkhave, evaṃ vadeyya: “Ahaṃ dukkhaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca, dukkhasamudayaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca…


<a id="M05-body-P032"></a>
## The condition for making an end of suffering
Miến / Burmese 32

…dukkhanirodhaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca, dukkhanirodhagāminiṃ paṭipadaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca sammā dukkhassantaṃ karissāmī”ti, netaṃ ṭhānaṃ vijjati. (Saṃyutta, vol. 3, p. 394.)

Yo ca kho, bhikkhave, evaṃ vadeyya: “Ahaṃ dukkhaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca, dukkhasamudayaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca, dukkhanirodhaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca, dukkhanirodhagāminiṃ paṭipadaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca sammā dukkhassantaṃ karissāmī”ti, ṭhānametaṃ vijjati. (Saṃyutta, vol. 3, p. 394.)

Bhikkhus, suppose someone says: “I will make a complete end of the suffering of saṃsāra even though I have yet to penetrate personally and directly, as they really are and without distortion through the wisdom of right view, the noble truths of suffering, its origin, its cessation, and the path leading to Nibbāna, where suffering ceases.” There is no possibility of that person’s statement coming true. (Saṃyutta, vol. 3, p. 394.)

Bhikkhus, suppose someone says: “Having personally and directly penetrated, as they really are and without distortion through the wisdom of right view, the noble truth of suffering and the noble truth of its origin…


<a id="M05-body-P033"></a>
## Striving to realize the four noble truths directly
Miến / Burmese 33

…and having personally and directly penetrated, as they really are and without distortion through the wisdom of right view, the noble truth of the cessation of suffering and the noble truth of the path leading to Nibbāna, where suffering ceases, I will make a complete end of the suffering of saṃsāra.” There is a possibility of that person’s statement coming true. (Saṃyutta, vol. 3, pp. 394–395.)

In accordance with these teachings, to make a definitive end of the great suffering of saṃsāra and escape it completely, a good person must strive to penetrate the four truths personally and directly with the wisdom of right view. In striving thus, first make an effort to know the phenomena belonging to suffering and its origin, how suffering arises due to its origin, and the characteristics of impermanence, suffering, and non-self in the phenomena of those two truths. Only then, at the culmination of mature insight knowledge, can the two supramundane truths of cessation and the path arise. Therefore, to penetrate all four truths directly with the eye of the wisdom of right view, a good person should remember to strive to know clearly each causal connection of dependent origination through the three kinds of full understanding.


<a id="M05-body-P034"></a>
## To attain knowledge of discerning conditions
Miến / Burmese 34

Vipassakena pana kammassa ca vipākassa ca ekadesato jānitabbaṃ. (Visuddhimagga, vol. 2, p. 237.)

Ekadesato jānitabbaṃ, anavasesato jānituṃ na sakkā avisayattā. Sabbena sabbaṃ ajānane paccayapariggaho na paripūrati. (Visuddhimagga Great Subcommentary, vol. 2, p. 380.)

One striving to cultivate the subject of insight meditation should know to some extent the distinctions among deeds, such as whether they are strong or weak, and among their results, such as whether they are inferior or superior. To know kamma and its results completely, without remainder, lies beyond the disciples’ range. It is the domain of perfectly awakened Buddhas endowed with omniscience. Yet if one knows nothing whatsoever about kamma and its results, knowledge of discerning conditions cannot be fulfilled. (Visuddhimagga, vol. 2, p. 237. Visuddhimagga Great Subcommentary, vol. 2, p. 380.)

Since knowledge of discerning conditions cannot be attained without any knowledge of kamma and its results, a good person who wishes to attain it must strive to know kamma and its results at least in part. Here knowledge of discerning conditions is also the knowledge of how the truth of suffering arises due to the truth of origin.

A good person may already know or have heard that the Buddha had the thirty-two marks of a great person. Among them, each mark…


<a id="M05-body-P035"></a>
## Distinct deeds, distinct results, and two ways of knowing the past
Miến / Burmese 35

…has its own corresponding deed that gave that result. The marks of the head, the teeth, and the tongue each arise from their own corresponding deeds. Causal deeds and their resulting marks are distinguished in this way. Likewise, in a single life a person encounters many kinds of favorable and unfavorable results. Favorable results come from wholesome kamma, and unfavorable results from unwholesome kamma. Different favorable results have corresponding wholesome deeds that bring them about. Different unfavorable results likewise have corresponding unwholesome deeds that bring them about. Disciples cannot know every kind of kamma and every kind of result. They can know only a part.

Direct knowledge and insight

The texts say that with the direct knowledge of recollecting former lives (pubbenivāsānussati-abhiññā), one can discern the past. They also say that with knowledge of the future (anāgataṃsañāṇa), an aspect of the direct knowledge of the divine eye, one can discern the future. These points are readily accepted. Yet people are reluctant to accept that the past and future aggregates can also be discerned with insight knowledge. Concerning the ability to discern the past and future aggregates subject to clinging with insight knowledge, the Buddha’s words in Pāli and the commentarial explanation are as follows.


<a id="M05-body-P036"></a>
## Recollecting former lives in the Khajjanīya Sutta
Miến / Burmese 36

Ye hi keci, bhikkhave, samaṇā vā brāhmaṇā vā anekavihitaṃ pubbenivāsaṃ anussaramānā anussaranti, sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataraṃ. (Saṃyutta, vol. 2, p. 71. Khajjanīyasutta.)

Pubbenivāsanti na idaṃ abhiññāvasena anussaraṇaṃ sandhāya vuttaṃ. Vipassanāvasena pana pubbenivāsaṃ anussaraṇe samaṇabrāhmaṇe sandhāyetaṃ vuttaṃ. Tenevāha “sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataran”ti. Abhiññāvasena hi samanussarantassa khandhāpi upādānakkhandhāpi khandhapaṭibaddhāpi paññattipi ārammaṇaṃ hotiyeva. Rūpaṃyeva anussaratīti evaṃ hi anussaraṇena na aññaṃ kiñci sattaṃ vā puggalaṃ vā anussarati, atīte pana niruddhaṃ rūpakkhandhameva anussarati. Vedanādīsupi eseva nayo. (Saṃyutta Commentary, vol. 2, p. 266.)

Bhikkhus, whatever ascetics or brahmins recollect many former lives and follow that succession of aggregates with knowledge, when they succeed in recollecting they do so by following that succession with knowledge. All those ascetics and brahmins who recollect in this way recollect the five aggregates subject to clinging or one of those five. (Saṃyutta, vol. 2, p. 71.)

In this Pāli passage, the Buddha uses the word pubbenivāsa, “former lives”, with reference to recollecting by tracing the succession of aggregates with knowledge. The reference here is to ascetics and brahmins who use insight knowledge to trace the succession of the aggregates of former lives and recollect…


<a id="M05-body-P037"></a>
## The objects of direct knowledge of former lives
Miến / Burmese 37

…and so the Buddha uses the word pubbenivāsa in that sense. It is for this reason that he goes on to say the following.

Sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataraṃ.

All those ascetics and brahmins can trace and recollect with knowledge the five aggregates subject to clinging. They can also trace and recollect with knowledge just one of those five. (Saṃyutta, vol. 2, p. 71.)

The Buddha taught in this way for the following reason. For ascetics and brahmins who trace the succession of the aggregates in former lives through the power of direct knowledge of former lives, that direct knowledge has four kinds of objects:
1. The five aggregates, including supramundane phenomena.
2. The five aggregates subject to clinging, which exclude supramundane phenomena.
3. Things connected with the aggregates, such as clan, appearance, food, pleasure, and pain.
4. Names, that is, various concepts.

Here the Buddha does not say that all four kinds of objects can be traced and recollected with knowledge. He says only that they can trace and recollect the five aggregates subject to clinging, or one of them. Thus what the Buddha has in mind here is tracing and recollecting the succession of the aggregates of former lives…


<a id="M05-body-P038"></a>
## Discerning past aggregates with insight knowledge
Miến / Burmese 38

…with insight knowledge. When a meditator thus traces and recollects the succession of the aggregates of former lives with insight knowledge, they do not trace and recollect any individual, being, or person. With insight knowledge they can trace and recollect materiality, feeling, perception, formations, and consciousness that ceased in the past. That is the meaning here. (Saṃyutta, vol. 2, p. 71. Saṃyutta Commentary, vol. 2, p. 266.)

This passage of the Buddha’s direct teaching and its commentarial explanation shows the distinction between direct knowledge of former lives and insight knowledge, and provides a textual basis for discerning past and future with insight knowledge.

A good person should also consider that arahants who are dry-insight practitioners (sukkhavipassaka), that is, those who take pure insight as their vehicle (suddhavipassanāyānika), have likewise personally and directly penetrated the four noble truths with the wisdom of right view. Let a good person strive to follow the true teaching of the Buddha’s dispensation.


<a id="M05-body-P039"></a>
## Part 2. A procedure for finding the causes
Miến / Burmese 39

Paccayapariggahe paññā dhammaṭṭhitiñāṇaṃ. (Paṭisambhidāmagga, p. 1.)

“Nāmarūpavavatthāne ñāṇan”ti avatvā eva kasmā “dhammaṭṭhitiñāṇan”ti vuttanti ce? Paccayapariggaheneva paccayasamuppannapariggahitattā siddhattaṃ. Paccayasamuppanne hi apariggahite paccayapariggaho na sakkā hoti kātuṃ. Tasmā dhammaṭṭhitiñāṇaggahaṇeneva tassa hetubhūtaṃ pubbe siddhaṃ nāmarūpavavatthānañāṇaṃ vuttameva hotīti veditabbaṃ. (Paṭisambhidāmagga Commentary, vol. 1, p. 18.)

Causes have the power to bring about results. Because that power is present, the causes are said to support the results. Since the results stand and arise owing to their causes, those causes are the standing ground of the results, called dhammaṭṭhiti. The knowledge that penetrates the causes on which the results stand is called knowledge of the conditioned standing of phenomena (dhammaṭṭhitiñāṇa).

If one asks why this passage speaks of knowledge of the conditioned standing of phenomena without mentioning the knowledge that defines mentality and materiality (nāmarūpavavatthānañāṇa)…


<a id="M05-body-P040"></a>
## Apprehending results before looking for causes
Miến / Burmese 40

…the answer is as follows.

To have apprehended the causes implies that apprehending the results has already been accomplished. Indeed, without first apprehending the results, one cannot carry out the apprehension of the causes. A cause truly has the power to produce a result, but only by distinguishing and apprehending with knowledge the results that arise owing to it can one know that the cause has that power. Therefore, directly mentioning knowledge of the conditioned standing of phenomena also implies the knowledge that defines mentality and materiality, which is its underlying cause and has already been accomplished. This is how it should be understood. (Paṭisambhidāmagga Commentary, vol. 1, p. 18.)

According to this commentarial explanation, a meditator wishing to distinguish and apprehend the causes with knowledge (paccayapariggaha) must first strive to apprehend and distinguish the resultant material and mental phenomena, the conditioned phenomena (paccayasamuppanna). This is called knowledge that defines mentality and materiality (nāmarūpavavatthānañāṇa). The main point is this. When wishing to distinguish and apprehend past causes, one must apprehend both the present material and mental phenomena conditioned by the past causes and the past conditioned material and mental phenomena on which those past causes depended…


<a id="M05-body-P041"></a>
## Mentality and materiality in the past, present, and future
Miến / Burmese 41

…and have distinguished them with knowledge. Again, if a meditator wishes to distinguish and apprehend with knowledge how the five future results, the conditioned mentality and materiality, arise due to the five present causes, one must apprehend and distinguish both the present mentality and materiality on which present causes such as ignorance, craving, clinging, formations, and kamma depend, and the future mentality and materiality constituting the five results that will arise due to those present causes.

The five present results form part of the five present aggregates. The five present causes also form part of the five present aggregates. Likewise, the five past causes form part of the five past aggregates, and the five future results form part of the five future aggregates. Thus, when one has systematically apprehended the five past, five present, and five future aggregates to the point of knowing them as ultimate realities, one can readily apprehend the corresponding portions: the five past causes, five present results, five present causes, and five future results.

In other words, one can readily apprehend and distinguish with knowledge how the five present results arise due to the five past causes and how the five future results arise due to the five present causes. Understand the same for successive past and successive future lives. Therefore, before apprehending how results arise due to causes, a good person…


<a id="M05-body-P042"></a>
## Four ways of teaching dependent origination
Miến / Burmese 42

…should first bear in mind the two points just made concerning the need to apprehend the five past, five present, and five future aggregates. Dependent origination is the causal connection between the conditioned mental and material phenomena occurring in the past, future, and present.

Four ways of teaching dependent origination

The Visuddhimagga (vol. 2, pp. 154–155) and the explanation of dependent origination in the Sammohavinodanī (Abhidhamma Commentary, vol. 2, pp. 124–125) explain four ways of teaching dependent origination, using the simile of four ways of taking hold of a creeper (vallihārakanaya).

1. Due to ignorance there are formations. The teaching proceeds in this way to how aging and death arise due to birth. This is a way of teaching dependent origination in forward order (anuloma), from the beginning to the end.

2. Beginning with feeling in the middle, the Buddha teaches the causal connection through to how birth arises due to becoming. This too is a way of teaching dependent origination in forward order, from the middle to the end.


<a id="M05-body-P043"></a>
## Reverse order and the fifth method
Miến / Burmese 43

3. It is also taught in reverse, beginning with aging and death due to birth as their cause, and going back to formations due to ignorance as their cause. This is a way of teaching dependent origination in reverse order (paṭiloma), from the end to the beginning.

4. The four kinds of nutriment arise due to craving. Craving arises due to feeling. The Buddha teaches in this way back to formations arising due to ignorance. This too is a way of teaching dependent origination in reverse order, from the middle to the beginning.

These are the four ways of teaching dependent origination. A further method occurs in the Pāli Paṭisambhidāmagga.

5. That text on dependent origination sets out how the five present results arise due to the five past causes and how the five future results arise due to the five present causes.

The method of apprehending the causes and effects in groups, as found in the Paṭisambhidāmagga, is called the fifth method of dependent origination in this book. The fifth method is readily taught to some meditators whose basic knowledge of Abhidhamma is still weak.

Among these five ways of teaching dependent origination, a good person can seek out the causes and effects by whichever method they prefer. Of these methods, the fifth is taken as the main one here in presenting how to apprehend the causal connection…


<a id="M05-body-P044"></a>
## Tracing from the middle to the beginning and the principle of many causes and results
Miến / Burmese 44

…between cause and effect. The search for causes begins by proceeding from the middle back to the beginning.

In searching for causes by tracing from the middle toward the beginning, as explained above in the Paṭisambhidāmagga Commentary, meditators who have already apprehended the continuity of the five aggregates from the present five aggregates back to the past five aggregates will find this easier. Therefore, apprehend the five aggregates, that is, mentality and materiality, from the present back to the past. The procedure presented here draws on the way of apprehending the succession of past aggregates described in the Visuddhimagga section on direct knowledge of former lives.

After apprehending the continuity of the five aggregates from the present back to the past, the meditator needs to trace and apprehend with knowledge how the five present aggregates, the resultant phenomena, become manifest due to the five past causes that arose within the five past aggregates. Once one has successfully apprehended the fifth method of dependent origination and can connect causes with effects, other methods, such as the first method of dependent origination, also become clear and easy for a good person to understand.

A point to understand beforehand

1. Ekato hi kāraṇato na idha kiñci ekaṃ phalamatthi.
2. Na anekaṃ.
3. Nāpi anekehi kāraṇehi ekaṃ.


<a id="M05-body-P045"></a>
## Why a teaching sometimes singles out one cause
Miến / Burmese 45

4. Anekehi pana kāraṇehi anekameva hoti. (Abhidhamma Commentary, vol. 2, p. 140. Visuddhimagga, vol. 2, p. 174.)

1. In this world, no single result arises from a single cause.
2. Nor do many results arise from a single cause.
3. Nor does a single result arise from many causes.
4. What actually occurs is that many results arise from many causes. (Abhidhamma Commentary, vol. 2, p. 140. Visuddhimagga, vol. 2, p. 174.)

In a discourse the Buddha sometimes singles out a cause or a result because it is principal (padhāna), evident (pākaṭa), or distinctive (asādhāraṇa). He does so in accordance with omniscience, the basis for presenting a well-ordered teaching, and in keeping with the dispositions of the beings who can be taught, namely humans, deities, and brahmās who can be guided. (Abhidhamma Commentary, vol. 2, p. 140. Visuddhimagga, vol. 2, p. 174.)


<a id="M05-body-P046"></a>
## Apprehending the associated phenomena as well
Miến / Burmese 46

As explained above, because a factor is principal, evident, or distinctive, the Buddha may single out one cause or result, such as ignorance, when teaching. He does so in accordance with omniscience, by which he can present a well-ordered discourse, and to suit the preferences, dispositions, and inclinations of those who can be guided. Yet one result cannot arise from a single cause, many results cannot arise from a single cause, and one result cannot arise from many causes. What actually occurs is that many results arise from many causes.

One should not assume that ignorance alone produces formations by themselves, that the six bases alone produce contact by itself, or that a single contact alone produces a single feeling. Understand that many results arise from many causes. It is insufficient to apprehend only ignorance, contact, or feeling in isolation. Remember to apprehend the phenomena associated with that ignorance, contact, or feeling as well. Understand the same at other points.

Try directing knowledge toward the past

First establish concentration in stages. Repeatedly apprehend internal and external mentality and materiality, alternating between one’s own continuity and that of others. In particular, for the external aspect…


<a id="M05-body-P047"></a>
## Using concentration and light to apprehend mentality and materiality
Miến / Burmese 47

…give priority to apprehending mentality and materiality in groups of beings on the mind-object track, designated track six. For many meditators, when they often and repeatedly give priority to apprehending these, the light grows progressively stronger. Repeatedly apprehend internal and external mentality and materiality in alternation. Before searching for the causes and conditions, the Buddha himself instructed in the Great Discourse on the Establishments of Mindfulness to apprehend mentality and materiality internally and externally. This was explained earlier in the section on the subject of mentality meditation. In particular, a meditator who cannot yet apprehend external mentality and materiality will find it very difficult to apprehend past mentality and materiality, because discerning the past is similar in nature to discerning external mentality and materiality.

When internal and external mentality and materiality have been apprehended, one’s own six kinds of clear materiality, those of the eye, ear, nose, tongue, body, and mind door, become progressively clearer to knowledge. Through the knowledge that is apprehending internal and external mentality and materiality, the light also grows stronger. Then try to see owing to which causes these material and mental phenomena are present. With the wish to know the causes, direct the mind toward the past. Direct knowledge there. When the light arising from that knowledge illuminates the surroundings, many meditators notice that it gradually shines more clearly toward the object to which they are attending.


<a id="M05-body-P048"></a>
## Further ways of looking for past causes
Miến / Burmese 48

Use the light of that knowledge to illuminate the past causes and look for them. Sometimes a wholesome formation and deed generated and accumulated in the past, which are root causes of present resultant mentality and materiality, will appear. This method is described in the commentaries. (Abhidhamma Commentary, vol. 2, p. 241. Majjhima Commentary, vol. 1, p. 281.)

If one tries to find past causes in this way without success, use the procedure in the Visuddhimagga section on direct knowledge of former lives. Begin with the mentality and materiality that arose in the most recent meditation sitting, go back step by step into the past, and try to apprehend mentality and materiality. Many meditators have succeeded with this method.

If this method also proves unsuccessful and one still cannot find past causes, try apprehending the causal connection from the middle back to the beginning, starting with the four kinds of nutriment. A meditator looking for causes in this way, however, needs to be well versed in the teaching of dependent origination.

The following pages set out in sequence how to use the method from the section on direct knowledge of former lives, beginning with the mentality and materiality that arose in the most recent sitting, to apprehend past mentality and materiality and to find and apprehend the causal connection.

Before sitting in meditation, a good person should make an offering to the Buddha of a lamp, water, or flowers, and then make an aspiration as follows…


<a id="M05-body-P049"></a>
## Making an aspiration and apprehending mentality and materiality before sitting
Miến / Burmese 49

Then aspire to a life you prefer, such as that of a bhikkhu or that of a woman, if you must continue wandering in saṃsāra before attaining Nibbāna. Since wholesome kamma conducive to the round (vaṭṭanissita) belongs to the truth of origin, a good person will readily be able to find how the truth of suffering arises from that truth of origin. In this way one can generate a wholesome deed conducive to the round for examination. Take note of and remember the succession of consciousness that arose while doing the deed and making the aspiration.

Then, at the place where you sit to meditate, establish concentration in stages and apprehend mentality and materiality internally and externally. In particular, give priority to apprehending the successions of wholesome impulsion processes on the mind-object track. If you take tranquillity as your vehicle, give priority here to apprehending the mental phenomena of jhāna. When the light is very strong, try to apprehend the mental phenomena that arose during the movements just before sitting, such as the successions of consciousness while offering flowers, a lamp, or water, while aspiring to the life of a bhikkhu or a woman, and while aspiring to attain Nibbāna.

When wishing to apprehend those mental phenomena, first apprehend the fifty-four kinds of materiality, including the heart-base, on which they depend at the heart. To apprehend that materiality, first apprehend the four great elements in the body at the time of making the aspiration and doing the wholesome deed. In particular, apprehend the four great elements in the heart region at that time. When the material groups (rūpakalāpa) are discerned, apprehend the fifty-four kinds of materiality including the heart-base…


<a id="M05-body-P050"></a>
## Apprehending recent mentality and materiality for a tranquillity practitioner
Miến / Burmese 50

…and continue by apprehending the clear life-continuum consciousness that arises dependent on the heart-base. Having apprehended the mind door, the clear life-continuum, trace back and forth through it and continue apprehending the mental phenomena called the succession of process consciousness that arises between moments of life-continuum. Having apprehended these mental phenomena, examine repeatedly whether they match the succession of consciousness that actually arose before the sitting. If they match, you have succeeded in apprehending the mentality and materiality of the nearest past, during the movements before sitting.

The case of a tranquillity practitioner

If a good person takes tranquillity as the vehicle and wishes for happiness in a brahmā realm, let them strive in accordance with their aspiration to attain a jhāna that can lead to the corresponding brahmā realm, such as the first jhāna, the second, or another jhāna. If they have actually attained it, let them enter it once. Just before or after entering it, let them aspire to birth in the corresponding brahmā realm, or make that resolve mentally. Making the aspiration or resolve generates and accumulates the round of defilements headed by ignorance, craving, and clinging. Repeatedly entering jhāna generates and accumulates the round of kamma consisting of formations and kamma.

Then go back in sequence to apprehend both the mental phenomena of the rounds of defilements and kamma and the material phenomena that serve as their bases…


<a id="M05-body-P051"></a>
## The rounds of defilements and kamma
Miến / Burmese 51

…If that mentality and materiality can be apprehended, the apprehension of the nearest past mentality and materiality has succeeded. In apprehending past mentality and materiality in this way, remember to give priority to the heart-base on the material side and to the clear life-continuum at the mind door on the mental side.

The rounds of defilements and kamma

Let us explain further the ignorance, craving, clinging, formations, and kamma mentioned above, which keep the round of rebirths going. Ignorance, craving, and clinging belong to the round of defilements. Formations and kamma belong to the round of kamma. Ignorance has no power to arise by itself, and neither do craving and clinging. They arise only in groups. In the aspiration just described, craving that reaches the strength capable of bringing about the desired life is called clinging.

Avijjāsamudayā āsavasamudayo. (Majjhima, vol. 1, p. 65.)
Āsavasamudayā avijjāsamudayo. (Majjhima, vol. 1, p. 65.)

According to these teachings, the taints arise with ignorance as their cause, and ignorance arises with the taints as its cause. Ignorance and the taints condition each other. The phenomena of ignorance, craving, and clinging are included among the taints. Therefore, in the round of defilements, ignorance together with craving and clinging can arise in one mind-door process, or they may arise in separate processes. In this section on dependent origination, ordinarily…


<a id="M05-body-P052"></a>
## Three phenomena in the round of defilements
Miến / Burmese 52

…they commonly arise in the greed group associated with wrong view. In rare cases they may arise in a greed group accompanied by conceit. Formations may be prompted or unprompted, according to the case. Here a greed-rooted consciousness accompanied by joy, associated with wrong view, and unprompted is taken as an example and numbered twenty. Similarly, the phenomena in the round of kamma called formations and kamma arise only in groups and have no power to arise singly. Here a great wholesome consciousness accompanied by joy, associated with knowledge, and unprompted is taken as an example and numbered thirty-four. The rounds of defilements and kamma can nevertheless differ between people and cases. Understand it in this way.

Three phenomena in the round of defilements

When offering flowers, a lamp, or water to the Buddha and then aspiring to a bhikkhu’s life, the three phenomena of the round of defilements are as follows:
1. Ignorance (20) — the quality of mistakenly knowing that there is a bhikkhu.
2. Craving (20) — the quality of desiring and delighting in a bhikkhu’s life.
3. Clinging (20) — the quality of the mind going toward and holding to a bhikkhu’s life.

If a good person is a woman and aspires to a woman’s life, the three phenomena of the round of defilements are as follows:
1. Ignorance (20) — the quality of mistakenly knowing that there is a woman.
2. Craving (20) — the quality of desiring and delighting in a woman’s life.
3. Clinging (20) — the quality of the mind going toward and holding to a woman’s life.

Here twenty refers to the whole greed group associated with wrong view in each moment of impulsion…


<a id="M05-body-P053"></a>
## Two phenomena in the round of kamma
Miến / Burmese 53

…Mental phenomena in groups of nineteen, twenty-two, or twenty-one can also arise, according to the case. Examine carefully how they actually arose, are arising, or will arise in your own continuity.

Two phenomena in the round of kamma

4. Formations (34) — the group of wholesome volition while offering flowers, a lamp, or water to the Buddha. Here it is a great wholesome consciousness accompanied by joy, associated with knowledge, and unprompted.
5. Kamma — the kammic power of those formations (34).

Ignorance, craving, and clinging, collectively called the round of defilements, commonly arise in a mind-door process with seven moments of impulsion. They can sometimes arise with a kamma object, namely the mentality and materiality in the bhikkhu’s life or woman’s life to which one has aspired. Here the greed group associated with wrong view, with twenty mental phenomena in each moment of impulsion, is given as the example.

The phenomena belonging to the round of kamma, called formations and kamma, also occur within the succession of great wholesome impulsion processes at the mind door. An impulsion may be associated with knowledge or dissociated from it. Here great wholesome impulsion accompanied by joy, associated with knowledge, and unprompted, with thirty-four mental phenomena, is given as an example. Apprehend these phenomena as they actually arise in your own continuity of mentality and materiality when accumulating kamma. A wholesome impulsion may be accompanied by joy or equanimity, associated with knowledge or dissociated from it, prompted or unprompted, according to the case.


<a id="M05-body-P054"></a>
## Kammic power and the case of aspiring to a brahmā realm
Miến / Burmese 54

Those wholesome volitions at impulsion, the phenomena belonging to the group of formations, are impermanent. At the end of their span of arising, presence, and dissolution, they cease. Before ceasing, however, they have established in the continuity of mentality and materiality a kammic power capable of bringing forth the aspired-to life of a bhikkhu or a woman in a future existence. Resultant and functional mental phenomena, by contrast, cease without leaving such a kammic power. The power to bring forth the result is called kamma, the power of asynchronous kamma condition (nānakkhaṇikakammapaccaya). We now continue with the second aspiration, the aspiration to a brahmā life.

The second aspiration: a brahmā life

1. Ignorance (20) — the quality of mistakenly knowing that there is a brahmā.
2. Craving (20) — the quality of desiring and delighting in that brahmā life.
3. Clinging (20) — the quality of the mind going toward and holding to that brahmā life.
4. Formations (31) — the group of wholesome volition of the fourth jhāna generated and accumulated with the aspiration to a brahmā life.
5. Kamma — the kammic power of those formations (31).

In the round of defilements comprising ignorance, craving, and clinging, the greed group associated with wrong view comprises twenty mental phenomena. In the fourth-jhāna formations there are thirty-one mental phenomena. These are successions of mind-door impulsion processes.

If a good person can apprehend and discern the mental phenomena of the rounds of defilements and kamma that arose during the most recent activity, using knowledge to break through the perception of compactness in mentality and reach ultimate mentality…


<a id="M05-body-P055"></a>
## Procedure when an image appears
Miến / Burmese 55

…then apprehending the mentality and materiality of the nearest past has succeeded.

Procedure when an image appears

Suppose a good person is alternately apprehending internal and external mentality and materiality, and the light grows very strong through the knowledge that distinguishes mentality and materiality. If one uses that light to attend to mentality and materiality in the most recent activity, an image of someone making an aspiration before the sitting may appear. This is seeing under the light. First apprehend the four great elements there, directing knowledge to see them. Treat the image as external mentality and materiality and attend to the four great elements as when seeking external mentality and materiality. A good person who has apprehended external mentality and materiality to the level of ultimate materiality will not find this very difficult.

Before long one will find the particles that are material groups. Continue apprehending the ultimate material phenomena in those groups through the six doors and the forty-two parts of the body. Give priority to the fifty-four kinds of materiality in the heart region, and among these to the heart-base. Continue apprehending the clear life-continuum consciousness, the mind door, which arises dependent on the heart-base. Then, between moments of that clear life-continuum, continue apprehending the mental phenomena arising dependent on the heart-base…


<a id="M05-body-P056"></a>
## Tracing back through past mentality and materiality step by step
Miến / Burmese 56

…Continue apprehending the succession of mental phenomena. After apprehending it in this way, examine carefully whether the succession of mental phenomena apprehended is the one that actually arose while making the aspiration. If they match completely, then apprehending the nearest past mentality and materiality has succeeded.

Once you have succeeded in this way, gradually direct knowledge toward the past. Apprehend in careful detail, step by step, the mentality and materiality of this morning, yesterday, last month, last year, and so on. If images of doing wholesome or unwholesome deeds, being content or discontent, rejoicing or grieving appear in between, apprehend the four great elements in those images and continue apprehending mentality and materiality as described above.

Gradually continue apprehending mentality and materiality back to entry into the mother’s womb. The more closely one can apprehend it, the better. While doing this, many meditators find images of themselves growing gradually younger. But the images are not the main point here. Mentality and materiality are. Even without seeing images, it is better if one can see ultimate mentality and materiality all the way back to entry into the mother’s womb.


<a id="M05-body-P057"></a>
## From rebirth-linking to the death-proximate period of the preceding life
Miến / Burmese 57

For human beings, at the rebirth-linking moment upon entry into the mother’s womb, there are three types of material groups: the heart-base decad, the body decad, and the sex decad. Counted by type of materiality, there are thirty. There are only three types of group, comprising thirty types of materiality, but each type of group may occur many times. That depends on the kamma giving the result. On the mental side, for one whose rebirth-linking consciousness is accompanied by joy, there are thirty-four great resultant mental phenomena accompanied by joy and associated with knowledge. Apprehend this mentality and materiality until the eye of knowledge becomes clear. When able to apprehend it to the level of ultimate reality with a clear eye of knowledge, investigate and distinguish as follows.

So “idaṃ nāmarūpaṃ na ahetu na appaccayā nibbattaṃ, sahetu sappaccayā nibbattaṃ. Ko panassa hetu, ko pana paccayo”ti upaparikkhanto “avijjāpaccayā, taṇhāpaccayā, kammapaccayā, āhārapaccayā cā”ti tassa paccayaṃ vavatthapetvā “atītepi paccayā ceva paccayasamuppannadhammā ca, anāgatepi etarahipi paccayā ceva paccayasamuppannadhammā ca. Tato uddhaṃ satto vā puggalo vā natthi, suddhasaṅkhārapuñjo evā”ti tīsu addhāsu kaṅkhaṃ vitarati. Ayaṃ pana vipassanāsaṅkhārasallakkhaṇañātapariññā nāma. (Abhidhamma Commentary, vol. 2, pp. 241–242.)

The meditator should investigate and distinguish with knowledge in this way: “This mentality and materiality did not arise in the absence of the direct cause that produces it or of the supporting condition…”


<a id="M05-body-P058"></a>
## Finding the death-proximate object and tracing back to the causal kamma
Miến / Burmese 58

“…Mentality and materiality arise only when there is a direct cause that brings it forth and a supporting condition. What is its direct cause? What is its supporting condition?” When directing knowledge to the past to investigate in this way, the meditator often begins to see both the mentality and materiality that arose near death in the former life and one of the three objects taken by the death-proximate mental phenomena: kamma, a sign of kamma, or a sign of the destination.

If one can apprehend mentality and materiality near death, it becomes very easy to find one of the three objects of those mental phenomena: kamma, a sign of kamma, or a sign of the destination. Remember that the death-proximate sign appears through the power of the kamma about to give its result. Thus once that sign is found, one can be confident of finding the formations and kamma that are the root causes of the resultant aggregates, such as the five present rebirth-linking aggregates. Once formations and kamma have been found, continue looking for the ignorance, craving, and clinging that surround them.

When a good person investigates past causes with knowledge and apprehends mentality and materiality at the time near death…


<a id="M05-body-P059"></a>
## When an image of a dying person or a corpse appears
Miến / Burmese 59

…and has yet to see that mentality and materiality, if an image of a person dying or of the period near death appears, begin by apprehending the four great elements in that dying body. When particles of material groups are seen, analyze those groups with knowledge, then continue apprehending the ultimate materiality of the temperature-produced octad.

The statement that there are temperature-produced octads in the corpse concerns the ordinary case. At that very time, a meditator can sometimes see mixed among them particles of material groups belonging to living creatures that inhabit the corpse. Thus some meditators see both transparent and non-transparent material groups mixed together in the corpse. Those living creatures have at least the transparent material groups called body decads. In the corpse itself there are only the non-transparent temperature-produced octads.

After apprehending the material phenomena in the corpse, direct attention into the past, go back step by step, and try to apprehend mentality and materiality near death before death occurs. If able to apprehend it, continue by apprehending the object of the impulsions that arise near death. If unsuccessful, apprehend the heart-base near death until it can be seen clearly. Then continue apprehending the clear life-continuum consciousness, the mind door, that arises dependent on the heart-base. If able to apprehend that clear life-continuum, continue to apprehend the death-proximate mentality and materiality…


<a id="M05-body-P060"></a>
## Finding the object of death-proximate impulsion
Miến / Burmese 60

…Continue apprehending the clear life-continuum consciousnesses that often arise repeatedly without interruption during that time. Examine back and forth over both the period before death and the later part of the death-proximate period. Once one can apprehend those clear life-continuum consciousnesses, one can find and apprehend one of the three signs appearing at the mind door as the object of death-proximate impulsion: kamma, a sign of kamma, or a sign of the destination. On examining proficient meditators, it is found that many experience kamma or a sign of kamma, while very few experience a sign of the destination.

If the sign appearing near death is kamma as the object, then according to the explanation using the expression abhinavakaraṇavasena in the Abhidhammatthasaṅgaha, section on the process-free, p. 90, the sign appears through the power of a wholesome deed being performed afresh. One must go back and apprehend the mentality and materiality that arose at the time of performing that deed.

How to find kamma as the object

First apprehend the four great elements in the image of the wholesome deed being done. When the material groups appear, analyze them and apprehend the material phenomena to the level of ultimate materiality. Give priority to the fifty-four kinds of materiality in the heart region, including the heart-base, that arose when doing that deed. Then apprehend the heart-base itself, and continue apprehending the clear life-continuum consciousness, the mind door, that arises in dependence on it. Then, between those moments of life-continuum…


<a id="M05-body-P061"></a>
## Finding the succession of consciousness when kamma was made
Miến / Burmese 61

…continue apprehending the groups of mental phenomena arising in between while the wholesome deed was being done. In doing so, look closely at the mental phenomena arising before, during, and after the deed. Direct knowledge to see clearly what kind of wholesome deed is being performed and what kind of succession of great wholesome impulsion processes at the mind door is arising.

If one discerns back and forth repeatedly, one will find the group of ignorance, craving, and clinging connected with the purpose and intention of doing the wholesome deed, and also what kind of wholesome impulsion process is arising as formations and kamma. In other words, one will find the round of defilements and the round of kamma, namely wholesome formations and kamma surrounded by ignorance, craving, and clinging. Note that wholesome formations and kamma are singled out here because those that give rise to human life and the human aggregates are wholesome formations and kamma.

Princess Sumanā’s former aspiration

To understand ignorance, craving, clinging, formations, and kamma more deeply, here is a former aspiration of Princess Sumanā, the well-known daughter of the king of Kosala. When Buddha Vipassī appeared, this good woman offered a garland of jasmine and food to the Saṅgha headed by Buddha Vipassī and then made the following aspiration.


<a id="M05-body-P062"></a>
## Five causes in Princess Sumanā’s aspiration
Miến / Burmese 62

Bhavābhavābhinibbattiyaṃ me sati paritassanajīvitaṃ nāma mā hotu. Ayaṃ sumanamālā viya nibbattanibbattaṭṭhāne piyāva homi, nāmena ca sumanāyeva. (Aṅguttara Commentary, vol. 3, pp. 13–14.)

“If I am still to be born in one existence or another, great or small, may I never have to earn my living in anxiety, want, and distress. Wherever I am born, may I be a woman loved by everyone, like this precious jasmine garland. May my name also be Sumanā.” (Aṅguttara Commentary, vol. 3, pp. 13–14.)

In examining that wholesome deed and aspiration, both the round of defilements and the round of kamma can be seen in full:
1. Ignorance — the quality of mistakenly knowing that there is a woman named Sumanā, loved by everyone and living without anxiety or want in her livelihood.
2. Craving — the quality of desiring and delighting in that woman’s life.
3. Clinging — the quality of the mind going toward and holding to that woman’s life.
4. Formations — the group of wholesome volition when offering a jasmine garland and food to the Saṅgha headed by Buddha Vipassī.
5. Kamma — the kammic power of that group of wholesome volition belonging to formations.

These five causes are causes of the five rebirth-linking aggregates and other resultant aggregates of Princess Sumanā, the king of Kosala’s daughter. (See Aṅguttara Commentary, vol. 3, pp. 13–14.)


<a id="M05-body-P063"></a>
## Five causes in Anojādevī’s aspiration
Miến / Burmese 63

In the time of Buddha Kassapa, a thousand weavers’ families, led by those who would later become Venerable Mahākappina and the elder nun Anojā, built a large and splendid monastery and offered it to the Saṅgha headed by the Buddha. At that offering, the good woman who would later become Anojādevī, the elder nun Anojā, placed a set of robes worth a thousand pieces, the color of anoja flowers, on a tray full of those flowers. She placed it at Buddha Kassapa’s feet as an offering and made the following aspiration.

Bhante, nibbattanibbattaṭṭhāne anojapupphavaṇṇameva me sarīraṃ hotu, Anojā eva ca me nāmaṃ hotu. (Dhammapada Commentary, vol. 1, p. 353.)

“Venerable sir, wherever I am born, may my body have the color of the anoja flower. May my name also be Anojā.” (Dhammapada Commentary, vol. 1, p. 353.)

1. Ignorance — the quality of mistakenly knowing that there is a woman named Anojā, with the color of the anoja flower.
2. Craving — the quality of desiring and delighting in that woman’s life.
3. Clinging — the quality of the mind going toward and holding to that woman’s life.
4. Formations — the group of wholesome volition while offering the monastery, flowers, and robes.
5. Kamma — the kammic power of that group of wholesome volition belonging to formations.


<a id="M05-body-P064"></a>
## The result of Anojā’s aspiration and the story of Queen Subhaddā
Miến / Burmese 64

Through that wholesome deed she became Anojādevī, the future elder nun Anojā, a woman whose complexion resembled the anoja flower. The five causal phenomena mentioned above were causes of her five rebirth-linking aggregates and of some phenomena in her round of results. When ignorance, craving, and clinging surround and support formations and kamma, the latter produce their corresponding results. It was a picture painted in the time of Buddha Kassapa.

Queen Subhaddā

Once the Buddha was teaching from the Dhamma seat at Jetavana in Sāvatthī. A young bhikkhunī looked upon the Buddha, endowed with ten bodily powers and ten powers of knowledge, whose excellent form had become manifest through the power of immeasurable perfections and wholesome deeds. She wondered whether, in wandering through saṃsāra, she had ever served at the feet of this eminent man.

Just then, knowledge that could trace back and recollect former lives arose in the young bhikkhunī’s continuum. Looking back with that knowledge, she vividly recalled the painful story of her life as Cūḷasubhaddā, consort of the elephant king Chaddanta, and burst into loud tears. The Buddha then related to the assembly the birth story of the elephant king Chaddanta…


<a id="M05-body-P065"></a>
## The two she-elephants and the circumstances of their offering
Miến / Burmese 65

…Chaddanta, the elephant king, had two consorts, Cūḷasubhaddā and Mahāsubhaddā. The young bhikkhunī had been Cūḷasubhaddā.

One day Chaddanta went with the herd into a grove of blossoming sāla trees. When the elephant king shook a tree, dry branches and leaves fell on Cūḷasubhaddā, who stood upwind, while pollen and petals fell on Mahāsubhaddā, who stood downwind. Cūḷasubhaddā was displeased. On another day, while the elephants played in Lake Chaddanta, one elephant obtained a large paduma lotus called sattuddhaya and presented it to the elephant king. With his trunk he lifted the lotus, shook its pollen over Mahāsubhaddā, and gave her the flower. Cūḷasubhaddā was displeased with this too. Because of these two incidents she came to bear a grudge against the Bodhisatta, Chaddanta.

At that time more than eight thousand elephants, led by Chaddanta, had an opportunity to offer fruit, food, and the like to five hundred solitary Buddhas. This was a rare opportunity. The herd led by Chaddanta was also endowed with pure virtue. Their giving thus met the following five conditions.

1. The donor is virtuous.
2. The gift is obtained by righteous means.
3. The mind has clear confidence.


<a id="M05-body-P066"></a>
## Giving with the requisite conditions and Cūḷasubhaddā’s aspiration
Miến / Burmese 66

4. There is firm confidence in kamma and its results.
5. The recipients also possess pure virtue.

The giving fulfilled these five conditions. See the Discourse on the Analysis of Offerings (Dakkhiṇāvibhaṅgasutta). It was a kind of giving capable of producing abundant and excellent results. As stated in the teaching “Ijjhati, bhikkhave, sīlavato cetopaṇidhi visuddhattā” (Aṅguttara Nikāya, vol. 3, p. 71), because virtue is pure, that gift can fulfil the aspirations of the mind. Cūḷasubhaddā understood that this was a great opportunity. So after offering her own fruit to the solitary Buddhas, she made the following aspiration.

“Bhante, ito cavitvā Maddarājakule nibbattitvā Subhaddā nāma rājakaññā hutvā vayappattā Bārāṇasirañño aggamahesibhāvaṃ patvā tassa piyā manāpā taṃ attano ruciṃ kāretuṃ samatthā hutvā taṃ ācikkhitvā ekaṃ luddakaṃ pesetvā imaṃ hatthiṃ visapītena sallena vijjhāpetvā jīvitakkhayaṃ pāpetvā chabbaṇṇaraṃsiṃ vissajjente yamakadante āharāpetuṃ samatthā homi.” (Jātaka Commentary, vol. 5, p. 40)

1. Venerable ones, when I die here, may I be born in the royal family of Madda.
2. May I be a princess named Subhaddā in that family.
3. When I come of age, may I become the chief queen of the king of Kāsi.
4. May I be the queen whom that king of Kāsi loves and trusts.


<a id="M05-body-P067"></a>
## The aspiration for revenge and the five causal phenomena
Miến / Burmese 67

5. May I be able to make the king of Kāsi act as I wish.
6. May I persuade the king of Kāsi to send a hunter to kill Chaddanta with a poisoned arrow.
7. May I be able to have the elephant king’s tusks brought back, radiating six colors.

That was the aspiration of Cūḷasubhaddā, the future queen.
1. Ignorance — the quality of mistakenly knowing that there is a chief queen named Subhaddā endowed with the abilities mentioned above.
2. Craving — the quality of desiring and delighting in that life as queen.
3. Clinging — the quality of the mind going toward and holding to that life.
4. Formations — the group of wholesome formations when offering fruit and food to the solitary Buddhas.
5. Kamma — the kammic power of that group of wholesome formations.

The five causal phenomena were complete. This was the kind of kamma that had yet to be undone and eradicated by the noble path at the very place where it had been accumulated. In accordance with her aspiration, after dying as an elephant she was born as Princess Subhaddā of Madda. She became the chief queen of the king of Kāsi and attained the foremost position among sixteen thousand women of the palace.


<a id="M05-body-P068"></a>
## Chaddanta and the hunter Soṇuttara
Miến / Burmese 68

By this point she might have been satisfied. Yet the queen was still dissatisfied. Even as chief queen she could not rest until Chaddanta, an animal living in the forest, had been killed. The kammic power accumulated in the past kept urging her on, so that she could not give up the intention to kill. This was the power of formations and kamma still surrounded by ignorance, craving, and clinging. Finally she sent the hunter Soṇuttara and obtained Chaddanta’s tusks. The painful scene unfolded as follows.

“Evarūpaṃ sobhaggappattaṃ vāraṇaṃ visapītena sallena jīvitakkhayaṃ pāpetvā ime dante chinditvā Sonuttaro āgato”ti mahāsattaṃ anussarantī sokaṃ uppādetvā adhivāsetuṃ nāsakkhi. Athassā tatheva hadayaṃ phali, taṃ divasameva kālamakāsi. (Jātaka Commentary, vol. 5, p. 56)

When the hunter Soṇuttara presented the magnificent tusks, radiant in six colors, Queen Subhaddā lifted them onto her lap and looked at them. It was as if she saw her beloved husband from her former life, and she remembered the Bodhisatta’s virtues: “An elephant king of such form and stature has now been shot dead with a poisoned arrow. The hunter Soṇuttara has cut off his tusks and brought them back.” As she looked at the tusks and remembered the Bodhisatta’s virtues, sorrow at separation from the one she loved arose. The sorrow was so strong that her heart broke and she died that very day. (Jātaka Commentary, vol. 5, p. 56.)


<a id="M05-body-P069"></a>
## An example from a meditator
Miến / Burmese 69

In her life as Queen Subhaddā, she had one rebirth and one death. Now, in her life as a bhikkhunī, she was reborn a second time. Thus a good person should exercise great care in making kamma. By this point, ignorance, craving, clinging, formations, and kamma should be fairly clear.

To make this clearer, here is another example from a meditator. On directing attention to the object of the near-death process in the previous life and discerning mentality and materiality, the meditator saw a sign of kamma manifest in the mind just before that process, namely the offering of fruit to a member of the Saṅgha. Continuing to discern mentality and materiality based on the four great elements in the continuum at the time of the offering, the meditator saw the mental processes of aspiring to become a woman in a large city with a modern education, weary of the poverty, hardship, and lack of modern education of rural life. The meditator also saw the mental processes of the group of wholesome volitions in offering fruit. They included the following.

1. Ignorance (avijjā, 20) is the mistaken perception of a city woman with a modern education.
2. Craving (taṇhā, 20) is longing and attachment for that woman's life.
3. Clinging (upādāna, 20) is the mind's firm attachment to that woman's life.


<a id="M05-body-P070"></a>
## Discerning cause and effect, and another example
Miến / Burmese 70

4. Formation (saṅkhāra, 34) is the group of wholesome volition in offering fruit to the member of the Saṅgha.
5. Kamma is the productive power of that formation (34).

Here, 20 denotes the twenty mental phenomena of the group with greed and wrong view, present in greed impulsions of the mind-door process belonging to the round of defilements. The number 34 denotes the mental factors together with consciousness in the wholesome impulsions of the mind-door process while offering the fruit, namely the mental phenomena of the group with faith and wisdom.

In this life, that meditator became a city woman with a modern education. Discerning the causal relationship personally, the meditator saw with right view that the productive power of the wholesome kamma of offering fruit conditioned the five rebirth aggregates and the resultant aggregates during the present life. Knowledge that penetrates the relationship between causal phenomena and resultant phenomena in this way is knowledge of discerning conditions (paccayapariggahañāṇa), knowledge that discerns the causal phenomena. Consider the following example to make this clearer.

A woman meditator investigated the object at the approach of death in her past life. As she repeatedly examined backwards from the approach of death to the time before death, she saw the following kammas appearing around the time before her death.


<a id="M05-body-P071"></a>
## Insight kamma and aspirations
Miến / Burmese 71

1. A kamma of giving a book.
2. A kamma of instructing someone in the Dhamma.
3. A kamma of attending to the Dhamma.
4. A kamma of teaching the Dhamma.

The four kammas appeared in turn. Repeatedly investigating which kamma had produced the five rebirth aggregates and the resultant phenomena during this life, she found that the kamma of attending to the Dhamma was giving its result. That act of attending to the Dhamma was the kamma that appeared as her object at the approach of death. When she examined which phenomena she was attending to, she found that it was insight kamma: discerning and examining the ultimate phenomena of materiality and mentality in terms of the three characteristics. Discern the causal relationship between that insight kamma and the five present rebirth aggregates until proficient. When she further examined why this insight kamma gave rise to rebirth, she saw that while cultivating insight, each time she finished cultivating the insight meditation subject, she would make the following aspirations.

1. May I be reborn as a human being.
2. May I go forth.
3. May I encounter the Buddha's Dispensation.

These were the three aspirations the woman meditator regularly made when she sat to meditate.
1. Ignorance (avijjā, 20) is the mistaken perception of a human being, a bhikkhu, and a person who has encountered the Dispensation.


<a id="M05-body-P072"></a>
## Insight kamma can give a rebirth result
Miến / Burmese 72

2. Craving (taṇhā, 20) is longing and attachment for that life.
3. Clinging (upādāna, 20) is the mind's firm attachment to that life.
4. Formations (saṅkhāra, 34) are the group of wholesome insight formations.
5. Kamma is the productive power of those formations (34).

The five causal phenomena are thus complete. One may ask whether these insight kammas can yield rebirth and similar results, as in the example above. The answer is that they can yield results.

“No ce, bhikkhave, ceteti, no ce pakappeti, atha ce anuseti, ārammaṇametaṃ hoti viññāṇassa ṭhitiyā.” (Saṃyutta Nikāya, vol. 1, p. 295, Cetanāsutta)

No ce bhikkhave cetetīti iminā tebhūmakacetanāya appavattanakkhaṇo vutto. No ce pakappetīti iminā taṇhādiṭṭhikappānaṃ appavattanakkhaṇo. Atha ce anusetīti iminā tebhūmakavipākesu parittakiriyāsu rūpeti ettha appahīnakoṭiyā anusayo gahito. Ārammaṇametaṃ hotīti anusaye sati kammaviññāṇassa uppattiyā avāritattā etaṃ anusayajātaṃ paccayova hoti. (Saṃyutta Commentary, vol. 2, p. 66.)

“Bhikkhus, if one does not intend” refers to the occasion when volition belonging to the three planes does not occur. “If one does not plan” refers to the occasion when planning through craving and views does not occur. “But if there is an underlying tendency” takes the tendency in the sense that it has not been abandoned in relation to results belonging to the three planes, sense-sphere functional states, and materiality. “This is an object” means that, while the underlying tendency remains, the arising of kamma-consciousness is unobstructed. Hence that underlying tendency serves as a condition.

Ettha ca “no ce bhikkhave ceteti no ce pakappeti, atha ce anusetī”ti evaṃ bhagavatā dutiyanaye pubbabhāge bhavanibbattakakusalākusalāyūhanaṃ, pakappanañca vināpi bhavesu diṭṭhādīnavassa yogino anusayapaccayā vipassanācetanāpi paṭisandhijanakā hotīti dassanatthaṃ kusalākusalassa appavatti cepi tadā vijjamānatebhūmakavipākādidhammesu appahīnakoṭiyā anusayitakilesapaccayā bhavavaṭṭassa kammaviññāṇassa patiṭṭhitatā hotīti dassanatthañca vuttaṃ. (Saṃyutta Subcommentary, vol. 2, p. 83.)

In the second presentation the Blessed One spoke thus to show that, even without prior accumulation of wholesome or unwholesome kamma productive of existence, and without planning, insight volition can still generate rebirth-linking in a meditator who has seen the danger in states of existence, owing to the underlying tendencies. He also spoke thus to show that, even when wholesome and unwholesome states are not occurring then, the establishment of kamma-consciousness in the round of existence occurs, conditioned by latent defilements still unabandoned in relation to phenomena then present, such as results belonging to the three planes.


<a id="M05-body-P073"></a>
## Burmese page 73
Miến / Burmese 73

Bhikkhus… Even if one does not exert oneself to bring forth wholesome or unwholesome volition that keeps the round of saṃsāra turning, and does not plan or imagine in association with craving and views, for example, “May I become a human being, may I become a deva,” the underlying tendency is still present because the noble path has yet to eradicate it. The very presence of that underlying tendency is a cause for the establishment, in a future life, of kamma-consciousness capable of giving the result of rebirth-linking. (Saṃyutta Nikāya, vol. 1, p. 295.)

When the underlying tendency is still present because the noble path has yet to eradicate it, the arising of kamma-consciousness capable of giving the result of rebirth-linking in a future life cannot be prevented. Hence the continued presence of the underlying tendency is a cause for the establishment of kamma-consciousness. (Saṃyutta Commentary, vol. 2, p. 66.)

In the Cetanāsutta the Buddha taught the following three cases.
1. Wholesome and unwholesome states belonging to the round, associated with craving and views or occurring.
2. Wholesome and unwholesome states tending away from the round, unassociated with craving and views, or volition of the three planes in the case where that volition does not occur.
3. Functional consciousness arising in the continuum of arahants who have abandoned the underlying tendencies, such as consciousness in giving, observing virtue, and developing serenity and insight.


<a id="M05-body-P074"></a>
## Burmese page 74
Miến / Burmese 74

The Buddha taught in these three ways. In the second, item 2 translated above, before and after practising insight the meditator does not exert effort to produce wholesome or unwholesome kamma capable of producing existence. Nor does the meditator plan or imagine with craving and views, “May I become a man, may I become a woman, may I become a human being, may I become a deva.” The meditator sees the danger in states of existence. In such a meditator, because the underlying tendencies are still present in the continuum, insight volition associated with insight knowledge is still capable of producing rebirth-linking. The Buddha taught the second way to make this meaning clear.

Insight kamma is a kind of kamma that brings to exhaustion the kammas that keep the round of saṃsāra turning. While insight knowledges arise without interruption, wholesome and unwholesome states that keep the round turning have no opportunity to arise. Yet at the moment insight knowledge arises, the underlying defilements remain latent, because the noble path has yet to eradicate them in relation to the phenomena present in the meditator’s continuum of mentality and materiality, including results belonging to the three planes, sense-sphere functional states, and materiality. Precisely because those underlying defilements are still present, kamma-consciousness capable of producing rebirth-linking becomes established in a future life. The danger is still present. The Buddha taught the second way to make this meaning clear. (Saṃyutta Subcommentary, vol. 2, p. 83.)

In the example of the meditator above, for the most part, both before and after insight practice, one finds an encircling presence of underlying tendencies…


<a id="M05-body-P075"></a>
## Burmese page 75
Miến / Burmese 75

…as well as craving and views. If the insight kamma of a good person who still has underlying tendencies can produce the result of rebirth-linking, the insight kamma of one who still has underlying tendencies and is also surrounded by craving and views can likewise produce that result. This agrees with the Sotānugatasutta in the Book of Fours of the Aṅguttara Nikāya (Aṅguttara Nikāya, vol. 1, pp. 504–507). One point about that meditator is worth remembering. Although insight knowledges arose in the previous life, the meditator had not seen dependent origination at all. Consequently, those past insight knowledges were not strong enough to support the meditator by the power of decisive support all the way to the manifestation of the noble path. The case resembles that of the Elder Channa, who had mistakenly identified himself as Channa the charioteer. (See the Channasutta, Saṃyutta Nikāya, vol. 2, p. 108.)

The round of defilements and the round of kamma

A little more should be explained about the round of defilements and the round of kamma. Consciousness and the mental factors called the round of defilements and the round of kamma lack the power to arise in isolation. They can arise only together with their associated phenomena. Even when arising with their associated phenomena, they can arise only in accordance with the law governing consciousness, in what is called a cognitive process. They cannot deviate from that customary course, turn back, or arise haphazardly as one might wish. Moreover, the round of defilements and the round of kamma capable of producing a rebirth-linking result belong only to mind-door impulsions. Five-door impulsions can produce only results during the course of life…


<a id="M05-body-P076"></a>
## Burmese page 76
Miến / Burmese 76

…they cannot produce a rebirth-linking result. Mind-door impulsions have the capacity to produce both types of result, at rebirth-linking and during the course of life. To clarify the point, consider another example.

When you look back for the object of the previous life's near-death process, suppose the kamma-object of offering food at a stūpa actually appears. Continue discerning the wholesome impulsion processes occurring as the food is offered. Continue discerning also the mind-door impulsion processes, led by ignorance, craving, and clinging, that surround that wholesome kamma. Even if you have yet to succeed in discerning them, or can see only the image of the offering, begin at that point by discerning the four great elements in the image of the person offering food. Then continue discerning the material and mental phenomena that arose during the offering. Give particular attention to discerning the heart-base and the mind door, the clear life-continuum. Among those clear life-continua, discern repeatedly the life-continuum serving as the mind door immediately before and during the offering of food at the stūpa. Then continue discerning the mind-door impulsion processes interspersed among those moments of life-continuum serving as the mind door, both the processes of offering food and those of making an aspiration. In these processes, find the round of defilements, namely ignorance, craving, and clinging, and the round of kamma, namely formations and kamma.


<a id="M05-body-P077"></a>
## Burmese page 77
Miến / Burmese 77

To clarify, consider an example. Suppose the meditator aspires, “May I become a bhikkhu capable of attaining Nibbāna” or “May I become a woman capable of attaining Nibbāna.”

Three phenomena in the round of defilements

1. Ignorance is the quality of mistakenly taking there to be a bhikkhu or a woman capable of attaining Nibbāna.
2. Craving is the quality of longing for and becoming attached to life as a bhikkhu or a woman capable of attaining Nibbāna.
3. Clinging is the quality of the mind approaching and holding fast to life as a bhikkhu or a woman capable of attaining Nibbāna.

This ignorance, craving, and clinging are the round of defilements. Ignorance, craving, and clinging, called the round of defilements, lack the power to arise in isolation. They can arise only in a cognitive process together with associated consciousness and mental factors such as contact, feeling, perception, volition, and consciousness. In general the group with greed and views has a full complement of twenty mental phenomena. At times there are nineteen mental phenomena when joy is absent. They may arise prompted or unprompted, as appropriate, and may arise with equanimous feeling. At times there is a group with greed and conceit. At times there may also be a greed-rooted group with neither views nor conceit. In the usual sequence of the cognitive process, one mind-door adverting is followed by seven impulsions. Registration may arise or may not. When there is craving for the mentality and materiality in the life as a bhikkhu for which one aspires, or…


<a id="M05-body-P078"></a>
## Burmese page 78
Miến / Burmese 78

…for the mentality and materiality in the life as a woman for which one aspires, there is an opportunity for registration. It may arise.

1. In mind-door adverting there are twelve mental phenomena.
2. In each impulsion, if it is of the group with greed and views, there are twenty mental phenomena.
3. If registration occurs, in each moment of registration there are thirty-four, thirty-three, thirty-three, thirty-two, twelve, or eleven mental phenomena, as appropriate.

These can occur in the respective ways just described. The following are included in those groups of mental phenomena.

1. Feeling is the feeling aggregate (vedanākkhandha), the group of feeling phenomena.
2. Perception is the perception aggregate (saññākkhandha), the group of perception phenomena.
3. The remaining mental factors are the formations aggregate (saṅkhārakkhandha), the group of formation phenomena.
4. Cognizing consciousness is the consciousness aggregate (viññāṇakkhandha), the group of cognizing phenomena.

Thus those mental phenomena constitute the four mental aggregates. The heart-base materiality that serves as their support, together with the material phenomena arising alongside that base, fifty-four kinds of material phenomena, constitutes the materiality aggregate. Mind-produced materiality may also be included as appropriate. Taken together, one materiality aggregate plus four mental aggregates makes five aggregates.

1. Five aggregates at the moment of mind-door adverting.
2. Five aggregates at each moment of impulsion.
3. Five aggregates at each moment of registration.

These groups are distinct in the respective ways just described. Registration may occur, as appropriate, as great resultant registration, rootless wholesome-resultant registration, or rootless unwholesome-resultant registration. Hence the figures thirty-four, thirty-three, thirty-three, thirty-two…


<a id="M05-body-P079"></a>
## Two phenomena in the round of kamma
Miến / Burmese 79

…twelve, and eleven are given separately in this way. A good person should investigate this personally.

To discern ignorance, craving, and clinging in the round of defilements, which surround the formations and kamma accumulated in the previous life and belong to the past causes, a good person needs to know how to discern present mentality and materiality. Use knowledge to break down each group of material and mental phenomena until ultimate phenomena are seen and the five aggregates can be discerned as described. In the sequence of knowledges this is knowledge of delimiting mentality and materiality (nāmarūpaparicchedañāṇa), also called knowledge of defining mentality and materiality (nāmarūpavavatthānañāṇa).

Two phenomena in the round of kamma

When offering food at the venerable stūpa, that is, offering it to the Buddha, the following cases are possible.
1. Wholesome impulsion processes may occur with the Buddha, the recipient, as their object.
2. Wholesome impulsion processes may also occur with the gift, namely the food, as their object.
3. With earlier wholesome volitions during the offering as their object, subsequent wholesome volitions, that is, wholesome impulsion processes, may also occur.

Carefully discern which wholesome impulsion processes occur during the offering of food. If the wholesome impulsions arise with joyful feeling and are associated with knowledge, each impulsion contains thirty-four mental phenomena, consciousness together with its mental factors. They belong to the group with faith and wisdom. In the sequence of a cognitive process…


<a id="M05-body-P080"></a>
## Burmese page 80
Miến / Burmese 80

…there is one moment of mind-door adverting, seven moments of impulsion, and two moments of registration. Registration sometimes occurs and sometimes does not.

1. At mind-door adverting there are twelve mental phenomena.
2. At each moment of impulsion there are thirty-four mental phenomena.
3. At each moment of registration there are thirty-four, thirty-three, thirty-three, thirty-two, twelve, eleven, or eleven mental phenomena.

These groups of mental phenomena constitute the four mental aggregates in each case. The material phenomena present at the heart-base, the support for those mental phenomena, constitute the materiality aggregate. Thus there are five aggregates at mind-door adverting, five at each moment of impulsion, and five at each moment of registration.

The aggregates occur in these respective ways. In the sequence of knowledges, the knowledge that sees, knows, discerns, and distinguishes the five aggregates is precisely knowledge of delimiting mentality and materiality (nāmarūpaparicchedañāṇa), or knowledge of defining mentality and materiality (nāmarūpavavatthānañāṇa). The five aggregates in the round of defilements and the five aggregates in the round of kamma are causal aggregates for some groups of five resultant aggregates in the present life, whether as a bhikkhu or as a woman, such as those at rebirth-linking, life-continuum, and death.

Among the groups of five aggregates just described, the thirty-four mental phenomena in each wholesome impulsion are called formations because they form the conditions for the five aggregates, namely the mentality and materiality of the life as a bhikkhu or as a woman that one aspires to, to come into being…


<a id="M05-body-P081"></a>
## Knowledge of discerning conditions
Miến / Burmese 81

…They are causal phenomena that bring about an existence.

These formations are impermanent and cease after arising. Yet they do not vanish without leaving a power in the continuum of mentality and materiality as do the indeterminate resultant and functional aggregates. They cease after leaving in the continuum of mentality and materiality a kammic potency capable of producing the five aggregates of the aspired-to life as a bhikkhu or a woman capable of attaining Nibbāna. That kammic potency is kamma.

Knowledge of discerning conditions

When a good person has found the causes established in the past life, namely ignorance, craving, clinging, formations, and kamma, compare that kamma, the kammic potency, with the thirty kinds of kamma-produced materiality present at the kalala stage of one's own rebirth-linking. Investigate repeatedly whether the kamma-produced materiality at rebirth-linking arose because of that kamma. Discern until it is understood whether the two are connected as cause and effect. Just as one can clearly discern whether consciousness and mind-produced materiality are connected as cause and effect, attend carefully to whether kamma and kamma-produced materiality are so connected.

If they truly are connected as cause and effect, the meditator will see directly with the wisdom of right view that kamma-produced materiality is arising in succession because of that kamma…


<a id="M05-body-P082"></a>
## Burmese page 82
Miến / Burmese 82

…Just as the meditator sees mind-produced materiality arising in succession because of consciousness, the meditator will see kamma-produced materiality arising in succession because of kamma.

If the kamma found is not causally connected with kamma-produced materiality, including the kamma-produced materiality at rebirth-linking, that is, if it is not seen with knowledge that this materiality arises because of that kamma, another kamma that is giving its result must be sought. Look again at the objects appearing in the clear life-continuum serving as the mind door at the approach of death, around the time of the near-death process. Look forwards, then back towards the near-death process. Search repeatedly in this way. A kamma that is actually giving its result must be found.

In some meditators, near death two, three, or more kammas appear in succession in the clear life-continuum serving as the mind door. Kammas capable of giving results appear in confusion. When the gate of a pen holding many cattle is opened at daybreak, the animals jostle in groups to get out. Similarly, in some people kammas appear in confusion at the approach of death. As the strongest bull pushes past the other cattle and comes out first, of the many kammas appearing and vying at the approach of death, the strongest ultimately gains the opportunity to give its result and gives it first. That kamma about to bear fruit is the last object of the near-death process. Put another way, one of the three objects that appear owing to its potency, namely kamma, a sign of kamma, or a sign of destination, becomes the object of the near-death process.


<a id="M05-body-P083"></a>
## Burmese page 83
Miến / Burmese 83

When many kammas appear at the approach of death in this way, find the object of the near-death process. From that object seek ignorance, craving, clinging, formations, and kamma by the method already given.

When many kammas appear incessantly and in confusion near death, one may be productive kamma (janakakamma) that directly produces results. Others may be supportive kammas (upatthambhakakamma) that sustain that productive kamma. In looking back to seek the object that appeared in the clear life-continuum serving as the mind door near death in the previous life, the meditator may pass over the object of the near-death process and attend first to objects appearing in the clear life-continuum immediately or a little before that process. By discerning past it in this way, the meditator may first encounter supportive kamma, kamma that lends support. If it is indeed supportive kamma, investigate repeatedly whether it is connected as cause and effect with kamma-produced materiality at rebirth-linking. One can see that there is no such connection, that the kamma-produced materiality does not arise directly because of that kamma. If one first encounters the productive kamma that directly produces kamma-produced materiality, including that at rebirth-linking, discern with knowledge whether they are causally connected, that is, whether that materiality arose because of that kamma. One will see that there is a causal connection.

Thus when seeking past kamma, a meditator may meet supportive kamma first, or may first meet productive kamma. This is because the object may be passed over in discerning. Therefore investigate repeatedly…


<a id="M05-body-P084"></a>
## Changes in the sign
Miến / Burmese 84

…and compare so as to know precisely whether there is a causal connection. When this is clear, attend until you ascertain the object of the last near-death process, the one closest to the death consciousness in the previous life. That sign appeared as an object because of the potency of the kamma about to give its result. Thus, in seeking the kamma, investigate and compare carefully to ascertain whether what is found is kamma, a sign of kamma, or a sign of destination.

Changes in the sign

Before the near-death process, kammas appearing around the approach of death, or kamma, a sign of kamma, and a sign of destination, can sometimes change according to causes such as wise attention and unwise attention. Recall the father of Elder Soṇa, who lived at the Acela forest monastery at the foot of Mount Soṇa. At first a sign of hell appeared in the father's continuum. Through arrangements made by his son, Elder Soṇa, he changed to taking as object the sign of offering flowers at a stūpa. Then signs of the heaven realm, a celestial mansion, and celestial maidens appeared. (See the Abhidhamma Commentary, vol. 2, pp. 420–421.) In light of his case, remember that signs appearing around the approach of death, before the near-death process, can also change according to mistaken attention, that is, unwise attention, or correct attention, that is, wise attention.

Because signs can change in this way, when a meditator investigates past causes, in discerning with knowledge…


<a id="M05-body-P085"></a>
## How to discern causes and effects
Miến / Burmese 85

…supportive kamma sometimes appears before the productive kamma that directly produces the result. Sometimes, in looking back for past causes, the meditator passes over the object of the near-death process and discerns objects in the continuum of mentality before that time. In such cases too, supportive kamma can be encountered first and productive kamma found upon re-examination. Furthermore, around the approach of death, before the near-death process, there may be various objects. Sometimes the very object of the near-death process appears well before the process itself. For example, when the layman Dhammika was about to die, the signs of six chariots from six heavenly realms appeared. When Dhammika chose Tusita from among them, only the chariot from Tusita remained at the end, in the near-death process. (Dhammapada Commentary, vol. 1, pp. 83–85.)

How to discern causes and effects

Using the sign that appeared near death as a basis, look back and seek the past causes. Suppose the object clearly manifest in the near-death process is the sign of offering food at a stūpa, as stated above. Find ignorance, craving, clinging, formations, and kamma in the continuum of mentality and materiality while the food was being offered, as explained above. Then investigate whether the potency of that kamma and the thirty kinds of materiality at the moment of the kalala have a causal connection…


<a id="M05-body-P086"></a>
## Main points to bear in mind
Miến / Burmese 86

…or not. Look at the cause, then at the effect, repeatedly comparing the nature of the causal relationship between causal phenomena and resultant phenomena. Just as consciousness and mind-produced materiality are causally connected, discern both the causal phenomenon called kamma and the resultant phenomenon called kamma-produced materiality in the same way. If you see them connected as cause and effect, discern the causes and effects as follows.

With the arising of ignorance (20), kamma-produced materiality at rebirth-linking arises. Ignorance (20) is the causal phenomenon. The materiality aggregate at rebirth-linking is the resultant phenomenon.

In this way, connect the causal phenomena with the resultant phenomena and discern with knowledge until their causal relationship is seen. Discern the causes and effects as above, distinguishing them with knowledge. When one can discern in this way it is called knowledge of discerning conditions (paccayapariggahañāṇa), the knowledge that can discern causal phenomena.

Main points to bear in mind

The past causes of the five resultant aggregates in the round of results are ignorance, craving, clinging, formations, and kamma. Of these, the past causes of the materiality aggregate are ignorance, craving, clinging, formations, and kamma. Its present causes are consciousness, temperature, and nutriment. The past causes of the four resultant mental aggregates are also ignorance, craving, clinging, formations, and kamma. Their present causes…


<a id="M05-body-P087"></a>
## The materiality aggregate
Miến / Burmese 87

…are causes such as base, object, and contact. This may also be remembered as follows.

The materiality aggregate

1. The causes of kamma-produced materiality, the resultant part of the materiality aggregate, are ignorance, craving, clinging, formations, and kamma. These are past causes.

2. The cause of mind-produced materiality is consciousness that arises dependent on the heart-base materiality.

3. The cause of temperature-produced materiality is the fire element, that is, temperature, in materiality that has reached the moment of presence, found in nearly all material groups. [Original note. As explained in the section on the meditation subject of materiality, the fire element, or temperature, in such material groups as the eye decad and groups produced by kamma, consciousness, temperature, and nutriment generates successive material groups. The fire element, or temperature, in the final group does not produce temperature-produced materiality. Hence the wording “found in nearly all material groups.”]

4. The cause of nutriment-produced materiality is nutritive essence, including nutritive essence produced by kamma, by consciousness, by temperature, and by nutriment. [Original note. When temperature-produced nutritive essence in the food eaten is supported by the kamma-produced digestive fire, it produces new groups with nutriment-produced nutritive essence. When that nutritive essence receives support from the nutritive essence in the material groups…


<a id="M05-body-P088"></a>
## The four mental aggregates
Miến / Burmese 88

…kamma-produced, mind-produced, and temperature-produced nutritive essence, as well as nutriment-produced nutritive essence in subsequent generations, produce their respective groups with nutriment-produced nutritive essence. Review all of this in the section on the meditation subject of materiality. When supported by nutritive essence in the material groups, the nutritive essence in subsequent generations of nutriment-produced material groups also produces new groups born of nutritive essence. Thus the account of the causes of nutriment-produced materiality includes nutriment-produced nutritive essence alongside that produced by kamma, consciousness, and temperature.]

The four mental aggregates

The past causes of the following two kinds of resultant mentality are ignorance, craving, clinging, formations, and kamma. The first comprises the four resultant mental aggregates of process-free consciousness, namely rebirth-linking, life-continuum, and death. The second comprises the four resultant mental aggregates within cognitive processes, including the five kinds of sense consciousness such as eye-consciousness, as well as receiving, investigating, and registration. The present causes of these mental phenomena include base, object, and contact.

1. The base is supporting materiality. In a five-aggregate realm, without supporting materiality those mental phenomena cannot arise.
2. The object. Those mental phenomena can arise only when an appropriate object appears at the corresponding door. There must be an object to cognize for cognition to occur. Understand it in this way.


<a id="M05-body-P089"></a>
## Burmese page 89
Miến / Burmese 89

3. Contact. Associated phenomena such as contact, in other words the four mental aggregates, must support one another by conditions such as conascence, mutuality, dependence, presence, and non-disappearance for those mental phenomena to arise. For one aggregate to arise the other three mental aggregates must support it. Among these aggregates contact is a prominent primary cause in receiving the object.

A point to bear in mind. Resultant consciousness during the course of life, such as fivefold sense consciousness, receiving, investigating, and registration, may arise from the same productive kamma that directly produces the process-free consciousness of rebirth-linking, life-continuum, and death. It may also arise from other productive kammas that produce results during the course of life. Such kamma may be wholesome or unwholesome. Wholesome kamma produces wholesome-resultant fivefold sense consciousness, receiving, investigating, and registration. Unwholesome kamma produces unwholesome-resultant fivefold sense consciousness, receiving, investigating, and registration. Wholesome results arise on encountering a desirable object and unwholesome results on encountering an undesirable object. Although disciples cannot know kamma and its results exhaustively, they should know some of them. Be mindful to investigate these causes both in discerning the five past aggregates and in seeking the past causes.

Furthermore, five-door adverting and determining in the five-door process, and mind-door adverting in the mind-door process, are all functional consciousness. They perform only the functions of adverting to and determining the object that has appeared. When the door and object meet…


<a id="M05-body-P090"></a>
## The four methods — 1. The method of identity
Miến / Burmese 90

…only those functional types of consciousness arise. Thus they are not mental phenomena arising from past causes. They are groups of mental phenomena arising only from present causes such as base, object, and contact. These mental phenomena therefore have no past causes. They have only present causes such as base, object, and contact.

Likewise, wholesome impulsions arise only from causes such as base, object, contact, and wise attention. Unwholesome impulsions arise only from causes such as base, object, contact, and unwise attention. These groups of mental phenomena are not mental phenomena arising from past causes. Thus remember that the groups of mental phenomena in wholesome and unwholesome impulsions have no past causes. They have only present causes.

The four methods — 1. The method of identity

In discerning dependent origination a meditator must understand four very important methods: identity (ekattanaya), diversity (nānattanaya), non-agency (abyāpāranaya), and regularity (evaṃdhammatānaya). Discern them so as to understand them while discerning dependent origination and the relationship between cause and effect. The method of identity is as follows.

1. Past mentality and materiality in which the past causes were accumulated.
2. Mentality and materiality arising moment by moment from present rebirth-linking to the present discernment of causes or, after entering the insight phase, up to the point of insight discernment…


<a id="M05-body-P091"></a>
## Burmese page 91
Miến / Burmese 91

3. Future mentality and materiality that will arise from the time one is now discerning dependent origination, the causal relationship, to the end in the future, if that future still remains because one has yet to practise to the attainment of arahantship. Put another way, past, present, and future mentality and materiality have existed, now exist, and will exist respectively in the three lives, past, present, and future.

One must see with knowledge the mentality and materiality that have existed, now exist, and will exist in these three times as a single succession in terms of the continuum of mentality and materiality. This succession of mentality and materiality is a succession of impermanence, a succession of arising and ceasing.

To clarify this a little, direct attention to the clear life-continuum serving as mind door when the wholesome deed that led to the present human life was accumulated in a past life, and then discern the present clear life-continuum serving as mind door. In terms of continuity they come in one succession, one connection, one series of arising and ceasing, like a thread stretched in one line. Discern this with knowledge until it is clear. Life-continuum is the consciousness that occurs most frequently in a life, so it is used here as the main example to make the explanation easier to understand. Sabhāvo vāyaṃ…


<a id="M05-body-P092"></a>
## The distinguishing marks of the past
Miến / Burmese 92

…cittassa paṇḍaratā. (Mūlaṭīkā, vol. 1, p. 125.) According to the root subcommentary, although unwholesome mental factors are defiled, all consciousness is clear. Thus the clarity of the life-continuum and that of the process consciousness occurring between moments of life-continuum, the clarity of all consciousness, is clarity by nature. A good person should discern with knowledge how that clear continuum of mentality occurs in one succession, one connection, one series. In the same way, continue discerning with knowledge how the continuum of materiality arises in one succession, one connection, one series.

The distinguishing marks of the past

Discern carefully whether the clear life-continuum serving as the mind door in the continuum of mentality and materiality performing a wholesome deed in a past life, or that continuum of mentality, is your own clear life-continuum serving as the mind door or your own continuum of mentality. If it is indeed your own clear life-continuum or continuum of mentality, you can readily understand that it is your own clear life-continuum serving as the mind door or your own continuum of mentality. Likewise, you can readily understand that it is your own continuum of materiality. This is because the continuum of mentality and the continuum of materiality occur in one succession, one connection, one series, one stream.

When looking back and discerning the past continuum of mentality and materiality in this way, some meditators acknowledge that “my mental dispositions in the past life…


<a id="M05-body-P093"></a>
## Broad, strong light when discerning a past life
Miến / Burmese 93

…largely resemble my present mental dispositions.” This is due to compatible habits carrying over. The cultivation of serenity and insight is the work of replacing bad habits with good habits and striving to make the good habits occur without interruption. When bad habits can be uprooted and good habits alone operate fully, one's work of cultivation has reached its highest point.

It seems difficult, and indeed it is difficult.
It seems profound, and indeed it is profound.

In discerning mentality and materiality from the past to the present or in discerning the past causes in this way, a meditator discerns mentality and materiality in the present life back to rebirth-linking, then directs knowledge toward the past to find the causes. Sometimes no mentality or materiality is seen, only a mass of radiant light, intensely bright, very large, and spread wide. At that point, if the meditator lacks learning, they may come to a standstill, unsure how to proceed. Such meditators have often descended from a deva or Brahmā realm. It is particularly necessary to investigate whether this is so. Most meditators encountering this difficulty, when discerning internal and external mentality and materiality…


<a id="M05-body-P094"></a>
## Burmese page 94
Miến / Burmese 94

…in the two kinds of continuum, internal and external, discerned in general without giving specific attention to mentality and materiality in the continua of devas and Brahmās. Thus when they encounter a great, broad mass of light, they do not know how to discern the mentality and materiality present within it. The greater a deva's merit, the brighter the radiance of the body. The radiance of Brahmās is brighter still than the radiance of devas. The bodies of devas are large, and those of Brahmās are larger still. The material phenomena of devas are extremely subtle, and those of Brahmās are subtler still. Someone who in discerning external mentality and materiality discerned only in general without attending carefully to that of devas and Brahmās may have difficulty discerning such exceedingly subtle material phenomena.

When you encounter such a difficulty, discern internal and external mentality and materiality again. Pay particular attention to discerning the material phenomena of devas. When you succeed, direct knowledge towards the deva realms and continue discerning the subtle material phenomena in the continua of devas in successive realms. Discern internally once and externally once. Then turn to discerning the material phenomena in the continua of Brahmās. The material phenomena of Brahmās are exceedingly subtle. Therefore re-establish concentration repeatedly and repeatedly…


<a id="M05-body-P095"></a>
## Burmese page 95
Miến / Burmese 95

…discern. Success is possible. When you can repeatedly discern internal and external material phenomena as far as the Brahmā realms in this way, continue discerning in particular to understand clearly that Brahmās have no nose decad, tongue decad, body decad, or sex decad. When you succeed, continue discerning mentality.

In the continua of devas, as in human continua, kamma-produced, mind-produced, and nutriment-produced groups of materiality can occur in full. In the continua of Brahmās the groups of materiality cannot all be present in full. This is the difference between devas and Brahmās with respect to material groups. Once you can turn to discerning the mentality and materiality of devas and Brahmās externally, begin by discerning the four great elements in the very large, broad mass of light encountered when seeking past causes. When you see the small particles that are material groups, analyze those groups down to ultimate phenomena. In discerning ultimate materiality this way, if the mass of light belongs to a deva existence, you can find the full complement of groups as explained above. If the mass of light belongs to a Brahmā existence, you will not find some types of kamma-produced materiality, as stated above. Once you can discern the material phenomena, continue discerning the heart-base materiality, the clear life-continuum or mind door, and the mental phenomena that arise taking that mind door as their door and depending on the heart-base. Continue discerning among those mental phenomena the groups led by ignorance, craving, and clinging…


<a id="M05-body-P096"></a>
## When three or four people appear
Miến / Burmese 96

…namely the groups of mental phenomena in mind-door processes of the round of defilements, and the groups of mental phenomena in mind-door processes of the round of kamma, namely formations and kamma. When discerning in this way, distinguish with knowledge and discern so as to know that the past and present continua of mentality and materiality make up one succession, one connection, one series, one stream. Knowing this is called knowing the method of identity.

When three or four people appear

Sometimes, when seeking past causes, a meditator sees three or four people performing a wholesome deed in the scene of wholesome action in a past life. If this happens, begin discerning the four great elements in each person's continuum, one person after another. First discern the four great elements in one person's continuum. When you see the particles that are material groups, continue discerning ultimate material phenomena. Then continue discerning mental phenomena. Next discern the mentality and materiality of another person in the same way. Then continue likewise with the mentality and materiality of the next person. Of these continua, the one seen as forming one succession, one connection, one series, one stream with your present mentality and materiality is your own continuum.

If uncertain while discerning in this way, direct your attention particularly to the clear life-continuum serving as mind door in each person…


<a id="M05-body-P097"></a>
## Burmese page 97
Miến / Burmese 97

…and discern it. A meditator can usually tell easily whether it is one's own clear life-continuum serving as mind door. When the meditator sees directly with the eye of right-view wisdom that the present clear life-continuum serving as mind door and the past clear life-continuum serving as mind door form one succession, one connection, one series, one stream in terms of the continuum of mentality, it is easy to see that the past clear life-continuum serving as mind door is one's own. If, when attending to a past clear life-continuum serving as mind door, it is not one's own clear life-continuum that one is discerning, this too can readily be seen. That is because the two continua of mentality do not connect. If the past mentality and materiality are not one's own continuum, the meditator can see personally that that other person's past continuum and one's own present continuum do not come in one succession, one connection, one series, one stream, but are continua that are unconnected.

One's past continuum of mentality and materiality and one's present continuum of mentality and materiality connect before and after, arising in succession as one succession, one connection, one series, one stream. When the meditator sees this directly with the wisdom of right view…


<a id="M05-body-P098"></a>
## Annihilationism and eternalism
Miến / Burmese 98

…then, because the meditator sees directly with the wisdom of right view that the continuum of mentality and materiality connects before and after and arises successively as one succession, one connection, one series, one stream, this is called knowing the method of identity. Understand in the same way when discerning to see directly with right-view wisdom that the present and future continua of mentality and materiality connect before and after, arising successively as one succession, one connection, one series, one stream.

Annihilationism and eternalism

Tattha avijjāpaccayā saṅkhārā, saṅkhārapaccayā viññāṇanti evaṃ bījassa aṅkurādibhāvena rukkhabhāvappatti viya santānānupacchedo ekattanayo nāma. Yaṃ sammā passanto hetuphalasambandhena pavattamānassa santānassa anupacchedāvabodhato ucchedadiṭṭhiṃ pajahati. Micchā passanto hetuphalasambandhena pavattamānassa santānānupacchedassa ekattaggahaṇato sassatadiṭṭhiṃ upādiyati. (Abhidhamma Commentary, vol. 2, p. 188. Visuddhimagga, vol. 2, p. 220.)

A shoot grows from the seed, and from that shoot a leaf develops. From that seed, roots, trunk, branches, young leaves, and mature leaves appear successively without interruption. The seed becomes a tree. It appears in the form of a tree. Thus, when the seed and tree occur in one series, the continuum is not interrupted. Because the continuum is uninterrupted, one may speak of it as “one and the same stream.” Likewise…


<a id="M05-body-P099"></a>
## Burmese page 99
Miến / Burmese 99

With ignorance as condition, formations arise. With formations as condition, consciousness arises. As this proceeds, causes and effects form one succession, one uninterrupted continuum. The way of understanding this as “one stream” is called the method of identity.

When the method of identity is seen correctly, knowledge penetrates the uninterrupted continuum of mentality and materiality arising successively in causal relationship, as between past causes and present results, and between present causes and future results. Such seeing makes it possible to abandon annihilationist belief and the strong attachment to it, the view that “life extends only from birth to death, ends at death, and nothing remains after death.” If the causal relationship is missed and seen wrongly, eternalism can also arise.

Causal and resultant phenomena differ in their respective ultimate natures. Yet although they differ in ultimate nature, viewed from the side of the cause as well as from the side of the effect, they are linked to each other causally. This connectedness is called santānānupaccheda here, the non-interruption of the continuum. Because the continuum of mentality and materiality is uninterrupted in this way, a result arises only in the very continuum of mentality and materiality in which its kamma was performed. Remember that kamma already performed cannot simply disappear, and kamma not performed cannot come forward to give a result.


<a id="M05-body-P100"></a>
## 2. The method of diversity
Miến / Burmese 100

The wrong way of seeing here arises through failing to investigate and see the difference between the causes and effects that arise in succession and are linked causally. One regards causes and effects alike as a single thing and grasps the non-interruption of the causally connected continuum of mentality and materiality as one undifferentiated entity. Failing to see impermanence, suffering, and non-self in causal and resultant mentality and materiality, one understands in terms of permanence and self, “Tadeva viññāṇaṃ sandhāvati saṃsarati”, this very consciousness runs from this life to that life, from that life to another, and wanders repeatedly even within a single life. Grasping the continuum of mentality and materiality as a single entity in this way is eternalism. One who understands the method of identity wrongly is already holding to eternalism. (Abhidhamma Commentary, vol. 2, p. 188. Visuddhimagga, vol. 2, p. 220. Mūlaṭīkā, vol. 2, p. 131. Mahāṭīkā, vol. 2, p. 347.)

2. The method of diversity

Avijjādīnaṃ pana yathāsakalakkhaṇavavatthānaṃ nānattanayo nāma. Yaṃ sammā passanto navanavānaṃ uppādadassanato sassatadiṭṭhiṃ pajahati. Micchā passanto ekasantānapatitassa bhinnasantānasseva nānattaggahaṇato ucchedadiṭṭhiṃ upādiyati. (Abhidhamma Commentary, vol. 2, p. 188. Visuddhimagga, vol. 2, p. 220.)

According to the method of identity, phenomena related as cause and effect occur as a single continuum…


<a id="M05-body-P101"></a>
## Burmese page 101
Miến / Burmese 101

…Distinguishing each of the respective characteristics of the causal and resultant phenomena arising in that continuum, such as ignorance, formations, consciousness, mentality and materiality, the six bases, contact, feeling, craving, clinging, becoming, birth, aging, and death, is called the method of diversity. To discern in this way, break down with knowledge the apparent compactness of mentality and materiality, including compactness of continuity, grouping, function, and object. Discern the factors of dependent origination in their proper places in terms of characteristic, function, manifestation, and proximate cause, until knowledge reaches ultimate phenomena.

Past, present, and future mentality and materiality do indeed form one continuum. Even so, discern each material group and each group of consciousness individually to break down compactness of continuity. Phenomena such as ignorance in turn occur only in material or mental groups. With knowledge analyze each ultimate phenomenon in each material or mental group: this is the earth element, this the water element, this the fire element, this the wind element, and so on, or this is contact, this feeling, this perception, this volition, this consciousness, and so on. Discern so as to break down compactness of grouping in the masses of materiality and mentality. Also discern to break down compactness of function, the functions of materiality and of mentality. Thus when a good person knows how to discern the factors of dependent origination in their proper places by characteristic, function, manifestation, and proximate cause, this is called knowing the method of diversity.


<a id="M05-body-P102"></a>
## Burmese page 102
Miến / Burmese 102

When the method of diversity is seen correctly, the meditator sees directly with right-view wisdom that new ultimate phenomena keep arising without interruption in causal succession. Because the meditator sees directly with right-view wisdom the distinct natures and characteristics of causes and effects, the eternalist view that “the self does not end at death” can be abandoned.

If the method of diversity is not seen correctly, one may see it wrongly. One clings to the diverse instances of mentality and materiality occurring in a single continuum as though they belonged to different continua. The continuum of the aggregates of mentality and materiality is one succession even across different lives. From the life of the ascetic Sumedha to the life of Buddha Gotama there was only one succession of mentality and materiality. Even so, someone unable to understand this as “one continuum” may suppose that the being who dies in this life is one person and the being born in the next life another, as though they had separate continua. One who understands thus is already holding the annihilationist view that “a being ends at death.” If one thinks in terms of separate continua, “the one who does good or ill is one person, the one who undergoes good or bad results another; the person in this life acts and the person in that life undergoes,” one is firmly holding annihilationism. (Abhidhamma Commentary, vol. 2, p. 188. Visuddhimagga, vol. 2, p. 220. Mūlaṭīkā, vol. 2, p. 132. Mahāṭīkā, vol. 2, pp. 347–348.)


<a id="M05-body-P103"></a>
## 3. The method of non-agency
Miến / Burmese 103

3. The method of non-agency

Avijjāya saṅkhārā mayā uppādetabbā, saṅkhārānaṃ vā viññāṇaṃ amhehīti evamādibyāpārābhāvo abyāpāranayo nāma. Yaṃ sammā passanto kārakassa abhāvāvabodhato attadiṭṭhiṃ pajahati. Micchā passanto yo asatipi byāpāre avijjādīnaṃ sabhāvaniyamasiddho hetubhāvo, tassa aggahaṇato akiriyadiṭṭhiṃ upādiyati. (Abhidhamma Commentary, vol. 2, p. 188. Visuddhimagga, vol. 2, p. 220.)

On the side of the causal phenomena there is no deliberate agency, no arranging for resultant phenomena to arise. On the side of the resultant phenomena there is no deliberate agency either, no arranging that “when the causal phenomena are present, we, the resultant phenomena, shall be present.”

In ignorance there is no deliberate agency, “I shall produce the formations.” In the formations there is no deliberate agency, “We shall produce consciousness.” The absence of deliberate agency in phenomena such as ignorance and formations is called the method of non-agency.

When discerning the meditation subject of dependent origination, a meditator must discern and cultivate it so as to see this method of non-agency correctly. Correct seeing is to see that “phenomena such as ignorance and formations are nirīha, without any endeavor or effort to bring about the result. They are nijjīva, not a living entity capable of making such an effort. They are dhammatā, simply the natural regularity capable of producing the corresponding result”…


<a id="M05-body-P104"></a>
## Burmese page 104
Miến / Burmese 104

…One who sees in this way is called sammā passanto, one who sees correctly, one who has right view. Seeing in this way is called seeing correctly.

When the meditator directly sees the method of non-agency correctly with right-view wisdom, the view of self can be abandoned, the belief in a supreme self that acts and creates or a living self that is acted upon and created. This is because the meditator directly sees with right-view wisdom that causal phenomena lack deliberate agency to make resultant phenomena arise.

If the method of non-agency is seen wrongly, one overlooks that although causal phenomena lack deliberate agency to produce their effects, they still exist as causes established by natural regularity and capable of producing effects such as formations. Unable to accept this nature, one may embrace the view of non-action (akiriyadiṭṭhi), that “even if one acts, the action is ineffective.”

Natural regularity (sabhāvaniyama) is the regular nature of arising. In association with a material group, the fire element called fire is oriented upwards, so the flame rises. In association with a material group, air has the nature of distension, so it expands. Modes of occurrence such as these are natural regularity, the nature of arising…


<a id="M05-body-P105"></a>
## Burmese page 105
Miến / Burmese 105

…that is, the customary course. In the same way, when causal phenomena such as ignorance are present, resultant phenomena such as formations occur. When causal phenomena such as ignorance are absent, resultant phenomena such as formations do not occur. In other words, when the causes ignorance, craving, clinging, formations, and kamma are present, the effects consciousness, mentality and materiality, the six bases, contact, and feeling arise. When those causes are absent, those effects do not arise. This is called sabhāvaniyamasiddhahetubhāva, the status of being a cause established by the natural regularity of arising. If one does not accept that causes such as ignorance have the power, established by the natural regularity of arising, to produce effects such as formations…

Kassaci kattuno abhāvā na kāci kiriyā phalappavattinī. (Mahāṭīkā, vol. 2, p. 348.)

…a kind of view of non-action may arise, rejecting kamma and its results. According to this view, since there is no person or phenomenon that is an agent, no bodily, verbal, or mental action is connected with a result, that is, none yields a result. It holds that there is no bodily, verbal, or mental action connected with a result. (Abhidhamma Commentary, vol. 2, p. 188. Visuddhimagga, vol. 2, p. 220. Mahāṭīkā, vol. 2, p. 348.)


<a id="M05-body-P106"></a>
## 4. The method of regularity
Miến / Burmese 106

4. The method of regularity

Avijjādīhi pana kāraṇehi saṅkhārādīnaṃyeva sambhavo khīrādīhi dadhiādīnaṃ viya, na aññesanti ayaṃ evaṃdhammatānayo nāma. Yaṃ sammā passanto paccayānurūpato phalāvabodhā ahetukadiṭṭhiṃ akiriyadiṭṭhiñca pajahati. Micchā passanto paccayānurūpaṃ phalappavattiṃ aggahetvā yato kutoci yassa kassaci asambhavaggahaṇato ahetukadiṭṭhiñceva niyatavādañca upādiyati. (Abhidhamma Commentary, vol. 2, pp. 188–189. Visuddhimagga, vol. 2, pp. 220–221.)

Just as from milk there arise only curds and the like, when results arise from causes such as ignorance, only results such as formations, corresponding to those causes, arise. Other results that do not correspond to the causes do not arise. Put another way, when results arise from the causes ignorance, craving, clinging, formations, and kamma, only effects corresponding to those causes arise, namely consciousness, mentality and materiality, the six bases, contact, and feeling. No other effect that does not correspond to the causes can arise. This is called the method of regularity. Seeing this method correctly, the meditator sees directly with right-view wisdom that results arise corresponding to their causes and can therefore abandon the view of causelessness, which holds that there are no causes, and the view of non-action, which holds that wholesome or unwholesome action is ineffective even when performed. In other words, one can abandon these two wrong views that reject effects arising from causes, thus rejecting both causes and effects.


<a id="M05-body-P107"></a>
## The doctrine of fatalism
Miến / Burmese 107

A person who sees wrongly may misunderstand the method of regularity. The mistaken way of seeing proceeds as follows. If any effect could arise from any cause, there would be no reason why curds and butter could not arise from water. Yet they cannot arise that way. The person therefore comes arbitrarily to hold that no effect can arise from any cause whatsoever, grasping the doctrine of causelessness.

Seeing wrongly in this way, one fails to grasp that effects arise in accordance with causal phenomena. Unable to grasp or accept that a particular effect arises from a particular cause, one comes to hold firmly to the view of causelessness or to the doctrine of fatalism.

The doctrine of fatalism (niyatavāda) rejects the existence of kamma and its results, holding that the good and bad results experienced by beings are fixed in advance. If asked in turn, “If there are no such causes, on what account do the beings and things before our eyes come into being?”, the proponent of causelessness will answer, “By fate,” meaning that the time at which one will become a human being, a deva, or some kind of animal is predetermined. This teaching is called the doctrine of fatalism. (For details see the doctrine of Makkhali Gosāla in the Sāmaññaphalasutta.) (Abhidhamma Commentary, vol. 2, pp. 188–189. Visuddhimagga, vol. 2, pp. 220–221. Mūlaṭīkā, vol. 2, p. 132. Mahāṭīkā, vol. 2, p. 348.)

Therefore a good person should, through right-view wisdom, personally penetrate the nature of dependent origination, the relationship between cause and effect…


<a id="M05-body-P108"></a>
## Burmese page 108
Miến / Burmese 108

…and know it directly. Receive this respectfully and remember that such direct knowledge is the best weapon for abandoning and destroying the various wrong doctrines, mistaken teachings, and wrong views.

❂ ❂ ❂


<a id="M05-body-P109"></a>
## Part 3. Practical discernment by the five-aggregate method
Miến / Burmese 109

Points requiring particular attention

1. The object of the near-death process in the previous life.
2. The object of the group of rebirth-linking mental phenomena in the present life.
3. The object of the clear life-continuum serving as the mind door, the group of life-continuum mental phenomena in the present life.
4. The object of the group of mental phenomena at death that will arise in the present life.

All four must have the same object. Since the meditator cannot yet discern the future, attend with knowledge and personally compare and carefully discern whether the objects of items 1–3 are the same. Moreover, the numbers of consciousness and mental factors in rebirth-linking, life-continuum, and death must be the same. Attend carefully and investigate. Discern repeatedly. By now the meditator should normally be able to discern the clear life-continuum serving as mind door. If not, discern the rebirth-linking mental phenomena carefully again. After the rebirth-linking mental phenomena have ceased and before process consciousness occurs, continue discerning the consciousness and mental factors that arise in succession in that interval…


<a id="M05-body-P110"></a>
## How to group phenomena into five aggregates
Miến / Burmese 110

…that is, those groups of mental phenomena. To maintain continuity of consciousness in a life, when process consciousness is not occurring, the consciousness that serves as the basis of that life continues to arise. These are the life-continuum consciousnesses. Once this is understood, continue discerning the life-continuum mental phenomena occurring between cognitive processes in the present. Success is possible.

How to group phenomena into five aggregates

When discerning causes and effects in causal relationship according to the fifth method of dependent origination, group the phenomena in each group of consciousness into five aggregates. By that five-aggregate method, see with knowledge the connection between cause and effect, then discern the causal and resultant phenomena. While discerning, distinguish process-free consciousness from process consciousness. Rebirth-linking, life-continuum, and death are process-free types of consciousness, outside the succession of process consciousness. For those process-free types too, group the phenomena into five aggregates, see with knowledge the causal relationship for each aggregate, and discern the causes and effects. Likewise, for process consciousness, group each group of consciousness into five aggregates, see with knowledge the causal relationship for each aggregate, and discern the causes and effects. Here “aggregate” means a group.

1. Material phenomena are considered in eleven aspects: past, future, present, internal, external, gross, subtle, inferior, superior, far, and near. They are objects of the taints and can be grasped through craving and views as “I” or “mine”…


<a id="M05-body-P111"></a>
## The five aggregates subject to clinging
Miến / Burmese 111

…That group of material phenomena is called the materiality aggregate subject to clinging.

2. Feeling is considered in eleven aspects: past, future, present, internal, external, gross, subtle, inferior, superior, far, and near. Feelings are objects of the taints and can be grasped through craving and views as “I” or “mine.” This group of feelings is called the feeling aggregate subject to clinging.
3. Past, pe. The group of perceptions is called the perception aggregate subject to clinging.
4. Past, pe. The group of mental factors belonging to formations is called the formations aggregate subject to clinging.
5. Past, pe. The group of cognizing consciousnesses is called the consciousness aggregate subject to clinging. (Saṃyutta Nikāya, vol. 2, p. 39, Khandhasutta.)

Among these eleven aspects, some of the words mean the following.
1. Oḷārika: gross phenomena.
2. Sukhuma: subtle phenomena.
3. Hīna: inferior phenomena.
4. Paṇīta: superior phenomena.
5. Dūra: far phenomena.
6. Santika: near phenomena.

Remember the meanings of the words in this way. Within each group of consciousness, which falls within these eleven aspects, the five aggregates can be reckoned together with the supporting material base and the material object. In each group of consciousness…


<a id="M05-body-P112"></a>
## The five aggregates at the moment of rebirth-linking
Miến / Burmese 112

1. The supporting material base and material object are called the materiality aggregate.
2. Feeling in that group of consciousness is called the feeling aggregate.
3. Perception is called the perception aggregate.
4. The remaining mental factors apart from feeling, perception, and consciousness are called the formations aggregate.
5. Cognizing consciousness is called the consciousness aggregate.

In the formations aggregate the number of mental factors remaining apart from feeling, perception, and consciousness may range from five to thirty-two. Whatever their number, remember that the whole group of remaining mental factors is called the formations aggregate. Once the delimitation of the five aggregates above is understood, the grouping into five aggregates in each group of consciousness to be presented below will also be understood. Moreover, each of the five aggregates has its respective causes. See with knowledge the causal relationship between the respective causes and their corresponding results, then discern causes and effects in that relationship.

At the formation of the kalala drop — the five rebirth-linking aggregates

At the formation of the kalala drop at rebirth-linking: 1. The three kinds of material groups, the heart-base decad, the body decad, and the sex decad, comprising thirty material phenomena, are called the materiality aggregate.


<a id="M05-body-P113"></a>
## Burmese page 113
Miến / Burmese 113

2. Among the thirty-four rebirth-linking mental phenomena, feeling is called the feeling aggregate.
3. Among the thirty-four rebirth-linking mental phenomena, perception is called the perception aggregate.
4. Among the thirty-four rebirth-linking mental phenomena, volition is called the formations aggregate according to the first method. According to the second, the thirty-one remaining mental factors apart from feeling, perception, and consciousness are called the formations aggregate.
5. Among the thirty-four rebirth-linking mental phenomena, cognizing consciousness is called the consciousness aggregate.

The five rebirth-linking aggregates above apply only to a person with three roots whose rebirth-linking is accompanied by joyful feeling. For a person with three roots whose rebirth-linking is accompanied by equanimous feeling, there are thirty-three mental phenomena because joy is absent. For a person with two roots there are thirty-three or thirty-two mental phenomena respectively. The formations aggregate is presented in two ways because, in the canonical Khandhavagga, the Buddha gave primacy to volition when teaching the formations aggregate according to the discourse method. Thus the first presentation takes volition alone as primary in showing the formations aggregate. On the other hand, if only volition is taken as the formations aggregate, in one group of consciousness…

…the remaining mental factors apart from feeling, perception, and volition would fall outside the five aggregates. One might also ask whether those remaining mental factors have their respective causes. In particular, regarding contact…


<a id="M05-body-P114"></a>
## How to discern causes in connection with their effects
Miến / Burmese 114

1. Phassasamudayā vedanāsamudayo.
2. Phassasamudayā saññāsamudayo.
3. Phassasamudayā saṅkhārasamudayo. (Saṃyutta Nikāya, vol. 2, pp. 51–52.)

According to these teachings, contact is a cause of the feeling, perception, and formations aggregates. One may then ask whether contact itself has causes. To make known that contact and the remaining mental factors all have their respective causes, and to give a full account of ultimate phenomena, the formations aggregate is also presented in the second way. Remember the same principle elsewhere.

How to discern causes in connection with their effects

First, among the past causes that you, the good meditator, have personally found, discern so as to understand how the two phenomena of the round of kamma, formations and kamma, arise owing to the round of defilements, ignorance, craving, and clinging. Then discern with knowledge how the materiality aggregate at rebirth-linking in the round of results arises in causal relationship through the potency of kamma belonging to formations and kamma. Once you see with knowledge the causal kamma and its effect, kamma-produced materiality at rebirth-linking, in other words, formations and kamma surrounded by ignorance, craving, and clinging as the cause and kamma-produced materiality at rebirth-linking as the result, begin discerning the causes and effects as follows.


<a id="M05-body-P115"></a>
## The materiality aggregate at rebirth-linking
Miến / Burmese 115

1. With the arising of ignorance (20), kamma-produced materiality at rebirth-linking arises. Ignorance (20) is the cause. Kamma-produced materiality at rebirth-linking is the effect.

2. With the arising of craving (20), kamma-produced materiality at rebirth-linking arises. Craving (20) is the cause. Kamma-produced materiality at rebirth-linking is the effect.

3. With the arising of clinging (20), kamma-produced materiality at rebirth-linking arises. Clinging (20) is the cause. Kamma-produced materiality at rebirth-linking is the effect.

4. With the arising of formations (34), kamma-produced materiality at rebirth-linking arises. Formations (34) is the cause. Kamma-produced materiality at rebirth-linking is the effect.

5. With the arising of kamma, the kammic potency of formations (34), kamma-produced materiality at rebirth-linking arises. Kamma, the kammic potency of formations (34) is the cause. Kamma-produced materiality at rebirth-linking is the effect.

Connect cause and effect in this way and discern the causal and resultant phenomena. Practise discerning them.

Note. The number twenty for ignorance, craving, and clinging refers to the mental phenomena of the group with greed and views in each greed impulsion in a mind-door process of the round of defilements. The number thirty-four for formations and kamma refers to the thirty-four mental phenomena of the group with faith and wisdom in each great wholesome impulsion in a mind-door process of the round of kamma.


<a id="M05-body-P116"></a>
## Burmese page 116
Miến / Burmese 116

If you accumulated the kamma with equanimous feeling, those formations and that kamma were associated with equanimous feeling. As joy is absent, there are thirty-three mental phenomena. Those who can discern causes and effects of mentality and materiality, distinguish them with knowledge, and cultivate discernment in this way are generally people with three roots. Therefore a person with three roots is given as the example here. For a person with two roots, understand the numbers as thirty-three or thirty-two. Mind-produced, temperature-produced, and nutriment-produced materiality have yet to arise at the arising moment of rebirth-linking. Only kamma-produced materiality begins at that moment, so the presentation gives priority to connecting causes with kamma-produced materiality and discerning causes and effects. From the presence moment of rebirth-linking, however, the fire element, that is, temperature, in that kamma-produced materiality has reached the presence moment of materiality and can produce new temperature-produced groups. Mind-produced materiality begins with the first life-continuum after rebirth-linking. Nutriment-produced materiality begins when nutritive essence in the mother's food reaches the body of the embryo. Thus these too can be discerned by directing knowledge to the relevant time.

Likewise, first see with knowledge that resultant phenomena, such as the feeling aggregate and the other mental aggregates, become manifest because their respective causes become manifest. When you see this directly with the eye of right-view wisdom, discern causes and effects as follows.


<a id="M05-body-P117"></a>
## The feeling aggregate at rebirth-linking
Miến / Burmese 117

Five past causes

1. With the arising of ignorance (20), the feeling aggregate at rebirth-linking arises. Ignorance (20) is the cause. The feeling aggregate at rebirth-linking is the effect.

2. With the arising of craving (20), the feeling aggregate at rebirth-linking arises. Craving (20) is the cause. The feeling aggregate at rebirth-linking is the effect.

3. With the arising of clinging (20), the feeling aggregate at rebirth-linking arises. Clinging (20) is the cause. The feeling aggregate at rebirth-linking is the effect.

4. With the arising of formations (34), the feeling aggregate at rebirth-linking arises. Formations (34) is the cause. The feeling aggregate at rebirth-linking is the effect.

5. With the arising of kamma, the kammic potency of formations (34), the feeling aggregate at rebirth-linking arises. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at rebirth-linking is the effect.

Three present causes

6. With the arising of the base, the heart-base materiality (30), the feeling aggregate at rebirth-linking arises. The base, the heart-base materiality (30), is the cause. The feeling aggregate at rebirth-linking is the effect.
7. With the arising of the object, the kamma-object, the feeling aggregate at rebirth-linking arises.


<a id="M05-body-P118"></a>
## The abbreviated presentation
Miến / Burmese 118

The object, the kamma-object, is the cause. The feeling aggregate at rebirth-linking is the effect.
8. With the arising of contact (thirty-four minus feeling, leaving thirty-three), the feeling aggregate at rebirth-linking arises. Contact (thirty-four minus feeling, leaving thirty-three) is the cause. The feeling aggregate at rebirth-linking is the effect.

Discern the causes and effects in this way. For brevity, however, the wording “With the arising of ignorance (20), the feeling aggregate at rebirth-linking arises,” and similar statements will be omitted. The text will simply state, “Ignorance (20) is the cause. The feeling aggregate at rebirth-linking is the effect,” and so on. In actually discerning causes and effects, discern them in the full manner set out above. To help you grasp the method, the discernment of the materiality and feeling aggregates described above is set out again here in abbreviated form.

Rebirth-linking — Materiality aggregate (kamma-produced materiality, 30)

1. Ignorance (20) is the cause. The materiality aggregate at rebirth-linking is the effect.

2. Craving (20) is the cause. The materiality aggregate at rebirth-linking is the effect.

3. Clinging (20) is the cause. The materiality aggregate at rebirth-linking is the effect.

4. Formations (34) is the cause. The materiality aggregate at rebirth-linking is the effect.

5. Kamma, the kammic potency of formations (34), is the cause. The materiality aggregate at rebirth-linking…


<a id="M05-body-P119"></a>
## Rebirth-linking — Feeling aggregate
Miến / Burmese 119

…is the effect.

Rebirth-linking — Feeling aggregate

Five past causes

1. Ignorance (20) is the cause. The feeling aggregate at rebirth-linking is the effect.

2. Craving (20) is the cause. The feeling aggregate at rebirth-linking is the effect.

3. Clinging (20) is the cause. The feeling aggregate at rebirth-linking is the effect.

4. Formations (34) is the cause. The feeling aggregate at rebirth-linking is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at rebirth-linking is the effect.

Three present causes

6. The base, the heart-base materiality (30), is the cause. The feeling aggregate at rebirth-linking is the effect.
7. The object is the cause. The feeling aggregate at rebirth-linking is the effect.
8. Contact (thirty-four minus feeling, leaving thirty-three) is the cause. The feeling aggregate at rebirth-linking is the effect.

Explanations

1. Base. In a five-aggregate realm, mental phenomena can arise only when supporting materiality is present. If there is no supporting materiality…


<a id="M05-body-P120"></a>
## Burmese page 120
Miến / Burmese 120

…mental phenomena have no capacity to arise. At rebirth-linking the rebirth-linking mental phenomena, including the rebirth-linking feeling aggregate, can arise only dependent on the heart-base materiality that arises together with them. Without a support they cannot arise. The heart-base materiality itself cannot arise in isolation either. It occurs only in a material group. In particular it arises only in dependence on the four great elements in its group, which can assist it through conditions such as conascence. Without that support it cannot arise. Further, at rebirth-linking the heart-base decad can arise only together with the body decad and the sex decad. Thus, according to the discourse method…

Vatthu nāma karajakāyo, pe. So atthato bhūtāni ceva upādārūpāni ca. (Majjhima Commentary, vol. 1, p. 281.)

Nāmarūpavavatthānassa adhippetattā niravasesarūpapariggahassa dassanatthaṃ “vatthu nāma karajakāyo”ti āha. Na cakkhādīni chavatthūnīti. Karajakāyassa pana vatthubhāvasādhanatthaṃ “idañca pana me viññāṇaṃ ettha sitaṃ, ettha paṭibaddhan”ti suttaṃ ābhataṃ. (Mūlaṭīkā, vol. 2, p. 157.)

The base is the material body (karajakāya), pe. In terms of ultimate phenomena, that body consists of the great elements and derived materiality. (Majjhima Commentary, vol. 1, p. 281.)

In accordance with these explanations in the Commentary and Subcommentary, when taking the material base as an object one includes both the great elements and derived materiality. Discern and cultivate this so as to break down compactness of material grouping and for knowledge to reach ultimate materiality. Thus the supporting material base of the feeling aggregate at rebirth-linking…


<a id="M05-body-P121"></a>
## Base and object
Miến / Burmese 121

…according to the Abhidhamma method, depends on the single type of materiality called the heart-base. Thus only the heart-base materiality is counted. According to the discourse method, all thirty material phenomena together with the heart-base are counted as the material base. The discourse method is the method for practice. To break down compactness and bring knowledge to ultimate phenomena, give priority to discerning all thirty. Therefore remember that according to the discourse method all thirty material phenomena together with the heart-base are termed the material base. See directly with the eye of right-view wisdom that the rebirth-linking feeling aggregate can arise only when it has that material base as support, then discern the cause and effect. Remember the same throughout. In accordance with the explanation, discern as follows.

With the arising of the base, the heart-base (30), the feeling aggregate at rebirth-linking arises. The base, the heart-base (30), is the cause. The feeling aggregate at rebirth-linking is the effect.

2. Object. It has already been explained that the object of rebirth-linking mentality is the object of the near-death process in the preceding life. Feeling experiences the taste of that object. See with knowledge and understand that without an object to experience, feeling cannot arise. In the example above, the object of offering food to the Buddha was given only as an illustration to make the point clear. The kammas of meditators are generally different from one person to another. In some, kamma of giving is giving its result. In others, kamma of virtue is giving its result. In still others…


<a id="M05-body-P122"></a>
## Object and contact
Miến / Burmese 122

…kamma of cultivation is giving its result. There are many kinds of kamma of giving, such as offering food, offering robes, and so on. There are many kinds of kamma of virtue, such as observing five precepts, eight precepts, ten precepts, and so on. There are also many kinds of kamma of cultivation, such as cultivating kasiṇa, foulness, mindfulness of breathing, loving-kindness, and insight. Since there can be many kinds of kamma, the object of the near-death process of the previous life and the object of rebirth-linking, life-continuum, and death in the present life can also be of many kinds. After discerning clearly with right-view wisdom the object of the near-death process of the previous life and the present rebirth-linking object, see with knowledge that feeling arises at rebirth-linking only when there is an object to experience. Discern the cause and effect as follows.

With the arising of the object, the kamma-object, the feeling aggregate at rebirth-linking arises. The object, the kamma-object, is the cause. The feeling aggregate at rebirth-linking is the effect.

3. Contact. Phassasamudayā vedanāsamudayo: with the arising of contact, feeling arises. Remember that this teaching gives primacy to contact. In the Paṭṭhāna teaching it is stated as follows.

Cattāro khandhā arūpino aññamaññaṃ sahajātapaccayena paccayo. Cattāro khandhā arūpino aññamaññaṃ nissayapaccayena paccayo. (Paṭṭhāna, vol. 1, p. 5.)

The four mental aggregates support one another through the force of conascence condition and dependence condition. (Paṭṭhāna, vol. 1, p. 5.) The teaching gives a full account in this way. Mental phenomena depend on and support each other like…


<a id="M05-body-P123"></a>
## Burmese page 123
Miến / Burmese 123

…“the island depends on the sandbank, and the sandbank on the island”. When eating a food, chewing thoroughly releases more of its juices and its flavor can be experienced more clearly. So too, among mental phenomena arising together in one group of consciousness or in different groups, when contact approaches the object, connects cognizing consciousness with it, and touches it, the taste of the object can be felt more clearly in the experience of feeling. Thus the teaching “from contact, feeling arises” gives primacy to contact. Yet contact does not have the ability to arise by itself. Only when the other associated phenomena support it through conditions such as conascence and dependence can contact arise together with them. Therefore, when “from contact” is said, remember that the other associated phenomena are included.

The main point to remember. Among the associated phenomena in one group of consciousness, when one mental phenomenon is an effect, that is, when one is discerned as the effect, the remaining mental phenomena are causes. Remember this essential point. The remaining mental aggregates can be understood by taking this feeling aggregate as an example. How mental phenomena support one another across groups of consciousness will be shown later. The meditator should see with knowledge how the mental phenomena support one another. In other words, see how the many mental phenomena such as contact support feeling, or how the three aggregates of perception, formations, and consciousness support the feeling aggregate by conascence…


<a id="M05-body-P124"></a>
## Rebirth-linking — Perception aggregate
Miến / Burmese 124

…mutuality, dependence, and so on. See with knowledge how these phenomena support one another, depend on one another, and are related causally. Discern them. Having seen with knowledge, discern the causes and effects as follows.

With the arising of contact (34 minus feeling, leaving 33), the feeling aggregate arises. Contact (34 minus feeling, leaving 33) is the cause. The feeling aggregate is the effect.

Rebirth-linking — Perception aggregate

Five past causes

1. Ignorance (20) is the cause. The perception aggregate at rebirth-linking is the effect.

2. Craving (20) is the cause. The perception aggregate at rebirth-linking is the effect.

3. Clinging (20) is the cause. The perception aggregate at rebirth-linking is the effect.

4. Formations (34) is the cause. The perception aggregate at rebirth-linking is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The perception aggregate at rebirth-linking is the effect.

Three present causes

6. The base (three groups, 30 kinds of materiality) is the cause. The perception aggregate at rebirth-linking is the effect.


<a id="M05-body-P125"></a>
## Rebirth-linking — Formations aggregate, first method
Miến / Burmese 125

7. The object (kamma-object) is the cause. The perception aggregate at rebirth-linking is the effect.

8. Contact (34 minus perception, leaving 33) is the cause. The perception aggregate at rebirth-linking is the effect.

Rebirth-linking — Formations aggregate (first method, with volition as primary)

Five past causes

1. Ignorance (20) is the cause. The formations aggregate is the effect.

2. Craving (20) is the cause. The formations aggregate is the effect.

3. Clinging (20) is the cause. The formations aggregate is the effect.

4. Formations (34) is the cause. The formations aggregate is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The formations aggregate is the effect.

Three present causes

6. The base (three groups, 30 kinds of materiality) is the cause. The formations aggregate is the effect.

7. The object (kamma-object) is the cause. The formations aggregate is the effect.

8. Contact (34 minus volition, leaving 33) is the cause. The formations aggregate is the effect.

Here the first method is the one that takes volition alone as primary in speaking of the formations aggregate. To account fully for the ultimate phenomena, a further method is given.


<a id="M05-body-P126"></a>
## Rebirth-linking — Formations aggregate, second method
Miến / Burmese 126

Rebirth-linking — Formations aggregate (second method, counting 31 mental factors)

Five past causes

1. Ignorance (20) is the cause. The formations aggregate is the effect.

2. Craving (20) is the cause. The formations aggregate is the effect.

3. Clinging (20) is the cause. The formations aggregate is the effect.

4. Formations (34) is the cause. The formations aggregate is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The formations aggregate is the effect.

Three present causes

6. The base (three groups, 30 kinds of materiality) is the cause. The formations aggregate is the effect.

7. The object (kamma-object) is the cause. The formations aggregate is the effect.

8. The other three mental aggregates is the cause. The formations aggregate is the effect.

Note. Of the thirty-four rebirth-linking mental phenomena, apart from feeling, perception, and consciousness, there remain thirty-one mental factors led by contact and volition. In this second method all thirty-one are called the formations aggregate and stand on the side of the effect. In looking for the present causes of the formations aggregate led by contact and volition, according to “Sesakkhandhā paccayā” (Visuddhimagga, vol. 2, p. 92), the other three mental aggregates, feeling, perception, and consciousness, are causes. They are the closest conditions. The discernment is presented in this second way…


<a id="M05-body-P127"></a>
## Rebirth-linking — Consciousness aggregate
Miến / Burmese 127

…because one may ask whether, if contact is a cause of the mental aggregates, contact itself or the remaining group of mental factors called the formations aggregate has causes. The intention is to discern causes and effects in full. Remember the same principle when the discernment of the formations aggregate is presented in two ways later.

Rebirth-linking — Consciousness aggregate

Five past causes

1. Ignorance (20) is the cause. The consciousness aggregate at rebirth-linking is the effect.

2. Craving (20) is the cause. The consciousness aggregate at rebirth-linking is the effect.

3. Clinging (20) is the cause. The consciousness aggregate at rebirth-linking is the effect.

4. Formations (34) is the cause. The consciousness aggregate at rebirth-linking is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The consciousness aggregate at rebirth-linking is the effect.

One present cause

6. Mentality and materiality is the cause. The consciousness aggregate at rebirth-linking is the effect.

Mentality is the thirty-three associated mental factors. Materiality is the supporting material base (three groups, thirty kinds of materiality) and materiality as object.


<a id="M05-body-P128"></a>
## Burmese page 128
Miến / Burmese 128

Note. “Mentality” is the group of associated mental factors that arise with the consciousness aggregate in a single group of consciousness. At this rebirth-linking moment it means the thirty-three associated mental factors arising with rebirth-linking consciousness. If you were reborn with equanimous feeling, there are thirty-two mental factors reckoned as mentality because joy is absent. “Materiality” is the supporting material base and materiality as object. Among the three kinds of object for the rebirth-linking group, namely kamma, a sign of kamma, and a sign of destination, when the object is materiality, that materiality is the material object. When the object is a sound, that sound is the material object. Understand the other cases in the same way. Moreover, the teaching “Nāmarūpasamudayā viññāṇasamudayo” (Saṃyutta Nikāya, vol. 2, p. 53) means that with the arising of mentality and materiality, consciousness arises. There is also the teaching “Viññāṇapaccayā nāmarūpaṃ” (Abhidhamma, vol. 2, p. 142), meaning that with consciousness as condition, mentality and materiality arise. Therefore remember that consciousness and mentality-materiality support one another. See with knowledge the causal relationship in which consciousness, the consciousness aggregate, arises owing to mentality and materiality, then discern the causes and effects. From these explanations understand that the causes called “base, object, and contact” and the cause called “mentality and materiality” differ in wording, but are the same as ultimate phenomena and in their own nature. The discernment is as follows.

With the arising of mentality and materiality, the consciousness aggregate at rebirth-linking arises. Mentality and materiality are the cause. The consciousness aggregate at rebirth-linking is the effect…


<a id="M05-body-P129"></a>
## The five life-continuum aggregates
Miến / Burmese 129

After rebirth-linking, life-continuum occurs fifteen or sixteen times. After those moments, process consciousness begins with one mind-door adverting and seven greed impulsions that relish existence, that is, greed impulsions attached to the new life. From the first life-continuum onwards, mind-produced and temperature-produced materiality are present. Since temperature-produced materiality began at the presence moment of rebirth-linking, it is of course present at this time. Nutriment-produced materiality arises from the time the mother's food reaches the body of the embryo. Thus, to discern the five life-continuum aggregates immediately after rebirth-linking in causal relationship, use the discernment of the five life-continuum aggregates to be presented below, leaving out nutriment-produced materiality. Discern mind-door adverting in the greed process that relishes existence according to the discernment of the five aggregates of mind-door adverting presented later. Discern the five aggregates of those greed impulsions according to the discernment of greed impulsions in the mind-door process given later. The discernment of the five life-continuum aggregates now occurring in your continuum is presented next.

The five life-continuum aggregates

1. The six material groups at the heart-base, the support for the present life-continuum, comprise fifty-four material phenomena and are the materiality aggregate. If the life-continuum object is materiality, include that materiality too.
2. Among the thirty-four life-continuum mental phenomena, feeling is called the feeling aggregate.


<a id="M05-body-P130"></a>
## Life-continuum — Materiality aggregate
Miến / Burmese 130

3. Among the thirty-four life-continuum mental phenomena, perception is called the perception aggregate.
4. Among the thirty-four life-continuum mental phenomena, volition is called the formations aggregate in the first method. In the second, the thirty-one remaining mental factors are called the formations aggregate.
5. Among the thirty-four life-continuum mental phenomena, cognizing consciousness is called the consciousness aggregate.

Life-continuum — Materiality aggregate

Five past causes

1. Ignorance (20) is the cause. The life-continuum materiality aggregate (kamma-produced materiality) is the effect.

2. Craving (20) is the cause. The life-continuum materiality aggregate (kamma-produced materiality) is the effect.

3. Clinging (20) is the cause. The life-continuum materiality aggregate (kamma-produced materiality) is the effect.

4. Formations (34) is the cause. The life-continuum materiality aggregate (kamma-produced materiality) is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The life-continuum materiality aggregate (kamma-produced materiality) is the effect.

Three present causes

6. Consciousness is the cause. The life-continuum materiality aggregate (mind-produced materiality) is the effect.


<a id="M05-body-P131"></a>
## Life-continuum — Feeling aggregate
Miến / Burmese 131

7. Temperature is the cause. The life-continuum materiality aggregate (temperature-produced materiality) is the effect.

8. Nutriment is the cause. The life-continuum materiality aggregate (nutriment-produced materiality) is the effect.

Life-continuum — Feeling aggregate

Five past causes

1. Ignorance (20) is the cause. The life-continuum feeling aggregate is the effect.

2. Craving (20) is the cause. The life-continuum feeling aggregate is the effect.

3. Clinging (20) is the cause. The life-continuum feeling aggregate is the effect.

4. Formations (34) is the cause. The life-continuum feeling aggregate is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The life-continuum feeling aggregate is the effect.

Three present causes

6. The base (six groups, 54 kinds of materiality) is the cause. The life-continuum feeling aggregate is the effect.

7. The object (kamma-object) is the cause. The life-continuum feeling aggregate is the effect.

8. Contact.

(a) Mind-contact of the preceding life-continuum (34) is the cause. The life-continuum feeling aggregate is the effect.


<a id="M05-body-P132"></a>
## Life-continuum — Perception and formations aggregates
Miến / Burmese 132

(b) Mind-contact of the subsequent life-continuum (34 minus feeling, leaving 33) is the cause. The life-continuum feeling aggregate is the effect.

Note. Mind-contact of the preceding life-continuum (34) belongs to the moment of life-continuum immediately before the one being discerned. This is a cause by proximity condition. Mind-contact of the subsequent life-continuum belongs to the very moment of life-continuum being discerned. When the feeling aggregate stands on the side of the effect, exclude that feeling, leaving thirty-four minus feeling, that is, thirty-three. Remember the same principle for the life-continuum perception aggregate and so on.

Life-continuum — Perception aggregate

1–7. Entirely the same as for the feeling aggregate.
8. Contact.

(a) Mind-contact of the preceding life-continuum (34) is the cause. The life-continuum perception aggregate is the effect.

(b) Mind-contact of the subsequent life-continuum (34 minus perception, leaving 33) is the cause. The life-continuum perception aggregate is the effect.

Life-continuum — Formations aggregate (volition, first method)

1–7. Entirely the same as for the feeling aggregate.
8. Contact.

(a) Mind-contact of the preceding life-continuum (34) is the cause. The life-continuum formations aggregate is the effect.

(b) Mind-contact of the subsequent life-continuum (34 minus volition, leaving 33) is the cause. The life-continuum formations aggregate is the effect.


<a id="M05-body-P133"></a>
## Life-continuum — Formations and consciousness aggregates
Miến / Burmese 133

Life-continuum — Formations aggregate (counting 31 mental factors, second method)

1–7. Entirely the same as for the feeling aggregate.
8. Contact.

(a) Mind-contact of the preceding life-continuum (34) is the cause. The life-continuum formations aggregate is the effect.

(b) The other three mental aggregates is the cause. The life-continuum formations aggregate is the effect.

Life-continuum — Consciousness aggregate

1–5. The five past causes are the same as for the feeling aggregate.

Two present causes

6. Mind-contact of the preceding life-continuum (34) is the cause. The life-continuum consciousness aggregate is the effect.

7. Mentality and materiality is the cause. The life-continuum consciousness aggregate is the effect.

Mentality is the thirty-three associated mental factors. Materiality is the supporting material base and materiality as object.

Visual-object process, that is, the process with colour as object — Five aggregates at five-door adverting

1. The fifty-four material phenomena at the heart-base, the support of five-door adverting, and the visual object are the materiality aggregate.
2. Feeling among the eleven mental phenomena of five-door adverting is the feeling aggregate.
3. Perception among the eleven mental phenomena of five-door adverting is the perception aggregate.


<a id="M05-body-P134"></a>
## Five-door adverting — Materiality aggregate
Miến / Burmese 134

4. Volition among the eleven mental phenomena of five-door adverting is the formations aggregate according to the first method. The eight remaining mental factors among the eleven mental phenomena of five-door adverting are the formations aggregate according to the second method.
5. Cognizing consciousness among the eleven mental phenomena of five-door adverting is the consciousness aggregate.

Five-door adverting, that is, turning to the object — Materiality aggregate

Five past causes

1. Ignorance (20) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

2. Craving (20) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

3. Clinging (20) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

4. Formations (34) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

Three present causes

6. Consciousness is the cause. The mind-produced materiality aggregate is the effect.

7. Temperature is the cause. The temperature-produced materiality aggregate is the effect.

8. Nutriment is the cause. The nutriment-produced materiality aggregate is the effect.


<a id="M05-body-P135"></a>
## Five-door adverting — Feeling and perception aggregates
Miến / Burmese 135

Five-door adverting — Feeling aggregate

Three present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate of five-door adverting is the effect.

2. The object, the visual object is the cause. The feeling aggregate of five-door adverting is the effect.

3. Contact.

(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate of five-door adverting is the effect.

(b) Mind-contact of five-door adverting (11 minus feeling, leaving 10) is the cause. The feeling aggregate of five-door adverting is the effect.

Five-door adverting — Perception aggregate

Three present causes

1. The base, the heart-base materiality (54) is the cause. The perception aggregate of five-door adverting is the effect.

2. The object, the visual object is the cause. The perception aggregate of five-door adverting is the effect.

3. Contact.

(a) Mind-contact of the life-continuum (34) is the cause. The perception aggregate of five-door adverting is the effect.

(b) Mind-contact of five-door adverting (11 minus perception, leaving 10) is the…


<a id="M05-body-P136"></a>
## Five-door adverting — Formations aggregate
Miến / Burmese 136

…cause. The perception aggregate of five-door adverting is the effect.

Five-door adverting — Formations aggregate (volition, first method)

Three present causes

1. The base, the heart-base materiality (54) is the cause. The formations aggregate of five-door adverting is the effect.

2. The object, the visual object is the cause. The formations aggregate of five-door adverting is the effect.

3. Contact.

(a) Mind-contact of the life-continuum (34) is the cause. The formations aggregate of five-door adverting is the effect.

(b) Mind-contact of five-door adverting (11 minus volition, leaving 10) is the cause. The formations aggregate of five-door adverting is the effect.

Five-door adverting — Formations aggregate (eight mental factors, second method)

Three present causes

1. The base, the heart-base materiality (54) is the cause. The formations aggregate of five-door adverting is the effect.

2. The object, the visual object is the cause. The formations aggregate of five-door adverting is the effect.

3. Contact.

(a) Mind-contact of the life-continuum (34) is the cause. The formations aggregate of five-door adverting is the effect.


<a id="M05-body-P137"></a>
## Five-door adverting — Consciousness aggregate
Miến / Burmese 137

(b) The other three mental aggregates is the cause. The formations aggregate of five-door adverting is the effect.

Five-door adverting — Consciousness aggregate

Two present causes

1. Mind-contact of the life-continuum (34) is the cause. The consciousness aggregate of five-door adverting is the effect.

2. Mentality and materiality is the cause. The consciousness aggregate of five-door adverting is the effect.

Mentality is the ten associated mental factors. Materiality is the heart-base (54 kinds of materiality) and the visual object.

Visual-object process, that is, the process with colour as object — Five aggregates at eye-consciousness, that is, seeing

1. The eye-base (six supporting material groups comprising fifty-four material phenomena) and the visual object are the materiality aggregate.
2. Feeling among the eight mental phenomena of eye-consciousness is the feeling aggregate.
3. Perception among the eight mental phenomena of eye-consciousness is the perception aggregate.
4. Volition among the eight mental phenomena of eye-consciousness is the formations aggregate in the first method. The five remaining mental factors among the eight mental phenomena of eye-consciousness are the formations aggregate in the second method.
5. Cognizing consciousness among the eight mental phenomena of eye-consciousness is the consciousness aggregate.


<a id="M05-body-P138"></a>
## Eye-consciousness — Materiality and feeling aggregates
Miến / Burmese 138

Eye-consciousness, that is, seeing — Materiality aggregate

Five past causes

1. Ignorance (20) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

2. Craving (20) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

3. Clinging (20) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

4. Formations (34) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

Three present causes

6. Consciousness is the cause. The mind-produced materiality aggregate is the effect.

7. Temperature is the cause. The temperature-produced materiality aggregate is the effect.

8. Nutriment is the cause. The nutriment-produced materiality aggregate is the effect.

Eye-consciousness, that is, seeing — Feeling aggregate

Five past causes

1. Ignorance (20) is the cause. The feeling aggregate of eye-consciousness is the effect.

2. Craving (20) is the cause. The feeling aggregate of eye-consciousness is the effect.


<a id="M05-body-P139"></a>
## Eye-consciousness — Causes of the feeling aggregate
Miến / Burmese 139

3. Clinging (20) is the cause. The feeling aggregate of eye-consciousness is the effect.

4. Formations (34) is the cause. The feeling aggregate of eye-consciousness is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate of eye-consciousness is the effect.

Five present causes

6. The base, namely the eye-base (54 kinds of materiality) is the cause. The feeling aggregate of eye-consciousness is the effect.

7. The object, namely the visual object is the cause. The feeling aggregate of eye-consciousness is the effect.

8. Eye-contact (8 minus feeling, leaving 7) is the cause. The feeling aggregate of eye-consciousness is the effect.

9. Light is the cause. The feeling aggregate of eye-consciousness is the effect.

10. Attention, namely five-door adverting (11) is the cause. The feeling aggregate of eye-consciousness is the effect.

Attention (manasikāra). Here attention is the turning of the mind toward the object, namely the visual object, and is precisely five-door adverting. The commentators call it attention that leads the cognitive process (vīthipaṭipādakamanasikāra). (Abhidhamma Commentary, vol. 1, p. 177.) It is a basic cause of process consciousness, attending to the object so that those moments can arise.

Light (āloka). Light comprises (1) moonlight, (2) sunlight, (3) firelight, and (4) the light of wisdom, as stated in…


<a id="M05-body-P140"></a>
## Eye-consciousness — Light and the perception aggregate
Miến / Burmese 140

…the Ābhāsutta in the canonical Book of Fours and similar discourses. All four kinds are called light here. When sitting with eyes closed and attending to the Dhamma as at present, the light of wisdom is particularly important. Without that light, one cannot see material groups, their colour, ultimate material phenomena, or ultimate mental phenomena. When insight knowledge has not arisen, or when one is not attending to the powerful cultivation of serenity and insight but sees a visible object with the ordinary physical eye, one of the three kinds of light, moonlight, sunlight, or firelight, is a cause of the mental phenomena of eye-consciousness. The Aṭṭhasālinī Commentary gives four causes of eye-consciousness. (Abhidhamma Commentary, vol. 1, p. 321.) It does not include eye-contact as a further cause. In keeping with the teaching “Phassasamudayā vedanāsamudayo,” meaning that with the arising of contact, feeling arises (Saṃyutta Nikāya, vol. 2, p. 49), eye-contact is included here, giving five present causes.

Eye-consciousness, that is, seeing — Perception aggregate

1–7, 9–10. The causes are the same as for the feeling aggregate.

8. Eye-contact (8 minus perception, leaving 7) is the cause. The perception aggregate of eye-consciousness is the effect.


<a id="M05-body-P141"></a>
## Eye-consciousness — Formations and consciousness aggregates
Miến / Burmese 141

Eye-consciousness, that is, seeing — Formations aggregate (volition, first method)

1–7, 9–10. The causes are the same as for the feeling aggregate.

8. Eye-contact (8 minus volition, leaving 7) is the cause. The formations aggregate of eye-consciousness is the effect.

Eye-consciousness, that is, seeing — Formations aggregate (counting five mental factors, second method)

1–7, 9–10. The causes are the same as for the feeling aggregate.

8. The other three mental aggregates is the cause. The formations aggregate of eye-consciousness is the effect.

Eye-consciousness, that is, seeing — Consciousness aggregate

1–5. The past causes are the same as for the feeling aggregate.

Three present causes

6. Mentality and materiality is the cause. The consciousness aggregate of eye-consciousness is the effect.

7. Light is the cause. The consciousness aggregate of eye-consciousness is the effect.

8. Attention, namely five-door adverting (11) is the cause. The consciousness aggregate of eye-consciousness is the effect.

Mentality is the seven associated mental factors.


<a id="M05-body-P142"></a>
## The five aggregates at receiving
Miến / Burmese 142

Materiality is the supporting material base (54 kinds of materiality) and the visual object. Contact is included among the seven associated mental factors.

Visual-object process, that is, the process with colour as object — Five aggregates at receiving (sampaṭicchana)

1. The fifty-four material phenomena comprising the heart-base, the support of receiving consciousness, and its accompanying materiality, together with the visual object, are the materiality aggregate.

2. Feeling among the 11 mental phenomena at receiving consciousness is the feeling aggregate.

3. Perception among the 11 mental phenomena at receiving consciousness is the perception aggregate.

4. Volition among the 11 mental phenomena at receiving consciousness is the formations aggregate in the first method. The 8 remaining mental factors are the formations aggregate in the second method.

5. Cognizing consciousness among the 11 mental phenomena at receiving consciousness is the consciousness aggregate.

Discern the materiality aggregate at receiving in the same way as the materiality aggregate at five-door adverting.

Receiving — Feeling aggregate

Five past causes

1. Ignorance (20) is the cause. The feeling aggregate at receiving is the effect.

2. Craving (20) is the cause. The feeling aggregate at receiving is the effect.

3. Clinging (20) is the cause. The feeling aggregate at receiving is the effect.


<a id="M05-body-P143"></a>
## Receiving — Feeling, perception, and formations aggregates
Miến / Burmese 143

4. Formations (34) is the cause. The feeling aggregate at receiving is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at receiving is the effect.

Three present causes

6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at receiving is the effect.

7. The object, the visual object is the cause. The feeling aggregate at receiving is the effect.

8(a) Eye-contact (8) is the cause. The feeling aggregate at receiving is the effect.

(b) Mind-contact at receiving (10, that is, 11 minus feeling) is the cause. The feeling aggregate at receiving is the effect.

Receiving — Perception aggregate

1–7. Discern in the same way as for the feeling aggregate.

8(a) Eye-contact (8) is the cause. The perception aggregate at receiving is the effect.

(b) Mind-contact at receiving (10, that is, 11 minus perception) is the cause. The perception aggregate at receiving is the effect.

Receiving — Formations aggregate (volition, first method)

1–7. Discern in the same way as for the feeling aggregate.


<a id="M05-body-P144"></a>
## Receiving — Formations and consciousness aggregates
Miến / Burmese 144

8(a) Eye-contact (8) is the cause. The formations aggregate at receiving is the effect.

(b) Mind-contact at receiving (10, that is, 11 minus volition) is the cause. The formations aggregate at receiving is the effect.

Receiving — Formations aggregate (eight mental factors, second method)

1–7. Discern in the same way as for the feeling aggregate.

8(a) Eye-contact (8) is the cause. The formations aggregate at receiving is the effect.

(b) The other three mental aggregates is the cause. The formations aggregate at receiving is the effect.

Receiving — Consciousness aggregate

1–5. Discern the past causes as for the feeling aggregate.

6. Eye-contact (8) is the cause. The consciousness aggregate at receiving is the effect.

7. Mentality and materiality at receiving is the cause. The consciousness aggregate at receiving is the effect.

Mentality is the ten mental factors associated with receiving consciousness. Materiality is the fifty-four material phenomena comprising the heart-base and the materiality accompanying it, together with the visual object.


<a id="M05-body-P145"></a>
## The five aggregates at investigating
Miến / Burmese 145

Visual-object process, that is, the process with colour as object — Five aggregates at investigating (santīraṇa)

1. The fifty-four material phenomena comprising the heart-base, the support of investigating consciousness, and its accompanying materiality, together with the visual object, are the materiality aggregate.

2. Feeling among the 12 mental phenomena at investigating consciousness is the feeling aggregate.

3. Perception among the 12 mental phenomena at investigating consciousness is the perception aggregate.

4. Volition among the 12 mental phenomena at investigating consciousness is the formations aggregate in the first method. The 9 remaining mental factors are the formations aggregate in the second method.

5. Cognizing consciousness among the 12 mental phenomena at investigating consciousness is the consciousness aggregate.

Note. Investigating consciousness accompanied by joyful feeling has twelve mental phenomena and includes joy. When accompanied by equanimous feeling it has eleven mental phenomena and does not include joy. When the impulsions have joy, investigating consciousness can also be accompanied by joy. Discern its materiality aggregate as in the case of five-door adverting.

Investigating — Feeling aggregate

Five past causes

1. Ignorance (20) is the cause. The feeling aggregate at investigating is the effect.

2. Craving (20) is the cause. The feeling aggregate at investigating is the effect.

3. Clinging (20) is the cause. The feeling aggregate at investigating is the effect.


<a id="M05-body-P146"></a>
## Investigating — Feeling and perception aggregates
Miến / Burmese 146

4. Formations (34) is the cause. The feeling aggregate at investigating is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at investigating is the effect.

Three present causes

6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at investigating is the effect.

7. The object, the visual object is the cause. The feeling aggregate at investigating is the effect.

8(a) Eye-contact (8) is the cause. The feeling aggregate at investigating is the effect.

(b) Mind-contact at receiving (11) is the cause. The feeling aggregate at investigating is the effect.

(c) Mind-contact at investigating (11, that is, 12 minus feeling) is the cause. The feeling aggregate at investigating is the effect.

Investigating — Perception aggregate

1–7. Entirely the same as for the feeling aggregate.

8(a) Eye-contact (8) is the cause. The perception aggregate at investigating is the effect.

(b) Mind-contact at receiving (11) is the cause. The perception aggregate at investigating is the effect.


<a id="M05-body-P147"></a>
## Investigating — Formations aggregate
Miến / Burmese 147

(c) Mind-contact at investigating (11 or 10, that is, 12 minus perception leaves 11, or 11 minus perception leaves 10) is the cause. The perception aggregate at investigating is the effect.

Investigating — Formations aggregate (volition, first method)

1–7. Entirely the same as for the feeling aggregate.

8(a) Eye-contact (8) is the cause. The formations aggregate at investigating is the effect.

(b) Mind-contact at receiving (11) is the cause. The formations aggregate at investigating is the effect.

(c) Mind-contact at investigating (11 or 10, that is, 12 minus volition leaves 11, or 11 minus volition leaves 10) is the cause. The formations aggregate at investigating is the effect.

Investigating — Formations aggregate (nine or eight mental factors, second method)

1–7. Entirely the same as for the feeling aggregate.

8(a) Eye-contact (8) is the cause. The formations aggregate at investigating is the effect.

(b) Mind-contact at receiving (11) is the cause. The formations aggregate at investigating is the effect.

(c) The other three mental aggregates is the cause. The formations aggregate at investigating is the effect.


<a id="M05-body-P148"></a>
## Investigating — Consciousness aggregate and the five aggregates at determining
Miến / Burmese 148

Investigating — Consciousness aggregate

1–5. Entirely the same as for the feeling aggregate.

6(a) Eye-contact (8) is the cause. The consciousness aggregate at investigating is the effect.

(b) Mind-contact at receiving (11) is the cause. The consciousness aggregate at investigating is the effect.

7. Mentality and materiality at investigating is the cause. The consciousness aggregate at investigating is the effect.

Mentality consists of the associated mental factors, eleven with joyful feeling or ten with equanimous feeling. Materiality consists of the fifty-four material phenomena including the heart-base and the materiality accompanying it, together with the visual object.

Visual-object process, that is, the process with colour as object — Five aggregates at determining (voṭṭhapana)

1. The fifty-four material phenomena comprising the heart-base, the support of determining consciousness, and its accompanying materiality, together with the visual object, are the materiality aggregate.

2. Feeling among the 12 mental phenomena at determining consciousness is the feeling aggregate.

3. Perception among the 12 mental phenomena at determining consciousness is the perception aggregate.

4. Volition among the 12 mental phenomena at determining consciousness is the formations aggregate in the first method. The 9 remaining mental factors are the formations aggregate in the second method.

5. Cognizing consciousness among the 12 mental phenomena at determining consciousness is the consciousness aggregate.

Note. Discern the materiality aggregate at determining in the same way as the materiality aggregate at five-door adverting. This determining consciousness is solely functional consciousness (kiriyā)…


<a id="M05-body-P149"></a>
## Determining — Feeling and perception aggregates
Miến / Burmese 149

…and does not arise from past causes. Thus the four mental aggregates at determining have no past causes. They arise only from present causes and therefore have present causes alone.

Determining — Feeling aggregate

Three present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at determining is the effect.

2. The object, the visual object is the cause. The feeling aggregate at determining is the effect.

3(a) Eye-contact (8) is the cause. The feeling aggregate at determining is the effect.

(b) Mind-contact at investigating (12 or 11) is the cause. The feeling aggregate at determining is the effect.

(c) Mind-contact at determining (12 minus feeling, leaving 11) is the cause. The feeling aggregate at determining is the effect.

Determining — Perception aggregate

Three present causes

1. The base, the heart-base materiality (54) is the cause. The perception aggregate at determining is the effect.

2. The object, the visual object is the cause. The perception aggregate at determining is the effect.


<a id="M05-body-P150"></a>
## Determining — Formations aggregate
Miến / Burmese 150

3(a) Eye-contact (8) is the cause. The perception aggregate at determining is the effect.

(b) Mind-contact at investigating (12 or 11) is the cause. The perception aggregate at determining is the effect.

(c) Mind-contact at determining (12 minus perception, leaving 11) is the cause. The perception aggregate at determining is the effect.

Determining — Formations aggregate (volition, first method)

Three present causes

1. The base, the heart-base materiality (54) is the cause. The formations aggregate at determining is the effect.

2. The object, the visual object is the cause. The formations aggregate at determining is the effect.

3(a) Eye-contact (8) is the cause. The formations aggregate at determining is the effect.

(b) Mind-contact at investigating (12 or 11) is the cause. The formations aggregate at determining is the effect.

(c) Mind-contact at determining (12 minus volition, leaving 11) is the cause. The formations aggregate at determining is the effect.

Determining — Formations aggregate (nine mental factors, second method)

Three present causes

1. The base, the heart-base materiality (54) is the cause. The formations aggregate at determining is the effect.


<a id="M05-body-P151"></a>
## Determining — Consciousness aggregate and attention leading to impulsion
Miến / Burmese 151

2. The object, the visual object is the cause. The formations aggregate at determining is the effect.

3(a) Eye-contact (8) is the cause. The formations aggregate at determining is the effect.

(b) Mind-contact at investigating (12 or 11) is the cause. The formations aggregate at determining is the effect.

(c) The other three mental aggregates is the cause. The formations aggregate at determining is the effect.

Determining — Consciousness aggregate

Two present causes

1(a) Eye-contact (8) is the cause. The consciousness aggregate at determining is the effect.

(b) Mind-contact at investigating (12 or 11) is the cause. The consciousness aggregate at determining is the effect.

2. Mentality and materiality at determining is the cause. The consciousness aggregate at determining is the effect.

Mentality is the eleven mental factors associated with determining. Materiality is the fifty-four material phenomena including the heart-base and the materiality accompanying it, together with the visual object.

Attention that leads to impulsion (javanapaṭipādakamanasikāra)

If determining occurs in relation to the object as desirable, undesirable, and so forth, by mistaken attention, that is, unwise attention, then after that determining the corresponding unwholesome impulsions…


<a id="M05-body-P152"></a>
## Attention leading to impulsion and the five aggregates at the first wholesome impulsion
Miến / Burmese 152

…will occur. However, determining within a five-door process does not itself actually decide that the object is desirable, undesirable, permanent, pleasant, self, beautiful, and so forth. Earlier mind-door processes have repeatedly determined the object in such terms as desirable, undesirable, permanent, pleasant, self, and beautiful. When five-door processes then occur, the earlier mind-door processes support them by the power of decisive support. Consequently determining in these later five-door processes occurs in a manner as if determining the object to be desirable, undesirable, permanent, pleasant, self, beautiful, and so forth. That is unwise attention. With that unwise attention as a cause, unwholesome impulsions occur after determining. On the other hand, when determining occurs in the manner of determining the object as a visual object, colour, and so forth, this is wise attention. Wholesome impulsions occur after that determining. Here too, remember that determining is incapable of judging on its own. It occurs as if determining. It is therefore called attention that leads to impulsion, attention to the object as a basic cause of impulsion. (Abhidhamma Commentary, vol. 1, p. 177.) The causal discernment of wholesome impulsions that arise from wise attention is presented first.

Visual-object process, that is, the process with colour as object — Five aggregates at the first wholesome impulsion

1. The fifty-four material phenomena comprising the heart-base, the support of the first wholesome impulsion, and its accompanying materiality, together with the visual object, are the materiality aggregate.

2. Feeling among the 34 mental phenomena at the first wholesome impulsion is the feeling aggregate.


<a id="M05-body-P153"></a>
## First great wholesome impulsion — Feeling aggregate
Miến / Burmese 153

3. Perception among the 34 mental phenomena at the first impulsion is the perception aggregate.

4. Volition among the 34 mental phenomena at the first impulsion is the formations aggregate in the first method. The 31 remaining mental factors are the formations aggregate in the second method.

5. Cognizing consciousness among the 34 mental phenomena at the first impulsion is the consciousness aggregate.

Note. Discern the materiality aggregate at the first wholesome impulsion in the same way as the materiality aggregate at five-door adverting. Impulsion mental phenomena do not arise from past causes. They arise only from present causes. Thus they have no past causes and have present causes alone.

First great wholesome impulsion — Feeling aggregate

Four present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the first impulsion is the effect.

2. The object, the visual object is the cause. The feeling aggregate at the first impulsion is the effect.

3(a) Eye-contact (8) is the cause. The feeling aggregate at the first impulsion is the effect.

(b) Mind-contact at the first impulsion (34 minus feeling, leaving 33) is the cause. The feeling aggregate at the first impulsion is the effect.

4. Wise attention, namely determining (12) is the cause. The feeling aggregate at the first impulsion is the effect.


<a id="M05-body-P154"></a>
## First great wholesome impulsion — Perception and formations aggregates
Miến / Burmese 154

First great wholesome impulsion — Perception aggregate

Four present causes

1. The base, the heart-base materiality (54) is the cause. The perception aggregate at the first impulsion is the effect.

2. The object, the visual object is the cause. The perception aggregate at the first impulsion is the effect.

3(a) Eye-contact (8) is the cause. The perception aggregate at the first impulsion is the effect.

(b) Mind-contact at the first impulsion (34 minus perception, leaving 33) is the cause. The perception aggregate at the first impulsion is the effect.

4. Wise attention, namely determining (12) is the cause. The perception aggregate at the first impulsion is the effect.

First great wholesome impulsion — Formations aggregate (volition, first method)

Four present causes

1. The base, the heart-base materiality (54) is the cause. The formations aggregate at the first impulsion is the effect.

2. The object, the visual object is the cause. The formations aggregate at the first impulsion is the effect.

3(a) Eye-contact (8) is the cause. The formations aggregate at the first impulsion is the effect.

(b) Mind-contact at the first impulsion (34 minus volition, leaving 33) is the cause. The formations aggregate at the first impulsion is the effect.


<a id="M05-body-P155"></a>
## First great wholesome impulsion — Formations and consciousness aggregates
Miến / Burmese 155

4. Wise attention, namely determining (12) is the cause. The formations aggregate at the first impulsion is the effect.

First great wholesome impulsion — Formations aggregate (31 mental factors, second method)

Four present causes

1. The base, the heart-base materiality (54) is the cause. The formations aggregate at the first impulsion is the effect.

2. The object, the visual object is the cause. The formations aggregate at the first impulsion is the effect.

3(a) Eye-contact (8) is the cause. The formations aggregate at the first impulsion is the effect.

(b) The other three mental aggregates is the cause. The formations aggregate at the first impulsion is the effect.

4. Wise attention, namely determining (12) is the cause. The formations aggregate at the first impulsion is the effect.

First great wholesome impulsion — Consciousness aggregate

Three present causes

1. Eye-contact (8) is the cause. The consciousness aggregate at the first impulsion is the effect.

2. Mentality and materiality is the cause. The consciousness aggregate at the first impulsion is the effect.

3. Wise attention, namely determining (12) is the cause. The consciousness aggregate at the first impulsion is the effect.


<a id="M05-body-P156"></a>
## Counts of mental phenomena and proximity condition
Miến / Burmese 156

Mentality consists of the 33 associated mental factors.

Materiality consists of the 54 material phenomena including the supporting heart-base and its accompanying materiality, together with the visual object.

Note. If the impulsion has equanimous feeling, joy is absent. Subtract the factor of joy from the 34 given above. If knowledge is absent, subtract knowledge. If neither knowledge nor joy is present, subtract both. Remember that apart from feeling, perception, and consciousness, all the remaining mental factors, whether few or many, are called the formations aggregate. As for the second impulsion onward, the Buddha taught in the Paṭṭhāna, “Purimā purimā kusalā dhammā pacchimānaṃ pacchimānaṃ kusalānaṃ dhammānaṃ anantarapaccayena paccayo.” (Paṭṭhāna 1, 3.) Thus each earlier impulsion is a proximity cause of the next impulsion. It can also be put as follows.

Yesaṃ yesaṃ dhammānaṃ anantarā ye ye dhammā uppajjanti cittacetasikā dhammā, te te dhammā tesaṃ tesaṃ dhammānaṃ anantarapaccayena paccayo. (Paṭṭhāna 1, 3.)

In accordance with these teachings, each earlier consciousness is a proximity cause of the next. In other words, each preceding group of mental phenomena is a proximity cause of the next group. Add this proximity cause when discerning the second impulsion onward and the registration moments. One may ask whether the first impulsion has a proximity cause. It does. Determining is the proximity cause of the first impulsion. Remember that determining has already been given here under the name of wise attention.


<a id="M05-body-P157"></a>
## Second great wholesome impulsion — Feeling aggregate
Miến / Burmese 157

The feeling aggregate at the second great wholesome impulsion alone is given here as a model. Use this method to discern the other mental aggregates, impulsions, and registration moments. Remember to discern the five aggregates in each impulsion and registration mind-moment.

Second great wholesome impulsion — Feeling aggregate

Four present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate is the effect.

2. The object, the visual object is the cause. The feeling aggregate is the effect.

3(a) Eye-contact (8) is the cause. The feeling aggregate is the effect.

(b) Mind-contact at the first impulsion (34) is the cause. The feeling aggregate is the effect.

(c) Mind-contact at the second impulsion (34 minus feeling, leaving 33) is the cause. The feeling aggregate is the effect.

4. Wise attention, namely determining (12) is the cause. The feeling aggregate is the effect.

1. The proximity cause of the third impulsion is the second impulsion.

2. The proximity cause of the fourth impulsion is the third impulsion.

3. The proximity cause of the fifth impulsion is the fourth impulsion.

4. The proximity cause of the sixth impulsion is the fifth impulsion.

5. The proximity cause of the seventh impulsion is the sixth impulsion.

6. The proximity cause of the first registration is the seventh impulsion.


<a id="M05-body-P158"></a>
## Five aggregates at registration
Miến / Burmese 158

7. The proximity cause of the second registration is the first registration.

With these examples in mind, understand item 3(b) above.

Visual-object process, that is, the process with colour as object — Five aggregates at registration

1. The fifty-four material phenomena comprising the heart-base, the support of great-resultant registration, and its accompanying materiality, together with the visual object, are the materiality aggregate.

2. Feeling among the 34 mental phenomena at great-resultant registration is the feeling aggregate.

3. Perception among the 34 mental phenomena at great-resultant registration is the perception aggregate.

4. Volition among the 34 mental phenomena at great-resultant registration is the formations aggregate in the first method. The 31 remaining mental factors are the formations aggregate in the second method.

5. Cognizing consciousness among the 34 mental phenomena at great-resultant registration is the consciousness aggregate.

Discern the materiality aggregate at registration in the same way as the materiality aggregate at five-door adverting.

First great-resultant registration — Feeling aggregate

Five past causes

1. Ignorance (20) is the cause. The feeling aggregate at the first registration is the effect.

2. Craving (20) is the cause. The feeling aggregate at the first registration is the effect.

3. Clinging (20) is the cause. The feeling aggregate at the first registration is the effect.


<a id="M05-body-P159"></a>
## First great-resultant registration — Feeling, perception, and formations aggregates
Miến / Burmese 159

4. Formations (34) is the cause. The feeling aggregate at the first registration is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at the first registration is the effect.

Three present causes

6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the first registration is the effect.

7. The object, the visual object is the cause. The feeling aggregate at the first registration is the effect.

8(a) Eye-contact (8) is the cause. The feeling aggregate at the first registration is the effect.

(b) Mind-contact at the seventh impulsion (34) is the cause. The feeling aggregate at the first registration is the effect.

(c) Mind-contact at the first registration (34 minus feeling, leaving 33) is the cause. The feeling aggregate at the first registration is the effect.

Perception aggregate at the first registration. In item 8(c), mind-contact at the first registration is 34 minus perception, leaving 33.

Formations aggregate at the first registration. In item 8(c), mind-contact at the first registration is 34 minus volition, leaving 33. This is the first method.

Formations aggregate at the first registration. Item 8(c) is the other three mental aggregates, namely feeling, perception, and consciousness. This is the second method.

These are the only differences. Discern as shown for the feeling aggregate.


<a id="M05-body-P160"></a>
## First great-resultant registration — Consciousness aggregate
Miến / Burmese 160

First great-resultant registration — Consciousness aggregate

Five past causes

1. Ignorance (20) is the cause. The consciousness aggregate at the first registration is the effect.

2. Craving (20) is the cause. The consciousness aggregate at the first registration is the effect.

3. Clinging (20) is the cause. The consciousness aggregate at the first registration is the effect.

4. Formations (34) is the cause. The consciousness aggregate at the first registration is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The consciousness aggregate at the first registration is the effect.

Two present causes

6(a) Eye-contact (8) is the cause. The consciousness aggregate at the first registration is the effect.

(b) Mind-contact at the seventh impulsion (34) is the cause. The consciousness aggregate at the first registration is the effect.

7. Mentality and materiality at the first registration is the cause. The consciousness aggregate at the first registration is the effect.

Mentality consists of the 33 associated mental factors.

Materiality consists of the 54 material phenomena including the supporting heart-base and its accompanying materiality, together with the visual object.

If great-resultant registration has equanimous feeling, joy is absent and there are 33 mental phenomena. If knowledge is absent, then owing to its absence…


<a id="M05-body-P161"></a>
## Counts at registration and the mind-door process
Miến / Burmese 161

…there are 33 mental phenomena. If neither knowledge nor joy is present, there are 32. The count varies with joyful or equanimous feeling and association or dissociation with knowledge. Under the second method for the formations aggregate, the number of mental factors increases or decreases according to those present. If registration is rootless wholesome-resultant investigating with joyful feeling, there are 12 mental phenomena. If it is rootless wholesome-resultant investigating with equanimous feeling, there are 11. If it is rootless unwholesome-resultant investigating with equanimous feeling, there are also 11. When registration is rootless, the count of mental factors in the formations aggregate can differ only under the second method. Discern following the model. Since the first registration is the proximity cause of the second registration, the count for mind-contact under item 8(b) can vary as appropriate among 34, 33, 33, 32, 12, 11, and 11. Take care to discern according to the model.

Mind-door processes taking a visual object

The method of discerning the causal relations of the five aggregates in each mind-moment of an eye-door process with wholesome impulsions has been set out above. Use this same method to discern cause and effect for the remaining mental groups in eye-door processes with wholesome impulsions. After an eye-door process, with intervening life-continuum moments, mind-door processes continue to arise and take the same visual object. Discern the five aggregates of the life-continuum there according to the method given earlier…


<a id="M05-body-P162"></a>
## Mind-door adverting and first great wholesome impulsion
Miến / Burmese 162

…for the five aggregates of the life-continuum. The feeling aggregate at mind-door adverting and at the impulsions is presented below as a model. The fivefold analysis of mind-door adverting is the same as at determining. The fivefold analysis of impulsions and registration follows the model used for impulsions and registration in an eye-door process.

Mind-door adverting — Feeling aggregate

Three present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at mind-door adverting is the effect.

2. The object, the visual object is the cause. The feeling aggregate at mind-door adverting is the effect.

3(a) Eye-contact (8) is the cause. The feeling aggregate at mind-door adverting is the effect.

(b) Mind-contact at the life-continuum (34) is the cause. The feeling aggregate at mind-door adverting is the effect.

(c) Mind-contact at mind-door adverting (12 minus feeling, leaving 11) is the cause. The feeling aggregate at mind-door adverting is the effect.

First great wholesome impulsion — Feeling aggregate

Four present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the first impulsion is the effect.


<a id="M05-body-P163"></a>
## First and second great wholesome impulsions in the mind-door process
Miến / Burmese 163

2. The object, the visual object is the cause. The feeling aggregate at the first impulsion is the effect.

3(a) Eye-contact (8) is the cause. The feeling aggregate at the first impulsion is the effect.

(b) Mind-contact at the life-continuum (34) is the cause. The feeling aggregate at the first impulsion is the effect.

(c) Mind-contact at the first impulsion (34 minus feeling, leaving 33) is the cause. The feeling aggregate at the first impulsion is the effect.

4. Wise attention, namely determining (12) is the cause. The feeling aggregate at the first impulsion is the effect.

Second great wholesome impulsion — Feeling aggregate

Four present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the second impulsion is the effect.

2. The object, the visual object is the cause. The feeling aggregate at the second impulsion is the effect.

3(a) Eye-contact (8) is the cause. The feeling aggregate at the second impulsion is the effect.

(b) Mind-contact at the life-continuum (34) is the cause. The feeling aggregate at the second impulsion is the effect.

(c) Mind-contact at the first impulsion (34) is the cause. The feeling aggregate at the second impulsion is the effect.

(d) Mind-contact at the second impulsion (34 minus feeling, leaving 33) is the cause. The feeling aggregate at the second impulsion is the effect.


<a id="M05-body-P164"></a>
## Explanation of eye-contact and mind-contact
Miến / Burmese 164

4. Wise attention, namely determining (12) is the cause. The feeling aggregate at the second impulsion is the effect.

Use the very methods given above to discern the remaining aggregates and the remaining impulsions and registration moments. By this point the method should be clear.

Explanation of eye-contact and mind-contact

Yampidaṃ cakkhusamphassapaccayā uppajjati vedayitaṃ sukhaṃ vā dukkhaṃ vā adukkhamasukhaṃ vā. (Saṃyutta 2, 248.)

Cakkhusamphassapaccayā uppajjati vedayitanti cakkhusamphassaṃ mūlapaccayaṃ katvā uppannā sampaṭicchana-santīraṇa-voṭṭhabbana-javanavedanā. Cakkhuviññāṇasampayuttāya pana vattabbameva natthi. Sotadvārādivedanāpaccayādīsupi eseva nayo. (Saṃyutta Commentary 3, 5.)

Yampidaṃ manosamphassapaccayā uppajjati vedayitaṃ sukhaṃ vā dukkhaṃ vā adukkhamasukhaṃ vā. (Saṃyutta 2, 248.)

Manosamphassoti bhavaṅgasahajāto samphasso. Vedayitanti javanasahajātā vedanā. Sahāvajjanena bhavaṅgasahajātāpi vaṭṭatiyeva. (Saṃyutta Commentary 3, 5.)

Yamidaṃ (yampidaṃ) cakkhusamphassapaccayā uppajjati vedanāgataṃ saññāgataṃ saṅkhāragataṃ viññāṇagataṃ. (Majjhima 3, 325.)

Yamidaṃ manosamphassapaccayā uppajjati vedanāgataṃ saññāgataṃ saṅkhāragataṃ viññāṇagataṃ. (Majjhima 3, 326.)

Sahāvajjanavedanāya javanavedanā “vedayitan”ti adhippetā.


<a id="M05-body-P165"></a>
## Eye-contact conditions the four mental aggregates
Miến / Burmese 165

Bhavaṅgasampayuttāya pana vedanāya gahaṇe vattabbameva natthi. (Saṃyutta Subcommentary 2, 286.)

According to the Pāli texts, commentaries, and subcommentaries above, feeling at eye-consciousness, receiving, investigating, determining, impulsion, and registration arises on account of eye-contact, and is therefore feeling conditioned by eye-contact. According to the Shorter Discourse of Advice to Rāhula (Cūḷarāhulovādasutta), eye-contact gives rise to more than feeling. “Yamidaṃ cakkhusamphassapaccayā uppajjati vedanāgataṃ saññāgataṃ saṅkhāragataṃ viññāṇagataṃ” (Majjhima 3, 326). All four mental aggregates, feeling, perception, formations, and consciousness, arise. Remember, therefore, that eye-contact associated with eye-consciousness supports the arising of each group of four mental aggregates at eye-consciousness, receiving, investigating, determining, impulsion, and registration.

When explaining how eye-contact supports the mental groups that arise on account of it, the commentary describes support within the same process, the eye-door process. The following Pāli passage also occurs.

“Cakkhusamphassapaccayā vedanākkhandho atthi anupādinno anupādāniyo asaṃkiliṭṭho asaṃkilesiko savitakkasavicāro.”

On the basis of such Pāli passages, the commentator explains that the support given by eye-contact to mental groups in other processes cannot be ruled out. This includes the mental groups in a mind-door process that continues to take the visual object. The explanation further states that the commentary describes the support given by eye-contact to the mental groups in the same eye-door process because such support is certain. (Mūlaṭīkā 2, 30.) Practitioners…


<a id="M05-body-P166"></a>
## Mind-contact in the mind-door process
Miến / Burmese 166

…in their investigations mostly agree with the explanation given by the author of the Mūlaṭīkā. Remember the corresponding principle for ear-contact and the other contacts when they support mind-door processes taking the same sound as the ear-door process or the corresponding objects at the other doors.

Mind-contact is the contact associated with the vibrating life-continuum immediately preceding mind-door adverting and supporting it by the power of proximity condition. This mind-contact also supports the arising of mental groups in the mind-door process, including mind-door adverting, impulsion, and registration when it occurs. In an absorption process the same mind-contact supports the arising of mind-door adverting, the impulsions of access concentration, and the absorption impulsions. Thus, for mental groups in mind-door processes that continue to take a visual object, the support of eye-contact, life-continuum mind-contact, and associated conascent mind-contact has been set out. From the second impulsion onward, proximity causes involving mind-contact, such as the first impulsion, have also been included.

Therefore, good friend, see clearly with knowledge how eye-contact, proximity mind-contact, and associated conascent mind-contact support the relevant mental aggregates in the eye-door groups. Also see how eye-contact, life-continuum mind-contact, proximity mind-contact, and associated conascent mind-contact support the mental groups at the mind door that continue to take that very visual object. See clearly with knowledge the relationship between cause and effect, and discern the causes and effects. Here, for eye-door and mind-door processes with wholesome impulsions that take a visual object…


<a id="M05-body-P167"></a>
## Five aggregates at greed-rooted impulsion associated with wrong view
Miến / Burmese 167

…the presentation of how to discern cause and effect by way of the five aggregates in each mind-moment stops here. Next comes the discernment of cause and effect by way of the five aggregates in each mind-moment of eye-door and mind-door processes with unwholesome impulsions taking the very same visual object.

In eye-door and mind-door processes with unwholesome impulsions that arise taking a visual object, five-door adverting, eye-consciousness, receiving, investigating, determining, registration, life-continuum, mind-door adverting, and registration follow the discernment model for processes with wholesome impulsions. Only the impulsions differ somewhat, so the group of 20 greed-associated mental phenomena with wrong view is given as the model. Like the wholesome impulsion groups, the unwholesome impulsion groups have only present causes and have no past causes.

Visual-object process, that is, the process with colour as object — Five aggregates at greed-rooted impulsion associated with wrong view

1. The fifty-four material phenomena comprising the heart-base, the support of greed-rooted impulsion associated with wrong view, and its accompanying materiality, together with the visual object, are the materiality aggregate.

2. Feeling among the 20 mental phenomena at greed-rooted impulsion associated with wrong view is the feeling aggregate.

3. Perception among the 20 mental phenomena at greed-rooted impulsion associated with wrong view is the perception aggregate.

4. Volition among the 20 mental phenomena at greed-rooted impulsion associated with wrong view is the formations aggregate in the first method. The 17 remaining mental factors are the formations aggregate in the second method.


<a id="M05-body-P168"></a>
## First greed-rooted impulsion associated with wrong view — Feeling and consciousness aggregates
Miến / Burmese 168

5. Cognizing consciousness among the 20 mental phenomena at greed-rooted impulsion associated with wrong view is the consciousness aggregate.

Discern the materiality aggregate at impulsion in the same way as the materiality aggregate at five-door adverting.

First greed-rooted impulsion associated with wrong view — Feeling aggregate (eye-door process)

Four present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the first impulsion is the effect.

2. The object, the visual object is the cause. The feeling aggregate at the first impulsion is the effect.

3(a) Eye-contact (8) is the cause. The feeling aggregate at the first impulsion is the effect.

(b) Mind-contact at the first impulsion (20 minus feeling, leaving 19) is the cause. The feeling aggregate at the first impulsion is the effect.

4. Unwise attention, namely determining (12) is the cause. The feeling aggregate at the first impulsion is the effect.

First greed-rooted impulsion associated with wrong view — Consciousness aggregate (eye-door process)

Three present causes

1. Eye-contact (8) is the cause. The consciousness aggregate at the first impulsion is the effect.

2. Mentality and materiality is the cause. The consciousness aggregate at the first impulsion is the effect.

3. Unwise attention, namely determining (12), is the cause…


<a id="M05-body-P169"></a>
## Second greed-rooted impulsion associated with wrong view
Miến / Burmese 169

…the consciousness aggregate at the first impulsion is the effect.

Mentality consists of the 19 associated mental factors.

Materiality consists of the 54 material phenomena including the heart-base and its accompanying materiality, together with the visual object.

Second greed-rooted impulsion associated with wrong view — Feeling aggregate (eye-door process)

Four present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the second impulsion is the effect.

2. The object, the visual object is the cause. The feeling aggregate at the second impulsion is the effect.

3(a) Eye-contact (8) is the cause. The feeling aggregate at the second impulsion is the effect.

(b) Mind-contact at the first impulsion (20) is the cause. The feeling aggregate at the second impulsion is the effect.

(c) Mind-contact at the second impulsion (20 minus feeling, leaving 19) is the cause. The feeling aggregate at the second impulsion is the effect.

4. Unwise attention, namely determining (12) is the cause. The feeling aggregate at the second impulsion is the effect.

Second greed-rooted impulsion associated with wrong view — Consciousness aggregate (eye-door process)

Three present causes

1(a) Eye-contact (8) is the cause. The consciousness aggregate at the second impulsion is the effect.

(b) Mind-contact at the first impulsion (20) is the cause…


<a id="M05-body-P170"></a>
## Consciousness aggregate and a note on changing objects
Miến / Burmese 170

…the consciousness aggregate at the second impulsion is the effect.

2. Mentality and materiality is the cause. The consciousness aggregate at the second impulsion is the effect.

3. Unwise attention, namely determining (12) is the cause. The consciousness aggregate at the second impulsion is the effect.

Mentality consists of the 19 associated mental factors.

Materiality consists of the 54 material phenomena including the heart-base and its accompanying materiality, together with the visual object.

A point to note

These models suffice to understand how to discern causes and effects by way of the five aggregates in each mind-moment of eye-door and mind-door processes with unwholesome impulsions taking a visual object. Once the discernment of causes and effects by way of the five aggregates in each moment of both wholesome and unwholesome processes taking a visual object is clear, move on to sound and the other objects. Understand how the count in each mind-moment rises or falls with the number of associated mental factors. Note that this variation in associated mental factors within a single mind-moment affects both the formations aggregate and conascent mind-contact. If, good friend, your grounding in Abhidhamma is weak or you have never studied its basics, you will need a teacher’s help. Hence only a few differences are presented here.


<a id="M05-body-P171"></a>
## Sound and the differences according to object
Miến / Burmese 171

Some differences

2. In the sound-object process, sound replaces the visual object and ear-contact replaces eye-contact.

3. In the odour-object process, the object is odour and the contact is nose-contact.

4. In the taste-object process, the object is taste and the contact is tongue-contact.

5. In the tangible-object process, the object is a tangible object and the contact is body-contact.

Sound-object process — Five-door adverting — Feeling aggregate

Three present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at five-door adverting is the effect.

2. The object, sound is the cause. The feeling aggregate at five-door adverting is the effect.

3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at five-door adverting is the effect.

(b) Mind-contact at five-door adverting (11 minus feeling, leaving 10) is the cause. The feeling aggregate at five-door adverting is the effect.


<a id="M05-body-P172"></a>
## Sound — Feeling aggregate at ear-consciousness
Miến / Burmese 172

By now the remaining mental aggregates should be clear. From here on, only one or two aggregates in a mind-moment are illustrated. In practice, discern all five aggregates fully in each mind-moment.

Sound-object process — Feeling aggregate at ear-consciousness, the consciousness that hears

Five past causes

1. Ignorance (20) is the cause. The feeling aggregate at ear-consciousness is the effect.

2. Craving (20) is the cause. The feeling aggregate at ear-consciousness is the effect.

3. Clinging (20) is the cause. The feeling aggregate at ear-consciousness is the effect.

4. Formations (34) is the cause. The feeling aggregate at ear-consciousness is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at ear-consciousness is the effect.

Five present causes

6. The base, the ear-base materiality (54) is the cause. The feeling aggregate at ear-consciousness is the effect.

7. The object, sound is the cause. The feeling aggregate at ear-consciousness is the effect.

8. Ear-contact (8 minus feeling, leaving 7) is the cause. The feeling aggregate at ear-consciousness is the effect.


<a id="M05-body-P173"></a>
## Space element and formations aggregate at receiving
Miến / Burmese 173

9. The space element, the intervening opening is the cause. The feeling aggregate at ear-consciousness is the effect.

10. Attention, namely five-door adverting (11) is the cause. The feeling aggregate at ear-consciousness is the effect.

The space element (ākāsadhātu). There must be an opening between ear-sensitivity and the sound object. Ear-consciousness can arise only in dependence on that space element. Without it, ear-consciousness cannot arise. Indeed, ear-consciousness cannot arise in someone who plugs the ear opening or whose ear opening has been plugged. Thus the space element is among the causes for the arising of the ear-consciousness mental group. (Abhidhamma Commentary 2, 322.)

Sound-object process — Receiving — Formations aggregate (second method)

Five past causes

1. Ignorance (20) is the cause. The formations aggregate at receiving is the effect.

2. Craving (20) is the cause. The formations aggregate at receiving is the effect.

3. Clinging (20) is the cause. The formations aggregate at receiving is the effect.

4. Formations (34) is the cause. The formations aggregate at receiving is the effect.


<a id="M05-body-P174"></a>
## Sound — Formations and consciousness aggregates at receiving
Miến / Burmese 174

5. Kamma, the kammic potency of formations (34) is the cause. The formations aggregate at receiving is the effect.

Three present causes

6. The base, the heart-base materiality (54) is the cause. The formations aggregate at receiving is the effect.

7. The object, sound is the cause. The formations aggregate at receiving is the effect.

8(a) Ear-contact (8) is the cause. The formations aggregate at receiving is the effect.

(b) The other three mental aggregates is the cause. The formations aggregate at receiving is the effect.

Sound-object process — Receiving — Consciousness aggregate

Five past causes

1. Ignorance (20) is the cause. The consciousness aggregate at receiving is the effect.

2. Craving (20) is the cause. The consciousness aggregate at receiving is the effect.

3. Clinging (20) is the cause. The consciousness aggregate at receiving is the effect.

4. Formations (34) is the cause. The consciousness aggregate at receiving is the effect.


<a id="M05-body-P175"></a>
## Sound — Consciousness aggregate at receiving and feeling aggregate at investigating
Miến / Burmese 175

5. Kamma, the kammic potency of formations (34) is the cause. The consciousness aggregate at receiving is the effect.

Two present causes

6. Ear-contact (8) is the cause. The consciousness aggregate at receiving is the effect.

7. Mentality and materiality is the cause. The consciousness aggregate at receiving is the effect.

Mentality consists of the 10 associated mental factors.

Materiality consists of the 54 material phenomena including the heart-base and its accompanying materiality, together with the sound object.

Sound-object process — Investigating — Feeling aggregate

Five past causes

1. Ignorance (20) is the cause. The feeling aggregate at investigating is the effect.

2. Craving (20) is the cause. The feeling aggregate at investigating is the effect.

3. Clinging (20) is the cause. The feeling aggregate at investigating is the effect.

4. Formations (34) is the cause. The feeling aggregate at investigating is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at investigating is the effect.


<a id="M05-body-P176"></a>
## From sound to odour
Miến / Burmese 176

Three present causes

6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at investigating is the effect.

7. The object, sound is the cause. The feeling aggregate at investigating is the effect.

8(a) Ear-contact (8) is the cause. The feeling aggregate at investigating is the effect.

(b) Mind-contact at receiving (11) is the cause. The feeling aggregate at investigating is the effect.

(c) Mind-contact at investigating (12 minus feeling, leaving 11) is the cause. The feeling aggregate at investigating is the effect.

Only enough examples to make the method clear are given here. These models should suffice for the sound-object process. Next, for the odour-object process, only examples are given of discerning causes and effects by way of the five aggregates in each mind-moment.

Odour-object process — Five-door adverting — Feeling aggregate

Three present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at five-door adverting is the effect.

2. The object, odour is the cause. The feeling aggregate at five-door adverting is the effect.


<a id="M05-body-P177"></a>
## Odour — Feeling aggregate at nose-consciousness
Miến / Burmese 177

3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at five-door adverting is the effect.

(b) Mind-contact at five-door adverting (10, that is, 11 minus feeling, leaving 10) is the cause. The feeling aggregate at five-door adverting is the effect.

Odour-object process — Nose-consciousness — Feeling aggregate

Five past causes

1. Ignorance (20) is the cause. The feeling aggregate at nose-consciousness is the effect.

2. Craving (20) is the cause. The feeling aggregate at nose-consciousness is the effect.

3. Clinging (20) is the cause. The feeling aggregate at nose-consciousness is the effect.

4. Formations (34) is the cause. The feeling aggregate at nose-consciousness is the effect.

5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at nose-consciousness is the effect.

Five present causes

6. The base, the nose-base materiality (54) is the cause. The feeling aggregate at nose-consciousness is the effect.

7. The object, odour is the cause. The feeling aggregate at nose-consciousness is the effect.


<a id="M05-body-P178"></a>
## Wind element and receiving in the odour-object process
Miến / Burmese 178

8. Nose-contact (8 minus feeling, leaving 7) is the cause. The feeling aggregate at nose-consciousness is the effect.

9. The wind element is the cause. The feeling aggregate at nose-consciousness is the effect.

10. Attention, namely five-door adverting (11) is the cause. The feeling aggregate at nose-consciousness is the effect.

The wind element (vāyodhātu). Only when the air capable of carrying an odour, the wind element, enters the nasal cavity where nose-sensitivity is located can the mental group together with nose-consciousness arise and cognize the same odour object. In the absence of that odour-bearing air, the wind element, the nose-consciousness mental group with its associated phenomena cannot arise. Hence the wind element is a cause.

Odour-object process — Receiving — Feeling aggregate

1–5. Discern the five past causes following the same model.

Three present causes

6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at receiving is the effect.

7. The object, odour is the cause. The feeling aggregate at receiving is the effect.

8(a) Nose-contact (8) is the cause. The feeling aggregate at receiving is the effect.


<a id="M05-body-P179"></a>
## Odour — Feeling aggregate at investigating
Miến / Burmese 179

(b) Mind-contact at receiving (10, that is, 11 minus feeling, leaving 10) is the cause.

Odour-object process — Investigating — Feeling aggregate

1–5. Discern the five past causes following the same model.

Three present causes

6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at investigating is the effect.

7. The object, odour is the cause. The feeling aggregate at investigating is the effect.

8(a) Nose-contact (8) is the cause. The feeling aggregate at investigating is the effect.

(b) Mind-contact at receiving (11) is the cause. The feeling aggregate at investigating is the effect.

(c) Mind-contact at investigating (11, that is, 12 minus feeling, leaving 11) is the cause. The feeling aggregate at investigating is the effect.

A particular point to remember. Among the present causes of the consciousness aggregates at nose-consciousness, receiving, investigating, and the other moments, where the cause is called mentality and materiality, take mentality as the associated mental factors arising together with the corresponding consciousness aggregate in the same mind-moment. Take materiality as the supporting base materiality and the odour object. In the other processes, likewise take the appropriate associated mental factors, supporting base materiality, and material object.


<a id="M05-body-P180"></a>
## Taste — Feeling aggregate at five-door adverting and tongue-consciousness
Miến / Burmese 180

Taste-object process — Five-door adverting — Feeling aggregate

Three present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at five-door adverting is the effect.

2. The object, taste is the cause. The feeling aggregate at five-door adverting is the effect.

3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at five-door adverting is the effect.

(b) Mind-contact at five-door adverting (10, that is, 11 minus feeling, leaving 10) is the cause. The feeling aggregate at five-door adverting is the effect.

Taste-object process — Tongue-consciousness — Feeling aggregate

1–5. Discern the five past causes following the same model.

Five present causes

6. The base, the tongue-base materiality (54) is the cause. The feeling aggregate at tongue-consciousness is the effect.

7. The object, taste is the cause. The feeling aggregate at tongue-consciousness is the effect.

8. Tongue-contact (8 minus feeling, leaving 7) is the cause. The feeling aggregate at tongue-consciousness is the effect.

9. The water element is the cause. The feeling aggregate at tongue-consciousness is the effect.


<a id="M05-body-P181"></a>
## Water element and receiving in the taste-object process
Miến / Burmese 181

10. Attention, namely five-door adverting (11) is the cause. The feeling aggregate at tongue-consciousness is the effect.

The water element (āpodhātu). The group of phenomena comprising tongue-consciousness and its associated factors can arise only when there is fluid of the water element to moisten the tongue. Without that fluid the group cannot arise. Even when dry food that can be chewed is placed on the tongue of a person whose tongue is dry, tongue-consciousness does not arise. (Abhidhamma Commentary 1, 322.)

Among the present causes of the consciousness aggregates at tongue-consciousness and the subsequent moments, take mentality as the corresponding associated mental factors and materiality as the corresponding supporting base materiality and the taste object.

Taste-object process — Receiving — Feeling aggregate

1–5. Discern the five past causes following the same model.

Three present causes

6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at receiving is the effect.

7. The object, taste is the cause. The feeling aggregate at receiving is the effect.

8(a) Tongue-contact (8) is the cause. The feeling aggregate at receiving is the effect.

(b) Mind-contact at receiving (10, that is, 11 minus feeling, leaving 10) is the cause. The feeling aggregate at receiving is the effect.


<a id="M05-body-P182"></a>
## Taste and tangible objects — Feeling aggregate
Miến / Burmese 182

Taste-object process — Investigating — Feeling aggregate

1–5. Discern the five past causes following the same model.

Three present causes

6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at investigating is the effect.

7. The object, taste is the cause. The feeling aggregate at investigating is the effect.

8(a) Tongue-contact (8) is the cause. The feeling aggregate at investigating is the effect.

(b) Mind-contact at receiving (11) is the cause. The feeling aggregate at investigating is the effect.

(c) Mind-contact at investigating (11, that is, 12 minus feeling, leaving 11) is the cause. The feeling aggregate at investigating is the effect.

Tangible objects-object process — Five-door adverting — Feeling aggregate

Three present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at five-door adverting is the effect.

2. The object, the tangible object is the cause. The feeling aggregate at five-door adverting is the effect.

3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at five-door adverting is the effect.

(b) Mind-contact at five-door adverting (10, that is, 11 minus feeling, leaving 10)…


<a id="M05-body-P183"></a>
## Tangible objects — Feeling aggregate at body-consciousness and the earth element
Miến / Burmese 183

…is the cause. The feeling aggregate at five-door adverting is the effect.

Tangible objects-object process — Body-consciousness — Feeling aggregate

1–5. Discern the five past causes following the same model.

Five present causes

6. The base, the body-base materiality (44) is the cause. The feeling aggregate at body-consciousness is the effect.

7. The object, the tangible object is the cause. The feeling aggregate at body-consciousness is the effect.

8. Body-contact (8 minus feeling, leaving 7) is the cause. The feeling aggregate at body-consciousness is the effect.

9. The earth element is the cause. The feeling aggregate at body-consciousness is the effect.

10. Attention, namely five-door adverting (11) is the cause. The feeling aggregate at body-consciousness is the effect.

The earth element (paṭhavīdhātu). When a tangible object strikes body-sensitivity, the transparent materiality of the body, it impacts both body-sensitivity and the great elements in the same cluster that serve as a support condition for body-sensitivity. Among those great elements, the earth element is the main cause of body-sensitivity. The body-consciousness mental group can arise only when it apprehends the earth element that is the root cause of body-sensitivity. Without that earth element it cannot arise. Indeed…


<a id="M05-body-P184"></a>
## Tangible objects — The earth element and receiving
Miến / Burmese 184

…at the body door, the external great elements called a tangible object, namely external earth, fire, and wind, strike internal body-sensitivity directly. Through that impact they also affect the great elements in the same cluster that support and serve as a cause for body-sensitivity. Hence the earth element is a root cause for the arising of the body-consciousness mental group. (Abhidhamma Commentary 1, 322.)

Among the present causes of the consciousness aggregate at body-consciousness, for the cause termed mentality and materiality, take mentality as all seven mental factors associated with body-consciousness. Take materiality as the 44 material phenomena including the body-base and its accompanying materiality, together with the material objects earth, fire, and wind, termed a tangible object.

Tangible objects-object process — Receiving — Feeling aggregate

1–5. Discern the five past causes following the same model.

Three present causes

6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at receiving is the effect.

7. The object, the tangible object is the cause. The feeling aggregate at receiving is the effect.

8(a) Body-contact (8) is the cause. The feeling aggregate at receiving is the effect.

(b) Mind-contact at receiving (10, that is, 11 minus feeling, leaving 10) is the cause. The feeling aggregate at receiving is the effect.


<a id="M05-body-P185"></a>
## Tangible and mental objects — Feeling aggregate
Miến / Burmese 185

Tangible objects-object process — Investigating — Feeling aggregate

1–5. Discern the five past causes following the same model.

Three present causes

6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at investigating is the effect.

7. The object, the tangible object is the cause. The feeling aggregate at investigating is the effect.

8(a) Body-contact (8) is the cause. The feeling aggregate at investigating is the effect.

(b) Mind-contact at receiving (11) is the cause. The feeling aggregate at investigating is the effect.

(c) Mind-contact at investigating (11 or 10, that is, 12 minus feeling leaving 11, or 11 minus feeling leaving 10) is the cause. The feeling aggregate at investigating is the effect.

Mental-object process — Wholesome impulsion process with eye-sensitivity as object

First impulsion — Feeling aggregate (mind-door process)

Four present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the first impulsion is the effect.

2. The object, eye-sensitivity is the cause. The feeling aggregate at the first impulsion is the effect.


<a id="M05-body-P186"></a>
## Mental objects — Feeling aggregate at the first and second impulsions
Miến / Burmese 186

3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at the first impulsion is the effect.

(b) Mind-contact at the first impulsion (33 (34 minus feeling, leaving 33)) is the cause. The feeling aggregate at the first impulsion is the effect.

4. Wise attention, namely mind-door adverting (12) is the cause. The feeling aggregate at the first impulsion is the effect.

Second impulsion — Feeling aggregate

Four present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the second impulsion is the effect.

2. The object, eye-sensitivity is the cause. The feeling aggregate at the second impulsion is the effect.

3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at the second impulsion is the effect.

(b) Mind-contact at the first impulsion (34) is the cause. The feeling aggregate at the second impulsion is the effect.

(c) Mind-contact at the second impulsion (33 (34 minus feeling, leaving 33)) is the cause. The feeling aggregate at the second impulsion is the effect.

4. Wise attention, namely mind-door adverting (12) is the cause. The feeling aggregate at the second impulsion is the effect.


<a id="M05-body-P187"></a>
## First-jhāna attainment process with the breath counterpart sign
Miến / Burmese 187

Mental-object process — First-jhāna attainment process (taking the breath counterpart sign as object)

First impulsion — Feeling aggregate

Four present causes

1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the first impulsion is the effect.

2. The object, the breath counterpart sign is the cause. The feeling aggregate at the first impulsion is the effect.

3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at the first impulsion is the effect.

(b) Mind-contact at the first impulsion (33) is the cause. The feeling aggregate at the first impulsion is the effect.

4. Wise attention, namely mind-door adverting (12) is the cause. The feeling aggregate at the first impulsion is the effect.

Subtracting feeling from the 34 mental phenomena of the first impulsion leaves 33 for mind-contact at the first impulsion. From the second impulsion onward the only difference is the addition of a proximity cause, the immediately preceding mental phenomena such as those of the first impulsion.

In this jhāna attainment process, for mentality and materiality as a cause of the consciousness aggregate at impulsion, take only the 54 material phenomena comprising the supporting heart-base and its accompanying materiality. The object is the breath counterpart sign, a conceptual object. With the skeleton counterpart sign or the white kasiṇa counterpart sign…


<a id="M05-body-P188"></a>
## Serenity counterpart signs and material phenomena as objects
Miến / Burmese 188

…or any similar serenity sign, see clearly with knowledge the causal relationship of the jhāna mental phenomena that arise taking that sign as object. When discerning causes and effects, for the cause called the object, substitute the serenity counterpart sign taken by the particular jhāna mental group you are discerning. For instance, substitute “the white kasiṇa counterpart sign as object” or the other appropriate designation. There are 34 mental phenomena in the first jhāna, 32 in the second, 31 in the third, 31 in the fourth, and 31 in each of the four immaterial jhānas. Accordingly, reduce the number of mental factors in mind-contact at impulsion as appropriate. Registration does not arise after absorption jhāna impulsions.

Mental-object process — Material phenomena as objects

When discerning a material phenomenon included in the mental-object process, such as one of the five kinds of sensitivity materiality, the transparent materiality, or one of the sixteen kinds of subtle materiality, wholesome impulsions occur accordingly when there is wise attention. Unwholesome impulsions occur accordingly when there is unwise attention. Attending to the material phenomenon as impermanent, suffering, non-self, or unattractive is wise attention. Attending to it as eye-sensitivity or the corresponding material phenomenon is also wise attention. See how unwise attention arises in the meditation subject on mentality. This has been explained in the section on the arising of the ten fetters. The remaining causes are the same as above. The causal discernment for unwholesome impulsion processes should now be clear. If registration occurs, discern it using the registration model given earlier.


<a id="M05-body-P189"></a>
## Individual kammas and their particular results
Miến / Burmese 189

Each case individually

Distinguish the five aggregates in each mind-moment of wholesome and unwholesome impulsion processes throughout the six classes of visual, sound, odour, taste, tangible, and mental objects. Fully discern the causes and effects by relating them according to the five aggregates. In discerning in this way, bear in mind the following.

Vipassakena pana kammantarañca vipākantarañca ekadesato jānitabbaṃ. (Visuddhimagga 2, 237.)

Following that explanation in the Visuddhimagga, good friend, continue to discern kamma and its results case by case, in their particulars. Resultant consciousnesses during life, such as the five sense consciousnesses, receiving, investigating, and registration in the six kinds of processes beginning with the eye-door process, have different kammic causes. Some resultants during life arise from the very kamma that produces rebirth-linking, life-continuum, and death. Others arise from a different kamma. Look at the twelve kinds of result given by the Buddha. Note that each kind of result has its own corresponding kamma. Therefore, good friend, discern the five past aggregates again in detail. If, in doing so, you discern certain wholesome or unwholesome kammas, see clearly with knowledge…


<a id="M05-body-P190"></a>
## Discernment externally and across successive lives
Miến / Burmese 190

…what favourable or adverse results those kammas bring about during the course of a life such as the present one, then discern by relating cause and effect.

Externally, across successive past and future lives

When you have fully discerned the causal relationship between the five past causes and the present effects in all six classes of objects, as above, apply the same method to discern causes and effects externally. Externally, discern like external phenomena together in general terms.

If you succeed, direct knowledge back through successive past lives to discern causes and effects, for example the causes in the second past life with the effects in the first, then the causes in the third past life with the effects in the second. When discerning in this way, in a past life in which you had never discerned mentality and materiality at the ultimate level, there is no need to discern the mental phenomena that arise taking those ultimate material phenomena as object or the causes associated with those mental phenomena. Similarly, in a past life in which jhāna was never attained, there is no need to discern jhāna mental phenomena or their associated causes.

Likewise, discern present causes and future effects by relating cause and effect. Direct knowledge to the successive future lives…


<a id="M05-body-P191"></a>
## Seeds of conduct and seeds of knowledge
Miến / Burmese 191

…as far as the future extends and discern the causes and effects as far as you can. In all three periods, past, present, and future, discern causes and effects externally in the same manner as internally.

Seeds of conduct and seeds of knowledge

In discerning causes and effects in this way, see clearly with knowledge and give particular attention to the following seeds, cultivated, nurtured, and practised in various past lives with the aspiration for Nibbāna.

1. Seeds of conduct are the practice of giving, virtue, and serenity.

2(a) Having discerned the four great elements.

(b) Having discerned material phenomena down to the ultimate level.

(c) Having discerned mental phenomena down to the ultimate level.

(d) Having discerned mentality and materiality down to the ultimate level.

(e) Having discerned causes and effects.

(f) Having contemplated and examined formations, namely materiality, mentality, causes, and effects, by insight under the three characteristics. These are some seeds of knowledge and also some seeds of conduct.

See clearly with knowledge how those seeds of conduct and knowledge support one another in succession through their sustaining potency and directly productive potency. Discern the causes and effects.


<a id="M05-body-P192"></a>
## Proximity causes of the life-continuum
Miến / Burmese 192

Proximity causes of the life-continuum

The consciousness that arises as a factor in the continuity of the stream of consciousness within one life, so that the stream is uninterrupted, is called the life-continuum. It has already been explained that the life-continuum arises from corresponding causes such as ignorance, craving, clinging, formations, kamma, base, object, and contact. Because the life-continuum is the type of consciousness that occurs most frequently during a life, there are also very many proximity causes of it. Briefly, to make the point easy to remember, the mind-moment immediately preceding the life-continuum moment being discerned, the moment that arises with no interval before it, is its proximity cause. Thus the following support by the power of proximity condition.

1. Rebirth-linking supports the first life-continuum moment.

2. The first life-continuum moment supports the second.

3. Each earlier life-continuum moment supports the following one.

4. If the life-continuum occurs after determining, determining supports it.

5. If the life-continuum occurs after impulsion, the final impulsion supports it.

6. If the life-continuum occurs after registration, the second registration supports it.

When one life-continuum moment arises after another, each preceding moment supports the next by the power of proximity condition.


<a id="M05-body-P193"></a>
## Reaching full understanding as the known
Miến / Burmese 193

Reaching full understanding as the known (ñātapariññā)

So “idaṃ nāmarūpaṃ na ahetu appaccayā nibbattaṃ, sahetu sappaccayā nibbattaṃ. Ko pana hetu, ko pana paccayo”ti upaparikkhanto “avijjāpaccayā taṇhāpaccayā kammapaccayā āhārapaccayā cā”ti taṃ paccayaṃ vavatthapetvā “atītepi paccayā ceva paccayasamuppannā dhammā ca, anāgatepi etarahipi paccayā ceva paccayasamuppannā dhammā ca, tato uddhaṃ satto vā puggalo vā natthi, suddhasaṅkhārapuñjo evā”ti tīsu addhāsu kaṅkhaṃ vitarati. Ayaṃ pana vipassanāsaṅkhārasallakkhaṇā ñātapariññā nāma. (Abhidhamma Commentary 2, 241–242.)

A practitioner who has fully discerned the five aggregates, that is, material and mental phenomena, by bases and doors in all six classes of objects, examines with knowledge as follows. “This mentality and materiality arises when there is a direct cause of its arising, a productive cause, and when there is a sustaining condition, a supporting cause. What, then, is the direct cause of this mentality and materiality? What are its supporting conditions?” In this way the practitioner distinguishes the causes of mentality and materiality. “It arises on account of the cause called ignorance, the cause called craving, the cause called kamma, and the cause called nutriment.” For example, with the arising of ignorance, kamma-produced materiality at rebirth-linking, the materiality aggregate, arises…


<a id="M05-body-P194"></a>
## Causes and effects in the three periods
Miến / Burmese 194

…Ignorance is the cause. Kamma-produced materiality at rebirth-linking, the materiality aggregate, is the effect. Having distinguished them in this way, the practitioner sees the following.

1. In the past there are only causes and effects.

2. In the future there are only causes and effects.

3. In the present there are only causes and effects.

Beyond these causes and effects there is no person or being who makes or creates, and no person or being made or created. There is no man, woman, person, being, human, deva, Brahmā, living entity, soul, consciousness, or self as an entity. There are simply groups of formations consisting of material phenomena, mental phenomena, causes, and effects. When right-view knowledge penetrates and sees this for oneself, that knowledge can dispel doubt and mistaken speculation about the past, future, and present. It clearly distinguishes the following formations, which are the objects of insight knowledge.

1. Material phenomena.

2. Mental phenomena.

3. Causes.

4. Effects.

The knowledge that clearly distinguishes these formations is called full understanding as the known. (Abhidhamma Commentary 2, 241–242.) However, at this point…


<a id="M05-body-P195"></a>
## Taking root in the Dispensation
Miến / Burmese 195

…the work is still incomplete. One must make further effort to discern the formations comprising materiality, mentality, causes, and effects by characteristic, function, manifestation, and proximate cause. After making that effort, the next task in the practice is as follows.

Taking root so as to be unable to leave the Dispensation

Evaṃ saṅkhāre sallakkhetvā ṭhito pana bhikkhu no dasabalassa sāsane mūlaṃ otaritvā ṭhito nāma hoti, patiṭṭhaṃ laddhā nāma, cūḷasotāpanno nāma hoti niyatagatikova. Tathārūpaṃ pana utusappāyaṃ puggalasappāyaṃ bhojanasappāyaṃ dhammassavanasappāyaṃ labhitvā ekāsane ekapallaṅkavaragato tīṇi lakkhaṇāni āropetvā vipassanāpaṭipāṭiyā saṅkhāre sammasanto arahattaṃ gaṇhāti. (Abhidhamma Commentary 2, 242.)

The practising bhikkhu has clearly distinguished materiality, mentality, causes, and effects as just described. When discerning those formations with knowledge discerning causes and conditions, the bhikkhu reaches purification by overcoming doubt (kaṅkhāvitaraṇavisuddhi), the clear vision that has gone beyond doubt. Thus the bhikkhu has taken root in the Dispensation of the Buddha, the One of Ten Powers, to the point of being unable to leave it. The bhikkhu has gained a footing in the Dispensation and is called a lesser stream-enterer (cūḷasotāpanna), with a secure good destination. Conditions conducive to attaining arahant fruition include the following.

1. Utusappāya, a suitable climate.

2. Puggalasappāya, suitable people such as good spiritual friends, good companions and relations, good teachers, and good fellow students.


<a id="M05-body-P196"></a>
## Suitable conditions and discernment in the postures
Miến / Burmese 196

3. Bhojanasappāya, suitable food.

4. Dhammassavanasappāya, hearing suitable Dhamma.

Having obtained these four suitable conditions, in a single sitting the practitioner can contemplate formations under the three characteristics, examine them in succession through the course of insight knowledge, and attain arahant fruition. (Abhidhamma Commentary 2, 242.)

Discernment in the postures and with clear comprehension

Good friend, you have practised in succession the meditation subjects on serenity, materiality, and mentality before moving on to dependent origination. Thus you already know how to discern the five aggregates, that is, mentality and materiality, using the methods for the postures and for clear comprehension. For practitioners who have discerned the five aggregates, mentality and materiality, the Buddha taught how to continue as follows.

1. Samudayadhammānupassī vā kāyasmiṃ viharati.

2. Vayadhammānupassī vā kāyasmiṃ viharati.

3. Samudayavayadhammānupassī vā kāyasmiṃ viharati. (Majjhima 1, 71–72.)

In accordance with these teachings, good friend, see clearly with knowledge the causal relationship of the five aggregates, mentality and materiality, while walking, standing, sitting, or lying down, and during the activities in which clear comprehension is practised. Discern causes and effects as far as you are able.


<a id="M05-body-P197"></a>
## Closing aspiration
Miến / Burmese 197

“May you make the effort to practise diligently and become noble among humans, a deva among devas.”

Pa-Auk Tawya Sayadaw

Cittala Monastery

Pa-Auk Tawya Forest

Year 1367 of the Burmese Era.


<a id="M05-index-P001"></a>
## Index — Burmese page 198
Chỉ mục / Index - Miến / Burmese 198

[This page is blank in the source PDF.]


<a id="M05-index-P002"></a>
## Index in Burmese alphabetical order — 199
Chỉ mục / Index - Miến / Burmese 199

Index in Burmese alphabetical order

အ

View of the inefficacy of action (akiriyadiṭṭhi) — 106

The best weapon — 108

Kamma about to give its result — 82

Summary for memorization — 19

How to discern causes and effects — 85

A sequence for finding causes — 39

How to discern by relating causes and effects — 114

Another example — 70

Clinging to a self-view — 104

The five past causes — 20

The influence of past habits — 92

Tracing back to the approach of death in the past — 57

Direct knowledge into the past — 46

A particular point to note — 109

Proximity cause — 156

The five future effects — 20

The nearest cause (padaṭṭhāna) — 126

Knowledge of understanding (anubodhañāṇa) — 4

Understanding and penetration (anubodha and paṭivedha) — 14

Inference and direct experience — 29

Anojādevī’s aspiration — 63

The method of non-agency — 103

Direct knowledge and insight — 35

The Pāli text of the Abhidhamma Vibhaṅga — 21

Coloured light — 139

Venerable Ānanda’s knowledge — 2

The arahant elder Soṇa — 84

The nature of right penetration — 13

Adherence to the doctrine of causelessness — 107

The view of causelessness — 106, 107

Some differences — 171

အာ

Space (ākāsa) — 173


<a id="M05-index-P003"></a>
## Index in Burmese alphabetical order — 200
Chỉ mục / Index - Miến / Burmese 200

The space element — 173

The water element — 181

Fluid of the water element — 181

Discourse on Light (Ābhāsutta) — 140

Formations as accumulation (āyūhanasaṅkhāra) — 25

Object — 120

Light — 140

Cause of nutriment-produced materiality — 87

Supporting kamma — 83

ဣ

Discernment in the postures and with clear comprehension — 196

ဥ

Learning (uggaha) — 6

Annihilationism and eternalism — 98

ဧ

The method of identity — 90, 99

Knowing the method of identity — 98

The method of regularity — 106

က

Kamma that exhausts kamma — 74

The power of kamma condition — 25

Kamma-becoming — 25

The two factors in the round of kamma — 53, 79

Called kammic potency — 27

The materially formed body (karajakāya) — 120

The five rebirth-linking aggregates at the first kalala moment — 112

Transparent body-sensitivity — 183

The rounds of defilements and kamma — 51, 75

The three factors in the round of defilements — 52, 77

Excerpt from the Discourse on the Peaked House (Kūṭāgārasutta) — 31

The princess, daughter of the king of Kosala — 61

How to find the kamma object — 60

When one has seen and known correctly — 106

Seeing and knowing correctly — 104

What is it to see and know correctly? — 103

The young embryo — 116


<a id="M05-index-P004"></a>
## Index in Burmese alphabetical order — 201
Chỉ mục / Index - Miến / Burmese 201

A heartbreaking scene — 68

The main point to remember beforehand — 86

A point to note beforehand — 44

The island depends on the sandbank, and the sandbank on the island — 122

ခ

How to classify the five aggregates — 110

It seems difficult and is difficult. It seems deep and is deep — 93

A pot of curd — 99

ဂ

Odour-object process — Nose-consciousness — Feeling aggregate — 177

Odour-object process — Five-door adverting — Feeling aggregate — 176

Odour-object process — Investigating — Feeling aggregate — 179

Odour-object process — Receiving — Feeling aggregate — 178

စ

Eye-consciousness — Materiality aggregate — 138

Eye-consciousness — Consciousness aggregate — 141

Eye-consciousness — Feeling aggregate — 138

Eye-consciousness — Formations aggregate — 141

Eye-consciousness — Perception aggregate — 140

Seeds of conduct and seeds of knowledge — 191

Shorter Discourse of Advice to Rāhula (Cūḷarāhulovādasutta) — 165

Cūḷasubhaddā’s aspiration — 67

Called a lesser stream-enterer — 195

Discourse on Volition (Cetanāsutta) — 73

Kammic potency — 54

That very kammic potency is kamma — 54

ဆ

The story of Chaddanta, king of the elephants — 64

Aspiration — 71


<a id="M05-index-P005"></a>
## Index in Burmese alphabetical order — 202
Chỉ mục / Index - Miến / Burmese 202

ဇ

Productive kamma (janakakamma) — 83

Attention that leads to impulsion (javanapaṭipādakamanasikāra) — 151

Knowledge of remembering a former birth (jātissarañāṇa) — 64

ဉ

Full understanding as the known — 11

Reaching full understanding as the known — 193

Called full understanding as the known — 12, 194

Knowing through full understanding as the known — 15

တ

Craving itself is called clinging — 51

The doctrine of other sectarians — 6

Discourse on the Sectarian Bases (Titthāyatanasutta) — 21

Called full understanding by scrutinizing — 12

Each case individually — 189

In the same continuum and the same group of consciousness — 123

ဒ

Kamma to be experienced in this very life — 28

Second aspiration — the Brahmā realm — 54

Second impulsion — Feeling aggregate — 186

Four ways of teaching — 42

ဓ

Knowledge of the stability of phenomena through conditions — 39

A natural principle — 35

Mental-object process — Wholesome impulsions taking eye-sensitivity as object — 185

Mental-object process — First-jhāna attainment taking the breath counterpart sign as object — 187

Mental-object process — Material phenomena as objects — 188

The lay follower Dhammika — 85

Retention (dhāraṇā) — 7

န

The method of diversity — 100

Kamma at a different moment — 26

Knowledge of delimiting mentality and materiality — 11

Knowledge of defining mentality and materiality — 40

Changes in the sign — 84

Fatalism — 107

What is fatalism? — 107

The four methods — 90

Material phenomena of devas — 94

The continua of devas — 94


<a id="M05-index-P006"></a>
## Index in Burmese alphabetical order — 203
Chỉ mục / Index - Miến / Burmese 203

The four mental aggregates — 88

What is mentality? — 128

A cow — 82

ပ

Knowledge of discerning causes and conditions — 10

To attain knowledge of discerning causes and conditions — 34

Knowledge of discerning causes and conditions — 81

What is knowledge of discerning causes and conditions? — 34

Conditioned phenomenon (paccayuppannadhamma) — 41

Called a conditioned phenomenon — 41

The five present effects — 20

The five present causes — 20

Five-door adverting — Materiality aggregate — 134

Five-door adverting — Consciousness aggregate — 137

Five-door adverting — Feeling aggregate — 135

Five-door adverting — Formations aggregate (volition, first method) — 136

Five-door adverting — Formations aggregate (eight mental factors, second method) — 136

Five-door adverting — Perception aggregate — 135

Conceptual object — 187

How the Buddha taught dependent origination — 42

Summary of dependent origination by the fifth method for memorization — 17

What is the principle of dependent origination? — 42

The materiality aggregate at rebirth-linking — 115

Rebirth-linking — Consciousness aggregate — 127

Rebirth-linking — Feeling aggregate — 117

Rebirth-linking — Formations aggregate — 125

Rebirth-linking — Perception aggregate — 124

Rebirth-linking is consciousness — 18

First impulsion — Feeling aggregate — 187

First impulsion — Feeling aggregate (mind-door process) — 185

The earth element — 183

Three kinds of full-understanding knowledge — 3

Inquiry (paripucchā) — 7

Called full understanding by abandoning — 12

Volition before the act — 24

Conventional designation by anticipation (pubbūpacārasammuti) — 5

The object of direct knowledge of former lives — 37


<a id="M05-index-P007"></a>
## Index in Burmese alphabetical order — 204
Chỉ mục / Index - Miến / Burmese 204

A painting — 64

ဖ

Contact — 122

Tangible-object process — Body-consciousness — Feeling aggregate — 183

Tangible-object process — Five-door adverting — Feeling aggregate — 182

Tangible-object process — Investigating — Feeling aggregate — 185

Tangible-object process — Receiving — Feeling aggregate — 184

ဗ

Externally, across successive past and future lives — 190

Bahussutabhāva — being learned — 8

What is a learned person? — 9

Material phenomena of Brahmās — 94

The continua of Brahmās — 94

One who has come down from the Brahmā realm — 93

ဘ

Proximity causes of the life-continuum — 192

The five aggregates at the life-continuum — 129

Called the life-continuum — 192

Life-continuum — Materiality aggregate — 130

Life-continuum — Consciousness aggregate — 133

Life-continuum — Feeling aggregate — 131

Life-continuum — Formations aggregate — 132

Life-continuum — Perception aggregate — 132

What is the life-continuum? — 91

When did that craving arise? — 23

မ

Attention that leads the cognitive process (vīthipaṭipādakamanasikāra) — 139

What is attention? — 139

Mind-door adverting — Feeling aggregate — 162

Second great wholesome impulsion — Feeling aggregate — 157, 163

First great wholesome impulsion — Consciousness aggregate — 155


<a id="M05-index-P008"></a>
## Index in Burmese alphabetical order — 205
Chỉ mục / Index - Miến / Burmese 205

First great wholesome impulsion — Feeling aggregate — 153, 162

First great wholesome impulsion — Formations aggregate — 154

First great wholesome impulsion — Perception aggregate — 154

The declaration in the Great Discourse on Causation — 1

First great-resultant registration — Consciousness aggregate — 160

First great-resultant registration — Feeling aggregate — 158

Volition during the act — 24

Queen Subhaddā — 64

The seed and the tree — 98

Natural law — 104

ယ

An example from a practitioner — 69

ရ

Taste-object process — Tongue-consciousness — Feeling aggregate — 180

Taste-object process — Five-door adverting — Feeling aggregate — 180

Taste-object process — Investigating — Feeling aggregate — 182

Taste-object process — Receiving — Feeling aggregate — 181

The materiality aggregate — 87

Visual-object process — Five aggregates at the first wholesome impulsion — 152

Visual-object process — Five aggregates at eye-consciousness, the consciousness that sees — 137

Visual-object process — Five aggregates at five-door adverting — 133

Visual-object process — Five aggregates at registration — 158

Visual-object process — Five aggregates at greed-rooted impulsion associated with wrong view — 167

Visual-object process — Five aggregates at determining — 148

Visual-object process — Five aggregates at investigating — 145

Visual-object process — Five aggregates at receiving — 142


<a id="M05-index-P009"></a>
## Index in Burmese alphabetical order — 206
Chỉ mục / Index - Miến / Burmese 206

Mind-door processes taking a visual object — 161

The materiality aggregate subject to clinging — 111

What to practise when an image of materiality appears — 55

Explanation of eye-contact and mind-contact — 164

Explanation of the base — 119

လ

Human rebirth-linking — 57

Three kinds of mundane full understanding — 11

Three kinds of supramundane full understanding — 13

Second greed-rooted impulsion associated with wrong view — Consciousness aggregate (eye-door process) — 169

Second greed-rooted impulsion associated with wrong view — Feeling aggregate (eye-door process) — 169

ဝ

Wholesome kamma that leads to the round — 49

The truth of the round — 31

Called base materiality — 121

The wind element — 178

Traces of habitual tendencies — 93

Consciousness aggregate (eye-door process) — 168

The consciousness aggregate subject to clinging — 111

The truth of release from the round — 31

Process-free consciousness — 88, 110

Determining — Consciousness aggregate — 151

Determining — Feeling aggregate — 149

Determining — Formations aggregate — 150

Determining — Perception aggregate — 149

The feeling aggregate subject to clinging — 111

သ

Only groups of formations — 194

Formations and kamma-becoming — 24

The formations aggregate subject to clinging — 111

The perception aggregate subject to clinging — 111

A point to note — 170

Sound-object process — Five-door adverting — Feeling aggregate — 171


<a id="M05-index-P010"></a>
## Index in Burmese alphabetical order — 207
Chỉ mục / Index - Miến / Burmese 207

Sound-object process — Investigating — Feeling aggregate — 175

Sound-object process — Receiving — Consciousness aggregate — 174

Sound-object process — Receiving — Formations aggregate (second method) — 173

Sound-object process — Ear-consciousness, the consciousness that hears — Feeling aggregate — 172

Investigating — Consciousness aggregate — 148

Investigating — Feeling aggregate — 145

Investigating — Formations aggregate — 147

Investigating — Perception aggregate — 146

A practitioner whose vehicle is serenity — 50

For a practitioner whose vehicle is serenity — 50

What is the truth of the origin of suffering? — 21

Receiving — Consciousness aggregate — 144

Receiving — Feeling aggregate — 142

Receiving — Formations aggregate — 143

Receiving — Perception aggregate — 143

Listening (savana) — 6

Taking root so as to be unable to leave the Dispensation — 195

What is truth learned by hearing (sutasacca)? — 10

Princess Sumanā’s former aspiration — 61

The Bodhisatta approaching death — 59

Sotāpannatā — becoming a stream-enterer — 7

If one takes oneself to be a stream-enterer — 8

What is a stream-enterer? — 5

When three or four lives are seen — 96

ဟ

Heart-base materiality — 120

❂ ❂ ❂
