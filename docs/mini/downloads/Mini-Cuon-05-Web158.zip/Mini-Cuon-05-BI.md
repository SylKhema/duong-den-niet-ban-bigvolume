# Nibbānagāminipaṭipadā · Mini · Cuốn 5 / Volume 5
Phần Duyên khởi (Paṭiccasamuppāda) — A / Dependent Origination — A
Pa-Auk Tawya Sayadaw
Việt–Anh

## Mục lục / Contents

- [Bìa trước và bìa sau / Front and back cover](#M05-cover-P001)
- [Trang nhan đề / Title page](#M05-front-P001)
- [Pháp thí và lời nguyện / The gift of Dhamma and aspiration](#M05-front-P002)
- [Mục lục — trang đầu / Contents — first page](#M05-front-P003)
- [Mục lục — ခ / Table of contents — ခ](#M05-front-P004)
- [Mục lục — ဂ / Table of contents — ဂ](#M05-front-P005)
- [Mục lục — ဃ / Table of contents — ဃ](#M05-front-P006)
- [Mục lục — င / Table of contents — င](#M05-front-P007)
- [Mục lục — စ / Table of contents — စ](#M05-front-P008)
- [Mục lục — ဆ / Table of contents — ဆ](#M05-front-P009)
- [Phần 1. Lời tuyên bố trong Kinh Đại Duyên / Part 1. The declaration in the Mahānidāna Sutta](#M05-body-P001)
- [Bốn cách quán Duyên khởi và lời Tôn giả Ānanda / Four ways of discerning dependent origination and Ānanda’s statement](#M05-body-P002)
- [Duyên khởi sâu xa và ba loại liễu tri / The depth of dependent origination and the three kinds of full understanding](#M05-body-P003)
- [Phá vỡ bánh xe hữu bằng lưỡi gươm trí tuệ / Breaking the wheel of becoming with the sword of knowledge](#M05-body-P004)
- [Vì sao Duyên khởi hiện rõ đối với Tôn giả Ānanda? / Why dependent origination appeared plain to Venerable Ānanda](#M05-body-P005)
- [Các trợ duyên đời trước và sự nương nơi bến lành / Former supporting conditions and living near a good ford](#M05-body-P006)
- [Học pháp nơi bậc thầy và thành tựu Nhập lưu / Learning from teachers and attaining stream-entry](#M05-body-P007)
- [Tự mình thấy mối liên hệ nhân quả / Seeing the causal connection for oneself](#M05-body-P008)
- [Sự đa văn và trí phân định danh sắc / Learning and the knowledge that distinguishes mentality and materiality](#M05-body-P009)
- [Tài sản nghe học / The wealth of learning](#M05-body-P010)
- [Trí nắm bắt các duyên và ba loại liễu tri hiệp thế / Knowledge that discerns conditions and the three kinds of mundane full understanding](#M05-body-P011)
- [Liễu tri bằng nhận biết, thẩm sát và đoạn trừ / Full understanding as knowing, investigation, and abandoning](#M05-body-P012)
- [Ba loại liễu tri siêu thế / Three kinds of supramundane full understanding](#M05-body-P013)
- [Liễu tri bằng thẩm sát ở tầng siêu thế / Supramundane full understanding as investigation](#M05-body-P014)
- [Hiểu theo nhờ trí sinh khởi nhiều lần / Understanding through the repeated arising of knowledge](#M05-body-P015)
- [Phận sự của Thánh đạo và sự trực tiếp thấy các duyên / Functions of the noble path and directly seeing conditions](#M05-body-P016)
- [Tóm lược Duyên khởi theo phương pháp thứ năm / A summary of dependent origination by the fifth method](#M05-body-P017)
- [Năm nhân quá khứ và năm quả hiện tại / Five past causes and five present results](#M05-body-P018)
- [Năm nhân hiện tại và năm quả tương lai / Five present causes and five future results](#M05-body-P019)
- [Năm nhân và năm quả qua ba thời / Five causes and five results across the three periods](#M05-body-P020)
- [Tập đế được trình bày theo năm cách / The truth of origin taught in five ways](#M05-body-P021)
- [Chuỗi Duyên khởi và Thánh đế về nguồn gốc khổ / The chain of dependent origination and the noble truth of the origin of suffering](#M05-body-P022)
- [Ái nào là nguồn gốc của khổ hiện tại? / Which craving is the origin of present suffering?](#M05-body-P023)
- [Phân biệt hành và nghiệp hữu / Distinguishing formations and kamma-becoming](#M05-body-P024)
- [Tư, hành và sức mạnh của nghiệp duyên / Volition, formations, and the power of kamma condition](#M05-body-P025)
- [Nghiệp khác sát-na và thời điểm trổ quả / Asynchronous kamma and the time of ripening](#M05-body-P026)
- [Vì sao gọi là nghiệp duyên khác sát-na? / Why it is called asynchronous kamma condition](#M05-body-P027)
- [Duyên quá khứ và thời gian tích lũy ba-la-mật / Past conditions and the time needed to cultivate the perfections](#M05-body-P028)
- [Suy luận và trực chứng / Inference and direct experience](#M05-body-P029)
- [Biết bốn Thánh đế đúng như thật / Knowing the four noble truths as they really are](#M05-body-P030)
- [Hai đế thuộc luân hồi và hai đế thoát luân hồi / Two truths of the round and two truths of release from the round](#M05-body-P031)
- [Điều kiện để chấm dứt khổ / The condition for making an end of suffering](#M05-body-P032)
- [Nỗ lực trực chứng bốn Thánh đế / Striving to realize the four noble truths directly](#M05-body-P033)
- [Để đạt trí nắm bắt các duyên / To attain knowledge of discerning conditions](#M05-body-P034)
- [Nghiệp riêng, quả riêng, và hai cách biết quá khứ / Distinct deeds, distinct results, and two ways of knowing the past](#M05-body-P035)
- [Nhớ lại đời trước theo Kinh Khajjanīya / Recollecting former lives in the Khajjanīya Sutta](#M05-body-P036)
- [Các đối tượng của thắng trí nhớ đời trước / The objects of direct knowledge of former lives](#M05-body-P037)
- [Quán các uẩn quá khứ bằng tuệ minh sát / Discerning past aggregates with insight knowledge](#M05-body-P038)
- [Phần 2. Một trình tự tìm các nhân / Part 2. A procedure for finding the causes](#M05-body-P039)
- [Quán các quả trước khi tìm nhân / Apprehending results before looking for causes](#M05-body-P040)
- [Danh sắc quá khứ, hiện tại và tương lai / Mentality and materiality in the past, present, and future](#M05-body-P041)
- [Bốn cách thuyết Duyên khởi / Four ways of teaching dependent origination](#M05-body-P042)
- [Chiều nghịch và phương pháp thứ năm / Reverse order and the fifth method](#M05-body-P043)
- [Lần từ giữa về đầu và nguyên tắc nhiều nhân nhiều quả / Tracing from the middle to the beginning and the principle of many causes and results](#M05-body-P044)
- [Vì sao bài pháp có khi chỉ nêu một nhân? / Why a teaching sometimes singles out one cause](#M05-body-P045)
- [Quán cả những pháp tương ưng / Apprehending the associated phenomena as well](#M05-body-P046)
- [Dùng định và ánh sáng để quán danh sắc / Using concentration and light to apprehend mentality and materiality](#M05-body-P047)
- [Các cách tiếp tục tìm nhân quá khứ / Further ways of looking for past causes](#M05-body-P048)
- [Phát nguyện và quán danh sắc trước khi ngồi thiền / Making an aspiration and apprehending mentality and materiality before sitting](#M05-body-P049)
- [Quán danh sắc vừa qua đối với người lấy thiền chỉ làm cỗ xe / Apprehending recent mentality and materiality for a tranquillity practitioner](#M05-body-P050)
- [Vòng phiền não và vòng nghiệp / The rounds of defilements and kamma](#M05-body-P051)
- [Ba pháp thuộc vòng phiền não / Three phenomena in the round of defilements](#M05-body-P052)
- [Hai pháp thuộc vòng nghiệp / Two phenomena in the round of kamma](#M05-body-P053)
- [Sức nghiệp và trường hợp phát nguyện cõi phạm thiên / Kammic power and the case of aspiring to a brahmā realm](#M05-body-P054)
- [Trình tự thực hành khi thấy một hình ảnh / Procedure when an image appears](#M05-body-P055)
- [Lần về danh sắc quá khứ từng bước / Tracing back through past mentality and materiality step by step](#M05-body-P056)
- [Từ tái tục đến sát-na cận tử của đời trước / From rebirth-linking to the death-proximate period of the preceding life](#M05-body-P057)
- [Tìm cảnh cận tử và lần về nghiệp làm nhân / Finding the death-proximate object and tracing back to the causal kamma](#M05-body-P058)
- [Khi hình ảnh người sắp chết hoặc thi thể hiện ra / When an image of a dying person or a corpse appears](#M05-body-P059)
- [Tìm đối tượng của tốc hành cận tử / Finding the object of death-proximate impulsion](#M05-body-P060)
- [Tìm dòng tâm lúc tạo nghiệp / Finding the succession of consciousness when kamma was made](#M05-body-P061)
- [Năm nhân trong lời nguyện của công chúa Sumanā / Five causes in Princess Sumanā’s aspiration](#M05-body-P062)
- [Năm nhân trong lời nguyện của Anojādevī / Five causes in Anojādevī’s aspiration](#M05-body-P063)
- [Quả của lời nguyện Anojā và chuyện hoàng hậu Subhaddā / The result of Anojā’s aspiration and the story of Queen Subhaddā](#M05-body-P064)
- [Hai voi cái và duyên của việc cúng dường / The two she-elephants and the circumstances of their offering](#M05-body-P065)
- [Sự bố thí hội đủ duyên và lời nguyện của Cūḷasubhaddā / Giving with the requisite conditions and Cūḷasubhaddā’s aspiration](#M05-body-P066)
- [Lời nguyện trả oán và năm pháp làm nhân / The aspiration for revenge and the five causal phenomena](#M05-body-P067)
- [Voi chúa Chaddanta và người thợ săn Soṇuttara / Chaddanta and the hunter Soṇuttara](#M05-body-P068)
- [Một ví dụ của hành giả / An example from a meditator](#M05-body-P069)
- [Phân biệt nhân quả và một ví dụ khác / Discerning cause and effect, and another example](#M05-body-P070)
- [Nghiệp minh sát và lời nguyện / Insight kamma and aspirations](#M05-body-P071)
- [Nghiệp minh sát có thể cho quả tái tục / Insight kamma can give a rebirth result](#M05-body-P072)
- [Miến 73 / Burmese page 73](#M05-body-P073)
- [Miến 74 / Burmese page 74](#M05-body-P074)
- [Miến 75 / Burmese page 75](#M05-body-P075)
- [Miến 76 / Burmese page 76](#M05-body-P076)
- [Miến 77 / Burmese page 77](#M05-body-P077)
- [Miến 78 / Burmese page 78](#M05-body-P078)
- [Hai pháp thuộc nghiệp luân / Two phenomena in the round of kamma](#M05-body-P079)
- [Miến 80 / Burmese page 80](#M05-body-P080)
- [Phần tuệ phân biệt nhân duyên / Knowledge of discerning conditions](#M05-body-P081)
- [Miến 82 / Burmese page 82](#M05-body-P082)
- [Miến 83 / Burmese page 83](#M05-body-P083)
- [Sự thay đổi của tướng / Changes in the sign](#M05-body-P084)
- [Cách quán các pháp nhân và quả / How to discern causes and effects](#M05-body-P085)
- [Điểm chính cần ghi nhớ / Main points to bear in mind](#M05-body-P086)
- [Sắc uẩn / The materiality aggregate](#M05-body-P087)
- [Bốn danh uẩn / The four mental aggregates](#M05-body-P088)
- [Miến 89 / Burmese page 89](#M05-body-P089)
- [Bốn phương pháp — 1. Phương pháp đồng nhất / The four methods — 1. The method of identity](#M05-body-P090)
- [Miến 91 / Burmese page 91](#M05-body-P091)
- [Đặc tính của đời quá khứ / The distinguishing marks of the past](#M05-body-P092)
- [Ánh sáng rộng và mạnh khi quán đời trước / Broad, strong light when discerning a past life](#M05-body-P093)
- [Miến 94 / Burmese page 94](#M05-body-P094)
- [Miến 95 / Burmese page 95](#M05-body-P095)
- [Khi thấy ba hoặc bốn người / When three or four people appear](#M05-body-P096)
- [Miến 97 / Burmese page 97](#M05-body-P097)
- [Đoạn kiến và thường kiến / Annihilationism and eternalism](#M05-body-P098)
- [Miến 99 / Burmese page 99](#M05-body-P099)
- [2. Phương pháp sai biệt / 2. The method of diversity](#M05-body-P100)
- [Miến 101 / Burmese page 101](#M05-body-P101)
- [Miến 102 / Burmese page 102](#M05-body-P102)
- [3. Phương pháp vô tác giả / 3. The method of non-agency](#M05-body-P103)
- [Miến 104 / Burmese page 104](#M05-body-P104)
- [Miến 105 / Burmese page 105](#M05-body-P105)
- [4. Phương pháp tính quy luật / 4. The method of regularity](#M05-body-P106)
- [Thuyết định mệnh / The doctrine of fatalism](#M05-body-P107)
- [Miến 108 / Burmese page 108](#M05-body-P108)
- [Phần 3. Thực hành quán theo phương pháp năm uẩn / Part 3. Practical discernment by the five-aggregate method](#M05-body-P109)
- [Cách nhóm thành năm uẩn / How to group phenomena into five aggregates](#M05-body-P110)
- [Năm thủ uẩn / The five aggregates subject to clinging](#M05-body-P111)
- [Năm uẩn ở sát-na tái tục / The five aggregates at the moment of rebirth-linking](#M05-body-P112)
- [Miến 113 / Burmese page 113](#M05-body-P113)
- [Cách quán nhân nối với quả / How to discern causes in connection with their effects](#M05-body-P114)
- [Sắc uẩn tái tục / The materiality aggregate at rebirth-linking](#M05-body-P115)
- [Miến 116 / Burmese page 116](#M05-body-P116)
- [Thọ uẩn tái tục / The feeling aggregate at rebirth-linking](#M05-body-P117)
- [Cách trình bày tóm tắt / The abbreviated presentation](#M05-body-P118)
- [Tái tục — Thọ uẩn / Rebirth-linking — Feeling aggregate](#M05-body-P119)
- [Miến 120 / Burmese page 120](#M05-body-P120)
- [Vật và cảnh / Base and object](#M05-body-P121)
- [Cảnh và xúc / Object and contact](#M05-body-P122)
- [Miến 123 / Burmese page 123](#M05-body-P123)
- [Tái tục — Tưởng uẩn / Rebirth-linking — Perception aggregate](#M05-body-P124)
- [Tái tục — Hành uẩn, cách thứ nhất / Rebirth-linking — Formations aggregate, first method](#M05-body-P125)
- [Tái tục — Hành uẩn, cách thứ hai / Rebirth-linking — Formations aggregate, second method](#M05-body-P126)
- [Tái tục — Thức uẩn / Rebirth-linking — Consciousness aggregate](#M05-body-P127)
- [Miến 128 / Burmese page 128](#M05-body-P128)
- [Năm uẩn hữu phần / The five life-continuum aggregates](#M05-body-P129)
- [Hữu phần — Sắc uẩn / Life-continuum — Materiality aggregate](#M05-body-P130)
- [Hữu phần — Thọ uẩn / Life-continuum — Feeling aggregate](#M05-body-P131)
- [Hữu phần — Tưởng uẩn và hành uẩn / Life-continuum — Perception and formations aggregates](#M05-body-P132)
- [Hữu phần — Hành uẩn và thức uẩn / Life-continuum — Formations and consciousness aggregates](#M05-body-P133)
- [Hướng ngũ môn — Sắc uẩn / Five-door adverting — Materiality aggregate](#M05-body-P134)
- [Hướng ngũ môn — Thọ uẩn và tưởng uẩn / Five-door adverting — Feeling and perception aggregates](#M05-body-P135)
- [Hướng ngũ môn — Hành uẩn / Five-door adverting — Formations aggregate](#M05-body-P136)
- [Hướng ngũ môn — Thức uẩn / Five-door adverting — Consciousness aggregate](#M05-body-P137)
- [Nhãn thức — Sắc uẩn và thọ uẩn / Eye-consciousness — Materiality and feeling aggregates](#M05-body-P138)
- [Nhãn thức — Các nhân của thọ uẩn / Eye-consciousness — Causes of the feeling aggregate](#M05-body-P139)
- [Nhãn thức — Ánh sáng và tưởng uẩn / Eye-consciousness — Light and the perception aggregate](#M05-body-P140)
- [Nhãn thức — Hành uẩn và thức uẩn / Eye-consciousness — Formations and consciousness aggregates](#M05-body-P141)
- [Năm uẩn ở tâm tiếp thọ / The five aggregates at receiving](#M05-body-P142)
- [Tiếp thọ — Thọ uẩn, tưởng uẩn và hành uẩn / Receiving — Feeling, perception, and formations aggregates](#M05-body-P143)
- [Tiếp thọ — Hành uẩn và thức uẩn / Receiving — Formations and consciousness aggregates](#M05-body-P144)
- [Năm uẩn ở tâm suy đạc / The five aggregates at investigating](#M05-body-P145)
- [Suy đạc — Thọ uẩn và tưởng uẩn / Investigating — Feeling and perception aggregates](#M05-body-P146)
- [Suy đạc — Hành uẩn / Investigating — Formations aggregate](#M05-body-P147)
- [Suy đạc — Thức uẩn và năm uẩn ở tâm xác định / Investigating — Consciousness aggregate and the five aggregates at determining](#M05-body-P148)
- [Xác định — Thọ uẩn và tưởng uẩn / Determining — Feeling and perception aggregates](#M05-body-P149)
- [Xác định — Hành uẩn / Determining — Formations aggregate](#M05-body-P150)
- [Xác định — Thức uẩn và tác ý dẫn đầu tốc hành / Determining — Consciousness aggregate and attention leading to impulsion](#M05-body-P151)
- [Tác ý dẫn đầu tốc hành và năm uẩn ở tốc hành thiện thứ nhất / Attention leading to impulsion and the five aggregates at the first wholesome impulsion](#M05-body-P152)
- [Tốc hành đại thiện thứ nhất — Thọ uẩn / First great wholesome impulsion — Feeling aggregate](#M05-body-P153)
- [Tốc hành đại thiện thứ nhất — Tưởng uẩn và hành uẩn / First great wholesome impulsion — Perception and formations aggregates](#M05-body-P154)
- [Tốc hành đại thiện thứ nhất — Hành uẩn và thức uẩn / First great wholesome impulsion — Formations and consciousness aggregates](#M05-body-P155)
- [Số danh pháp và duyên vô gián / Counts of mental phenomena and proximity condition](#M05-body-P156)
- [Tốc hành đại thiện thứ hai — Thọ uẩn / Second great wholesome impulsion — Feeling aggregate](#M05-body-P157)
- [Năm uẩn ở tâm đăng ký / Five aggregates at registration](#M05-body-P158)
- [Tâm đăng ký đại quả thứ nhất — Thọ, tưởng và hành uẩn / First great-resultant registration — Feeling, perception, and formations aggregates](#M05-body-P159)
- [Tâm đăng ký đại quả thứ nhất — Thức uẩn / First great-resultant registration — Consciousness aggregate](#M05-body-P160)
- [Số danh pháp ở tâm đăng ký và lộ ý môn / Counts at registration and the mind-door process](#M05-body-P161)
- [Hướng ý môn và tốc hành đại thiện thứ nhất / Mind-door adverting and first great wholesome impulsion](#M05-body-P162)
- [Tốc hành đại thiện thứ nhất và thứ hai trong lộ ý môn / First and second great wholesome impulsions in the mind-door process](#M05-body-P163)
- [Giải thích về nhãn xúc và ý xúc / Explanation of eye-contact and mind-contact](#M05-body-P164)
- [Nhãn xúc làm duyên cho bốn danh uẩn / Eye-contact conditions the four mental aggregates](#M05-body-P165)
- [Ý xúc trong lộ ý môn / Mind-contact in the mind-door process](#M05-body-P166)
- [Năm uẩn ở tốc hành tham hợp tà kiến / Five aggregates at greed-rooted impulsion associated with wrong view](#M05-body-P167)
- [Tốc hành tham hợp tà kiến thứ nhất — Thọ uẩn và thức uẩn / First greed-rooted impulsion associated with wrong view — Feeling and consciousness aggregates](#M05-body-P168)
- [Tốc hành tham hợp tà kiến thứ hai / Second greed-rooted impulsion associated with wrong view](#M05-body-P169)
- [Thức uẩn và lưu ý khi chuyển sang cảnh khác / Consciousness aggregate and a note on changing objects](#M05-body-P170)
- [Cảnh thinh và những điểm thay đổi theo cảnh / Sound and the differences according to object](#M05-body-P171)
- [Cảnh thinh — Thọ uẩn của nhĩ thức / Sound — Feeling aggregate at ear-consciousness](#M05-body-P172)
- [Giới hư không và hành uẩn của tâm tiếp thâu / Space element and formations aggregate at receiving](#M05-body-P173)
- [Cảnh thinh — Hành uẩn và thức uẩn của tâm tiếp thâu / Sound — Formations and consciousness aggregates at receiving](#M05-body-P174)
- [Cảnh thinh — Thức uẩn của tâm tiếp thâu và thọ uẩn của tâm suy đạc / Sound — Consciousness aggregate at receiving and feeling aggregate at investigating](#M05-body-P175)
- [Từ cảnh thinh sang cảnh hương / From sound to odour](#M05-body-P176)
- [Cảnh hương — Thọ uẩn của tỷ thức / Odour — Feeling aggregate at nose-consciousness](#M05-body-P177)
- [Giới gió và tâm tiếp thâu trong lộ cảnh hương / Wind element and receiving in the odour-object process](#M05-body-P178)
- [Cảnh hương — Thọ uẩn của tâm suy đạc / Odour — Feeling aggregate at investigating](#M05-body-P179)
- [Cảnh vị — Thọ uẩn của tâm hướng ngũ môn và thiệt thức / Taste — Feeling aggregate at five-door adverting and tongue-consciousness](#M05-body-P180)
- [Giới nước và tâm tiếp thâu trong lộ cảnh vị / Water element and receiving in the taste-object process](#M05-body-P181)
- [Cảnh vị và cảnh xúc — Thọ uẩn / Taste and tangible objects — Feeling aggregate](#M05-body-P182)
- [Cảnh xúc — Thọ uẩn của thân thức và giới đất / Tangible objects — Feeling aggregate at body-consciousness and the earth element](#M05-body-P183)
- [Cảnh xúc — Giới đất và tâm tiếp thâu / Tangible objects — The earth element and receiving](#M05-body-P184)
- [Cảnh xúc và cảnh pháp — Thọ uẩn / Tangible and mental objects — Feeling aggregate](#M05-body-P185)
- [Cảnh pháp — Thọ uẩn của tốc hành thứ nhất và thứ hai / Mental objects — Feeling aggregate at the first and second impulsions](#M05-body-P186)
- [Lộ chứng sơ thiền với tợ tướng hơi thở / First-jhāna attainment process with the breath counterpart sign](#M05-body-P187)
- [Tợ tướng thiền chỉ và sắc pháp làm cảnh / Serenity counterpart signs and material phenomena as objects](#M05-body-P188)
- [Từng nghiệp và từng phần quả / Individual kammas and their particular results](#M05-body-P189)
- [Quán bên ngoài và qua nhiều đời / Discernment externally and across successive lives](#M05-body-P190)
- [Hạt giống hạnh và hạt giống minh / Seeds of conduct and seeds of knowledge](#M05-body-P191)
- [Nhân vô gián của hữu phần / Proximity causes of the life-continuum](#M05-body-P192)
- [Đạt đến tuệ liễu tri bằng nhận biết / Reaching full understanding as the known](#M05-body-P193)
- [Nhân và quả trong ba thời / Causes and effects in the three periods](#M05-body-P194)
- [Bén rễ trong Giáo pháp / Taking root in the Dispensation](#M05-body-P195)
- [Các duyên thích hợp và cách quán trong oai nghi / Suitable conditions and discernment in the postures](#M05-body-P196)
- [Lời nguyện cuối cuốn / Closing aspiration](#M05-body-P197)
- [Chỉ mục — Miến 198 / Index — Burmese page 198](#M05-index-P001)
- [Chỉ mục theo thứ tự chữ cái Miến — 199 / Index in Burmese alphabetical order — 199](#M05-index-P002)
- [Chỉ mục theo thứ tự chữ cái Miến — 200 / Index in Burmese alphabetical order — 200](#M05-index-P003)
- [Chỉ mục theo thứ tự chữ cái Miến — 201 / Index in Burmese alphabetical order — 201](#M05-index-P004)
- [Chỉ mục theo thứ tự chữ cái Miến — 202 / Index in Burmese alphabetical order — 202](#M05-index-P005)
- [Chỉ mục theo thứ tự chữ cái Miến — 203 / Index in Burmese alphabetical order — 203](#M05-index-P006)
- [Chỉ mục theo thứ tự chữ cái Miến — 204 / Index in Burmese alphabetical order — 204](#M05-index-P007)
- [Chỉ mục theo thứ tự chữ cái Miến — 205 / Index in Burmese alphabetical order — 205](#M05-index-P008)
- [Chỉ mục theo thứ tự chữ cái Miến — 206 / Index in Burmese alphabetical order — 206](#M05-index-P009)
- [Chỉ mục theo thứ tự chữ cái Miến — 207 / Index in Burmese alphabetical order — 207](#M05-index-P010)

<a id="M05-cover-P001"></a>
## Bìa trước và bìa sau / Front and back cover
Bìa / Cover

**VI**
Nibbānagāminipaṭipadā — Đường đến Niết-bàn (bản lược), Cuốn 5. Phần Duyên khởi (Paṭiccasamuppāda) — A. Thiền sư Pa-Auk Tawya.

**EN**
Nibbānagāminipaṭipadā — The Practice Leading to Nibbāna (Abridged), Volume 5. Dependent Origination (Paṭiccasamuppāda) — A. Pa-Auk Tawya Sayadaw.

**VI**
Pháp Duyên khởi

**EN**
The teaching of dependent origination

**VI**
Đức Phật không lập ra hay tạo nên quy luật Duyên khởi này. Dù chư Phật xuất hiện hay không xuất hiện, quy luật ấy vẫn tồn tại. Chỉ khi chư Phật xuất hiện, nhờ các Ngài khai thị và thuyết giảng, chúng sinh mới có dịp biết đến pháp này. Nếu Đức Phật không xuất hiện, hoặc có xuất hiện mà người ta không được nghe pháp, hoặc đã nghe mà vẫn chấp chặt những tà kiến như thường kiến và đoạn kiến, thì họ không thể hiểu được quy luật Duyên khởi này.

**EN**
The Buddha did not establish or create this principle of dependent origination. Whether or not Buddhas arise, the principle still holds. Only when Buddhas arise and disclose and teach it do beings have the opportunity to know it. If a Buddha does not arise, if people do not hear the teaching when one arises, or if, even after hearing it, they cling to such wrong views as eternalism and annihilationism, they cannot understand this principle of dependent origination.

**VI**
Pháp Duyên khởi sâu xa, có vẻ sâu xa, khó hiểu, có vẻ khó hiểu. Khi Tôn giả Ānanda nói pháp ấy dễ hiểu và nông cạn, Đức Phật ngăn lại: “Mā hevaṃ, Ānanda … Này Ānanda, chớ nói như vậy.” Dù pháp này khó hiểu và sâu xa đến đâu, ai chưa biết rõ Duyên khởi thì không thể thoát khỏi khổ luân hồi. Ai chưa biết pháp này thì chưa xứng đáng được gọi là sa-môn hay bà-la-môn.

**EN**
Dependent origination is deep and appears deep, difficult and appears difficult. When Venerable Ānanda said that it was easy and shallow, the Buddha restrained him: “Mā hevaṃ, Ānanda … Ānanda, do not say so.” However difficult and profound this teaching may be, one who has yet to know dependent origination clearly cannot escape the suffering of saṃsāra. One who has yet to know this teaching does not deserve to be called an ascetic or a brahmin.

**VI**
Chư Phật đã xuất hiện, đang xuất hiện và sẽ xuất hiện thành tựu Phật quả nhờ biết rõ pháp Duyên khởi. Chừng nào chúng sinh còn chưa biết rõ pháp này, họ còn rơi vào một trong hai vực sâu là thường kiến và đoạn kiến, và còn phải chịu mọi nỗi khổ. Vì vậy, trong Nidānasaṃyutta, Đức Phật dạy rằng ai muốn thoát khỏi khổ luân hồi phải nỗ lực thấu hiểu pháp Duyên khởi này. (Theo bản nissaya của Nidānavaggasaṃyutta.)

**EN**
The Buddhas of the past, present, and future attain Buddhahood through clearly knowing dependent origination. As long as beings have yet to know it clearly, they continue to fall into one of two abysses, eternalism and annihilationism, and undergo all kinds of suffering. Therefore, in the Nidānasaṃyutta the Buddha taught that anyone wishing to escape the suffering of saṃsāra must strive to penetrate this teaching of dependent origination. (From the nissaya of the Nidānavaggasaṃyutta.)


<a id="M05-front-P001"></a>
## Trang nhan đề / Title page
Đầu sách / Front matter - 1

**VI**
Nibbānagāminipaṭipadā — Đường đến Niết-bàn (bản lược), Cuốn 5. Phần Duyên khởi (Paṭiccasamuppāda) — A. Thiền sư Pa-Auk Tawya.

**EN**
Nibbānagāminipaṭipadā — The Practice Leading to Nibbāna (Abridged), Volume 5. Dependent Origination (Paṭiccasamuppāda) — A. Pa-Auk Tawya Sayadaw.


<a id="M05-front-P002"></a>
## Pháp thí và lời nguyện / The gift of Dhamma and aspiration
Đầu sách / Front matter - 2

**VI**
Sabbadānaṃ dhammadānaṃ jināti.
Sabbarasaṃ dhammaraso jināti.
Sabbaratiṃ dhammarati jināti.
Taṇhakkhayo sabbadukkhaṃ jināti.

**EN**
Sabbadānaṃ dhammadānaṃ jināti.
Sabbarasaṃ dhammaraso jināti.
Sabbaratiṃ dhammarati jināti.
Taṇhakkhayo sabbadukkhaṃ jināti.

**VI**
Pháp thí thắng mọi sự bố thí.
Vị Pháp thắng mọi vị.
Niềm vui trong Pháp thắng mọi niềm vui.
Ái diệt thắng mọi khổ.

**EN**
The gift of Dhamma surpasses every gift.
The taste of Dhamma surpasses every taste.
Delight in Dhamma surpasses every delight.
The destruction of craving overcomes all suffering.

**VI**
Ciraṃ tiṭṭhatu saddhammo, dhamme hontu sagāravā.

**EN**
Ciraṃ tiṭṭhatu saddhammo, dhamme hontu sagāravā.

**VI**
Nguyện giáo pháp của Đức Phật tồn tại lâu dài. Nguyện mọi người kính trọng ba loại Chánh pháp.

**EN**
May the Buddha’s dispensation endure for a long time. May all honour the three kinds of true Dhamma.


<a id="M05-front-P003"></a>
## Mục lục — trang đầu / Contents — first page
Đầu sách / Front matter - 3

**VI**
Namo tassa bhagavato arahato sammāsambuddhassa.

**EN**
Namo tassa bhagavato arahato sammāsambuddhassa.

**VI**
Phần Duyên khởi (Paṭiccasamuppāda) — A. Mục lục.

**EN**
Dependent Origination (Paṭiccasamuppāda) — A. Contents.

**VI**
Phần 1 — 1

**EN**
Part 1 — 1

**VI**
Lời tuyên bố trong Kinh Đại Duyên — 1

**EN**
The declaration in the Great Discourse on Causation — 1

**VI**
Thế nào là bậc Nhập lưu? — 5

**EN**
What is a stream-enterer? — 5

**VI**
Quy ước gọi tên theo nghĩa có trước (pubbūpacārasammuti) — 5

**EN**
Conventional designation by anticipation (pubbūpacārasammuti) — 5

**VI**
Chủ trương của ngoại đạo — 6

**EN**
The doctrine of other sectarians — 6

**VI**
Sotāpannatā — sự thành tựu Nhập lưu — 7

**EN**
Sotāpannatā — becoming a stream-enterer — 7

**VI**
Bahussutabhāva — sự đa văn — 8

**EN**
Bahussutabhāva — being learned — 8

**VI**
Thế nào là người đa văn? — 9

**EN**
What is a learned person? — 9

**VI**
Ba loại liễu tri hiệp thế — 11

**EN**
Three kinds of mundane full understanding — 11

**VI**
Ba loại liễu tri siêu thế — 13

**EN**
Three kinds of supramundane full understanding — 13

**VI**
Hiểu và thấu triệt (anubodha và paṭivedha) — 14

**EN**
Understanding and penetration (anubodha and paṭivedha) — 14

**VI**
Tóm lược Duyên khởi theo phương pháp thứ năm để ghi nhớ — 17

**EN**
A summary of dependent origination by the fifth method for memorization — 17

**VI**
Thế nào là sự thật về nguồn gốc khổ? — 21

**EN**
What is the truth of the origin of suffering? — 21

**VI**
Nhân ấy có từ khi nào? — 23

**EN**
When did that cause arise? — 23

**VI**
Hành và nghiệp hữu — 24

**EN**
Formations and kamma-becoming — 24

**VI**
Sức mạnh của nghiệp duyên — 25

**EN**
The power of kamma condition — 25

**VI**
Suy luận và trực chứng — 29

**EN**
Inference and direct experience — 29

**VI**
Trích Kinh Nhà Có Nóc Nhọn (Kūṭāgārasutta) — 31

**EN**
An excerpt from the Discourse on the Peaked House (Kūṭāgārasutta) — 31

**VI**
Để đạt tuệ phân biệt nhân duyên (paccayapariggahañāṇa) — 34

**EN**
To attain knowledge of discerning conditions (paccayapariggahañāṇa) — 34

**VI**
Thắng trí và minh sát — 35

**EN**
Direct knowledge and insight — 35


<a id="M05-front-P004"></a>
## Mục lục — ခ / Table of contents — ခ
Đầu sách / Front matter - 4

**VI**
Đề mục — Trang

**EN**
Subject — Page

**VI**
Phần 2 — 39

**EN**
Part 2 — 39

**VI**
Một trình tự tìm các pháp nhân — 39

**EN**
A sequence for finding causes — 39

**VI**
Cách Đức Phật thuyết pháp Duyên khởi — 42

**EN**
How the Buddha taught dependent origination — 42

**VI**
Bốn cách thuyết giảng — 42

**EN**
Four ways of teaching — 42

**VI**
Một điểm cần lưu ý trước — 44

**EN**
A point to note beforehand — 44

**VI**
Hãy hướng trí về quá khứ để xem — 46

**EN**
Direct knowledge into the past — 46

**VI**
Nếu là hành giả lấy thiền chỉ làm cỗ xe — 50

**EN**
For a practitioner whose vehicle is serenity — 50

**VI**
Vòng phiền não và vòng nghiệp — 51

**EN**
The rounds of defilements and kamma — 51

**VI**
Ba pháp thuộc vòng phiền não — 52

**EN**
The three factors in the round of defilements — 52

**VI**
Hai pháp thuộc vòng nghiệp — 53

**EN**
The two factors in the round of kamma — 53

**VI**
Trường hợp phát nguyện thứ hai — cõi Phạm thiên — 54

**EN**
Second aspiration — the Brahmā realm — 54

**VI**
Việc cần thực hành khi hình ảnh sắc hiện ra — 55

**EN**
What to practise when an image of materiality appears — 55

**VI**
Lần về cận tử quá khứ — 57

**EN**
Tracing back to the approach of death in the past — 57

**VI**
Cách tìm cảnh nghiệp — 60

**EN**
How to find the kamma object — 60

**VI**
Lời nguyện trước kia của công chúa Sumanā — 61

**EN**
Princess Sumanā’s former aspiration — 61

**VI**
Lời nguyện của Anojādevī — 63

**EN**
Anojādevī’s aspiration — 63

**VI**
Hoàng hậu Subhaddā — 64

**EN**
Queen Subhaddā — 64

**VI**
Một ví dụ của hành giả — 69

**EN**
An example from a practitioner — 69

**VI**
Một ví dụ khác — 70

**EN**
Another example — 70

**VI**
Vòng phiền não và vòng nghiệp — 75

**EN**
The rounds of defilements and kamma — 75

**VI**
Ba pháp thuộc vòng phiền não — 77

**EN**
The three factors in the round of defilements — 77

**VI**
Hai pháp thuộc vòng nghiệp — 79

**EN**
The two factors in the round of kamma — 79

**VI**
Phần tuệ phân biệt nhân duyên — 81

**EN**
Knowledge of discerning causes and conditions — 81

**VI**
Sự thay đổi của tướng — 84

**EN**
Changes in the sign — 84


<a id="M05-front-P005"></a>
## Mục lục — ဂ / Table of contents — ဂ
Đầu sách / Front matter - 5

**VI**
Đề mục — Trang

**EN**
Subject — Page

**VI**
Cách quán các pháp nhân và quả — 85

**EN**
How to discern causes and effects — 85

**VI**
Điểm chính cần ghi nhớ trước — 86

**EN**
The main point to remember beforehand — 86

**VI**
Sắc uẩn — 87

**EN**
The materiality aggregate — 87

**VI**
Bốn danh uẩn — 88

**EN**
The four mental aggregates — 88

**VI**
Bốn phương pháp — 1. Phương pháp đồng nhất — 90

**EN**
Four methods — 1. The method of identity — 90

**VI**
Sức chi phối của tập khí quá khứ — 92

**EN**
The influence of past habits — 92

**VI**
Có vẻ khó, và quả thật là khó. Có vẻ sâu, và quả thật là sâu — 93

**EN**
It seems difficult and is difficult. It seems deep and is deep — 93

**VI**
Khi thấy được ba hoặc bốn đời — 96

**EN**
When three or four lives are seen — 96

**VI**
Đoạn kiến và thường kiến — 98

**EN**
Annihilationism and eternalism — 98

**VI**
2. Phương pháp sai biệt — 100

**EN**
2. The method of diversity — 100

**VI**
3. Phương pháp vô tác giả — 103

**EN**
3. The method of non-agency — 103

**VI**
4. Phương pháp tính quy luật — 106

**EN**
4. The method of regularity — 106

**VI**
Thuyết định mệnh — 107

**EN**
Fatalism — 107

**VI**
Phần 3 — 109

**EN**
Part 3 — 109

**VI**
Thực hành quán theo năm uẩn — 109

**EN**
Practical discernment by way of the five aggregates — 109

**VI**
Điểm đặc biệt cần lưu ý — 109

**EN**
A particular point to note — 109

**VI**
Cách phân thành năm uẩn — 110

**EN**
How to classify the five aggregates — 110

**VI**
Năm uẩn tái tục ở sát-na đầu của phôi kalala — 112

**EN**
The five rebirth-linking aggregates at the first kalala moment — 112

**VI**
Cách quán các pháp bằng cách nối nhân với quả — 114

**EN**
How to discern by relating causes and effects — 114

**VI**
Sắc uẩn tái tục — 115

**EN**
The materiality aggregate at rebirth-linking — 115

**VI**
Tái tục — Thọ uẩn — 117

**EN**
Rebirth-linking — Feeling aggregate — 117

**VI**
Giải thích — 1. Vật — 119

**EN**
Explanation — 1. Base — 119

**VI**
2. Cảnh — 120

**EN**
2. Object — 120


<a id="M05-front-P006"></a>
## Mục lục — ဃ / Table of contents — ဃ
Đầu sách / Front matter - 6

**VI**
Đề mục — Trang

**EN**
Subject — Page

**VI**
3. Xúc — 122

**EN**
3. Contact — 122

**VI**
Tái tục — Tưởng uẩn — 124

**EN**
Rebirth-linking — Perception aggregate — 124

**VI**
Tái tục — Hành uẩn — 125

**EN**
Rebirth-linking — Formations aggregate — 125

**VI**
Tái tục — Thức uẩn — 127

**EN**
Rebirth-linking — Consciousness aggregate — 127

**VI**
Năm uẩn của hữu phần — 129

**EN**
The five aggregates at the life-continuum — 129

**VI**
Hữu phần — Sắc uẩn — 130

**EN**
Life-continuum — Materiality aggregate — 130

**VI**
Hữu phần — Thọ uẩn — 131

**EN**
Life-continuum — Feeling aggregate — 131

**VI**
Hữu phần — Tưởng uẩn — 132

**EN**
Life-continuum — Perception aggregate — 132

**VI**
Hữu phần — Hành uẩn — 132

**EN**
Life-continuum — Formations aggregate — 132

**VI**
Hữu phần — Thức uẩn — 133

**EN**
Life-continuum — Consciousness aggregate — 133

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm hướng ngũ môn — 133

**EN**
Visual-object process — Five aggregates at five-door adverting — 133

**VI**
Hướng ngũ môn — Sắc uẩn — 134

**EN**
Five-door adverting — Materiality aggregate — 134

**VI**
Hướng ngũ môn — Thọ uẩn — 135

**EN**
Five-door adverting — Feeling aggregate — 135

**VI**
Hướng ngũ môn — Tưởng uẩn — 135

**EN**
Five-door adverting — Perception aggregate — 135

**VI**
Hướng ngũ môn — Hành uẩn (tư, cách thứ nhất) — 136

**EN**
Five-door adverting — Formations aggregate (volition, first method) — 136

**VI**
Hướng ngũ môn — Hành uẩn (tám tâm sở, cách thứ hai) — 136

**EN**
Five-door adverting — Formations aggregate (eight mental factors, second method) — 136

**VI**
Hướng ngũ môn — Thức uẩn — 137

**EN**
Five-door adverting — Consciousness aggregate — 137

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn của nhãn thức, tức tâm thấy — 137

**EN**
Visual-object process — Five aggregates at eye-consciousness, the consciousness that sees — 137

**VI**
Nhãn thức — Sắc uẩn — 138

**EN**
Eye-consciousness — Materiality aggregate — 138

**VI**
Nhãn thức — Thọ uẩn — 138

**EN**
Eye-consciousness — Feeling aggregate — 138

**VI**
Tác ý dẫn đầu lộ tâm (vīthipaṭipādakamanasikāra) — 139

**EN**
Attention that leads the cognitive process (vīthipaṭipādakamanasikāra) — 139

**VI**
Ánh sáng — 140

**EN**
Light — 140

**VI**
Nhãn thức — Tưởng uẩn — 140

**EN**
Eye-consciousness — Perception aggregate — 140

**VI**
Nhãn thức — Hành uẩn — 141

**EN**
Eye-consciousness — Formations aggregate — 141

**VI**
Nhãn thức — Thức uẩn — 141

**EN**
Eye-consciousness — Consciousness aggregate — 141


<a id="M05-front-P007"></a>
## Mục lục — င / Table of contents — င
Đầu sách / Front matter - 7

**VI**
Đề mục — Trang

**EN**
Subject — Page

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm tiếp thâu — 142

**EN**
Visual-object process — Five aggregates at receiving — 142

**VI**
Tiếp thâu — Thọ uẩn — 142

**EN**
Receiving — Feeling aggregate — 142

**VI**
Tiếp thâu — Tưởng uẩn — 143

**EN**
Receiving — Perception aggregate — 143

**VI**
Tiếp thâu — Hành uẩn — 143

**EN**
Receiving — Formations aggregate — 143

**VI**
Tiếp thâu — Thức uẩn — 144

**EN**
Receiving — Consciousness aggregate — 144

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm suy đạc — 145

**EN**
Visual-object process — Five aggregates at investigating — 145

**VI**
Suy đạc — Thọ uẩn — 145

**EN**
Investigating — Feeling aggregate — 145

**VI**
Suy đạc — Tưởng uẩn — 146

**EN**
Investigating — Perception aggregate — 146

**VI**
Suy đạc — Hành uẩn — 147

**EN**
Investigating — Formations aggregate — 147

**VI**
Suy đạc — Thức uẩn — 148

**EN**
Investigating — Consciousness aggregate — 148

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm xác định — 148

**EN**
Visual-object process — Five aggregates at determining — 148

**VI**
Xác định — Thọ uẩn — 149

**EN**
Determining — Feeling aggregate — 149

**VI**
Xác định — Tưởng uẩn — 149

**EN**
Determining — Perception aggregate — 149

**VI**
Xác định — Hành uẩn — 150

**EN**
Determining — Formations aggregate — 150

**VI**
Xác định — Thức uẩn — 151

**EN**
Determining — Consciousness aggregate — 151

**VI**
Tác ý dẫn đầu tốc hành (javanapaṭipādakamanasikāra) — 151

**EN**
Attention that leads to impulsion (javanapaṭipādakamanasikāra) — 151

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn ở tốc hành thiện thứ nhất — 152

**EN**
Visual-object process — Five aggregates at the first wholesome impulsion — 152

**VI**
Tốc hành đại thiện thứ nhất — Thọ uẩn — 153

**EN**
First great wholesome impulsion — Feeling aggregate — 153

**VI**
Tốc hành đại thiện thứ nhất — Tưởng uẩn — 154

**EN**
First great wholesome impulsion — Perception aggregate — 154

**VI**
Tốc hành đại thiện thứ nhất — Hành uẩn — 154

**EN**
First great wholesome impulsion — Formations aggregate — 154

**VI**
Tốc hành đại thiện thứ nhất — Thức uẩn — 155

**EN**
First great wholesome impulsion — Consciousness aggregate — 155

**VI**
Tốc hành đại thiện thứ hai — Thọ uẩn — 157

**EN**
Second great wholesome impulsion — Feeling aggregate — 157

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn ở tâm đăng ký — 158

**EN**
Visual-object process — Five aggregates at registration — 158

**VI**
Tâm đăng ký đại quả thứ nhất — Thọ uẩn — 158

**EN**
First great-resultant registration — Feeling aggregate — 158

**VI**
Tâm đăng ký đại quả thứ nhất — Thức uẩn — 160

**EN**
First great-resultant registration — Consciousness aggregate — 160


<a id="M05-front-P008"></a>
## Mục lục — စ / Table of contents — စ
Đầu sách / Front matter - 8

**VI**
Đề mục — Trang

**EN**
Subject — Page

**VI**
Các lộ ý môn lấy cảnh sắc làm đối tượng — 161

**EN**
Mind-door processes taking a visual object — 161

**VI**
Hướng ý môn — Thọ uẩn — 162

**EN**
Mind-door adverting — Feeling aggregate — 162

**VI**
Tốc hành đại thiện thứ nhất — Thọ uẩn — 162

**EN**
First great wholesome impulsion — Feeling aggregate — 162

**VI**
Tốc hành đại thiện thứ hai — Thọ uẩn — 163

**EN**
Second great wholesome impulsion — Feeling aggregate — 163

**VI**
Giải thích về nhãn xúc và ý xúc — 164

**EN**
Explanation of eye-contact and mind-contact — 164

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn ở tốc hành tham hợp tà kiến — 167

**EN**
Visual-object process — Five aggregates at greed-rooted impulsion associated with wrong view — 167

**VI**
Tốc hành tham hợp tà kiến thứ nhất — Thọ uẩn và thức uẩn (lộ nhãn môn) — 168

**EN**
First greed-rooted impulsion associated with wrong view — Feeling and consciousness aggregates (eye-door process) — 168

**VI**
Tốc hành tham hợp tà kiến thứ hai — Thọ uẩn (lộ nhãn môn) — 169

**EN**
Second greed-rooted impulsion associated with wrong view — Feeling aggregate (eye-door process) — 169

**VI**
Tốc hành tham hợp tà kiến thứ hai — Thức uẩn (lộ nhãn môn) — 169

**EN**
Second greed-rooted impulsion associated with wrong view — Consciousness aggregate (eye-door process) — 169

**VI**
Điểm cần lưu ý — 170

**EN**
A point to note — 170

**VI**
Một số điểm thay đổi — 171

**EN**
Some differences — 171

**VI**
Lộ cảnh thinh, tức âm thanh — Hướng ngũ môn — Thọ uẩn — 171

**EN**
Sound-object process — Five-door adverting — Feeling aggregate — 171

**VI**
Lộ cảnh thinh, tức âm thanh — Nhĩ thức, tức tâm nghe — Thọ uẩn — 172

**EN**
Sound-object process — Ear-consciousness, the consciousness that hears — Feeling aggregate — 172

**VI**
Khoảng trống (ākāsa) — 173

**EN**
Space (ākāsa) — 173

**VI**
Lộ cảnh thinh, tức âm thanh — Tiếp thâu — Hành uẩn (cách thứ hai) — 173

**EN**
Sound-object process — Receiving — Formations aggregate (second method) — 173

**VI**
Lộ cảnh thinh, tức âm thanh — Tiếp thâu — Thức uẩn — 174

**EN**
Sound-object process — Receiving — Consciousness aggregate — 174

**VI**
Lộ cảnh thinh, tức âm thanh — Suy đạc — Thọ uẩn — 175

**EN**
Sound-object process — Investigating — Feeling aggregate — 175

**VI**
Lộ cảnh hương, tức mùi — Hướng ngũ môn — Thọ uẩn — 176

**EN**
Odour-object process — Five-door adverting — Feeling aggregate — 176

**VI**
Lộ cảnh hương, tức mùi — Tỷ thức — Thọ uẩn — 177

**EN**
Odour-object process — Nose-consciousness — Feeling aggregate — 177

**VI**
Giới gió — 178

**EN**
The wind element — 178

**VI**
Lộ cảnh hương, tức mùi — Tiếp thâu — Thọ uẩn — 178

**EN**
Odour-object process — Receiving — Feeling aggregate — 178

**VI**
Lộ cảnh hương, tức mùi — Suy đạc — Thọ uẩn — 179

**EN**
Odour-object process — Investigating — Feeling aggregate — 179

**VI**
Lộ cảnh vị — Hướng ngũ môn — Thọ uẩn — 180

**EN**
Taste-object process — Five-door adverting — Feeling aggregate — 180

**VI**
Lộ cảnh vị — Thiệt thức — Thọ uẩn — 180

**EN**
Taste-object process — Tongue-consciousness — Feeling aggregate — 180


<a id="M05-front-P009"></a>
## Mục lục — ဆ / Table of contents — ဆ
Đầu sách / Front matter - 9

**VI**
Đề mục — Trang

**EN**
Subject — Page

**VI**
Giới nước — 181

**EN**
The water element — 181

**VI**
Lộ cảnh vị — Tiếp thâu — Thọ uẩn — 181

**EN**
Taste-object process — Receiving — Feeling aggregate — 181

**VI**
Lộ cảnh vị — Suy đạc — Thọ uẩn — 182

**EN**
Taste-object process — Investigating — Feeling aggregate — 182

**VI**
Lộ cảnh xúc — Hướng ngũ môn — Thọ uẩn — 182

**EN**
Tangible-object process — Five-door adverting — Feeling aggregate — 182

**VI**
Lộ cảnh xúc — Thân thức — Thọ uẩn — 183

**EN**
Tangible-object process — Body-consciousness — Feeling aggregate — 183

**VI**
Giới đất — 183

**EN**
The earth element — 183

**VI**
Lộ cảnh xúc — Tiếp thâu — Thọ uẩn — 184

**EN**
Tangible-object process — Receiving — Feeling aggregate — 184

**VI**
Lộ cảnh xúc — Suy đạc — Thọ uẩn — 185

**EN**
Tangible-object process — Investigating — Feeling aggregate — 185

**VI**
Lộ cảnh pháp — Lộ tốc hành thiện lấy nhãn tịnh sắc làm cảnh — 185

**EN**
Mental-object process — Wholesome impulsions taking eye-sensitivity as object — 185

**VI**
Tốc hành thứ nhất — Thọ uẩn (lộ ý môn) — 185

**EN**
First impulsion — Feeling aggregate (mind-door process) — 185

**VI**
Tốc hành thứ hai — Thọ uẩn — 186

**EN**
Second impulsion — Feeling aggregate — 186

**VI**
Lộ cảnh pháp — Lộ chứng sơ thiền lấy tợ tướng hơi thở làm cảnh — 187

**EN**
Mental-object process — First-jhāna attainment taking the breath counterpart sign as object — 187

**VI**
Tốc hành thứ nhất — Thọ uẩn — 187

**EN**
First impulsion — Feeling aggregate — 187

**VI**
Lộ cảnh pháp — Sắc pháp làm cảnh — 188

**EN**
Mental-object process — Material phenomena as objects — 188

**VI**
Từng phần, từng trường hợp — 189

**EN**
Each case individually — 189

**VI**
Bên ngoài, nhiều đời quá khứ và nhiều đời vị lai — 190

**EN**
Externally, across successive past and future lives — 190

**VI**
Hạt giống hạnh và hạt giống minh — 191

**EN**
Seeds of conduct and seeds of knowledge — 191

**VI**
Nhân vô gián của hữu phần — 192

**EN**
Proximity causes of the life-continuum — 192

**VI**
Đạt đến tuệ liễu tri bằng nhận biết — 193

**EN**
Reaching full understanding as the known — 193

**VI**
Bén rễ đến mức không thể lìa Giáo pháp — 195

**EN**
Taking root so as to be unable to leave the Dispensation — 195

**VI**
Cách quán trong các oai nghi và khi tỉnh giác — 196

**EN**
Discernment in the postures and with clear comprehension — 196

**VI**
❂ ❂ ❂

**EN**
❂ ❂ ❂


<a id="M05-body-P001"></a>
## Phần 1. Lời tuyên bố trong Kinh Đại Duyên / Part 1. The declaration in the Mahānidāna Sutta
Miến / Burmese 1

**VI**
Nibbānagāminipaṭipadā — Đường đến Niết-bàn (bản lược), Cuốn 5. Phần Duyên khởi (Paṭiccasamuppāda) — A.

**EN**
Nibbānagāminipaṭipadā — The Practice Leading to Nibbāna (Abridged), Volume 5. Dependent Origination (Paṭiccasamuppāda) — A.

**VI**
Namo tassa bhagavato arahato sammāsambuddhassa.

**EN**
Namo tassa bhagavato arahato sammāsambuddhassa.

**VI**
Phần 1. Lời tuyên bố trong Kinh Đại Duyên (Mahānidānasutta).

**EN**
Part 1. The declaration in the Great Discourse on Causation (Mahānidānasutta).

**VI**
Thuở ấy Đức Phật trú tại xứ Kuru, lấy thị trấn Kammāsadhamma làm nơi khất thực. Hôm ấy, trước khi Đức Phật thuyết Kinh Đại Duyên, Tôn giả Ānanda đi đến chỗ nghỉ ban ngày, ngồi xuống và nhập quả định Nhập lưu. Khi thời gian đã định trôi qua, Tôn giả xuất khỏi quả định Nhập lưu và hướng tâm đến pháp Duyên khởi, còn gọi là các duyên (paccayākāra). Tôn giả Ānanda quán theo các cách sau:

**EN**
At that time the Buddha was staying in the country of the Kurus, relying on the town of Kammāsadhamma for alms. On the day the Buddha was to give the Great Discourse on Causation, Venerable Ānanda went to his daytime retreat, sat down, and entered the fruition attainment of stream-entry. When the time he had determined elapsed, he emerged from that attainment and directed his mind to dependent origination, also called the pattern of conditions (paccayākāra). Venerable Ānanda discerned it in the following ways:

**VI**
1. Từ vô minh đến già chết, theo chiều thuận của Duyên khởi (anuloma).
2. Từ già chết đến vô minh, theo chiều nghịch của Duyên khởi (paṭiloma).

**EN**
1. From ignorance to aging and death, in the forward order of dependent origination (anuloma).
2. From aging and death to ignorance, in the reverse order of dependent origination (paṭiloma).


<a id="M05-body-P002"></a>
## Bốn cách quán Duyên khởi và lời Tôn giả Ānanda / Four ways of discerning dependent origination and Ānanda’s statement
Miến / Burmese 2

**VI**
3. Từ hai đầu vào giữa, theo chiều thuận và nghịch của Duyên khởi.
4. Từ giữa ra hai đầu, theo chiều thuận và nghịch của Duyên khởi.

**EN**
3. From both ends toward the middle, in the forward and reverse orders of dependent origination.
4. From the middle toward both ends, in the forward and reverse orders of dependent origination.

**VI**
Tôn giả lần lượt tu tập minh sát trên từng chi trong mười hai chi Duyên khởi theo cả bốn cách ấy, như người ta vạch từng đường lên mặt đất. Khi Tôn giả Ānanda tu tập minh sát như vậy, mối liên hệ nhân quả của Duyên khởi, còn gọi là các duyên (paccayākāra), hiện rõ trong trí của Tôn giả.

**EN**
He developed insight into each of the twelve factors of dependent origination in turn, using all four methods, as one might trace lines on the ground. As Venerable Ānanda developed insight in this way, the relation between cause and effect in dependent origination, also called the pattern of conditions (paccayākāra), became clear to his knowledge.

**VI**
Tôn giả nghĩ rằng nếu đem điều này trình lên Đức Phật, mình có thể được nghe một bài pháp hay. Chiều hôm ấy, Tôn giả đến chỗ Đức Phật, đảnh lễ, ngồi sang một bên và thưa:

**EN**
He thought that if he presented this to the Buddha, he might hear a fine discourse. That evening he went to the Buddha, paid homage, sat to one side, and said:

**VI**
“Bạch Đức Thế Tôn, thật kỳ diệu! Bạch Đức Thế Tôn, thật chưa từng có! Pháp Duyên khởi này thật sâu xa và hiện ra sâu xa. Vậy mà đối với con, pháp ấy dường như hết sức dễ hiểu, bạch Đức Thế Tôn.”

**EN**
“It is wonderful, venerable sir! It is astonishing, venerable sir! This dependent origination is very deep and appears deep, yet to me it seems quite plain, venerable sir.”

**VI**
Khi ấy Đức Phật thuyết Kinh Đại Duyên cho Tôn giả Ānanda. Sau đây là đoạn trích từ kinh ấy.

**EN**
The Buddha then taught the Great Discourse on Causation to Venerable Ānanda. The following passage is an excerpt from that discourse.


<a id="M05-body-P003"></a>
## Duyên khởi sâu xa và ba loại liễu tri / The depth of dependent origination and the three kinds of full understanding
Miến / Burmese 3

**VI**
Mā hevaṃ, Ānanda, avaca, mā hevaṃ, Ānanda, avaca. Gambhīro cāyaṃ, Ānanda, paṭiccasamuppādo gambhīrāvabhāso ca. Etassa, Ānanda, dhammassa ananubodhā appaṭivedhā evamayaṃ pajā tantākulakajātā kulagaṇṭhikajātā muñjapabbajabhūtā apāyaṃ duggatiṃ vinipātaṃ saṃsāraṃ nātivattati. (Dīgha, tập 2, tr. 47.)

**EN**
Mā hevaṃ, Ānanda, avaca, mā hevaṃ, Ānanda, avaca. Gambhīro cāyaṃ, Ānanda, paṭiccasamuppādo gambhīrāvabhāso ca. Etassa, Ānanda, dhammassa ananubodhā appaṭivedhā evamayaṃ pajā tantākulakajātā kulagaṇṭhikajātā muñjapabbajabhūtā apāyaṃ duggatiṃ vinipātaṃ saṃsāraṃ nātivattati. (Dīgha, vol. 2, p. 47.)

**VI**
Ananubodhāti ñātapariññāvasena ananubujjhanā. Appaṭivedhāti tīraṇapahānapariññāvasena appaṭivijjhanā. (Chú giải Dīgha, tập 2, tr. 85.)

**EN**
Ananubodhāti ñātapariññāvasena ananubujjhanā. Appaṭivedhāti tīraṇapahānapariññāvasena appaṭivijjhanā. (Dīgha Commentary, vol. 2, p. 85.)

**VI**
“Này Ānanda, chớ nói như vậy. Này Ānanda, chớ nói như vậy. Mối liên hệ nhân quả này, tức pháp Duyên khởi, thật sâu xa. Vì sâu xa nên pháp ấy cũng hiện ra sâu xa.”

**EN**
“Ānanda, do not say so. Ānanda, do not say so. This relation of cause and effect, the teaching of dependent origination, is deep. Because it is deep, it also appears deep.”

**VI**
“Này Ānanda, vì không hiểu và không thấu triệt mối liên hệ nhân quả ấy bằng ba loại tuệ liễu tri là liễu tri bằng nhận biết (ñātapariññā), liễu tri bằng thẩm sát (tīraṇapariññā) và liễu tri bằng đoạn trừ (pahānapariññā), chúng sinh trong cuộc luân hồi dài lâu này rối như cuộn chỉ, thắt nút như một búi sợi, đan chằng chịt như cỏ muñja và pabbaja. Họ không thể vượt qua vòng luân hồi nơi các cõi khổ, ác thú và đọa xứ, là chỗ đến của người làm ác, nơi thiếu sự an vui và chịu suy tổn. Họ cũng không thể vượt qua vòng luân hồi ở các thiện thú ngoài những cõi khổ ấy.” (Dīgha, tập 2, tr. 47.)

**EN**
“Ānanda, because beings have not understood and penetrated that relation of cause and effect by the three kinds of full understanding—full understanding as knowing (ñātapariññā), as investigation (tīraṇapariññā), and as abandoning (pahānapariññā)—in this long round of rebirths they are tangled like a skein of thread, knotted like a bundle of fibres, and matted like muñja and pabbaja grasses. They cannot pass beyond the round of rebirths in the realms of misery, bad destinations, and states of downfall, where wrongdoers go, deprived of well-being and subject to ruin. They cannot pass beyond the round of rebirths in the good destinations outside those realms of misery either.” (Dīgha, vol. 2, p. 47.)

**VI**
Dựa vào lời dạy trên, các vị chú giải sư lại đưa ra nhận định như sau.

**EN**
Drawing on the teaching above, the commentators then make the following determination.


<a id="M05-body-P004"></a>
## Phá vỡ bánh xe hữu bằng lưỡi gươm trí tuệ / Breaking the wheel of becoming with the sword of knowledge
Miến / Burmese 4

**VI**
Ñāṇāsinā samādhipavarasilāya sunisitena —
Bhavacakkamapadāletvā, asanivicakkamiva niccanimmathaṃ.
Saṃsārabhayamatīto, na koci supinantarepyatthi.
(Chú giải Abhidhamma, tập 2, tr. 189. Thanh tịnh đạo, tập 2, tr. 221.)

**EN**
Ñāṇāsinā samādhipavarasilāya sunisitena —
Bhavacakkamapadāletvā, asanivicakkamiva niccanimmathaṃ.
Saṃsārabhayamatīto, na koci supinantarepyatthi.
(Abhidhamma Commentary, vol. 2, p. 189. Visuddhimagga, vol. 2, p. 221.)

**VI**
Lưỡi gươm trí tuệ được mài sắc trên đá mài quý là định. Bánh xe hữu, tức mối liên hệ nhân quả của Duyên khởi trong luân hồi, không ngừng nghiền ép và hành hạ chúng sinh như một bánh xe sấm sét. Nếu chưa dùng lưỡi gươm ấy phá vỡ bánh xe hữu thì chưa từng có ai vượt qua được hiểm họa lớn của khổ luân hồi, dù chỉ trong giấc mộng. (Chú giải Abhidhamma, tập 2, tr. 189. Thanh tịnh đạo, tập 2, tr. 221.)

**EN**
The sword of knowledge is honed on the excellent whetstone of concentration. The wheel of becoming, the causal connection of dependent origination within saṃsāra, continually grinds down and oppresses beings like a wheel of thunderbolts. Without breaking that wheel with this sword, no one has ever passed beyond the great danger of suffering in saṃsāra, even in a dream. (Abhidhamma Commentary, vol. 2, p. 189. Visuddhimagga, vol. 2, p. 221.)

**VI**
Theo câu Pāli và lời chú giải trên, thiện nhân mong cầu Chân pháp, mong đạt pháp cao quý là sự an lạc Niết-bàn, phải nỗ lực biết rõ mối liên hệ nhân quả của Duyên khởi bằng ba loại tuệ liễu tri: liễu tri bằng nhận biết (ñātapariññā), gọi là hiểu theo (anubodha), và liễu tri bằng thẩm sát (tīraṇapariññā) cùng liễu tri bằng đoạn trừ (pahānapariññā), gọi là thấu triệt (paṭivedha). Chính Đức Phật đã dạy rằng vì chưa nhiều lần biết rõ bằng sự hiểu theo, và chưa tự mình xuyên thấu bằng sự thấu triệt cho đến sát-na đạo và quả, nên chúng sinh chưa vượt thoát luân hồi. Vì vậy, muốn thoát luân hồi, phải nỗ lực để biết sâu bằng cả sự hiểu theo lẫn sự thấu triệt. Đây là việc cần gắng sức để tự mình biết rõ. Chỉ dựa vào lời thầy rồi lần mò thì…

**EN**
In accordance with the Pāli and the commentary above, a good person who seeks the true Dhamma and aspires to the sublime peace of Nibbāna must strive to know the causal connection of dependent origination clearly through three kinds of full understanding: full understanding as knowing (ñātapariññā), called understanding (anubodha), and full understanding as investigation (tīraṇapariññā) and as abandoning (pahānapariññā), called penetration (paṭivedha). The Buddha himself taught that beings have yet to pass beyond saṃsāra because they have not repeatedly known it through understanding and have not personally penetrated it through to the moments of path and fruition. Those who wish to escape saṃsāra must therefore strive for deep knowledge through both understanding and penetration. This is a task that calls for effort to know it for oneself. As for feeling one’s way guided solely by a teacher’s words…


<a id="M05-body-P005"></a>
## Vì sao Duyên khởi hiện rõ đối với Tôn giả Ānanda? / Why dependent origination appeared plain to Venerable Ānanda
Miến / Burmese 5

**VI**
…hãy hiểu rằng việc này không thể thành tựu theo cách ấy.

**EN**
…understand that this task cannot be accomplished in that way.

**VI**
Thế nào là bậc Nhập lưu?

**EN**
What is a stream-enterer?

**VI**
Mối liên hệ nhân quả của Duyên khởi sâu xa, hiện ra sâu xa, khó hiểu và có vẻ khó hiểu. Vậy do đâu pháp ấy hiện ra trong trí Tôn giả Ānanda “dễ hiểu như thể nông cạn”? Câu trả lời như sau.

**EN**
The causal connection of dependent origination is deep and appears deep, difficult and appears difficult. Why, then, did it appear to Venerable Ānanda’s knowledge to be “easy to understand, as though shallow”? The answer is as follows.

**VI**
Therassa hi catūhi kāraṇehi gambhīropi paṭiccasamuppādo uttānoti upaṭṭhāsi. Katamehi catūhi? Pubbūpanissayasampattiyā, titthavāsena, sotāpannatāya, bahussutabhāvenāti. (Chú giải Dīgha, tập 2, tr. 78.)

**EN**
Therassa hi catūhi kāraṇehi gambhīropi paṭiccasamuppādo uttānoti upaṭṭhāsi. Katamehi catūhi? Pubbūpanissayasampattiyā, titthavāsena, sotāpannatāya, bahussutabhāvenāti. (Dīgha Commentary, vol. 2, p. 78.)

**VI**
Do bốn duyên sau, mối liên hệ nhân quả của Duyên khởi, dù sâu xa và khó hiểu, đã hiện rõ trong trí Tôn giả Ānanda:
1. Pubbūpanissayasampatti — có đầy đủ các ba-la-mật đã vun bồi trong những đời trước.
2. Titthavāsa — thường xuyên nương gần những bến lành trong giáo pháp.
3. Sotāpannatā — đã thành tựu Nhập lưu.
4. Bahussutabhāva — đã nghe học nhiều.

**EN**
For the following four reasons, the causal connection of dependent origination, though deep and difficult, appeared clear to Venerable Ānanda’s knowledge:
1. Pubbūpanissayasampatti — possessing the perfections cultivated in former lives.
2. Titthavāsa — continually living near the good fords in the dispensation.
3. Sotāpannatā — having become a stream-enterer.
4. Bahussutabhāva — being learned in the teachings.

**VI**
Chính do bốn duyên này mà mối liên hệ nhân quả của Duyên khởi, vốn sâu xa và khó hiểu…

**EN**
It was owing to these four conditions that the causal connection of dependent origination, deep and difficult as it is…


<a id="M05-body-P006"></a>
## Các trợ duyên đời trước và sự nương nơi bến lành / Former supporting conditions and living near a good ford
Miến / Burmese 6

**VI**
…hiện rõ trong trí Tôn giả Ānanda.

**EN**
…appeared clearly to Venerable Ānanda’s knowledge.

**VI**
1. Pubbūpanissayasampatti. Trong giáo pháp của Đức Phật Padumuttara, Tôn giả Ānanda đã phát nguyện và vun bồi ba-la-mật trong một trăm nghìn kiếp để đạt địa vị bậc nhất trong năm phương diện. Tất cả các ba-la-mật đã tích lũy qua nhiều đời, hướng đến tuệ giác của một vị đại đệ tử có thể đạt năm địa vị bậc nhất, nay đã đầy đủ trong dòng tương tục của Tôn giả. Đây là một duyên.

**EN**
1. Pubbūpanissayasampatti. In the dispensation of Buddha Padumuttara, Venerable Ānanda made an aspiration and cultivated the perfections for a hundred thousand aeons in order to attain foremost rank in five respects. All the perfections accumulated through many lives for the great disciple’s awakening that would enable him to hold these five foremost ranks were now fulfilled in his continuity. This is one condition.

**VI**
2. Titthavāsa. Những bến lành để đi đến Niết-bàn được gọi là tittha. Đức Phật Chánh Đẳng Giác và các vị đại đệ tử bậc nhất có thể chỉ dẫn đúng đắn con đường đi đến Niết-bàn trong giáo pháp, nên các Ngài được gọi bằng tên tittha vì giống như những bến tốt để sang bờ bên kia, tức Niết-bàn. Sống gần và nương tựa những bậc thầy như thế gọi là titthavāsa. Tôn giả Ānanda cũng đầy đủ phẩm chất này.

**EN**
2. Titthavāsa. Good fords on the way to Nibbāna are called tittha. The Perfectly Awakened Buddha and his foremost great disciples can correctly show the way to Nibbāna within the dispensation. They are called tittha because they are like good fords for crossing to the farther shore, Nibbāna. Living near and relying on such teachers is called titthavāsa. Venerable Ānanda possessed this quality too.

**VI**
Dù ở gần Đức Phật hay ở gần các đại đệ tử bậc nhất như Tôn giả Sāriputta, Mahāmoggallāna, Mahākoṭṭhita và Mahāpanthaka, Tôn giả Ānanda thực hành các việc sau trước những bậc thầy cao quý ấy:
(a) Uggaha — học văn bản Pāli.
(b) Savana — nghe giải nghĩa văn bản Pāli, tức nghe chú giải (atthakathā hoặc aṭṭhakathā).

**EN**
Whether with the Buddha or with foremost great disciples such as Venerable Sāriputta, Mahāmoggallāna, Mahākoṭṭhita, and Mahāpanthaka, Venerable Ānanda practised the following in the presence of those eminent teachers:
(a) Uggaha — learning the Pāli text.
(b) Savana — listening to its meaning, that is, to the commentary (atthakathā or aṭṭhakathā).


<a id="M05-body-P007"></a>
## Học pháp nơi bậc thầy và thành tựu Nhập lưu / Learning from teachers and attaining stream-entry
Miến / Burmese 7

**VI**
(c) Paripucchā — hỏi thêm về ý nghĩa và chú giải của những điểm sâu xa, khó hiểu.
(d) Dhāraṇā — ghi nhớ văn bản Pāli cũng như ý nghĩa trong chú giải, giữ thuộc lòng.

**EN**
(c) Paripucchā — asking further about the meaning and commentary on profound and difficult points.
(d) Dhāraṇā — retaining both the Pāli text and its meaning in the commentary, keeping them in memory.

**VI**
Như vậy, Tôn giả đã học có hệ thống các bản Pāli và chú giải về Duyên khởi, ghi nhớ đến mức thuộc lòng. Cũng vì duyên này, pháp Duyên khởi, dù sâu xa và khó hiểu, đã hiện rõ trong trí Tôn giả Ānanda như một điều dễ hiểu. (Chú giải Dīgha, tập 2, tr. 83.)

**EN**
In this way he systematically learned the Pāli and commentaries on dependent origination and retained them in memory. For this reason too, dependent origination, though deep and difficult, appeared plainly to Venerable Ānanda’s knowledge as something easy to understand. (Dīgha Commentary, vol. 2, p. 83.)

**VI**
3. Sotāpannatā — sự thành tựu Nhập lưu.

**EN**
3. Sotāpannatā — having become a stream-enterer.

**VI**
Sotāpannānañca nāma paccayākāro uttānakova hutvā upaṭṭhāti. Ayañca āyasmā sotāpanno. (Chú giải Dīgha, tập 2, tr. 83.)

**EN**
Sotāpannānañca nāma paccayākāro uttānakova hutvā upaṭṭhāti. Ayañca āyasmā sotāpanno. (Dīgha Commentary, vol. 2, p. 83.)

**VI**
Sotāpannānañca … pe … upaṭṭhāti tattha sammohaviddhaṃsanena. “Yaṃ kiñci samudayadhammaṃ, sabbaṃ taṃ nirodhadhamman”ti attapaccakkhavasena upaṭṭhānato. (Phụ chú giải Dīgha, tập 2, tr. 84.)

**EN**
Sotāpannānañca … pe … upaṭṭhāti tattha sammohaviddhaṃsanena. “Yaṃ kiñci samudayadhammaṃ, sabbaṃ taṃ nirodhadhamman”ti attapaccakkhavasena upaṭṭhānato. (Dīgha Subcommentary, vol. 2, p. 84.)

**VI**
Mối liên hệ nhân quả của Duyên khởi, còn gọi là các duyên (paccayākāra), hiện rõ trong dòng tương tục của một bậc Nhập lưu chân thật. Bởi đạo Nhập lưu đã phá tan si mê che lấp sự thấy biết mối liên hệ nhân quả gọi là sự thật về nguồn gốc khổ, nên vị ấy tự mình trực chứng rằng: “Bất cứ pháp nào có tính sinh khởi, tất cả đều có tính đoạn diệt.” Do vậy, trong trí vị ấy…

**EN**
The causal connection of dependent origination, also called the pattern of conditions (paccayākāra), appears clearly in the continuity of a genuine stream-enterer. The path of stream-entry has dispelled the delusion that conceals knowledge of the causal connection called the truth of origin, so that one has directly realized for oneself: “Whatever is subject to arising is all subject to cessation.” Thus, in that person’s knowledge…


<a id="M05-body-P008"></a>
## Tự mình thấy mối liên hệ nhân quả / Seeing the causal connection for oneself
Miến / Burmese 8

**VI**
…mối liên hệ ấy hiện rõ. Tôn giả Ānanda đã thành tựu Nhập lưu. Do đó, mối liên hệ nhân quả của Duyên khởi hiện rõ trong trí Tôn giả.

**EN**
…that connection is clear. Venerable Ānanda had attained stream-entry. Thus the causal connection of dependent origination appeared clearly in his knowledge.

**VI**
Nếu một thiện nhân tự cho mình là bậc Nhập lưu, hãy tự xét xem mình đã trực tiếp thấu suốt mối liên hệ nhân quả của Duyên khởi bằng trí chánh kiến hay chưa. Hãy tự hỏi như sau.

**EN**
If a good person thinks they are a stream-enterer, let them examine whether they have directly penetrated the causal connection of dependent origination with the knowledge of right view. Let them ask themselves as follows.

**VI**
Do các nhân đã vun bồi trong quá khứ là vô minh, ái, thủ, hành và nghiệp, các quả hiện tại là thức, danh sắc, sáu xứ, xúc và thọ hiện khởi như thế nào? Do vô minh, ái, thủ, hành và nghiệp được vun bồi trong hiện tại, các quả là thức, danh sắc, sáu xứ, xúc và thọ sẽ hiện khởi trong tương lai như thế nào?

**EN**
How do the present results—consciousness, mentality-materiality, the six bases, contact, and feeling—arise due to the causes cultivated in the past, namely ignorance, craving, clinging, formations, and kamma? How will the results—consciousness, mentality-materiality, the six bases, contact, and feeling—arise in the future due to ignorance, craving, clinging, formations, and kamma cultivated in the present?

**VI**
Hãy tự hỏi xem mình đã trực tiếp thấu suốt những điều ấy bằng trí chánh kiến chưa. Nếu vẫn chỉ dò theo lời thầy, câu trả lời đã rõ. Hãy tự kết luận rằng mình chưa phải là bậc Nhập lưu chân thật mà Đức Phật nói đến. Vì các bậc thánh là những đệ tử chân thật của Đức Phật đã tự mình trực tiếp thấu suốt mối liên hệ nhân quả của Duyên khởi bằng trí chánh kiến.

**EN**
Ask whether you have directly penetrated these matters with the knowledge of right view. If you are still merely feeling your way by a teacher’s words, the answer is already clear. Conclude for yourself that you have yet to become a genuine stream-enterer of the kind the Buddha described. For the noble ones, the Buddha’s true disciples, have directly penetrated the causal connection of dependent origination for themselves with the knowledge of right view.

**VI**
4. Bahussutabhāva — sự đa văn.

**EN**
4. Bahussutabhāva — being learned.

**VI**
Bahussutānañca catuhatthe ovarake padīpe jalamāne mañcapīṭha…

**EN**
Bahussutānañca catuhatthe ovarake padīpe jalamāne mañcapīṭha…


<a id="M05-body-P009"></a>
## Sự đa văn và trí phân định danh sắc / Learning and the knowledge that distinguishes mentality and materiality
Miến / Burmese 9

**VI**
…viya nāmarūpaparicchedo pākaṭo hoti. Ayañca āyasmā bahussutānaṃ aggo hoti. Bahussutānubhāvenapissa gambhīropi paccayākāro uttānako viya upaṭṭhāsi. (Chú giải Dīgha, tập 2, tr. 83.)

**EN**
…viya nāmarūpaparicchedo pākaṭo hoti. Ayañca āyasmā bahussutānaṃ aggo hoti. Bahussutānubhāvenapissa gambhīropi paccayākāro uttānako viya upaṭṭhāsi. (Dīgha Commentary, vol. 2, p. 83.)

**VI**
Nāmarūpaparicchedoti saha paccayena nāmarūpassa paricchijja avabodho. (Phụ chú giải Dīgha, tập 2, tr. 84.)

**EN**
Nāmarūpaparicchedoti saha paccayena nāmarūpassa paricchijja avabodho. (Dīgha Subcommentary, vol. 2, p. 84.)

**VI**
Khi thắp đèn trong căn phòng rộng bốn khuỷu tay, giường và ghế trong phòng hiện ra rõ ràng. Cũng vậy, trong trí người đa văn, sự phân định rành rẽ danh sắc cùng các duyên, tức trí phân định danh sắc và trí nắm bắt các duyên, hiện ra rõ ràng. Tôn giả Ānanda lại là vị đứng đầu trong các vị tỳ-khưu đa văn. Do sức của sự đa văn ấy, mối liên hệ nhân quả của Duyên khởi, dù sâu xa và khó hiểu, hiện rõ trong trí Tôn giả như một điều dễ hiểu. (Chú giải Dīgha, tập 2, tr. 83. Phụ chú giải Dīgha, tập 2, tr. 84.)

**EN**
When a lamp is lit in a room four cubits across, the bed and seat in the room can be seen clearly. Likewise, to a learned person the clear distinction of mentality and materiality together with their conditions becomes evident, through the knowledge that distinguishes mentality and materiality and the knowledge that discerns conditions. Venerable Ānanda was foremost among the learned bhikkhus. Through the power of that learning, the causal connection of dependent origination, deep and difficult though it is, appeared plainly to his knowledge as something easy to understand. (Dīgha Commentary, vol. 2, p. 83. Dīgha Subcommentary, vol. 2, p. 84.)

**VI**
Thế nào là người đa văn?

**EN**
What is a learned person?

**VI**
Katamañca, bhikkhave, sutadhanaṃ? Idha, bhikkhave, ariyasāvako bahussuto hoti sutadharo sutasannicayo. Ye te dhammā ādikalyāṇā majjhekalyāṇā pariyosānakalyāṇā sātthaṃ sabyañjanaṃ kevalaparipuṇṇaṃ parisuddhaṃ brahmacariyaṃ abhivadanti, tathārūpāssa dhammā bahussutā honti dhātā vacasā paricitā manasānupekkhitā…

**EN**
Katamañca, bhikkhave, sutadhanaṃ? Idha, bhikkhave, ariyasāvako bahussuto hoti sutadharo sutasannicayo. Ye te dhammā ādikalyāṇā majjhekalyāṇā pariyosānakalyāṇā sātthaṃ sabyañjanaṃ kevalaparipuṇṇaṃ parisuddhaṃ brahmacariyaṃ abhivadanti, tathārūpāssa dhammā bahussutā honti dhātā vacasā paricitā manasānupekkhitā…


<a id="M05-body-P010"></a>
## Tài sản nghe học / The wealth of learning
Miến / Burmese 10

**VI**
…diṭṭhiyā suppaṭividdhā. Idaṃ vuccati, bhikkhave, sutadhanaṃ. (Aṅguttara, tập 2, tr. 399.)

**EN**
…diṭṭhiyā suppaṭividdhā. Idaṃ vuccati, bhikkhave, sutadhanaṃ. (Aṅguttara, vol. 2, p. 399.)

**VI**
Diṭṭhiyā suppaṭividdhāti atthato ca kāraṇato ca paññāya suṭṭhu paṭividdhā, paccakkhaṃ katā. (Chú giải Aṅguttara, tập 2, tr. 364.)

**EN**
Diṭṭhiyā suppaṭividdhāti atthato ca kāraṇato ca paññāya suṭṭhu paṭividdhā, paccakkhaṃ katā. (Aṅguttara Commentary, vol. 2, p. 364.)

**VI**
Suppaṭividdhāti nijjaṭaṃ niggumbaṃ katvā suṭṭhu yāthāvato paṭividdhā. (Phụ chú giải Aṅguttara, tập 2, tr. 362.)

**EN**
Suppaṭividdhāti nijjaṭaṃ niggumbaṃ katvā suṭṭhu yāthāvato paṭividdhā. (Aṅguttara Subcommentary, vol. 2, p. 362.)

**VI**
“Này các tỳ-khưu, thế nào là tài sản nghe học?”

**EN**
“Bhikkhus, what is the wealth of learning?”

**VI**
“Này các tỳ-khưu, ở đây, vị thánh đệ tử trong giáo pháp này, tức đệ tử của Ta, bậc đã thành tựu thánh quả, đã nghe học nhiều, ghi nhớ và tích lũy những điều đã nghe. Vị ấy nghe học nhiều những lời dạy tốt đẹp ở đầu, với sự thực hành giới, tốt đẹp ở giữa, với sự thực hành định, và tốt đẹp ở cuối, với sự thực hành tuệ. Những lời dạy ấy trình bày đời sống phạm hạnh đầy đủ cả nghĩa lẫn lời, hoàn toàn viên mãn và thanh tịnh, tức sự thực hành giới, định, tuệ trong giáo pháp, hay sự thực hành thánh đạo gồm tám chi. Vị ấy ghi nhớ các lời dạy ấy, quen thuộc qua việc tụng đọc, suy xét ý nghĩa trong tâm, và tự mình trực tiếp thấu suốt đúng như thật bằng tuệ chánh kiến, cả về ý nghĩa lẫn nguyên do. Này các tỳ-khưu, đó gọi là tài sản nghe học.” (Aṅguttara, tập 2, tr. 399.)

**EN**
“Bhikkhus, here a noble disciple in this dispensation, a disciple of mine who has become noble, has heard much, retains what has been heard, and accumulates it. The disciple has heard many teachings good in the beginning through the practice of virtue, good in the middle through the practice of concentration, and good in the end through the practice of wisdom. Those teachings set forth the holy life complete in meaning and expression, wholly fulfilled and pure: the practice of virtue, concentration, and wisdom in the dispensation, or the practice of the noble eightfold path. The disciple retains these teachings, grows familiar with them through recitation, considers their meaning in the mind, and personally penetrates them directly as they really are with the wisdom of right view, both in meaning and in reason. Bhikkhus, this is called the wealth of learning.” (Aṅguttara, vol. 2, p. 399.)

**VI**
Theo những lời dạy ấy, một thiện nhân đa văn có cả sự học từ truyền thừa (āgamasuta) lẫn sự học do chứng nghiệm (adhigamasuta), tức có cả điều đã nghe lẫn điều đã trực thấy. Vị ấy đã có trí phân định danh sắc và trí…

**EN**
According to these teachings, a learned good person has both learning received through transmission (āgamasuta) and learning through attainment (adhigamasuta), encompassing what has been heard and what has been directly seen. Such a person already has the knowledge that distinguishes mentality and materiality and the knowledge…


<a id="M05-body-P011"></a>
## Trí nắm bắt các duyên và ba loại liễu tri hiệp thế / Knowledge that discerns conditions and the three kinds of mundane full understanding
Miến / Burmese 11

**VI**
…nắm bắt các duyên. Người đa văn đã tự mình trực tiếp thấu suốt các sắc pháp và danh pháp thuộc năm thủ uẩn, gọi là khổ đế, bằng trí chánh kiến đến mức thấy chúng là pháp chân đế. Vị ấy cũng đã tự mình trực tiếp thấu suốt các nhân gọi là tập đế bằng trí chánh kiến. Vì vậy, trong dòng tương tục của vị ấy, mối liên hệ nhân quả của Duyên khởi hiện rõ.

**EN**
…that discerns conditions. A learned person has personally penetrated with the knowledge of right view the material and mental phenomena belonging to the five aggregates subject to clinging, called the truth of suffering, to the point of seeing them as ultimate realities. Such a person has also personally penetrated with the knowledge of right view the causes called the truth of origin. Thus the causal connection of dependent origination appears clearly in that person's continuity.

**VI**
Vì vậy, để trở thành một bậc thánh như bậc Nhập lưu và để vượt thoát khổ luân hồi, thiện nhân cần nỗ lực tự mình trực tiếp thấu suốt mối liên hệ nhân quả của Duyên khởi bằng trí chánh kiến. Cần cố gắng biết rõ pháp ấy bằng cả ba loại tuệ liễu tri. Có hai nhóm liễu tri, hiệp thế và siêu thế. Có ba loại liễu tri hiệp thế và ba loại liễu tri siêu thế.

**EN**
Therefore, to become a noble person such as a stream-enterer and to pass beyond the suffering of saṃsāra, a good person should strive to penetrate the causal connection of dependent origination directly with the knowledge of right view. One should endeavour to know it clearly through all three kinds of full understanding. Full understanding is of two classes, mundane and supramundane. There are three kinds of mundane and three kinds of supramundane full understanding.

**VI**
Ba loại liễu tri hiệp thế

**EN**
Three kinds of mundane full understanding

**VI**
1. Liễu tri bằng nhận biết (ñātapariññā). Nếu hành giả có thể dùng trí để phân định và quán đặc tính, phận sự, sự hiện khởi và nhân gần của từng chi Duyên khởi—vô minh, hành, thức, danh sắc, sáu xứ, xúc, thọ, ái, thủ, hữu, sinh, già chết—thì trí ấy là trí phân định danh sắc.

**EN**
1. Full understanding as knowing (ñātapariññā). If a meditator can distinguish and apprehend with knowledge the characteristic, function, manifestation, and proximate cause of each factor of dependent origination—ignorance, formations, consciousness, mentality-materiality, the six bases, contact, feeling, craving, clinging, becoming, birth, and aging and death—that knowledge distinguishes mentality and materiality.


<a id="M05-body-P012"></a>
## Liễu tri bằng nhận biết, thẩm sát và đoạn trừ / Full understanding as knowing, investigation, and abandoning
Miến / Burmese 12

**VI**
Khi tự mình trực tiếp thấu suốt mối liên hệ nhân quả như do vô minh có hành, do hành có thức, do thức có danh sắc, trí ấy là trí nắm bắt các duyên. Trí phân định danh sắc và trí nắm bắt các duyên, cả hai gọi là liễu tri bằng nhận biết (ñātapariññā). Chúng giúp biết rõ và phân biệt minh bạch các pháp hành sẽ làm cảnh cho tuệ minh sát. Vì vậy gọi là liễu tri bằng nhận biết.

**EN**
When one personally penetrates causal connections such as formations arising due to ignorance, consciousness due to formations, and mentality-materiality due to consciousness, that knowledge discerns conditions. The knowledge that distinguishes mentality and materiality and the knowledge that discerns conditions are both called full understanding as knowing (ñātapariññā). They make it possible to know and clearly distinguish the formations that will become the objects of insight knowledge. Hence the name full understanding as knowing.

**VI**
2. Liễu tri bằng thẩm sát (tīraṇapariññā). Khi quán bằng trí tướng vô thường, tướng khổ và tướng vô ngã của mười hai chi Duyên khởi như vô minh và hành, hai trí là tuệ thẩm sát (sammasanañāṇa) và tuệ sinh diệt (udayabbayañāṇa), có khả năng phân định các tướng ấy, được gọi là liễu tri bằng thẩm sát. Chúng thẩm sát và phân định các chi Duyên khởi theo tướng vô thường, khổ và vô ngã.

**EN**
2. Full understanding as investigation (tīraṇapariññā). When one discerns with wisdom the characteristics of impermanence, suffering, and non-self in the twelve factors of dependent origination, beginning with ignorance and formations, the two knowledges capable of determining these characteristics are comprehension knowledge (sammasanañāṇa) and knowledge of arising and passing away (udayabbayañāṇa). They are called full understanding as investigation. They investigate and determine the factors of dependent origination in terms of impermanence, suffering, and non-self.

**VI**
3. Liễu tri bằng đoạn trừ (pahānapariññā). Khi quán bằng trí mặt hoại diệt của các chi Duyên khởi, các tuệ minh sát từ tuệ hoại diệt (bhaṅgañāṇa) trở lên đoạn trừ bằng sức đối trị từng phần những phiền não có thể được đoạn trừ theo cách ấy, đồng thời thấy rõ các chi Duyên khởi đã được biết theo các tướng vô thường, khổ và vô ngã. Vì vậy gọi là liễu tri bằng đoạn trừ. Trên đây là ba loại liễu tri hiệp thế.

**EN**
3. Full understanding as abandoning (pahānapariññā). When one discerns with wisdom the dissolution of the factors of dependent origination, the insight knowledges beginning with knowledge of dissolution (bhaṅgañāṇa) abandon by momentary opposition the defilements that can be abandoned in that way. At the same time they clearly see the known factors of dependent origination in terms of impermanence, suffering, and non-self. Hence the name full understanding as abandoning. These are the three kinds of mundane full understanding.


<a id="M05-body-P013"></a>
## Ba loại liễu tri siêu thế / Three kinds of supramundane full understanding
Miến / Burmese 13

**VI**
Ba loại liễu tri siêu thế

**EN**
Three kinds of supramundane full understanding

**VI**
1. Ở chặng cuối của các tuệ minh sát, tức các tuệ liễu tri hiệp thế, Thánh đạo lấy Niết-bàn làm cảnh và sinh khởi. Thánh đạo nhổ tận gốc các phiền não có thể đoạn trừ ở tầng đạo ấy, đồng thời thấu suốt rõ ràng Niết-bàn, chân lý cần được chứng biết. Vì vậy, trước hết Thánh đạo được gọi là liễu tri bằng đoạn trừ (pahānapariññā).

**EN**
1. At the culmination of the insight knowledges, that is, the kinds of mundane full understanding, the noble path arises with Nibbāna as its object. The path eradicates the defilements that can be abandoned at that stage and clearly penetrates Nibbāna, the truth to be realized. Thus the noble path is first called full understanding as abandoning (pahānapariññā).

**VI**
2. Bằng sự thấu triệt đối tượng (ārammaṇapaṭivedha), Thánh đạo trực tiếp thấu suốt chân lý cần được chứng biết là Niết-bàn. Đồng thời, Thánh đạo nhổ tận gốc si mê che lấp sự biết rõ bốn Thánh đế. Do si mê che lấp đã bị nhổ tận gốc, sự biết bốn đế được hoàn tất ngay cùng lúc. Biết các Thánh đế theo phận sự như vậy gọi là thấu triệt bằng cách hết mê mờ (asammohapaṭivedha). Ở đây Thánh đạo biết diệt đế bằng sự thấu triệt đối tượng, và biết khổ đế, tập đế, đạo đế bằng sự thấu triệt do hết mê mờ. Như vậy Thánh đạo hoàn tất việc biết các chi Duyên khởi thuộc khổ đế và mối liên hệ nhân quả của các chi ấy thuộc tập đế. Vì phận sự này, Thánh đạo cũng được gọi là liễu tri bằng nhận biết (ñātapariññā).

**EN**
2. By penetration of the object (ārammaṇapaṭivedha), the noble path directly penetrates the truth to be realized, Nibbāna. At the same time, it eradicates the delusion that obscures clear knowledge of the four noble truths. Once this obscuring delusion is eradicated, knowledge of the four truths is accomplished at the same time. Knowing the noble truths in this way by function is called penetration through non-delusion (asammohapaṭivedha). Here the noble path knows the truth of cessation by penetration of the object, and knows the truths of suffering, origin, and the path by penetration through non-delusion. Thus the noble path accomplishes knowledge of the factors of dependent origination belonging to the truth of suffering, and of their causal connection belonging to the truth of origin. By virtue of this function the noble path is also called full understanding as knowing (ñātapariññā).


<a id="M05-body-P014"></a>
## Liễu tri bằng thẩm sát ở tầng siêu thế / Supramundane full understanding as investigation
Miến / Burmese 14

**VI**
3. Thánh đạo cũng nhổ tận gốc si mê che lấp sự biết rõ các tướng vô thường, khổ và vô ngã của các pháp thuộc khổ đế và tập đế. Vì vậy, phận sự thẩm sát và phân định các tướng vô thường, khổ và vô ngã của danh sắc và các nhân duyên, tức của các pháp thuộc hai đế ấy, cũng được hoàn tất. Vì phận sự này, Thánh đạo được gọi là liễu tri bằng thẩm sát (tīraṇapariññā). Trên đây là ba loại liễu tri siêu thế.

**EN**
3. The noble path also eradicates the delusion that obscures clear knowledge of the characteristics of impermanence, suffering, and non-self in the phenomena belonging to the truths of suffering and origin. Thus it completes the function of investigating and determining these characteristics in mentality, materiality, and their conditions, the phenomena belonging to those two truths. In virtue of this function the noble path is also called full understanding as investigation (tīraṇapariññā). These are the three kinds of supramundane full understanding.

**VI**
Chỉ khi tự mình trực tiếp thấu suốt mối liên hệ nhân quả của Duyên khởi bằng liễu tri hiệp thế và liễu tri siêu thế thì mới có thể nói đến sự hiểu theo và thấu triệt (anubodha và paṭivedha). Chỉ khi biết sâu pháp Duyên khởi bằng sự hiểu theo và thấu triệt như vậy mới có thể hoàn toàn vượt qua nỗi khổ lớn của luân hồi. Đó là ý nghĩa cốt yếu của đoạn trích Kinh Đại Duyên ở trên.

**EN**
Understanding and penetration (anubodha and paṭivedha) apply when one has personally and directly penetrated the causal connection of dependent origination by mundane and supramundane full understanding. Only when one knows dependent origination deeply through such understanding and penetration can one fully pass beyond the great suffering of saṃsāra. This is the essential meaning of the passage quoted above from the Great Discourse on Causation.

**VI**
Hiểu theo và thấu triệt (anubodha và paṭivedha)

**EN**
Understanding and penetration (anubodha and paṭivedha)

**VI**
Ananubodhāti ñātapariññāvasena ananubujjhanā. Appaṭivedhāti tīraṇapahānapariññāvasena appaṭivijjhanā. (Chú giải Dīgha, tập 2, tr. 85.)

**EN**
Ananubodhāti ñātapariññāvasena ananubujjhanā. Appaṭivedhāti tīraṇapahānapariññāvasena appaṭivijjhanā. (Dīgha Commentary, vol. 2, p. 85.)

**VI**
Nāmarūpaparicchedo, tassa ca paccayapariggaho na paṭhamābhinivesamattena hoti, atha kho tattha aparāparaṃ ñāṇuppattisaṅkhātena anu anu bujjhanena. Tadubhayābhāvaṃ pana dassento “ñātapariññāvasena ananubujjhanā”ti āha. Niccasaññādīnaṃ pajahanavasena vattamānā…

**EN**
Nāmarūpaparicchedo, tassa ca paccayapariggaho na paṭhamābhinivesamattena hoti, atha kho tattha aparāparaṃ ñāṇuppattisaṅkhātena anu anu bujjhanena. Tadubhayābhāvaṃ pana dassento “ñātapariññāvasena ananubujjhanā”ti āha. Niccasaññādīnaṃ pajahanavasena vattamānā…


<a id="M05-body-P015"></a>
## Hiểu theo nhờ trí sinh khởi nhiều lần / Understanding through the repeated arising of knowledge
Miến / Burmese 15

**VI**
…vipassanā dhamme ca paṭivijjhati eva nāma hoti paṭipakkhavikkhambhanena tikkhavisadabhāvāpattito. Tadadhiṭṭhānabhūtā ca tīraṇapariññā, ariyamaggo ca pariññāpahānābhisamayavasena pavattiyā tīraṇapahānapariññāsaṅgaho cāti tadubhayapaṭivedhābhāvaṃ dassento “tīraṇa … pe … appaṭivijjhanā”ti āha. (Phụ chú giải Dīgha, tập 2, tr. 89–90.)

**EN**
…vipassanā dhamme ca paṭivijjhati eva nāma hoti paṭipakkhavikkhambhanena tikkhavisadabhāvāpattito. Tadadhiṭṭhānabhūtā ca tīraṇapariññā, ariyamaggo ca pariññāpahānābhisamayavasena pavattiyā tīraṇapahānapariññāsaṅgaho cāti tadubhayapaṭivedhābhāvaṃ dassento “tīraṇa … pe … appaṭivijjhanā”ti āha. (Dīgha Subcommentary, vol. 2, pp. 89–90.)

**VI**
Hãy đọc lại ba loại liễu tri hiệp thế và ba loại liễu tri siêu thế đã giải thích ở trên. Lời chú giải và phụ chú giải này nói rõ rằng khi chưa thực sự thấy và hiểu rõ các pháp Duyên khởi bằng ba loại liễu tri hiệp thế và ba loại liễu tri siêu thế thì chưa có được sự hiểu theo và thấu triệt.

**EN**
Read again the three kinds of mundane and the three kinds of supramundane full understanding explained above. The commentary and subcommentary make clear that understanding and penetration have yet to be attained so long as the phenomena of dependent origination have yet to be distinctly seen and known through the three mundane and the three supramundane kinds of full understanding.

**VI**
Trí phân định danh sắc phân biệt sắc pháp và danh pháp. Trí nắm bắt các duyên phân biệt các nhân, các quả và mối liên hệ nhân quả giữa chúng. Theo lời phụ chú giải “anu anu bujjhanena”, tức hiểu đi hiểu lại, cả hai loại trí này không thành tựu chỉ bằng một lần biết mà phải được tu tập nhiều lần, hết lần này đến lần khác, cho đến khi thành tựu. Vì vậy, trí phân định danh sắc và trí nắm bắt các duyên gọi là sự hiểu theo (anubodha). Biết bằng trí hiểu theo gọi là hiểu theo (anubodhi). Đây là liễu tri bằng nhận biết.

**EN**
The knowledge that distinguishes mentality and materiality distinguishes mental and material phenomena. The knowledge that discerns conditions distinguishes causes, effects, and the causal connection between them. The subcommentary says “anu anu bujjhanena”, by understanding repeatedly. These two kinds of knowledge are brought to completion through repeated cultivation, over and over. The knowledge that distinguishes mentality and materiality and the knowledge that discerns conditions are therefore called understanding (anubodha). Knowing through this knowledge is called understanding (anubodhi). This is full understanding as knowing.

**VI**
Lại nữa, biết bằng tuệ liễu tri qua thẩm sát và đoạn trừ gọi là thấu triệt (paṭivedha). Các tuệ minh sát có thể đoạn trừ bằng sức đối trị từng phần các phiền não như tưởng thường, nhưng không thể nhổ tận gốc chúng để chúng vĩnh viễn không sinh lại. Do khả năng đoạn trừ từng phần ấy, các tuệ này được gọi là liễu tri bằng đoạn trừ…

**EN**
Further, knowing through the wisdom of full understanding as investigation and abandoning is called penetration (paṭivedha). The insight knowledges can abandon such defilements as the perception of permanence by momentary opposition, but cannot uproot them so that they never arise again. On account of this capacity for abandoning by opposition, these knowledges are called full understanding as abandoning…


<a id="M05-body-P016"></a>
## Phận sự của Thánh đạo và sự trực tiếp thấy các duyên / Functions of the noble path and directly seeing conditions
Miến / Burmese 16

**VI**
…(pahānapariññā). Tương tự, bằng sự thấu triệt do hết mê mờ (asammohapaṭivedha), Thánh đạo thấu suốt danh sắc và mối liên hệ nhân quả, tức các pháp thuộc khổ đế và tập đế, cũng như các tướng vô thường, khổ và vô ngã của chúng. Vì các phận sự được thực hiện qua sự thấu triệt do hết mê mờ ấy, Thánh đạo được gọi là liễu tri bằng nhận biết và liễu tri bằng thẩm sát. Riêng Thánh đạo có thể đoạn trừ tận gốc phiền não một cách vĩnh viễn, nên được gọi là liễu tri bằng đoạn trừ theo nghĩa chính. Vì vậy, biết thấu suốt danh sắc thuộc khổ đế và mối liên hệ nhân quả của Duyên khởi thuộc tập đế bằng liễu tri qua thẩm sát và đoạn trừ, cho đến khi đạt sát-na đạo và quả, được gọi là thấu triệt (paṭivedha).

**EN**
…(pahānapariññā). Likewise, through penetration by non-delusion (asammohapaṭivedha), the noble path penetrates mentality and materiality and their causal connection, the phenomena belonging to the truths of suffering and origin, as well as their characteristics of impermanence, suffering, and non-self. By virtue of these functions accomplished through penetration by non-delusion, the noble path is called full understanding as knowing and as investigation. The noble path alone can permanently uproot defilements, so it is called full understanding as abandoning in the primary sense. Thus penetrating mentality and materiality belonging to the truth of suffering and the causal connection of dependent origination belonging to the truth of origin through full understanding as investigation and abandoning, through to the moments of path and fruition, is called penetration (paṭivedha).

**VI**
Trong ba thời quá khứ, tương lai và hiện tại, hành giả phân định bằng trí các sắc và danh trong từng nhóm sắc và nhóm danh thuộc các chi Duyên khởi như vô minh và hành, rồi tự mình trực tiếp thấu suốt chúng bằng trí chánh kiến đến mức biết chúng là pháp chân đế. Hành giả cũng tự mình trực tiếp thấu suốt bằng trí chánh kiến mối liên hệ nhân quả giữa những nhân như vô minh và những quả như hành. Hai loại biết này gọi là hiểu theo (anubodhi). Còn tự mình trực tiếp thấu suốt bằng trí chánh kiến các tướng vô thường, khổ, vô ngã của các chi Duyên khởi ấy, cho đến khi đạt sát-na đạo và quả…

**EN**
In the past, future, and present, the meditator distinguishes with knowledge the material and mental phenomena in each material and mental group belonging to the factors of dependent origination, such as ignorance and formations. One personally and directly penetrates them through the knowledge of right view, to the point of knowing them as ultimate realities. One also personally and directly penetrates through the knowledge of right view the causal connection between causes such as ignorance and effects such as formations. These two kinds of knowing are called understanding (anubodhi). To personally and directly penetrate with the knowledge of right view the characteristics of impermanence, suffering, and non-self in those factors of dependent origination, through to the moments of path and fruition…


<a id="M05-body-P017"></a>
## Tóm lược Duyên khởi theo phương pháp thứ năm / A summary of dependent origination by the fifth method
Miến / Burmese 17

**VI**
…gọi là thấu triệt (paṭivedha). Nếu thiện nhân chưa tự mình trực tiếp biết đúng như thật các pháp Duyên khởi bằng hai loại biết là hiểu theo và thấu triệt, thì không thể vượt thoát khổ luân hồi bằng bất cứ cách nào. Chỉ khi biết như vậy mới có thể vượt thoát khổ luân hồi. Vì thế, thiện nhân muốn hoàn toàn vượt qua nỗi khổ lớn của vòng luân hồi phải gắng sức biết các pháp Duyên khởi bằng sự hiểu theo và thấu triệt. Để giúp nỗ lực tu tập như vậy, sau đây trình bày trước phương pháp thực hành gọi là phương pháp thứ năm về Duyên khởi.

**EN**
…is called penetration (paṭivedha). As long as a good person has yet to know the phenomena of dependent origination personally, directly, and as they really are through understanding and penetration, there is no way to escape the suffering of saṃsāra. Only through knowing in this way can one escape that suffering. Therefore, a good person wishing to pass completely beyond the great suffering of the round of rebirths must strive to know dependent origination through understanding and penetration. To support such practice, the procedure called the fifth method of dependent origination is presented first below.

**VI**
Tóm lược Duyên khởi theo phương pháp thứ năm để ghi nhớ

**EN**
A summary of dependent origination by the fifth method for memorization

**VI**
1. Purimakammabhavasmiṃ moho avijjā, āyūhanā saṅkhārā, nikanti taṇhā, upagamanaṃ upādānaṃ, cetanā bhavo. Ime pañca dhammā purimakammabhavasmiṃ idha paṭisandhiyā paccayā.

**EN**
1. Purimakammabhavasmiṃ moho avijjā, āyūhanā saṅkhārā, nikanti taṇhā, upagamanaṃ upādānaṃ, cetanā bhavo. Ime pañca dhammā purimakammabhavasmiṃ idha paṭisandhiyā paccayā.

**VI**
2. Idha paṭisandhi viññāṇaṃ, okkanti nāmarūpaṃ, pasādo āyatanaṃ, phuṭṭho phasso, vedayitaṃ vedanā. Ime pañca dhammā idhupapattibhavasmiṃ purekatassa kammassa paccayā.

**EN**
2. Idha paṭisandhi viññāṇaṃ, okkanti nāmarūpaṃ, pasādo āyatanaṃ, phuṭṭho phasso, vedayitaṃ vedanā. Ime pañca dhammā idhupapattibhavasmiṃ purekatassa kammassa paccayā.

**VI**
3. Idha paripakkattā āyatanānaṃ moho avijjā, āyūhanā saṅkhārā, nikanti taṇhā, upagamanaṃ upādānaṃ, cetanā bhavo. Ime pañca dhammā idha kammabhavasmiṃ āyatiṃ paṭisandhiyā paccayā.

**EN**
3. Idha paripakkattā āyatanānaṃ moho avijjā, āyūhanā saṅkhārā, nikanti taṇhā, upagamanaṃ upādānaṃ, cetanā bhavo. Ime pañca dhammā idha kammabhavasmiṃ āyatiṃ paṭisandhiyā paccayā.

**VI**
4. Āyatiṃ paṭisandhi viññāṇaṃ, okkanti nāmarūpaṃ, pasādo āyatanaṃ, phuṭṭho phasso, vedayitaṃ vedanā. Ime pañca dhammā āyatiṃ…

**EN**
4. Āyatiṃ paṭisandhi viññāṇaṃ, okkanti nāmarūpaṃ, pasādo āyatanaṃ, phuṭṭho phasso, vedayitaṃ vedanā. Ime pañca dhammā āyatiṃ…


<a id="M05-body-P018"></a>
## Năm nhân quá khứ và năm quả hiện tại / Five past causes and five present results
Miến / Burmese 18

**VI**
…upapattibhavasmiṃ idha katassa kammassa paccayā. (Paṭisambhidāmagga, tr. 50–51.)

**EN**
…upapattibhavasmiṃ idha katassa kammassa paccayā. (Paṭisambhidāmagga, pp. 50–51.)

**VI**
1. Khi tạo dựng nghiệp hữu trong một đời quá khứ đã qua:
(a) Sự mê mờ, tức si, được gọi là vô minh.
(b) Sự nỗ lực tạo tác và tích lũy nghiệp được gọi là hành.
(c) Sự ham muốn và mê đắm hữu được gọi là ái.
(d) Sự nắm giữ chắc chắn được gọi là thủ.
(e) Tư tác thúc đẩy hành động được gọi là hữu.

**EN**
1. When building up kamma-becoming in a past life:
(a) Confusion, that is, delusion, is called ignorance.
(b) Exertion in generating and accumulating kamma is called formations.
(c) Desire and longing for becoming are called craving.
(d) Holding on firmly is called clinging.
(e) The volition that prompts action is called becoming.

**VI**
Năm pháp đã sinh khởi khi tạo dựng nghiệp hữu trong đời quá khứ ấy là các nhân của sự tái tục trong đời hiện tại này.

**EN**
The five phenomena that arose while building up kamma-becoming in that past life are causes of rebirth-linking in this present life.

**VI**
2. Trong đời hiện tại này:
(a) Pháp tái tục có tướng nối kết đời này với đời kia, tức nối kết các uẩn của đời này với các uẩn của đời kia, gọi là thức.
(b) Các pháp sinh khởi như thể đi vào bụng mẹ gọi là danh sắc.
(c) Sự trong suốt của các đại chủng gọi là xứ.
(d) Tính chất tiếp xúc gọi là xúc.
(e) Tính chất cảm nhận gọi là thọ.

**EN**
2. In this present life:
(a) The rebirth-linking phenomenon characterized by connecting one life to another, that is, the aggregates of one life to the aggregates of another, is called consciousness.
(b) The phenomena arising as though entering the mother’s womb are called mentality-materiality.
(c) The sensitivity of the great elements is called a sense base.
(d) The quality of coming into contact is called contact.
(e) The quality of experiencing is called feeling.

**VI**
Năm pháp thuộc vòng quả trong đời hiện tại này là những quả sinh khởi do nghiệp đã được tạo tác và tích lũy khi xây dựng nghiệp hữu trong đời quá khứ.

**EN**
These five phenomena in the round of results in the present life are results that arise from kamma generated and accumulated while building up kamma-becoming in a past life.


<a id="M05-body-P019"></a>
## Năm nhân hiện tại và năm quả tương lai / Five present causes and five future results
Miến / Burmese 19

**VI**
3. Trong đời hiện tại này, do các xứ đã chín muồi, những pháp sau sinh khởi:
(a) Mê mờ, tức si, gọi là vô minh.
(b) Nỗ lực tạo tác và tích lũy nghiệp gọi là hành.
(c) Mong muốn và mê đắm hữu gọi là ái.
(d) Nắm giữ chắc chắn gọi là thủ.
(e) Tư thúc đẩy hành động gọi là hữu.

**EN**
3. In this present life, owing to the maturity of the sense bases, the following phenomena arise:
(a) Confusion, that is, delusion, is called ignorance.
(b) Exertion in generating and accumulating kamma is called formations.
(c) Desire and longing for becoming are called craving.
(d) Holding on firmly is called clinging.
(e) Volition that prompts action is called becoming.

**VI**
Năm pháp làm nhân ấy, sinh trong nghiệp hữu hiện tại, là các nhân của sự tái tục trong tương lai.

**EN**
These five causes, arising in present kamma-becoming, are causes of future rebirth-linking.

**VI**
4. Trong tương lai:
(a) Pháp tái tục có tướng nối kết đời này với đời kia, tức nối kết các uẩn của đời này với các uẩn của đời kia, gọi là thức.
(b) Các pháp sinh khởi như thể đi vào bụng mẹ gọi là danh sắc.
(c) Sự trong suốt của các đại chủng gọi là xứ.
(d) Tính chất tiếp xúc gọi là xúc.
(e) Tính chất cảm nhận gọi là thọ.

**EN**
4. In the future:
(a) The rebirth-linking phenomenon characterized by connecting one life to another, that is, the aggregates of one life to the aggregates of another, is called consciousness.
(b) Phenomena arising as though entering the mother’s womb are called mentality-materiality.
(c) The sensitivity of the great elements is called a sense base.
(d) The quality of coming into contact is called contact.
(e) The quality of experiencing is called feeling.

**VI**
Năm pháp sinh trong sinh hữu tương lai ấy là quả do nghiệp đã tạo tác và tích lũy trong đời hiện tại làm nhân. (Paṭisambhidāmagga, tr. 50–51.)

**EN**
These five phenomena arising in future rebirth-becoming are results caused by kamma generated and accumulated in the present life. (Paṭisambhidāmagga, pp. 50–51.)

**VI**
Dựa vào đoạn Pāli trong Paṭisambhidāmagga đã nêu trên, các vị chú giải sư giải thích tóm tắt để dễ ghi nhớ như sau.

**EN**
On the basis of the Pāli passage from the Paṭisambhidāmagga quoted above, the commentators give the following summary for memorization.


<a id="M05-body-P020"></a>
## Năm nhân và năm quả qua ba thời / Five causes and five results across the three periods
Miến / Burmese 20

**VI**
Atīte hetavo pañca, idāni phalapañcakaṃ.
Idāni hetavo pañca, āyatiṃ phalapañcakaṃ.
(Chú giải Abhidhamma, tập 2, tr. 182. Thanh tịnh đạo, tập 2, tr. 214.)

**EN**
Atīte hetavo pañca, idāni phalapañcakaṃ.
Idāni hetavo pañca, āyatiṃ phalapañcakaṃ.
(Abhidhamma Commentary, vol. 2, p. 182. Visuddhimagga, vol. 2, p. 214.)

**VI**
1. Do năm nhân quá khứ đã được tạo tác và vun bồi là vô minh, ái, thủ, hành và nghiệp, năm quả hiện tại trong đời này hiện khởi là thức, danh sắc, sáu xứ, xúc và thọ.

**EN**
1. Owing to the five past causes generated and accumulated in the past, namely ignorance, craving, clinging, formations, and kamma, the five present results arise in this life: consciousness, mentality-materiality, the six bases, contact, and feeling.

**VI**
2. Do năm nhân hiện tại được tạo tác và vun bồi trong đời này là vô minh, ái, thủ, hành và nghiệp, năm quả tương lai hiện khởi trong đời sau là thức, danh sắc, sáu xứ, xúc và thọ. (Chú giải Abhidhamma, tập 2, tr. 182. Thanh tịnh đạo, tập 2, tr. 214.)

**EN**
2. Owing to the five present causes generated and accumulated in this life, namely ignorance, craving, clinging, formations, and kamma, the five future results arise in a future life: consciousness, mentality-materiality, the six bases, contact, and feeling. (Abhidhamma Commentary, vol. 2, p. 182. Visuddhimagga, vol. 2, p. 214.)

**VI**
Thiện hữu muốn vượt thoát hãy nỗ lực tự mình trực tiếp thấu suốt bằng trí chánh kiến cách năm quả hiện tại hiện khởi do năm nhân quá khứ, và cách năm quả tương lai hiện khởi do năm nhân hiện tại. Chỉ khi ấy mới có thể vượt hẳn qua nỗi khổ lớn của luân hồi.

**EN**
A good person who wishes to escape should strive to penetrate directly for themselves, with the knowledge of right view, how the five present results arise due to the five past causes and how the five future results arise due to the five present causes. Only then can one pass entirely beyond the great suffering of saṃsāra.

**VI**
Ở đây các nhân là tập đế và các quả là khổ đế. Vì vậy, thiện hữu muốn vượt thoát phải nỗ lực tự mình trực tiếp thấu suốt bằng trí chánh kiến cách khổ đế hiện tại phát sinh do tập đế đã tạo tác, vun bồi trong quá khứ, và cách khổ đế tương lai phát sinh do tập đế được tạo tác, vun bồi trong hiện tại.

**EN**
Here the causes are the truth of origin and the results are the truth of suffering. Therefore, a good person who wishes to escape should strive to penetrate directly for themselves, with the knowledge of right view, how the present truth of suffering arises due to the truth of origin accumulated in the past and how the future truth of suffering arises due to the truth of origin accumulated in the present.


<a id="M05-body-P021"></a>
## Tập đế được trình bày theo năm cách / The truth of origin taught in five ways
Miến / Burmese 21

**VI**
Trong Pāli Abhidhamma Vibhaṅga (Abhidhamma, tập 2, tr. 112–118), Đức Phật dạy về tập đế theo năm cách:
1. Ái là tập đế.
2. Ái và tất cả phiền não đi cùng ái là tập đế.
3. Tất cả pháp bất thiện là tập đế.
4. Tất cả pháp bất thiện và ba căn thiện là vô tham, vô sân, vô si làm cảnh cho các pháp hữu lậu khiến luân hồi tiếp diễn là tập đế.
5. Tất cả nghiệp thiện làm cảnh cho các pháp hữu lậu khiến luân hồi tiếp diễn, cùng tất cả nghiệp bất thiện, là tập đế.

**EN**
In the Pāli Abhidhamma Vibhaṅga (Abhidhamma, vol. 2, pp. 112–118), the Buddha taught the truth of origin in five ways:
1. Craving is the truth of origin.
2. Craving and all the defilements accompanying it are the truth of origin.
3. All unwholesome phenomena are the truth of origin.
4. All unwholesome phenomena and the three wholesome roots—non-greed, non-hatred, and non-delusion—that serve as objects for phenomena with taints that keep saṃsāra going are the truth of origin.
5. All wholesome kamma serving as an object for phenomena with taints that keep saṃsāra going, together with all unwholesome kamma, is the truth of origin.

**VI**
Vì Đức Phật đã phân tích tập đế theo năm cách như vậy, các vị chú giải sư trong Sammohavinodanī giải thích như sau.

**EN**
Since the Buddha analyzed the truth of origin in these five ways, the commentators explain it as follows in the Sammohavinodanī.

**VI**
Tattha yasmā kusalākusalakammaṃ avisesena samudayasaccanti saccavibhaṅge vuttaṃ. (Chú giải Abhidhamma, tập 2, tr. 185.)

**EN**
Tattha yasmā kusalākusalakammaṃ avisesena samudayasaccanti saccavibhaṅge vuttaṃ. (Abhidhamma Commentary, vol. 2, p. 185.)

**VI**
Trong phần Phân tích các đế, Đức Phật dạy chung rằng tất cả nghiệp thiện và bất thiện là tập đế, không giới hạn ở tư hoặc những pháp tương ưng với tư. (Chú giải Abhidhamma, tập 2, tr. 185.)

**EN**
In the Analysis of the Truths, the Buddha taught in general that all wholesome and unwholesome kamma is the truth of origin, without restricting the statement to volition or the phenomena associated with volition. (Abhidhamma Commentary, vol. 2, p. 185.)

**VI**
Lại nữa, trong Kinh Titthāyatanasutta thuộc chương Ba pháp của Aṅguttara, Đức Phật dạy về tập đế như sau.

**EN**
Again, in the Titthāyatanasutta of the Book of Threes in the Aṅguttara, the Buddha taught the truth of origin as follows.


<a id="M05-body-P022"></a>
## Chuỗi Duyên khởi và Thánh đế về nguồn gốc khổ / The chain of dependent origination and the noble truth of the origin of suffering
Miến / Burmese 22

**VI**
Katamañca, bhikkhave, dukkhasamudayaṃ ariyasaccaṃ? Avijjāpaccayā saṅkhārā, saṅkhārapaccayā viññāṇaṃ, viññāṇapaccayā nāmarūpaṃ, nāmarūpapaccayā saḷāyatanaṃ, saḷāyatanapaccayā phasso, phassapaccayā vedanā, vedanāpaccayā taṇhā, taṇhāpaccayā upādānaṃ, upādānapaccayā bhavo, bhavapaccayā jāti, jātipaccayā jarāmaraṇaṃ sokaparidevadukkhadomanassupāyāsā sambhavanti. Evametassa kevalassa dukkhakkhandhassa samudayo hoti. Idaṃ vuccati, bhikkhave, dukkhasamudayaṃ ariyasaccaṃ. (Aṅguttara, tập 1, tr. 178.)

**EN**
Katamañca, bhikkhave, dukkhasamudayaṃ ariyasaccaṃ? Avijjāpaccayā saṅkhārā, saṅkhārapaccayā viññāṇaṃ, viññāṇapaccayā nāmarūpaṃ, nāmarūpapaccayā saḷāyatanaṃ, saḷāyatanapaccayā phasso, phassapaccayā vedanā, vedanāpaccayā taṇhā, taṇhāpaccayā upādānaṃ, upādānapaccayā bhavo, bhavapaccayā jāti, jātipaccayā jarāmaraṇaṃ sokaparidevadukkhadomanassupāyāsā sambhavanti. Evametassa kevalassa dukkhakkhandhassa samudayo hoti. Idaṃ vuccati, bhikkhave, dukkhasamudayaṃ ariyasaccaṃ. (Aṅguttara, vol. 1, p. 178.)

**VI**
Này các tỳ-khưu, thế nào là Thánh đế về nguồn gốc khổ?
1. Do vô minh sinh, hành sinh.
2. Do hành sinh, thức sinh.
3. Do thức sinh, danh sắc sinh.
4. Do danh sắc sinh, sáu xứ sinh.
5. Do sáu xứ sinh, xúc sinh.
6. Do xúc sinh, thọ sinh.
7. Do thọ sinh, ái sinh.
8. Do ái sinh, thủ sinh.
9. Do thủ sinh, hữu sinh.
10. Do hữu sinh, sinh sinh.
11. Do sinh, già chết, sầu, bi, khổ, ưu và não hiện khởi.

**EN**
Bhikkhus, what is the noble truth of the origin of suffering?
1. With the arising of ignorance, formations arise.
2. With the arising of formations, consciousness arises.
3. With the arising of consciousness, mentality-materiality arises.
4. With the arising of mentality-materiality, the six bases arise.
5. With the arising of the six bases, contact arises.
6. With the arising of contact, feeling arises.
7. With the arising of feeling, craving arises.
8. With the arising of craving, clinging arises.
9. With the arising of clinging, becoming arises.
10. With the arising of becoming, birth arises.
11. With birth, aging and death, sorrow, lamentation, pain, grief, and despair arise.

**VI**
Như vậy, nguyên nhân sinh khởi của toàn bộ khối khổ không có chút an lạc này, nói cách khác, sự sinh khởi của toàn bộ khối khổ, hiện rõ. Này các tỳ-khưu, mối liên hệ nhân quả của Duyên khởi này là Thánh đế về nguồn gốc khổ…

**EN**
In this way the origin of this whole mass of suffering, with no trace of ease, becomes evident. In other words, the entire mass of suffering arises. Bhikkhus, this causal connection of dependent origination is the noble truth of the origin of suffering…


<a id="M05-body-P023"></a>
## Ái nào là nguồn gốc của khổ hiện tại? / Which craving is the origin of present suffering?
Miến / Burmese 23

**VI**
…được gọi như vậy. (Aṅguttara, tập 1, tr. 178.)

**EN**
…it is called thus. (Aṅguttara, vol. 1, p. 178.)

**VI**
Trong Kinh Titthāyatana, Đức Phật gọi toàn bộ mối liên hệ nhân quả giữa các nhân và các quả là tập đế.

**EN**
In the Titthāyatana Sutta, the Buddha calls the whole causal connection between causes and results the truth of origin.

**VI**
Ái ấy từ khi nào?

**EN**
When did that craving arise?

**VI**
Đức Phật quả có dạy rằng ái là tập đế. Nhưng cần suy xét kỹ ái được gọi là tập đế, tức nhân gốc của các pháp thuộc khổ đế hiện tại, là ái sinh khởi từ khi nào.

**EN**
The Buddha did indeed teach that craving is the truth of origin. But one should carefully consider when the craving called the truth of origin, the root cause of the present phenomena belonging to the truth of suffering, arose.

**VI**
Rūpārūpaṃ panetaṃ hoti dukkhasaccaṃ, taṃsamuṭṭhāpikā purimataṇhā samudayasaccaṃ. (Chú giải Abhidhamma, tập 2, tr. 68–69.)

**EN**
Rūpārūpaṃ panetaṃ hoti dukkhasaccaṃ, taṃsamuṭṭhāpikā purimataṇhā samudayasaccaṃ. (Abhidhamma Commentary, vol. 2, pp. 68–69.)

**VI**
Danh và sắc là năm uẩn. Năm uẩn ấy là khổ đế. Ái đã được tạo tác và vun bồi từ trước, làm sinh khởi khổ đế ấy, là tập đế. (Chú giải Abhidhamma, tập 2, tr. 68–69.)

**EN**
Mentality and materiality are the five aggregates. Those five aggregates are the truth of suffering. The craving generated and accumulated in the past that gives rise to that truth of suffering is the truth of origin. (Abhidhamma Commentary, vol. 2, pp. 68–69.)

**VI**
Theo lời giải thích trên, hãy hiểu rằng ái gọi là tập đế, nhân gốc thật sự của năm thủ uẩn thuộc khổ đế hiện có trong dòng tương tục của thiện hữu, là ái đã được tạo tác và vun bồi trong những đời trước.

**EN**
According to the explanation above, understand that the craving called the truth of origin, the actual root cause of the five aggregates subject to clinging that now constitute the truth of suffering in a good person’s continuity, is craving generated and accumulated in past lives.

**VI**
Lời giải thích của chú giải này phù hợp với lời Đức Phật dạy và phù hợp với ý nghĩa đoạn Pāli Paṭisambhidāmagga đã nêu trên. Khi tạo tác và vun bồi nghiệp gọi là nghiệp hữu…

**EN**
This explanation of the commentary accords with the Buddha’s teaching and with the meaning of the Pāli passage from the Paṭisambhidāmagga given above. When generating and accumulating the kamma called kamma-becoming…


<a id="M05-body-P024"></a>
## Phân biệt hành và nghiệp hữu / Distinguishing formations and kamma-becoming
Miến / Burmese 24

**VI**
…si, tức sự biết sai, sinh trong đời quá khứ xa xưa gọi là vô minh. Những pháp nỗ lực làm cho nghiệp sinh khởi là hành. Mê đắm hữu và cảnh tương ứng, tức nikanti, là ái. Tâm tiến đến và bám lấy hữu hay cảnh ấy là thủ. Tư thiện hay tư bất thiện là hữu. Năm pháp sinh khởi khi tạo tác, vun bồi nghiệp hữu trong đời quá khứ ấy là các nhân của tái tục trong đời hiện tại này. Đối với loài người, chúng là các nhân của năm uẩn tái tục. (Paṭisambhidāmagga, tr. 50.)

**EN**
…delusion, the mistaken knowing that arose in a former life, is called ignorance. The phenomena that exert themselves to bring kamma into being are formations. Attachment to becoming and to its corresponding object, that is, nikanti, is craving. The mind’s going toward and holding to that becoming or object is clinging. Wholesome or unwholesome volition is becoming. The five phenomena that arose when generating and accumulating kamma-becoming in that past life are causes of rebirth-linking in this present life. For human beings, they are causes of the five rebirth-linking aggregates. (Paṭisambhidāmagga, p. 50.)

**VI**
Ý chính của đoạn Pāli này là hành và nghiệp đã được tạo tác dưới sự chi phối của vô minh, ái và thủ trong đời quá khứ khi vun bồi nghiệp trước kia chính là nhân gốc của năm uẩn tái tục hiện tại, tức các uẩn quả. Ở đây, hãy hiểu cách phân định hành với nghiệp hữu, tức nghiệp, qua ví dụ về một việc bố thí.

**EN**
The point of this Pāli passage is that the formations and kamma generated under the influence of ignorance, craving, and clinging when past kamma was accumulated are the root causes of the five present rebirth-linking aggregates, the resultant aggregates. Here the distinction between formations and kamma-becoming, that is, kamma, can be understood through the example of an act of giving.

**VI**
1. Trong khi chuẩn bị làm một việc bố thí thiện, các tư trước khi trao vật thí là hành. Tư thiết lập vật thí trong tay người nhận, tức tư buông xả (muñcanacetanā), là nghiệp hữu.

**EN**
1. In preparing a wholesome act of giving, the volitions before handing over the gift are formations. The volition that places the gift in the recipient’s hands, the volition of relinquishing (muñcanacetanā), is kamma-becoming.

**VI**
2. Theo cách khác, trong các lộ tâm tốc hành qua ý môn sinh khi tạo tác và vun bồi một nghiệp, các tư ở sáu tốc hành đầu trong bảy tốc hành được gọi là hành nỗ lực (āyūhanasaṅkhāra), tức những nhân nỗ lực khiến nghiệp sinh khởi. Còn tư ở tốc hành thứ bảy…

**EN**
2. Alternatively, in the mind-door impulsion processes that arise while generating and accumulating an act of kamma, the volitions at the first six of the seven impulsions are called exertive formations (āyūhanasaṅkhāra), the exertive causes that bring kamma into being. The volition at the seventh impulsion…


<a id="M05-body-P025"></a>
## Tư, hành và sức mạnh của nghiệp duyên / Volition, formations, and the power of kamma condition
Miến / Burmese 25

**VI**
…là tư ở tốc hành thứ bảy, gọi là nghiệp hữu.

**EN**
…is the volition at the seventh impulsion, called kamma-becoming.

**VI**
3. Theo cách khác, tư trong một sát-na tốc hành khi tạo tác và vun bồi một nghiệp được gọi là nghiệp hữu. Tâm và các tâm sở đồng sinh, tức các pháp tương ưng với tư ấy, được gọi là hành nỗ lực (āyūhanasaṅkhāra). (Chú giải Abhidhamma, tập 2, tr. 182–183.)

**EN**
3. Alternatively, the volition present in a moment of impulsion while generating and accumulating an act of kamma is called kamma-becoming. The consciousness and mental factors arising together with it, that is, the phenomena associated with that volition, are called exertive formations (āyūhanasaṅkhāra). (Abhidhamma Commentary, vol. 2, pp. 182–183.)

**VI**
Sức mạnh của nghiệp duyên

**EN**
The power of kamma condition

**VI**
Kusalākusalaṃ kammaṃ vipākānaṃ khandhānaṃ kaṭattā ca rūpānaṃ kammapaccayena paccayo. (Paṭṭhāna, tập 1, tr. 7.)

**EN**
Kusalākusalaṃ kammaṃ vipākānaṃ khandhānaṃ kaṭattā ca rūpānaṃ kammapaccayena paccayo. (Paṭṭhāna, vol. 1, p. 7.)

**VI**
Kammapaccayenāti anekampi kappakoṭīnaṃ matthake attano phalaṃ uppādetuṃ samatthena nānakkhaṇikakammapaccayenāti attho. Kusalākusalañhi kammaṃ attano pavattikkhaṇe phalaṃ na deti. Yadi dadeyya, yaṃ manusso devalokūpagaṃ kusalaṃ kammaṃ karoti, taṃānubhāvena tasmiṃyeva khaṇe devo bhaveyya. Yasmiṃ pana khaṇe taṃ kataṃ, tato aññasmiṃ khaṇe avijjamānampi kevalaṃ kaṭattāyeva diṭṭheva dhamme upapajje vā apare vā pariyāye avasesapaccayasamāyoge sati phalaṃ uppādeti, niruddhāpi purimasippādikiriyā viya kālantare pacchimasippādikiriyāya. Tasmā nānakkhaṇikakammapaccayoti vuccati. (Chú giải Abhidhamma, tập 3, tr. 374.)

**EN**
Kammapaccayenāti anekampi kappakoṭīnaṃ matthake attano phalaṃ uppādetuṃ samatthena nānakkhaṇikakammapaccayenāti attho. Kusalākusalañhi kammaṃ attano pavattikkhaṇe phalaṃ na deti. Yadi dadeyya, yaṃ manusso devalokūpagaṃ kusalaṃ kammaṃ karoti, taṃānubhāvena tasmiṃyeva khaṇe devo bhaveyya. Yasmiṃ pana khaṇe taṃ kataṃ, tato aññasmiṃ khaṇe avijjamānampi kevalaṃ kaṭattāyeva diṭṭheva dhamme upapajje vā apare vā pariyāye avasesapaccayasamāyoge sati phalaṃ uppādeti, niruddhāpi purimasippādikiriyā viya kālantare pacchimasippādikiriyāya. Tasmā nānakkhaṇikakammapaccayoti vuccati. (Abhidhamma Commentary, vol. 3, p. 374.)

**VI**
Thiện hữu hãy xét năm nhân của các uẩn quả hiện tại, lấy nghiệp làm điểm chính. Hãy lưu ý nghiệp ấy được vô minh, ái và thủ bao quanh. Trong phần nói về nghiệp duyên, Đức Phật dạy như sau.

**EN**
Let the good person consider the five causes of the present resultant aggregates with kamma as the main point. Note that this kamma is surrounded by ignorance, craving, and clinging. In the section on kamma condition, the Buddha teaches as follows.

**VI**
Nghiệp thiện và nghiệp bất thiện trợ duyên cho các uẩn quả và cho các sắc do nghiệp đã làm mà sinh…

**EN**
Wholesome and unwholesome kamma condition the resultant aggregates and the material phenomena that arise because kamma has been done…


<a id="M05-body-P026"></a>
## Nghiệp khác sát-na và thời điểm trổ quả / Asynchronous kamma and the time of ripening
Miến / Burmese 26

**VI**
…bằng sức của nghiệp duyên. (Paṭṭhāna, tập 1, tr. 7.)

**EN**
…by the power of kamma condition. (Paṭṭhāna, vol. 1, p. 7.)

**VI**
“Bằng sức của nghiệp duyên” có nghĩa như sau. Dù đã trải qua nhiều koṭi kiếp, nghiệp đã tạo tác và tích lũy vẫn trợ duyên bằng sức của nghiệp duyên khác sát-na (nānakkhaṇikakammapaccaya), có khả năng làm sinh quả của nó. “Nghiệp khác sát-na” chỉ duyên mà thời điểm của nhân nghiệp và thời điểm quả sinh khởi khác nhau.

**EN**
“By the power of kamma condition” means the following. Even after many koṭis of aeons, kamma that was generated and accumulated can condition its own result through the power of asynchronous kamma condition (nānakkhaṇikakammapaccaya). “Asynchronous kamma” denotes a condition in which the time of the causal kamma differs from the time its result arises.

**VI**
Nghiệp thiện và nghiệp bất thiện không cho quả ngay trong sát-na nó đang diễn ra. Nếu nó có khả năng cho quả ngay khi đang diễn ra, khi một người tạo nghiệp thiện đưa đến cõi trời thì người ấy sẽ lập tức thành một vị trời. Nhưng sự việc không diễn ra như vậy.

**EN**
Wholesome and unwholesome kamma do not give their result in the very moment they are occurring. If kamma could give its result as it occurs, a person who did a wholesome deed leading to a heavenly realm would immediately become a deity. That is not how it happens.

**VI**
Khi một nghiệp được tạo do ước muốn, sau sát-na tạo nghiệp ấy, nghiệp không còn hiện hữu như một pháp hiện tại. Tuy vậy, chính vì nghiệp ấy đã được làm, khi hội đủ các duyên còn lại thì quả có thể sinh trong đời hiện tại nếu đó là nghiệp cho quả hiện đời (diṭṭhadhammavedanīyakamma), trong đời thứ hai kế tiếp nếu là nghiệp cho quả đời kế (upapajjavedanīyakamma), hoặc trong một đời thích hợp từ đời thứ ba trở đi nếu là nghiệp cho quả các đời sau (aparāpariyavedanīyakamma). Các duyên thích hợp gồm sự thành tựu hay bất lợi về cảnh giới tái sinh, thân tướng, thời kỳ và nỗ lực, tùy theo nghiệp thiện hay bất thiện.

**EN**
When an act is performed with an intention, after the moment of doing it the kamma no longer exists as a present phenomenon. Yet because it was done, its result can arise when the remaining conditions come together. It may arise in the present life for kamma to be experienced here and now (diṭṭhadhammavedanīyakamma), in the next, second life for kamma to be experienced in the next rebirth (upapajjavedanīyakamma), or in a suitable life from the third onward for kamma to be experienced in subsequent lives (aparāpariyavedanīyakamma). The relevant conditions include favorable or unfavorable destination, bodily endowment, period, and effort, according to whether the kamma is wholesome or unwholesome.


<a id="M05-body-P027"></a>
## Vì sao gọi là nghiệp duyên khác sát-na? / Why it is called asynchronous kamma condition
Miến / Burmese 27

**VI**
Như việc học nghề trước đây, dù đã chấm dứt, vẫn làm nền và trợ giúp cho việc thực hành nghề về sau khi đến lúc thích hợp, tư gọi là nghiệp cũng vậy. Tư trợ duyên cho quả sinh vào một thời điểm sau khi nghiệp đã được tạo tác và tích lũy. Vì thế gọi là nghiệp duyên khác sát-na, tức tư sinh ở sát-na khác với sát-na quả được cho. (Chú giải Abhidhamma, tập 3, tr. 374.)

**EN**
Earlier training in a craft, though it has ceased, still provides a basis and support for practising that craft when the appropriate time comes. So it is with the volition called kamma. It conditions the arising of a result at a time after the kamma was generated and accumulated. Hence it is called asynchronous kamma condition, a volition that arose at a moment different from the moment at which it gives its result. (Abhidhamma Commentary, vol. 3, p. 374.)

**VI**
Sức làm cho quả sinh khởi của tư đã được tạo tác, vun bồi từ đời quá khứ xa xưa hay từ nhiều koṭi kiếp, dù tư ấy không còn hiện hữu như một pháp hiện tại, gọi là sức nghiệp (kammasatti). Thiện hữu hãy suy xét điều này, lấy sức nghiệp làm điểm chính.

**EN**
The power to produce a result belonging to a volition generated and accumulated in a distant past life or many koṭis of aeons ago, even though that volition no longer exists as a present phenomenon, is called the power of kamma (kammasatti). Let the good person consider this with the power of kamma as the main point.

**VI**
Nếu nghiệp cho quả ngay khi đang được tạo, như đã giải thích trong chú giải, khi một người tạo nghiệp thiện đưa đến cõi trời thì ngay lúc tạo nghiệp người ấy phải thành một vị trời. Điều ấy không xảy ra. Cũng vậy, nếu một người muốn đạt tuổi trưởng thành và tạo nghiệp để thành người nam hay người nữ mười sáu tuổi, thì ngay khi tạo nghiệp ấy người đó phải thành người mười sáu tuổi. Điều ấy cũng không xảy ra. Nếu quả sinh như vậy thì thế gian sẽ không có người già, người bệnh hay người chết. Vì sao? Vì mọi người sẽ làm việc thiện rồi cầu cho mình khỏi già, khỏi bệnh, khỏi chết. Nói gọn, trên đời cũng sẽ không còn người xấu…

**EN**
If kamma gave its result while it was being generated, as the commentary explains, a person doing a wholesome deed that leads to a heavenly realm would have to become a deity at the very time of doing it. That does not happen. Likewise, if a person wished to reach maturity and did kamma to become a sixteen-year-old man or woman, they would have to become sixteen at the very moment of doing that kamma. That does not happen either. If results arose in that way, there would be no old, sick, or dying people in the world. Why? Everyone would do good deeds and aspire to be free from aging, sickness, and death. In brief, there would also be no bad people in the world…


<a id="M05-body-P028"></a>
## Duyên quá khứ và thời gian tích lũy ba-la-mật / Past conditions and the time needed to cultivate the perfections
Miến / Burmese 28

**VI**
…vì mọi người sẽ làm việc thiện rồi cầu trở thành người đứng đầu thế gian, như vị vua Chuyển luân. Ngay cả nghiệp có khả năng cho quả trong đời hiện tại (diṭṭhadhammavedanīyakamma) cũng chỉ cho quả sau một khoảng thời gian kể từ lúc tạo nghiệp. Các nghiệp khác lại không như thế.

**EN**
…because everyone would do good deeds and aspire to become a foremost person in the world, such as a wheel-turning monarch. Even kamma able to give a result in this life (diṭṭhadhammavedanīyakamma) gives that result only after some time has elapsed since the deed. Other kamma does not ripen in that way.

**VI**
Vì vậy, khi suy xét năm nhân quá khứ mà lấy nghiệp làm điểm chính, thiện hữu có thể chấp nhận rằng các pháp thuộc khổ đế của đời này hiện khởi do tập đế đã được tạo tác, vun bồi trong quá khứ. Nếu thiện hữu không thể chấp nhận rằng năm uẩn tái tục và các pháp thuộc khổ đế trong đời hiện tại hiện khởi do nghiệp, gọi là tập đế, đã được vun bồi từ trước, thì hãy suy xét vì sao các vị Bồ-tát Chánh Đẳng Giác phải vun bồi ba-la-mật để thành tựu tuệ giác của một vị Phật Chánh Đẳng Giác trong bốn a-tăng-kỳ và một trăm nghìn kiếp.

**EN**
Therefore, when considering the five past causes with kamma as the main point, a good person can accept that the phenomena belonging to the truth of suffering in this life arise due to the truth of origin accumulated in the past. If one cannot accept that the five rebirth-linking aggregates and the phenomena belonging to the truth of suffering in this life arise due to previously accumulated kamma, called the truth of origin, then consider why a bodhisatta destined for perfect awakening has to cultivate the perfections for four incalculables and a hundred thousand aeons to attain the awakening of a perfectly awakened Buddha.

**VI**
Hãy suy xét tương tự đối với vị hướng đến tuệ giác Độc Giác trong hai a-tăng-kỳ và một trăm nghìn kiếp, vị hướng đến tuệ giác của thượng thủ đệ tử trong một a-tăng-kỳ và một trăm nghìn kiếp, và vị hướng đến tuệ giác của đại đệ tử trong một trăm nghìn kiếp. Liệu các vị ấy có cần phải vun bồi ba-la-mật suốt thời gian đó hay không? Hãy suy xét lại. Chỉ vì không chấp nhận rằng tập đế đã được tạo tác trong quá khứ…

**EN**
Consider likewise one aspiring to the awakening of a solitary Buddha for two incalculables and a hundred thousand aeons, one aspiring to the awakening of a chief disciple for one incalculable and a hundred thousand aeons, and one aspiring to the awakening of a great disciple for a hundred thousand aeons. Would they need to cultivate the perfections throughout those periods? Consider this again. It is precisely because of being unable to accept that the truth of origin accumulated in the past…


<a id="M05-body-P029"></a>
## Suy luận và trực chứng / Inference and direct experience
Miến / Burmese 29

**VI**
…làm cho các pháp thuộc vòng quả, tức khổ đế, hiện khởi rõ ràng trong đời này.

**EN**
…brings forth the phenomena of the round of results, the truth of suffering, clearly in this life.

**VI**
Suy luận và trực chứng (anumāna và paccakkha)

**EN**
Inference and direct experience (anumāna and paccakkha)

**VI**
Giả sử thiện hữu chấp nhận rằng: “Quá khứ đã diệt, nay không còn. Tương lai chưa đến, nên chưa hiện khởi. Vì vậy, hành giả chỉ có thể quán quá khứ và tương lai bằng cách suy đoán, tức bằng suy luận.”

**EN**
Suppose a good person accepts the following: “The past has ceased and no longer exists. The future has yet to arrive and has yet to arise. Therefore a meditator can discern the past and future only by conjecture, that is, by inference.”

**VI**
Tương tự, giả sử vị ấy chấp nhận rằng hành giả chỉ có thể quán bằng suy luận cách năm quả hiện tại phát sinh do năm nhân quá khứ, và cách năm quả tương lai phát sinh do năm nhân hiện tại.

**EN**
Likewise, suppose one accepts that a meditator can discern only by inference how the five present results arise due to the five past causes and how the five future results arise due to the five present causes.

**VI**
Nếu chấp nhận như vậy, thì hàm ý rằng các bậc thánh, đặc biệt các vị đại thánh đệ tử đứng đầu là Tôn giả Ānanda và các vị khác, cũng chỉ biết mối liên hệ nhân quả của Duyên khởi và cách khổ đế sinh do tập đế bằng suy luận. Đó là hệ quả của cách nói ấy. Tuy nhiên, trong các bài kinh do Đức Phật thuyết và trong các chú giải, có lời như sau.

**EN**
Accepting this would imply that the noble ones, especially such foremost great noble disciples as Venerable Ānanda, knew the causal connection of dependent origination and how suffering arises from its origin only by inference. That is the implication of the claim. The Buddha’s discourses and the commentaries say the following.

**VI**
Idha, bhikkhave, bhikkhu “idaṃ dukkhan”ti yathābhūtaṃ pajānāti, “ayaṃ dukkhasamudayo”ti yathābhūtaṃ pajānāti, “ayaṃ dukkhanirodho”ti yathābhūtaṃ pajānāti, “ayaṃ dukkhanirodhagāminī paṭipadā”ti yathābhūtaṃ pajānāti. (Majjhima, tập 1, tr. 82.)

**EN**
Idha, bhikkhave, bhikkhu “idaṃ dukkhan”ti yathābhūtaṃ pajānāti, “ayaṃ dukkhasamudayo”ti yathābhūtaṃ pajānāti, “ayaṃ dukkhanirodho”ti yathābhūtaṃ pajānāti, “ayaṃ dukkhanirodhagāminī paṭipadā”ti yathābhūtaṃ pajānāti. (Majjhima, vol. 1, p. 82.)


<a id="M05-body-P030"></a>
## Biết bốn Thánh đế đúng như thật / Knowing the four noble truths as they really are
Miến / Burmese 30

**VI**
Này các tỳ-khưu, ở đây, vị tỳ-khưu hành thiền trong giáo pháp này biết phân minh, đúng như thật và không sai lệch: “Đây là Thánh đế về khổ.” Vị ấy biết phân minh, đúng như thật và không sai lệch: “Đây là Thánh đế về nguyên nhân sinh khổ.” Vị ấy biết phân minh, đúng như thật và không sai lệch: “Đây là Thánh đế về sự diệt khổ.” Vị ấy biết phân minh, đúng như thật và không sai lệch: “Đây là Thánh đế về con đường dẫn đến Niết-bàn, nơi khổ chấm dứt.” (Majjhima, tập 1, tr. 82.)

**EN**
Bhikkhus, here a meditating bhikkhu in this dispensation knows distinctly, as it really is and without distortion: “This is the noble truth of suffering.” The bhikkhu knows distinctly, as it really is and without distortion: “This is the noble truth of the origin of suffering.” The bhikkhu knows distinctly, as it really is and without distortion: “This is the noble truth of the cessation of suffering.” The bhikkhu knows distinctly, as it really is and without distortion: “This is the noble truth of the way to Nibbāna, where suffering ceases.” (Majjhima, vol. 1, p. 82.)

**VI**
Trong những bài kinh như vậy, các bậc thánh được nói là tự mình trực tiếp thấu suốt bốn Thánh đế đúng như thật bằng tuệ chánh kiến. Các bài kinh ấy không nói rằng các vị chỉ biết bằng cách suy đoán, tức bằng suy luận.

**EN**
In such discourses, the noble ones are said to penetrate the four noble truths personally, directly, and as they really are through the wisdom of right view. The discourses do not say that the noble ones know them only by conjecture, that is, by inference.

**VI**
“Ayaṃ lokiyo, ayaṃ lokuttaro”ti ariyaṃ aṭṭhaṅgikaṃ maggaṃ yathābhūtaṃ na pajānāti, ajānanto lokiyamagge abhinivisitvā lokuttaraṃ nibbattetuṃ na sakkoti. (Chú giải Majjhima, tập 2, tr. 165.)

**EN**
“Ayaṃ lokiyo, ayaṃ lokuttaro”ti ariyaṃ aṭṭhaṅgikaṃ maggaṃ yathābhūtaṃ na pajānāti, ajānanto lokiyamagge abhinivisitvā lokuttaraṃ nibbattetuṃ na sakkoti. (Majjhima Commentary, vol. 2, p. 165.)

**VI**
Nếu hành giả không biết phân minh, đúng như thật và không sai lệch bằng tuệ chánh kiến rằng “đây là đạo đế hiệp thế, đây là Thánh đế về đạo siêu thế”, tức con đường cao quý gồm tám chi, thì vị ấy không thể đặt minh sát vào đạo đế hiệp thế, hay tu tập đạo đế hiệp thế, để làm sinh khởi Thánh đế về đạo siêu thế. (Chú giải Majjhima, tập 2, tr. 165.)

**EN**
If a meditator fails to know distinctly, as it really is and without distortion through the wisdom of right view, “This is the mundane truth of the path, and this is the supramundane noble truth of the path,” that is, the noble path of eight factors, they cannot engage insight in the mundane truth of the path, or develop that mundane path so as to bring forth the supramundane noble truth of the path. (Majjhima Commentary, vol. 2, p. 165.)

**VI**
Chỉ khi hành giả tự mình trực tiếp thấu suốt bằng tuệ chánh kiến đúng như thật cả các pháp thuộc khổ đế và tập đế, lẫn cách khổ đế sinh do tập đế…

**EN**
Only when a meditator personally and directly penetrates with the wisdom of right view, as they really are, both the phenomena of the truths of suffering and origin and how the truth of suffering arises due to the truth of origin…


<a id="M05-body-P031"></a>
## Hai đế thuộc luân hồi và hai đế thoát luân hồi / Two truths of the round and two truths of release from the round
Miến / Burmese 31

**VI**
…thì mới có thể đặt các pháp thuộc khổ đế và tập đế dưới ba đặc tướng mà tu tập đề mục minh sát. Nỗ lực tu tập như vậy chính là tu tập đạo đế. Chỉ khi tu tập đạo đế hiệp thế mới có thể đạt đạo đế siêu thế và diệt đế siêu thế. Hãy đọc phần giải thích của chú giải sau đây.

**EN**
…can one examine the phenomena of the truths of suffering and origin in terms of the three characteristics and develop the subject of insight meditation. Such effort in cultivation is the development of the truth of the path. Only by developing the mundane truth of the path can one reach the supramundane truths of the path and cessation. Read the following explanation from the commentary.

**VI**
Tattha purimāni dve saccāni vaṭṭaṃ, pacchimāni vivaṭṭaṃ. Tesu bhikkhuno vaṭṭe kammaṭṭhānābhiniveso hoti, vivaṭṭe natthi abhiniveso. (Chú giải Abhidhamma, tập 2, tr. 109.)

**EN**
Tattha purimāni dve saccāni vaṭṭaṃ, pacchimāni vivaṭṭaṃ. Tesu bhikkhuno vaṭṭe kammaṭṭhānābhiniveso hoti, vivaṭṭe natthi abhiniveso. (Abhidhamma Commentary, vol. 2, p. 109.)

**VI**
Trong bốn đế ấy, hai đế đầu là khổ đế và tập đế thuộc luân hồi. Hai đế sau là diệt đế và đạo đế thuộc phần thoát luân hồi. Trong hai nhóm ấy, vị tỳ-khưu hành thiền đặt đề mục minh sát vào các đế thuộc luân hồi. Vị ấy không đặt đề mục minh sát vào các đế thuộc phần thoát luân hồi. Ở đây đạo đế thuộc phần thoát luân hồi là đạo đế siêu thế.

**EN**
Of the four truths, the first two, suffering and origin, belong to the round. The last two, cessation and the path, belong to release from the round. Of these two groups, the meditating bhikkhu engages in insight meditation on the truths belonging to the round. The bhikkhu does not engage in insight meditation on the truths belonging to release from the round. Here the truth of the path belonging to release from the round means the supramundane truth of the path.

**VI**
Theo lời giải thích của chú giải này, hành giả tu tập đề mục minh sát trên hai đế hiệp thế là khổ đế và tập đế. Chỉ khi có thể quán sát và tu tập minh sát thấu đáo trên hai đế hiệp thế này thì hai đế siêu thế mới có thể hiện khởi rõ ràng. Nếu chưa biết cả bốn đế thì điều gì có thể xảy ra?

**EN**
According to these commentarial explanations, a meditator develops the subject of insight meditation on the two mundane truths, suffering and origin. Only when one can discern and develop insight thoroughly into these two mundane truths can the two supramundane truths become manifest. What can happen if the four truths have yet to be known?

**VI**
Trích Kinh Nhà Có Nóc Nhọn (Kūṭāgārasutta)

**EN**
An excerpt from the Discourse on the Peaked House (Kūṭāgārasutta)

**VI**
Yo ca kho, bhikkhave, evaṃ vadeyya: “Ahaṃ dukkhaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca, dukkhasamudayaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca…

**EN**
Yo ca kho, bhikkhave, evaṃ vadeyya: “Ahaṃ dukkhaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca, dukkhasamudayaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca…


<a id="M05-body-P032"></a>
## Điều kiện để chấm dứt khổ / The condition for making an end of suffering
Miến / Burmese 32

**VI**
…dukkhanirodhaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca, dukkhanirodhagāminiṃ paṭipadaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca sammā dukkhassantaṃ karissāmī”ti, netaṃ ṭhānaṃ vijjati. (Saṃyutta, tập 3, tr. 394.)

**EN**
…dukkhanirodhaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca, dukkhanirodhagāminiṃ paṭipadaṃ ariyasaccaṃ yathābhūtaṃ anabhisamecca sammā dukkhassantaṃ karissāmī”ti, netaṃ ṭhānaṃ vijjati. (Saṃyutta, vol. 3, p. 394.)

**VI**
Yo ca kho, bhikkhave, evaṃ vadeyya: “Ahaṃ dukkhaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca, dukkhasamudayaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca, dukkhanirodhaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca, dukkhanirodhagāminiṃ paṭipadaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca sammā dukkhassantaṃ karissāmī”ti, ṭhānametaṃ vijjati. (Saṃyutta, tập 3, tr. 394.)

**EN**
Yo ca kho, bhikkhave, evaṃ vadeyya: “Ahaṃ dukkhaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca, dukkhasamudayaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca, dukkhanirodhaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca, dukkhanirodhagāminiṃ paṭipadaṃ ariyasaccaṃ yathābhūtaṃ abhisamecca sammā dukkhassantaṃ karissāmī”ti, ṭhānametaṃ vijjati. (Saṃyutta, vol. 3, p. 394.)

**VI**
Này các tỳ-khưu, giả sử có người nói: “Tôi sẽ hoàn toàn chấm dứt khổ luân hồi dù chưa tự mình trực tiếp thấu suốt đúng như thật, không sai lệch, bằng tuệ chánh kiến, Thánh đế về khổ, Thánh đế về nguyên nhân sinh khổ, Thánh đế về sự diệt khổ và Thánh đế về con đường dẫn đến Niết-bàn, nơi khổ chấm dứt.” Người ấy nói như vậy thì không có trường hợp lời nói ấy có thể thành sự thật. (Saṃyutta, tập 3, tr. 394.)

**EN**
Bhikkhus, suppose someone says: “I will make a complete end of the suffering of saṃsāra even though I have yet to penetrate personally and directly, as they really are and without distortion through the wisdom of right view, the noble truths of suffering, its origin, its cessation, and the path leading to Nibbāna, where suffering ceases.” There is no possibility of that person’s statement coming true. (Saṃyutta, vol. 3, p. 394.)

**VI**
Này các tỳ-khưu, giả sử có người nói: “Sau khi tự mình trực tiếp thấu suốt đúng như thật, không sai lệch, bằng tuệ chánh kiến, Thánh đế về khổ và Thánh đế về nguyên nhân sinh khổ…

**EN**
Bhikkhus, suppose someone says: “Having personally and directly penetrated, as they really are and without distortion through the wisdom of right view, the noble truth of suffering and the noble truth of its origin…


<a id="M05-body-P033"></a>
## Nỗ lực trực chứng bốn Thánh đế / Striving to realize the four noble truths directly
Miến / Burmese 33

**VI**
…và sau khi tự mình trực tiếp thấu suốt đúng như thật, không sai lệch, bằng tuệ chánh kiến, Thánh đế về sự diệt khổ và Thánh đế về con đường dẫn đến Niết-bàn, nơi khổ chấm dứt, tôi sẽ hoàn toàn chấm dứt khổ luân hồi.” Người ấy nói như vậy thì có trường hợp lời nói ấy có thể thành sự thật. (Saṃyutta, tập 3, tr. 394–395.)

**EN**
…and having personally and directly penetrated, as they really are and without distortion through the wisdom of right view, the noble truth of the cessation of suffering and the noble truth of the path leading to Nibbāna, where suffering ceases, I will make a complete end of the suffering of saṃsāra.” There is a possibility of that person’s statement coming true. (Saṃyutta, vol. 3, pp. 394–395.)

**VI**
Theo những lời dạy này, để chấm dứt hẳn nỗi khổ lớn của luân hồi và hoàn toàn thoát khỏi nỗi khổ ấy, thiện hữu phải gắng sức tự mình trực tiếp thấu suốt bốn đế bằng tuệ chánh kiến. Khi gắng sức như vậy, trước hết phải cố gắng biết rõ các pháp thuộc khổ đế và tập đế, cách khổ đế sinh do tập đế, và các tướng vô thường, khổ, vô ngã của các pháp thuộc hai đế ấy. Chỉ khi đó, ở chặng cuối của các tuệ minh sát đã chín muồi, hai đế siêu thế là diệt đế và đạo đế mới có thể hiện khởi. Vì thế, để trực tiếp thấu suốt cả bốn đế bằng con mắt tuệ chánh kiến, thiện hữu hãy ghi nhớ rằng phải nỗ lực biết rõ từng mối liên hệ nhân quả của Duyên khởi bằng ba loại tuệ liễu tri.

**EN**
In accordance with these teachings, to make a definitive end of the great suffering of saṃsāra and escape it completely, a good person must strive to penetrate the four truths personally and directly with the wisdom of right view. In striving thus, first make an effort to know the phenomena belonging to suffering and its origin, how suffering arises due to its origin, and the characteristics of impermanence, suffering, and non-self in the phenomena of those two truths. Only then, at the culmination of mature insight knowledge, can the two supramundane truths of cessation and the path arise. Therefore, to penetrate all four truths directly with the eye of the wisdom of right view, a good person should remember to strive to know clearly each causal connection of dependent origination through the three kinds of full understanding.


<a id="M05-body-P034"></a>
## Để đạt trí nắm bắt các duyên / To attain knowledge of discerning conditions
Miến / Burmese 34

**VI**
Vipassakena pana kammassa ca vipākassa ca ekadesato jānitabbaṃ. (Thanh tịnh đạo, tập 2, tr. 237.)

**EN**
Vipassakena pana kammassa ca vipākassa ca ekadesato jānitabbaṃ. (Visuddhimagga, vol. 2, p. 237.)

**VI**
Ekadesato jānitabbaṃ, anavasesato jānituṃ na sakkā avisayattā. Sabbena sabbaṃ ajānane paccayapariggaho na paripūrati. (Đại phụ chú giải Thanh tịnh đạo, tập 2, tr. 380.)

**EN**
Ekadesato jānitabbaṃ, anavasesato jānituṃ na sakkā avisayattā. Sabbena sabbaṃ ajānane paccayapariggaho na paripūrati. (Visuddhimagga Great Subcommentary, vol. 2, p. 380.)

**VI**
Người đang nỗ lực tu tập đề mục minh sát cần biết một phần những sai biệt của các nghiệp, chẳng hạn nghiệp có sức hay không có sức, và những sai biệt của quả, chẳng hạn quả thấp kém hay cao quý. Biết nghiệp và quả của nghiệp một cách toàn diện, không sót gì, vượt ngoài phạm vi của các vị đệ tử. Đó là phạm vi của chư Phật Chánh Đẳng Giác có trí toàn giác. Tuy nhiên, nếu hoàn toàn không biết gì về nghiệp và quả của nghiệp, thì trí nắm bắt các duyên không thể viên mãn. (Thanh tịnh đạo, tập 2, tr. 237. Đại phụ chú giải Thanh tịnh đạo, tập 2, tr. 380.)

**EN**
One striving to cultivate the subject of insight meditation should know to some extent the distinctions among deeds, such as whether they are strong or weak, and among their results, such as whether they are inferior or superior. To know kamma and its results completely, without remainder, lies beyond the disciples’ range. It is the domain of perfectly awakened Buddhas endowed with omniscience. Yet if one knows nothing whatsoever about kamma and its results, knowledge of discerning conditions cannot be fulfilled. (Visuddhimagga, vol. 2, p. 237. Visuddhimagga Great Subcommentary, vol. 2, p. 380.)

**VI**
Vì hoàn toàn không biết nghiệp và quả của nghiệp thì không thể có trí nắm bắt các duyên, nên để đạt trí ấy, thiện hữu phải nỗ lực biết nghiệp và quả của nghiệp ít nhất một phần. Ở đây, trí nắm bắt các duyên cũng chính là trí biết cách khổ đế sinh do tập đế.

**EN**
Since knowledge of discerning conditions cannot be attained without any knowledge of kamma and its results, a good person who wishes to attain it must strive to know kamma and its results at least in part. Here knowledge of discerning conditions is also the knowledge of how the truth of suffering arises due to the truth of origin.

**VI**
Thiện hữu có thể đã biết hoặc đã nghe rằng Đức Phật có ba mươi hai tướng của bậc đại nhân. Trong số ấy, mỗi tướng…

**EN**
A good person may already know or have heard that the Buddha had the thirty-two marks of a great person. Among them, each mark…


<a id="M05-body-P035"></a>
## Nghiệp riêng, quả riêng, và hai cách biết quá khứ / Distinct deeds, distinct results, and two ways of knowing the past
Miến / Burmese 35

**VI**
…có nghiệp tương ứng riêng đã cho quả. Tướng đỉnh đầu, tướng răng và tướng lưỡi đều do nghiệp riêng tương ứng mà có. Nghiệp làm nhân và tướng làm quả được phân biệt như vậy. Tương tự, trong một đời, những quả tốt và xấu một người gặp có rất nhiều loại. Quả tốt do nghiệp thiện, quả xấu do nghiệp bất thiện. Các loại quả tốt khác nhau có những nghiệp thiện tương ứng làm chúng sinh khởi. Các loại quả xấu khác nhau cũng có những nghiệp bất thiện tương ứng làm chúng sinh khởi. Các vị đệ tử không thể biết hết từng loại nghiệp và từng loại quả. Các vị chỉ có thể biết một phần.

**EN**
…has its own corresponding deed that gave that result. The marks of the head, the teeth, and the tongue each arise from their own corresponding deeds. Causal deeds and their resulting marks are distinguished in this way. Likewise, in a single life a person encounters many kinds of favorable and unfavorable results. Favorable results come from wholesome kamma, and unfavorable results from unwholesome kamma. Different favorable results have corresponding wholesome deeds that bring them about. Different unfavorable results likewise have corresponding unwholesome deeds that bring them about. Disciples cannot know every kind of kamma and every kind of result. They can know only a part.

**VI**
Thắng trí và minh sát

**EN**
Direct knowledge and insight

**VI**
Các bản văn có nói rằng với túc mạng minh, tức thắng trí nhớ lại đời trước (pubbenivāsānussati-abhiññā), có thể quán quá khứ. Các bản văn cũng nói rằng với trí biết tương lai (anāgataṃsañāṇa), một phương diện của thắng trí thiên nhãn, có thể quán tương lai. Những điều ấy dễ được chấp nhận. Nhưng người ta không muốn chấp nhận rằng bằng tuệ minh sát cũng có thể quán các uẩn quá khứ và tương lai. Về khả năng quán các thủ uẩn quá khứ và tương lai bằng tuệ minh sát, lời Phật trong Pāli và lời giải thích của chú giải như sau.

**EN**
The texts say that with the direct knowledge of recollecting former lives (pubbenivāsānussati-abhiññā), one can discern the past. They also say that with knowledge of the future (anāgataṃsañāṇa), an aspect of the direct knowledge of the divine eye, one can discern the future. These points are readily accepted. Yet people are reluctant to accept that the past and future aggregates can also be discerned with insight knowledge. Concerning the ability to discern the past and future aggregates subject to clinging with insight knowledge, the Buddha’s words in Pāli and the commentarial explanation are as follows.


<a id="M05-body-P036"></a>
## Nhớ lại đời trước theo Kinh Khajjanīya / Recollecting former lives in the Khajjanīya Sutta
Miến / Burmese 36

**VI**
Ye hi keci, bhikkhave, samaṇā vā brāhmaṇā vā anekavihitaṃ pubbenivāsaṃ anussaramānā anussaranti, sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataraṃ. (Saṃyutta, tập 2, tr. 71. Khajjanīyasutta.)

**EN**
Ye hi keci, bhikkhave, samaṇā vā brāhmaṇā vā anekavihitaṃ pubbenivāsaṃ anussaramānā anussaranti, sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataraṃ. (Saṃyutta, vol. 2, p. 71. Khajjanīyasutta.)

**VI**
Pubbenivāsanti na idaṃ abhiññāvasena anussaraṇaṃ sandhāya vuttaṃ. Vipassanāvasena pana pubbenivāsaṃ anussaraṇe samaṇabrāhmaṇe sandhāyetaṃ vuttaṃ. Tenevāha “sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataran”ti. Abhiññāvasena hi samanussarantassa khandhāpi upādānakkhandhāpi khandhapaṭibaddhāpi paññattipi ārammaṇaṃ hotiyeva. Rūpaṃyeva anussaratīti evaṃ hi anussaraṇena na aññaṃ kiñci sattaṃ vā puggalaṃ vā anussarati, atīte pana niruddhaṃ rūpakkhandhameva anussarati. Vedanādīsupi eseva nayo. (Chú giải Saṃyutta, tập 2, tr. 266.)

**EN**
Pubbenivāsanti na idaṃ abhiññāvasena anussaraṇaṃ sandhāya vuttaṃ. Vipassanāvasena pana pubbenivāsaṃ anussaraṇe samaṇabrāhmaṇe sandhāyetaṃ vuttaṃ. Tenevāha “sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataran”ti. Abhiññāvasena hi samanussarantassa khandhāpi upādānakkhandhāpi khandhapaṭibaddhāpi paññattipi ārammaṇaṃ hotiyeva. Rūpaṃyeva anussaratīti evaṃ hi anussaraṇena na aññaṃ kiñci sattaṃ vā puggalaṃ vā anussarati, atīte pana niruddhaṃ rūpakkhandhameva anussarati. Vedanādīsupi eseva nayo. (Saṃyutta Commentary, vol. 2, p. 266.)

**VI**
Này các tỳ-khưu, bất cứ sa-môn hay bà-la-môn nào nhớ lại nhiều đời sống trước và lần theo dòng các uẩn ấy bằng trí, nếu có nhớ lại được thì họ nhớ lại theo dòng ấy bằng trí. Tất cả những sa-môn và bà-la-môn nhớ lại được như vậy đều nhớ lại năm thủ uẩn, hoặc một uẩn trong năm thủ uẩn ấy. (Saṃyutta, tập 2, tr. 71.)

**EN**
Bhikkhus, whatever ascetics or brahmins recollect many former lives and follow that succession of aggregates with knowledge, when they succeed in recollecting they do so by following that succession with knowledge. All those ascetics and brahmins who recollect in this way recollect the five aggregates subject to clinging or one of those five. (Saṃyutta, vol. 2, p. 71.)

**VI**
Trong đoạn Pāli này, Đức Phật dùng chữ pubbenivāsa, “đời sống trước”, với ý chỉ sự nhớ lại bằng cách dùng trí lần theo dòng các uẩn. Ý ở đây là các sa-môn và bà-la-môn dùng tuệ minh sát để lần theo dòng các uẩn của những đời trước và nhớ lại…

**EN**
In this Pāli passage, the Buddha uses the word pubbenivāsa, “former lives”, with reference to recollecting by tracing the succession of aggregates with knowledge. The reference here is to ascetics and brahmins who use insight knowledge to trace the succession of the aggregates of former lives and recollect…


<a id="M05-body-P037"></a>
## Các đối tượng của thắng trí nhớ đời trước / The objects of direct knowledge of former lives
Miến / Burmese 37

**VI**
…nên Đức Phật dùng chữ pubbenivāsa theo ý ấy. Chính vì vậy, Ngài nói tiếp như sau.

**EN**
…and so the Buddha uses the word pubbenivāsa in that sense. It is for this reason that he goes on to say the following.

**VI**
Sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataraṃ.

**EN**
Sabbe te pañcupādānakkhandhe anussaranti etesaṃ vā aññataraṃ.

**VI**
Tất cả những sa-môn và bà-la-môn ấy đều có thể dùng trí lần theo và nhớ lại năm thủ uẩn. Họ cũng có thể dùng trí lần theo và nhớ lại riêng một uẩn trong năm thủ uẩn ấy. (Saṃyutta, tập 2, tr. 71.)

**EN**
All those ascetics and brahmins can trace and recollect with knowledge the five aggregates subject to clinging. They can also trace and recollect with knowledge just one of those five. (Saṃyutta, vol. 2, p. 71.)

**VI**
Đức Phật đã dạy như vậy. Lý do là thế này. Đối với các sa-môn và bà-la-môn dùng sức thắng trí nhớ đời trước để lần theo dòng các uẩn của những đời trước, các cảnh của thắng trí ấy có bốn loại:
1. Năm uẩn, kể cả các pháp siêu thế.
2. Năm thủ uẩn, trong đó không có các pháp siêu thế.
3. Những gì liên hệ với các uẩn, như dòng họ, sắc diện, thức ăn, vui và khổ.
4. Các tên gọi, tức những chế định khác nhau.

**EN**
The Buddha taught in this way for the following reason. For ascetics and brahmins who trace the succession of the aggregates in former lives through the power of direct knowledge of former lives, that direct knowledge has four kinds of objects:
1. The five aggregates, including supramundane phenomena.
2. The five aggregates subject to clinging, which exclude supramundane phenomena.
3. Things connected with the aggregates, such as clan, appearance, food, pleasure, and pain.
4. Names, that is, various concepts.

**VI**
Đức Phật không nói ở đây rằng người ta có thể dùng trí lần theo và nhớ lại cả bốn loại cảnh ấy. Ngài chỉ nói rằng họ có thể dùng trí lần theo và nhớ lại năm thủ uẩn hay một uẩn trong số đó. Vì thế, ở đây Đức Phật có ý nói đến sự dùng trí lần theo và nhớ lại dòng các uẩn của những đời trước…

**EN**
Here the Buddha does not say that all four kinds of objects can be traced and recollected with knowledge. He says only that they can trace and recollect the five aggregates subject to clinging, or one of them. Thus what the Buddha has in mind here is tracing and recollecting the succession of the aggregates of former lives…


<a id="M05-body-P038"></a>
## Quán các uẩn quá khứ bằng tuệ minh sát / Discerning past aggregates with insight knowledge
Miến / Burmese 38

**VI**
…bằng tuệ minh sát. Khi dùng tuệ minh sát lần theo và nhớ lại dòng các uẩn của những đời trước như vậy, hành giả không lần theo và nhớ lại một cá nhân, chúng sinh hay con người nào. Hành giả có thể dùng tuệ minh sát lần theo và nhớ lại sắc, thọ, tưởng, hành và thức đã diệt trong quá khứ. Ý ở đây là như vậy. (Saṃyutta, tập 2, tr. 71. Chú giải Saṃyutta, tập 2, tr. 266.)

**EN**
…with insight knowledge. When a meditator thus traces and recollects the succession of the aggregates of former lives with insight knowledge, they do not trace and recollect any individual, being, or person. With insight knowledge they can trace and recollect materiality, feeling, perception, formations, and consciousness that ceased in the past. That is the meaning here. (Saṃyutta, vol. 2, p. 71. Saṃyutta Commentary, vol. 2, p. 266.)

**VI**
Trên đây là một đoạn trong lời dạy trực tiếp của Đức Phật cùng lời giải thích của chú giải, cho thấy sự khác biệt giữa thắng trí nhớ đời trước và tuệ minh sát, và làm căn cứ cho việc dùng tuệ minh sát để quán quá khứ và tương lai.

**EN**
This passage of the Buddha’s direct teaching and its commentarial explanation shows the distinction between direct knowledge of former lives and insight knowledge, and provides a textual basis for discerning past and future with insight knowledge.

**VI**
Ở đây, thiện hữu cũng nên suy xét thêm rằng các vị A-la-hán thuộc hạng thuần quán (sukkhavipassaka), tức lấy thuần minh sát làm cỗ xe (suddhavipassanāyānika), cũng đã tự mình trực tiếp thấu suốt bốn Thánh đế bằng tuệ chánh kiến. Thiện hữu hãy nỗ lực để đi đúng theo lời dạy chân thật trong giáo pháp của Đức Phật.

**EN**
A good person should also consider that arahants who are dry-insight practitioners (sukkhavipassaka), that is, those who take pure insight as their vehicle (suddhavipassanāyānika), have likewise personally and directly penetrated the four noble truths with the wisdom of right view. Let a good person strive to follow the true teaching of the Buddha’s dispensation.


<a id="M05-body-P039"></a>
## Phần 2. Một trình tự tìm các nhân / Part 2. A procedure for finding the causes
Miến / Burmese 39

**VI**
Paccayapariggahe paññā dhammaṭṭhitiñāṇaṃ. (Paṭisambhidāmagga, tr. 1.)

**EN**
Paccayapariggahe paññā dhammaṭṭhitiñāṇaṃ. (Paṭisambhidāmagga, p. 1.)

**VI**
“Nāmarūpavavatthāne ñāṇan”ti avatvā eva kasmā “dhammaṭṭhitiñāṇan”ti vuttanti ce? Paccayapariggaheneva paccayasamuppannapariggahitattā siddhattaṃ. Paccayasamuppanne hi apariggahite paccayapariggaho na sakkā hoti kātuṃ. Tasmā dhammaṭṭhitiñāṇaggahaṇeneva tassa hetubhūtaṃ pubbe siddhaṃ nāmarūpavavatthānañāṇaṃ vuttameva hotīti veditabbaṃ. (Chú giải Paṭisambhidāmagga, tập 1, tr. 18.)

**EN**
“Nāmarūpavavatthāne ñāṇan”ti avatvā eva kasmā “dhammaṭṭhitiñāṇan”ti vuttanti ce? Paccayapariggaheneva paccayasamuppannapariggahitattā siddhattaṃ. Paccayasamuppanne hi apariggahite paccayapariggaho na sakkā hoti kātuṃ. Tasmā dhammaṭṭhitiñāṇaggahaṇeneva tassa hetubhūtaṃ pubbe siddhaṃ nāmarūpavavatthānañāṇaṃ vuttameva hotīti veditabbaṃ. (Paṭisambhidāmagga Commentary, vol. 1, p. 18.)

**VI**
Các nhân có khả năng làm cho các quả hiện khởi. Vì năng lực ấy hiện hữu nên nói các nhân có thể nâng đỡ các quả. Do các quả tồn tại và sinh khởi nhờ các nhân, những nhân ấy là chỗ đứng của các quả, gọi là dhammaṭṭhiti. Trí thấu suốt các nhân làm chỗ đứng cho các quả ấy gọi là trí biết sự tồn tại của các pháp do duyên (dhammaṭṭhitiñāṇa).

**EN**
Causes have the power to bring about results. Because that power is present, the causes are said to support the results. Since the results stand and arise owing to their causes, those causes are the standing ground of the results, called dhammaṭṭhiti. The knowledge that penetrates the causes on which the results stand is called knowledge of the conditioned standing of phenomena (dhammaṭṭhitiñāṇa).

**VI**
Nếu hỏi vì sao ở đây nói trí biết sự tồn tại của các pháp do duyên, mà không nói trí phân định danh sắc (nāmarūpavavatthānañāṇa)…

**EN**
If one asks why this passage speaks of knowledge of the conditioned standing of phenomena without mentioning the knowledge that defines mentality and materiality (nāmarūpavavatthānañāṇa)…


<a id="M05-body-P040"></a>
## Quán các quả trước khi tìm nhân / Apprehending results before looking for causes
Miến / Burmese 40

**VI**
…thì câu trả lời như sau.

**EN**
…the answer is as follows.

**VI**
Quán được các nhân hàm ý rằng việc quán các quả đã thành tựu. Quả thật, khi chưa quán các quả, không thể tiến hành quán các nhân. Tuy nhân thực sự có khả năng sinh quả, chỉ khi phân định và quán bằng trí những quả sinh do nhân ấy mới có thể biết rằng nhân đó có khả năng sinh quả. Vì thế, khi trực tiếp nêu trí biết sự tồn tại của các pháp do duyên, cũng đã nêu trí phân định danh sắc, vốn là nhân gốc của trí ấy và đã thành tựu từ trước. Hãy hiểu như vậy. (Chú giải Paṭisambhidāmagga, tập 1, tr. 18.)

**EN**
To have apprehended the causes implies that apprehending the results has already been accomplished. Indeed, without first apprehending the results, one cannot carry out the apprehension of the causes. A cause truly has the power to produce a result, but only by distinguishing and apprehending with knowledge the results that arise owing to it can one know that the cause has that power. Therefore, directly mentioning knowledge of the conditioned standing of phenomena also implies the knowledge that defines mentality and materiality, which is its underlying cause and has already been accomplished. This is how it should be understood. (Paṭisambhidāmagga Commentary, vol. 1, p. 18.)

**VI**
Theo lời giải thích của chú giải này, hành giả muốn phân định bằng trí và quán các nhân (paccayapariggaha) phải cố gắng trước hết quán và phân định sắc pháp, danh pháp làm quả, tức các pháp được trợ (paccayasamuppanna). Đây gọi là trí phân định danh sắc (nāmarūpavavatthānañāṇa). Ý chính như sau. Khi hành giả muốn phân định và quán các nhân quá khứ, cần quán cả sắc pháp và danh pháp hiện tại, tức các pháp được trợ hiện khởi do các nhân quá khứ, lẫn sắc pháp và danh pháp quá khứ được trợ, vốn là nơi nương của các nhân quá khứ ấy…

**EN**
According to this commentarial explanation, a meditator wishing to distinguish and apprehend the causes with knowledge (paccayapariggaha) must first strive to apprehend and distinguish the resultant material and mental phenomena, the conditioned phenomena (paccayasamuppanna). This is called knowledge that defines mentality and materiality (nāmarūpavavatthānañāṇa). The main point is this. When wishing to distinguish and apprehend past causes, one must apprehend both the present material and mental phenomena conditioned by the past causes and the past conditioned material and mental phenomena on which those past causes depended…


<a id="M05-body-P041"></a>
## Danh sắc quá khứ, hiện tại và tương lai / Mentality and materiality in the past, present, and future
Miến / Burmese 41

**VI**
…và đã phân định chúng bằng trí. Lại nữa, nếu hành giả muốn phân định và dùng tuệ quán xem năm quả tương lai, tức danh sắc được trợ, sinh do năm nhân hiện tại, thì cần quán và phân định cả danh sắc hiện tại là nơi nương của các nhân hiện tại như vô minh, ái, thủ, hành và nghiệp, lẫn danh sắc tương lai là năm quả sẽ hiện khởi do các nhân hiện tại.

**EN**
…and have distinguished them with knowledge. Again, if a meditator wishes to distinguish and apprehend with knowledge how the five future results, the conditioned mentality and materiality, arise due to the five present causes, one must apprehend and distinguish both the present mentality and materiality on which present causes such as ignorance, craving, clinging, formations, and kamma depend, and the future mentality and materiality constituting the five results that will arise due to those present causes.

**VI**
Năm quả hiện tại là một phần trong năm uẩn hiện tại. Năm nhân hiện tại cũng là một phần trong năm uẩn hiện tại. Tương tự, năm nhân quá khứ là một phần trong năm uẩn quá khứ và năm quả tương lai là một phần trong năm uẩn tương lai. Vì vậy, khi đã quán có hệ thống năm uẩn quá khứ, năm uẩn hiện tại và năm uẩn tương lai đến mức biết chúng là pháp chân đế, hành giả có thể dễ dàng quán những phần tương ứng là năm nhân quá khứ, năm quả hiện tại, năm nhân hiện tại và năm quả tương lai.

**EN**
The five present results form part of the five present aggregates. The five present causes also form part of the five present aggregates. Likewise, the five past causes form part of the five past aggregates, and the five future results form part of the five future aggregates. Thus, when one has systematically apprehended the five past, five present, and five future aggregates to the point of knowing them as ultimate realities, one can readily apprehend the corresponding portions: the five past causes, five present results, five present causes, and five future results.

**VI**
Nói cách khác, hành giả có thể dễ dàng quán và dùng trí phân định cách năm quả hiện tại hiện khởi do năm nhân quá khứ, và cách năm quả tương lai hiện khởi do năm nhân hiện tại. Hãy hiểu tương tự đối với các đời quá khứ nối tiếp và các đời tương lai nối tiếp. Vì vậy, trước khi quán xem các quả sinh do các nhân như thế nào, thiện hữu…

**EN**
In other words, one can readily apprehend and distinguish with knowledge how the five present results arise due to the five past causes and how the five future results arise due to the five present causes. Understand the same for successive past and successive future lives. Therefore, before apprehending how results arise due to causes, a good person…


<a id="M05-body-P042"></a>
## Bốn cách thuyết Duyên khởi / Four ways of teaching dependent origination
Miến / Burmese 42

**VI**
…hãy ghi nhớ trước hai điểm là phải quán năm uẩn quá khứ, năm uẩn hiện tại và năm uẩn tương lai. Pháp Duyên khởi là mối liên hệ nhân quả giữa các pháp sắc và danh được trợ, vốn tồn tại trong ba thời quá khứ, tương lai và hiện tại.

**EN**
…should first bear in mind the two points just made concerning the need to apprehend the five past, five present, and five future aggregates. Dependent origination is the causal connection between the conditioned mental and material phenomena occurring in the past, future, and present.

**VI**
Bốn cách thuyết pháp Duyên khởi

**EN**
Four ways of teaching dependent origination

**VI**
Trong Thanh tịnh đạo (tập 2, tr. 154–155) và phần giải về Duyên khởi trong Sammohavinodanī (Chú giải Abhidhamma, tập 2, tr. 124–125), các vị giải thích rõ rằng có bốn cách thuyết Duyên khởi, dùng ví dụ bốn cách nắm một dây leo (vallihārakanaya).

**EN**
The Visuddhimagga (vol. 2, pp. 154–155) and the explanation of dependent origination in the Sammohavinodanī (Abhidhamma Commentary, vol. 2, pp. 124–125) explain four ways of teaching dependent origination, using the simile of four ways of taking hold of a creeper (vallihārakanaya).

**VI**
1. Do vô minh có hành. Cứ như vậy, bài pháp được thuyết tiếp đến cách già chết sinh do sinh. Đây là cách thuyết Duyên khởi theo chiều thuận (anuloma), từ đầu đến cuối.

**EN**
1. Due to ignorance there are formations. The teaching proceeds in this way to how aging and death arise due to birth. This is a way of teaching dependent origination in forward order (anuloma), from the beginning to the end.

**VI**
2. Bắt đầu từ thọ ở giữa, Đức Phật thuyết mối liên hệ giữa nhân và quả đến cách sinh có do hữu. Đây cũng là một cách thuyết Duyên khởi theo chiều thuận, từ giữa đến cuối.

**EN**
2. Beginning with feeling in the middle, the Buddha teaches the causal connection through to how birth arises due to becoming. This too is a way of teaching dependent origination in forward order, from the middle to the end.


<a id="M05-body-P043"></a>
## Chiều nghịch và phương pháp thứ năm / Reverse order and the fifth method
Miến / Burmese 43

**VI**
3. Cũng có cách thuyết ngược, bắt đầu từ già chết do sinh làm nhân, rồi đi ngược đến hành do vô minh làm nhân. Đây là cách thuyết Duyên khởi theo chiều nghịch (paṭiloma), từ cuối về đầu.

**EN**
3. It is also taught in reverse, beginning with aging and death due to birth as their cause, and going back to formations due to ignorance as their cause. This is a way of teaching dependent origination in reverse order (paṭiloma), from the end to the beginning.

**VI**
4. Bốn loại vật thực sinh do ái. Ái sinh do thọ. Cứ như vậy, Đức Phật thuyết đến hành sinh do vô minh. Đây cũng là một cách thuyết Duyên khởi theo chiều nghịch, từ giữa về đầu.

**EN**
4. The four kinds of nutriment arise due to craving. Craving arises due to feeling. The Buddha teaches in this way back to formations arising due to ignorance. This too is a way of teaching dependent origination in reverse order, from the middle to the beginning.

**VI**
Trên đây là bốn cách thuyết Duyên khởi. Lại có một cách trong Pāli Paṭisambhidāmagga.

**EN**
These are the four ways of teaching dependent origination. A further method occurs in the Pāli Paṭisambhidāmagga.

**VI**
5. Bản văn Duyên khởi ấy trình bày cách năm quả hiện tại hiện khởi do năm nhân quá khứ và cách năm quả tương lai hiện khởi do năm nhân hiện tại.

**EN**
5. That text on dependent origination sets out how the five present results arise due to the five past causes and how the five future results arise due to the five present causes.

**VI**
Cách quán các nhân và các quả thành từng nhóm, như có trong Paṭisambhidāmagga, được gọi trong sách này là phương pháp thứ năm của Duyên khởi. Cách thứ năm dễ dạy cho một số hành giả còn yếu về trí căn bản của Abhidhamma.

**EN**
The method of apprehending the causes and effects in groups, as found in the Paṭisambhidāmagga, is called the fifth method of dependent origination in this book. The fifth method is readily taught to some meditators whose basic knowledge of Abhidhamma is still weak.

**VI**
Trong năm cách thuyết Duyên khởi này, thiện hữu có thể tìm các nhân và các quả bằng cách thuyết mình ưa thích. Trong các cách ấy, ở đây sẽ lấy cách thứ năm làm chính để trình bày cách quán mối liên hệ nhân quả…

**EN**
Among these five ways of teaching dependent origination, a good person can seek out the causes and effects by whichever method they prefer. Of these methods, the fifth is taken as the main one here in presenting how to apprehend the causal connection…


<a id="M05-body-P044"></a>
## Lần từ giữa về đầu và nguyên tắc nhiều nhân nhiều quả / Tracing from the middle to the beginning and the principle of many causes and results
Miến / Burmese 44

**VI**
…giữa nhân và quả. Trong phần bắt đầu tìm các nhân, dùng cách đi từ giữa về đầu.

**EN**
…between cause and effect. The search for causes begins by proceeding from the middle back to the beginning.

**VI**
Khi lần từ giữa về phía đầu để tìm các nhân, theo lời giải thích của Chú giải Paṭisambhidāmagga đã nêu ở trên, hành giả nào đã quán trước dòng năm uẩn liên tục từ năm uẩn hiện tại cho đến năm uẩn quá khứ sẽ thấy việc này dễ dàng hơn. Vì vậy, hãy quán năm uẩn, tức danh và sắc, từ năm uẩn hiện tại đến năm uẩn quá khứ. Để làm việc ấy, ở đây dựa vào cách quán dòng các uẩn quá khứ trong phần nói về thắng trí nhớ đời trước của Thanh tịnh đạo.

**EN**
In searching for causes by tracing from the middle toward the beginning, as explained above in the Paṭisambhidāmagga Commentary, meditators who have already apprehended the continuity of the five aggregates from the present five aggregates back to the past five aggregates will find this easier. Therefore, apprehend the five aggregates, that is, mentality and materiality, from the present back to the past. The procedure presented here draws on the way of apprehending the succession of past aggregates described in the Visuddhimagga section on direct knowledge of former lives.

**VI**
Sau khi quán dòng năm uẩn liên tục từ năm uẩn hiện tại đến năm uẩn quá khứ, hành giả cần lần theo và dùng tuệ quán xem năm uẩn hiện tại, tức các pháp quả, hiện khởi do năm nhân quá khứ cùng sinh trong năm uẩn quá khứ. Khi đã quán Duyên khởi thành công theo phương pháp thứ năm và có thể nối nhân với quả, các cách khác, như phương pháp thứ nhất của Duyên khởi, cũng trở nên rõ ràng và dễ hiểu đối với thiện hữu.

**EN**
After apprehending the continuity of the five aggregates from the present back to the past, the meditator needs to trace and apprehend with knowledge how the five present aggregates, the resultant phenomena, become manifest due to the five past causes that arose within the five past aggregates. Once one has successfully apprehended the fifth method of dependent origination and can connect causes with effects, other methods, such as the first method of dependent origination, also become clear and easy for a good person to understand.

**VI**
Một điểm cần biết trước

**EN**
A point to understand beforehand

**VI**
1. Ekato hi kāraṇato na idha kiñci ekaṃ phalamatthi.
2. Na anekaṃ.
3. Nāpi anekehi kāraṇehi ekaṃ.

**EN**
1. Ekato hi kāraṇato na idha kiñci ekaṃ phalamatthi.
2. Na anekaṃ.
3. Nāpi anekehi kāraṇehi ekaṃ.


<a id="M05-body-P045"></a>
## Vì sao bài pháp có khi chỉ nêu một nhân? / Why a teaching sometimes singles out one cause
Miến / Burmese 45

**VI**
4. Anekehi pana kāraṇehi anekameva hoti. (Chú giải Abhidhamma, tập 2, tr. 140. Thanh tịnh đạo, tập 2, tr. 174.)

**EN**
4. Anekehi pana kāraṇehi anekameva hoti. (Abhidhamma Commentary, vol. 2, p. 140. Visuddhimagga, vol. 2, p. 174.)

**VI**
1. Trong thế gian này, không có một quả đơn lẻ nào sinh do một nhân đơn lẻ.
2. Cũng không có nhiều quả sinh do một nhân đơn lẻ.
3. Cũng không có một quả đơn lẻ sinh do nhiều nhân.
4. Nói đúng theo thực tế, chỉ có nhiều quả sinh do nhiều nhân. (Chú giải Abhidhamma, tập 2, tr. 140. Thanh tịnh đạo, tập 2, tr. 174.)

**EN**
1. In this world, no single result arises from a single cause.
2. Nor do many results arise from a single cause.
3. Nor does a single result arise from many causes.
4. What actually occurs is that many results arise from many causes. (Abhidhamma Commentary, vol. 2, p. 140. Visuddhimagga, vol. 2, p. 174.)

**VI**
Trong bài pháp, Đức Phật có khi nêu một nhân hay một quả vì đó là yếu tố chính (padhāna), vì đó là yếu tố nổi bật (pākaṭa), hoặc vì đó là yếu tố riêng biệt (asādhāraṇa). Ngài nêu như vậy theo trí toàn giác, nhân để trình bày bài pháp cho rõ đẹp, và theo căn tính của chúng sinh có thể được giáo hóa, tức những người, chư thiên và phạm thiên có thể được dẫn dắt. (Chú giải Abhidhamma, tập 2, tr. 140. Thanh tịnh đạo, tập 2, tr. 174.)

**EN**
In a discourse the Buddha sometimes singles out a cause or a result because it is principal (padhāna), evident (pākaṭa), or distinctive (asādhāraṇa). He does so in accordance with omniscience, the basis for presenting a well-ordered teaching, and in keeping with the dispositions of the beings who can be taught, namely humans, deities, and brahmās who can be guided. (Abhidhamma Commentary, vol. 2, p. 140. Visuddhimagga, vol. 2, p. 174.)


<a id="M05-body-P046"></a>
## Quán cả những pháp tương ưng / Apprehending the associated phenomena as well
Miến / Burmese 46

**VI**
Theo lời giải thích trên, vì một yếu tố là chính, nổi bật hay riêng biệt, Đức Phật có thể lấy một nhân hoặc một quả như vô minh làm tiêu biểu khi thuyết pháp. Ngài làm như vậy theo trí toàn giác, nhờ đó có thể trình bày bài pháp cho rõ đẹp, và phù hợp với sở thích, căn tính và khuynh hướng của những người có thể được dẫn dắt. Tuy nhiên, một quả không thể sinh do một nhân đơn lẻ, nhiều quả không thể sinh do một nhân đơn lẻ, và một quả không thể sinh do nhiều nhân. Điều có thật là nhiều quả sinh do nhiều nhân.

**EN**
As explained above, because a factor is principal, evident, or distinctive, the Buddha may single out one cause or result, such as ignorance, when teaching. He does so in accordance with omniscience, by which he can present a well-ordered discourse, and to suit the preferences, dispositions, and inclinations of those who can be guided. Yet one result cannot arise from a single cause, many results cannot arise from a single cause, and one result cannot arise from many causes. What actually occurs is that many results arise from many causes.

**VI**
Không nên chấp rằng chỉ một pháp vô minh làm cho một mình hành sinh, rằng chỉ một mình sáu xứ làm cho một mình xúc sinh, hay rằng chỉ một xúc làm cho một thọ sinh. Hãy hiểu rằng nhiều quả sinh do nhiều nhân. Chỉ quán riêng từng pháp vô minh, xúc hay thọ là chưa đủ. Hãy ghi nhớ rằng cần quán cả những pháp tương ưng với vô minh, xúc và thọ ấy. Hãy hiểu tương tự đối với những chỗ khác.

**EN**
One should not assume that ignorance alone produces formations by themselves, that the six bases alone produce contact by itself, or that a single contact alone produces a single feeling. Understand that many results arise from many causes. It is insufficient to apprehend only ignorance, contact, or feeling in isolation. Remember to apprehend the phenomena associated with that ignorance, contact, or feeling as well. Understand the same at other points.

**VI**
Thử hướng trí về quá khứ

**EN**
Try directing knowledge toward the past

**VI**
Trước hết hãy tuần tự thiết lập định. Luân phiên quán nhiều lần danh sắc bên trong và bên ngoài, trong dòng tương tục của mình và của người khác. Đặc biệt, đối với phần bên ngoài…

**EN**
First establish concentration in stages. Repeatedly apprehend internal and external mentality and materiality, alternating between one’s own continuity and that of others. In particular, for the external aspect…


<a id="M05-body-P047"></a>
## Dùng định và ánh sáng để quán danh sắc / Using concentration and light to apprehend mentality and materiality
Miến / Burmese 47

**VI**
…hãy ưu tiên quán danh sắc theo từng nhóm chúng sinh ở tuyến cảnh pháp, gọi là tuyến số 6. Đối với nhiều hành giả, khi thường xuyên và nhiều lần ưu tiên quán như vậy, sức của ánh sáng ngày càng mạnh. Hãy nhiều lần luân phiên quán danh sắc bên trong và bên ngoài. Trước khi tìm các nhân duyên, chính Đức Phật đã chỉ dạy trong Kinh Đại Niệm Xứ rằng phải quán danh sắc bên trong và bên ngoài. Điều này đã được giải thích trong phần đề mục thiền về danh trước đây. Đặc biệt, hành giả chưa thể quán danh sắc bên ngoài sẽ rất khó quán danh sắc quá khứ, vì quán danh sắc quá khứ có cùng tính chất với quán danh sắc bên ngoài.

**EN**
…give priority to apprehending mentality and materiality in groups of beings on the mind-object track, designated track six. For many meditators, when they often and repeatedly give priority to apprehending these, the light grows progressively stronger. Repeatedly apprehend internal and external mentality and materiality in alternation. Before searching for the causes and conditions, the Buddha himself instructed in the Great Discourse on the Establishments of Mindfulness to apprehend mentality and materiality internally and externally. This was explained earlier in the section on the subject of mentality meditation. In particular, a meditator who cannot yet apprehend external mentality and materiality will find it very difficult to apprehend past mentality and materiality, because discerning the past is similar in nature to discerning external mentality and materiality.

**VI**
Khi đã quán danh sắc bên trong và bên ngoài, sáu loại sắc trong suốt của chính mình, tức sắc trong suốt của mắt, tai, mũi, lưỡi, thân và ý môn, ngày càng hiện rõ trong trí. Nhờ trí đang quán danh sắc bên trong và bên ngoài ấy, ánh sáng cũng ngày càng mạnh. Khi ấy hãy thử xem các sắc pháp và danh pháp này đang hiện hữu do những nhân nào. Với tâm muốn biết các nhân, hãy hướng tâm về quá khứ. Hãy hướng trí về đó. Khi ánh sáng phát sinh nhờ trí ấy soi sáng chung quanh, nhiều hành giả nhận thấy ánh sáng dần dần chiếu rõ về phía đối tượng họ chú ý.

**EN**
When internal and external mentality and materiality have been apprehended, one’s own six kinds of clear materiality, those of the eye, ear, nose, tongue, body, and mind door, become progressively clearer to knowledge. Through the knowledge that is apprehending internal and external mentality and materiality, the light also grows stronger. Then try to see owing to which causes these material and mental phenomena are present. With the wish to know the causes, direct the mind toward the past. Direct knowledge there. When the light arising from that knowledge illuminates the surroundings, many meditators notice that it gradually shines more clearly toward the object to which they are attending.


<a id="M05-body-P048"></a>
## Các cách tiếp tục tìm nhân quá khứ / Further ways of looking for past causes
Miến / Burmese 48

**VI**
Hãy dùng ánh sáng của trí ấy chiếu về phía các nhân quá khứ để tìm chúng. Có khi một hành và nghiệp thiện đã được tạo tác, vun bồi trong quá khứ, làm nhân gốc cho danh sắc quả hiện tại, sẽ hiện ra. Đây là cách được nêu trong các chú giải. (Chú giải Abhidhamma, tập 2, tr. 241. Chú giải Majjhima, tập 1, tr. 281.)

**EN**
Use the light of that knowledge to illuminate the past causes and look for them. Sometimes a wholesome formation and deed generated and accumulated in the past, which are root causes of present resultant mentality and materiality, will appear. This method is described in the commentaries. (Abhidhamma Commentary, vol. 2, p. 241. Majjhima Commentary, vol. 1, p. 281.)

**VI**
Nếu thử tìm các nhân quá khứ bằng cách này mà chưa thành công, hãy dựa vào cách trong phần nói về thắng trí nhớ đời trước của Thanh tịnh đạo. Bắt đầu từ danh sắc đã sinh trong lần ngồi thiền gần nhất, lùi từng bước về quá khứ và thử quán danh sắc. Đây là cách nhiều hành giả đã thực hành thành công.

**EN**
If one tries to find past causes in this way without success, use the procedure in the Visuddhimagga section on direct knowledge of former lives. Begin with the mentality and materiality that arose in the most recent meditation sitting, go back step by step into the past, and try to apprehend mentality and materiality. Many meditators have succeeded with this method.

**VI**
Nếu cách này cũng chưa thành công và vẫn chưa tìm được các nhân quá khứ, hãy thử dùng cách quán mối liên hệ nhân quả từ giữa về đầu, bắt đầu với bốn loại vật thực. Tuy nhiên, hành giả tìm các nhân bằng cách ấy cần thông thạo cách thuyết Duyên khởi.

**EN**
If this method also proves unsuccessful and one still cannot find past causes, try apprehending the causal connection from the middle back to the beginning, starting with the four kinds of nutriment. A meditator looking for causes in this way, however, needs to be well versed in the teaching of dependent origination.

**VI**
Sau đây sẽ lần lượt trình bày cách dựa vào phương pháp trong phần nói về thắng trí nhớ đời trước, bắt đầu từ danh sắc đã sinh trong lần ngồi thiền gần nhất, để quán danh sắc quá khứ và tìm ra mối liên hệ nhân quả bằng cách quán.

**EN**
The following pages set out in sequence how to use the method from the section on direct knowledge of former lives, beginning with the mentality and materiality that arose in the most recent sitting, to apprehend past mentality and materiality and to find and apprehend the causal connection.

**VI**
Thiện hữu trước khi ngồi thiền hãy cúng dường Đức Phật bằng đèn, nước hay hoa, rồi phát nguyện như sau…

**EN**
Before sitting in meditation, a good person should make an offering to the Buddha of a lamp, water, or flowers, and then make an aspiration as follows…


<a id="M05-body-P049"></a>
## Phát nguyện và quán danh sắc trước khi ngồi thiền / Making an aspiration and apprehending mentality and materiality before sitting
Miến / Burmese 49

**VI**
Sau đó, hãy nguyện được sinh vào đời sống mà thiện hữu ưa thích, chẳng hạn đời sống của một vị tỳ-khưu hoặc đời sống của một người nữ, nếu còn phải lưu chuyển trong luân hồi trước khi đạt Niết-bàn. Vì nghiệp thiện còn dẫn đến luân hồi (vaṭṭanissita) thuộc tập đế, thiện hữu sẽ có thể dễ dàng tìm thấy cách khổ đế sinh do tập đế ấy. Nhờ vậy có thể tạo một nghiệp thiện còn dẫn đến luân hồi để quan sát. Hãy lưu ý và ghi nhớ dòng tâm đã sinh trong khi tạo nghiệp và phát nguyện.

**EN**
Then aspire to a life you prefer, such as that of a bhikkhu or that of a woman, if you must continue wandering in saṃsāra before attaining Nibbāna. Since wholesome kamma conducive to the round (vaṭṭanissita) belongs to the truth of origin, a good person will readily be able to find how the truth of suffering arises from that truth of origin. In this way one can generate a wholesome deed conducive to the round for examination. Take note of and remember the succession of consciousness that arose while doing the deed and making the aspiration.

**VI**
Sau đó, tại nơi ngồi thiền, hãy thiết lập định theo từng bậc và quán danh sắc cả bên trong lẫn bên ngoài. Đặc biệt, hãy ưu tiên quán dòng tâm lộ tốc hành thiện thuộc tuyến cảnh pháp. Nếu là người lấy thiền chỉ làm cỗ xe, ở đây trước hết hãy ưu tiên quán các danh pháp thiền. Khi ánh sáng đã rất mạnh, hãy thử quán các danh pháp vừa sinh khi cử động trước lúc ngồi thiền, như dòng tâm cúng hoa, đèn hay nước, dòng tâm nguyện đời sống tỳ-khưu hay đời sống người nữ, và dòng tâm nguyện đạt Niết-bàn.

**EN**
Then, at the place where you sit to meditate, establish concentration in stages and apprehend mentality and materiality internally and externally. In particular, give priority to apprehending the successions of wholesome impulsion processes on the mind-object track. If you take tranquillity as your vehicle, give priority here to apprehending the mental phenomena of jhāna. When the light is very strong, try to apprehend the mental phenomena that arose during the movements just before sitting, such as the successions of consciousness while offering flowers, a lamp, or water, while aspiring to the life of a bhikkhu or a woman, and while aspiring to attain Nibbāna.

**VI**
Khi muốn quán những danh pháp ấy, trước hết hãy quán 54 sắc cùng với sắc ý vật, là chỗ nương của chúng ở tim. Để quán những sắc ấy, trước hết hãy quán bốn đại trong thân lúc đang phát nguyện và làm việc thiện. Đặc biệt, hãy quán bốn đại ở vùng tim lúc ấy. Khi gặp các nhóm sắc (rūpakalāpa), hãy quán 54 sắc, kể cả sắc ý vật…

**EN**
When wishing to apprehend those mental phenomena, first apprehend the fifty-four kinds of materiality, including the heart-base, on which they depend at the heart. To apprehend that materiality, first apprehend the four great elements in the body at the time of making the aspiration and doing the wholesome deed. In particular, apprehend the four great elements in the heart region at that time. When the material groups (rūpakalāpa) are discerned, apprehend the fifty-four kinds of materiality including the heart-base…


<a id="M05-body-P050"></a>
## Quán danh sắc vừa qua đối với người lấy thiền chỉ làm cỗ xe / Apprehending recent mentality and materiality for a tranquillity practitioner
Miến / Burmese 50

**VI**
…rồi tiếp tục quán tâm hữu phần trong sáng sinh nương sắc ý vật ấy. Khi đã quán ý môn, tức hữu phần trong sáng, hãy lần tới lui trong dòng hữu phần và tiếp tục quán các danh pháp gọi là dòng tâm lộ, sinh xen giữa các tâm hữu phần. Khi đã quán các danh pháp ấy, hãy nhiều lần xem kỹ chúng có khớp với dòng tâm thật sự đã sinh trước khi ngồi thiền hay không. Nếu thấy chúng khớp, thì việc quán danh sắc quá khứ gần nhất, lúc còn cử động trước khi ngồi, đã thành công.

**EN**
…and continue by apprehending the clear life-continuum consciousness that arises dependent on the heart-base. Having apprehended the mind door, the clear life-continuum, trace back and forth through it and continue apprehending the mental phenomena called the succession of process consciousness that arises between moments of life-continuum. Having apprehended these mental phenomena, examine repeatedly whether they match the succession of consciousness that actually arose before the sitting. If they match, you have succeeded in apprehending the mentality and materiality of the nearest past, during the movements before sitting.

**VI**
Trường hợp người lấy thiền chỉ làm cỗ xe

**EN**
The case of a tranquillity practitioner

**VI**
Nếu một thiện hữu lấy thiền chỉ làm cỗ xe và mong được an lạc nơi cõi phạm thiên, hãy theo nguyện vọng của mình mà nỗ lực tu tập để chứng một thiền chứng có thể đưa đến cõi phạm thiên tương ứng, như sơ thiền, nhị thiền hoặc một tầng thiền khác. Nếu đã thật sự chứng tầng thiền ấy, hãy nhập tầng thiền đó một lần. Ngay trước hoặc sau khi nhập thiền, hãy nguyện được sinh vào cõi phạm thiên tương ứng. Hoặc hãy quyết định về sự sinh ấy trong tâm. Sự phát nguyện hay quyết định trong tâm là sự tạo tác, vun bồi vòng phiền não do vô minh, ái và thủ dẫn đầu. Việc nhiều lần nhập thiền là sự tạo tác, vun bồi vòng nghiệp gồm hành và nghiệp.

**EN**
If a good person takes tranquillity as the vehicle and wishes for happiness in a brahmā realm, let them strive in accordance with their aspiration to attain a jhāna that can lead to the corresponding brahmā realm, such as the first jhāna, the second, or another jhāna. If they have actually attained it, let them enter it once. Just before or after entering it, let them aspire to birth in the corresponding brahmā realm, or make that resolve mentally. Making the aspiration or resolve generates and accumulates the round of defilements headed by ignorance, craving, and clinging. Repeatedly entering jhāna generates and accumulates the round of kamma consisting of formations and kamma.

**VI**
Sau đó, thiện hữu hãy lần lượt quay lại quán cả danh pháp thuộc vòng phiền não và vòng nghiệp, cùng những sắc làm chỗ nương cho các danh pháp ấy…

**EN**
Then go back in sequence to apprehend both the mental phenomena of the rounds of defilements and kamma and the material phenomena that serve as their bases…


<a id="M05-body-P051"></a>
## Vòng phiền não và vòng nghiệp / The rounds of defilements and kamma
Miến / Burmese 51

**VI**
…Nếu quán được danh sắc ấy thì việc quán danh sắc quá khứ gần nhất đã thành công. Khi quán danh sắc quá khứ như vậy, hãy nhớ ưu tiên quán sắc ý vật về phía sắc, và hữu phần trong sáng ở ý môn về phía danh.

**EN**
…If that mentality and materiality can be apprehended, the apprehension of the nearest past mentality and materiality has succeeded. In apprehending past mentality and materiality in this way, remember to give priority to the heart-base on the material side and to the clear life-continuum at the mind door on the mental side.

**VI**
Vòng phiền não và vòng nghiệp

**EN**
The rounds of defilements and kamma

**VI**
Hãy giải thích thêm về vô minh, ái, thủ, hành và nghiệp đã nêu trên, là những pháp khiến luân hồi tiếp diễn. Vô minh, ái và thủ thuộc vòng phiền não. Hành và nghiệp thuộc vòng nghiệp. Vô minh không có sức sinh riêng lẻ. Ái và thủ cũng vậy. Chúng chỉ có khả năng sinh theo nhóm. Trong sự phát nguyện nói trên, ái đạt đến mức có thể khiến đời sống được mong cầu thành tựu thì được gọi là thủ.

**EN**
Let us explain further the ignorance, craving, clinging, formations, and kamma mentioned above, which keep the round of rebirths going. Ignorance, craving, and clinging belong to the round of defilements. Formations and kamma belong to the round of kamma. Ignorance has no power to arise by itself, and neither do craving and clinging. They arise only in groups. In the aspiration just described, craving that reaches the strength capable of bringing about the desired life is called clinging.

**VI**
Avijjāsamudayā āsavasamudayo. (Majjhima, tập 1, tr. 65.)
Āsavasamudayā avijjāsamudayo. (Majjhima, tập 1, tr. 65.)

**EN**
Avijjāsamudayā āsavasamudayo. (Majjhima, vol. 1, p. 65.)
Āsavasamudayā avijjāsamudayo. (Majjhima, vol. 1, p. 65.)

**VI**
Theo các lời dạy ấy, do vô minh làm nhân mà các lậu hoặc sinh khởi, và do các lậu hoặc làm nhân mà vô minh sinh khởi. Vô minh và các lậu hoặc là những pháp trợ duyên cho nhau. Trong các lậu hoặc có cả những pháp vô minh, ái và thủ. Do đó, trong vòng phiền não, vô minh cùng ái và thủ có thể cùng sinh trong một lộ tâm ý môn, hoặc cũng có thể sinh ở những lộ khác nhau. Trong phần Duyên khởi này, thông thường…

**EN**
According to these teachings, the taints arise with ignorance as their cause, and ignorance arises with the taints as its cause. Ignorance and the taints condition each other. The phenomena of ignorance, craving, and clinging are included among the taints. Therefore, in the round of defilements, ignorance together with craving and clinging can arise in one mind-door process, or they may arise in separate processes. In this section on dependent origination, ordinarily…


<a id="M05-body-P052"></a>
## Ba pháp thuộc vòng phiền não / Three phenomena in the round of defilements
Miến / Burmese 52

**VI**
…chúng thường sinh trong nhóm tham hợp tà kiến. Hiếm khi chúng sinh trong nhóm tham đi cùng mạn. Hành có thể là hữu trợ hoặc vô trợ, tùy trường hợp. Ở đây lấy tâm căn tham thọ hỷ, hợp tà kiến, vô trợ làm ví dụ và ghi số 20. Tương tự, các pháp thuộc vòng nghiệp, gọi là hành và nghiệp, cũng chỉ sinh theo nhóm, không có sức sinh riêng lẻ. Ở đây lấy tâm đại thiện thọ hỷ, hợp trí, vô trợ làm ví dụ và ghi số 34. Tuy nhiên, vòng phiền não và vòng nghiệp có thể khác nhau tùy từng người và từng trường hợp. Hãy hiểu như vậy.

**EN**
…they commonly arise in the greed group associated with wrong view. In rare cases they may arise in a greed group accompanied by conceit. Formations may be prompted or unprompted, according to the case. Here a greed-rooted consciousness accompanied by joy, associated with wrong view, and unprompted is taken as an example and numbered twenty. Similarly, the phenomena in the round of kamma called formations and kamma arise only in groups and have no power to arise singly. Here a great wholesome consciousness accompanied by joy, associated with knowledge, and unprompted is taken as an example and numbered thirty-four. The rounds of defilements and kamma can nevertheless differ between people and cases. Understand it in this way.

**VI**
Ba pháp thuộc vòng phiền não

**EN**
Three phenomena in the round of defilements

**VI**
Khi cúng hoa, đèn hay nước lên Đức Phật rồi phát nguyện đời sống tỳ-khưu, ba pháp thuộc vòng phiền não là như sau:
1. Vô minh (20) — tính chất biết sai rằng có một vị tỳ-khưu.
2. Ái (20) — tính chất ham muốn và mê đắm đời sống tỳ-khưu.
3. Thủ (20) — tính chất tâm tiến đến và bám lấy đời sống tỳ-khưu.

**EN**
When offering flowers, a lamp, or water to the Buddha and then aspiring to a bhikkhu’s life, the three phenomena of the round of defilements are as follows:
1. Ignorance (20) — the quality of mistakenly knowing that there is a bhikkhu.
2. Craving (20) — the quality of desiring and delighting in a bhikkhu’s life.
3. Clinging (20) — the quality of the mind going toward and holding to a bhikkhu’s life.

**VI**
Nếu thiện hữu là người nữ và phát nguyện đời sống người nữ, ba pháp thuộc vòng phiền não là như sau:
1. Vô minh (20) — tính chất biết sai rằng có một người nữ.
2. Ái (20) — tính chất ham muốn và mê đắm đời sống người nữ.
3. Thủ (20) — tính chất tâm tiến đến và bám lấy đời sống người nữ.

**EN**
If a good person is a woman and aspires to a woman’s life, the three phenomena of the round of defilements are as follows:
1. Ignorance (20) — the quality of mistakenly knowing that there is a woman.
2. Craving (20) — the quality of desiring and delighting in a woman’s life.
3. Clinging (20) — the quality of the mind going toward and holding to a woman’s life.

**VI**
Ở đây số 20 chỉ cho toàn bộ nhóm tham hợp tà kiến trong mỗi sát-na tốc hành…

**EN**
Here twenty refers to the whole greed group associated with wrong view in each moment of impulsion…


<a id="M05-body-P053"></a>
## Hai pháp thuộc vòng nghiệp / Two phenomena in the round of kamma
Miến / Burmese 53

**VI**
…Các danh pháp trong những nhóm 19, 22 hoặc 21 cũng có thể sinh tùy trường hợp. Cần xét kỹ đúng theo cách chúng đã sinh, đang sinh hoặc sẽ sinh nơi mình.

**EN**
…Mental phenomena in groups of nineteen, twenty-two, or twenty-one can also arise, according to the case. Examine carefully how they actually arose, are arising, or will arise in your own continuity.

**VI**
Hai pháp thuộc vòng nghiệp

**EN**
Two phenomena in the round of kamma

**VI**
4. Hành (34) — nhóm tư thiện trong khi cúng hoa, đèn hay nước lên Đức Phật. Ở đây là tâm đại thiện thọ hỷ, hợp trí, vô trợ.
5. Nghiệp — sức nghiệp của hành (34) ấy.

**EN**
4. Formations (34) — the group of wholesome volition while offering flowers, a lamp, or water to the Buddha. Here it is a great wholesome consciousness accompanied by joy, associated with knowledge, and unprompted.
5. Kamma — the kammic power of those formations (34).

**VI**
Vô minh, ái và thủ, gọi chung là vòng phiền não, thường sinh trong một lộ ý môn với bảy sát-na tốc hành. Đôi khi cũng có thể sinh với cảnh nghiệp là danh sắc ở đời sống tỳ-khưu hay đời sống người nữ mà mình đã phát nguyện. Ở đây lấy nhóm tham hợp tà kiến có đủ 20 danh pháp trong từng sát-na tốc hành làm ví dụ.

**EN**
Ignorance, craving, and clinging, collectively called the round of defilements, commonly arise in a mind-door process with seven moments of impulsion. They can sometimes arise with a kamma object, namely the mentality and materiality in the bhikkhu’s life or woman’s life to which one has aspired. Here the greed group associated with wrong view, with twenty mental phenomena in each moment of impulsion, is given as the example.

**VI**
Các pháp thuộc vòng nghiệp, gọi là hành và nghiệp, cũng nằm trong dòng tâm lộ tốc hành đại thiện qua ý môn. Mỗi tốc hành có thể có một trong hai loại hợp trí hay ly trí. Ở đây lấy tốc hành đại thiện thọ hỷ, hợp trí, vô trợ với 34 danh pháp làm ví dụ. Cần quán đúng theo cách các pháp ấy sinh trong dòng danh sắc của mình khi vun bồi nghiệp. Tốc hành thiện có thể là thọ hỷ hay thọ xả, hợp trí hay ly trí, hữu trợ hay vô trợ, tùy trường hợp.

**EN**
The phenomena belonging to the round of kamma, called formations and kamma, also occur within the succession of great wholesome impulsion processes at the mind door. An impulsion may be associated with knowledge or dissociated from it. Here great wholesome impulsion accompanied by joy, associated with knowledge, and unprompted, with thirty-four mental phenomena, is given as an example. Apprehend these phenomena as they actually arise in your own continuity of mentality and materiality when accumulating kamma. A wholesome impulsion may be accompanied by joy or equanimity, associated with knowledge or dissociated from it, prompted or unprompted, according to the case.


<a id="M05-body-P054"></a>
## Sức nghiệp và trường hợp phát nguyện cõi phạm thiên / Kammic power and the case of aspiring to a brahmā realm
Miến / Burmese 54

**VI**
Những tư thiện ở tốc hành, tức các pháp thuộc nhóm hành ấy, đều là pháp vô thường. Hết tuổi thọ sinh, trụ và diệt, chúng liền hoại diệt. Tuy nhiên, trước khi hoại diệt, chúng đã đặt trong dòng danh sắc sức nghiệp có thể làm sinh đời sống tỳ-khưu hay đời sống người nữ đã mong cầu vào một đời tương lai. Chúng khác với các danh pháp quả và danh pháp duy tác, vốn hoại diệt mà không để lại sức nghiệp như vậy. Chính sức làm sinh quả ấy được gọi là nghiệp, tức sức của nghiệp duyên khác sát-na (nānakkhaṇikakammapaccaya). Sau đây tiếp tục trình bày sự phát nguyện thứ hai, tức phát nguyện cõi phạm thiên.

**EN**
Those wholesome volitions at impulsion, the phenomena belonging to the group of formations, are impermanent. At the end of their span of arising, presence, and dissolution, they cease. Before ceasing, however, they have established in the continuity of mentality and materiality a kammic power capable of bringing forth the aspired-to life of a bhikkhu or a woman in a future existence. Resultant and functional mental phenomena, by contrast, cease without leaving such a kammic power. The power to bring forth the result is called kamma, the power of asynchronous kamma condition (nānakkhaṇikakammapaccaya). We now continue with the second aspiration, the aspiration to a brahmā life.

**VI**
Trường hợp phát nguyện thứ hai: cõi phạm thiên

**EN**
The second aspiration: a brahmā life

**VI**
1. Vô minh (20) — tính chất biết sai rằng có một vị phạm thiên.
2. Ái (20) — tính chất ham muốn và mê đắm đời sống phạm thiên ấy.
3. Thủ (20) — tính chất tâm tiến đến và bám lấy đời sống phạm thiên ấy.
4. Hành (31) — nhóm tư thiện của tứ thiền đã được tạo tác, vun bồi với nguyện vọng sinh vào đời sống phạm thiên.
5. Nghiệp — sức nghiệp của hành (31) ấy.

**EN**
1. Ignorance (20) — the quality of mistakenly knowing that there is a brahmā.
2. Craving (20) — the quality of desiring and delighting in that brahmā life.
3. Clinging (20) — the quality of the mind going toward and holding to that brahmā life.
4. Formations (31) — the group of wholesome volition of the fourth jhāna generated and accumulated with the aspiration to a brahmā life.
5. Kamma — the kammic power of those formations (31).

**VI**
Trong vòng phiền não gồm vô minh, ái và thủ, nhóm tham hợp tà kiến có đủ 20 danh pháp. Trong hành thuộc tứ thiền có 31 danh pháp. Đây đều là các dòng tâm lộ tốc hành qua ý môn.

**EN**
In the round of defilements comprising ignorance, craving, and clinging, the greed group associated with wrong view comprises twenty mental phenomena. In the fourth-jhāna formations there are thirty-one mental phenomena. These are successions of mind-door impulsion processes.

**VI**
Nếu thiện hữu có thể nhận diện và quán các danh pháp thuộc vòng phiền não và vòng nghiệp sinh trong lần cử động vừa qua, dùng trí phá vỡ khối tưởng về danh để biết đến mức danh chân đế…

**EN**
If a good person can apprehend and discern the mental phenomena of the rounds of defilements and kamma that arose during the most recent activity, using knowledge to break through the perception of compactness in mentality and reach ultimate mentality…


<a id="M05-body-P055"></a>
## Trình tự thực hành khi thấy một hình ảnh / Procedure when an image appears
Miến / Burmese 55

**VI**
…thì đã thành công trong việc quán danh sắc quá khứ gần nhất.

**EN**
…then apprehending the mentality and materiality of the nearest past has succeeded.

**VI**
Trình tự thực hành khi thấy một hình ảnh

**EN**
Procedure when an image appears

**VI**
Giả sử thiện hữu đang luân phiên quán danh sắc bên trong và bên ngoài, và nhờ trí phân định danh sắc mà ánh sáng trở nên rất mạnh. Nếu dùng ánh sáng ấy để hướng đến danh sắc trong lần cử động gần nhất, hình ảnh một người đang phát nguyện trước khi ngồi thiền có thể hiện ra. Đó là thấy dưới ánh sáng. Trước hết hãy quán bốn đại nơi hình ảnh ấy, hướng trí để thấy bốn đại. Hãy xem hình ảnh ấy như danh sắc bên ngoài và hướng đến bốn đại như khi tìm danh sắc bên ngoài. Người đã quán danh sắc bên ngoài đến mức sắc chân đế sẽ không gặp nhiều khó khăn.

**EN**
Suppose a good person is alternately apprehending internal and external mentality and materiality, and the light grows very strong through the knowledge that distinguishes mentality and materiality. If one uses that light to attend to mentality and materiality in the most recent activity, an image of someone making an aspiration before the sitting may appear. This is seeing under the light. First apprehend the four great elements there, directing knowledge to see them. Treat the image as external mentality and materiality and attend to the four great elements as when seeking external mentality and materiality. A good person who has apprehended external mentality and materiality to the level of ultimate materiality will not find this very difficult.

**VI**
Chẳng bao lâu sẽ thấy những hạt nhóm sắc. Hãy tiếp tục quán các sắc chân đế trong các nhóm ấy theo sáu cửa và 42 phần của thân. Đặc biệt, hãy ưu tiên quán 54 sắc trong vùng tim, trong đó ưu tiên sắc ý vật. Tiếp tục quán tâm hữu phần trong sáng, tức ý môn, sinh nương sắc ý vật. Rồi, giữa những tâm hữu phần trong sáng ấy, hãy tiếp tục quán các danh pháp sinh nương sắc ý vật…

**EN**
Before long one will find the particles that are material groups. Continue apprehending the ultimate material phenomena in those groups through the six doors and the forty-two parts of the body. Give priority to the fifty-four kinds of materiality in the heart region, and among these to the heart-base. Continue apprehending the clear life-continuum consciousness, the mind door, which arises dependent on the heart-base. Then, between moments of that clear life-continuum, continue apprehending the mental phenomena arising dependent on the heart-base…


<a id="M05-body-P056"></a>
## Lần về danh sắc quá khứ từng bước / Tracing back through past mentality and materiality step by step
Miến / Burmese 56

**VI**
…Hãy tiếp tục quán dòng các danh pháp. Sau khi quán như vậy, hãy xem xét lại thật kỹ xem dòng danh pháp đã quán có đúng là dòng danh pháp thật sự đã sinh khi phát nguyện hay không. Nếu chúng khớp hoàn toàn, thì việc quán danh sắc quá khứ gần nhất đã thành công.

**EN**
…Continue apprehending the succession of mental phenomena. After apprehending it in this way, examine carefully whether the succession of mental phenomena apprehended is the one that actually arose while making the aspiration. If they match completely, then apprehending the nearest past mentality and materiality has succeeded.

**VI**
Khi đã thành công như vậy, dần dần hướng trí về quá khứ, quán từng bước danh sắc buổi sáng nay, danh sắc hôm qua, tháng trước, năm trước và cứ thế, thật tỉ mỉ. Nếu xen vào đó hiện ra những hình ảnh đang làm thiện, đang làm bất thiện, đang vui, đang không vui, đang mừng hay đang buồn, hãy quán bốn đại trong các hình ảnh ấy rồi tiếp tục quán danh sắc theo cách đã nêu ở trên.

**EN**
Once you have succeeded in this way, gradually direct knowledge toward the past. Apprehend in careful detail, step by step, the mentality and materiality of this morning, yesterday, last month, last year, and so on. If images of doing wholesome or unwholesome deeds, being content or discontent, rejoicing or grieving appear in between, apprehend the four great elements in those images and continue apprehending mentality and materiality as described above.

**VI**
Hãy dần dần tiếp tục quán danh sắc cho đến khi vào bụng mẹ. Quán được càng tỉ mỉ thì càng tốt. Khi làm vậy, nhiều hành giả thấy các hình ảnh của mình dần dần trẻ lại. Nhưng ở đây hình ảnh không phải là điều chính. Danh sắc mới là điều chính. Ngay cả khi không thấy hình ảnh, nếu thấy được danh sắc chân đế cho đến khi vào bụng mẹ thì càng tốt.

**EN**
Gradually continue apprehending mentality and materiality back to entry into the mother’s womb. The more closely one can apprehend it, the better. While doing this, many meditators find images of themselves growing gradually younger. But the images are not the main point here. Mentality and materiality are. Even without seeing images, it is better if one can see ultimate mentality and materiality all the way back to entry into the mother’s womb.


<a id="M05-body-P057"></a>
## Từ tái tục đến sát-na cận tử của đời trước / From rebirth-linking to the death-proximate period of the preceding life
Miến / Burmese 57

**VI**
Đối với loài người, ở sát-na tái tục khi vào bụng mẹ có ba loại nhóm sắc: nhóm mười sắc ý vật, nhóm mười sắc thân và nhóm mười sắc tính. Tính theo loại sắc, có 30 sắc. Chỉ có ba loại nhóm, gồm 30 loại sắc, nhưng mỗi loại có thể có nhiều nhóm. Điều đó tùy vào nghiệp đang cho quả. Về phía danh, nếu là người tái tục bằng tâm thọ hỷ thì có 34 danh pháp đại quả thọ hỷ, hợp trí. Hãy quán danh sắc ấy cho đến khi tuệ nhãn trở nên trong sáng. Khi có thể quán cho đến mức biết chân đế bằng tuệ nhãn trong sáng, hãy suy xét và phân định như sau.

**EN**
For human beings, at the rebirth-linking moment upon entry into the mother’s womb, there are three types of material groups: the heart-base decad, the body decad, and the sex decad. Counted by type of materiality, there are thirty. There are only three types of group, comprising thirty types of materiality, but each type of group may occur many times. That depends on the kamma giving the result. On the mental side, for one whose rebirth-linking consciousness is accompanied by joy, there are thirty-four great resultant mental phenomena accompanied by joy and associated with knowledge. Apprehend this mentality and materiality until the eye of knowledge becomes clear. When able to apprehend it to the level of ultimate reality with a clear eye of knowledge, investigate and distinguish as follows.

**VI**
So “idaṃ nāmarūpaṃ na ahetu na appaccayā nibbattaṃ, sahetu sappaccayā nibbattaṃ. Ko panassa hetu, ko pana paccayo”ti upaparikkhanto “avijjāpaccayā, taṇhāpaccayā, kammapaccayā, āhārapaccayā cā”ti tassa paccayaṃ vavatthapetvā “atītepi paccayā ceva paccayasamuppannadhammā ca, anāgatepi etarahipi paccayā ceva paccayasamuppannadhammā ca. Tato uddhaṃ satto vā puggalo vā natthi, suddhasaṅkhārapuñjo evā”ti tīsu addhāsu kaṅkhaṃ vitarati. Ayaṃ pana vipassanāsaṅkhārasallakkhaṇañātapariññā nāma. (Chú giải Abhidhamma, tập 2, tr. 241–242.)

**EN**
So “idaṃ nāmarūpaṃ na ahetu na appaccayā nibbattaṃ, sahetu sappaccayā nibbattaṃ. Ko panassa hetu, ko pana paccayo”ti upaparikkhanto “avijjāpaccayā, taṇhāpaccayā, kammapaccayā, āhārapaccayā cā”ti tassa paccayaṃ vavatthapetvā “atītepi paccayā ceva paccayasamuppannadhammā ca, anāgatepi etarahipi paccayā ceva paccayasamuppannadhammā ca. Tato uddhaṃ satto vā puggalo vā natthi, suddhasaṅkhārapuñjo evā”ti tīsu addhāsu kaṅkhaṃ vitarati. Ayaṃ pana vipassanāsaṅkhārasallakkhaṇañātapariññā nāma. (Abhidhamma Commentary, vol. 2, pp. 241–242.)

**VI**
Hành giả hãy suy xét và dùng trí phân định như sau: “Danh sắc này không sinh khi thiếu nhân trực tiếp làm nó hiện khởi, hay thiếu duyên nâng đỡ nó…”

**EN**
The meditator should investigate and distinguish with knowledge in this way: “This mentality and materiality did not arise in the absence of the direct cause that produces it or of the supporting condition…”


<a id="M05-body-P058"></a>
## Tìm cảnh cận tử và lần về nghiệp làm nhân / Finding the death-proximate object and tracing back to the causal kamma
Miến / Burmese 58

**VI**
“…Danh sắc chỉ sinh khi có nhân trực tiếp làm nó hiện khởi và có duyên nâng đỡ nó. Nhân trực tiếp ấy là gì? Duyên nâng đỡ ấy là gì?” Khi hướng trí về quá khứ để suy xét như vậy, hành giả thường bắt đầu thấy cả danh sắc sinh vào thời cận tử của đời trước lẫn một trong ba cảnh làm đối tượng cho danh pháp cận tử: nghiệp, nghiệp tướng hoặc thú tướng.

**EN**
“…Mentality and materiality arise only when there is a direct cause that brings it forth and a supporting condition. What is its direct cause? What is its supporting condition?” When directing knowledge to the past to investigate in this way, the meditator often begins to see both the mentality and materiality that arose near death in the former life and one of the three objects taken by the death-proximate mental phenomena: kamma, a sign of kamma, or a sign of the destination.

**VI**
Nếu có thể quán danh sắc lúc cận tử thì việc gặp một trong ba cảnh là nghiệp, nghiệp tướng hoặc thú tướng của các danh pháp ấy trở nên rất dễ. Đừng quên rằng tướng cận tử ấy là tướng hiện ra do sức của nghiệp sắp cho quả. Vì vậy, khi tìm được tướng ấy thì có thể chắc rằng mình sẽ tìm được hành và nghiệp là nhân gốc của những uẩn quả, như năm uẩn tái tục hiện tại. Khi đã gặp hành và nghiệp, hãy tiếp tục tìm vô minh, ái và thủ bao quanh chúng.

**EN**
If one can apprehend mentality and materiality near death, it becomes very easy to find one of the three objects of those mental phenomena: kamma, a sign of kamma, or a sign of the destination. Remember that the death-proximate sign appears through the power of the kamma about to give its result. Thus once that sign is found, one can be confident of finding the formations and kamma that are the root causes of the resultant aggregates, such as the five present rebirth-linking aggregates. Once formations and kamma have been found, continue looking for the ignorance, craving, and clinging that surround them.

**VI**
Khi thiện hữu dùng trí suy xét các nhân quá khứ và quán danh sắc vào thời cận tử…

**EN**
When a good person investigates past causes with knowledge and apprehends mentality and materiality at the time near death…


<a id="M05-body-P059"></a>
## Khi hình ảnh người sắp chết hoặc thi thể hiện ra / When an image of a dying person or a corpse appears
Miến / Burmese 59

**VI**
…mà chưa thấy danh sắc ấy, nếu thấy hình ảnh một người đang chết hoặc hình ảnh cận tử, hãy bắt đầu quán bốn đại trong thân đang chết ấy. Khi thấy những hạt nhóm sắc, hãy dùng trí phân tích các nhóm sắc ấy rồi tiếp tục quán sắc chân đế do thời tiết sinh, gồm tám sắc.

**EN**
…and has yet to see that mentality and materiality, if an image of a person dying or of the period near death appears, begin by apprehending the four great elements in that dying body. When particles of material groups are seen, analyze those groups with knowledge, then continue apprehending the ultimate materiality of the temperature-produced octad.

**VI**
Nói rằng trong thi thể có các nhóm tám sắc do thời tiết sinh là nói theo trường hợp thông thường. Bởi ngay khi ấy, hành giả đôi khi có thể thấy lẫn những hạt nhóm sắc của một số sinh vật còn sống nương ở thi thể. Vì vậy, một số hành giả thấy lẫn các nhóm sắc trong suốt và không trong suốt trong thi thể ấy. Những sinh vật ấy ít nhất cũng có các nhóm sắc trong suốt, tức nhóm mười sắc thân. Trong chính thi thể chỉ có các nhóm tám sắc không trong suốt do thời tiết sinh.

**EN**
The statement that there are temperature-produced octads in the corpse concerns the ordinary case. At that very time, a meditator can sometimes see mixed among them particles of material groups belonging to living creatures that inhabit the corpse. Thus some meditators see both transparent and non-transparent material groups mixed together in the corpse. Those living creatures have at least the transparent material groups called body decads. In the corpse itself there are only the non-transparent temperature-produced octads.

**VI**
Sau khi quán sắc pháp trong thi thể ấy, thiện hữu hãy hướng sự chú ý về quá khứ, lùi từng bước và thử quán danh sắc cận tử trước khi chết. Nếu có thể quán danh sắc cận tử, hãy tiếp tục quán đối tượng của các tốc hành hiện khởi lúc cận tử. Nếu chưa thành công, hãy quán sắc ý vật lúc cận tử cho đến khi thấy rõ. Sau đó, tiếp tục quán tâm hữu phần trong sáng, tức ý môn, sinh nương sắc ý vật ấy. Nếu có thể quán tâm hữu phần trong sáng ấy thì hãy tiếp tục quán danh sắc cận tử trước khi chết…

**EN**
After apprehending the material phenomena in the corpse, direct attention into the past, go back step by step, and try to apprehend mentality and materiality near death before death occurs. If able to apprehend it, continue by apprehending the object of the impulsions that arise near death. If unsuccessful, apprehend the heart-base near death until it can be seen clearly. Then continue apprehending the clear life-continuum consciousness, the mind door, that arises dependent on the heart-base. If able to apprehend that clear life-continuum, continue to apprehend the death-proximate mentality and materiality…


<a id="M05-body-P060"></a>
## Tìm đối tượng của tốc hành cận tử / Finding the object of death-proximate impulsion
Miến / Burmese 60

**VI**
…Hãy tiếp tục quán những tâm hữu phần trong sáng thường lặp đi lặp lại không ngừng trong thời gian ấy. Hãy xét tới lui cả khoảng trước khi chết và khoảng sau của thời cận tử. Khi quán được các tâm hữu phần trong sáng ấy, hành giả có thể tìm thấy và quán một trong ba tướng hiện ở ý môn là nghiệp, nghiệp tướng hay thú tướng, làm đối tượng cho tốc hành cận tử. Khi khảo sát các hành giả đã thành thạo, thấy số người có cảnh nghiệp và nghiệp tướng hiện ra thì nhiều, còn số người có thú tướng hiện ra thì rất ít.

**EN**
…Continue apprehending the clear life-continuum consciousnesses that often arise repeatedly without interruption during that time. Examine back and forth over both the period before death and the later part of the death-proximate period. Once one can apprehend those clear life-continuum consciousnesses, one can find and apprehend one of the three signs appearing at the mind door as the object of death-proximate impulsion: kamma, a sign of kamma, or a sign of the destination. On examining proficient meditators, it is found that many experience kamma or a sign of kamma, while very few experience a sign of the destination.

**VI**
Nếu tướng hiện vào thời cận tử là cảnh nghiệp, thì theo lời giải thích bằng cụm abhinavakaraṇavasena trong Abhidhammatthasaṅgaha, phần Ngoài lộ tâm, tr. 90, đó là tướng hiện do sức của một việc thiện đang được làm lại như mới. Cần quay lại quán danh sắc đã sinh vào thời điểm làm việc thiện ấy.

**EN**
If the sign appearing near death is kamma as the object, then according to the explanation using the expression abhinavakaraṇavasena in the Abhidhammatthasaṅgaha, section on the process-free, p. 90, the sign appears through the power of a wholesome deed being performed afresh. One must go back and apprehend the mentality and materiality that arose at the time of performing that deed.

**VI**
Cách tìm cảnh nghiệp

**EN**
How to find kamma as the object

**VI**
Trước hết, hãy quán bốn đại nơi hình ảnh đang làm việc thiện ấy. Khi thấy các nhóm sắc, hãy phân tích chúng và quán sắc pháp cho đến mức sắc chân đế. Đặc biệt, hãy ưu tiên quán 54 sắc trong vùng tim, kể cả sắc ý vật, đã sinh khi làm việc thiện ấy. Sau đó quán riêng sắc ý vật, rồi tiếp tục quán tâm hữu phần trong sáng, tức ý môn, sinh nương sắc ý vật. Tiếp theo, giữa những tâm hữu phần ấy…

**EN**
First apprehend the four great elements in the image of the wholesome deed being done. When the material groups appear, analyze them and apprehend the material phenomena to the level of ultimate materiality. Give priority to the fifty-four kinds of materiality in the heart region, including the heart-base, that arose when doing that deed. Then apprehend the heart-base itself, and continue apprehending the clear life-continuum consciousness, the mind door, that arises in dependence on it. Then, between those moments of life-continuum…


<a id="M05-body-P061"></a>
## Tìm dòng tâm lúc tạo nghiệp / Finding the succession of consciousness when kamma was made
Miến / Burmese 61

**VI**
…hãy tiếp tục quán những nhóm danh pháp sinh xen vào trong lúc làm việc thiện ấy. Khi quán như vậy, hãy nhìn kỹ những danh pháp sinh trước, trong và sau khi làm việc thiện. Hãy hướng trí để thấy rõ việc thiện thuộc loại nào đang được làm và dòng tâm lộ tốc hành đại thiện qua ý môn thuộc loại nào đang sinh.

**EN**
…continue apprehending the groups of mental phenomena arising in between while the wholesome deed was being done. In doing so, look closely at the mental phenomena arising before, during, and after the deed. Direct knowledge to see clearly what kind of wholesome deed is being performed and what kind of succession of great wholesome impulsion processes at the mind door is arising.

**VI**
Nếu quán tới lui nhiều lần, hành giả sẽ tìm thấy nhóm vô minh, ái và thủ liên hệ với mục đích và ý hướng khi làm việc thiện, cũng như các hành và nghiệp là dòng tâm lộ tốc hành thiện thuộc loại nào đang hiện khởi. Nói cách khác, hành giả sẽ tìm thấy vòng phiền não và vòng nghiệp, tức hành và nghiệp thiện được vô minh, ái và thủ bao quanh. Hãy lưu ý rằng ở đây chỉ tách riêng để nói về hành và nghiệp thiện vì hành và nghiệp làm phát sinh đời sống và các uẩn của con người là hành và nghiệp thiện.

**EN**
If one discerns back and forth repeatedly, one will find the group of ignorance, craving, and clinging connected with the purpose and intention of doing the wholesome deed, and also what kind of wholesome impulsion process is arising as formations and kamma. In other words, one will find the round of defilements and the round of kamma, namely wholesome formations and kamma surrounded by ignorance, craving, and clinging. Note that wholesome formations and kamma are singled out here because those that give rise to human life and the human aggregates are wholesome formations and kamma.

**VI**
Lời nguyện trước kia của công chúa Sumanā

**EN**
Princess Sumanā’s former aspiration

**VI**
Để hiểu sâu hơn về vô minh, ái, thủ, hành và nghiệp, sau đây trình bày một lần phát nguyện trước kia của công chúa Sumanā, con gái nổi tiếng của vua Kosala. Khi Đức Phật Vipassī xuất hiện, sau khi dâng lên Tăng chúng do Đức Phật Vipassī đứng đầu vòng hoa lài và vật thực, người nữ thiện lành ấy đã phát nguyện như sau.

**EN**
To understand ignorance, craving, clinging, formations, and kamma more deeply, here is a former aspiration of Princess Sumanā, the well-known daughter of the king of Kosala. When Buddha Vipassī appeared, this good woman offered a garland of jasmine and food to the Saṅgha headed by Buddha Vipassī and then made the following aspiration.


<a id="M05-body-P062"></a>
## Năm nhân trong lời nguyện của công chúa Sumanā / Five causes in Princess Sumanā’s aspiration
Miến / Burmese 62

**VI**
Bhavābhavābhinibbattiyaṃ me sati paritassanajīvitaṃ nāma mā hotu. Ayaṃ sumanamālā viya nibbattanibbattaṭṭhāne piyāva homi, nāmena ca sumanāyeva. (Chú giải Aṅguttara, tập 3, tr. 13–14.)

**EN**
Bhavābhavābhinibbattiyaṃ me sati paritassanajīvitaṃ nāma mā hotu. Ayaṃ sumanamālā viya nibbattanibbattaṭṭhāne piyāva homi, nāmena ca sumanāyeva. (Aṅguttara Commentary, vol. 3, pp. 13–14.)

**VI**
“Nếu con còn sinh vào đời này đời khác, lớn hay nhỏ, nguyện con không phải sống trong lo lắng, mong cầu và khốn khó để nuôi mạng. Trong mỗi đời được sinh ra, nguyện con là người nữ được mọi người yêu mến, như vòng hoa lài quý này. Nguyện tên con cũng là Sumanā.” (Chú giải Aṅguttara, tập 3, tr. 13–14.)

**EN**
“If I am still to be born in one existence or another, great or small, may I never have to earn my living in anxiety, want, and distress. Wherever I am born, may I be a woman loved by everyone, like this precious jasmine garland. May my name also be Sumanā.” (Aṅguttara Commentary, vol. 3, pp. 13–14.)

**VI**
Khi xét việc thiện và lời nguyện ấy, có thể thấy đầy đủ cả vòng phiền não và vòng nghiệp:
1. Vô minh — tính chất biết sai rằng có một người nữ tên Sumanā, được mọi người yêu mến và sống không lo lắng, thiếu thốn về sinh kế.
2. Ái — tính chất ham muốn và mê đắm đời sống người nữ ấy.
3. Thủ — tính chất tâm tiến đến và bám lấy đời sống người nữ ấy.
4. Hành — nhóm tư thiện khi cúng vòng hoa lài và vật thực lên Tăng chúng do Đức Phật Vipassī đứng đầu.
5. Nghiệp — sức nghiệp của nhóm tư thiện thuộc hành ấy.

**EN**
In examining that wholesome deed and aspiration, both the round of defilements and the round of kamma can be seen in full:
1. Ignorance — the quality of mistakenly knowing that there is a woman named Sumanā, loved by everyone and living without anxiety or want in her livelihood.
2. Craving — the quality of desiring and delighting in that woman’s life.
3. Clinging — the quality of the mind going toward and holding to that woman’s life.
4. Formations — the group of wholesome volition when offering a jasmine garland and food to the Saṅgha headed by Buddha Vipassī.
5. Kamma — the kammic power of that group of wholesome volition belonging to formations.

**VI**
Năm pháp làm nhân ấy là các nhân của năm uẩn tái tục và các uẩn quả khác của công chúa Sumanā, con gái vua Kosala. (Xem Chú giải Aṅguttara, tập 3, tr. 13–14.)

**EN**
These five causes are causes of the five rebirth-linking aggregates and other resultant aggregates of Princess Sumanā, the king of Kosala’s daughter. (See Aṅguttara Commentary, vol. 3, pp. 13–14.)


<a id="M05-body-P063"></a>
## Năm nhân trong lời nguyện của Anojādevī / Five causes in Anojādevī’s aspiration
Miến / Burmese 63

**VI**
Vào thời Đức Phật Kassapa, một nghìn gia đình thợ dệt, dẫn đầu bởi những người về sau là Tôn giả Mahākappina và trưởng lão ni Anojā, đã xây dựng một ngôi tinh xá lớn, lộng lẫy rồi cúng dường Tăng chúng do Đức Phật đứng đầu. Trong buổi cúng dường ấy, người nữ thiện lành về sau là Anojādevī, tức trưởng lão ni Anojā, đặt một bộ y trị giá một nghìn đồng, có màu hoa anoja, lên một mâm đầy hoa anoja, rồi đặt dưới chân Đức Phật Kassapa để cúng dường. Khi ấy bà phát nguyện như sau.

**EN**
In the time of Buddha Kassapa, a thousand weavers’ families, led by those who would later become Venerable Mahākappina and the elder nun Anojā, built a large and splendid monastery and offered it to the Saṅgha headed by the Buddha. At that offering, the good woman who would later become Anojādevī, the elder nun Anojā, placed a set of robes worth a thousand pieces, the color of anoja flowers, on a tray full of those flowers. She placed it at Buddha Kassapa’s feet as an offering and made the following aspiration.

**VI**
Bhante, nibbattanibbattaṭṭhāne anojapupphavaṇṇameva me sarīraṃ hotu, Anojā eva ca me nāmaṃ hotu. (Chú giải Dhammapada, tập 1, tr. 353.)

**EN**
Bhante, nibbattanibbattaṭṭhāne anojapupphavaṇṇameva me sarīraṃ hotu, Anojā eva ca me nāmaṃ hotu. (Dhammapada Commentary, vol. 1, p. 353.)

**VI**
“Bạch Đức Thế Tôn, trong mỗi đời được sinh ra, nguyện thân con có màu như hoa anoja. Nguyện tên con cũng là Anojā.” (Chú giải Dhammapada, tập 1, tr. 353.)

**EN**
“Venerable sir, wherever I am born, may my body have the color of the anoja flower. May my name also be Anojā.” (Dhammapada Commentary, vol. 1, p. 353.)

**VI**
1. Vô minh — tính chất biết sai rằng có một người nữ tên Anojā, mang màu hoa anoja.
2. Ái — tính chất ham muốn và mê đắm đời sống người nữ ấy.
3. Thủ — tính chất tâm tiến đến và bám lấy đời sống người nữ ấy.
4. Hành — nhóm tư thiện khi cúng dường tinh xá, hoa và y.
5. Nghiệp — sức nghiệp của nhóm tư thiện thuộc hành ấy.

**EN**
1. Ignorance — the quality of mistakenly knowing that there is a woman named Anojā, with the color of the anoja flower.
2. Craving — the quality of desiring and delighting in that woman’s life.
3. Clinging — the quality of the mind going toward and holding to that woman’s life.
4. Formations — the group of wholesome volition while offering the monastery, flowers, and robes.
5. Kamma — the kammic power of that group of wholesome volition belonging to formations.


<a id="M05-body-P064"></a>
## Quả của lời nguyện Anojā và chuyện hoàng hậu Subhaddā / The result of Anojā’s aspiration and the story of Queen Subhaddā
Miến / Burmese 64

**VI**
Nhờ việc thiện ấy, bà sinh làm Anojādevī, tức vị trưởng lão ni Anojā về sau, một người nữ có nước da như màu hoa anoja. Năm pháp làm nhân kể trên là các nhân của năm uẩn tái tục và một số pháp thuộc vòng quả của bà. Khi vô minh, ái và thủ còn bao quanh và trợ lực, hành và nghiệp làm sinh các quả tương ứng. Đó là một bức tranh đã được vẽ từ thời Đức Phật Kassapa.

**EN**
Through that wholesome deed she became Anojādevī, the future elder nun Anojā, a woman whose complexion resembled the anoja flower. The five causal phenomena mentioned above were causes of her five rebirth-linking aggregates and of some phenomena in her round of results. When ignorance, craving, and clinging surround and support formations and kamma, the latter produce their corresponding results. It was a picture painted in the time of Buddha Kassapa.

**VI**
Hoàng hậu Subhaddā

**EN**
Queen Subhaddā

**VI**
Một thuở, Đức Phật đang ngồi trên pháp tọa thuyết pháp tại Jetavana ở Sāvatthī. Một vị tỳ-khưu-ni trẻ nhìn thân Đức Phật, đầy đủ mười thân lực và mười trí lực, với sắc thân cao quý hiện rõ nhờ năng lực của những ba-la-mật và việc thiện vô lượng. Vị ấy tự hỏi trong khi lưu chuyển trong luân hồi mình đã từng hầu hạ dưới chân bậc cao quý này hay chưa.

**EN**
Once the Buddha was teaching from the Dhamma seat at Jetavana in Sāvatthī. A young bhikkhunī looked upon the Buddha, endowed with ten bodily powers and ten powers of knowledge, whose excellent form had become manifest through the power of immeasurable perfections and wholesome deeds. She wondered whether, in wandering through saṃsāra, she had ever served at the feet of this eminent man.

**VI**
Ngay lúc ấy, trong dòng tâm của vị tỳ-khưu-ni trẻ, trí nhớ đời trước sinh khởi, có thể lần ngược và nhớ lại câu chuyện đau lòng trong kiếp trước. Nhìn lại bằng trí ấy, vị ấy nhớ rõ chuyện đau lòng khi làm Cūḷasubhaddā, bạn đời của voi chúa Chaddanta, rồi bật khóc lớn. Đức Phật liền thuyết cho hội chúng nghe chuyện tiền thân voi chúa Chaddanta…

**EN**
Just then, knowledge that could trace back and recollect former lives arose in the young bhikkhunī’s continuum. Looking back with that knowledge, she vividly recalled the painful story of her life as Cūḷasubhaddā, consort of the elephant king Chaddanta, and burst into loud tears. The Buddha then related to the assembly the birth story of the elephant king Chaddanta…


<a id="M05-body-P065"></a>
## Hai voi cái và duyên của việc cúng dường / The two she-elephants and the circumstances of their offering
Miến / Burmese 65

**VI**
…Voi chúa Chaddanta có hai bạn đời là Cūḷasubhaddā và Mahāsubhaddā. Vị tỳ-khưu-ni trẻ ấy chính là Cūḷasubhaddā khi xưa.

**EN**
…Chaddanta, the elephant king, had two consorts, Cūḷasubhaddā and Mahāsubhaddā. The young bhikkhunī had been Cūḷasubhaddā.

**VI**
Một ngày nọ, voi chúa Chaddanta cùng đàn voi đi vào khu rừng cây sāla đang nở hoa. Khi voi chúa làm rung cây, cành và lá khô rơi trên mình Cūḷasubhaddā đang đứng đầu gió, còn phấn hoa và cánh hoa rơi trên mình Mahāsubhaddā đang đứng cuối gió. Cūḷasubhaddā bất bình về việc ấy. Một ngày khác, khi đàn voi chơi dưới nước ở hồ Chaddanta, một con voi hái được một đóa sen paduma lớn gọi là sattuddhaya và dâng lên voi chúa. Voi chúa dùng vòi nâng đóa sen, rũ phấn hoa lên mình Mahāsubhaddā rồi trao đóa sen cho nàng. Cūḷasubhaddā cũng không hài lòng về việc ấy. Do hai việc này, Cūḷasubhaddā sinh lòng oán hận đối với Bồ-tát là voi chúa Chaddanta.

**EN**
One day Chaddanta went with the herd into a grove of blossoming sāla trees. When the elephant king shook a tree, dry branches and leaves fell on Cūḷasubhaddā, who stood upwind, while pollen and petals fell on Mahāsubhaddā, who stood downwind. Cūḷasubhaddā was displeased. On another day, while the elephants played in Lake Chaddanta, one elephant obtained a large paduma lotus called sattuddhaya and presented it to the elephant king. With his trunk he lifted the lotus, shook its pollen over Mahāsubhaddā, and gave her the flower. Cūḷasubhaddā was displeased with this too. Because of these two incidents she came to bear a grudge against the Bodhisatta, Chaddanta.

**VI**
Khi ấy hơn tám nghìn con voi, đứng đầu là Chaddanta, có cơ hội cúng dường trái cây, vật thực và những thứ tương tự đến năm trăm vị Phật Độc Giác. Đây là một cơ hội tốt hiếm có. Đàn voi do Chaddanta đứng đầu cũng đầy đủ giới thanh tịnh. Vì vậy sự bố thí của họ hội đủ năm yếu tố sau.

**EN**
At that time more than eight thousand elephants, led by Chaddanta, had an opportunity to offer fruit, food, and the like to five hundred solitary Buddhas. This was a rare opportunity. The herd led by Chaddanta was also endowed with pure virtue. Their giving thus met the following five conditions.

**VI**
1. Người bố thí có giới.
2. Vật thí được tìm kiếm bằng phương tiện chân chánh.
3. Tâm có niềm tin trong sáng.

**EN**
1. The donor is virtuous.
2. The gift is obtained by righteous means.
3. The mind has clear confidence.


<a id="M05-body-P066"></a>
## Sự bố thí hội đủ duyên và lời nguyện của Cūḷasubhaddā / Giving with the requisite conditions and Cūḷasubhaddā’s aspiration
Miến / Burmese 66

**VI**
4. Có niềm tin vững chắc vào nghiệp và quả của nghiệp.
5. Những người nhận cũng có giới thanh tịnh.

**EN**
4. There is firm confidence in kamma and its results.
5. The recipients also possess pure virtue.

**VI**
Sự bố thí hội đủ năm yếu tố ấy. Hãy xem Kinh Phân biệt cúng dường (Dakkhiṇāvibhaṅgasutta). Đây là loại bố thí có sức đem lại nhiều quả tốt đẹp, lớn lao. Theo lời dạy “Ijjhati, bhikkhave, sīlavato cetopaṇidhi visuddhattā” (Aṅguttara Nikāya, tập 3, tr. 71), vì giới trong sạch nên sự bố thí ấy có thể làm thành tựu những điều tâm mong nguyện. Cūḷasubhaddā hiểu rằng đây là một cơ hội tốt lớn lao. Vì vậy, sau khi cúng trái cây của mình đến các vị Phật Độc Giác, nàng phát nguyện như sau.

**EN**
The giving fulfilled these five conditions. See the Discourse on the Analysis of Offerings (Dakkhiṇāvibhaṅgasutta). It was a kind of giving capable of producing abundant and excellent results. As stated in the teaching “Ijjhati, bhikkhave, sīlavato cetopaṇidhi visuddhattā” (Aṅguttara Nikāya, vol. 3, p. 71), because virtue is pure, that gift can fulfil the aspirations of the mind. Cūḷasubhaddā understood that this was a great opportunity. So after offering her own fruit to the solitary Buddhas, she made the following aspiration.

**VI**
“Bhante, ito cavitvā Maddarājakule nibbattitvā Subhaddā nāma rājakaññā hutvā vayappattā Bārāṇasirañño aggamahesibhāvaṃ patvā tassa piyā manāpā taṃ attano ruciṃ kāretuṃ samatthā hutvā taṃ ācikkhitvā ekaṃ luddakaṃ pesetvā imaṃ hatthiṃ visapītena sallena vijjhāpetvā jīvitakkhayaṃ pāpetvā chabbaṇṇaraṃsiṃ vissajjente yamakadante āharāpetuṃ samatthā homi.” (Chú giải Jātaka, tập 5, tr. 40)

**EN**
“Bhante, ito cavitvā Maddarājakule nibbattitvā Subhaddā nāma rājakaññā hutvā vayappattā Bārāṇasirañño aggamahesibhāvaṃ patvā tassa piyā manāpā taṃ attano ruciṃ kāretuṃ samatthā hutvā taṃ ācikkhitvā ekaṃ luddakaṃ pesetvā imaṃ hatthiṃ visapītena sallena vijjhāpetvā jīvitakkhayaṃ pāpetvā chabbaṇṇaraṃsiṃ vissajjente yamakadante āharāpetuṃ samatthā homi.” (Jātaka Commentary, vol. 5, p. 40)

**VI**
1. Bạch các ngài, sau khi chết ở đây, nguyện tôi được sinh trong hoàng tộc Madda.
2. Nguyện tôi là công chúa tên Subhaddā trong hoàng tộc ấy.
3. Khi đến tuổi trưởng thành, nguyện tôi được làm chánh hậu của vua xứ Kāsi.
4. Nguyện tôi là hoàng hậu được vị vua xứ Kāsi ấy yêu quý và tin cậy.

**EN**
1. Venerable ones, when I die here, may I be born in the royal family of Madda.
2. May I be a princess named Subhaddā in that family.
3. When I come of age, may I become the chief queen of the king of Kāsi.
4. May I be the queen whom that king of Kāsi loves and trusts.


<a id="M05-body-P067"></a>
## Lời nguyện trả oán và năm pháp làm nhân / The aspiration for revenge and the five causal phenomena
Miến / Burmese 67

**VI**
5. Nguyện tôi có thể khiến vua xứ Kāsi làm theo ý muốn của tôi.
6. Nguyện tôi có thể thuyết phục vua xứ Kāsi sai một người thợ săn đến giết voi chúa Chaddanta bằng mũi tên tẩm độc.
7. Nguyện tôi có thể sai người mang về cặp ngà của voi chúa, tỏa hào quang sáu màu.

**EN**
5. May I be able to make the king of Kāsi act as I wish.
6. May I persuade the king of Kāsi to send a hunter to kill Chaddanta with a poisoned arrow.
7. May I be able to have the elephant king’s tusks brought back, radiating six colors.

**VI**
Đó là lời nguyện của Cūḷasubhaddā, vị hoàng hậu về sau.
1. Vô minh — tính chất biết sai rằng có một chánh hậu tên Subhaddā, có đủ những khả năng nói trên.
2. Ái — tính chất ham muốn và mê đắm đời sống hoàng hậu ấy.
3. Thủ — tính chất tâm tiến đến và bám lấy đời sống ấy.
4. Hành — nhóm hành thiện khi cúng trái cây và vật thực đến các vị Phật Độc Giác.
5. Nghiệp — sức nghiệp của nhóm hành thiện ấy.

**EN**
That was the aspiration of Cūḷasubhaddā, the future queen.
1. Ignorance — the quality of mistakenly knowing that there is a chief queen named Subhaddā endowed with the abilities mentioned above.
2. Craving — the quality of desiring and delighting in that life as queen.
3. Clinging — the quality of the mind going toward and holding to that life.
4. Formations — the group of wholesome formations when offering fruit and food to the solitary Buddhas.
5. Kamma — the kammic power of that group of wholesome formations.

**VI**
Năm pháp làm nhân ấy đã đầy đủ. Đó là loại nghiệp chưa bị Thánh đạo phá bỏ và dứt trừ ngay tại nơi nó đã được vun bồi. Đúng như nàng đã phát nguyện, sau khi chết trong đời voi, nàng sinh làm công chúa Subhaddā của xứ Madda. Nàng trở thành chánh hậu của vua xứ Kāsi và đạt địa vị cao nhất trong số mười sáu nghìn cung nữ.

**EN**
The five causal phenomena were complete. This was the kind of kamma that had yet to be undone and eradicated by the noble path at the very place where it had been accumulated. In accordance with her aspiration, after dying as an elephant she was born as Princess Subhaddā of Madda. She became the chief queen of the king of Kāsi and attained the foremost position among sixteen thousand women of the palace.


<a id="M05-body-P068"></a>
## Voi chúa Chaddanta và người thợ săn Soṇuttara / Chaddanta and the hunter Soṇuttara
Miến / Burmese 68

**VI**
Đến đây đáng lẽ nàng đã mãn nguyện. Nhưng hoàng hậu vẫn không mãn nguyện. Dù đã thành chánh hậu, nàng vẫn không yên cho đến khi giết được Chaddanta, dù vị ấy chỉ là một con vật sống trong rừng. Sức nghiệp đã vun bồi trong quá khứ tiếp tục thúc đẩy nàng, khiến nàng không thể thôi ý định giết. Đó là sức của hành và nghiệp còn được vô minh, ái và thủ bao quanh. Cuối cùng nàng sai người thợ săn Soṇuttara đi và lấy được cặp ngà của voi chúa Chaddanta. Cảnh tượng đau lòng ấy diễn ra như sau.

**EN**
By this point she might have been satisfied. Yet the queen was still dissatisfied. Even as chief queen she could not rest until Chaddanta, an animal living in the forest, had been killed. The kammic power accumulated in the past kept urging her on, so that she could not give up the intention to kill. This was the power of formations and kamma still surrounded by ignorance, craving, and clinging. Finally she sent the hunter Soṇuttara and obtained Chaddanta’s tusks. The painful scene unfolded as follows.

**VI**
“Evarūpaṃ sobhaggappattaṃ vāraṇaṃ visapītena sallena jīvitakkhayaṃ pāpetvā ime dante chinditvā Sonuttaro āgato”ti mahāsattaṃ anussarantī sokaṃ uppādetvā adhivāsetuṃ nāsakkhi. Athassā tatheva hadayaṃ phali, taṃ divasameva kālamakāsi. (Chú giải Jātaka, tập 5, tr. 56)

**EN**
“Evarūpaṃ sobhaggappattaṃ vāraṇaṃ visapītena sallena jīvitakkhayaṃ pāpetvā ime dante chinditvā Sonuttaro āgato”ti mahāsattaṃ anussarantī sokaṃ uppādetvā adhivāsetuṃ nāsakkhi. Athassā tatheva hadayaṃ phali, taṃ divasameva kālamakāsi. (Jātaka Commentary, vol. 5, p. 56)

**VI**
Khi người thợ săn Soṇuttara dâng cặp ngà tuyệt đẹp, chiếu sáng sáu màu, hoàng hậu Subhaddā nâng chúng đặt vào lòng và nhìn chúng. Nàng tưởng như trông thấy người chồng yêu quý đời trước và nhớ đến đức hạnh của Bồ-tát: “Vị voi chúa có hình dáng và tầm vóc như thế, nay đã bị mũi tên tẩm độc bắn đến chết. Người thợ săn Soṇuttara đã cắt ngà của vị ấy và đem về.” Khi nhìn cặp ngà và nhớ đến những đức hạnh của Bồ-tát, nàng sinh sầu muộn vì xa lìa người yêu quý. Nỗi sầu mạnh đến mức ngay hôm ấy tim nàng vỡ ra và nàng qua đời. (Chú giải Jātaka, tập 5, tr. 56.)

**EN**
When the hunter Soṇuttara presented the magnificent tusks, radiant in six colors, Queen Subhaddā lifted them onto her lap and looked at them. It was as if she saw her beloved husband from her former life, and she remembered the Bodhisatta’s virtues: “An elephant king of such form and stature has now been shot dead with a poisoned arrow. The hunter Soṇuttara has cut off his tusks and brought them back.” As she looked at the tusks and remembered the Bodhisatta’s virtues, sorrow at separation from the one she loved arose. The sorrow was so strong that her heart broke and she died that very day. (Jātaka Commentary, vol. 5, p. 56.)


<a id="M05-body-P069"></a>
## Một ví dụ của hành giả / An example from a meditator
Miến / Burmese 69

**VI**
Trong đời làm hoàng hậu Subhaddā, bà đã có một lần tái sinh và một lần chết. Nay, trong đời làm tỳ-khưu-ni, bà lại tái sinh lần thứ hai. Vì thế, người thiện nên hết sức thận trọng khi tạo nghiệp. Đến đây, có lẽ đã có thể hiểu khá rõ về vô minh, ái, thủ, hành và nghiệp.

**EN**
In her life as Queen Subhaddā, she had one rebirth and one death. Now, in her life as a bhikkhunī, she was reborn a second time. Thus a good person should exercise great care in making kamma. By this point, ignorance, craving, clinging, formations, and kamma should be fairly clear.

**VI**
Để hiểu rõ hơn, xin nêu thêm một ví dụ của hành giả. Khi chú tâm tìm đối tượng của lộ cận tử trong đời trước rồi quán danh sắc, hành giả thấy nghiệp tướng hiện rõ trong tâm ngay trước lộ cận tử đời trước, đó là đang dâng trái cây cúng dường một vị tăng. Lại dựa vào bốn đại trong dòng thân tâm lúc dâng trái cây để tiếp tục quán danh sắc, hành giả thấy các lộ tâm phát nguyện trở thành một phụ nữ ở thành phố lớn, có học vấn hiện đại, do chán cảnh quê nghèo khổ và thất học. Hành giả cũng thấy các lộ tâm thuộc nhóm tư thiện khi dâng trái cây. Trong đó có các pháp sau.

**EN**
To make this clearer, here is another example from a meditator. On directing attention to the object of the near-death process in the previous life and discerning mentality and materiality, the meditator saw a sign of kamma manifest in the mind just before that process, namely the offering of fruit to a member of the Saṅgha. Continuing to discern mentality and materiality based on the four great elements in the continuum at the time of the offering, the meditator saw the mental processes of aspiring to become a woman in a large city with a modern education, weary of the poverty, hardship, and lack of modern education of rural life. The meditator also saw the mental processes of the group of wholesome volitions in offering fruit. They included the following.

**VI**
1. Vô minh (avijjā, 20) là nhận lầm rằng có một phụ nữ thành thị có học vấn hiện đại.
2. Ái (taṇhā, 20) là ham muốn, dính mắc vào đời sống của người nữ ấy.
3. Thủ (upādāna, 20) là sự bám chặt của tâm vào đời sống của người nữ ấy.

**EN**
1. Ignorance (avijjā, 20) is the mistaken perception of a city woman with a modern education.
2. Craving (taṇhā, 20) is longing and attachment for that woman's life.
3. Clinging (upādāna, 20) is the mind's firm attachment to that woman's life.


<a id="M05-body-P070"></a>
## Phân biệt nhân quả và một ví dụ khác / Discerning cause and effect, and another example
Miến / Burmese 70

**VI**
4. Hành (saṅkhāra, 34) là nhóm tư thiện khi dâng trái cây cúng dường vị tăng.
5. Nghiệp (kamma) là năng lực tạo quả của hành ấy (34).

**EN**
4. Formation (saṅkhāra, 34) is the group of wholesome volition in offering fruit to the member of the Saṅgha.
5. Kamma is the productive power of that formation (34).

**VI**
Ở đây, 20 là 20 danh pháp thuộc nhóm tham và tà kiến, hiện hữu trong những tâm tốc hành tham của lộ ý môn thuộc phiền não luân. Số 34 là các tâm sở cùng với tâm trong những tâm tốc hành thiện của lộ ý môn khi dâng trái cây, tức các danh pháp thuộc nhóm tín và tuệ.

**EN**
Here, 20 denotes the twenty mental phenomena of the group with greed and wrong view, present in greed impulsions of the mind-door process belonging to the round of defilements. The number 34 denotes the mental factors together with consciousness in the wholesome impulsions of the mind-door process while offering the fruit, namely the mental phenomena of the group with faith and wisdom.

**VI**
Trong đời này, hành giả ấy đã trở thành một phụ nữ thành thị có học vấn hiện đại. Khi tự mình quán mối liên hệ nhân quả, hành giả thấy bằng chánh kiến rằng năng lực tạo quả của nghiệp thiện dâng trái cây đã làm duyên cho năm uẩn tái tục và các uẩn quả trong đời sống hiện tại. Tuệ thấy xuyên suốt mối liên hệ giữa các pháp nhân và các pháp quả như vậy là tuệ phân biệt nhân duyên (paccayapariggahañāṇa), tức tuệ phân biệt các pháp làm nhân. Để hiểu rõ và sáng tỏ hơn, hãy xem thêm ví dụ dưới đây.

**EN**
In this life, that meditator became a city woman with a modern education. Discerning the causal relationship personally, the meditator saw with right view that the productive power of the wholesome kamma of offering fruit conditioned the five rebirth aggregates and the resultant aggregates during the present life. Knowledge that penetrates the relationship between causal phenomena and resultant phenomena in this way is knowledge of discerning conditions (paccayapariggahañāṇa), knowledge that discerns the causal phenomena. Consider the following example to make this clearer.

**VI**
Một nữ hành giả dò tìm đối tượng lúc cận tử của đời trước. Khi lần lượt khảo sát lui về từ lúc cận tử đến trước lúc chết, bà thấy các nghiệp dưới đây hiện ra quanh thời điểm trước khi chết.

**EN**
A woman meditator investigated the object at the approach of death in her past life. As she repeatedly examined backwards from the approach of death to the time before death, she saw the following kammas appearing around the time before her death.


<a id="M05-body-P071"></a>
## Nghiệp minh sát và lời nguyện / Insight kamma and aspirations
Miến / Burmese 71

**VI**
1. Một nghiệp tặng sách.
2. Một nghiệp chỉ dạy Pháp.
3. Một nghiệp tác ý đến Pháp.
4. Một nghiệp thuyết Pháp.

**EN**
1. A kamma of giving a book.
2. A kamma of instructing someone in the Dhamma.
3. A kamma of attending to the Dhamma.
4. A kamma of teaching the Dhamma.

**VI**
Bốn nghiệp ấy đều lần lượt hiện ra. Khi khảo sát nhiều lần xem nghiệp nào đã làm sinh khởi năm uẩn tái tục và các pháp quả trong đời sống hiện tại, bà thấy chính nghiệp tác ý đến Pháp đang cho quả. Việc tác ý đến Pháp ấy là đối tượng nghiệp hiện ra lúc cận tử. Khi lại khảo sát xem mình đang tác ý đến những pháp nào, bà thấy đó là nghiệp minh sát, đang quán sát và thẩm xét các pháp chân đế danh sắc theo ba đặc tướng. Hãy phân biệt rõ đến mức thành thạo mối liên hệ nhân quả giữa nghiệp minh sát ấy và năm uẩn tái tục trong hiện tại. Khi lại khảo sát vì sao nghiệp minh sát ấy làm sinh khởi tái tục, bà thấy lúc tu tập minh sát, mỗi khi vừa tu tập xong đề mục minh sát, bà thường nguyện như sau.

**EN**
The four kammas appeared in turn. Repeatedly investigating which kamma had produced the five rebirth aggregates and the resultant phenomena during this life, she found that the kamma of attending to the Dhamma was giving its result. That act of attending to the Dhamma was the kamma that appeared as her object at the approach of death. When she examined which phenomena she was attending to, she found that it was insight kamma: discerning and examining the ultimate phenomena of materiality and mentality in terms of the three characteristics. Discern the causal relationship between that insight kamma and the five present rebirth aggregates until proficient. When she further examined why this insight kamma gave rise to rebirth, she saw that while cultivating insight, each time she finished cultivating the insight meditation subject, she would make the following aspirations.

**VI**
1. Nguyện được sinh làm người.
2. Nguyện được xuất gia.
3. Nguyện gặp được Giáo pháp.

**EN**
1. May I be reborn as a human being.
2. May I go forth.
3. May I encounter the Buddha's Dispensation.

**VI**
Đó là ba điều mà nữ hành giả thường nguyện mỗi khi ngồi thiền.
1. Vô minh (avijjā, 20) là nhận lầm rằng có người, vị tỳ-khưu và người được gặp Giáo pháp.

**EN**
These were the three aspirations the woman meditator regularly made when she sat to meditate.
1. Ignorance (avijjā, 20) is the mistaken perception of a human being, a bhikkhu, and a person who has encountered the Dispensation.


<a id="M05-body-P072"></a>
## Nghiệp minh sát có thể cho quả tái tục / Insight kamma can give a rebirth result
Miến / Burmese 72

**VI**
2. Ái (taṇhā, 20) là sự ham muốn, dính mắc vào đời sống ấy.
3. Thủ (upādāna, 20) là sự bám chặt của tâm vào đời sống ấy.
4. Hành (saṅkhāra, 34) là nhóm hành thiện minh sát.
5. Nghiệp (kamma) là năng lực tạo quả của hành ấy (34).

**EN**
2. Craving (taṇhā, 20) is longing and attachment for that life.
3. Clinging (upādāna, 20) is the mind's firm attachment to that life.
4. Formations (saṅkhāra, 34) are the group of wholesome insight formations.
5. Kamma is the productive power of those formations (34).

**VI**
Như vậy đã đủ năm pháp làm nhân. Có thể hỏi liệu các nghiệp minh sát này có thể cho quả tái tục và những quả tương tự như trong ví dụ vừa nêu hay không. Câu trả lời là có thể cho quả.

**EN**
The five causal phenomena are thus complete. One may ask whether these insight kammas can yield rebirth and similar results, as in the example above. The answer is that they can yield results.

**VI**
“No ce, bhikkhave, ceteti, no ce pakappeti, atha ce anuseti, ārammaṇametaṃ hoti viññāṇassa ṭhitiyā.” (Saṃyutta Nikāya, tập 1, tr. 295, Cetanāsutta)

**EN**
“No ce, bhikkhave, ceteti, no ce pakappeti, atha ce anuseti, ārammaṇametaṃ hoti viññāṇassa ṭhitiyā.” (Saṃyutta Nikāya, vol. 1, p. 295, Cetanāsutta)

**VI**
No ce bhikkhave cetetīti iminā tebhūmakacetanāya appavattanakkhaṇo vutto. No ce pakappetīti iminā taṇhādiṭṭhikappānaṃ appavattanakkhaṇo. Atha ce anusetīti iminā tebhūmakavipākesu parittakiriyāsu rūpeti ettha appahīnakoṭiyā anusayo gahito. Ārammaṇametaṃ hotīti anusaye sati kammaviññāṇassa uppattiyā avāritattā etaṃ anusayajātaṃ paccayova hoti. (Chú giải Saṃyutta, tập 2, tr. 66.)

**EN**
No ce bhikkhave cetetīti iminā tebhūmakacetanāya appavattanakkhaṇo vutto. No ce pakappetīti iminā taṇhādiṭṭhikappānaṃ appavattanakkhaṇo. Atha ce anusetīti iminā tebhūmakavipākesu parittakiriyāsu rūpeti ettha appahīnakoṭiyā anusayo gahito. Ārammaṇametaṃ hotīti anusaye sati kammaviññāṇassa uppattiyā avāritattā etaṃ anusayajātaṃ paccayova hoti. (Saṃyutta Commentary, vol. 2, p. 66.)

**VI**
“Này các tỳ-khưu, nếu không có tư” nói đến lúc tư thuộc ba cõi không vận hành. “Nếu không hoạch định” nói đến lúc sự hoạch định do ái và kiến không vận hành. “Nhưng nếu còn tiềm phục” nói đến tùy miên theo nghĩa chưa được đoạn trừ đối với các pháp quả thuộc ba cõi, các pháp duy tác dục giới và sắc. “Điều ấy là đối tượng” nghĩa là khi còn tùy miên thì sự sinh khởi của nghiệp thức chưa bị ngăn chặn, nên tùy miên ấy làm duyên.

**EN**
“Bhikkhus, if one does not intend” refers to the occasion when volition belonging to the three planes does not occur. “If one does not plan” refers to the occasion when planning through craving and views does not occur. “But if there is an underlying tendency” takes the tendency in the sense that it has not been abandoned in relation to results belonging to the three planes, sense-sphere functional states, and materiality. “This is an object” means that, while the underlying tendency remains, the arising of kamma-consciousness is unobstructed. Hence that underlying tendency serves as a condition.

**VI**
Ettha ca “no ce bhikkhave ceteti no ce pakappeti, atha ce anusetī”ti evaṃ bhagavatā dutiyanaye pubbabhāge bhavanibbattakakusalākusalāyūhanaṃ, pakappanañca vināpi bhavesu diṭṭhādīnavassa yogino anusayapaccayā vipassanācetanāpi paṭisandhijanakā hotīti dassanatthaṃ kusalākusalassa appavatti cepi tadā vijjamānatebhūmakavipākādidhammesu appahīnakoṭiyā anusayitakilesapaccayā bhavavaṭṭassa kammaviññāṇassa patiṭṭhitatā hotīti dassanatthañca vuttaṃ. (Phụ chú giải Saṃyutta, tập 2, tr. 83.)

**EN**
Ettha ca “no ce bhikkhave ceteti no ce pakappeti, atha ce anusetī”ti evaṃ bhagavatā dutiyanaye pubbabhāge bhavanibbattakakusalākusalāyūhanaṃ, pakappanañca vināpi bhavesu diṭṭhādīnavassa yogino anusayapaccayā vipassanācetanāpi paṭisandhijanakā hotīti dassanatthaṃ kusalākusalassa appavatti cepi tadā vijjamānatebhūmakavipākādidhammesu appahīnakoṭiyā anusayitakilesapaccayā bhavavaṭṭassa kammaviññāṇassa patiṭṭhitatā hotīti dassanatthañca vuttaṃ. (Saṃyutta Subcommentary, vol. 2, p. 83.)

**VI**
Trong cách trình bày thứ hai, Đức Thế Tôn nói như vậy để chỉ rõ rằng ngay cả khi hành giả đã thấy sự nguy hại trong các hữu và trước đó không tích lũy thiện hay bất thiện làm sinh hữu, cũng không hoạch định, tư minh sát vẫn có thể sinh tái tục do tùy miên làm duyên. Ngài cũng chỉ rõ rằng dù thiện và bất thiện không vận hành vào lúc ấy, nghiệp thức thuộc vòng hữu vẫn được thiết lập do các phiền não tiềm phục làm duyên, vì chúng chưa được đoạn trừ đối với các pháp đang hiện hữu, như quả thuộc ba cõi.

**EN**
In the second presentation the Blessed One spoke thus to show that, even without prior accumulation of wholesome or unwholesome kamma productive of existence, and without planning, insight volition can still generate rebirth-linking in a meditator who has seen the danger in states of existence, owing to the underlying tendencies. He also spoke thus to show that, even when wholesome and unwholesome states are not occurring then, the establishment of kamma-consciousness in the round of existence occurs, conditioned by latent defilements still unabandoned in relation to phenomena then present, such as results belonging to the three planes.


<a id="M05-body-P073"></a>
## Miến 73 / Burmese page 73
Miến / Burmese 73

**VI**
Này các tỳ-khưu… Dù không ra sức làm khởi lên tư thiện hay tư bất thiện khiến vòng luân hồi tiếp tục, và cũng không hoạch định hay tưởng nghĩ cùng với ái và kiến, chẳng hạn “nguyện được làm người, nguyện được làm chư thiên”, khuynh hướng tùy miên vẫn còn hiện hữu vì chưa được Thánh đạo đoạn trừ. Chính sự hiện hữu của khuynh hướng tùy miên ấy là nhân cho nghiệp thức có khả năng cho quả tái tục được thiết lập trong một đời sống mới về sau. (Saṃyutta Nikāya, tập 1, tr. 295.)

**EN**
Bhikkhus… Even if one does not exert oneself to bring forth wholesome or unwholesome volition that keeps the round of saṃsāra turning, and does not plan or imagine in association with craving and views, for example, “May I become a human being, may I become a deva,” the underlying tendency is still present because the noble path has yet to eradicate it. The very presence of that underlying tendency is a cause for the establishment, in a future life, of kamma-consciousness capable of giving the result of rebirth-linking. (Saṃyutta Nikāya, vol. 1, p. 295.)

**VI**
Khi khuynh hướng tùy miên còn hiện hữu vì chưa được Thánh đạo đoạn trừ, nó không thể ngăn sự sinh khởi của nghiệp thức có khả năng cho quả tái tục trong một đời sống mới về sau. Vì vậy chính sự còn hiện hữu của khuynh hướng tùy miên là nhân cho nghiệp thức được thiết lập. (Chú giải Saṃyutta, tập 2, tr. 66.)

**EN**
When the underlying tendency is still present because the noble path has yet to eradicate it, the arising of kamma-consciousness capable of giving the result of rebirth-linking in a future life cannot be prevented. Hence the continued presence of the underlying tendency is a cause for the establishment of kamma-consciousness. (Saṃyutta Commentary, vol. 2, p. 66.)

**VI**
Trong Cetanāsutta, Đức Phật thuyết ba trường hợp sau.
1. Thiện và bất thiện thuộc vòng luân hồi, đi cùng với ái và kiến hoặc đang sinh khởi.
2. Thiện và bất thiện hướng ra khỏi vòng luân hồi, không tương ưng với ái và kiến, hoặc tư thuộc ba cõi trong trường hợp tư ấy không sinh khởi.
3. Các tâm duy tác sinh trong dòng danh sắc của các bậc A-la-hán đã đoạn trừ tùy miên, chẳng hạn các tâm khi bố thí, trì giới, tu thiền chỉ và minh sát.

**EN**
In the Cetanāsutta the Buddha taught the following three cases.
1. Wholesome and unwholesome states belonging to the round, associated with craving and views or occurring.
2. Wholesome and unwholesome states tending away from the round, unassociated with craving and views, or volition of the three planes in the case where that volition does not occur.
3. Functional consciousness arising in the continuum of arahants who have abandoned the underlying tendencies, such as consciousness in giving, observing virtue, and developing serenity and insight.


<a id="M05-body-P074"></a>
## Miến 74 / Burmese page 74
Miến / Burmese 74

**VI**
Đức Phật đã thuyết theo ba cách như vậy. Trong cách thứ hai, tức mục 2 đã dịch ở trên, trước và sau khi hành minh sát, hành giả không ra sức tạo thiện hay bất thiện có khả năng làm sinh hữu. Hành giả cũng không hoạch định hay tưởng nghĩ với ái và kiến theo kiểu “nguyện được làm nam, nguyện được làm nữ, nguyện được làm người, nguyện được làm chư thiên”. Hành giả thấy sự nguy hại trong các hữu. Đối với hành giả như vậy, vì khuynh hướng tùy miên vẫn còn trong dòng danh sắc, tư minh sát đi cùng tuệ minh sát vẫn có khả năng làm sinh tái tục. Để làm rõ ý nghĩa ấy, Đức Phật đã thuyết theo cách thứ hai.

**EN**
The Buddha taught in these three ways. In the second, item 2 translated above, before and after practising insight the meditator does not exert effort to produce wholesome or unwholesome kamma capable of producing existence. Nor does the meditator plan or imagine with craving and views, “May I become a man, may I become a woman, may I become a human being, may I become a deva.” The meditator sees the danger in states of existence. In such a meditator, because the underlying tendencies are still present in the continuum, insight volition associated with insight knowledge is still capable of producing rebirth-linking. The Buddha taught the second way to make this meaning clear.

**VI**
Nghiệp minh sát là loại nghiệp làm cạn kiệt những nghiệp khiến vòng luân hồi tiếp tục. Khi các tuệ minh sát liên tục sinh khởi, thiện và bất thiện khiến vòng luân hồi tiếp tục không có cơ hội sinh khởi. Tuy nhiên, ngay lúc tuệ minh sát sinh, các phiền não tùy miên vẫn còn tiềm phục, vì Thánh đạo chưa đoạn trừ chúng đối với các pháp đang hiện hữu trong dòng danh sắc của hành giả, gồm các pháp quả thuộc ba cõi, các pháp duy tác dục giới và sắc. Chính vì các phiền não tùy miên vẫn còn hiện hữu mà nghiệp thức có khả năng làm sinh tái tục trong một đời sống mới về sau được thiết lập. Sự nguy hại ấy vẫn hiện hữu. Để làm rõ ý nghĩa ấy, Đức Phật đã thuyết theo cách thứ hai. (Phụ chú giải Saṃyutta, tập 2, tr. 83.)

**EN**
Insight kamma is a kind of kamma that brings to exhaustion the kammas that keep the round of saṃsāra turning. While insight knowledges arise without interruption, wholesome and unwholesome states that keep the round turning have no opportunity to arise. Yet at the moment insight knowledge arises, the underlying defilements remain latent, because the noble path has yet to eradicate them in relation to the phenomena present in the meditator’s continuum of mentality and materiality, including results belonging to the three planes, sense-sphere functional states, and materiality. Precisely because those underlying defilements are still present, kamma-consciousness capable of producing rebirth-linking becomes established in a future life. The danger is still present. The Buddha taught the second way to make this meaning clear. (Saṃyutta Subcommentary, vol. 2, p. 83.)

**VI**
Ở hành giả được nêu làm ví dụ trên, phần nhiều cả trước lẫn sau khi hành minh sát, ta thấy có sự bao quanh của các khuynh hướng tùy miên…

**EN**
In the example of the meditator above, for the most part, both before and after insight practice, one finds an encircling presence of underlying tendencies…


<a id="M05-body-P075"></a>
## Miến 75 / Burmese page 75
Miến / Burmese 75

**VI**
…và cả ái và kiến. Nếu nghiệp minh sát của người thiện vẫn còn khuynh hướng tùy miên có thể cho quả tái tục, thì nghiệp minh sát của người vừa còn khuynh hướng tùy miên vừa có ái và kiến bao quanh cũng có thể cho quả tái tục. Điều này cũng phù hợp với Sotānugatasutta trong Phẩm Bốn pháp của Tăng chi bộ (Tăng chi bộ, tập 1, tr. 504–507). Liên quan đến hành giả ấy, có một điểm đáng ghi nhớ. Dù các tuệ minh sát đã sinh trong đời trước, hành giả hoàn toàn chưa thấy duyên khởi. Do đó, các tuệ minh sát sinh trong đời trước ấy chưa đủ mạnh để trợ giúp bằng năng lực của duyên y chỉ mạnh cho đến khi Thánh đạo hiển hiện. Trường hợp này giống như Trưởng lão Channa, người từng lầm nhận mình là Channa, người đánh xe. (Xem Channasutta, Tương ưng bộ, tập 2, tr. 108.)

**EN**
…as well as craving and views. If the insight kamma of a good person who still has underlying tendencies can produce the result of rebirth-linking, the insight kamma of one who still has underlying tendencies and is also surrounded by craving and views can likewise produce that result. This agrees with the Sotānugatasutta in the Book of Fours of the Aṅguttara Nikāya (Aṅguttara Nikāya, vol. 1, pp. 504–507). One point about that meditator is worth remembering. Although insight knowledges arose in the previous life, the meditator had not seen dependent origination at all. Consequently, those past insight knowledges were not strong enough to support the meditator by the power of decisive support all the way to the manifestation of the noble path. The case resembles that of the Elder Channa, who had mistakenly identified himself as Channa the charioteer. (See the Channasutta, Saṃyutta Nikāya, vol. 2, p. 108.)

**VI**
Phiền não luân và nghiệp luân

**EN**
The round of defilements and the round of kamma

**VI**
Xin giải thích thêm đôi chút về phiền não luân và nghiệp luân. Tâm và các tâm sở được gọi là phiền não luân và nghiệp luân không có khả năng sinh riêng lẻ. Chúng chỉ có thể sinh cùng các pháp tương ưng. Ngay cả khi sinh cùng các pháp tương ưng, chúng chỉ có thể sinh theo quy luật của tâm, tức theo lộ tâm. Chúng không thể chệch khỏi trình tự thông thường ấy, đảo ngược hay sinh tùy tiện theo ý muốn. Lại nữa, phiền não luân và nghiệp luân có khả năng cho quả tái tục chỉ thuộc về các tốc hành ý môn. Tốc hành ngũ môn chỉ có thể làm sinh quả trong thời bình nhật…

**EN**
A little more should be explained about the round of defilements and the round of kamma. Consciousness and the mental factors called the round of defilements and the round of kamma lack the power to arise in isolation. They can arise only together with their associated phenomena. Even when arising with their associated phenomena, they can arise only in accordance with the law governing consciousness, in what is called a cognitive process. They cannot deviate from that customary course, turn back, or arise haphazardly as one might wish. Moreover, the round of defilements and the round of kamma capable of producing a rebirth-linking result belong only to mind-door impulsions. Five-door impulsions can produce only results during the course of life…


<a id="M05-body-P076"></a>
## Miến 76 / Burmese page 76
Miến / Burmese 76

**VI**
…chúng không thể cho quả tái tục. Tốc hành ý môn có khả năng cho cả hai loại quả, quả tái tục và quả trong thời bình nhật. Ở đây, để hiểu rõ, xin giải thích bằng một ví dụ nữa.

**EN**
…they cannot produce a rebirth-linking result. Mind-door impulsions have the capacity to produce both types of result, at rebirth-linking and during the course of life. To clarify the point, consider another example.

**VI**
Khi hướng đến và tìm đối tượng của lộ cận tử đời trước, giả sử cảnh nghiệp dâng vật thực cúng dường bảo tháp hiện ra. Hãy tiếp tục quán các lộ tốc hành thiện trong khi dâng vật thực ấy. Hãy tiếp tục quán cả những lộ tốc hành ý môn do vô minh, ái và thủ dẫn đầu, bao quanh thiện nghiệp ấy. Dù chưa quán thành công, hoặc dù chỉ thấy hình ảnh dâng vật thực, ngay lúc ấy hãy bắt đầu quán bốn đại trong hình ảnh người đang dâng vật thực đó. Sau đó hãy tiếp tục quán các sắc pháp và danh pháp sinh trong khi dâng vật thực. Hãy đặc biệt chú trọng quán sắc ý vật và ý môn, tức hữu phần trong sáng. Trong số các hữu phần trong sáng ấy, hãy nhiều lần quán đi quán lại những hữu phần làm ý môn có mặt ngay trước và trong lúc dâng vật thực đến bảo tháp. Rồi tiếp tục quán các lộ tốc hành ý môn xen giữa những hữu phần làm ý môn ấy, cả lộ tâm đang dâng vật thực lẫn lộ tâm đang phát nguyện. Trong các lộ tâm ấy, cần tìm cho ra phiền não luân, tức vô minh, ái và thủ, cùng nghiệp luân, tức hành và nghiệp.

**EN**
When you look back for the object of the previous life's near-death process, suppose the kamma-object of offering food at a stūpa actually appears. Continue discerning the wholesome impulsion processes occurring as the food is offered. Continue discerning also the mind-door impulsion processes, led by ignorance, craving, and clinging, that surround that wholesome kamma. Even if you have yet to succeed in discerning them, or can see only the image of the offering, begin at that point by discerning the four great elements in the image of the person offering food. Then continue discerning the material and mental phenomena that arose during the offering. Give particular attention to discerning the heart-base and the mind door, the clear life-continuum. Among those clear life-continua, discern repeatedly the life-continuum serving as the mind door immediately before and during the offering of food at the stūpa. Then continue discerning the mind-door impulsion processes interspersed among those moments of life-continuum serving as the mind door, both the processes of offering food and those of making an aspiration. In these processes, find the round of defilements, namely ignorance, craving, and clinging, and the round of kamma, namely formations and kamma.


<a id="M05-body-P077"></a>
## Miến 77 / Burmese page 77
Miến / Burmese 77

**VI**
Để hiểu rõ, xin nêu một ví dụ. Giả sử hành giả phát nguyện “Nguyện tôi trở thành một vị tỳ-khưu có thể chứng đạt Niết-bàn” hoặc “Nguyện tôi trở thành một người nữ có thể chứng đạt Niết-bàn”.

**EN**
To clarify, consider an example. Suppose the meditator aspires, “May I become a bhikkhu capable of attaining Nibbāna” or “May I become a woman capable of attaining Nibbāna.”

**VI**
Ba pháp thuộc phiền não luân

**EN**
Three phenomena in the round of defilements

**VI**
1. Vô minh là tính chất nhận lầm có một vị tỳ-khưu hoặc một người nữ có thể chứng đạt Niết-bàn.
2. Ái là tính chất ham muốn, đắm nhiễm vào đời sống của một vị tỳ-khưu hoặc một người nữ có thể chứng đạt Niết-bàn.
3. Thủ là tính chất tâm hướng đến và bám chặt lấy đời sống của một vị tỳ-khưu hoặc một người nữ có thể chứng đạt Niết-bàn.

**EN**
1. Ignorance is the quality of mistakenly taking there to be a bhikkhu or a woman capable of attaining Nibbāna.
2. Craving is the quality of longing for and becoming attached to life as a bhikkhu or a woman capable of attaining Nibbāna.
3. Clinging is the quality of the mind approaching and holding fast to life as a bhikkhu or a woman capable of attaining Nibbāna.

**VI**
Vô minh, ái và thủ này là phiền não luân. Các pháp vô minh, ái và thủ được gọi là phiền não luân không có khả năng tự sinh riêng lẻ. Chúng chỉ có thể sinh theo lộ tâm, cùng với những tâm và tâm sở tương ưng như xúc, thọ, tưởng, tư và thức. Nói chung, nhóm tham và kiến có đủ 20 danh pháp. Khi không có hỷ thì đôi lúc có 19 danh pháp. Chúng có thể sinh hữu trợ hoặc vô trợ tùy trường hợp. Chúng cũng có thể sinh cùng thọ xả tùy trường hợp. Đôi khi có nhóm tham và mạn. Đôi khi cũng có thể có nhóm tâm căn tham thiếu cả kiến lẫn mạn. Xét theo trình tự lộ tâm, thông thường một tâm hướng ý môn được theo sau bởi bảy tốc hành. Tâm đồng sở duyên có khi sinh, có khi không. Khi tâm tham ái đối với danh sắc trong đời sống tỳ-khưu mà mình mong cầu, hoặc…

**EN**
This ignorance, craving, and clinging are the round of defilements. Ignorance, craving, and clinging, called the round of defilements, lack the power to arise in isolation. They can arise only in a cognitive process together with associated consciousness and mental factors such as contact, feeling, perception, volition, and consciousness. In general the group with greed and views has a full complement of twenty mental phenomena. At times there are nineteen mental phenomena when joy is absent. They may arise prompted or unprompted, as appropriate, and may arise with equanimous feeling. At times there is a group with greed and conceit. At times there may also be a greed-rooted group with neither views nor conceit. In the usual sequence of the cognitive process, one mind-door adverting is followed by seven impulsions. Registration may arise or may not. When there is craving for the mentality and materiality in the life as a bhikkhu for which one aspires, or…


<a id="M05-body-P078"></a>
## Miến 78 / Burmese page 78
Miến / Burmese 78

**VI**
…danh sắc trong đời sống người nữ mà mình mong cầu, có cơ hội cho tâm đồng sở duyên sinh. Tâm ấy có thể sinh.

**EN**
…for the mentality and materiality in the life as a woman for which one aspires, there is an opportunity for registration. It may arise.

**VI**
1. Trong tâm hướng ý môn có 12 danh pháp.
2. Trong mỗi tốc hành, nếu là nhóm tham và kiến, có 20 danh pháp.
3. Nếu đồng sở duyên sinh, trong mỗi sát-na đồng sở duyên có 34, 33, 33, 32, 12 hoặc 11 danh pháp tùy trường hợp.

**EN**
1. In mind-door adverting there are twelve mental phenomena.
2. In each impulsion, if it is of the group with greed and views, there are twenty mental phenomena.
3. If registration occurs, in each moment of registration there are thirty-four, thirty-three, thirty-three, thirty-two, twelve, or eleven mental phenomena, as appropriate.

**VI**
Có thể sinh theo từng trường hợp như vậy. Trong các nhóm danh pháp ấy có những thành phần sau.

**EN**
These can occur in the respective ways just described. The following are included in those groups of mental phenomena.

**VI**
1. Thọ là thọ uẩn (vedanākkhandha), tức nhóm các pháp thọ.
2. Tưởng là tưởng uẩn (saññākkhandha), tức nhóm các pháp tưởng.
3. Các tâm sở còn lại là hành uẩn (saṅkhārakkhandha), tức nhóm các pháp hành.
4. Tâm hay thức biết là thức uẩn (viññāṇakkhandha), tức nhóm các pháp thức có tính chất biết.

**EN**
1. Feeling is the feeling aggregate (vedanākkhandha), the group of feeling phenomena.
2. Perception is the perception aggregate (saññākkhandha), the group of perception phenomena.
3. The remaining mental factors are the formations aggregate (saṅkhārakkhandha), the group of formation phenomena.
4. Cognizing consciousness is the consciousness aggregate (viññāṇakkhandha), the group of cognizing phenomena.

**VI**
Vì vậy các danh pháp ấy chính là bốn danh uẩn. Sắc ý vật là chỗ nương của các danh pháp ấy, cùng các loại sắc đồng sinh với ý vật, gồm 54 sắc pháp, là sắc uẩn. Các sắc do tâm sinh cũng có thể được tính vào tùy trường hợp. Cộng lại, một sắc uẩn và bốn danh uẩn thành năm uẩn.

**EN**
Thus those mental phenomena constitute the four mental aggregates. The heart-base materiality that serves as their support, together with the material phenomena arising alongside that base, fifty-four kinds of material phenomena, constitutes the materiality aggregate. Mind-produced materiality may also be included as appropriate. Taken together, one materiality aggregate plus four mental aggregates makes five aggregates.

**VI**
1. Năm uẩn ở sát-na hướng ý môn.
2. Năm uẩn ở mỗi sát-na tốc hành.
3. Năm uẩn ở mỗi sát-na đồng sở duyên.

**EN**
1. Five aggregates at the moment of mind-door adverting.
2. Five aggregates at each moment of impulsion.
3. Five aggregates at each moment of registration.

**VI**
Các nhóm ấy phân biệt như vậy. Tùy trường hợp, đồng sở duyên có thể là tâm đại quả, tâm quả thiện vô nhân hoặc tâm quả bất thiện vô nhân. Vì vậy các con số 34, 33, 33, 32…

**EN**
These groups are distinct in the respective ways just described. Registration may occur, as appropriate, as great resultant registration, rootless wholesome-resultant registration, or rootless unwholesome-resultant registration. Hence the figures thirty-four, thirty-three, thirty-three, thirty-two…


<a id="M05-body-P079"></a>
## Hai pháp thuộc nghiệp luân / Two phenomena in the round of kamma
Miến / Burmese 79

**VI**
…12 và 11 được nêu riêng như vậy. Người thiện hãy tự mình khảo sát.

**EN**
…twelve, and eleven are given separately in this way. A good person should investigate this personally.

**VI**
Để quán vô minh, ái và thủ thuộc phiền não luân, tức những pháp bao quanh hành và nghiệp đã được vun bồi trong đời trước và thuộc các nhân quá khứ, người thiện cần biết quán danh và sắc trong hiện tại. Hãy vận dụng trí để phân tích từng nhóm sắc và từng nhóm danh, cho đến khi thấy các pháp chân đế và có thể quán năm uẩn ấy theo cách vừa trình bày. Theo thứ tự các tuệ, đây chính là tuệ phân biệt danh sắc (nāmarūpaparicchedañāṇa), tức tuệ xác định danh sắc (nāmarūpavavatthānañāṇa).

**EN**
To discern ignorance, craving, and clinging in the round of defilements, which surround the formations and kamma accumulated in the previous life and belong to the past causes, a good person needs to know how to discern present mentality and materiality. Use knowledge to break down each group of material and mental phenomena until ultimate phenomena are seen and the five aggregates can be discerned as described. In the sequence of knowledges this is knowledge of delimiting mentality and materiality (nāmarūpaparicchedañāṇa), also called knowledge of defining mentality and materiality (nāmarūpavavatthānañāṇa).

**VI**
Hai pháp thuộc nghiệp luân

**EN**
Two phenomena in the round of kamma

**VI**
Khi dâng vật thực cúng dường bảo tháp tôn quý, tức cúng dường Đức Phật, có thể xảy ra những trường hợp sau.
1. Lấy Đức Phật, bậc thọ nhận, làm đối tượng thì các lộ tốc hành thiện có thể sinh.
2. Lấy vật thí, tức vật thực, làm đối tượng thì các lộ tốc hành thiện cũng có thể sinh.
3. Lấy các tư thiện trước đó trong khi dâng cúng làm đối tượng thì những tư thiện về sau, tức các lộ tốc hành thiện, cũng có thể sinh.

**EN**
When offering food at the venerable stūpa, that is, offering it to the Buddha, the following cases are possible.
1. Wholesome impulsion processes may occur with the Buddha, the recipient, as their object.
2. Wholesome impulsion processes may also occur with the gift, namely the food, as their object.
3. With earlier wholesome volitions during the offering as their object, subsequent wholesome volitions, that is, wholesome impulsion processes, may also occur.

**VI**
Hãy chú tâm quán rõ xem các lộ tốc hành thiện nào sinh trong khi dâng vật thực. Nếu các tốc hành thiện ấy sinh cùng thọ hỷ và tương ưng với trí, thì trong mỗi tốc hành có 34 danh pháp, gồm tâm và các tâm sở. Chúng thuộc nhóm tín và tuệ. Xét theo trình tự lộ tâm…

**EN**
Carefully discern which wholesome impulsion processes occur during the offering of food. If the wholesome impulsions arise with joyful feeling and are associated with knowledge, each impulsion contains thirty-four mental phenomena, consciousness together with its mental factors. They belong to the group with faith and wisdom. In the sequence of a cognitive process…


<a id="M05-body-P080"></a>
## Miến 80 / Burmese page 80
Miến / Burmese 80

**VI**
…có một sát-na hướng ý môn, bảy sát-na tốc hành và hai sát-na đồng sở duyên. Đồng sở duyên có khi sinh và có khi không.

**EN**
…there is one moment of mind-door adverting, seven moments of impulsion, and two moments of registration. Registration sometimes occurs and sometimes does not.

**VI**
1. Ở sát-na hướng ý môn có 12 danh pháp.
2. Ở mỗi sát-na tốc hành có 34 danh pháp.
3. Ở mỗi sát-na đồng sở duyên có 34, 33, 33, 32, 12, 11 hoặc 11 danh pháp.

**EN**
1. At mind-door adverting there are twelve mental phenomena.
2. At each moment of impulsion there are thirty-four mental phenomena.
3. At each moment of registration there are thirty-four, thirty-three, thirty-three, thirty-two, twelve, eleven, or eleven mental phenomena.

**VI**
Các nhóm danh pháp ấy là bốn danh uẩn trong từng trường hợp. Các sắc pháp có ở ý vật, chỗ nương của các danh pháp ấy, là sắc uẩn. Do đó có năm uẩn ở sát-na hướng ý môn, năm uẩn ở mỗi sát-na tốc hành và năm uẩn ở mỗi sát-na đồng sở duyên.

**EN**
These groups of mental phenomena constitute the four mental aggregates in each case. The material phenomena present at the heart-base, the support for those mental phenomena, constitute the materiality aggregate. Thus there are five aggregates at mind-door adverting, five at each moment of impulsion, and five at each moment of registration.

**VI**
Các uẩn sinh theo từng trường hợp như vậy. Trí thấy, biết, quán và phân biệt năm uẩn ấy, theo thứ tự các tuệ, chính là tuệ phân biệt danh sắc (nāmarūpaparicchedañāṇa), tức tuệ xác định danh sắc (nāmarūpavavatthānañāṇa). Năm uẩn thuộc phiền não luân và năm uẩn thuộc nghiệp luân là những uẩn làm nhân cho một số nhóm năm uẩn quả, như tái tục, hữu phần và tử, trong đời hiện tại, dù là đời sống tỳ-khưu hay đời sống người nữ.

**EN**
The aggregates occur in these respective ways. In the sequence of knowledges, the knowledge that sees, knows, discerns, and distinguishes the five aggregates is precisely knowledge of delimiting mentality and materiality (nāmarūpaparicchedañāṇa), or knowledge of defining mentality and materiality (nāmarūpavavatthānañāṇa). The five aggregates in the round of defilements and the five aggregates in the round of kamma are causal aggregates for some groups of five resultant aggregates in the present life, whether as a bhikkhu or as a woman, such as those at rebirth-linking, life-continuum, and death.

**VI**
Trong các nhóm năm uẩn nói trên, 34 danh pháp có trong mỗi tốc hành thiện được gọi là hành vì chúng tạo tác cho năm uẩn, tức danh và sắc của đời sống tỳ-khưu hoặc đời sống người nữ mà mình mong cầu, có thể sinh khởi…

**EN**
Among the groups of five aggregates just described, the thirty-four mental phenomena in each wholesome impulsion are called formations because they form the conditions for the five aggregates, namely the mentality and materiality of the life as a bhikkhu or as a woman that one aspires to, to come into being…


<a id="M05-body-P081"></a>
## Phần tuệ phân biệt nhân duyên / Knowledge of discerning conditions
Miến / Burmese 81

**VI**
…Chúng là các pháp nhân thúc đẩy một đời sống sinh khởi.

**EN**
…They are causal phenomena that bring about an existence.

**VI**
Các pháp hành ấy là vô thường, nên khi sinh rồi chúng diệt. Tuy nhiên, ngay cả khi diệt, chúng không biến mất mà không để lại một năng lực nào trong dòng danh sắc như các uẩn vô ký thuộc quả và duy tác. Chúng để lại trong dòng danh sắc năng lực nghiệp có thể làm sinh năm uẩn của đời sống tỳ-khưu hoặc đời sống người nữ có thể chứng đạt Niết-bàn mà mình mong cầu, rồi mới diệt. Năng lực nghiệp ấy chính là nghiệp.

**EN**
These formations are impermanent and cease after arising. Yet they do not vanish without leaving a power in the continuum of mentality and materiality as do the indeterminate resultant and functional aggregates. They cease after leaving in the continuum of mentality and materiality a kammic potency capable of producing the five aggregates of the aspired-to life as a bhikkhu or a woman capable of attaining Nibbāna. That kammic potency is kamma.

**VI**
Phần tuệ phân biệt nhân duyên

**EN**
Knowledge of discerning conditions

**VI**
Sau khi người thiện tìm thấy các nhân vô minh, ái, thủ, hành và nghiệp đã được tạo dựng từ đời trước như vậy, hãy đối chiếu nghiệp, tức năng lực ấy, với 30 sắc do nghiệp sinh có ở giai đoạn giọt dịch kalala lúc tái tục của mình. Hãy khảo sát nhiều lần xem các sắc do nghiệp sinh lúc tái tục có sinh do nghiệp đó hay không. Hãy quán cho đến khi hiểu được hai bên có liên hệ theo tính chất nhân quả hay không. Cũng như có thể quán rõ tâm và sắc do tâm sinh liên hệ với nhau theo nhân quả hay không, hãy chuyên chú quán rõ nghiệp và sắc do nghiệp sinh có liên hệ nhân quả với nhau hay không.

**EN**
When a good person has found the causes established in the past life, namely ignorance, craving, clinging, formations, and kamma, compare that kamma, the kammic potency, with the thirty kinds of kamma-produced materiality present at the kalala stage of one's own rebirth-linking. Investigate repeatedly whether the kamma-produced materiality at rebirth-linking arose because of that kamma. Discern until it is understood whether the two are connected as cause and effect. Just as one can clearly discern whether consciousness and mind-produced materiality are connected as cause and effect, attend carefully to whether kamma and kamma-produced materiality are so connected.

**VI**
Nếu chúng thật sự liên hệ với nhau theo nhân quả, chính hành giả sẽ thấy rõ bằng trí tuệ chánh kiến rằng các sắc do nghiệp sinh đang sinh nối tiếp do nghiệp ấy…

**EN**
If they truly are connected as cause and effect, the meditator will see directly with the wisdom of right view that kamma-produced materiality is arising in succession because of that kamma…


<a id="M05-body-P082"></a>
## Miến 82 / Burmese page 82
Miến / Burmese 82

**VI**
…Cũng như thấy sắc do tâm sinh đang sinh nối tiếp vì tâm, hành giả sẽ thấy sắc do nghiệp sinh đang sinh nối tiếp vì nghiệp.

**EN**
…Just as the meditator sees mind-produced materiality arising in succession because of consciousness, the meditator will see kamma-produced materiality arising in succession because of kamma.

**VI**
Nếu nghiệp đã tìm được và các sắc do nghiệp sinh, kể cả sắc do nghiệp sinh lúc tái tục, không liên hệ với nhau theo nhân quả, tức nếu không thấy bằng tuệ rằng các sắc do nghiệp sinh ấy sinh do nghiệp kia, thì cần tìm thêm một nghiệp khác đang cho quả. Hãy quay lại tìm các đối tượng hiện ra trong hữu phần làm ý môn trong sáng khi cận tử, lúc lộ cận tử đang diễn ra. Hãy nhìn tiến về phía trước, rồi lùi lại về phía lộ cận tử. Cứ tìm đi tìm lại như vậy. Phải tìm ra một nghiệp thực sự đang cho quả.

**EN**
If the kamma found is not causally connected with kamma-produced materiality, including the kamma-produced materiality at rebirth-linking, that is, if it is not seen with knowledge that this materiality arises because of that kamma, another kamma that is giving its result must be sought. Look again at the objects appearing in the clear life-continuum serving as the mind door at the approach of death, around the time of the near-death process. Look forwards, then back towards the near-death process. Search repeatedly in this way. A kamma that is actually giving its result must be found.

**VI**
Ở một số hành giả, gần lúc chết, hai hay ba nghiệp hoặc nhiều hơn hiện ra nối tiếp không dứt trong hữu phần làm ý môn trong sáng. Các nghiệp có thể cho quả hiện ra lẫn lộn. Giống như khi mở cổng chuồng có nhiều bò bị nhốt, đàn bò trong chuồng chen lấn từng nhóm để thoát ra lúc trời sáng, các nghiệp của một số người gần chết cũng xuất hiện lẫn lộn như vậy. Giống như con bò đực khỏe nhất trong chuồng chen qua những con khác và ra khỏi chuồng trước tiên, trong số nhiều nghiệp hiện ra chen nhau gần lúc chết, nghiệp mạnh nhất cuối cùng có cơ hội cho quả và cho quả trước. Chính nghiệp sắp cho quả ấy là đối tượng cuối cùng của lộ cận tử. Nói theo cách khác, một trong ba đối tượng xuất hiện do năng lực của nghiệp sắp cho quả ấy, tức nghiệp, nghiệp tướng hoặc thú tướng, trở thành đối tượng của lộ cận tử.

**EN**
In some meditators, near death two, three, or more kammas appear in succession in the clear life-continuum serving as the mind door. Kammas capable of giving results appear in confusion. When the gate of a pen holding many cattle is opened at daybreak, the animals jostle in groups to get out. Similarly, in some people kammas appear in confusion at the approach of death. As the strongest bull pushes past the other cattle and comes out first, of the many kammas appearing and vying at the approach of death, the strongest ultimately gains the opportunity to give its result and gives it first. That kamma about to bear fruit is the last object of the near-death process. Put another way, one of the three objects that appear owing to its potency, namely kamma, a sign of kamma, or a sign of destination, becomes the object of the near-death process.


<a id="M05-body-P083"></a>
## Miến 83 / Burmese page 83
Miến / Burmese 83

**VI**
Khi nhiều nghiệp hiện ra gần lúc chết như vậy, cần tìm cho ra đối tượng của lộ cận tử. Từ đối tượng ấy, hãy tìm vô minh, ái, thủ, hành và nghiệp theo phương pháp trước.

**EN**
When many kammas appear at the approach of death in this way, find the object of the near-death process. From that object seek ignorance, craving, clinging, formations, and kamma by the method already given.

**VI**
Khi nhiều nghiệp hiện ra không ngớt và lẫn lộn vào lúc cận tử, nếu một nghiệp trong số ấy là nghiệp sinh (janakakamma), trực tiếp làm sinh quả, những nghiệp khác có thể là nghiệp trợ (upatthambhakakamma), có tác dụng nâng đỡ nghiệp sinh ấy. Khi nhìn lại để tìm đối tượng hiện ra trong hữu phần làm ý môn trong sáng gần lúc chết ở đời trước, hành giả có thể lướt qua đối tượng của lộ cận tử và chú tâm trước vào các đối tượng hiện ra trong hữu phần trong sáng ngay trước lộ cận tử hoặc ít lâu trước đó. Khi quán vượt qua như vậy, có thể gặp trước một nghiệp trợ, tức nghiệp có tác dụng nâng đỡ. Nếu nghiệp đó thực sự là nghiệp trợ, hãy khảo sát nhiều lần xem có liên hệ nhân quả giữa nghiệp ấy và sắc do nghiệp sinh lúc tái tục hay không. Có thể thấy giữa chúng không có mối liên hệ ấy, sắc do nghiệp sinh không sinh trực tiếp từ nghiệp đó. Nếu gặp trước nghiệp sinh có thể trực tiếp làm sinh các sắc do nghiệp sinh, kể cả sắc do nghiệp sinh lúc tái tục, thì khi dùng tuệ quán xem chúng có liên hệ nhân quả hay không, tức các sắc ấy có sinh do nghiệp đó hay không, sẽ thấy chúng thực sự có liên hệ nhân quả.

**EN**
When many kammas appear incessantly and in confusion near death, one may be productive kamma (janakakamma) that directly produces results. Others may be supportive kammas (upatthambhakakamma) that sustain that productive kamma. In looking back to seek the object that appeared in the clear life-continuum serving as the mind door near death in the previous life, the meditator may pass over the object of the near-death process and attend first to objects appearing in the clear life-continuum immediately or a little before that process. By discerning past it in this way, the meditator may first encounter supportive kamma, kamma that lends support. If it is indeed supportive kamma, investigate repeatedly whether it is connected as cause and effect with kamma-produced materiality at rebirth-linking. One can see that there is no such connection, that the kamma-produced materiality does not arise directly because of that kamma. If one first encounters the productive kamma that directly produces kamma-produced materiality, including that at rebirth-linking, discern with knowledge whether they are causally connected, that is, whether that materiality arose because of that kamma. One will see that there is a causal connection.

**VI**
Vì vậy, khi tìm nghiệp quá khứ, hành giả có thể gặp nghiệp trợ có tác dụng nâng đỡ trước, hoặc có thể gặp nghiệp sinh trước. Đó là do quán vượt qua đối tượng. Vì thế cần khảo sát nhiều lần…

**EN**
Thus when seeking past kamma, a meditator may meet supportive kamma first, or may first meet productive kamma. This is because the object may be passed over in discerning. Therefore investigate repeatedly…


<a id="M05-body-P084"></a>
## Sự thay đổi của tướng / Changes in the sign
Miến / Burmese 84

**VI**
…và đối chiếu để biết chính xác có liên hệ nhân quả hay không. Khi đã thấy rõ, hãy chú tâm cho đến khi nắm được đối tượng của lộ cận tử cuối cùng, lộ sinh gần tâm tử nhất trong đời trước. Tướng làm đối tượng ấy xuất hiện do năng lực của nghiệp sắp cho quả. Vì thế khi tìm nghiệp ấy, hãy khảo sát và đối chiếu để biết chính xác đối tượng tìm được là nghiệp, nghiệp tướng hay thú tướng.

**EN**
…and compare so as to know precisely whether there is a causal connection. When this is clear, attend until you ascertain the object of the last near-death process, the one closest to the death consciousness in the previous life. That sign appeared as an object because of the potency of the kamma about to give its result. Thus, in seeking the kamma, investigate and compare carefully to ascertain whether what is found is kamma, a sign of kamma, or a sign of destination.

**VI**
Sự thay đổi của tướng

**EN**
Changes in the sign

**VI**
Trước khi đến lộ cận tử, các nghiệp hiện ra vào khoảng gần lúc chết, hoặc nghiệp, nghiệp tướng và thú tướng, đôi khi có thể thay đổi tùy theo các nhân như tác ý như lý và tác ý không như lý. Hãy nhớ trường hợp người cha của Trưởng lão Soṇa, vị sống ở tu viện rừng Acela dưới chân núi Soṇa. Ban đầu, trong dòng tâm của người cha hiện ra tướng địa ngục. Theo sự thu xếp của người con là Trưởng lão Soṇa, ông chuyển sang lấy tướng dâng hoa cúng dường bảo tháp làm đối tượng. Vì thế, tướng cõi trời, tướng thiên cung và tướng các thiên nữ hiện ra. (Xem Chú giải Abhidhamma, tập 2, tr. 420–421.) Qua trường hợp ấy, cần ghi nhớ rằng các tướng hiện ra khoảng gần lúc chết, trước lộ cận tử, cũng có thể thay đổi tùy theo tác ý sai, tức tác ý không như lý, hay tác ý đúng, tức tác ý như lý.

**EN**
Before the near-death process, kammas appearing around the approach of death, or kamma, a sign of kamma, and a sign of destination, can sometimes change according to causes such as wise attention and unwise attention. Recall the father of Elder Soṇa, who lived at the Acela forest monastery at the foot of Mount Soṇa. At first a sign of hell appeared in the father's continuum. Through arrangements made by his son, Elder Soṇa, he changed to taking as object the sign of offering flowers at a stūpa. Then signs of the heaven realm, a celestial mansion, and celestial maidens appeared. (See the Abhidhamma Commentary, vol. 2, pp. 420–421.) In light of his case, remember that signs appearing around the approach of death, before the near-death process, can also change according to mistaken attention, that is, unwise attention, or correct attention, that is, wise attention.

**VI**
Cũng vì các tướng có thể thay đổi như vậy nên khi hành giả khảo sát tìm các nhân quá khứ, trong sự quán sát bằng tuệ…

**EN**
Because signs can change in this way, when a meditator investigates past causes, in discerning with knowledge…


<a id="M05-body-P085"></a>
## Cách quán các pháp nhân và quả / How to discern causes and effects
Miến / Burmese 85

**VI**
…đôi khi nghiệp trợ có tác dụng nâng đỡ hiện ra trước nghiệp sinh trực tiếp làm sinh quả. Đôi khi, khi nhìn lại để tìm các nhân quá khứ, hành giả quán lướt qua đối tượng của lộ cận tử, sang những đối tượng của dòng danh pháp trước thời điểm ấy. Trong những trường hợp như vậy cũng có thể gặp nghiệp trợ trước rồi khảo sát lại mới gặp nghiệp sinh. Mặt khác, vào khoảng gần lúc chết trước lộ cận tử, các đối tượng có thể có nhiều loại. Đôi khi chính đối tượng của lộ cận tử hiện ra từ khá lâu trước đó. Chẳng hạn, khi cư sĩ Dhammika sắp mất, tướng sáu cỗ xe từ sáu cõi trời hiện ra. Trong sáu cỗ xe, khi cư sĩ Dhammika chọn cõi trời Tusita, cuối cùng chỉ còn cỗ xe của cõi Tusita hiện ra trong lộ cận tử. (Chú giải Dhammapada, tập 1, tr. 83–85.)

**EN**
…supportive kamma sometimes appears before the productive kamma that directly produces the result. Sometimes, in looking back for past causes, the meditator passes over the object of the near-death process and discerns objects in the continuum of mentality before that time. In such cases too, supportive kamma can be encountered first and productive kamma found upon re-examination. Furthermore, around the approach of death, before the near-death process, there may be various objects. Sometimes the very object of the near-death process appears well before the process itself. For example, when the layman Dhammika was about to die, the signs of six chariots from six heavenly realms appeared. When Dhammika chose Tusita from among them, only the chariot from Tusita remained at the end, in the near-death process. (Dhammapada Commentary, vol. 1, pp. 83–85.)

**VI**
Cách quán các pháp nhân và quả

**EN**
How to discern causes and effects

**VI**
Dựa vào tướng hiện ra gần lúc chết như vậy để nhìn lại và tìm các nhân quá khứ. Giả sử đối tượng hiện rõ trong lộ cận tử là tướng dâng vật thực cúng dường bảo tháp, như đã nêu trên. Hãy tìm vô minh, ái, thủ, hành và nghiệp trong dòng danh sắc lúc đang dâng vật thực như đã giải thích. Rồi khảo sát xem năng lực nghiệp ấy và 30 sắc pháp vào sát-na giọt dịch kalala có liên hệ nhân quả…

**EN**
Using the sign that appeared near death as a basis, look back and seek the past causes. Suppose the object clearly manifest in the near-death process is the sign of offering food at a stūpa, as stated above. Find ignorance, craving, clinging, formations, and kamma in the continuum of mentality and materiality while the food was being offered, as explained above. Then investigate whether the potency of that kamma and the thirty kinds of materiality at the moment of the kalala have a causal connection…


<a id="M05-body-P086"></a>
## Điểm chính cần ghi nhớ / Main points to bear in mind
Miến / Burmese 86

**VI**
…hay không. Hãy lần lượt nhìn nhân rồi nhìn quả, nhiều lần đối chiếu tính chất liên hệ nhân quả giữa các pháp nhân và các pháp quả. Tâm và sắc do tâm sinh liên hệ nhân quả với nhau thế nào, cũng hãy quán hai bên là pháp nhân gọi là nghiệp và pháp quả gọi là sắc do nghiệp sinh như thế ấy. Nếu thấy chúng liên hệ với nhau theo nhân quả, hãy quán các pháp nhân và các pháp quả theo cách dưới đây.

**EN**
…or not. Look at the cause, then at the effect, repeatedly comparing the nature of the causal relationship between causal phenomena and resultant phenomena. Just as consciousness and mind-produced materiality are causally connected, discern both the causal phenomenon called kamma and the resultant phenomenon called kamma-produced materiality in the same way. If you see them connected as cause and effect, discern the causes and effects as follows.

**VI**
Do vô minh (20) sinh nên sắc do nghiệp sinh lúc tái tục sinh. Vô minh (20) là pháp nhân. Sắc uẩn lúc tái tục là pháp quả.

**EN**
With the arising of ignorance (20), kamma-produced materiality at rebirth-linking arises. Ignorance (20) is the causal phenomenon. The materiality aggregate at rebirth-linking is the resultant phenomenon.

**VI**
Cứ như vậy, hãy nối pháp nhân với pháp quả và dùng tuệ quán cho đến khi thấy mối liên hệ nhân quả giữa chúng. Hãy quán các pháp nhân và các pháp quả như trên, tức dùng tuệ phân biệt chúng. Khi quán được như vậy thì gọi là tuệ phân biệt nhân duyên (paccayapariggahañāṇa), tức tuệ có thể quán các pháp nhân.

**EN**
In this way, connect the causal phenomena with the resultant phenomena and discern with knowledge until their causal relationship is seen. Discern the causes and effects as above, distinguishing them with knowledge. When one can discern in this way it is called knowledge of discerning conditions (paccayapariggahañāṇa), the knowledge that can discern causal phenomena.

**VI**
Điểm chính cần ghi nhớ

**EN**
Main points to bear in mind

**VI**
Các nhân quá khứ của năm uẩn quả thuộc quả luân là vô minh, ái, thủ, hành và nghiệp. Trong đó, các nhân quá khứ của sắc uẩn là vô minh, ái, thủ, hành và nghiệp. Các nhân hiện tại là tâm, thời tiết và vật thực. Các nhân quá khứ của bốn danh uẩn quả cũng là vô minh, ái, thủ, hành và nghiệp. Các nhân hiện tại…

**EN**
The past causes of the five resultant aggregates in the round of results are ignorance, craving, clinging, formations, and kamma. Of these, the past causes of the materiality aggregate are ignorance, craving, clinging, formations, and kamma. Its present causes are consciousness, temperature, and nutriment. The past causes of the four resultant mental aggregates are also ignorance, craving, clinging, formations, and kamma. Their present causes…


<a id="M05-body-P087"></a>
## Sắc uẩn / The materiality aggregate
Miến / Burmese 87

**VI**
…là các nhân như vật, cảnh và xúc. Có thể ghi nhớ theo cách khác như sau.

**EN**
…are causes such as base, object, and contact. This may also be remembered as follows.

**VI**
Sắc uẩn

**EN**
The materiality aggregate

**VI**
1. Các nhân của sắc do nghiệp sinh, phần thuộc về quả trong sắc uẩn, là vô minh, ái, thủ, hành và nghiệp. Đó là các nhân quá khứ.

**EN**
1. The causes of kamma-produced materiality, the resultant part of the materiality aggregate, are ignorance, craving, clinging, formations, and kamma. These are past causes.

**VI**
2. Nhân của sắc do tâm sinh là tâm sinh nương sắc ý vật.

**EN**
2. The cause of mind-produced materiality is consciousness that arises dependent on the heart-base materiality.

**VI**
3. Nhân của sắc do thời tiết sinh là hỏa đại, tức thời tiết, của sắc đã đạt đến sát-na trụ và hiện diện trong hầu hết các nhóm sắc. [Ghi chú của nguyên tác. Như đã giải thích ở phần đề mục thiền sắc, hỏa đại, tức thời tiết, có trong các nhóm sắc như nhóm mười sắc có thần kinh nhãn và các nhóm sắc do nghiệp, tâm, thời tiết và vật thực sinh làm sinh các nhóm sắc nối tiếp. Hỏa đại, tức thời tiết, trong nhóm sắc cuối cùng không làm sinh sắc do thời tiết sinh. Vì vậy dùng chữ “hiện diện trong hầu hết các nhóm sắc”.]

**EN**
3. The cause of temperature-produced materiality is the fire element, that is, temperature, in materiality that has reached the moment of presence, found in nearly all material groups. [Original note. As explained in the section on the meditation subject of materiality, the fire element, or temperature, in such material groups as the eye decad and groups produced by kamma, consciousness, temperature, and nutriment generates successive material groups. The fire element, or temperature, in the final group does not produce temperature-produced materiality. Hence the wording “found in nearly all material groups.”]

**VI**
4. Nhân của sắc do vật thực sinh là dưỡng chất, gồm dưỡng chất do nghiệp, do tâm, do thời tiết và do vật thực sinh. [Ghi chú của nguyên tác. Khi dưỡng chất do thời tiết sinh trong thức ăn đã ăn được lửa tiêu hóa do nghiệp sinh nâng đỡ, nó làm sinh các nhóm sắc mới có dưỡng chất do vật thực sinh. Khi dưỡng chất ấy được dưỡng chất có trong các nhóm sắc nâng đỡ…

**EN**
4. The cause of nutriment-produced materiality is nutritive essence, including nutritive essence produced by kamma, by consciousness, by temperature, and by nutriment. [Original note. When temperature-produced nutritive essence in the food eaten is supported by the kamma-produced digestive fire, it produces new groups with nutriment-produced nutritive essence. When that nutritive essence receives support from the nutritive essence in the material groups…


<a id="M05-body-P088"></a>
## Bốn danh uẩn / The four mental aggregates
Miến / Burmese 88

**VI**
…dưỡng chất do nghiệp, tâm và thời tiết sinh, cùng dưỡng chất do vật thực sinh thuộc các thế hệ tiếp theo, lần lượt làm sinh các nhóm sắc có dưỡng chất do vật thực sinh. Hãy xem lại toàn bộ điều này trong phần đề mục thiền sắc. Khi được dưỡng chất trong các nhóm sắc nâng đỡ, dưỡng chất trong những nhóm sắc do vật thực sinh thuộc các thế hệ tiếp theo cũng lại làm sinh các nhóm sắc mới do dưỡng chất sinh. Do đó, trong phần nói về các nhân của sắc do vật thực sinh có nêu cả dưỡng chất do vật thực sinh, cùng với dưỡng chất do nghiệp, tâm và thời tiết sinh.]

**EN**
…kamma-produced, mind-produced, and temperature-produced nutritive essence, as well as nutriment-produced nutritive essence in subsequent generations, produce their respective groups with nutriment-produced nutritive essence. Review all of this in the section on the meditation subject of materiality. When supported by nutritive essence in the material groups, the nutritive essence in subsequent generations of nutriment-produced material groups also produces new groups born of nutritive essence. Thus the account of the causes of nutriment-produced materiality includes nutriment-produced nutritive essence alongside that produced by kamma, consciousness, and temperature.]

**VI**
Bốn danh uẩn

**EN**
The four mental aggregates

**VI**
Các nhân quá khứ của hai loại danh pháp quả sau đều là vô minh, ái, thủ, hành và nghiệp. Một là bốn danh uẩn quả thuộc tâm ngoài lộ, tức tái tục, hữu phần và tử. Hai là bốn danh uẩn quả trong lộ tâm, gồm năm thức như nhãn thức, cùng tâm tiếp thọ, suy đạc và đồng sở duyên. Các nhân hiện tại của những danh pháp ấy là các nhân như vật, cảnh và xúc.

**EN**
The past causes of the following two kinds of resultant mentality are ignorance, craving, clinging, formations, and kamma. The first comprises the four resultant mental aggregates of process-free consciousness, namely rebirth-linking, life-continuum, and death. The second comprises the four resultant mental aggregates within cognitive processes, including the five kinds of sense consciousness such as eye-consciousness, as well as receiving, investigating, and registration. The present causes of these mental phenomena include base, object, and contact.

**VI**
1. Vật là sắc làm chỗ nương. Trong cõi có năm uẩn, nếu không có sắc làm chỗ nương thì các danh pháp ấy không thể sinh.
2. Cảnh. Chỉ khi một cảnh thích hợp hiện ra, đến đúng môn tương ứng, thì các danh pháp ấy mới có thể sinh. Phải có cảnh để biết thì mới có sự biết. Hãy hiểu theo cách ấy.

**EN**
1. The base is supporting materiality. In a five-aggregate realm, without supporting materiality those mental phenomena cannot arise.
2. The object. Those mental phenomena can arise only when an appropriate object appears at the corresponding door. There must be an object to cognize for cognition to occur. Understand it in this way.


<a id="M05-body-P089"></a>
## Miến 89 / Burmese page 89
Miến / Burmese 89

**VI**
3. Xúc. Các pháp tương ưng như xúc, nói cách khác là bốn danh uẩn, phải trợ lẫn nhau bằng năng lực của các duyên như câu sinh, hỗ tương, y chỉ, hiện hữu và bất ly thì những danh pháp ấy mới có thể sinh. Để một uẩn sinh, ba danh uẩn còn lại phải trợ cho nó. Trong các uẩn ấy, xúc là một nhân chính nổi bật đối với việc tiếp nhận cảnh.

**EN**
3. Contact. Associated phenomena such as contact, in other words the four mental aggregates, must support one another by conditions such as conascence, mutuality, dependence, presence, and non-disappearance for those mental phenomena to arise. For one aggregate to arise the other three mental aggregates must support it. Among these aggregates contact is a prominent primary cause in receiving the object.

**VI**
Điều cần lưu ý. Các thức quả trong thời bình nhật, như ngũ thức, tiếp thọ, suy đạc và đồng sở duyên, có thể sinh do chính nghiệp sinh trực tiếp làm sinh các tâm ngoài lộ là tái tục, hữu phần và tử. Chúng cũng có thể sinh do những nghiệp sinh khác làm sinh các quả trong thời bình nhật. Nghiệp ấy có thể là thiện hay bất thiện. Do nghiệp thiện sinh ngũ thức, tiếp thọ, suy đạc và đồng sở duyên là quả thiện. Do nghiệp bất thiện sinh ngũ thức, tiếp thọ, suy đạc và đồng sở duyên là quả bất thiện. Quả thiện sinh khi gặp cảnh khả ái, quả bất thiện sinh khi gặp cảnh bất khả ái. Dù các vị đệ tử không thể biết hết nghiệp và quả của nghiệp, họ vẫn cần biết được một phần. Cần lưu ý để khảo sát các nhân này cả khi quán năm uẩn quá khứ lẫn khi tìm các nhân quá khứ.

**EN**
A point to bear in mind. Resultant consciousness during the course of life, such as fivefold sense consciousness, receiving, investigating, and registration, may arise from the same productive kamma that directly produces the process-free consciousness of rebirth-linking, life-continuum, and death. It may also arise from other productive kammas that produce results during the course of life. Such kamma may be wholesome or unwholesome. Wholesome kamma produces wholesome-resultant fivefold sense consciousness, receiving, investigating, and registration. Unwholesome kamma produces unwholesome-resultant fivefold sense consciousness, receiving, investigating, and registration. Wholesome results arise on encountering a desirable object and unwholesome results on encountering an undesirable object. Although disciples cannot know kamma and its results exhaustively, they should know some of them. Be mindful to investigate these causes both in discerning the five past aggregates and in seeking the past causes.

**VI**
Lại nữa, tâm hướng ngũ môn và tâm xác định trong lộ ngũ môn, cùng tâm hướng ý môn trong lộ ý môn, cả ba đều là tâm duy tác. Chúng chỉ làm nhiệm vụ hướng đến và xác định cảnh đã hiện ra. Khi môn và cảnh gặp nhau…

**EN**
Furthermore, five-door adverting and determining in the five-door process, and mind-door adverting in the mind-door process, are all functional consciousness. They perform only the functions of adverting to and determining the object that has appeared. When the door and object meet…


<a id="M05-body-P090"></a>
## Bốn phương pháp — 1. Phương pháp đồng nhất / The four methods — 1. The method of identity
Miến / Burmese 90

**VI**
…chỉ các tâm duy tác ấy hiện khởi. Do đó chúng không phải là danh pháp sinh do các nhân quá khứ. Chúng là nhóm danh pháp sinh chỉ do những nhân hiện tại như vật, cảnh và xúc. Vì thế những danh pháp này không có nhân quá khứ. Chúng chỉ có các nhân hiện tại như vật, cảnh và xúc.

**EN**
…only those functional types of consciousness arise. Thus they are not mental phenomena arising from past causes. They are groups of mental phenomena arising only from present causes such as base, object, and contact. These mental phenomena therefore have no past causes. They have only present causes such as base, object, and contact.

**VI**
Cũng vậy, các tốc hành thiện chỉ sinh do các nhân như vật, cảnh, xúc và tác ý như lý. Các tốc hành bất thiện cũng chỉ sinh do các nhân như vật, cảnh, xúc và tác ý không như lý. Các nhóm danh pháp ấy không phải là danh pháp sinh từ các nhân quá khứ. Vì vậy hãy ghi nhớ rằng các nhóm danh pháp tốc hành thiện và bất thiện không có nhân quá khứ. Chúng chỉ có các nhân hiện tại.

**EN**
Likewise, wholesome impulsions arise only from causes such as base, object, contact, and wise attention. Unwholesome impulsions arise only from causes such as base, object, contact, and unwise attention. These groups of mental phenomena are not mental phenomena arising from past causes. Thus remember that the groups of mental phenomena in wholesome and unwholesome impulsions have no past causes. They have only present causes.

**VI**
Bốn phương pháp — 1. Phương pháp đồng nhất

**EN**
The four methods — 1. The method of identity

**VI**
Khi hành giả quán duyên khởi, cần hiểu rõ bốn phương pháp rất quan trọng là phương pháp đồng nhất (ekattanaya), sai biệt (nānattanaya), vô tác giả (abyāpāranaya) và tính quy luật (evaṃdhammatānaya). Hãy quán để hiểu chúng trong khi quán tính chất duyên khởi và mối liên hệ nhân quả. Phương pháp đồng nhất là như sau.

**EN**
In discerning dependent origination a meditator must understand four very important methods: identity (ekattanaya), diversity (nānattanaya), non-agency (abyāpāranaya), and regularity (evaṃdhammatānaya). Discern them so as to understand them while discerning dependent origination and the relationship between cause and effect. The method of identity is as follows.

**VI**
1. Danh sắc quá khứ trong đó các nhân quá khứ được vun bồi.
2. Danh sắc đang sinh từng lúc từ tái tục hiện tại đến lúc quán các nhân trong hiện tại, hoặc, khi đã bước sang phần minh sát, đến lúc quán minh sát…

**EN**
1. Past mentality and materiality in which the past causes were accumulated.
2. Mentality and materiality arising moment by moment from present rebirth-linking to the present discernment of causes or, after entering the insight phase, up to the point of insight discernment…


<a id="M05-body-P091"></a>
## Miến 91 / Burmese page 91
Miến / Burmese 91

**VI**
3. Danh sắc tương lai sẽ sinh từ lúc hiện đang quán duyên khởi, tức mối liên hệ nhân quả, cho đến lúc chấm dứt trong tương lai, nếu vẫn chưa có thể tu tập đến quả vị A-la-hán nên tương lai ấy còn hiện hữu. Nói cách khác, danh sắc quá khứ, hiện tại và tương lai lần lượt đã hiện hữu, đang hiện hữu và sẽ hiện hữu trong ba đời, đời quá khứ, đời hiện tại và đời tương lai.

**EN**
3. Future mentality and materiality that will arise from the time one is now discerning dependent origination, the causal relationship, to the end in the future, if that future still remains because one has yet to practise to the attainment of arahantship. Put another way, past, present, and future mentality and materiality have existed, now exist, and will exist respectively in the three lives, past, present, and future.

**VI**
Cần thấy bằng tuệ các danh sắc đã hiện hữu, đang hiện hữu và sẽ hiện hữu trong ba thời quá khứ, hiện tại và tương lai ấy như một dòng nối tiếp, xét theo dòng danh sắc. Dòng danh sắc ấy là một dòng vô thường, một dòng sinh rồi diệt.

**EN**
One must see with knowledge the mentality and materiality that have existed, now exist, and will exist in these three times as a single succession in terms of the continuum of mentality and materiality. This succession of mentality and materiality is a succession of impermanence, a succession of arising and ceasing.

**VI**
Nói rõ hơn đôi chút, nếu hành giả chú tâm quán hữu phần làm ý môn trong sáng vào lúc vun bồi việc thiện trong đời quá khứ làm nhân đưa đến đời người hiện nay, rồi quán hữu phần làm ý môn trong sáng hiện tại, sẽ thấy, như sợi chỉ được kéo thành một đường, rằng xét theo dòng tương tục, chúng tiếp nối thành một dãy, một mạch, một chuỗi, thành một dòng sinh diệt. Hãy quán bằng tuệ cho đến khi hiểu rõ điều đó. Hữu phần là tâm sinh thường xuyên nhất trong một đời. Vì vậy ở đây lấy hữu phần làm chính để giải thích cho dễ hiểu. Sabhāvo vāyaṃ…

**EN**
To clarify this a little, direct attention to the clear life-continuum serving as mind door when the wholesome deed that led to the present human life was accumulated in a past life, and then discern the present clear life-continuum serving as mind door. In terms of continuity they come in one succession, one connection, one series of arising and ceasing, like a thread stretched in one line. Discern this with knowledge until it is clear. Life-continuum is the consciousness that occurs most frequently in a life, so it is used here as the main example to make the explanation easier to understand. Sabhāvo vāyaṃ…


<a id="M05-body-P092"></a>
## Đặc tính của đời quá khứ / The distinguishing marks of the past
Miến / Burmese 92

**VI**
…cittassa paṇḍaratā. (Mūlaṭīkā, tập 1, tr. 125.) Theo lời Phụ chú giải gốc, dù các tâm sở bất thiện ô nhiễm, mọi tâm vẫn có tính trong sáng. Do đó, sự trong sáng của hữu phần và sự trong sáng của các tâm trong lộ xen giữa các hữu phần, tức sự trong sáng của mọi tâm, là sự trong sáng theo bản tính. Người thiện hãy dùng tuệ quán cho thấy rằng dòng danh pháp trong sáng ấy sinh nối tiếp thành một dãy, một mạch, một chuỗi. Cũng theo cách ấy, hãy tiếp tục dùng tuệ quán cho thấy dòng sắc pháp sinh nối tiếp thành một dãy, một mạch, một chuỗi.

**EN**
…cittassa paṇḍaratā. (Mūlaṭīkā, vol. 1, p. 125.) According to the root subcommentary, although unwholesome mental factors are defiled, all consciousness is clear. Thus the clarity of the life-continuum and that of the process consciousness occurring between moments of life-continuum, the clarity of all consciousness, is clarity by nature. A good person should discern with knowledge how that clear continuum of mentality occurs in one succession, one connection, one series. In the same way, continue discerning with knowledge how the continuum of materiality arises in one succession, one connection, one series.

**VI**
Đặc tính của đời quá khứ

**EN**
The distinguishing marks of the past

**VI**
Hãy quán kỹ xem hữu phần làm ý môn trong sáng thuộc về dòng danh sắc đang làm việc thiện trong đời quá khứ, hay dòng danh pháp ấy, có phải là hữu phần làm ý môn trong sáng của chính mình, hay là dòng danh pháp của chính mình hay không. Nếu đúng là hữu phần làm ý môn trong sáng hoặc dòng danh pháp của mình, hành giả có thể dễ dàng hiểu rõ là hữu phần làm ý môn trong sáng và dòng danh pháp của chính mình. Cũng vậy, hành giả có thể dễ dàng hiểu rõ đó là dòng sắc của chính mình. Sở dĩ như vậy là vì dòng danh pháp và dòng sắc pháp tiếp nối thành một dãy, một mạch, một chuỗi, một dòng.

**EN**
Discern carefully whether the clear life-continuum serving as the mind door in the continuum of mentality and materiality performing a wholesome deed in a past life, or that continuum of mentality, is your own clear life-continuum serving as the mind door or your own continuum of mentality. If it is indeed your own clear life-continuum or continuum of mentality, you can readily understand that it is your own clear life-continuum serving as the mind door or your own continuum of mentality. Likewise, you can readily understand that it is your own continuum of materiality. This is because the continuum of mentality and the continuum of materiality occur in one succession, one connection, one series, one stream.

**VI**
Khi nhìn lại dòng danh sắc quá khứ như vậy, một số hành giả nhận rằng “tâm tính của mình trong đời quá khứ…

**EN**
When looking back and discerning the past continuum of mentality and materiality in this way, some meditators acknowledge that “my mental dispositions in the past life…


<a id="M05-body-P093"></a>
## Ánh sáng rộng và mạnh khi quán đời trước / Broad, strong light when discerning a past life
Miến / Burmese 93

**VI**
…phần lớn giống với tâm tính hiện nay”. Đó chính là do các tập khí tương tự, hợp nhau, đi theo. Tu tập thiền chỉ và minh sát là để thay các tập khí xấu bằng các tập khí tốt và nỗ lực làm cho những tập khí tốt sinh khởi liên tục. Khi các tập khí xấu đã được nhổ tận gốc và chỉ các tập khí tốt vận hành trọn vẹn, công việc tu tập của hành giả đã đạt đến chỗ cao nhất.

**EN**
…largely resemble my present mental dispositions.” This is due to compatible habits carrying over. The cultivation of serenity and insight is the work of replacing bad habits with good habits and striving to make the good habits occur without interruption. When bad habits can be uprooted and good habits alone operate fully, one's work of cultivation has reached its highest point.

**VI**
Có vẻ khó, và quả thật là khó.
Có vẻ sâu, và quả thật là sâu.

**EN**
It seems difficult, and indeed it is difficult.
It seems profound, and indeed it is profound.

**VI**
Khi quán danh sắc từ quá khứ đến hiện tại hoặc quán các nhân quá khứ theo cách ấy, sau khi quán danh sắc của đời hiện tại ngược đến tái tục, hành giả hướng tuệ về quá khứ để tìm các nhân. Có khi không thấy danh sắc nào, chỉ thấy một khối ánh sáng sáng rực, rất mạnh, rất lớn và trải rộng. Lúc đó, nếu thiếu kiến thức đã học, hành giả có thể đứng lại, không biết cách tiến tiếp. Những hành giả như vậy phần lớn là người từ cõi trời hoặc cõi Phạm thiên sinh xuống. Cần khảo sát cẩn thận xem có đúng hay không. Phần lớn những hành giả gặp khó khăn như vậy, trong lúc quán danh sắc nội phần và ngoại phần…

**EN**
In discerning mentality and materiality from the past to the present or in discerning the past causes in this way, a meditator discerns mentality and materiality in the present life back to rebirth-linking, then directs knowledge toward the past to find the causes. Sometimes no mentality or materiality is seen, only a mass of radiant light, intensely bright, very large, and spread wide. At that point, if the meditator lacks learning, they may come to a standstill, unsure how to proceed. Such meditators have often descended from a deva or Brahmā realm. It is particularly necessary to investigate whether this is so. Most meditators encountering this difficulty, when discerning internal and external mentality and materiality…


<a id="M05-body-P094"></a>
## Miến 94 / Burmese page 94
Miến / Burmese 94

**VI**
…trong hai loại dòng tương tục, nội phần và ngoại phần, đã chỉ quán chung mà chưa chú trọng riêng danh sắc trong dòng tương tục của chư thiên và trong dòng tương tục của Phạm thiên. Vì thế, khi gặp khối ánh sáng lớn và trải rộng như vậy, họ không biết cách quán danh sắc hiện hữu trong đó. Chư thiên có phước càng lớn thì ánh sáng thân thể càng rực rỡ. Ánh sáng thân thể của Phạm thiên còn rực rỡ hơn ánh sáng thân thể chư thiên. Thân chư thiên to lớn, thân Phạm thiên còn to lớn hơn. Sắc pháp của chư thiên cực kỳ vi tế, sắc pháp của Phạm thiên còn vi tế hơn sắc pháp của chư thiên. Người khi quán danh sắc ngoại phần chỉ quán chung mà chưa chú tâm khảo sát danh sắc chư thiên và Phạm thiên có thể gặp khó khăn khi quán các sắc pháp hết sức vi tế như vậy.

**EN**
…in the two kinds of continuum, internal and external, discerned in general without giving specific attention to mentality and materiality in the continua of devas and Brahmās. Thus when they encounter a great, broad mass of light, they do not know how to discern the mentality and materiality present within it. The greater a deva's merit, the brighter the radiance of the body. The radiance of Brahmās is brighter still than the radiance of devas. The bodies of devas are large, and those of Brahmās are larger still. The material phenomena of devas are extremely subtle, and those of Brahmās are subtler still. Someone who in discerning external mentality and materiality discerned only in general without attending carefully to that of devas and Brahmās may have difficulty discerning such exceedingly subtle material phenomena.

**VI**
Khi gặp khó khăn như vậy, hãy quán lại danh sắc nội phần và ngoại phần. Hãy đặc biệt chú trọng quán sắc pháp của chư thiên. Khi quán thành công, hãy hướng tuệ đến các cõi trời và tiếp tục quán các sắc pháp vi tế trong dòng tương tục của chư thiên ở từng tầng trời. Hãy quán một lượt nội phần rồi một lượt ngoại phần. Sau đó hãy chuyển sang quán các sắc pháp trong dòng tương tục của Phạm thiên. Sắc pháp của Phạm thiên hết sức vi tế. Vì thế hãy nhiều lần thiết lập lại định và nhiều lần…

**EN**
When you encounter such a difficulty, discern internal and external mentality and materiality again. Pay particular attention to discerning the material phenomena of devas. When you succeed, direct knowledge towards the deva realms and continue discerning the subtle material phenomena in the continua of devas in successive realms. Discern internally once and externally once. Then turn to discerning the material phenomena in the continua of Brahmās. The material phenomena of Brahmās are exceedingly subtle. Therefore re-establish concentration repeatedly and repeatedly…


<a id="M05-body-P095"></a>
## Miến 95 / Burmese page 95
Miến / Burmese 95

**VI**
…quán. Có thể thành công. Khi đã có thể nhiều lần quán sắc pháp nội phần và ngoại phần đến tận cõi Phạm thiên như vậy, hãy đặc biệt tiếp tục quán để hiểu rõ trong dòng tương tục của Phạm thiên không có nhóm mười sắc có thần kinh tỷ, nhóm mười sắc có thần kinh thiệt, nhóm mười sắc có thần kinh thân và nhóm mười sắc giới tính. Khi thành công, hãy tiếp tục quán các danh pháp.

**EN**
…discern. Success is possible. When you can repeatedly discern internal and external material phenomena as far as the Brahmā realms in this way, continue discerning in particular to understand clearly that Brahmās have no nose decad, tongue decad, body decad, or sex decad. When you succeed, continue discerning mentality.

**VI**
Trong dòng tương tục của chư thiên, cũng như trong dòng tương tục của người, các nhóm sắc do nghiệp, tâm và vật thực sinh có thể hiện diện đầy đủ. Trong dòng tương tục của Phạm thiên, các nhóm sắc không thể hiện diện đầy đủ tất cả. Đó là sự khác nhau về các nhóm sắc giữa chư thiên và Phạm thiên. Khi đã có thể chuyển sang quán danh sắc của chư thiên và Phạm thiên ngoại phần, hãy bắt đầu quán bốn đại trong khối ánh sáng rất lớn và trải rộng đã gặp khi tìm các nhân quá khứ. Khi thấy những hạt nhỏ là các nhóm sắc, hãy phân tích những nhóm sắc ấy đến tận chân đế. Khi quán sắc chân đế như vậy, nếu khối ánh sáng đó thuộc đời sống chư thiên, hành giả sẽ thấy các nhóm sắc đầy đủ như đã giải thích trên. Nếu khối ánh sáng thuộc đời sống Phạm thiên thì trong các sắc do nghiệp sinh sẽ không tìm thấy một số loại, như đã nêu. Khi đã có thể quán sắc pháp, hãy tiếp tục quán sắc ý vật, hữu phần trong sáng tức ý môn, và những danh pháp sinh lấy ý môn ấy làm cửa và nương trên sắc ý vật ấy. Lại tiếp tục quán trong số những danh pháp ấy các nhóm do vô minh, ái và thủ dẫn đầu…

**EN**
In the continua of devas, as in human continua, kamma-produced, mind-produced, and nutriment-produced groups of materiality can occur in full. In the continua of Brahmās the groups of materiality cannot all be present in full. This is the difference between devas and Brahmās with respect to material groups. Once you can turn to discerning the mentality and materiality of devas and Brahmās externally, begin by discerning the four great elements in the very large, broad mass of light encountered when seeking past causes. When you see the small particles that are material groups, analyze those groups down to ultimate phenomena. In discerning ultimate materiality this way, if the mass of light belongs to a deva existence, you can find the full complement of groups as explained above. If the mass of light belongs to a Brahmā existence, you will not find some types of kamma-produced materiality, as stated above. Once you can discern the material phenomena, continue discerning the heart-base materiality, the clear life-continuum or mind door, and the mental phenomena that arise taking that mind door as their door and depending on the heart-base. Continue discerning among those mental phenomena the groups led by ignorance, craving, and clinging…


<a id="M05-body-P096"></a>
## Khi thấy ba hoặc bốn người / When three or four people appear
Miến / Burmese 96

**VI**
…tức các nhóm danh pháp trong lộ ý môn thuộc phiền não luân, cùng các nhóm danh pháp trong lộ ý môn thuộc nghiệp luân, tức hành và nghiệp. Khi quán như vậy, hãy dùng tuệ phân biệt và quán cho biết rằng dòng danh sắc đời trước và dòng danh sắc hiện tại tiếp nối thành một dãy, một mạch, một chuỗi, một dòng. Khi biết như vậy, gọi là biết phương pháp đồng nhất.

**EN**
…namely the groups of mental phenomena in mind-door processes of the round of defilements, and the groups of mental phenomena in mind-door processes of the round of kamma, namely formations and kamma. When discerning in this way, distinguish with knowledge and discern so as to know that the past and present continua of mentality and materiality make up one succession, one connection, one series, one stream. Knowing this is called knowing the method of identity.

**VI**
Khi thấy ba hoặc bốn người

**EN**
When three or four people appear

**VI**
Đôi khi, khi tìm các nhân quá khứ, một số hành giả thấy trong cảnh làm việc thiện ở đời trước có ba hoặc bốn người đang làm việc thiện. Nếu thấy như vậy, hãy bắt đầu quán bốn đại trong dòng tương tục của từng người, hết người này đến người khác. Trước tiên hãy quán bốn đại trong dòng tương tục của một người. Khi thấy các hạt nhóm sắc, tiếp tục quán các sắc chân đế. Sau đó tiếp tục quán danh pháp. Rồi tiếp tục quán danh sắc của một người khác theo cách tương tự. Kế đó lại tiếp tục quán danh sắc của người tiếp theo theo cách tương tự. Trong các dòng danh sắc ấy, dòng danh sắc nào thấy được là nối với danh sắc hiện tại của mình thành một dãy, một mạch, một chuỗi, một dòng, thì đó chính là dòng danh sắc của mình.

**EN**
Sometimes, when seeking past causes, a meditator sees three or four people performing a wholesome deed in the scene of wholesome action in a past life. If this happens, begin discerning the four great elements in each person's continuum, one person after another. First discern the four great elements in one person's continuum. When you see the particles that are material groups, continue discerning ultimate material phenomena. Then continue discerning mental phenomena. Next discern the mentality and materiality of another person in the same way. Then continue likewise with the mentality and materiality of the next person. Of these continua, the one seen as forming one succession, one connection, one series, one stream with your present mentality and materiality is your own continuum.

**VI**
Trong khi quán như vậy, nếu còn chưa chắc, hãy chú tâm riêng vào hữu phần làm ý môn trong sáng của từng người…

**EN**
If uncertain while discerning in this way, direct your attention particularly to the clear life-continuum serving as mind door in each person…


<a id="M05-body-P097"></a>
## Miến 97 / Burmese page 97
Miến / Burmese 97

**VI**
…mà quán. Hành giả thường có thể dễ dàng biết đó có phải là hữu phần làm ý môn trong sáng của mình hay không. Sở dĩ như vậy là vì khi chính mình thấy rõ bằng con mắt trí tuệ chánh kiến rằng hữu phần làm ý môn trong sáng hiện tại và hữu phần làm ý môn trong sáng đời trước hợp thành một dãy, một mạch, một chuỗi, một dòng xét theo dòng danh pháp, hành giả dễ dàng thấy rõ rằng hữu phần làm ý môn trong sáng đời trước ấy chính là của mình. Nếu chú tâm quán hữu phần làm ý môn trong sáng trong quá khứ mà nó không phải là hữu phần làm ý môn trong sáng của mình đang quán, hành giả cũng có thể dễ dàng thấy rằng nó không phải của mình. Sở dĩ như vậy là vì hai dòng danh pháp không tiếp nối với nhau. Nếu danh sắc quá khứ không phải dòng danh sắc của mình, hành giả có thể tự mình thấy rằng dòng danh sắc của người khác ấy trong quá khứ và dòng danh sắc hiện tại của mình không đến thành một dãy, một mạch, một chuỗi, một dòng, mà là hai dòng không tiếp nối với nhau.

**EN**
…and discern it. A meditator can usually tell easily whether it is one's own clear life-continuum serving as mind door. When the meditator sees directly with the eye of right-view wisdom that the present clear life-continuum serving as mind door and the past clear life-continuum serving as mind door form one succession, one connection, one series, one stream in terms of the continuum of mentality, it is easy to see that the past clear life-continuum serving as mind door is one's own. If, when attending to a past clear life-continuum serving as mind door, it is not one's own clear life-continuum that one is discerning, this too can readily be seen. That is because the two continua of mentality do not connect. If the past mentality and materiality are not one's own continuum, the meditator can see personally that that other person's past continuum and one's own present continuum do not come in one succession, one connection, one series, one stream, but are continua that are unconnected.

**VI**
Dòng danh sắc của mình trong quá khứ và dòng danh sắc của mình hiện tại tiếp nối trước sau, lần lượt sinh, thành một dãy, một mạch, một chuỗi, một dòng. Khi hành giả tự mình thấy rõ điều này bằng trí tuệ chánh kiến…

**EN**
One's past continuum of mentality and materiality and one's present continuum of mentality and materiality connect before and after, arising in succession as one succession, one connection, one series, one stream. When the meditator sees this directly with the wisdom of right view…


<a id="M05-body-P098"></a>
## Đoạn kiến và thường kiến / Annihilationism and eternalism
Miến / Burmese 98

**VI**
…thì do thấy rõ bằng trí tuệ chánh kiến rằng dòng danh sắc ấy tiếp nối trước sau và sinh nối tiếp như một dãy, một mạch, một chuỗi, một dòng, gọi là biết phương pháp đồng nhất. Cũng hãy hiểu theo cách ấy khi quán để chính mình thấy rõ bằng trí tuệ chánh kiến rằng dòng danh sắc hiện tại và dòng danh sắc tương lai nối nhau trước sau, lần lượt sinh thành một dãy, một mạch, một chuỗi, một dòng.

**EN**
…then, because the meditator sees directly with the wisdom of right view that the continuum of mentality and materiality connects before and after and arises successively as one succession, one connection, one series, one stream, this is called knowing the method of identity. Understand in the same way when discerning to see directly with right-view wisdom that the present and future continua of mentality and materiality connect before and after, arising successively as one succession, one connection, one series, one stream.

**VI**
Đoạn kiến và thường kiến

**EN**
Annihilationism and eternalism

**VI**
Tattha avijjāpaccayā saṅkhārā, saṅkhārapaccayā viññāṇanti evaṃ bījassa aṅkurādibhāvena rukkhabhāvappatti viya santānānupacchedo ekattanayo nāma. Yaṃ sammā passanto hetuphalasambandhena pavattamānassa santānassa anupacchedāvabodhato ucchedadiṭṭhiṃ pajahati. Micchā passanto hetuphalasambandhena pavattamānassa santānānupacchedassa ekattaggahaṇato sassatadiṭṭhiṃ upādiyati. (Chú giải Abhidhamma, tập 2, tr. 188. Visuddhimagga, tập 2, tr. 220.)

**EN**
Tattha avijjāpaccayā saṅkhārā, saṅkhārapaccayā viññāṇanti evaṃ bījassa aṅkurādibhāvena rukkhabhāvappatti viya santānānupacchedo ekattanayo nāma. Yaṃ sammā passanto hetuphalasambandhena pavattamānassa santānassa anupacchedāvabodhato ucchedadiṭṭhiṃ pajahati. Micchā passanto hetuphalasambandhena pavattamānassa santānānupacchedassa ekattaggahaṇato sassatadiṭṭhiṃ upādiyati. (Abhidhamma Commentary, vol. 2, p. 188. Visuddhimagga, vol. 2, p. 220.)

**VI**
Từ hạt giống nảy ra mầm, từ mầm ấy sinh ra lá. Từ hạt giống ấy, rễ, thân, cành, lá non và lá già lần lượt xuất hiện không gián đoạn. Hạt giống trở thành cây. Nó xuất hiện dưới dạng cây. Vì vậy, khi hạt giống và cây nối thành một dãy, dòng tương tục không đứt. Khi dòng tương tục không đứt, có thể nói là “cùng một dòng”. Cũng như thế…

**EN**
A shoot grows from the seed, and from that shoot a leaf develops. From that seed, roots, trunk, branches, young leaves, and mature leaves appear successively without interruption. The seed becomes a tree. It appears in the form of a tree. Thus, when the seed and tree occur in one series, the continuum is not interrupted. Because the continuum is uninterrupted, one may speak of it as “one and the same stream.” Likewise…


<a id="M05-body-P099"></a>
## Miến 99 / Burmese page 99
Miến / Burmese 99

**VI**
Do vô minh, hành sinh. Do hành, thức sinh. Cứ như vậy, khi nhân và quả tiếp nối thành một dãy, một dòng tương tục không gián đoạn, cách hiểu đó là “một dòng” được gọi là phương pháp đồng nhất.

**EN**
With ignorance as condition, formations arise. With formations as condition, consciousness arises. As this proceeds, causes and effects form one succession, one uninterrupted continuum. The way of understanding this as “one stream” is called the method of identity.

**VI**
Khi thấy biết phương pháp đồng nhất đúng đắn, tuệ thấu suốt sự không gián đoạn của dòng danh sắc sinh nối tiếp trong quan hệ nhân quả, chẳng hạn các nhân quá khứ với các quả hiện tại, và các nhân hiện tại với các quả tương lai. Nhờ thấy biết như vậy, có thể đoạn trừ kiến chấp và sự bám chặt vào đoạn kiến cho rằng “đời sống chỉ có từ lúc sinh đến lúc chết, chết là hết, sau khi chết chẳng còn gì”. Nếu không thấy sự liên hệ nhân quả ấy mà thấy sai lầm, thì thường kiến cũng có thể sinh khởi.

**EN**
When the method of identity is seen correctly, knowledge penetrates the uninterrupted continuum of mentality and materiality arising successively in causal relationship, as between past causes and present results, and between present causes and future results. Such seeing makes it possible to abandon annihilationist belief and the strong attachment to it, the view that “life extends only from birth to death, ends at death, and nothing remains after death.” If the causal relationship is missed and seen wrongly, eternalism can also arise.

**VI**
Pháp nhân và pháp quả khác nhau xét theo tự tính chân đế của pháp nhân và tự tính chân đế của pháp quả. Tuy nhiên, dù chúng khác nhau theo tự tính chân đế, xét về mặt pháp nhân cũng như xét về mặt pháp quả, chúng liên kết với nhau theo tính chất nhân quả. Chính sự tiếp nối ấy ở đây được gọi là santānānupaccheda, tức sự không gián đoạn của dòng tương tục. Vì dòng danh sắc không gián đoạn như vậy, nghiệp đã tạo trong dòng danh sắc nào thì quả chỉ sinh trong chính dòng danh sắc ấy. Hãy ghi nhớ rằng nghiệp đã tạo không thể mất đi, và nghiệp chưa tạo cũng không thể tiến đến cho quả.

**EN**
Causal and resultant phenomena differ in their respective ultimate natures. Yet although they differ in ultimate nature, viewed from the side of the cause as well as from the side of the effect, they are linked to each other causally. This connectedness is called santānānupaccheda here, the non-interruption of the continuum. Because the continuum of mentality and materiality is uninterrupted in this way, a result arises only in the very continuum of mentality and materiality in which its kamma was performed. Remember that kamma already performed cannot simply disappear, and kamma not performed cannot come forward to give a result.


<a id="M05-body-P100"></a>
## 2. Phương pháp sai biệt / 2. The method of diversity
Miến / Burmese 100

**VI**
Cái thấy sai lầm ở đây sinh do không khảo sát và không thấy sự sai khác giữa các pháp nhân và quả đang sinh nối tiếp và liên hệ với nhau theo nhân quả. Người ấy xem các pháp nhân và các pháp quả là cùng một thứ, rồi chấp sự không gián đoạn của dòng danh sắc sinh nối tiếp theo nhân quả là một thực thể duy nhất không sai khác. Vì không thấy vô thường, khổ và vô ngã nơi danh sắc nhân và danh sắc quả, người ấy hiểu theo nghĩa thường còn và theo nghĩa tự ngã rằng “Tadeva viññāṇaṃ sandhāvati saṃsarati”, chính thức ấy chạy từ đời này sang đời kia, từ đời kia sang đời nọ, rồi nhiều lần lưu chuyển trong cùng một đời. Chấp dòng danh sắc là một thực thể duy nhất theo cách ấy chính là thường kiến. Nếu hiểu sai phương pháp đồng nhất thì đã nắm chặt thường kiến. (Chú giải Abhidhamma, tập 2, tr. 188. Visuddhimagga, tập 2, tr. 220. Mūlaṭīkā, tập 2, tr. 131. Mahāṭīkā, tập 2, tr. 347.)

**EN**
The wrong way of seeing here arises through failing to investigate and see the difference between the causes and effects that arise in succession and are linked causally. One regards causes and effects alike as a single thing and grasps the non-interruption of the causally connected continuum of mentality and materiality as one undifferentiated entity. Failing to see impermanence, suffering, and non-self in causal and resultant mentality and materiality, one understands in terms of permanence and self, “Tadeva viññāṇaṃ sandhāvati saṃsarati”, this very consciousness runs from this life to that life, from that life to another, and wanders repeatedly even within a single life. Grasping the continuum of mentality and materiality as a single entity in this way is eternalism. One who understands the method of identity wrongly is already holding to eternalism. (Abhidhamma Commentary, vol. 2, p. 188. Visuddhimagga, vol. 2, p. 220. Mūlaṭīkā, vol. 2, p. 131. Mahāṭīkā, vol. 2, p. 347.)

**VI**
2. Phương pháp sai biệt

**EN**
2. The method of diversity

**VI**
Avijjādīnaṃ pana yathāsakalakkhaṇavavatthānaṃ nānattanayo nāma. Yaṃ sammā passanto navanavānaṃ uppādadassanato sassatadiṭṭhiṃ pajahati. Micchā passanto ekasantānapatitassa bhinnasantānasseva nānattaggahaṇato ucchedadiṭṭhiṃ upādiyati. (Chú giải Abhidhamma, tập 2, tr. 188. Visuddhimagga, tập 2, tr. 220.)

**EN**
Avijjādīnaṃ pana yathāsakalakkhaṇavavatthānaṃ nānattanayo nāma. Yaṃ sammā passanto navanavānaṃ uppādadassanato sassatadiṭṭhiṃ pajahati. Micchā passanto ekasantānapatitassa bhinnasantānasseva nānattaggahaṇato ucchedadiṭṭhiṃ upādiyati. (Abhidhamma Commentary, vol. 2, p. 188. Visuddhimagga, vol. 2, p. 220.)

**VI**
Theo phương pháp đồng nhất, các pháp liên hệ nhân quả hiện ra thành một dòng tương tục…

**EN**
According to the method of identity, phenomena related as cause and effect occur as a single continuum…


<a id="M05-body-P101"></a>
## Miến 101 / Burmese page 101
Miến / Burmese 101

**VI**
…Nhận rõ từng đặc tính riêng của các pháp nhân và quả đang sinh trong dòng ấy, như vô minh, hành, thức, danh sắc, sáu xứ, xúc, thọ, ái, thủ, hữu, sinh, già và chết, được gọi là phương pháp sai biệt. Để quán theo phương pháp này, phải dùng tuệ phá tan khối tưởng về danh sắc, gồm khối do tương tục, do tập hợp, do chức năng và do đối tượng. Hãy quán các chi duyên khởi đúng từng trường hợp theo đặc tính, chức năng, biểu hiện và nhân gần, cho đến khi tuệ thấy chân đế.

**EN**
…Distinguishing each of the respective characteristics of the causal and resultant phenomena arising in that continuum, such as ignorance, formations, consciousness, mentality and materiality, the six bases, contact, feeling, craving, clinging, becoming, birth, aging, and death, is called the method of diversity. To discern in this way, break down with knowledge the apparent compactness of mentality and materiality, including compactness of continuity, grouping, function, and object. Discern the factors of dependent origination in their proper places in terms of characteristic, function, manifestation, and proximate cause, until knowledge reaches ultimate phenomena.

**VI**
Danh sắc quá khứ, hiện tại và tương lai quả thật nối nhau thành một dòng tương tục. Tuy vậy, hãy quán để thấy từng nhóm sắc và từng nhóm tâm riêng biệt, phá tan khối do tương tục. Các pháp như vô minh ấy lại chỉ sinh thành nhóm sắc hoặc nhóm danh. Hãy dùng tuệ phân tích từng pháp chân đế trong mỗi nhóm sắc hoặc nhóm danh: đây là địa đại, đây là thủy đại, đây là hỏa đại, đây là phong đại, v.v., hoặc đây là xúc, đây là thọ, đây là tưởng, đây là tư, đây là thức, v.v. Hãy quán để phá tan khối do tập hợp của sắc và khối do tập hợp của danh. Cũng hãy quán để phá tan khối do chức năng, tức chức năng của sắc và chức năng của danh. Vì thế, khi người thiện biết quán các chi duyên khởi đúng từng trường hợp theo đặc tính, chức năng, biểu hiện và nhân gần, gọi là biết phương pháp sai biệt.

**EN**
Past, present, and future mentality and materiality do indeed form one continuum. Even so, discern each material group and each group of consciousness individually to break down compactness of continuity. Phenomena such as ignorance in turn occur only in material or mental groups. With knowledge analyze each ultimate phenomenon in each material or mental group: this is the earth element, this the water element, this the fire element, this the wind element, and so on, or this is contact, this feeling, this perception, this volition, this consciousness, and so on. Discern so as to break down compactness of grouping in the masses of materiality and mentality. Also discern to break down compactness of function, the functions of materiality and of mentality. Thus when a good person knows how to discern the factors of dependent origination in their proper places by characteristic, function, manifestation, and proximate cause, this is called knowing the method of diversity.


<a id="M05-body-P102"></a>
## Miến 102 / Burmese page 102
Miến / Burmese 102

**VI**
Khi thấy đúng phương pháp sai biệt ấy, hành giả tự mình thấy rõ bằng trí tuệ chánh kiến rằng các pháp chân đế mới liên tục sinh lên, lần lượt nối nhau theo nhân quả. Vì tự mình thấy rõ bằng trí tuệ chánh kiến rằng các pháp nhân và các pháp quả có tự tính và đặc tính khác nhau, hành giả có thể đoạn trừ thường kiến chấp rằng “tự ngã không chấm dứt khi chết”.

**EN**
When the method of diversity is seen correctly, the meditator sees directly with right-view wisdom that new ultimate phenomena keep arising without interruption in causal succession. Because the meditator sees directly with right-view wisdom the distinct natures and characteristics of causes and effects, the eternalist view that “the self does not end at death” can be abandoned.

**VI**
Nếu không thấy đúng phương pháp sai biệt ấy, có thể thấy sai lầm. Người ấy bám chặt vào các danh sắc riêng biệt đang sinh trong cùng một dòng danh sắc như thể chúng thuộc các dòng khác nhau. Dòng các uẩn danh sắc, tuy qua những đời khác nhau, chỉ là một dòng tiếp nối. Từ đời ẩn sĩ Sumedha cho đến đời Đức Phật Gotama, dòng danh sắc vẫn chỉ là một dòng tiếp nối. Mặc dù vậy, có người không thể hiểu là “cùng một dòng tương tục” và cho rằng chúng sinh chết trong đời này là một người, chúng sinh sinh trong đời sau lại là một người khác, như thể có những dòng tương tục riêng biệt. Hiểu như vậy là đã nắm chặt đoạn kiến rằng “chúng sinh chết là hết”. Nếu hiểu như thể có các dòng tương tục riêng biệt, rằng “người làm thiện hay bất thiện là một người, người nhận quả tốt hay xấu lại là người khác, thân này do người đời này làm, thân kia do người đời kia chịu”, thì đã nắm chặt đoạn kiến. (Chú giải Abhidhamma, tập 2, tr. 188. Visuddhimagga, tập 2, tr. 220. Mūlaṭīkā, tập 2, tr. 132. Mahāṭīkā, tập 2, tr. 347–348.)

**EN**
If the method of diversity is not seen correctly, one may see it wrongly. One clings to the diverse instances of mentality and materiality occurring in a single continuum as though they belonged to different continua. The continuum of the aggregates of mentality and materiality is one succession even across different lives. From the life of the ascetic Sumedha to the life of Buddha Gotama there was only one succession of mentality and materiality. Even so, someone unable to understand this as “one continuum” may suppose that the being who dies in this life is one person and the being born in the next life another, as though they had separate continua. One who understands thus is already holding the annihilationist view that “a being ends at death.” If one thinks in terms of separate continua, “the one who does good or ill is one person, the one who undergoes good or bad results another; the person in this life acts and the person in that life undergoes,” one is firmly holding annihilationism. (Abhidhamma Commentary, vol. 2, p. 188. Visuddhimagga, vol. 2, p. 220. Mūlaṭīkā, vol. 2, p. 132. Mahāṭīkā, vol. 2, pp. 347–348.)


<a id="M05-body-P103"></a>
## 3. Phương pháp vô tác giả / 3. The method of non-agency
Miến / Burmese 103

**VI**
3. Phương pháp vô tác giả

**EN**
3. The method of non-agency

**VI**
Avijjāya saṅkhārā mayā uppādetabbā, saṅkhārānaṃ vā viññāṇaṃ amhehīti evamādibyāpārābhāvo abyāpāranayo nāma. Yaṃ sammā passanto kārakassa abhāvāvabodhato attadiṭṭhiṃ pajahati. Micchā passanto yo asatipi byāpāre avijjādīnaṃ sabhāvaniyamasiddho hetubhāvo, tassa aggahaṇato akiriyadiṭṭhiṃ upādiyati. (Chú giải Abhidhamma, tập 2, tr. 188. Visuddhimagga, tập 2, tr. 220.)

**EN**
Avijjāya saṅkhārā mayā uppādetabbā, saṅkhārānaṃ vā viññāṇaṃ amhehīti evamādibyāpārābhāvo abyāpāranayo nāma. Yaṃ sammā passanto kārakassa abhāvāvabodhato attadiṭṭhiṃ pajahati. Micchā passanto yo asatipi byāpāre avijjādīnaṃ sabhāvaniyamasiddho hetubhāvo, tassa aggahaṇato akiriyadiṭṭhiṃ upādiyati. (Abhidhamma Commentary, vol. 2, p. 188. Visuddhimagga, vol. 2, p. 220.)

**VI**
Về phía các pháp nhân, không có sự chủ động lo liệu rằng mình sẽ làm cho các pháp quả sinh khởi. Về phía các pháp quả, cũng không có sự chủ động lo liệu rằng “khi các pháp nhân hiện hữu thì chúng ta, những pháp quả, sẽ hiện hữu”.

**EN**
On the side of the causal phenomena there is no deliberate agency, no arranging for resultant phenomena to arise. On the side of the resultant phenomena there is no deliberate agency either, no arranging that “when the causal phenomena are present, we, the resultant phenomena, shall be present.”

**VI**
Trong vô minh không có sự chủ động lo liệu “ta sẽ làm sinh các hành”. Trong các hành cũng không có sự chủ động lo liệu “chúng ta sẽ làm sinh thức”. Tính chất không có sự chủ động lo liệu nơi các pháp như vô minh và hành được gọi là phương pháp vô tác giả.

**EN**
In ignorance there is no deliberate agency, “I shall produce the formations.” In the formations there is no deliberate agency, “We shall produce consciousness.” The absence of deliberate agency in phenomena such as ignorance and formations is called the method of non-agency.

**VI**
Khi quán đề mục duyên khởi, hành giả phải quán và tu tập để thấy đúng phương pháp vô tác giả này. Thấy đúng là thấy rằng “các pháp như vô minh và hành là nirīha, không có sự cố gắng, nỗ lực làm sinh pháp quả. Chúng là nijjīva, không phải một sinh mạng có khả năng nỗ lực như vậy. Chúng là dhammatā, chỉ có tính quy luật tự nhiên là có thể làm sinh pháp quả tương ứng”…

**EN**
When discerning the meditation subject of dependent origination, a meditator must discern and cultivate it so as to see this method of non-agency correctly. Correct seeing is to see that “phenomena such as ignorance and formations are nirīha, without any endeavor or effort to bring about the result. They are nijjīva, not a living entity capable of making such an effort. They are dhammatā, simply the natural regularity capable of producing the corresponding result”…


<a id="M05-body-P104"></a>
## Miến 104 / Burmese page 104
Miến / Burmese 104

**VI**
…Người thấy như vậy được gọi là sammā passanto, người thấy đúng đắn, người có chánh kiến. Sự thấy biết như vậy gọi là thấy đúng.

**EN**
…One who sees in this way is called sammā passanto, one who sees correctly, one who has right view. Seeing in this way is called seeing correctly.

**VI**
Khi hành giả tự mình thấy rõ phương pháp vô tác giả ấy bằng trí tuệ chánh kiến, có thể đoạn trừ ngã kiến chấp rằng có một tự ngã tối thượng tác động và sáng tạo, hoặc một sinh mạng, một tự ngã chịu sự tác động và sáng tạo ấy. Sở dĩ như vậy là vì hành giả tự mình thấy rõ bằng trí tuệ chánh kiến rằng trong các pháp nhân không có sự chủ động lo liệu làm sinh các pháp quả.

**EN**
When the meditator directly sees the method of non-agency correctly with right-view wisdom, the view of self can be abandoned, the belief in a supreme self that acts and creates or a living self that is acted upon and created. This is because the meditator directly sees with right-view wisdom that causal phenomena lack deliberate agency to make resultant phenomena arise.

**VI**
Nếu thấy sai phương pháp vô tác giả này, dù các pháp nhân không có sự chủ động lo liệu làm sinh các pháp quả, chúng vẫn hiện hữu với tính chất là pháp nhân, thành tựu theo quy luật tự nhiên, có thể làm sinh các pháp quả như hành. Do không thể chấp nhận tính chất ấy, người ấy có thể chấp tà kiến vô tác (akiriyadiṭṭhi), cho rằng “dù có hành động thì hành động ấy là vô hiệu”.

**EN**
If the method of non-agency is seen wrongly, one overlooks that although causal phenomena lack deliberate agency to produce their effects, they still exist as causes established by natural regularity and capable of producing effects such as formations. Unable to accept this nature, one may embrace the view of non-action (akiriyadiṭṭhi), that “even if one acts, the action is ineffective.”

**VI**
Quy luật tự nhiên (sabhāvaniyama) là tính quy luật của sự sinh khởi. Cùng với cụm sắc kết hợp, hỏa đại gọi là lửa hướng lên trên, nên ngọn lửa vươn lên. Cùng với cụm sắc kết hợp, gió có tính trương giãn, nên căng ra. Những cách sinh khởi như vậy là quy luật tự nhiên, là tính chất sinh khởi…

**EN**
Natural regularity (sabhāvaniyama) is the regular nature of arising. In association with a material group, the fire element called fire is oriented upwards, so the flame rises. In association with a material group, air has the nature of distension, so it expands. Modes of occurrence such as these are natural regularity, the nature of arising…


<a id="M05-body-P105"></a>
## Miến 105 / Burmese page 105
Miến / Burmese 105

**VI**
…tức diễn tiến thông thường. Cũng tương tự như vậy, khi các pháp nhân như vô minh hiện hữu, các pháp quả như hành hiện khởi. Khi các pháp nhân như vô minh không hiện hữu, các pháp quả như hành cũng không hiện khởi. Nói cách khác, khi các pháp nhân là vô minh, ái, thủ, hành và nghiệp hiện hữu, các pháp quả là thức, danh sắc, sáu xứ, xúc và thọ hiện khởi. Khi các pháp nhân là vô minh, ái, thủ, hành và nghiệp không hiện hữu, các pháp quả là thức, danh sắc, sáu xứ, xúc và thọ cũng không hiện khởi. Đây gọi là sabhāvaniyamasiddhahetubhāva, tính chất làm nhân được thành tựu theo quy luật sinh khởi tự nhiên. Nếu không chấp nhận rằng các pháp nhân như vô minh có năng lực thành tựu theo quy luật sinh khởi tự nhiên để làm sinh các pháp quả như hành…

**EN**
…that is, the customary course. In the same way, when causal phenomena such as ignorance are present, resultant phenomena such as formations occur. When causal phenomena such as ignorance are absent, resultant phenomena such as formations do not occur. In other words, when the causes ignorance, craving, clinging, formations, and kamma are present, the effects consciousness, mentality and materiality, the six bases, contact, and feeling arise. When those causes are absent, those effects do not arise. This is called sabhāvaniyamasiddhahetubhāva, the status of being a cause established by the natural regularity of arising. If one does not accept that causes such as ignorance have the power, established by the natural regularity of arising, to produce effects such as formations…

**VI**
Kassaci kattuno abhāvā na kāci kiriyā phalappavattinī. (Mahāṭīkā, tập 2, tr. 348.)

**EN**
Kassaci kattuno abhāvā na kāci kiriyā phalappavattinī. (Mahāṭīkā, vol. 2, p. 348.)

**VI**
…thì có thể sinh một loại tà kiến vô tác, bác bỏ nghiệp và quả của nghiệp. Kiến ấy cho rằng vì không có một người hay một pháp nào đóng vai trò tác giả nên bất cứ hành động nào bằng thân, khẩu hay ý cũng không liên hệ với quả, tức không cho quả. Theo kiến ấy, không có hành động bằng thân, khẩu hay ý nào liên hệ với quả. (Chú giải Abhidhamma, tập 2, tr. 188. Visuddhimagga, tập 2, tr. 220. Mahāṭīkā, tập 2, tr. 348.)

**EN**
…a kind of view of non-action may arise, rejecting kamma and its results. According to this view, since there is no person or phenomenon that is an agent, no bodily, verbal, or mental action is connected with a result, that is, none yields a result. It holds that there is no bodily, verbal, or mental action connected with a result. (Abhidhamma Commentary, vol. 2, p. 188. Visuddhimagga, vol. 2, p. 220. Mahāṭīkā, vol. 2, p. 348.)


<a id="M05-body-P106"></a>
## 4. Phương pháp tính quy luật / 4. The method of regularity
Miến / Burmese 106

**VI**
4. Phương pháp tính quy luật

**EN**
4. The method of regularity

**VI**
Avijjādīhi pana kāraṇehi saṅkhārādīnaṃyeva sambhavo khīrādīhi dadhiādīnaṃ viya, na aññesanti ayaṃ evaṃdhammatānayo nāma. Yaṃ sammā passanto paccayānurūpato phalāvabodhā ahetukadiṭṭhiṃ akiriyadiṭṭhiñca pajahati. Micchā passanto paccayānurūpaṃ phalappavattiṃ aggahetvā yato kutoci yassa kassaci asambhavaggahaṇato ahetukadiṭṭhiñceva niyatavādañca upādiyati. (Chú giải Abhidhamma, tập 2, tr. 188–189. Visuddhimagga, tập 2, tr. 220–221.)

**EN**
Avijjādīhi pana kāraṇehi saṅkhārādīnaṃyeva sambhavo khīrādīhi dadhiādīnaṃ viya, na aññesanti ayaṃ evaṃdhammatānayo nāma. Yaṃ sammā passanto paccayānurūpato phalāvabodhā ahetukadiṭṭhiṃ akiriyadiṭṭhiñca pajahati. Micchā passanto paccayānurūpaṃ phalappavattiṃ aggahetvā yato kutoci yassa kassaci asambhavaggahaṇato ahetukadiṭṭhiñceva niyatavādañca upādiyati. (Abhidhamma Commentary, vol. 2, pp. 188–189. Visuddhimagga, vol. 2, pp. 220–221.)

**VI**
Cũng như từ sữa chỉ sinh sữa đông và những thứ tương tự, khi các pháp quả sinh từ các pháp nhân như vô minh thì chỉ các pháp quả như hành, phù hợp với các pháp nhân ấy, mới sinh. Quả khác, không phù hợp với nhân, không sinh. Nói cách khác, khi có quả sinh do các pháp nhân là vô minh, ái, thủ, hành và nghiệp, chỉ những pháp quả phù hợp với các nhân ấy, tức thức, danh sắc, sáu xứ, xúc và thọ, mới sinh. Bất kỳ quả nào khác không phù hợp với nhân đều không thể sinh. Đây gọi là phương pháp tính quy luật. Khi thấy đúng phương pháp này, do tự mình thấy rõ bằng trí tuệ chánh kiến rằng quả sinh phù hợp với nhân, hành giả có thể đoạn trừ vô nhân kiến, vốn chấp rằng không có nhân, và vô tác kiến, vốn chấp rằng dù làm thiện hay bất thiện thì hành động ấy cũng vô hiệu. Nói cách khác, có thể đoạn trừ hai tà kiến này, vốn bác bỏ quả sinh do nhân, tức bác bỏ cả nhân lẫn quả.

**EN**
Just as from milk there arise only curds and the like, when results arise from causes such as ignorance, only results such as formations, corresponding to those causes, arise. Other results that do not correspond to the causes do not arise. Put another way, when results arise from the causes ignorance, craving, clinging, formations, and kamma, only effects corresponding to those causes arise, namely consciousness, mentality and materiality, the six bases, contact, and feeling. No other effect that does not correspond to the causes can arise. This is called the method of regularity. Seeing this method correctly, the meditator sees directly with right-view wisdom that results arise corresponding to their causes and can therefore abandon the view of causelessness, which holds that there are no causes, and the view of non-action, which holds that wholesome or unwholesome action is ineffective even when performed. In other words, one can abandon these two wrong views that reject effects arising from causes, thus rejecting both causes and effects.


<a id="M05-body-P107"></a>
## Thuyết định mệnh / The doctrine of fatalism
Miến / Burmese 107

**VI**
Người thấy sai có thể hiểu phương pháp tính quy luật ấy một cách sai lầm. Sự thấy sai diễn ra như thế này. Nếu một quả bất kỳ có thể sinh từ một nhân bất kỳ thì chẳng có lý do gì sữa đông và bơ không thể sinh từ nước. Nhưng chúng không thể sinh như vậy. Vì thế, người ấy đi đến chỗ chấp chặt một cách tùy tiện rằng không quả nào có thể sinh từ bất cứ nhân nào, tức chấp thuyết vô nhân.

**EN**
A person who sees wrongly may misunderstand the method of regularity. The mistaken way of seeing proceeds as follows. If any effect could arise from any cause, there would be no reason why curds and butter could not arise from water. Yet they cannot arise that way. The person therefore comes arbitrarily to hold that no effect can arise from any cause whatsoever, grasping the doctrine of causelessness.

**VI**
Do hiểu sai như vậy, người ấy không nắm được rằng quả sinh phù hợp với pháp nhân. Vì không thể nắm và chấp nhận rằng một quả nhất định sinh từ một nhân nhất định, người ấy đã nắm chặt vô nhân kiến hoặc thuyết định mệnh.

**EN**
Seeing wrongly in this way, one fails to grasp that effects arise in accordance with causal phenomena. Unable to grasp or accept that a particular effect arises from a particular cause, one comes to hold firmly to the view of causelessness or to the doctrine of fatalism.

**VI**
Thuyết định mệnh (niyatavāda) là một học thuyết bác bỏ sự hiện hữu của nghiệp và quả của nghiệp, cho rằng các quả tốt xấu của chúng sinh đã được ấn định sẵn. Nếu hỏi lại “Nếu không có nhân như vậy, do nhân nào mà chúng sinh và các vật hiện ra trước mắt lại sinh khởi?”, người theo thuyết vô nhân sẽ nói “Do định mệnh”, tức đã ấn định sẵn rằng đến thời điểm nào sẽ thành người, thành chư thiên hay thành loại súc sinh nào đó. Học thuyết ấy được gọi là thuyết định mệnh. (Xem lời Makkhali Gosāla trong Sāmaññaphalasutta để biết chi tiết.) (Chú giải Abhidhamma, tập 2, tr. 188–189. Visuddhimagga, tập 2, tr. 220–221. Mūlaṭīkā, tập 2, tr. 132. Mahāṭīkā, tập 2, tr. 348.)

**EN**
The doctrine of fatalism (niyatavāda) rejects the existence of kamma and its results, holding that the good and bad results experienced by beings are fixed in advance. If asked in turn, “If there are no such causes, on what account do the beings and things before our eyes come into being?”, the proponent of causelessness will answer, “By fate,” meaning that the time at which one will become a human being, a deva, or some kind of animal is predetermined. This teaching is called the doctrine of fatalism. (For details see the doctrine of Makkhali Gosāla in the Sāmaññaphalasutta.) (Abhidhamma Commentary, vol. 2, pp. 188–189. Visuddhimagga, vol. 2, pp. 220–221. Mūlaṭīkā, vol. 2, p. 132. Mahāṭīkā, vol. 2, p. 348.)

**VI**
Vì vậy, người thiện hãy tự mình, bằng trí tuệ chánh kiến, thấu suốt tính chất duyên khởi, tức mối liên hệ nhân quả…

**EN**
Therefore a good person should, through right-view wisdom, personally penetrate the nature of dependent origination, the relationship between cause and effect…


<a id="M05-body-P108"></a>
## Miến 108 / Burmese page 108
Miến / Burmese 108

**VI**
…và thấy biết trực tiếp. Hãy trân trọng tiếp nhận và ghi nhớ rằng sự thấy biết trực tiếp ấy là vũ khí tốt nhất để đoạn trừ, phá tan các loại tà thuyết, lời dạy sai lạc và tà kiến.

**EN**
…and know it directly. Receive this respectfully and remember that such direct knowledge is the best weapon for abandoning and destroying the various wrong doctrines, mistaken teachings, and wrong views.

**VI**
❂ ❂ ❂

**EN**
❂ ❂ ❂


<a id="M05-body-P109"></a>
## Phần 3. Thực hành quán theo phương pháp năm uẩn / Part 3. Practical discernment by the five-aggregate method
Miến / Burmese 109

**VI**
Điều cần đặc biệt lưu ý

**EN**
Points requiring particular attention

**VI**
1. Đối tượng của lộ cận tử trong đời trước.
2. Đối tượng của nhóm danh pháp tái tục trong đời hiện tại.
3. Đối tượng của hữu phần trong sáng làm ý môn, tức nhóm danh pháp hữu phần trong đời hiện tại.
4. Đối tượng của nhóm danh pháp tử sẽ sinh trong đời hiện tại.

**EN**
1. The object of the near-death process in the previous life.
2. The object of the group of rebirth-linking mental phenomena in the present life.
3. The object of the clear life-continuum serving as the mind door, the group of life-continuum mental phenomena in the present life.
4. The object of the group of mental phenomena at death that will arise in the present life.

**VI**
Cả bốn phải có cùng đối tượng. Vì hành giả chưa quán được tương lai, hãy tự mình dùng tuệ chú tâm so sánh và quán kỹ xem đối tượng của ba mục 1–3 có giống nhau không. Lại nữa, số lượng tâm và tâm sở trong ba loại tâm tái tục, hữu phần và tử phải giống nhau. Hãy chú tâm khảo sát kỹ. Hãy quán đi quán lại. Lúc này hành giả hẳn đã có thể quán hữu phần trong sáng làm ý môn. Nếu chưa thể, hãy quán kỹ lại các danh pháp tái tục. Sau khi danh pháp tái tục đã diệt và trước khi các tâm trong lộ sinh, hãy tiếp tục quán các tâm và tâm sở sinh liên tiếp trong khoảng ấy…

**EN**
All four must have the same object. Since the meditator cannot yet discern the future, attend with knowledge and personally compare and carefully discern whether the objects of items 1–3 are the same. Moreover, the numbers of consciousness and mental factors in rebirth-linking, life-continuum, and death must be the same. Attend carefully and investigate. Discern repeatedly. By now the meditator should normally be able to discern the clear life-continuum serving as mind door. If not, discern the rebirth-linking mental phenomena carefully again. After the rebirth-linking mental phenomena have ceased and before process consciousness occurs, continue discerning the consciousness and mental factors that arise in succession in that interval…


<a id="M05-body-P110"></a>
## Cách nhóm thành năm uẩn / How to group phenomena into five aggregates
Miến / Burmese 110

**VI**
…tức các nhóm danh pháp ấy. Để dòng tâm của một đời không gián đoạn, vào lúc các tâm trong lộ không sinh, chính các tâm làm nền cho đời sống tiếp tục sinh. Đó là các tâm hữu phần. Khi đã hiểu, hãy tiếp tục quán những danh pháp hữu phần sinh xen giữa các lộ tâm ngay trong hiện tại. Có thể thành công.

**EN**
…that is, those groups of mental phenomena. To maintain continuity of consciousness in a life, when process consciousness is not occurring, the consciousness that serves as the basis of that life continues to arise. These are the life-continuum consciousnesses. Once this is understood, continue discerning the life-continuum mental phenomena occurring between cognitive processes in the present. Success is possible.

**VI**
Cách nhóm thành năm uẩn

**EN**
How to group phenomena into five aggregates

**VI**
Khi theo phương pháp thứ năm của duyên khởi để quán các pháp nhân và các pháp quả trong mối liên hệ nhân quả, hãy nhóm thành năm uẩn trong từng nhóm tâm. Theo phương pháp năm uẩn ấy, hãy dùng tuệ thấy mối liên hệ giữa nhân và quả rồi quán các pháp nhân và các pháp quả. Trong khi quán, hãy phân biệt các tâm ngoài lộ với các tâm trong lộ. Tâm tái tục, hữu phần và tử là các tâm ngoài lộ, ở ngoài dòng tâm trong lộ. Với những tâm ngoài lộ ấy cũng hãy nhóm thành năm uẩn, dùng tuệ thấy tính chất liên hệ nhân quả của từng uẩn rồi quán các pháp nhân và các pháp quả. Tương tự, đối với tâm trong lộ, hãy nhóm thành năm uẩn trong từng nhóm tâm, dùng tuệ thấy tính chất liên hệ nhân quả của từng uẩn rồi quán các pháp nhân và các pháp quả. Ở đây “uẩn” có nghĩa là nhóm.

**EN**
When discerning causes and effects in causal relationship according to the fifth method of dependent origination, group the phenomena in each group of consciousness into five aggregates. By that five-aggregate method, see with knowledge the connection between cause and effect, then discern the causal and resultant phenomena. While discerning, distinguish process-free consciousness from process consciousness. Rebirth-linking, life-continuum, and death are process-free types of consciousness, outside the succession of process consciousness. For those process-free types too, group the phenomena into five aggregates, see with knowledge the causal relationship for each aggregate, and discern the causes and effects. Likewise, for process consciousness, group each group of consciousness into five aggregates, see with knowledge the causal relationship for each aggregate, and discern the causes and effects. Here “aggregate” means a group.

**VI**
1. Các sắc pháp được xét theo mười một phương diện là quá khứ, tương lai, hiện tại, bên trong, bên ngoài, thô, tế, hạ liệt, cao quý, xa, gần. Chúng làm đối tượng cho các lậu hoặc và là những pháp có thể bị ái và kiến chấp là “tôi, của tôi”…

**EN**
1. Material phenomena are considered in eleven aspects: past, future, present, internal, external, gross, subtle, inferior, superior, far, and near. They are objects of the taints and can be grasped through craving and views as “I” or “mine”…


<a id="M05-body-P111"></a>
## Năm thủ uẩn / The five aggregates subject to clinging
Miến / Burmese 111

**VI**
…Nhóm các sắc pháp ấy gọi là sắc thủ uẩn.

**EN**
…That group of material phenomena is called the materiality aggregate subject to clinging.

**VI**
2. Các pháp thọ được xét theo mười một phương diện là quá khứ, tương lai, hiện tại, bên trong, bên ngoài, thô, tế, hạ liệt, cao quý, xa, gần. Chúng làm đối tượng cho các lậu hoặc và có thể bị ái và kiến chấp là “tôi, của tôi”. Nhóm các pháp thọ ấy gọi là thọ thủ uẩn.
3. Quá khứ, pe. Nhóm các pháp tưởng gọi là tưởng thủ uẩn.
4. Quá khứ, pe. Nhóm các tâm sở thuộc hành gọi là hành thủ uẩn.
5. Quá khứ, pe. Nhóm tâm biết, tức các pháp thức, gọi là thức thủ uẩn. (Tương ưng bộ, tập 2, tr. 39, Khandhasutta.)

**EN**
2. Feeling is considered in eleven aspects: past, future, present, internal, external, gross, subtle, inferior, superior, far, and near. Feelings are objects of the taints and can be grasped through craving and views as “I” or “mine.” This group of feelings is called the feeling aggregate subject to clinging.
3. Past, pe. The group of perceptions is called the perception aggregate subject to clinging.
4. Past, pe. The group of mental factors belonging to formations is called the formations aggregate subject to clinging.
5. Past, pe. The group of cognizing consciousnesses is called the consciousness aggregate subject to clinging. (Saṃyutta Nikāya, vol. 2, p. 39, Khandhasutta.)

**VI**
Trong mười một phương diện ấy, một số từ có nghĩa như sau.
1. Oḷārika: pháp thô.
2. Sukhuma: pháp vi tế.
3. Hīna: pháp hạ liệt.
4. Paṇīta: pháp cao quý.
5. Dūra: pháp xa.
6. Santika: pháp gần.

**EN**
Among these eleven aspects, some of the words mean the following.
1. Oḷārika: gross phenomena.
2. Sukhuma: subtle phenomena.
3. Hīna: inferior phenomena.
4. Paṇīta: superior phenomena.
5. Dūra: far phenomena.
6. Santika: near phenomena.

**VI**
Hãy ghi nhớ nghĩa của các từ như vậy. Trong từng nhóm tâm, vốn là một phần của mười một phương diện này, có thể kể năm uẩn khi tính cả sắc vật nương và sắc làm cảnh. Trong mỗi nhóm tâm…

**EN**
Remember the meanings of the words in this way. Within each group of consciousness, which falls within these eleven aspects, the five aggregates can be reckoned together with the supporting material base and the material object. In each group of consciousness…


<a id="M05-body-P112"></a>
## Năm uẩn ở sát-na tái tục / The five aggregates at the moment of rebirth-linking
Miến / Burmese 112

**VI**
1. Sắc vật nương và sắc làm cảnh gọi là sắc uẩn.
2. Thọ thuộc nhóm tâm ấy gọi là thọ uẩn.
3. Tưởng gọi là tưởng uẩn.
4. Tất cả các tâm sở còn lại ngoài thọ, tưởng và thức gọi là hành uẩn.
5. Tâm biết, tức thức, gọi là thức uẩn.

**EN**
1. The supporting material base and material object are called the materiality aggregate.
2. Feeling in that group of consciousness is called the feeling aggregate.
3. Perception is called the perception aggregate.
4. The remaining mental factors apart from feeling, perception, and consciousness are called the formations aggregate.
5. Cognizing consciousness is called the consciousness aggregate.

**VI**
Trong hành uẩn, số tâm sở còn lại ngoài thọ, tưởng và thức có thể từ 5 đến 32. Dù có bao nhiêu, hãy ghi nhớ rằng toàn bộ nhóm tâm sở còn lại gọi là hành uẩn. Khi hiểu cách phân định năm uẩn như trên, cũng sẽ hiểu cách nhóm thành năm uẩn trong từng nhóm tâm được trình bày tiếp theo. Lại nữa, vì từng uẩn trong năm uẩn ấy có các nhân tương ứng riêng, hãy dùng tuệ thấy mối liên hệ nhân quả giữa các nhân ấy và các quả tương ứng, rồi quán pháp nhân và pháp quả theo mối liên hệ ấy.

**EN**
In the formations aggregate the number of mental factors remaining apart from feeling, perception, and consciousness may range from five to thirty-two. Whatever their number, remember that the whole group of remaining mental factors is called the formations aggregate. Once the delimitation of the five aggregates above is understood, the grouping into five aggregates in each group of consciousness to be presented below will also be understood. Moreover, each of the five aggregates has its respective causes. See with knowledge the causal relationship between the respective causes and their corresponding results, then discern causes and effects in that relationship.

**VI**
Sát-na giọt dịch kalala hình thành — Năm uẩn tái tục

**EN**
At the formation of the kalala drop — the five rebirth-linking aggregates

**VI**
Khi giọt dịch kalala hình thành vào sát-na tái tục: 1. Ba loại nhóm sắc là nhóm mười sắc có ý vật, nhóm mười sắc có thần kinh thân và nhóm mười sắc giới tính, gồm 30 sắc pháp, gọi là sắc uẩn.

**EN**
At the formation of the kalala drop at rebirth-linking: 1. The three kinds of material groups, the heart-base decad, the body decad, and the sex decad, comprising thirty material phenomena, are called the materiality aggregate.


<a id="M05-body-P113"></a>
## Miến 113 / Burmese page 113
Miến / Burmese 113

**VI**
2. Trong 34 danh pháp tái tục, thọ gọi là thọ uẩn.
3. Trong 34 danh pháp tái tục, tưởng gọi là tưởng uẩn.
4. Trong 34 danh pháp tái tục, tư gọi là hành uẩn theo cách thứ nhất. Trong 34 danh pháp tái tục, 31 tâm sở còn lại ngoài thọ, tưởng và thức gọi là hành uẩn theo cách thứ hai.
5. Trong 34 danh pháp tái tục, tâm biết, tức thức, gọi là thức uẩn.

**EN**
2. Among the thirty-four rebirth-linking mental phenomena, feeling is called the feeling aggregate.
3. Among the thirty-four rebirth-linking mental phenomena, perception is called the perception aggregate.
4. Among the thirty-four rebirth-linking mental phenomena, volition is called the formations aggregate according to the first method. According to the second, the thirty-one remaining mental factors apart from feeling, perception, and consciousness are called the formations aggregate.
5. Among the thirty-four rebirth-linking mental phenomena, cognizing consciousness is called the consciousness aggregate.

**VI**
Năm uẩn tái tục nêu trên chỉ áp dụng cho người có ba nhân, tái tục với thọ hỷ. Nếu là người có ba nhân tái tục với thọ xả, do không có hỷ nên có 33 danh pháp. Với người có hai nhân thì lần lượt có 33 hoặc 32 danh pháp. Sở dĩ trình bày hành uẩn theo hai cách là vì trong Khandhavagga của Chánh tạng, khi thuyết hành uẩn theo cách kinh, Đức Phật nêu tư làm chính. Vì thế, cách thứ nhất lấy riêng tư làm chính để trình bày hành uẩn. Mặt khác, nếu chỉ lấy tư làm hành uẩn thì trong một nhóm tâm…

**EN**
The five rebirth-linking aggregates above apply only to a person with three roots whose rebirth-linking is accompanied by joyful feeling. For a person with three roots whose rebirth-linking is accompanied by equanimous feeling, there are thirty-three mental phenomena because joy is absent. For a person with two roots there are thirty-three or thirty-two mental phenomena respectively. The formations aggregate is presented in two ways because, in the canonical Khandhavagga, the Buddha gave primacy to volition when teaching the formations aggregate according to the discourse method. Thus the first presentation takes volition alone as primary in showing the formations aggregate. On the other hand, if only volition is taken as the formations aggregate, in one group of consciousness…

**VI**
…các tâm sở còn lại ngoài thọ, tưởng và tư sẽ nằm ngoài năm uẩn. Lại có thể hỏi các tâm sở còn lại ấy có các nhân tương ứng hay không. Đặc biệt đối với xúc…

**EN**
…the remaining mental factors apart from feeling, perception, and volition would fall outside the five aggregates. One might also ask whether those remaining mental factors have their respective causes. In particular, regarding contact…


<a id="M05-body-P114"></a>
## Cách quán nhân nối với quả / How to discern causes in connection with their effects
Miến / Burmese 114

**VI**
1. Phassasamudayā vedanāsamudayo.
2. Phassasamudayā saññāsamudayo.
3. Phassasamudayā saṅkhārasamudayo. (Tương ưng bộ, tập 2, tr. 51–52.)

**EN**
1. Phassasamudayā vedanāsamudayo.
2. Phassasamudayā saññāsamudayo.
3. Phassasamudayā saṅkhārasamudayo. (Saṃyutta Nikāya, vol. 2, pp. 51–52.)

**VI**
Theo những lời dạy này, xúc là nhân của thọ uẩn, tưởng uẩn và hành uẩn. Lại có thể hỏi xúc ấy có nhân hay không. Vì muốn cho biết rằng xúc cùng các tâm sở còn lại đều có các nhân tương ứng, và vì muốn trình bày đầy đủ các pháp chân đế, nên hành uẩn cũng được trình bày theo cách thứ hai. Hãy ghi nhớ tương tự ở những chỗ khác.

**EN**
According to these teachings, contact is a cause of the feeling, perception, and formations aggregates. One may then ask whether contact itself has causes. To make known that contact and the remaining mental factors all have their respective causes, and to give a full account of ultimate phenomena, the formations aggregate is also presented in the second way. Remember the same principle elsewhere.

**VI**
Cách quán nhân nối với quả

**EN**
How to discern causes in connection with their effects

**VI**
Trước tiên, trong các nhân quá khứ mà thiện hữu hành thiền đã tự tìm thấy, hãy quán cho hiểu rõ vì sao hai pháp thuộc nghiệp luân, hành và nghiệp, sinh do phiền não luân gồm vô minh, ái và thủ. Sau đó dùng tuệ quán cho thấy sắc uẩn tái tục thuộc quả luân sinh trong mối liên hệ nhân quả do năng lực nghiệp thuộc hành và nghiệp. Khi dùng tuệ thấy nghiệp nhân và sắc do nghiệp sinh lúc tái tục là quả, nói cách khác, thấy hành và nghiệp được vô minh, ái và thủ bao quanh là nhân, còn sắc do nghiệp sinh lúc tái tục là quả, hãy bắt đầu quán các pháp nhân và các pháp quả theo cách sau.

**EN**
First, among the past causes that you, the good meditator, have personally found, discern so as to understand how the two phenomena of the round of kamma, formations and kamma, arise owing to the round of defilements, ignorance, craving, and clinging. Then discern with knowledge how the materiality aggregate at rebirth-linking in the round of results arises in causal relationship through the potency of kamma belonging to formations and kamma. Once you see with knowledge the causal kamma and its effect, kamma-produced materiality at rebirth-linking, in other words, formations and kamma surrounded by ignorance, craving, and clinging as the cause and kamma-produced materiality at rebirth-linking as the result, begin discerning the causes and effects as follows.


<a id="M05-body-P115"></a>
## Sắc uẩn tái tục / The materiality aggregate at rebirth-linking
Miến / Burmese 115

**VI**
1. Do vô minh (20) sinh nên sắc do nghiệp sinh lúc tái tục sinh. Vô minh (20) là pháp nhân. Sắc do nghiệp sinh lúc tái tục là pháp quả.

**EN**
1. With the arising of ignorance (20), kamma-produced materiality at rebirth-linking arises. Ignorance (20) is the cause. Kamma-produced materiality at rebirth-linking is the effect.

**VI**
2. Do ái (20) sinh nên sắc do nghiệp sinh lúc tái tục sinh. Ái (20) là pháp nhân. Sắc do nghiệp sinh lúc tái tục là pháp quả.

**EN**
2. With the arising of craving (20), kamma-produced materiality at rebirth-linking arises. Craving (20) is the cause. Kamma-produced materiality at rebirth-linking is the effect.

**VI**
3. Do thủ (20) sinh nên sắc do nghiệp sinh lúc tái tục sinh. Thủ (20) là pháp nhân. Sắc do nghiệp sinh lúc tái tục là pháp quả.

**EN**
3. With the arising of clinging (20), kamma-produced materiality at rebirth-linking arises. Clinging (20) is the cause. Kamma-produced materiality at rebirth-linking is the effect.

**VI**
4. Do hành (34) sinh nên sắc do nghiệp sinh lúc tái tục sinh. Hành (34) là pháp nhân. Sắc do nghiệp sinh lúc tái tục là pháp quả.

**EN**
4. With the arising of formations (34), kamma-produced materiality at rebirth-linking arises. Formations (34) is the cause. Kamma-produced materiality at rebirth-linking is the effect.

**VI**
5. Do nghiệp, tức năng lực nghiệp của hành (34) sinh nên sắc do nghiệp sinh lúc tái tục sinh. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Sắc do nghiệp sinh lúc tái tục là pháp quả.

**EN**
5. With the arising of kamma, the kammic potency of formations (34), kamma-produced materiality at rebirth-linking arises. Kamma, the kammic potency of formations (34) is the cause. Kamma-produced materiality at rebirth-linking is the effect.

**VI**
Hãy nối nhân với quả như vậy rồi quán các pháp nhân và các pháp quả. Hãy thực hành quán.

**EN**
Connect cause and effect in this way and discern the causal and resultant phenomena. Practise discerning them.

**VI**
Ghi chú. Số 20 của vô minh, ái và thủ chỉ các danh pháp thuộc nhóm tham và kiến trong mỗi tốc hành tham của lộ ý môn thuộc phiền não luân. Số 34 của hành và nghiệp chỉ 34 danh pháp thuộc nhóm tín và tuệ trong mỗi tốc hành đại thiện của lộ ý môn thuộc nghiệp luân.

**EN**
Note. The number twenty for ignorance, craving, and clinging refers to the mental phenomena of the group with greed and views in each greed impulsion in a mind-door process of the round of defilements. The number thirty-four for formations and kamma refers to the thirty-four mental phenomena of the group with faith and wisdom in each great wholesome impulsion in a mind-door process of the round of kamma.


<a id="M05-body-P116"></a>
## Miến 116 / Burmese page 116
Miến / Burmese 116

**VI**
Nếu thiện hữu vun bồi nghiệp với thọ xả, hành và nghiệp ấy đi cùng thọ xả. Vì không có hỷ nên có 33 danh pháp. Những người có thể quán các pháp nhân và quả của danh sắc, phân định bằng tuệ và tu tập quán như vậy nói chung là người có ba nhân. Vì vậy ở đây trình bày người có ba nhân làm mẫu. Đối với người có hai nhân, hãy hiểu là có 33 hoặc 32 danh pháp. Sắc do tâm sinh, do thời tiết sinh và do vật thực sinh chưa sinh ở sát-na sinh của tái tục. Chỉ sắc do nghiệp sinh bắt đầu sinh ở sát-na đó, nên ở đây ưu tiên trình bày cách nối các nhân với riêng sắc do nghiệp sinh và quán các pháp nhân, các pháp quả. Tuy nhiên, từ sát-na trụ của tái tục, hỏa đại, tức thời tiết, trong các sắc do nghiệp sinh đã đến sát-na trụ của sắc và có thể làm sinh các nhóm sắc mới do thời tiết sinh. Từ hữu phần thứ nhất sau tái tục, sắc do tâm sinh bắt đầu sinh. Từ lúc dưỡng chất trong thức ăn người mẹ ăn truyền đến thân của thai nhi, sắc do vật thực sinh bắt đầu sinh. Vì vậy, nếu hướng tuệ đến thời điểm tương ứng thì cũng có thể quán các sắc ấy.

**EN**
If you accumulated the kamma with equanimous feeling, those formations and that kamma were associated with equanimous feeling. As joy is absent, there are thirty-three mental phenomena. Those who can discern causes and effects of mentality and materiality, distinguish them with knowledge, and cultivate discernment in this way are generally people with three roots. Therefore a person with three roots is given as the example here. For a person with two roots, understand the numbers as thirty-three or thirty-two. Mind-produced, temperature-produced, and nutriment-produced materiality have yet to arise at the arising moment of rebirth-linking. Only kamma-produced materiality begins at that moment, so the presentation gives priority to connecting causes with kamma-produced materiality and discerning causes and effects. From the presence moment of rebirth-linking, however, the fire element, that is, temperature, in that kamma-produced materiality has reached the presence moment of materiality and can produce new temperature-produced groups. Mind-produced materiality begins with the first life-continuum after rebirth-linking. Nutriment-produced materiality begins when nutritive essence in the mother's food reaches the body of the embryo. Thus these too can be discerned by directing knowledge to the relevant time.

**VI**
Tương tự, trước hết hãy dùng tuệ quán cho thấy các pháp quả như thọ uẩn và các danh uẩn khác hiện hữu do các pháp nhân tương ứng hiện hữu. Khi chính mình thấy rõ bằng con mắt trí tuệ chánh kiến, hãy quán các pháp nhân và các pháp quả như sau.

**EN**
Likewise, first see with knowledge that resultant phenomena, such as the feeling aggregate and the other mental aggregates, become manifest because their respective causes become manifest. When you see this directly with the eye of right-view wisdom, discern causes and effects as follows.


<a id="M05-body-P117"></a>
## Thọ uẩn tái tục / The feeling aggregate at rebirth-linking
Miến / Burmese 117

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Do vô minh (20) sinh nên thọ uẩn tái tục sinh. Vô minh (20) là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
1. With the arising of ignorance (20), the feeling aggregate at rebirth-linking arises. Ignorance (20) is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
2. Do ái (20) sinh nên thọ uẩn tái tục sinh. Ái (20) là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
2. With the arising of craving (20), the feeling aggregate at rebirth-linking arises. Craving (20) is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
3. Do thủ (20) sinh nên thọ uẩn tái tục sinh. Thủ (20) là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
3. With the arising of clinging (20), the feeling aggregate at rebirth-linking arises. Clinging (20) is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
4. Do hành (34) sinh nên thọ uẩn tái tục sinh. Hành (34) là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
4. With the arising of formations (34), the feeling aggregate at rebirth-linking arises. Formations (34) is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
5. Do nghiệp, tức năng lực nghiệp của hành (34) sinh nên thọ uẩn tái tục sinh. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
5. With the arising of kamma, the kammic potency of formations (34), the feeling aggregate at rebirth-linking arises. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Do vật, tức sắc ý vật (30), sinh nên thọ uẩn tái tục sinh. Vật, tức sắc ý vật (30), là pháp nhân. Thọ uẩn tái tục là pháp quả.
7. Do cảnh, tức cảnh nghiệp, sinh nên thọ uẩn tái tục sinh.

**EN**
6. With the arising of the base, the heart-base materiality (30), the feeling aggregate at rebirth-linking arises. The base, the heart-base materiality (30), is the cause. The feeling aggregate at rebirth-linking is the effect.
7. With the arising of the object, the kamma-object, the feeling aggregate at rebirth-linking arises.


<a id="M05-body-P118"></a>
## Cách trình bày tóm tắt / The abbreviated presentation
Miến / Burmese 118

**VI**
Cảnh, tức cảnh nghiệp, là pháp nhân. Thọ uẩn tái tục là pháp quả.
8. Do xúc (34 trừ thọ, còn 33) sinh nên thọ uẩn tái tục sinh. Xúc (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
The object, the kamma-object, is the cause. The feeling aggregate at rebirth-linking is the effect.
8. With the arising of contact (thirty-four minus feeling, leaving thirty-three), the feeling aggregate at rebirth-linking arises. Contact (thirty-four minus feeling, leaving thirty-three) is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
Hãy quán các pháp nhân và pháp quả như vậy. Tuy nhiên, để văn bản gọn, từ đây lược câu “Do vô minh (20) sinh nên thọ uẩn tái tục sinh” và những câu tương tự, chỉ ghi “Vô minh (20) là pháp nhân. Thọ uẩn tái tục là pháp quả”, v.v. Khi thực hành quán các pháp nhân và quả, hãy quán theo cách đầy đủ nêu trên. Để nắm được cách làm, sau đây trình bày lại dưới dạng tóm tắt phép quán sắc uẩn và thọ uẩn đã nêu trên.

**EN**
Discern the causes and effects in this way. For brevity, however, the wording “With the arising of ignorance (20), the feeling aggregate at rebirth-linking arises,” and similar statements will be omitted. The text will simply state, “Ignorance (20) is the cause. The feeling aggregate at rebirth-linking is the effect,” and so on. In actually discerning causes and effects, discern them in the full manner set out above. To help you grasp the method, the discernment of the materiality and feeling aggregates described above is set out again here in abbreviated form.

**VI**
Tái tục — Sắc uẩn (sắc do nghiệp sinh, 30)

**EN**
Rebirth-linking — Materiality aggregate (kamma-produced materiality, 30)

**VI**
1. Vô minh (20) là pháp nhân. Sắc uẩn tái tục là pháp quả.

**EN**
1. Ignorance (20) is the cause. The materiality aggregate at rebirth-linking is the effect.

**VI**
2. Ái (20) là pháp nhân. Sắc uẩn tái tục là pháp quả.

**EN**
2. Craving (20) is the cause. The materiality aggregate at rebirth-linking is the effect.

**VI**
3. Thủ (20) là pháp nhân. Sắc uẩn tái tục là pháp quả.

**EN**
3. Clinging (20) is the cause. The materiality aggregate at rebirth-linking is the effect.

**VI**
4. Hành (34) là pháp nhân. Sắc uẩn tái tục là pháp quả.

**EN**
4. Formations (34) is the cause. The materiality aggregate at rebirth-linking is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34), là pháp nhân. Sắc uẩn tái tục…

**EN**
5. Kamma, the kammic potency of formations (34), is the cause. The materiality aggregate at rebirth-linking…


<a id="M05-body-P119"></a>
## Tái tục — Thọ uẩn / Rebirth-linking — Feeling aggregate
Miến / Burmese 119

**VI**
…là pháp quả.

**EN**
…is the effect.

**VI**
Tái tục — Thọ uẩn

**EN**
Rebirth-linking — Feeling aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
1. Ignorance (20) is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
2. Ái (20) là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
2. Craving (20) is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
3. Thủ (20) là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
3. Clinging (20) is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
4. Hành (34) là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
4. Formations (34) is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật, tức sắc ý vật (30), là pháp nhân. Thọ uẩn tái tục là pháp quả.
7. Cảnh là pháp nhân. Thọ uẩn tái tục là pháp quả.
8. Xúc (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
6. The base, the heart-base materiality (30), is the cause. The feeling aggregate at rebirth-linking is the effect.
7. The object is the cause. The feeling aggregate at rebirth-linking is the effect.
8. Contact (thirty-four minus feeling, leaving thirty-three) is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
Giải thích

**EN**
Explanations

**VI**
1. Vật. Trong cõi có năm uẩn, các danh pháp chỉ có khả năng sinh khi có sắc vật nương. Nếu không có sắc vật nương…

**EN**
1. Base. In a five-aggregate realm, mental phenomena can arise only when supporting materiality is present. If there is no supporting materiality…


<a id="M05-body-P120"></a>
## Miến 120 / Burmese page 120
Miến / Burmese 120

**VI**
…các danh pháp không có khả năng sinh. Vào sát-na tái tục, các danh pháp tái tục, gồm thọ uẩn tái tục, chỉ có thể sinh nương vào sắc ý vật sinh cùng với chúng. Nếu không có chỗ nương, chúng không thể sinh. Mặt khác, sắc ý vật cũng không thể sinh riêng lẻ, chỉ có thể sinh trong một nhóm sắc. Đặc biệt, nó chỉ có thể sinh khi nương vào bốn đại cùng nhóm, có khả năng trợ cho nó bằng các duyên như câu sinh. Nếu không có chỗ nương ấy thì nó không thể sinh. Hơn nữa, nhóm mười sắc có ý vật ở sát-na tái tục chỉ có thể sinh cùng với nhóm mười sắc có thần kinh thân và nhóm mười sắc giới tính. Vì thế, theo phương pháp kinh…

**EN**
…mental phenomena have no capacity to arise. At rebirth-linking the rebirth-linking mental phenomena, including the rebirth-linking feeling aggregate, can arise only dependent on the heart-base materiality that arises together with them. Without a support they cannot arise. The heart-base materiality itself cannot arise in isolation either. It occurs only in a material group. In particular it arises only in dependence on the four great elements in its group, which can assist it through conditions such as conascence. Without that support it cannot arise. Further, at rebirth-linking the heart-base decad can arise only together with the body decad and the sex decad. Thus, according to the discourse method…

**VI**
Vatthu nāma karajakāyo, pe. So atthato bhūtāni ceva upādārūpāni ca. (Chú giải Majjhima, tập 1, tr. 281.)

**EN**
Vatthu nāma karajakāyo, pe. So atthato bhūtāni ceva upādārūpāni ca. (Majjhima Commentary, vol. 1, p. 281.)

**VI**
Nāmarūpavavatthānassa adhippetattā niravasesarūpapariggahassa dassanatthaṃ “vatthu nāma karajakāyo”ti āha. Na cakkhādīni chavatthūnīti. Karajakāyassa pana vatthubhāvasādhanatthaṃ “idañca pana me viññāṇaṃ ettha sitaṃ, ettha paṭibaddhan”ti suttaṃ ābhataṃ. (Mūlaṭīkā, tập 2, tr. 157.)

**EN**
Nāmarūpavavatthānassa adhippetattā niravasesarūpapariggahassa dassanatthaṃ “vatthu nāma karajakāyo”ti āha. Na cakkhādīni chavatthūnīti. Karajakāyassa pana vatthubhāvasādhanatthaṃ “idañca pana me viññāṇaṃ ettha sitaṃ, ettha paṭibaddhan”ti suttaṃ ābhataṃ. (Mūlaṭīkā, vol. 2, p. 157.)

**VI**
Vật là thân do vật chất tạo thành (karajakāya), pe. Xét theo pháp chân đế, thân ấy là các sắc đại chủng và sắc y sinh. (Chú giải Majjhima, tập 1, tr. 281.)

**EN**
The base is the material body (karajakāya), pe. In terms of ultimate phenomena, that body consists of the great elements and derived materiality. (Majjhima Commentary, vol. 1, p. 281.)

**VI**
Theo các giải thích của Chú giải và Phụ chú giải, khi lấy sắc vật làm đối tượng thì cần tính cả các sắc đại chủng và sắc y sinh. Hãy quán và tu tập để phá khối do tập hợp của sắc và để tuệ thấy đến sắc chân đế. Vì vậy, sắc vật nương của thọ uẩn tái tục…

**EN**
In accordance with these explanations in the Commentary and Subcommentary, when taking the material base as an object one includes both the great elements and derived materiality. Discern and cultivate this so as to break down compactness of material grouping and for knowledge to reach ultimate materiality. Thus the supporting material base of the feeling aggregate at rebirth-linking…


<a id="M05-body-P121"></a>
## Vật và cảnh / Base and object
Miến / Burmese 121

**VI**
…theo phương pháp Abhidhamma, chỉ nương vào một loại sắc là sắc ý vật, nên chỉ kể riêng sắc ý vật. Theo phương pháp kinh, phải kể làm sắc vật cả 30 sắc pháp cùng với sắc ý vật. Phương pháp kinh là phương pháp thực hành. Để phá khối và để tuệ thấy đến chân đế, hãy ưu tiên quán cả 30 sắc. Vì vậy, theo phương pháp kinh, hãy ghi nhớ rằng cả 30 sắc pháp cùng với sắc ý vật đều gọi là sắc vật. Hãy tự mình dùng con mắt trí tuệ chánh kiến quán cho thấy thọ uẩn tái tục chỉ có thể sinh khi có sắc vật ấy làm chỗ nương, rồi quán pháp nhân và pháp quả. Hãy ghi nhớ tương tự ở mọi chỗ. Theo lời giải thích ấy, hãy quán như sau.

**EN**
…according to the Abhidhamma method, depends on the single type of materiality called the heart-base. Thus only the heart-base materiality is counted. According to the discourse method, all thirty material phenomena together with the heart-base are counted as the material base. The discourse method is the method for practice. To break down compactness and bring knowledge to ultimate phenomena, give priority to discerning all thirty. Therefore remember that according to the discourse method all thirty material phenomena together with the heart-base are termed the material base. See directly with the eye of right-view wisdom that the rebirth-linking feeling aggregate can arise only when it has that material base as support, then discern the cause and effect. Remember the same throughout. In accordance with the explanation, discern as follows.

**VI**
Do vật, tức ý vật (30), sinh nên thọ uẩn tái tục sinh. Vật, tức ý vật (30), là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
With the arising of the base, the heart-base (30), the feeling aggregate at rebirth-linking arises. The base, the heart-base (30), is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
2. Cảnh. Đã giải thích rằng cảnh của danh pháp tái tục chính là cảnh của lộ cận tử đời trước. Thọ cảm nhận vị của cảnh ấy. Hãy dùng tuệ quán cho thấy và hiểu rõ rằng nếu không có cảnh để cảm nhận thì thọ không thể sinh. Trong ví dụ trên, cảnh dâng vật thực cúng dường Đức Phật chỉ được nêu làm mẫu để dễ hiểu. Nghiệp của các hành giả phần nhiều khác nhau. Với một số người, nghiệp bố thí đang cho quả. Với một số người, nghiệp trì giới đang cho quả. Với một số người…

**EN**
2. Object. It has already been explained that the object of rebirth-linking mentality is the object of the near-death process in the preceding life. Feeling experiences the taste of that object. See with knowledge and understand that without an object to experience, feeling cannot arise. In the example above, the object of offering food to the Buddha was given only as an illustration to make the point clear. The kammas of meditators are generally different from one person to another. In some, kamma of giving is giving its result. In others, kamma of virtue is giving its result. In still others…


<a id="M05-body-P122"></a>
## Cảnh và xúc / Object and contact
Miến / Burmese 122

**VI**
…nghiệp tu tập đang cho quả. Trong nghiệp bố thí cũng có nhiều loại, như nghiệp dâng vật thực, nghiệp dâng y, v.v. Nghiệp trì giới cũng có nhiều loại, như giữ năm giới, tám giới, mười giới, v.v. Nghiệp tu tập cũng có nhiều loại, như tu kasiṇa, bất tịnh, niệm hơi thở, tâm từ và minh sát. Vì có thể có nhiều loại nghiệp như vậy, cảnh của lộ cận tử đời trước và cảnh của tái tục, hữu phần và tử trong đời hiện tại cũng có thể có nhiều loại. Sau khi dùng trí tuệ chánh kiến quán cho rõ cảnh của lộ cận tử đời trước và cảnh tái tục đời hiện tại, hãy dùng tuệ thấy rằng chỉ khi có cảnh để cảm nhận thì thọ mới sinh ở sát-na tái tục. Hãy quán pháp nhân và pháp quả như sau.

**EN**
…kamma of cultivation is giving its result. There are many kinds of kamma of giving, such as offering food, offering robes, and so on. There are many kinds of kamma of virtue, such as observing five precepts, eight precepts, ten precepts, and so on. There are also many kinds of kamma of cultivation, such as cultivating kasiṇa, foulness, mindfulness of breathing, loving-kindness, and insight. Since there can be many kinds of kamma, the object of the near-death process of the previous life and the object of rebirth-linking, life-continuum, and death in the present life can also be of many kinds. After discerning clearly with right-view wisdom the object of the near-death process of the previous life and the present rebirth-linking object, see with knowledge that feeling arises at rebirth-linking only when there is an object to experience. Discern the cause and effect as follows.

**VI**
Do cảnh, tức cảnh nghiệp, sinh nên thọ uẩn tái tục sinh. Cảnh, tức cảnh nghiệp, là pháp nhân. Thọ uẩn tái tục là pháp quả.

**EN**
With the arising of the object, the kamma-object, the feeling aggregate at rebirth-linking arises. The object, the kamma-object, is the cause. The feeling aggregate at rebirth-linking is the effect.

**VI**
3. Xúc. Phassasamudayā vedanāsamudayo: do xúc sinh nên thọ sinh. Hãy ghi nhớ rằng lời dạy này lấy xúc làm chính. Trong lời dạy Paṭṭhāna có nói như sau.

**EN**
3. Contact. Phassasamudayā vedanāsamudayo: with the arising of contact, feeling arises. Remember that this teaching gives primacy to contact. In the Paṭṭhāna teaching it is stated as follows.

**VI**
Cattāro khandhā arūpino aññamaññaṃ sahajātapaccayena paccayo. Cattāro khandhā arūpino aññamaññaṃ nissayapaccayena paccayo. (Paṭṭhāna, tập 1, tr. 5.)

**EN**
Cattāro khandhā arūpino aññamaññaṃ sahajātapaccayena paccayo. Cattāro khandhā arūpino aññamaññaṃ nissayapaccayena paccayo. (Paṭṭhāna, vol. 1, p. 5.)

**VI**
Bốn danh uẩn trợ lẫn nhau bằng năng lực của duyên câu sinh và duyên y chỉ. (Paṭṭhāna, tập 1, tr. 5.) Lời dạy đầy đủ theo cách ấy. Các danh pháp nương nhau và trợ nhau như…

**EN**
The four mental aggregates support one another through the force of conascence condition and dependence condition. (Paṭṭhāna, vol. 1, p. 5.) The teaching gives a full account in this way. Mental phenomena depend on and support each other like…


<a id="M05-body-P123"></a>
## Miến 123 / Burmese page 123
Miến / Burmese 123

**VI**
…“cù lao nương bãi bồi, bãi bồi nương cù lao”. Khi ăn một món, nhai kỹ thì nước vị tiết ra nhiều hơn và vị được cảm nhận rõ hơn. Cũng vậy, trong các danh pháp cùng sinh trong một nhóm tâm hay trong các danh pháp ở những nhóm tâm khác nhau, khi xúc tiếp cận cảnh, kết nối tâm biết với cảnh và chạm đến cảnh, thì vị của cảnh có thể được cảm nhận rõ hơn trong sự cảm nhận của thọ. Vì vậy lời dạy “do xúc nên thọ sinh” lấy xúc làm chính. Tuy vậy, một mình xúc không có khả năng sinh. Chỉ khi được các pháp tương ưng khác trợ bằng năng lực của các duyên như câu sinh và y chỉ, xúc mới có thể sinh cùng các pháp tương ưng ấy. Do đó, khi nói “do xúc”, hãy ghi nhớ rằng các pháp tương ưng khác cũng được kể vào.

**EN**
…“the island depends on the sandbank, and the sandbank on the island”. When eating a food, chewing thoroughly releases more of its juices and its flavor can be experienced more clearly. So too, among mental phenomena arising together in one group of consciousness or in different groups, when contact approaches the object, connects cognizing consciousness with it, and touches it, the taste of the object can be felt more clearly in the experience of feeling. Thus the teaching “from contact, feeling arises” gives primacy to contact. Yet contact does not have the ability to arise by itself. Only when the other associated phenomena support it through conditions such as conascence and dependence can contact arise together with them. Therefore, when “from contact” is said, remember that the other associated phenomena are included.

**VI**
Điểm cần ghi nhớ. Trong các pháp tương ưng có trong một nhóm tâm, khi một danh pháp là pháp quả, tức khi lấy một danh pháp làm quả mà quán, các danh pháp còn lại là pháp nhân. Hãy ghi nhớ điểm thiết yếu này. Có thể hiểu các danh uẩn còn lại bằng cách lấy thọ uẩn này làm mẫu. Cách các danh pháp trợ nhau giữa các nhóm tâm sẽ được nêu ở phần sau. Hành giả hãy dùng tuệ thấy cách các danh pháp trợ lẫn nhau. Nói cách khác, hãy thấy cách nhiều danh pháp như xúc trợ cho thọ, hay cách ba danh uẩn là tưởng uẩn, hành uẩn và thức uẩn trợ cho thọ uẩn bằng các duyên câu sinh…

**EN**
The main point to remember. Among the associated phenomena in one group of consciousness, when one mental phenomenon is an effect, that is, when one is discerned as the effect, the remaining mental phenomena are causes. Remember this essential point. The remaining mental aggregates can be understood by taking this feeling aggregate as an example. How mental phenomena support one another across groups of consciousness will be shown later. The meditator should see with knowledge how the mental phenomena support one another. In other words, see how the many mental phenomena such as contact support feeling, or how the three aggregates of perception, formations, and consciousness support the feeling aggregate by conascence…


<a id="M05-body-P124"></a>
## Tái tục — Tưởng uẩn / Rebirth-linking — Perception aggregate
Miến / Burmese 124

**VI**
…hỗ tương, y chỉ, v.v. Hãy dùng tuệ thấy cách các pháp ấy trợ nhau, nương nhau và liên hệ với nhau theo nhân quả. Hãy quán. Khi đã thấy bằng tuệ, hãy quán các pháp nhân và pháp quả như sau.

**EN**
…mutuality, dependence, and so on. See with knowledge how these phenomena support one another, depend on one another, and are related causally. Discern them. Having seen with knowledge, discern the causes and effects as follows.

**VI**
Do xúc (34 trừ thọ, còn 33) sinh nên thọ uẩn sinh. Xúc (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn là pháp quả.

**EN**
With the arising of contact (34 minus feeling, leaving 33), the feeling aggregate arises. Contact (34 minus feeling, leaving 33) is the cause. The feeling aggregate is the effect.

**VI**
Tái tục — Tưởng uẩn

**EN**
Rebirth-linking — Perception aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

**EN**
1. Ignorance (20) is the cause. The perception aggregate at rebirth-linking is the effect.

**VI**
2. Ái (20) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

**EN**
2. Craving (20) is the cause. The perception aggregate at rebirth-linking is the effect.

**VI**
3. Thủ (20) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

**EN**
3. Clinging (20) is the cause. The perception aggregate at rebirth-linking is the effect.

**VI**
4. Hành (34) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

**EN**
4. Formations (34) is the cause. The perception aggregate at rebirth-linking is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The perception aggregate at rebirth-linking is the effect.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật (3 nhóm, 30 sắc) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

**EN**
6. The base (three groups, 30 kinds of materiality) is the cause. The perception aggregate at rebirth-linking is the effect.


<a id="M05-body-P125"></a>
## Tái tục — Hành uẩn, cách thứ nhất / Rebirth-linking — Formations aggregate, first method
Miến / Burmese 125

**VI**
7. Cảnh (cảnh nghiệp) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

**EN**
7. The object (kamma-object) is the cause. The perception aggregate at rebirth-linking is the effect.

**VI**
8. Xúc (34 trừ tưởng, còn 33) là pháp nhân. Tưởng uẩn tái tục là pháp quả.

**EN**
8. Contact (34 minus perception, leaving 33) is the cause. The perception aggregate at rebirth-linking is the effect.

**VI**
Tái tục — Hành uẩn (cách thứ nhất, lấy tư làm chính)

**EN**
Rebirth-linking — Formations aggregate (first method, with volition as primary)

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Hành uẩn là pháp quả.

**EN**
1. Ignorance (20) is the cause. The formations aggregate is the effect.

**VI**
2. Ái (20) là pháp nhân. Hành uẩn là pháp quả.

**EN**
2. Craving (20) is the cause. The formations aggregate is the effect.

**VI**
3. Thủ (20) là pháp nhân. Hành uẩn là pháp quả.

**EN**
3. Clinging (20) is the cause. The formations aggregate is the effect.

**VI**
4. Hành (34) là pháp nhân. Hành uẩn là pháp quả.

**EN**
4. Formations (34) is the cause. The formations aggregate is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Hành uẩn là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The formations aggregate is the effect.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật (3 nhóm, 30 sắc) là pháp nhân. Hành uẩn là pháp quả.

**EN**
6. The base (three groups, 30 kinds of materiality) is the cause. The formations aggregate is the effect.

**VI**
7. Cảnh (cảnh nghiệp) là pháp nhân. Hành uẩn là pháp quả.

**EN**
7. The object (kamma-object) is the cause. The formations aggregate is the effect.

**VI**
8. Xúc (34 trừ tư, còn 33) là pháp nhân. Hành uẩn là pháp quả.

**EN**
8. Contact (34 minus volition, leaving 33) is the cause. The formations aggregate is the effect.

**VI**
Ở đây, cách thứ nhất là cách lấy riêng tư làm chính khi nói đến hành uẩn. Để trình bày đầy đủ các pháp chân đế, xin nêu thêm một cách nữa.

**EN**
Here the first method is the one that takes volition alone as primary in speaking of the formations aggregate. To account fully for the ultimate phenomena, a further method is given.


<a id="M05-body-P126"></a>
## Tái tục — Hành uẩn, cách thứ hai / Rebirth-linking — Formations aggregate, second method
Miến / Burmese 126

**VI**
Tái tục — Hành uẩn (cách thứ hai, kể 31 tâm sở)

**EN**
Rebirth-linking — Formations aggregate (second method, counting 31 mental factors)

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Hành uẩn là pháp quả.

**EN**
1. Ignorance (20) is the cause. The formations aggregate is the effect.

**VI**
2. Ái (20) là pháp nhân. Hành uẩn là pháp quả.

**EN**
2. Craving (20) is the cause. The formations aggregate is the effect.

**VI**
3. Thủ (20) là pháp nhân. Hành uẩn là pháp quả.

**EN**
3. Clinging (20) is the cause. The formations aggregate is the effect.

**VI**
4. Hành (34) là pháp nhân. Hành uẩn là pháp quả.

**EN**
4. Formations (34) is the cause. The formations aggregate is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Hành uẩn là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The formations aggregate is the effect.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật (3 nhóm, 30 sắc) là pháp nhân. Hành uẩn là pháp quả.

**EN**
6. The base (three groups, 30 kinds of materiality) is the cause. The formations aggregate is the effect.

**VI**
7. Cảnh (cảnh nghiệp) là pháp nhân. Hành uẩn là pháp quả.

**EN**
7. The object (kamma-object) is the cause. The formations aggregate is the effect.

**VI**
8. Ba danh uẩn còn lại là pháp nhân. Hành uẩn là pháp quả.

**EN**
8. The other three mental aggregates is the cause. The formations aggregate is the effect.

**VI**
Ghi chú. Trong 34 danh pháp tái tục, trừ thọ, tưởng và thức, còn 31 tâm sở, do xúc và tư dẫn đầu. Theo cách thứ hai này, cả 31 tâm sở đều được gọi là hành uẩn và đứng về phía quả. Khi tìm các nhân hiện tại của hành uẩn do xúc và tư dẫn đầu, theo câu “Sesakkhandhā paccayā” (Visuddhimagga, tập 2, tr. 92), ba danh uẩn còn lại là thọ, tưởng và thức là các nhân. Chúng là các duyên gần nhất. Khi trình bày phép quán theo cách thứ hai này…

**EN**
Note. Of the thirty-four rebirth-linking mental phenomena, apart from feeling, perception, and consciousness, there remain thirty-one mental factors led by contact and volition. In this second method all thirty-one are called the formations aggregate and stand on the side of the effect. In looking for the present causes of the formations aggregate led by contact and volition, according to “Sesakkhandhā paccayā” (Visuddhimagga, vol. 2, p. 92), the other three mental aggregates, feeling, perception, and consciousness, are causes. They are the closest conditions. The discernment is presented in this second way…


<a id="M05-body-P127"></a>
## Tái tục — Thức uẩn / Rebirth-linking — Consciousness aggregate
Miến / Burmese 127

**VI**
…vì có thể hỏi rằng nếu xúc là nhân của các danh uẩn thì chính xúc hoặc nhóm tâm sở còn lại gọi là hành uẩn có nhân hay không. Mục đích là quán cho đầy đủ các pháp nhân và pháp quả. Khi về sau trình bày phép quán hành uẩn theo hai cách, hãy ghi nhớ nguyên tắc tương tự.

**EN**
…because one may ask whether, if contact is a cause of the mental aggregates, contact itself or the remaining group of mental factors called the formations aggregate has causes. The intention is to discern causes and effects in full. Remember the same principle when the discernment of the formations aggregate is presented in two ways later.

**VI**
Tái tục — Thức uẩn

**EN**
Rebirth-linking — Consciousness aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Thức uẩn tái tục là pháp quả.

**EN**
1. Ignorance (20) is the cause. The consciousness aggregate at rebirth-linking is the effect.

**VI**
2. Ái (20) là pháp nhân. Thức uẩn tái tục là pháp quả.

**EN**
2. Craving (20) is the cause. The consciousness aggregate at rebirth-linking is the effect.

**VI**
3. Thủ (20) là pháp nhân. Thức uẩn tái tục là pháp quả.

**EN**
3. Clinging (20) is the cause. The consciousness aggregate at rebirth-linking is the effect.

**VI**
4. Hành (34) là pháp nhân. Thức uẩn tái tục là pháp quả.

**EN**
4. Formations (34) is the cause. The consciousness aggregate at rebirth-linking is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thức uẩn tái tục là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The consciousness aggregate at rebirth-linking is the effect.

**VI**
Một nhân hiện tại

**EN**
One present cause

**VI**
6. Danh và sắc là pháp nhân. Thức uẩn tái tục là pháp quả.

**EN**
6. Mentality and materiality is the cause. The consciousness aggregate at rebirth-linking is the effect.

**VI**
Danh là 33 tâm sở tương ưng. Sắc là sắc vật nương (3 nhóm, 30 sắc) và sắc làm cảnh.

**EN**
Mentality is the thirty-three associated mental factors. Materiality is the supporting material base (three groups, thirty kinds of materiality) and materiality as object.


<a id="M05-body-P128"></a>
## Miến 128 / Burmese page 128
Miến / Burmese 128

**VI**
Ghi chú. “Danh” là nhóm tâm sở tương ưng sinh cùng thức uẩn trong một nhóm tâm. Ở sát-na tái tục này, từ ấy chỉ 33 tâm sở tương ưng sinh cùng thức tái tục. Nếu thiện hữu tái tục với thọ xả, do không tương ưng với hỷ nên có 32 tâm sở được kể là danh pháp. “Sắc” là sắc vật nương và sắc làm cảnh. Trong ba loại cảnh của nhóm danh pháp tái tục là nghiệp, nghiệp tướng và thú tướng, khi cảnh thuộc loại sắc thì sắc làm cảnh là sắc ấy. Khi cảnh là tiếng, sắc làm cảnh là tiếng ấy. Hãy hiểu tương tự trong các trường hợp khác. Lại nữa, có lời dạy “Nāmarūpasamudayā viññāṇasamudayo” (Tương ưng bộ, tập 2, tr. 53), nghĩa là do danh sắc sinh nên thức sinh. Cũng có lời dạy “Viññāṇapaccayā nāmarūpaṃ” (Abhidhamma, tập 2, tr. 142), nghĩa là do thức làm duyên nên danh sắc sinh. Vì vậy, hãy ghi nhớ rằng thức và danh sắc là các pháp trợ lẫn nhau. Hành giả cần dùng tuệ thấy quan hệ nhân quả, thấy thức, tức thức uẩn, sinh do danh sắc, rồi quán các pháp nhân và pháp quả. Qua các lời giải thích này, hãy hiểu rằng các nhân được gọi là “vật, cảnh và xúc” và nhân được gọi là “danh sắc” chỉ khác nhau về cách nói, còn xét theo các pháp chân đế và tự tính thì giống nhau. Phép quán như sau.

**EN**
Note. “Mentality” is the group of associated mental factors that arise with the consciousness aggregate in a single group of consciousness. At this rebirth-linking moment it means the thirty-three associated mental factors arising with rebirth-linking consciousness. If you were reborn with equanimous feeling, there are thirty-two mental factors reckoned as mentality because joy is absent. “Materiality” is the supporting material base and materiality as object. Among the three kinds of object for the rebirth-linking group, namely kamma, a sign of kamma, and a sign of destination, when the object is materiality, that materiality is the material object. When the object is a sound, that sound is the material object. Understand the other cases in the same way. Moreover, the teaching “Nāmarūpasamudayā viññāṇasamudayo” (Saṃyutta Nikāya, vol. 2, p. 53) means that with the arising of mentality and materiality, consciousness arises. There is also the teaching “Viññāṇapaccayā nāmarūpaṃ” (Abhidhamma, vol. 2, p. 142), meaning that with consciousness as condition, mentality and materiality arise. Therefore remember that consciousness and mentality-materiality support one another. See with knowledge the causal relationship in which consciousness, the consciousness aggregate, arises owing to mentality and materiality, then discern the causes and effects. From these explanations understand that the causes called “base, object, and contact” and the cause called “mentality and materiality” differ in wording, but are the same as ultimate phenomena and in their own nature. The discernment is as follows.

**VI**
Do danh sắc sinh nên thức uẩn tái tục sinh. Danh sắc là pháp nhân. Thức uẩn tái tục là pháp quả…

**EN**
With the arising of mentality and materiality, the consciousness aggregate at rebirth-linking arises. Mentality and materiality are the cause. The consciousness aggregate at rebirth-linking is the effect…


<a id="M05-body-P129"></a>
## Năm uẩn hữu phần / The five life-continuum aggregates
Miến / Burmese 129

**VI**
Sau tái tục, hữu phần sinh 15 hoặc 16 lần. Sau những hữu phần ấy, các tâm trong lộ bắt đầu sinh, gồm một tâm hướng ý môn và bảy tốc hành tham có chức năng ưa thích hữu, tức các tốc hành tham đắm đời sống mới. Trong các tâm hữu phần, kể từ hữu phần đầu tiên, sắc do tâm sinh và sắc do thời tiết sinh xuất hiện. Vì sắc do thời tiết sinh bắt đầu từ sát-na trụ của tái tục, nó đương nhiên cũng có trong thời gian này. Sắc do vật thực sinh xuất hiện từ khi thức ăn do người mẹ ăn truyền vào thân của thai nhi. Do đó nếu muốn quán năm uẩn hữu phần ngay sau tái tục theo nhân quả, hãy quán theo phép quán năm uẩn hữu phần sẽ trình bày dưới đây, bỏ sắc do vật thực sinh. Hãy quán tâm hướng ý môn trong lộ tốc hành tham có chức năng ưa thích hữu theo phép quán năm uẩn của tâm hướng ý môn sẽ trình bày sau. Hãy quán năm uẩn trong các tốc hành tham có chức năng ưa thích hữu theo phép quán các tốc hành tham trong lộ ý môn sẽ trình bày sau. Bây giờ sẽ trình bày phép quán năm uẩn hữu phần đang sinh trong dòng tương tục của thiện hữu.

**EN**
After rebirth-linking, life-continuum occurs fifteen or sixteen times. After those moments, process consciousness begins with one mind-door adverting and seven greed impulsions that relish existence, that is, greed impulsions attached to the new life. From the first life-continuum onwards, mind-produced and temperature-produced materiality are present. Since temperature-produced materiality began at the presence moment of rebirth-linking, it is of course present at this time. Nutriment-produced materiality arises from the time the mother's food reaches the body of the embryo. Thus, to discern the five life-continuum aggregates immediately after rebirth-linking in causal relationship, use the discernment of the five life-continuum aggregates to be presented below, leaving out nutriment-produced materiality. Discern mind-door adverting in the greed process that relishes existence according to the discernment of the five aggregates of mind-door adverting presented later. Discern the five aggregates of those greed impulsions according to the discernment of greed impulsions in the mind-door process given later. The discernment of the five life-continuum aggregates now occurring in your continuum is presented next.

**VI**
Năm uẩn hữu phần

**EN**
The five life-continuum aggregates

**VI**
1. Sáu nhóm sắc tại ý vật, chỗ nương của hữu phần hiện tại, gồm 54 sắc pháp, là sắc uẩn. Nếu cảnh của hữu phần là sắc pháp, hãy kể cả sắc pháp ấy.
2. Trong 34 danh pháp hữu phần, thọ gọi là thọ uẩn.

**EN**
1. The six material groups at the heart-base, the support for the present life-continuum, comprise fifty-four material phenomena and are the materiality aggregate. If the life-continuum object is materiality, include that materiality too.
2. Among the thirty-four life-continuum mental phenomena, feeling is called the feeling aggregate.


<a id="M05-body-P130"></a>
## Hữu phần — Sắc uẩn / Life-continuum — Materiality aggregate
Miến / Burmese 130

**VI**
3. Trong 34 danh pháp hữu phần, tưởng gọi là tưởng uẩn.
4. Trong 34 danh pháp hữu phần, tư gọi là hành uẩn theo cách thứ nhất. Theo cách thứ hai, 31 tâm sở còn lại gọi là hành uẩn.
5. Trong 34 danh pháp hữu phần, tâm biết, tức thức, gọi là thức uẩn.

**EN**
3. Among the thirty-four life-continuum mental phenomena, perception is called the perception aggregate.
4. Among the thirty-four life-continuum mental phenomena, volition is called the formations aggregate in the first method. In the second, the thirty-one remaining mental factors are called the formations aggregate.
5. Among the thirty-four life-continuum mental phenomena, cognizing consciousness is called the consciousness aggregate.

**VI**
Hữu phần — Sắc uẩn

**EN**
Life-continuum — Materiality aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Sắc uẩn hữu phần (sắc do nghiệp sinh) là pháp quả.

**EN**
1. Ignorance (20) is the cause. The life-continuum materiality aggregate (kamma-produced materiality) is the effect.

**VI**
2. Ái (20) là pháp nhân. Sắc uẩn hữu phần (sắc do nghiệp sinh) là pháp quả.

**EN**
2. Craving (20) is the cause. The life-continuum materiality aggregate (kamma-produced materiality) is the effect.

**VI**
3. Thủ (20) là pháp nhân. Sắc uẩn hữu phần (sắc do nghiệp sinh) là pháp quả.

**EN**
3. Clinging (20) is the cause. The life-continuum materiality aggregate (kamma-produced materiality) is the effect.

**VI**
4. Hành (34) là pháp nhân. Sắc uẩn hữu phần (sắc do nghiệp sinh) là pháp quả.

**EN**
4. Formations (34) is the cause. The life-continuum materiality aggregate (kamma-produced materiality) is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Sắc uẩn hữu phần (sắc do nghiệp sinh) là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The life-continuum materiality aggregate (kamma-produced materiality) is the effect.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Tâm là pháp nhân. Sắc uẩn hữu phần (sắc do tâm sinh) là pháp quả.

**EN**
6. Consciousness is the cause. The life-continuum materiality aggregate (mind-produced materiality) is the effect.


<a id="M05-body-P131"></a>
## Hữu phần — Thọ uẩn / Life-continuum — Feeling aggregate
Miến / Burmese 131

**VI**
7. Thời tiết là pháp nhân. Sắc uẩn hữu phần (sắc do thời tiết sinh) là pháp quả.

**EN**
7. Temperature is the cause. The life-continuum materiality aggregate (temperature-produced materiality) is the effect.

**VI**
8. Vật thực là pháp nhân. Sắc uẩn hữu phần (sắc do vật thực sinh) là pháp quả.

**EN**
8. Nutriment is the cause. The life-continuum materiality aggregate (nutriment-produced materiality) is the effect.

**VI**
Hữu phần — Thọ uẩn

**EN**
Life-continuum — Feeling aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

**EN**
1. Ignorance (20) is the cause. The life-continuum feeling aggregate is the effect.

**VI**
2. Ái (20) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

**EN**
2. Craving (20) is the cause. The life-continuum feeling aggregate is the effect.

**VI**
3. Thủ (20) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

**EN**
3. Clinging (20) is the cause. The life-continuum feeling aggregate is the effect.

**VI**
4. Hành (34) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

**EN**
4. Formations (34) is the cause. The life-continuum feeling aggregate is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The life-continuum feeling aggregate is the effect.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật (6 nhóm, 54 sắc) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

**EN**
6. The base (six groups, 54 kinds of materiality) is the cause. The life-continuum feeling aggregate is the effect.

**VI**
7. Cảnh (cảnh nghiệp) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

**EN**
7. The object (kamma-object) is the cause. The life-continuum feeling aggregate is the effect.

**VI**
8. Xúc.

**EN**
8. Contact.

**VI**
(a) Ý xúc của hữu phần trước (34) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

**EN**
(a) Mind-contact of the preceding life-continuum (34) is the cause. The life-continuum feeling aggregate is the effect.


<a id="M05-body-P132"></a>
## Hữu phần — Tưởng uẩn và hành uẩn / Life-continuum — Perception and formations aggregates
Miến / Burmese 132

**VI**
(b) Ý xúc của hữu phần sau (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn hữu phần là pháp quả.

**EN**
(b) Mind-contact of the subsequent life-continuum (34 minus feeling, leaving 33) is the cause. The life-continuum feeling aggregate is the effect.

**VI**
Ghi chú. Ý xúc của hữu phần trước (34) thuộc sát-na hữu phần ngay trước hữu phần đang được quán. Đó là nhân theo duyên vô gián. Ý xúc của hữu phần sau thuộc chính hữu phần đang được quán. Khi thọ uẩn đứng về phía quả thì trừ thọ ấy, còn 34 trừ thọ, tức 33. Hãy ghi nhớ tương tự đối với tưởng uẩn hữu phần, v.v.

**EN**
Note. Mind-contact of the preceding life-continuum (34) belongs to the moment of life-continuum immediately before the one being discerned. This is a cause by proximity condition. Mind-contact of the subsequent life-continuum belongs to the very moment of life-continuum being discerned. When the feeling aggregate stands on the side of the effect, exclude that feeling, leaving thirty-four minus feeling, that is, thirty-three. Remember the same principle for the life-continuum perception aggregate and so on.

**VI**
Hữu phần — Tưởng uẩn

**EN**
Life-continuum — Perception aggregate

**VI**
1–7. Hoàn toàn giống như đối với thọ uẩn.
8. Xúc.

**EN**
1–7. Entirely the same as for the feeling aggregate.
8. Contact.

**VI**
(a) Ý xúc của hữu phần trước (34) là pháp nhân. Tưởng uẩn hữu phần là pháp quả.

**EN**
(a) Mind-contact of the preceding life-continuum (34) is the cause. The life-continuum perception aggregate is the effect.

**VI**
(b) Ý xúc của hữu phần sau (34 trừ tưởng, còn 33) là pháp nhân. Tưởng uẩn hữu phần là pháp quả.

**EN**
(b) Mind-contact of the subsequent life-continuum (34 minus perception, leaving 33) is the cause. The life-continuum perception aggregate is the effect.

**VI**
Hữu phần — Hành uẩn (tư, cách thứ nhất)

**EN**
Life-continuum — Formations aggregate (volition, first method)

**VI**
1–7. Hoàn toàn giống như đối với thọ uẩn.
8. Xúc.

**EN**
1–7. Entirely the same as for the feeling aggregate.
8. Contact.

**VI**
(a) Ý xúc của hữu phần trước (34) là pháp nhân. Hành uẩn hữu phần là pháp quả.

**EN**
(a) Mind-contact of the preceding life-continuum (34) is the cause. The life-continuum formations aggregate is the effect.

**VI**
(b) Ý xúc của hữu phần sau (34 trừ tư, còn 33) là pháp nhân. Hành uẩn hữu phần là pháp quả.

**EN**
(b) Mind-contact of the subsequent life-continuum (34 minus volition, leaving 33) is the cause. The life-continuum formations aggregate is the effect.


<a id="M05-body-P133"></a>
## Hữu phần — Hành uẩn và thức uẩn / Life-continuum — Formations and consciousness aggregates
Miến / Burmese 133

**VI**
Hữu phần — Hành uẩn (kể 31 tâm sở, cách thứ hai)

**EN**
Life-continuum — Formations aggregate (counting 31 mental factors, second method)

**VI**
1–7. Hoàn toàn giống như đối với thọ uẩn.
8. Xúc.

**EN**
1–7. Entirely the same as for the feeling aggregate.
8. Contact.

**VI**
(a) Ý xúc của hữu phần trước (34) là pháp nhân. Hành uẩn hữu phần là pháp quả.

**EN**
(a) Mind-contact of the preceding life-continuum (34) is the cause. The life-continuum formations aggregate is the effect.

**VI**
(b) Ba danh uẩn còn lại là pháp nhân. Hành uẩn hữu phần là pháp quả.

**EN**
(b) The other three mental aggregates is the cause. The life-continuum formations aggregate is the effect.

**VI**
Hữu phần — Thức uẩn

**EN**
Life-continuum — Consciousness aggregate

**VI**
1–5. Năm nhân quá khứ giống như đối với thọ uẩn.

**EN**
1–5. The five past causes are the same as for the feeling aggregate.

**VI**
Hai nhân hiện tại

**EN**
Two present causes

**VI**
6. Ý xúc của hữu phần trước (34) là pháp nhân. Thức uẩn hữu phần là pháp quả.

**EN**
6. Mind-contact of the preceding life-continuum (34) is the cause. The life-continuum consciousness aggregate is the effect.

**VI**
7. Danh và sắc là pháp nhân. Thức uẩn hữu phần là pháp quả.

**EN**
7. Mentality and materiality is the cause. The life-continuum consciousness aggregate is the effect.

**VI**
Danh là 33 tâm sở tương ưng. Sắc là sắc vật nương và sắc làm cảnh.

**EN**
Mentality is the thirty-three associated mental factors. Materiality is the supporting material base and materiality as object.

**VI**
Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tâm hướng ngũ môn

**EN**
Visual-object process, that is, the process with colour as object — Five aggregates at five-door adverting

**VI**
1. 54 sắc pháp ở ý vật, chỗ nương của tâm hướng ngũ môn, và cảnh sắc là sắc uẩn.
2. Thọ trong 11 danh pháp của tâm hướng ngũ môn là thọ uẩn.
3. Tưởng trong 11 danh pháp của tâm hướng ngũ môn là tưởng uẩn.

**EN**
1. The fifty-four material phenomena at the heart-base, the support of five-door adverting, and the visual object are the materiality aggregate.
2. Feeling among the eleven mental phenomena of five-door adverting is the feeling aggregate.
3. Perception among the eleven mental phenomena of five-door adverting is the perception aggregate.


<a id="M05-body-P134"></a>
## Hướng ngũ môn — Sắc uẩn / Five-door adverting — Materiality aggregate
Miến / Burmese 134

**VI**
4. Tư trong 11 danh pháp của tâm hướng ngũ môn là hành uẩn theo cách thứ nhất. Tám tâm sở còn lại trong 11 danh pháp của tâm hướng ngũ môn là hành uẩn theo cách thứ hai.
5. Tâm biết, tức thức, trong 11 danh pháp của tâm hướng ngũ môn là thức uẩn.

**EN**
4. Volition among the eleven mental phenomena of five-door adverting is the formations aggregate according to the first method. The eight remaining mental factors among the eleven mental phenomena of five-door adverting are the formations aggregate according to the second method.
5. Cognizing consciousness among the eleven mental phenomena of five-door adverting is the consciousness aggregate.

**VI**
Hướng ngũ môn, tức hướng đến cảnh — Sắc uẩn

**EN**
Five-door adverting, that is, turning to the object — Materiality aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

**EN**
1. Ignorance (20) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

**VI**
2. Ái (20) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

**EN**
2. Craving (20) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

**VI**
3. Thủ (20) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

**EN**
3. Clinging (20) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

**VI**
4. Hành (34) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

**EN**
4. Formations (34) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Tâm là pháp nhân. Sắc uẩn do tâm sinh là pháp quả.

**EN**
6. Consciousness is the cause. The mind-produced materiality aggregate is the effect.

**VI**
7. Thời tiết là pháp nhân. Sắc uẩn do thời tiết sinh là pháp quả.

**EN**
7. Temperature is the cause. The temperature-produced materiality aggregate is the effect.

**VI**
8. Vật thực là pháp nhân. Sắc uẩn do vật thực sinh là pháp quả.

**EN**
8. Nutriment is the cause. The nutriment-produced materiality aggregate is the effect.


<a id="M05-body-P135"></a>
## Hướng ngũ môn — Thọ uẩn và tưởng uẩn / Five-door adverting — Feeling and perception aggregates
Miến / Burmese 135

**VI**
Hướng ngũ môn — Thọ uẩn

**EN**
Five-door adverting — Feeling aggregate

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate of five-door adverting is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
2. The object, the visual object is the cause. The feeling aggregate of five-door adverting is the effect.

**VI**
3. Xúc.

**EN**
3. Contact.

**VI**
(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate of five-door adverting is the effect.

**VI**
(b) Ý xúc của tâm hướng ngũ môn (11 trừ thọ, còn 10) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
(b) Mind-contact of five-door adverting (11 minus feeling, leaving 10) is the cause. The feeling aggregate of five-door adverting is the effect.

**VI**
Hướng ngũ môn — Tưởng uẩn

**EN**
Five-door adverting — Perception aggregate

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Tưởng uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The perception aggregate of five-door adverting is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Tưởng uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
2. The object, the visual object is the cause. The perception aggregate of five-door adverting is the effect.

**VI**
3. Xúc.

**EN**
3. Contact.

**VI**
(a) Ý xúc của hữu phần (34) là pháp nhân. Tưởng uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
(a) Mind-contact of the life-continuum (34) is the cause. The perception aggregate of five-door adverting is the effect.

**VI**
(b) Ý xúc của tâm hướng ngũ môn (11 trừ tưởng, còn 10) là pháp…

**EN**
(b) Mind-contact of five-door adverting (11 minus perception, leaving 10) is the…


<a id="M05-body-P136"></a>
## Hướng ngũ môn — Hành uẩn / Five-door adverting — Formations aggregate
Miến / Burmese 136

**VI**
…nhân. Tưởng uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
…cause. The perception aggregate of five-door adverting is the effect.

**VI**
Hướng ngũ môn — Hành uẩn (tư, cách thứ nhất)

**EN**
Five-door adverting — Formations aggregate (volition, first method)

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The formations aggregate of five-door adverting is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
2. The object, the visual object is the cause. The formations aggregate of five-door adverting is the effect.

**VI**
3. Xúc.

**EN**
3. Contact.

**VI**
(a) Ý xúc của hữu phần (34) là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
(a) Mind-contact of the life-continuum (34) is the cause. The formations aggregate of five-door adverting is the effect.

**VI**
(b) Ý xúc của tâm hướng ngũ môn (11 trừ tư, còn 10) là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
(b) Mind-contact of five-door adverting (11 minus volition, leaving 10) is the cause. The formations aggregate of five-door adverting is the effect.

**VI**
Hướng ngũ môn — Hành uẩn (tám tâm sở, cách thứ hai)

**EN**
Five-door adverting — Formations aggregate (eight mental factors, second method)

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The formations aggregate of five-door adverting is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
2. The object, the visual object is the cause. The formations aggregate of five-door adverting is the effect.

**VI**
3. Xúc.

**EN**
3. Contact.

**VI**
(a) Ý xúc của hữu phần (34) là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
(a) Mind-contact of the life-continuum (34) is the cause. The formations aggregate of five-door adverting is the effect.


<a id="M05-body-P137"></a>
## Hướng ngũ môn — Thức uẩn / Five-door adverting — Consciousness aggregate
Miến / Burmese 137

**VI**
(b) Ba danh uẩn còn lại là pháp nhân. Hành uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
(b) The other three mental aggregates is the cause. The formations aggregate of five-door adverting is the effect.

**VI**
Hướng ngũ môn — Thức uẩn

**EN**
Five-door adverting — Consciousness aggregate

**VI**
Hai nhân hiện tại

**EN**
Two present causes

**VI**
1. Ý xúc của hữu phần (34) là pháp nhân. Thức uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
1. Mind-contact of the life-continuum (34) is the cause. The consciousness aggregate of five-door adverting is the effect.

**VI**
2. Danh và sắc là pháp nhân. Thức uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
2. Mentality and materiality is the cause. The consciousness aggregate of five-door adverting is the effect.

**VI**
Danh là 10 tâm sở tương ưng. Sắc là ý vật (54 sắc) và cảnh sắc.

**EN**
Mentality is the ten associated mental factors. Materiality is the heart-base (54 kinds of materiality) and the visual object.

**VI**
Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở nhãn thức, tức sự thấy

**EN**
Visual-object process, that is, the process with colour as object — Five aggregates at eye-consciousness, that is, seeing

**VI**
1. Nhãn vật (sáu nhóm sắc làm chỗ nương, gồm 54 sắc) và cảnh sắc là sắc uẩn.
2. Thọ trong tám danh pháp nhãn thức là thọ uẩn.
3. Tưởng trong tám danh pháp nhãn thức là tưởng uẩn.
4. Tư trong tám danh pháp nhãn thức là hành uẩn theo cách thứ nhất. Năm tâm sở còn lại trong tám danh pháp nhãn thức là hành uẩn theo cách thứ hai.
5. Tâm biết, tức thức, trong tám danh pháp nhãn thức là thức uẩn.

**EN**
1. The eye-base (six supporting material groups comprising fifty-four material phenomena) and the visual object are the materiality aggregate.
2. Feeling among the eight mental phenomena of eye-consciousness is the feeling aggregate.
3. Perception among the eight mental phenomena of eye-consciousness is the perception aggregate.
4. Volition among the eight mental phenomena of eye-consciousness is the formations aggregate in the first method. The five remaining mental factors among the eight mental phenomena of eye-consciousness are the formations aggregate in the second method.
5. Cognizing consciousness among the eight mental phenomena of eye-consciousness is the consciousness aggregate.


<a id="M05-body-P138"></a>
## Nhãn thức — Sắc uẩn và thọ uẩn / Eye-consciousness — Materiality and feeling aggregates
Miến / Burmese 138

**VI**
Nhãn thức, tức sự thấy — Sắc uẩn

**EN**
Eye-consciousness, that is, seeing — Materiality aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

**EN**
1. Ignorance (20) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

**VI**
2. Ái (20) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

**EN**
2. Craving (20) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

**VI**
3. Thủ (20) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

**EN**
3. Clinging (20) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

**VI**
4. Hành (34) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

**EN**
4. Formations (34) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Sắc uẩn (30 sắc do nghiệp sinh) là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The materiality aggregate (30 kinds of kamma-produced materiality) is the effect.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Tâm là pháp nhân. Sắc uẩn do tâm sinh là pháp quả.

**EN**
6. Consciousness is the cause. The mind-produced materiality aggregate is the effect.

**VI**
7. Thời tiết là pháp nhân. Sắc uẩn do thời tiết sinh là pháp quả.

**EN**
7. Temperature is the cause. The temperature-produced materiality aggregate is the effect.

**VI**
8. Vật thực là pháp nhân. Sắc uẩn do vật thực sinh là pháp quả.

**EN**
8. Nutriment is the cause. The nutriment-produced materiality aggregate is the effect.

**VI**
Nhãn thức, tức sự thấy — Thọ uẩn

**EN**
Eye-consciousness, that is, seeing — Feeling aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

**EN**
1. Ignorance (20) is the cause. The feeling aggregate of eye-consciousness is the effect.

**VI**
2. Ái (20) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

**EN**
2. Craving (20) is the cause. The feeling aggregate of eye-consciousness is the effect.


<a id="M05-body-P139"></a>
## Nhãn thức — Các nhân của thọ uẩn / Eye-consciousness — Causes of the feeling aggregate
Miến / Burmese 139

**VI**
3. Thủ (20) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

**EN**
3. Clinging (20) is the cause. The feeling aggregate of eye-consciousness is the effect.

**VI**
4. Hành (34) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

**EN**
4. Formations (34) is the cause. The feeling aggregate of eye-consciousness is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate of eye-consciousness is the effect.

**VI**
Năm nhân hiện tại

**EN**
Five present causes

**VI**
6. Vật, tức nhãn vật (54 sắc) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

**EN**
6. The base, namely the eye-base (54 kinds of materiality) is the cause. The feeling aggregate of eye-consciousness is the effect.

**VI**
7. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

**EN**
7. The object, namely the visual object is the cause. The feeling aggregate of eye-consciousness is the effect.

**VI**
8. Nhãn xúc (8 trừ thọ, còn 7) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

**EN**
8. Eye-contact (8 minus feeling, leaving 7) is the cause. The feeling aggregate of eye-consciousness is the effect.

**VI**
9. Ánh sáng là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

**EN**
9. Light is the cause. The feeling aggregate of eye-consciousness is the effect.

**VI**
10. Tác ý, tức tâm hướng ngũ môn (11) là pháp nhân. Thọ uẩn của nhãn thức là pháp quả.

**EN**
10. Attention, namely five-door adverting (11) is the cause. The feeling aggregate of eye-consciousness is the effect.

**VI**
Tác ý (manasikāra). Ở đây, tác ý là sự hướng tâm đến cảnh, tức cảnh sắc, và chính là tâm hướng ngũ môn. Các vị luận sư gọi đó là tác ý dẫn đầu lộ tâm (vīthipaṭipādakamanasikāra). (Chú giải Abhidhamma, tập 1, tr. 177.) Đó là nhân căn bản của các tâm trong lộ, hướng đến cảnh để các tâm ấy sinh khởi.

**EN**
Attention (manasikāra). Here attention is the turning of the mind toward the object, namely the visual object, and is precisely five-door adverting. The commentators call it attention that leads the cognitive process (vīthipaṭipādakamanasikāra). (Abhidhamma Commentary, vol. 1, p. 177.) It is a basic cause of process consciousness, attending to the object so that those moments can arise.

**VI**
Ánh sáng (āloka). Ánh sáng gồm (1) ánh trăng, (2) ánh mặt trời, (3) ánh lửa và (4) ánh sáng của tuệ, như được nêu trong…

**EN**
Light (āloka). Light comprises (1) moonlight, (2) sunlight, (3) firelight, and (4) the light of wisdom, as stated in…


<a id="M05-body-P140"></a>
## Nhãn thức — Ánh sáng và tưởng uẩn / Eye-consciousness — Light and the perception aggregate
Miến / Burmese 140

**VI**
…Ābhāsutta thuộc Phẩm Bốn pháp của Chánh tạng và các bài kinh tương tự. Cả bốn loại ánh sáng đều được gọi là ánh sáng ở đây. Khi ngồi nhắm mắt và tác ý đến Pháp như lúc này, ánh sáng của tuệ đặc biệt quan trọng. Nếu không có ánh sáng của tuệ thì không thể thấy các nhóm sắc, màu của các nhóm sắc, các sắc chân đế và các danh pháp chân đế. Khi tuệ minh sát chưa sinh, hoặc khi chưa tác ý đến sự tu tập thiền chỉ và minh sát mạnh mẽ mà chỉ thấy cảnh sắc bằng mắt thịt thông thường, một trong ba thứ ánh sáng là ánh trăng, ánh mặt trời hoặc ánh lửa là nhân của các danh pháp nhãn thức. Chú giải Aṭṭhasālinī nêu bốn nhân của nhãn thức. (Chú giải Abhidhamma, tập 1, tr. 321.) Ở đó không kể thêm nhãn xúc làm nhân. Tuy nhiên, theo lời dạy “Phassasamudayā vedanāsamudayo”, nghĩa là do xúc sinh nên thọ sinh (Tương ưng bộ, tập 2, tr. 49), ở đây kể thêm nhãn xúc và nêu năm nhân hiện tại.

**EN**
…the Ābhāsutta in the canonical Book of Fours and similar discourses. All four kinds are called light here. When sitting with eyes closed and attending to the Dhamma as at present, the light of wisdom is particularly important. Without that light, one cannot see material groups, their colour, ultimate material phenomena, or ultimate mental phenomena. When insight knowledge has not arisen, or when one is not attending to the powerful cultivation of serenity and insight but sees a visible object with the ordinary physical eye, one of the three kinds of light, moonlight, sunlight, or firelight, is a cause of the mental phenomena of eye-consciousness. The Aṭṭhasālinī Commentary gives four causes of eye-consciousness. (Abhidhamma Commentary, vol. 1, p. 321.) It does not include eye-contact as a further cause. In keeping with the teaching “Phassasamudayā vedanāsamudayo,” meaning that with the arising of contact, feeling arises (Saṃyutta Nikāya, vol. 2, p. 49), eye-contact is included here, giving five present causes.

**VI**
Nhãn thức, tức sự thấy — Tưởng uẩn

**EN**
Eye-consciousness, that is, seeing — Perception aggregate

**VI**
1–7, 9–10. Các nhân giống như đối với thọ uẩn.

**EN**
1–7, 9–10. The causes are the same as for the feeling aggregate.

**VI**
8. Nhãn xúc (8 trừ tưởng, còn 7) là pháp nhân. Tưởng uẩn của nhãn thức là pháp quả.

**EN**
8. Eye-contact (8 minus perception, leaving 7) is the cause. The perception aggregate of eye-consciousness is the effect.


<a id="M05-body-P141"></a>
## Nhãn thức — Hành uẩn và thức uẩn / Eye-consciousness — Formations and consciousness aggregates
Miến / Burmese 141

**VI**
Nhãn thức, tức sự thấy — Hành uẩn (tư, cách thứ nhất)

**EN**
Eye-consciousness, that is, seeing — Formations aggregate (volition, first method)

**VI**
1–7, 9–10. Các nhân giống như đối với thọ uẩn.

**EN**
1–7, 9–10. The causes are the same as for the feeling aggregate.

**VI**
8. Nhãn xúc (8 trừ tư, còn 7) là pháp nhân. Hành uẩn của nhãn thức là pháp quả.

**EN**
8. Eye-contact (8 minus volition, leaving 7) is the cause. The formations aggregate of eye-consciousness is the effect.

**VI**
Nhãn thức, tức sự thấy — Hành uẩn (kể năm tâm sở, cách thứ hai)

**EN**
Eye-consciousness, that is, seeing — Formations aggregate (counting five mental factors, second method)

**VI**
1–7, 9–10. Các nhân giống như đối với thọ uẩn.

**EN**
1–7, 9–10. The causes are the same as for the feeling aggregate.

**VI**
8. Ba danh uẩn còn lại là pháp nhân. Hành uẩn của nhãn thức là pháp quả.

**EN**
8. The other three mental aggregates is the cause. The formations aggregate of eye-consciousness is the effect.

**VI**
Nhãn thức, tức sự thấy — Thức uẩn

**EN**
Eye-consciousness, that is, seeing — Consciousness aggregate

**VI**
1–5. Các nhân quá khứ giống như đối với thọ uẩn.

**EN**
1–5. The past causes are the same as for the feeling aggregate.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Danh và sắc là pháp nhân. Thức uẩn của nhãn thức là pháp quả.

**EN**
6. Mentality and materiality is the cause. The consciousness aggregate of eye-consciousness is the effect.

**VI**
7. Ánh sáng là pháp nhân. Thức uẩn của nhãn thức là pháp quả.

**EN**
7. Light is the cause. The consciousness aggregate of eye-consciousness is the effect.

**VI**
8. Tác ý, tức tâm hướng ngũ môn (11) là pháp nhân. Thức uẩn của nhãn thức là pháp quả.

**EN**
8. Attention, namely five-door adverting (11) is the cause. The consciousness aggregate of eye-consciousness is the effect.

**VI**
Danh là bảy tâm sở tương ưng.

**EN**
Mentality is the seven associated mental factors.


<a id="M05-body-P142"></a>
## Năm uẩn ở tâm tiếp thọ / The five aggregates at receiving
Miến / Burmese 142

**VI**
Sắc là sắc vật nương (54 sắc) và cảnh sắc. Trong bảy tâm sở tương ưng có xúc.

**EN**
Materiality is the supporting material base (54 kinds of materiality) and the visual object. Contact is included among the seven associated mental factors.

**VI**
Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tâm tiếp thọ (sampaṭicchana)

**EN**
Visual-object process, that is, the process with colour as object — Five aggregates at receiving (sampaṭicchana)

**VI**
1. 54 sắc pháp gồm sắc ý vật, chỗ nương của tâm tiếp thọ, và các sắc cùng với nó, cùng cảnh sắc, là sắc uẩn.

**EN**
1. The fifty-four material phenomena comprising the heart-base, the support of receiving consciousness, and its accompanying materiality, together with the visual object, are the materiality aggregate.

**VI**
2. Thọ trong 11 danh pháp của tâm tiếp thọ là thọ uẩn.

**EN**
2. Feeling among the 11 mental phenomena at receiving consciousness is the feeling aggregate.

**VI**
3. Tưởng trong 11 danh pháp của tâm tiếp thọ là tưởng uẩn.

**EN**
3. Perception among the 11 mental phenomena at receiving consciousness is the perception aggregate.

**VI**
4. Tư trong 11 danh pháp của tâm tiếp thọ là hành uẩn theo cách thứ nhất. 8 tâm sở còn lại trong 11 danh pháp ấy là hành uẩn theo cách thứ hai.

**EN**
4. Volition among the 11 mental phenomena at receiving consciousness is the formations aggregate in the first method. The 8 remaining mental factors are the formations aggregate in the second method.

**VI**
5. Tâm biết, tức thức, trong 11 danh pháp của tâm tiếp thọ là thức uẩn.

**EN**
5. Cognizing consciousness among the 11 mental phenomena at receiving consciousness is the consciousness aggregate.

**VI**
Hãy quán sắc uẩn của tâm tiếp thọ theo cách quán sắc uẩn của tâm hướng ngũ môn.

**EN**
Discern the materiality aggregate at receiving in the same way as the materiality aggregate at five-door adverting.

**VI**
Tiếp thọ — Thọ uẩn

**EN**
Receiving — Feeling aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

**EN**
1. Ignorance (20) is the cause. The feeling aggregate at receiving is the effect.

**VI**
2. Ái (20) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

**EN**
2. Craving (20) is the cause. The feeling aggregate at receiving is the effect.

**VI**
3. Thủ (20) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

**EN**
3. Clinging (20) is the cause. The feeling aggregate at receiving is the effect.


<a id="M05-body-P143"></a>
## Tiếp thọ — Thọ uẩn, tưởng uẩn và hành uẩn / Receiving — Feeling, perception, and formations aggregates
Miến / Burmese 143

**VI**
4. Hành (34) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

**EN**
4. Formations (34) is the cause. The feeling aggregate at receiving is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at receiving is the effect.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

**EN**
6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at receiving is the effect.

**VI**
7. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

**EN**
7. The object, the visual object is the cause. The feeling aggregate at receiving is the effect.

**VI**
8(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

**EN**
8(a) Eye-contact (8) is the cause. The feeling aggregate at receiving is the effect.

**VI**
(b) Ý xúc của tâm tiếp thọ (10, tức 11 trừ thọ) là pháp nhân. Thọ uẩn của tâm tiếp thọ là pháp quả.

**EN**
(b) Mind-contact at receiving (10, that is, 11 minus feeling) is the cause. The feeling aggregate at receiving is the effect.

**VI**
Tiếp thọ — Tưởng uẩn

**EN**
Receiving — Perception aggregate

**VI**
1–7. Hãy quán tương tự như đối với thọ uẩn.

**EN**
1–7. Discern in the same way as for the feeling aggregate.

**VI**
8(a) Nhãn xúc (8) là pháp nhân. Tưởng uẩn của tâm tiếp thọ là pháp quả.

**EN**
8(a) Eye-contact (8) is the cause. The perception aggregate at receiving is the effect.

**VI**
(b) Ý xúc của tâm tiếp thọ (10, tức 11 trừ tưởng) là pháp nhân. Tưởng uẩn của tâm tiếp thọ là pháp quả.

**EN**
(b) Mind-contact at receiving (10, that is, 11 minus perception) is the cause. The perception aggregate at receiving is the effect.

**VI**
Tiếp thọ — Hành uẩn (tư, cách thứ nhất)

**EN**
Receiving — Formations aggregate (volition, first method)

**VI**
1–7. Hãy quán tương tự như đối với thọ uẩn.

**EN**
1–7. Discern in the same way as for the feeling aggregate.


<a id="M05-body-P144"></a>
## Tiếp thọ — Hành uẩn và thức uẩn / Receiving — Formations and consciousness aggregates
Miến / Burmese 144

**VI**
8(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tâm tiếp thọ là pháp quả.

**EN**
8(a) Eye-contact (8) is the cause. The formations aggregate at receiving is the effect.

**VI**
(b) Ý xúc của tâm tiếp thọ (10, tức 11 trừ tư) là pháp nhân. Hành uẩn của tâm tiếp thọ là pháp quả.

**EN**
(b) Mind-contact at receiving (10, that is, 11 minus volition) is the cause. The formations aggregate at receiving is the effect.

**VI**
Tiếp thọ — Hành uẩn (tám tâm sở, cách thứ hai)

**EN**
Receiving — Formations aggregate (eight mental factors, second method)

**VI**
1–7. Hãy quán tương tự như đối với thọ uẩn.

**EN**
1–7. Discern in the same way as for the feeling aggregate.

**VI**
8(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tâm tiếp thọ là pháp quả.

**EN**
8(a) Eye-contact (8) is the cause. The formations aggregate at receiving is the effect.

**VI**
(b) Ba danh uẩn còn lại là pháp nhân. Hành uẩn của tâm tiếp thọ là pháp quả.

**EN**
(b) The other three mental aggregates is the cause. The formations aggregate at receiving is the effect.

**VI**
Tiếp thọ — Thức uẩn

**EN**
Receiving — Consciousness aggregate

**VI**
1–5. Hãy quán các nhân quá khứ như đối với thọ uẩn.

**EN**
1–5. Discern the past causes as for the feeling aggregate.

**VI**
6. Nhãn xúc (8) là pháp nhân. Thức uẩn của tâm tiếp thọ là pháp quả.

**EN**
6. Eye-contact (8) is the cause. The consciousness aggregate at receiving is the effect.

**VI**
7. Danh và sắc ở tâm tiếp thọ là pháp nhân. Thức uẩn của tâm tiếp thọ là pháp quả.

**EN**
7. Mentality and materiality at receiving is the cause. The consciousness aggregate at receiving is the effect.

**VI**
Danh là mười tâm sở tương ưng với tâm tiếp thọ. Sắc là 54 sắc pháp gồm sắc ý vật và các sắc cùng với nó, cùng cảnh sắc.

**EN**
Mentality is the ten mental factors associated with receiving consciousness. Materiality is the fifty-four material phenomena comprising the heart-base and the materiality accompanying it, together with the visual object.


<a id="M05-body-P145"></a>
## Năm uẩn ở tâm suy đạc / The five aggregates at investigating
Miến / Burmese 145

**VI**
Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tâm suy đạc (santīraṇa)

**EN**
Visual-object process, that is, the process with colour as object — Five aggregates at investigating (santīraṇa)

**VI**
1. 54 sắc pháp gồm sắc ý vật, chỗ nương của tâm suy đạc, và các sắc cùng với nó, cùng cảnh sắc, là sắc uẩn.

**EN**
1. The fifty-four material phenomena comprising the heart-base, the support of investigating consciousness, and its accompanying materiality, together with the visual object, are the materiality aggregate.

**VI**
2. Thọ trong 12 danh pháp của tâm suy đạc là thọ uẩn.

**EN**
2. Feeling among the 12 mental phenomena at investigating consciousness is the feeling aggregate.

**VI**
3. Tưởng trong 12 danh pháp của tâm suy đạc là tưởng uẩn.

**EN**
3. Perception among the 12 mental phenomena at investigating consciousness is the perception aggregate.

**VI**
4. Tư trong 12 danh pháp của tâm suy đạc là hành uẩn theo cách thứ nhất. 9 tâm sở còn lại trong 12 danh pháp ấy là hành uẩn theo cách thứ hai.

**EN**
4. Volition among the 12 mental phenomena at investigating consciousness is the formations aggregate in the first method. The 9 remaining mental factors are the formations aggregate in the second method.

**VI**
5. Tâm biết, tức thức, trong 12 danh pháp của tâm suy đạc là thức uẩn.

**EN**
5. Cognizing consciousness among the 12 mental phenomena at investigating consciousness is the consciousness aggregate.

**VI**
Ghi chú. Tâm suy đạc tương ưng với thọ hỷ có 12 danh pháp và có hỷ. Nếu tương ưng với thọ xả thì có 11 danh pháp và không có hỷ. Nếu tốc hành có hỷ thì tâm suy đạc cũng có thể có hỷ. Hãy quán sắc uẩn của tâm suy đạc theo cách quán sắc uẩn của tâm hướng ngũ môn.

**EN**
Note. Investigating consciousness accompanied by joyful feeling has twelve mental phenomena and includes joy. When accompanied by equanimous feeling it has eleven mental phenomena and does not include joy. When the impulsions have joy, investigating consciousness can also be accompanied by joy. Discern its materiality aggregate as in the case of five-door adverting.

**VI**
Suy đạc — Thọ uẩn

**EN**
Investigating — Feeling aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
1. Ignorance (20) is the cause. The feeling aggregate at investigating is the effect.

**VI**
2. Ái (20) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
2. Craving (20) is the cause. The feeling aggregate at investigating is the effect.

**VI**
3. Thủ (20) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
3. Clinging (20) is the cause. The feeling aggregate at investigating is the effect.


<a id="M05-body-P146"></a>
## Suy đạc — Thọ uẩn và tưởng uẩn / Investigating — Feeling and perception aggregates
Miến / Burmese 146

**VI**
4. Hành (34) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
4. Formations (34) is the cause. The feeling aggregate at investigating is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at investigating is the effect.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at investigating is the effect.

**VI**
7. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
7. The object, the visual object is the cause. The feeling aggregate at investigating is the effect.

**VI**
8(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
8(a) Eye-contact (8) is the cause. The feeling aggregate at investigating is the effect.

**VI**
(b) Ý xúc của tâm tiếp thọ (11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
(b) Mind-contact at receiving (11) is the cause. The feeling aggregate at investigating is the effect.

**VI**
(c) Ý xúc của tâm suy đạc (11, tức 12 trừ thọ) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
(c) Mind-contact at investigating (11, that is, 12 minus feeling) is the cause. The feeling aggregate at investigating is the effect.

**VI**
Suy đạc — Tưởng uẩn

**EN**
Investigating — Perception aggregate

**VI**
1–7. Hoàn toàn giống như đối với thọ uẩn.

**EN**
1–7. Entirely the same as for the feeling aggregate.

**VI**
8(a) Nhãn xúc (8) là pháp nhân. Tưởng uẩn của tâm suy đạc là pháp quả.

**EN**
8(a) Eye-contact (8) is the cause. The perception aggregate at investigating is the effect.

**VI**
(b) Ý xúc của tâm tiếp thọ (11) là pháp nhân. Tưởng uẩn của tâm suy đạc là pháp quả.

**EN**
(b) Mind-contact at receiving (11) is the cause. The perception aggregate at investigating is the effect.


<a id="M05-body-P147"></a>
## Suy đạc — Hành uẩn / Investigating — Formations aggregate
Miến / Burmese 147

**VI**
(c) Ý xúc của tâm suy đạc (11 hoặc 10, tức 12 trừ tưởng còn 11, hoặc 11 trừ tưởng còn 10) là pháp nhân. Tưởng uẩn của tâm suy đạc là pháp quả.

**EN**
(c) Mind-contact at investigating (11 or 10, that is, 12 minus perception leaves 11, or 11 minus perception leaves 10) is the cause. The perception aggregate at investigating is the effect.

**VI**
Suy đạc — Hành uẩn (tư, cách thứ nhất)

**EN**
Investigating — Formations aggregate (volition, first method)

**VI**
1–7. Hoàn toàn giống như đối với thọ uẩn.

**EN**
1–7. Entirely the same as for the feeling aggregate.

**VI**
8(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tâm suy đạc là pháp quả.

**EN**
8(a) Eye-contact (8) is the cause. The formations aggregate at investigating is the effect.

**VI**
(b) Ý xúc của tâm tiếp thọ (11) là pháp nhân. Hành uẩn của tâm suy đạc là pháp quả.

**EN**
(b) Mind-contact at receiving (11) is the cause. The formations aggregate at investigating is the effect.

**VI**
(c) Ý xúc của tâm suy đạc (11 hoặc 10, tức 12 trừ tư còn 11, hoặc 11 trừ tư còn 10) là pháp nhân. Hành uẩn của tâm suy đạc là pháp quả.

**EN**
(c) Mind-contact at investigating (11 or 10, that is, 12 minus volition leaves 11, or 11 minus volition leaves 10) is the cause. The formations aggregate at investigating is the effect.

**VI**
Suy đạc — Hành uẩn (chín hoặc tám tâm sở, cách thứ hai)

**EN**
Investigating — Formations aggregate (nine or eight mental factors, second method)

**VI**
1–7. Hoàn toàn giống như đối với thọ uẩn.

**EN**
1–7. Entirely the same as for the feeling aggregate.

**VI**
8(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tâm suy đạc là pháp quả.

**EN**
8(a) Eye-contact (8) is the cause. The formations aggregate at investigating is the effect.

**VI**
(b) Ý xúc của tâm tiếp thọ (11) là pháp nhân. Hành uẩn của tâm suy đạc là pháp quả.

**EN**
(b) Mind-contact at receiving (11) is the cause. The formations aggregate at investigating is the effect.

**VI**
(c) Ba danh uẩn còn lại là pháp nhân. Hành uẩn của tâm suy đạc là pháp quả.

**EN**
(c) The other three mental aggregates is the cause. The formations aggregate at investigating is the effect.


<a id="M05-body-P148"></a>
## Suy đạc — Thức uẩn và năm uẩn ở tâm xác định / Investigating — Consciousness aggregate and the five aggregates at determining
Miến / Burmese 148

**VI**
Suy đạc — Thức uẩn

**EN**
Investigating — Consciousness aggregate

**VI**
1–5. Hoàn toàn giống như đối với thọ uẩn.

**EN**
1–5. Entirely the same as for the feeling aggregate.

**VI**
6(a) Nhãn xúc (8) là pháp nhân. Thức uẩn của tâm suy đạc là pháp quả.

**EN**
6(a) Eye-contact (8) is the cause. The consciousness aggregate at investigating is the effect.

**VI**
(b) Ý xúc của tâm tiếp thọ (11) là pháp nhân. Thức uẩn của tâm suy đạc là pháp quả.

**EN**
(b) Mind-contact at receiving (11) is the cause. The consciousness aggregate at investigating is the effect.

**VI**
7. Danh và sắc ở tâm suy đạc là pháp nhân. Thức uẩn của tâm suy đạc là pháp quả.

**EN**
7. Mentality and materiality at investigating is the cause. The consciousness aggregate at investigating is the effect.

**VI**
Danh là các tâm sở tương ưng, 11 nếu có thọ hỷ, 10 nếu có thọ xả. Sắc là 54 sắc gồm ý vật và các sắc cùng với nó, cùng cảnh sắc.

**EN**
Mentality consists of the associated mental factors, eleven with joyful feeling or ten with equanimous feeling. Materiality consists of the fifty-four material phenomena including the heart-base and the materiality accompanying it, together with the visual object.

**VI**
Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tâm xác định (voṭṭhapana)

**EN**
Visual-object process, that is, the process with colour as object — Five aggregates at determining (voṭṭhapana)

**VI**
1. 54 sắc pháp gồm sắc ý vật, chỗ nương của tâm xác định, và các sắc cùng với nó, cùng cảnh sắc, là sắc uẩn.

**EN**
1. The fifty-four material phenomena comprising the heart-base, the support of determining consciousness, and its accompanying materiality, together with the visual object, are the materiality aggregate.

**VI**
2. Thọ trong 12 danh pháp của tâm xác định là thọ uẩn.

**EN**
2. Feeling among the 12 mental phenomena at determining consciousness is the feeling aggregate.

**VI**
3. Tưởng trong 12 danh pháp của tâm xác định là tưởng uẩn.

**EN**
3. Perception among the 12 mental phenomena at determining consciousness is the perception aggregate.

**VI**
4. Tư trong 12 danh pháp của tâm xác định là hành uẩn theo cách thứ nhất. 9 tâm sở còn lại trong 12 danh pháp ấy là hành uẩn theo cách thứ hai.

**EN**
4. Volition among the 12 mental phenomena at determining consciousness is the formations aggregate in the first method. The 9 remaining mental factors are the formations aggregate in the second method.

**VI**
5. Tâm biết, tức thức, trong 12 danh pháp của tâm xác định là thức uẩn.

**EN**
5. Cognizing consciousness among the 12 mental phenomena at determining consciousness is the consciousness aggregate.

**VI**
Ghi chú. Hãy quán sắc uẩn của tâm xác định theo cách quán sắc uẩn của tâm hướng ngũ môn. Tâm xác định này chỉ là tâm duy tác (kiriyā)…

**EN**
Note. Discern the materiality aggregate at determining in the same way as the materiality aggregate at five-door adverting. This determining consciousness is solely functional consciousness (kiriyā)…


<a id="M05-body-P149"></a>
## Xác định — Thọ uẩn và tưởng uẩn / Determining — Feeling and perception aggregates
Miến / Burmese 149

**VI**
…và không sinh do các nhân quá khứ. Do đó, cả bốn danh uẩn của tâm xác định không có nhân quá khứ. Chúng chỉ sinh do các nhân hiện tại, nên chỉ có các nhân hiện tại.

**EN**
…and does not arise from past causes. Thus the four mental aggregates at determining have no past causes. They arise only from present causes and therefore have present causes alone.

**VI**
Xác định — Thọ uẩn

**EN**
Determining — Feeling aggregate

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm xác định là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at determining is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tâm xác định là pháp quả.

**EN**
2. The object, the visual object is the cause. The feeling aggregate at determining is the effect.

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tâm xác định là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The feeling aggregate at determining is the effect.

**VI**
(b) Ý xúc của tâm suy đạc (12 hoặc 11) là pháp nhân. Thọ uẩn của tâm xác định là pháp quả.

**EN**
(b) Mind-contact at investigating (12 or 11) is the cause. The feeling aggregate at determining is the effect.

**VI**
(c) Ý xúc của tâm xác định (12 trừ thọ, còn 11) là pháp nhân. Thọ uẩn của tâm xác định là pháp quả.

**EN**
(c) Mind-contact at determining (12 minus feeling, leaving 11) is the cause. The feeling aggregate at determining is the effect.

**VI**
Xác định — Tưởng uẩn

**EN**
Determining — Perception aggregate

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Tưởng uẩn của tâm xác định là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The perception aggregate at determining is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Tưởng uẩn của tâm xác định là pháp quả.

**EN**
2. The object, the visual object is the cause. The perception aggregate at determining is the effect.


<a id="M05-body-P150"></a>
## Xác định — Hành uẩn / Determining — Formations aggregate
Miến / Burmese 150

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Tưởng uẩn của tâm xác định là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The perception aggregate at determining is the effect.

**VI**
(b) Ý xúc của tâm suy đạc (12 hoặc 11) là pháp nhân. Tưởng uẩn của tâm xác định là pháp quả.

**EN**
(b) Mind-contact at investigating (12 or 11) is the cause. The perception aggregate at determining is the effect.

**VI**
(c) Ý xúc của tâm xác định (12 trừ tưởng, còn 11) là pháp nhân. Tưởng uẩn của tâm xác định là pháp quả.

**EN**
(c) Mind-contact at determining (12 minus perception, leaving 11) is the cause. The perception aggregate at determining is the effect.

**VI**
Xác định — Hành uẩn (tư, cách thứ nhất)

**EN**
Determining — Formations aggregate (volition, first method)

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The formations aggregate at determining is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

**EN**
2. The object, the visual object is the cause. The formations aggregate at determining is the effect.

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The formations aggregate at determining is the effect.

**VI**
(b) Ý xúc của tâm suy đạc (12 hoặc 11) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

**EN**
(b) Mind-contact at investigating (12 or 11) is the cause. The formations aggregate at determining is the effect.

**VI**
(c) Ý xúc của tâm xác định (12 trừ tư, còn 11) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

**EN**
(c) Mind-contact at determining (12 minus volition, leaving 11) is the cause. The formations aggregate at determining is the effect.

**VI**
Xác định — Hành uẩn (chín tâm sở, cách thứ hai)

**EN**
Determining — Formations aggregate (nine mental factors, second method)

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The formations aggregate at determining is the effect.


<a id="M05-body-P151"></a>
## Xác định — Thức uẩn và tác ý dẫn đầu tốc hành / Determining — Consciousness aggregate and attention leading to impulsion
Miến / Burmese 151

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

**EN**
2. The object, the visual object is the cause. The formations aggregate at determining is the effect.

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The formations aggregate at determining is the effect.

**VI**
(b) Ý xúc của tâm suy đạc (12 hoặc 11) là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

**EN**
(b) Mind-contact at investigating (12 or 11) is the cause. The formations aggregate at determining is the effect.

**VI**
(c) Ba danh uẩn còn lại là pháp nhân. Hành uẩn của tâm xác định là pháp quả.

**EN**
(c) The other three mental aggregates is the cause. The formations aggregate at determining is the effect.

**VI**
Xác định — Thức uẩn

**EN**
Determining — Consciousness aggregate

**VI**
Hai nhân hiện tại

**EN**
Two present causes

**VI**
1(a) Nhãn xúc (8) là pháp nhân. Thức uẩn của tâm xác định là pháp quả.

**EN**
1(a) Eye-contact (8) is the cause. The consciousness aggregate at determining is the effect.

**VI**
(b) Ý xúc của tâm suy đạc (12 hoặc 11) là pháp nhân. Thức uẩn của tâm xác định là pháp quả.

**EN**
(b) Mind-contact at investigating (12 or 11) is the cause. The consciousness aggregate at determining is the effect.

**VI**
2. Danh và sắc ở tâm xác định là pháp nhân. Thức uẩn của tâm xác định là pháp quả.

**EN**
2. Mentality and materiality at determining is the cause. The consciousness aggregate at determining is the effect.

**VI**
Danh là 11 tâm sở tương ưng với tâm xác định. Sắc là 54 sắc gồm ý vật và các sắc cùng với nó, cùng cảnh sắc.

**EN**
Mentality is the eleven mental factors associated with determining. Materiality is the fifty-four material phenomena including the heart-base and the materiality accompanying it, together with the visual object.

**VI**
Tác ý dẫn đầu tốc hành (javanapaṭipādakamanasikāra)

**EN**
Attention that leads to impulsion (javanapaṭipādakamanasikāra)

**VI**
Nếu tâm xác định này xác định cảnh là khả ái, bất khả ái, v.v., theo cách tác ý sai, tức tác ý không như lý, thì sau tâm xác định ấy các tốc hành bất thiện thích hợp…

**EN**
If determining occurs in relation to the object as desirable, undesirable, and so forth, by mistaken attention, that is, unwise attention, then after that determining the corresponding unwholesome impulsions…


<a id="M05-body-P152"></a>
## Tác ý dẫn đầu tốc hành và năm uẩn ở tốc hành thiện thứ nhất / Attention leading to impulsion and the five aggregates at the first wholesome impulsion
Miến / Burmese 152

**VI**
…sẽ sinh. Tuy nhiên, tâm xác định trong lộ ngũ môn không thật sự tự xác định cảnh là khả ái, bất khả ái, thường, lạc, ngã, đẹp, v.v. Các lộ ý môn trước đó đã nhiều lần xác định cảnh là khả ái, bất khả ái, thường, lạc, ngã, đẹp, v.v. Khi các lộ ngũ môn xuất hiện sau đó, các lộ ý môn trước trợ bằng năng lực của duyên y chỉ mạnh. Do vậy, tâm xác định trong các lộ ngũ môn sau sinh với cách thức như thể xác định cảnh là khả ái, bất khả ái, thường, lạc, ngã, đẹp, v.v. Đó là tác ý không như lý. Do tác ý không như lý làm nhân, các tốc hành bất thiện sinh sau tâm xác định ấy. Mặt khác, nếu tâm xác định sinh theo cách xác định cảnh là cảnh sắc, màu sắc, v.v., đó là tác ý như lý. Sau tâm xác định ấy, các tốc hành thiện sinh. Ở đây cũng hãy ghi nhớ rằng tâm xác định không thể tự mình phán định. Nó sinh như thể đang xác định. Vì vậy, tâm xác định ấy gọi là tác ý dẫn đầu tốc hành, tức sự tác ý đến cảnh làm nhân căn bản cho tốc hành. (Chú giải Abhidhamma, tập 1, tr. 177.) Ở đây sẽ trình bày trước cách quán quan hệ nhân quả trong các tốc hành thiện sinh do tác ý như lý.

**EN**
…will occur. However, determining within a five-door process does not itself actually decide that the object is desirable, undesirable, permanent, pleasant, self, beautiful, and so forth. Earlier mind-door processes have repeatedly determined the object in such terms as desirable, undesirable, permanent, pleasant, self, and beautiful. When five-door processes then occur, the earlier mind-door processes support them by the power of decisive support. Consequently determining in these later five-door processes occurs in a manner as if determining the object to be desirable, undesirable, permanent, pleasant, self, beautiful, and so forth. That is unwise attention. With that unwise attention as a cause, unwholesome impulsions occur after determining. On the other hand, when determining occurs in the manner of determining the object as a visual object, colour, and so forth, this is wise attention. Wholesome impulsions occur after that determining. Here too, remember that determining is incapable of judging on its own. It occurs as if determining. It is therefore called attention that leads to impulsion, attention to the object as a basic cause of impulsion. (Abhidhamma Commentary, vol. 1, p. 177.) The causal discernment of wholesome impulsions that arise from wise attention is presented first.

**VI**
Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tốc hành thiện thứ nhất

**EN**
Visual-object process, that is, the process with colour as object — Five aggregates at the first wholesome impulsion

**VI**
1. 54 sắc pháp gồm sắc ý vật, chỗ nương của tốc hành thiện thứ nhất, và các sắc cùng với nó, cùng cảnh sắc, là sắc uẩn.

**EN**
1. The fifty-four material phenomena comprising the heart-base, the support of the first wholesome impulsion, and its accompanying materiality, together with the visual object, are the materiality aggregate.

**VI**
2. Thọ trong 34 danh pháp của tốc hành thiện thứ nhất là thọ uẩn.

**EN**
2. Feeling among the 34 mental phenomena at the first wholesome impulsion is the feeling aggregate.


<a id="M05-body-P153"></a>
## Tốc hành đại thiện thứ nhất — Thọ uẩn / First great wholesome impulsion — Feeling aggregate
Miến / Burmese 153

**VI**
3. Tưởng trong 34 danh pháp của tốc hành thứ nhất là tưởng uẩn.

**EN**
3. Perception among the 34 mental phenomena at the first impulsion is the perception aggregate.

**VI**
4. Tư trong 34 danh pháp của tốc hành thứ nhất là hành uẩn theo cách thứ nhất. 31 tâm sở còn lại trong 34 danh pháp ấy là hành uẩn theo cách thứ hai.

**EN**
4. Volition among the 34 mental phenomena at the first impulsion is the formations aggregate in the first method. The 31 remaining mental factors are the formations aggregate in the second method.

**VI**
5. Tâm biết, tức thức, trong 34 danh pháp của tốc hành thứ nhất là thức uẩn.

**EN**
5. Cognizing consciousness among the 34 mental phenomena at the first impulsion is the consciousness aggregate.

**VI**
Ghi chú. Hãy quán sắc uẩn của tốc hành thiện thứ nhất nêu trên theo cách quán sắc uẩn của tâm hướng ngũ môn. Các danh pháp tốc hành không sinh do các nhân quá khứ, chỉ sinh do các nhân hiện tại. Vì thế các danh pháp tốc hành không có nhân quá khứ, chỉ có các nhân hiện tại.

**EN**
Note. Discern the materiality aggregate at the first wholesome impulsion in the same way as the materiality aggregate at five-door adverting. Impulsion mental phenomena do not arise from past causes. They arise only from present causes. Thus they have no past causes and have present causes alone.

**VI**
Tốc hành đại thiện thứ nhất — Thọ uẩn

**EN**
First great wholesome impulsion — Feeling aggregate

**VI**
Bốn nhân hiện tại

**EN**
Four present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
2. The object, the visual object is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
(b) Ý xúc của tốc hành thứ nhất (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
(b) Mind-contact at the first impulsion (34 minus feeling, leaving 33) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
4. Wise attention, namely determining (12) is the cause. The feeling aggregate at the first impulsion is the effect.


<a id="M05-body-P154"></a>
## Tốc hành đại thiện thứ nhất — Tưởng uẩn và hành uẩn / First great wholesome impulsion — Perception and formations aggregates
Miến / Burmese 154

**VI**
Tốc hành đại thiện thứ nhất — Tưởng uẩn

**EN**
First great wholesome impulsion — Perception aggregate

**VI**
Bốn nhân hiện tại

**EN**
Four present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Tưởng uẩn của tốc hành thứ nhất là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The perception aggregate at the first impulsion is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Tưởng uẩn của tốc hành thứ nhất là pháp quả.

**EN**
2. The object, the visual object is the cause. The perception aggregate at the first impulsion is the effect.

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Tưởng uẩn của tốc hành thứ nhất là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The perception aggregate at the first impulsion is the effect.

**VI**
(b) Ý xúc của tốc hành thứ nhất (34 trừ tưởng, còn 33) là pháp nhân. Tưởng uẩn của tốc hành thứ nhất là pháp quả.

**EN**
(b) Mind-contact at the first impulsion (34 minus perception, leaving 33) is the cause. The perception aggregate at the first impulsion is the effect.

**VI**
4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Tưởng uẩn của tốc hành thứ nhất là pháp quả.

**EN**
4. Wise attention, namely determining (12) is the cause. The perception aggregate at the first impulsion is the effect.

**VI**
Tốc hành đại thiện thứ nhất — Hành uẩn (tư, cách thứ nhất)

**EN**
First great wholesome impulsion — Formations aggregate (volition, first method)

**VI**
Bốn nhân hiện tại

**EN**
Four present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The formations aggregate at the first impulsion is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

**EN**
2. The object, the visual object is the cause. The formations aggregate at the first impulsion is the effect.

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The formations aggregate at the first impulsion is the effect.

**VI**
(b) Ý xúc của tốc hành thứ nhất (34 trừ tư, còn 33) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

**EN**
(b) Mind-contact at the first impulsion (34 minus volition, leaving 33) is the cause. The formations aggregate at the first impulsion is the effect.


<a id="M05-body-P155"></a>
## Tốc hành đại thiện thứ nhất — Hành uẩn và thức uẩn / First great wholesome impulsion — Formations and consciousness aggregates
Miến / Burmese 155

**VI**
4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

**EN**
4. Wise attention, namely determining (12) is the cause. The formations aggregate at the first impulsion is the effect.

**VI**
Tốc hành đại thiện thứ nhất — Hành uẩn (31 tâm sở, cách thứ hai)

**EN**
First great wholesome impulsion — Formations aggregate (31 mental factors, second method)

**VI**
Bốn nhân hiện tại

**EN**
Four present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The formations aggregate at the first impulsion is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

**EN**
2. The object, the visual object is the cause. The formations aggregate at the first impulsion is the effect.

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The formations aggregate at the first impulsion is the effect.

**VI**
(b) Ba danh uẩn còn lại là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

**EN**
(b) The other three mental aggregates is the cause. The formations aggregate at the first impulsion is the effect.

**VI**
4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Hành uẩn của tốc hành thứ nhất là pháp quả.

**EN**
4. Wise attention, namely determining (12) is the cause. The formations aggregate at the first impulsion is the effect.

**VI**
Tốc hành đại thiện thứ nhất — Thức uẩn

**EN**
First great wholesome impulsion — Consciousness aggregate

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Nhãn xúc (8) là pháp nhân. Thức uẩn của tốc hành thứ nhất là pháp quả.

**EN**
1. Eye-contact (8) is the cause. The consciousness aggregate at the first impulsion is the effect.

**VI**
2. Danh và sắc là pháp nhân. Thức uẩn của tốc hành thứ nhất là pháp quả.

**EN**
2. Mentality and materiality is the cause. The consciousness aggregate at the first impulsion is the effect.

**VI**
3. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Thức uẩn của tốc hành thứ nhất là pháp quả.

**EN**
3. Wise attention, namely determining (12) is the cause. The consciousness aggregate at the first impulsion is the effect.


<a id="M05-body-P156"></a>
## Số danh pháp và duyên vô gián / Counts of mental phenomena and proximity condition
Miến / Burmese 156

**VI**
Danh là 33 tâm sở tương ưng.

**EN**
Mentality consists of the 33 associated mental factors.

**VI**
Sắc là 54 sắc gồm sắc ý vật làm chỗ nương và các sắc đi cùng nó, cùng cảnh sắc.

**EN**
Materiality consists of the 54 material phenomena including the supporting heart-base and its accompanying materiality, together with the visual object.

**VI**
Ghi chú. Nếu tốc hành có thọ xả thì hỷ không tương ưng. Bớt một hỷ trong số 34 kể trên. Nếu trí không tương ưng thì bớt trí. Nếu cả trí lẫn hỷ đều không tương ưng thì bớt cả hai. Hãy ghi nhớ rằng trừ thọ, tưởng và thức, tất cả tâm sở còn lại, dù ít hay nhiều, đều gọi là hành uẩn. Mặt khác, từ tốc hành thứ hai trở đi, Đức Phật dạy trong Paṭṭhāna rằng “Purimā purimā kusalā dhammā pacchimānaṃ pacchimānaṃ kusalānaṃ dhammānaṃ anantarapaccayena paccayo.” (Paṭṭhāna 1, 3.) Vì vậy, mỗi tốc hành trước là nhân vô gián của tốc hành sau. Nói cách khác như sau.

**EN**
Note. If the impulsion has equanimous feeling, joy is absent. Subtract the factor of joy from the 34 given above. If knowledge is absent, subtract knowledge. If neither knowledge nor joy is present, subtract both. Remember that apart from feeling, perception, and consciousness, all the remaining mental factors, whether few or many, are called the formations aggregate. As for the second impulsion onward, the Buddha taught in the Paṭṭhāna, “Purimā purimā kusalā dhammā pacchimānaṃ pacchimānaṃ kusalānaṃ dhammānaṃ anantarapaccayena paccayo.” (Paṭṭhāna 1, 3.) Thus each earlier impulsion is a proximity cause of the next impulsion. It can also be put as follows.

**VI**
Yesaṃ yesaṃ dhammānaṃ anantarā ye ye dhammā uppajjanti cittacetasikā dhammā, te te dhammā tesaṃ tesaṃ dhammānaṃ anantarapaccayena paccayo. (Paṭṭhāna 1, 3.)

**EN**
Yesaṃ yesaṃ dhammānaṃ anantarā ye ye dhammā uppajjanti cittacetasikā dhammā, te te dhammā tesaṃ tesaṃ dhammānaṃ anantarapaccayena paccayo. (Paṭṭhāna 1, 3.)

**VI**
Theo các lời dạy này, mỗi tâm trước là nhân vô gián của tâm sau, tức mỗi nhóm danh pháp trước là nhân vô gián của nhóm danh pháp sau. Hãy thêm nhân vô gián này khi quán tốc hành thứ hai trở đi và các tâm đăng ký. Có thể hỏi liệu tốc hành thứ nhất có nhân vô gián hay không. Có. Tâm xác định là nhân vô gián của tốc hành thứ nhất. Hãy nhớ rằng ở đây tâm xác định đã được nêu dưới tên tác ý như lý.

**EN**
In accordance with these teachings, each earlier consciousness is a proximity cause of the next. In other words, each preceding group of mental phenomena is a proximity cause of the next group. Add this proximity cause when discerning the second impulsion onward and the registration moments. One may ask whether the first impulsion has a proximity cause. It does. Determining is the proximity cause of the first impulsion. Remember that determining has already been given here under the name of wise attention.


<a id="M05-body-P157"></a>
## Tốc hành đại thiện thứ hai — Thọ uẩn / Second great wholesome impulsion — Feeling aggregate
Miến / Burmese 157

**VI**
Ở đây lấy riêng thọ uẩn của tốc hành đại thiện thứ hai để nêu làm mẫu. Hãy dựa vào cách ấy để quán các danh uẩn còn lại và các tốc hành, tâm đăng ký còn lại. Trong mỗi sát-na tâm tốc hành và mỗi sát-na tâm đăng ký, hãy nhớ phân thành năm uẩn mà quán.

**EN**
The feeling aggregate at the second great wholesome impulsion alone is given here as a model. Use this method to discern the other mental aggregates, impulsions, and registration moments. Remember to discern the five aggregates in each impulsion and registration mind-moment.

**VI**
Tốc hành đại thiện thứ hai — Thọ uẩn

**EN**
Second great wholesome impulsion — Feeling aggregate

**VI**
Bốn nhân hiện tại

**EN**
Four present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn là pháp quả.

**EN**
2. The object, the visual object is the cause. The feeling aggregate is the effect.

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The feeling aggregate is the effect.

**VI**
(b) Ý xúc của tốc hành thứ nhất (34) là pháp nhân. Thọ uẩn là pháp quả.

**EN**
(b) Mind-contact at the first impulsion (34) is the cause. The feeling aggregate is the effect.

**VI**
(c) Ý xúc của tốc hành thứ hai (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn là pháp quả.

**EN**
(c) Mind-contact at the second impulsion (34 minus feeling, leaving 33) is the cause. The feeling aggregate is the effect.

**VI**
4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Thọ uẩn là pháp quả.

**EN**
4. Wise attention, namely determining (12) is the cause. The feeling aggregate is the effect.

**VI**
1. Nhân vô gián của tốc hành thứ ba là tốc hành thứ hai.

**EN**
1. The proximity cause of the third impulsion is the second impulsion.

**VI**
2. Nhân vô gián của tốc hành thứ tư là tốc hành thứ ba.

**EN**
2. The proximity cause of the fourth impulsion is the third impulsion.

**VI**
3. Nhân vô gián của tốc hành thứ năm là tốc hành thứ tư.

**EN**
3. The proximity cause of the fifth impulsion is the fourth impulsion.

**VI**
4. Nhân vô gián của tốc hành thứ sáu là tốc hành thứ năm.

**EN**
4. The proximity cause of the sixth impulsion is the fifth impulsion.

**VI**
5. Nhân vô gián của tốc hành thứ bảy là tốc hành thứ sáu.

**EN**
5. The proximity cause of the seventh impulsion is the sixth impulsion.

**VI**
6. Nhân vô gián của tâm đăng ký thứ nhất là tốc hành thứ bảy.

**EN**
6. The proximity cause of the first registration is the seventh impulsion.


<a id="M05-body-P158"></a>
## Năm uẩn ở tâm đăng ký / Five aggregates at registration
Miến / Burmese 158

**VI**
7. Nhân vô gián của tâm đăng ký thứ hai là tâm đăng ký thứ nhất.

**EN**
7. The proximity cause of the second registration is the first registration.

**VI**
Dựa vào những trường hợp như vậy, hãy hiểu mục 3(b) trên đây.

**EN**
With these examples in mind, understand item 3(b) above.

**VI**
Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tâm đăng ký

**EN**
Visual-object process, that is, the process with colour as object — Five aggregates at registration

**VI**
1. 54 sắc pháp gồm sắc ý vật, chỗ nương của tâm đăng ký đại quả, và các sắc cùng với nó, cùng cảnh sắc, là sắc uẩn.

**EN**
1. The fifty-four material phenomena comprising the heart-base, the support of great-resultant registration, and its accompanying materiality, together with the visual object, are the materiality aggregate.

**VI**
2. Thọ trong 34 danh pháp của tâm đăng ký đại quả là thọ uẩn.

**EN**
2. Feeling among the 34 mental phenomena at great-resultant registration is the feeling aggregate.

**VI**
3. Tưởng trong 34 danh pháp của tâm đăng ký đại quả là tưởng uẩn.

**EN**
3. Perception among the 34 mental phenomena at great-resultant registration is the perception aggregate.

**VI**
4. Tư trong 34 danh pháp của tâm đăng ký đại quả là hành uẩn theo cách thứ nhất. 31 tâm sở còn lại trong 34 danh pháp ấy là hành uẩn theo cách thứ hai.

**EN**
4. Volition among the 34 mental phenomena at great-resultant registration is the formations aggregate in the first method. The 31 remaining mental factors are the formations aggregate in the second method.

**VI**
5. Tâm biết, tức thức, trong 34 danh pháp của tâm đăng ký đại quả là thức uẩn.

**EN**
5. Cognizing consciousness among the 34 mental phenomena at great-resultant registration is the consciousness aggregate.

**VI**
Hãy quán sắc uẩn của tâm đăng ký theo cách quán sắc uẩn của tâm hướng ngũ môn.

**EN**
Discern the materiality aggregate at registration in the same way as the materiality aggregate at five-door adverting.

**VI**
Tâm đăng ký đại quả thứ nhất — Thọ uẩn

**EN**
First great-resultant registration — Feeling aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
1. Ignorance (20) is the cause. The feeling aggregate at the first registration is the effect.

**VI**
2. Ái (20) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
2. Craving (20) is the cause. The feeling aggregate at the first registration is the effect.

**VI**
3. Thủ (20) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
3. Clinging (20) is the cause. The feeling aggregate at the first registration is the effect.


<a id="M05-body-P159"></a>
## Tâm đăng ký đại quả thứ nhất — Thọ, tưởng và hành uẩn / First great-resultant registration — Feeling, perception, and formations aggregates
Miến / Burmese 159

**VI**
4. Hành (34) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
4. Formations (34) is the cause. The feeling aggregate at the first registration is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at the first registration is the effect.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the first registration is the effect.

**VI**
7. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
7. The object, the visual object is the cause. The feeling aggregate at the first registration is the effect.

**VI**
8(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
8(a) Eye-contact (8) is the cause. The feeling aggregate at the first registration is the effect.

**VI**
(b) Ý xúc của tâm tốc hành thứ bảy (34) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
(b) Mind-contact at the seventh impulsion (34) is the cause. The feeling aggregate at the first registration is the effect.

**VI**
(c) Ý xúc của tâm đăng ký thứ nhất (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
(c) Mind-contact at the first registration (34 minus feeling, leaving 33) is the cause. The feeling aggregate at the first registration is the effect.

**VI**
Tưởng uẩn của tâm đăng ký thứ nhất. Mục 8(c), ý xúc của tâm đăng ký thứ nhất là 34 trừ tưởng, còn 33.

**EN**
Perception aggregate at the first registration. In item 8(c), mind-contact at the first registration is 34 minus perception, leaving 33.

**VI**
Hành uẩn của tâm đăng ký thứ nhất. Mục 8(c), ý xúc của tâm đăng ký thứ nhất là 34 trừ tư, còn 33. Đây là cách thứ nhất.

**EN**
Formations aggregate at the first registration. In item 8(c), mind-contact at the first registration is 34 minus volition, leaving 33. This is the first method.

**VI**
Hành uẩn của tâm đăng ký thứ nhất. Mục 8(c) là ba danh uẩn còn lại, tức thọ, tưởng và thức. Đây là cách thứ hai.

**EN**
Formations aggregate at the first registration. Item 8(c) is the other three mental aggregates, namely feeling, perception, and consciousness. This is the second method.

**VI**
Chỉ khác ở các điểm này. Hãy quán theo cách đã nêu cho thọ uẩn.

**EN**
These are the only differences. Discern as shown for the feeling aggregate.


<a id="M05-body-P160"></a>
## Tâm đăng ký đại quả thứ nhất — Thức uẩn / First great-resultant registration — Consciousness aggregate
Miến / Burmese 160

**VI**
Tâm đăng ký đại quả thứ nhất — Thức uẩn

**EN**
First great-resultant registration — Consciousness aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
1. Ignorance (20) is the cause. The consciousness aggregate at the first registration is the effect.

**VI**
2. Ái (20) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
2. Craving (20) is the cause. The consciousness aggregate at the first registration is the effect.

**VI**
3. Thủ (20) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
3. Clinging (20) is the cause. The consciousness aggregate at the first registration is the effect.

**VI**
4. Hành (34) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
4. Formations (34) is the cause. The consciousness aggregate at the first registration is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The consciousness aggregate at the first registration is the effect.

**VI**
Hai nhân hiện tại

**EN**
Two present causes

**VI**
6(a) Nhãn xúc (8) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
6(a) Eye-contact (8) is the cause. The consciousness aggregate at the first registration is the effect.

**VI**
(b) Ý xúc của tâm tốc hành thứ bảy (34) là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
(b) Mind-contact at the seventh impulsion (34) is the cause. The consciousness aggregate at the first registration is the effect.

**VI**
7. Danh và sắc ở tâm đăng ký thứ nhất là pháp nhân. Thức uẩn của tâm đăng ký thứ nhất là pháp quả.

**EN**
7. Mentality and materiality at the first registration is the cause. The consciousness aggregate at the first registration is the effect.

**VI**
Danh là 33 tâm sở tương ưng.

**EN**
Mentality consists of the 33 associated mental factors.

**VI**
Sắc là 54 sắc gồm sắc ý vật làm chỗ nương và các sắc đi cùng nó, cùng cảnh sắc.

**EN**
Materiality consists of the 54 material phenomena including the supporting heart-base and its accompanying materiality, together with the visual object.

**VI**
Nếu tâm đăng ký đại quả có thọ xả thì hỷ không tương ưng, có 33 danh pháp. Nếu trí không tương ưng thì do thiếu trí…

**EN**
If great-resultant registration has equanimous feeling, joy is absent and there are 33 mental phenomena. If knowledge is absent, then owing to its absence…


<a id="M05-body-P161"></a>
## Số danh pháp ở tâm đăng ký và lộ ý môn / Counts at registration and the mind-door process
Miến / Burmese 161

**VI**
…có 33 danh pháp. Nếu cả trí lẫn hỷ đều không tương ưng thì có 32 danh pháp. Số danh pháp khác nhau tùy theo thọ hỷ hay thọ xả và tương ưng trí hay ly trí. Trong cách thứ hai về hành uẩn, số tâm sở cũng tăng giảm theo số tâm sở hiện diện. Nếu tâm đăng ký là tâm suy đạc quả thiện vô nhân có thọ hỷ thì có 12 danh pháp. Nếu là tâm suy đạc quả thiện vô nhân có thọ xả thì có 11. Nếu là tâm suy đạc quả bất thiện vô nhân có thọ xả thì cũng có 11. Khi tâm đăng ký là vô nhân, số tâm sở trong hành uẩn chỉ thay đổi ở cách thứ hai. Hãy dựa theo mẫu mà quán. Vì tâm đăng ký thứ nhất là nhân vô gián của tâm đăng ký thứ hai, số danh pháp ở ý xúc trong mục 8(b) có thể thay đổi thích hợp thành 34, 33, 33, 32, 12, 11 hoặc 11. Hãy lưu ý và quán theo mẫu.

**EN**
…there are 33 mental phenomena. If neither knowledge nor joy is present, there are 32. The count varies with joyful or equanimous feeling and association or dissociation with knowledge. Under the second method for the formations aggregate, the number of mental factors increases or decreases according to those present. If registration is rootless wholesome-resultant investigating with joyful feeling, there are 12 mental phenomena. If it is rootless wholesome-resultant investigating with equanimous feeling, there are 11. If it is rootless unwholesome-resultant investigating with equanimous feeling, there are also 11. When registration is rootless, the count of mental factors in the formations aggregate can differ only under the second method. Discern following the model. Since the first registration is the proximity cause of the second registration, the count for mind-contact under item 8(b) can vary as appropriate among 34, 33, 33, 32, 12, 11, and 11. Take care to discern according to the model.

**VI**
Các lộ ý môn lấy cảnh sắc làm đối tượng

**EN**
Mind-door processes taking a visual object

**VI**
Trên đây đã trình bày cách quán quan hệ nhân quả của năm uẩn trong mỗi sát-na tâm của lộ nhãn môn có tốc hành thiện. Hãy dùng chính phương pháp này để quán nhân và quả trong các nhóm danh pháp còn lại của các lộ nhãn môn có tốc hành thiện. Sau lộ nhãn môn, cách một số tâm hữu phần, các lộ ý môn tiếp tục sinh và lấy cùng cảnh sắc làm đối tượng. Hãy quán năm uẩn của hữu phần trong các lộ ấy theo cách đã nêu trước đây…

**EN**
The method of discerning the causal relations of the five aggregates in each mind-moment of an eye-door process with wholesome impulsions has been set out above. Use this same method to discern cause and effect for the remaining mental groups in eye-door processes with wholesome impulsions. After an eye-door process, with intervening life-continuum moments, mind-door processes continue to arise and take the same visual object. Discern the five aggregates of the life-continuum there according to the method given earlier…


<a id="M05-body-P162"></a>
## Hướng ý môn và tốc hành đại thiện thứ nhất / Mind-door adverting and first great wholesome impulsion
Miến / Burmese 162

**VI**
…đối với năm uẩn của hữu phần. Sau đây, thọ uẩn ở tâm hướng ý môn và ở các tốc hành được lấy riêng làm mẫu. Việc phân năm uẩn ở tâm hướng ý môn giống như ở tâm xác định. Cách phân năm uẩn ở các tốc hành và tâm đăng ký cũng giống như cách phân năm uẩn ở các tốc hành và tâm đăng ký của lộ nhãn môn.

**EN**
…for the five aggregates of the life-continuum. The feeling aggregate at mind-door adverting and at the impulsions is presented below as a model. The fivefold analysis of mind-door adverting is the same as at determining. The fivefold analysis of impulsions and registration follows the model used for impulsions and registration in an eye-door process.

**VI**
Hướng ý môn — Thọ uẩn

**EN**
Mind-door adverting — Feeling aggregate

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm hướng ý môn là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at mind-door adverting is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tâm hướng ý môn là pháp quả.

**EN**
2. The object, the visual object is the cause. The feeling aggregate at mind-door adverting is the effect.

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tâm hướng ý môn là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The feeling aggregate at mind-door adverting is the effect.

**VI**
(b) Ý xúc của tâm hữu phần (34) là pháp nhân. Thọ uẩn của tâm hướng ý môn là pháp quả.

**EN**
(b) Mind-contact at the life-continuum (34) is the cause. The feeling aggregate at mind-door adverting is the effect.

**VI**
(c) Ý xúc của tâm hướng ý môn (12 trừ thọ, còn 11) là pháp nhân. Thọ uẩn của tâm hướng ý môn là pháp quả.

**EN**
(c) Mind-contact at mind-door adverting (12 minus feeling, leaving 11) is the cause. The feeling aggregate at mind-door adverting is the effect.

**VI**
Tốc hành đại thiện thứ nhất — Thọ uẩn

**EN**
First great wholesome impulsion — Feeling aggregate

**VI**
Bốn nhân hiện tại

**EN**
Four present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the first impulsion is the effect.


<a id="M05-body-P163"></a>
## Tốc hành đại thiện thứ nhất và thứ hai trong lộ ý môn / First and second great wholesome impulsions in the mind-door process
Miến / Burmese 163

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
2. The object, the visual object is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
(b) Ý xúc của tâm hữu phần (34) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
(b) Mind-contact at the life-continuum (34) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
(c) Ý xúc của tâm tốc hành thứ nhất (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
(c) Mind-contact at the first impulsion (34 minus feeling, leaving 33) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
4. Wise attention, namely determining (12) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
Tốc hành đại thiện thứ hai — Thọ uẩn

**EN**
Second great wholesome impulsion — Feeling aggregate

**VI**
Bốn nhân hiện tại

**EN**
Four present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
2. The object, the visual object is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
(b) Ý xúc của tâm hữu phần (34) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
(b) Mind-contact at the life-continuum (34) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
(c) Ý xúc của tâm tốc hành thứ nhất (34) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
(c) Mind-contact at the first impulsion (34) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
(d) Ý xúc của tốc hành thứ hai (34 trừ thọ, còn 33) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
(d) Mind-contact at the second impulsion (34 minus feeling, leaving 33) is the cause. The feeling aggregate at the second impulsion is the effect.


<a id="M05-body-P164"></a>
## Giải thích về nhãn xúc và ý xúc / Explanation of eye-contact and mind-contact
Miến / Burmese 164

**VI**
4. Tác ý như lý, tức tâm xác định (12) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
4. Wise attention, namely determining (12) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
Hãy dựa vào chính các phương pháp đã trình bày ở trên để quán các uẩn còn lại, cũng như các tốc hành và tâm đăng ký còn lại. Đến đây hẳn đã có thể hiểu cách quán.

**EN**
Use the very methods given above to discern the remaining aggregates and the remaining impulsions and registration moments. By this point the method should be clear.

**VI**
Giải thích về nhãn xúc và ý xúc

**EN**
Explanation of eye-contact and mind-contact

**VI**
Yampidaṃ cakkhusamphassapaccayā uppajjati vedayitaṃ sukhaṃ vā dukkhaṃ vā adukkhamasukhaṃ vā. (Saṃyutta 2, 248.)

**EN**
Yampidaṃ cakkhusamphassapaccayā uppajjati vedayitaṃ sukhaṃ vā dukkhaṃ vā adukkhamasukhaṃ vā. (Saṃyutta 2, 248.)

**VI**
Cakkhusamphassapaccayā uppajjati vedayitanti cakkhusamphassaṃ mūlapaccayaṃ katvā uppannā sampaṭicchana-santīraṇa-voṭṭhabbana-javanavedanā. Cakkhuviññāṇasampayuttāya pana vattabbameva natthi. Sotadvārādivedanāpaccayādīsupi eseva nayo. (Chú giải Saṃyutta 3, 5.)

**EN**
Cakkhusamphassapaccayā uppajjati vedayitanti cakkhusamphassaṃ mūlapaccayaṃ katvā uppannā sampaṭicchana-santīraṇa-voṭṭhabbana-javanavedanā. Cakkhuviññāṇasampayuttāya pana vattabbameva natthi. Sotadvārādivedanāpaccayādīsupi eseva nayo. (Saṃyutta Commentary 3, 5.)

**VI**
Yampidaṃ manosamphassapaccayā uppajjati vedayitaṃ sukhaṃ vā dukkhaṃ vā adukkhamasukhaṃ vā. (Saṃyutta 2, 248.)

**EN**
Yampidaṃ manosamphassapaccayā uppajjati vedayitaṃ sukhaṃ vā dukkhaṃ vā adukkhamasukhaṃ vā. (Saṃyutta 2, 248.)

**VI**
Manosamphassoti bhavaṅgasahajāto samphasso. Vedayitanti javanasahajātā vedanā. Sahāvajjanena bhavaṅgasahajātāpi vaṭṭatiyeva. (Chú giải Saṃyutta 3, 5.)

**EN**
Manosamphassoti bhavaṅgasahajāto samphasso. Vedayitanti javanasahajātā vedanā. Sahāvajjanena bhavaṅgasahajātāpi vaṭṭatiyeva. (Saṃyutta Commentary 3, 5.)

**VI**
Yamidaṃ (yampidaṃ) cakkhusamphassapaccayā uppajjati vedanāgataṃ saññāgataṃ saṅkhāragataṃ viññāṇagataṃ. (Majjhima 3, 325.)

**EN**
Yamidaṃ (yampidaṃ) cakkhusamphassapaccayā uppajjati vedanāgataṃ saññāgataṃ saṅkhāragataṃ viññāṇagataṃ. (Majjhima 3, 325.)

**VI**
Yamidaṃ manosamphassapaccayā uppajjati vedanāgataṃ saññāgataṃ saṅkhāragataṃ viññāṇagataṃ. (Majjhima 3, 326.)

**EN**
Yamidaṃ manosamphassapaccayā uppajjati vedanāgataṃ saññāgataṃ saṅkhāragataṃ viññāṇagataṃ. (Majjhima 3, 326.)

**VI**
Sahāvajjanavedanāya javanavedanā “vedayitan”ti adhippetā.

**EN**
Sahāvajjanavedanāya javanavedanā “vedayitan”ti adhippetā.


<a id="M05-body-P165"></a>
## Nhãn xúc làm duyên cho bốn danh uẩn / Eye-contact conditions the four mental aggregates
Miến / Burmese 165

**VI**
Bhavaṅgasampayuttāya pana vedanāya gahaṇe vattabbameva natthi. (Phụ chú giải Saṃyutta 2, 286.)

**EN**
Bhavaṅgasampayuttāya pana vedanāya gahaṇe vattabbameva natthi. (Saṃyutta Subcommentary 2, 286.)

**VI**
Theo các bản Pāli, chú giải và phụ chú giải nêu trên, thọ ở nhãn thức, tiếp thâu, suy đạc, xác định, tốc hành và đăng ký sinh do nhãn xúc, nên đều là thọ do nhãn xúc làm duyên. Theo Kinh Giáo Giới Rāhula Ngắn (Cūḷarāhulovādasutta), do nhãn xúc không chỉ có thọ sinh, mà “Yamidaṃ cakkhusamphassapaccayā uppajjati vedanāgataṃ saññāgataṃ saṅkhāragataṃ viññāṇagataṃ” (Majjhima 3, 326), cả bốn danh uẩn thọ, tưởng, hành và thức đều sinh. Vì vậy, hãy ghi nhớ rằng nhãn xúc tương ưng với nhãn thức trợ cho từng nhóm bốn danh uẩn ở nhãn thức, tiếp thâu, suy đạc, xác định, tốc hành và đăng ký sinh khởi.

**EN**
According to the Pāli texts, commentaries, and subcommentaries above, feeling at eye-consciousness, receiving, investigating, determining, impulsion, and registration arises on account of eye-contact, and is therefore feeling conditioned by eye-contact. According to the Shorter Discourse of Advice to Rāhula (Cūḷarāhulovādasutta), eye-contact gives rise to more than feeling. “Yamidaṃ cakkhusamphassapaccayā uppajjati vedanāgataṃ saññāgataṃ saṅkhāragataṃ viññāṇagataṃ” (Majjhima 3, 326). All four mental aggregates, feeling, perception, formations, and consciousness, arise. Remember, therefore, that eye-contact associated with eye-consciousness supports the arising of each group of four mental aggregates at eye-consciousness, receiving, investigating, determining, impulsion, and registration.

**VI**
Tuy nhiên, khi giải thích cách nhãn xúc trợ các nhóm danh pháp sinh do nó, chú giải chỉ nêu sự trợ giúp trong cùng một lộ, tức trong lộ nhãn môn. Tuy vậy, có lời Pāli sau đây.

**EN**
When explaining how eye-contact supports the mental groups that arise on account of it, the commentary describes support within the same process, the eye-door process. The following Pāli passage also occurs.

**VI**
“Cakkhusamphassapaccayā vedanākkhandho atthi anupādinno anupādāniyo asaṃkiliṭṭho asaṃkilesiko savitakkasavicāro.”

**EN**
“Cakkhusamphassapaccayā vedanākkhandho atthi anupādinno anupādāniyo asaṃkiliṭṭho asaṃkilesiko savitakkasavicāro.”

**VI**
Dựa vào những lời Pāli như vậy, vị chú giải giải thích rằng không thể bác bỏ sự trợ giúp của nhãn xúc đối với các nhóm danh pháp ở lộ khác, tức ở những lộ tâm khác nhau, kể cả các nhóm danh pháp trong lộ ý môn tiếp tục lấy cảnh sắc làm đối tượng. Vị ấy còn giải thích rằng chú giải trình bày sự trợ giúp của nhãn xúc đối với các nhóm danh pháp trong cùng một lộ nhãn môn vì sự trợ giúp ấy là chắc chắn. (Mūlaṭīkā 2, 30.) Các hành giả…

**EN**
On the basis of such Pāli passages, the commentator explains that the support given by eye-contact to mental groups in other processes cannot be ruled out. This includes the mental groups in a mind-door process that continues to take the visual object. The explanation further states that the commentary describes the support given by eye-contact to the mental groups in the same eye-door process because such support is certain. (Mūlaṭīkā 2, 30.) Practitioners…


<a id="M05-body-P166"></a>
## Ý xúc trong lộ ý môn / Mind-contact in the mind-door process
Miến / Burmese 166

**VI**
…khi khảo sát phần lớn vẫn tán đồng lời giải thích của vị soạn Mūlaṭīkā. Hãy ghi nhớ cách tương tự đối với nhĩ xúc và các xúc khác khi chúng trợ cho các lộ ý môn lấy cùng cảnh thinh của lộ nhĩ môn và các cảnh tương ứng.

**EN**
…in their investigations mostly agree with the explanation given by the author of the Mūlaṭīkā. Remember the corresponding principle for ear-contact and the other contacts when they support mind-door processes taking the same sound as the ear-door process or the corresponding objects at the other doors.

**VI**
Ý xúc là xúc tương ưng với hữu phần rung động liền kề tâm hướng ý môn, đang trợ cho tâm hướng ý môn bằng năng lực duyên vô gián. Ý xúc ấy cũng trợ cho các nhóm danh pháp trong lộ ý môn, gồm hướng ý môn và tốc hành, cùng tâm đăng ký nếu có, sinh khởi. Trong lộ an chỉ, ý xúc ấy vẫn trợ cho sự sinh khởi của tâm hướng ý môn, các tốc hành cận định và các tốc hành an chỉ. Vì vậy, ở các nhóm danh pháp trong lộ ý môn tiếp tục lấy cảnh sắc, bản văn trình bày sự trợ giúp của nhãn xúc, ý xúc của hữu phần và ý xúc tương ưng đồng sinh. Từ tốc hành thứ hai trở đi, còn nêu các nhân ý xúc vô gián như tốc hành thứ nhất.

**EN**
Mind-contact is the contact associated with the vibrating life-continuum immediately preceding mind-door adverting and supporting it by the power of proximity condition. This mind-contact also supports the arising of mental groups in the mind-door process, including mind-door adverting, impulsion, and registration when it occurs. In an absorption process the same mind-contact supports the arising of mind-door adverting, the impulsions of access concentration, and the absorption impulsions. Thus, for mental groups in mind-door processes that continue to take a visual object, the support of eye-contact, life-continuum mind-contact, and associated conascent mind-contact has been set out. From the second impulsion onward, proximity causes involving mind-contact, such as the first impulsion, have also been included.

**VI**
Vì vậy, thiện hữu hãy dùng trí thấy rõ sự trợ giúp của nhãn xúc, ý xúc vô gián và ý xúc đồng sinh tương ưng đối với các danh uẩn liên hệ trong các nhóm danh pháp ở lộ nhãn môn. Hãy cũng thấy rõ sự trợ giúp của nhãn xúc, ý xúc của hữu phần, ý xúc vô gián và ý xúc đồng sinh tương ưng trong các nhóm danh pháp ở lộ ý môn tiếp tục lấy chính cảnh sắc ấy. Hãy dùng trí thấy rõ mối quan hệ giữa các pháp nhân và pháp quả rồi quán các pháp nhân và pháp quả ấy. Ở đây, đối với các lộ nhãn môn và ý môn có tốc hành thiện lấy cảnh sắc…

**EN**
Therefore, good friend, see clearly with knowledge how eye-contact, proximity mind-contact, and associated conascent mind-contact support the relevant mental aggregates in the eye-door groups. Also see how eye-contact, life-continuum mind-contact, proximity mind-contact, and associated conascent mind-contact support the mental groups at the mind door that continue to take that very visual object. See clearly with knowledge the relationship between cause and effect, and discern the causes and effects. Here, for eye-door and mind-door processes with wholesome impulsions that take a visual object…


<a id="M05-body-P167"></a>
## Năm uẩn ở tốc hành tham hợp tà kiến / Five aggregates at greed-rooted impulsion associated with wrong view
Miến / Burmese 167

**VI**
…phần trình bày cách quán nhân và quả theo năm uẩn trong từng sát-na tâm dừng tại đây. Sau đây sẽ trình bày tiếp cách quán nhân và quả theo năm uẩn trong mỗi sát-na của các lộ nhãn môn và ý môn có tốc hành bất thiện cũng lấy chính cảnh sắc ấy.

**EN**
…the presentation of how to discern cause and effect by way of the five aggregates in each mind-moment stops here. Next comes the discernment of cause and effect by way of the five aggregates in each mind-moment of eye-door and mind-door processes with unwholesome impulsions taking the very same visual object.

**VI**
Trong các lộ nhãn môn và ý môn có tốc hành bất thiện sinh khi lấy cảnh sắc, hướng ngũ môn, nhãn thức, tiếp thâu, suy đạc, xác định, đăng ký, hữu phần, hướng ý môn và đăng ký đều theo mẫu quán của lộ có tốc hành thiện. Chỉ ở các tốc hành có một vài khác biệt, nên ở đây lấy nhóm tham hợp tà kiến gồm 20 danh pháp làm mẫu. Cũng như các nhóm danh pháp tốc hành thiện, các nhóm danh pháp tốc hành bất thiện không có nhân quá khứ, chỉ có nhân hiện tại.

**EN**
In eye-door and mind-door processes with unwholesome impulsions that arise taking a visual object, five-door adverting, eye-consciousness, receiving, investigating, determining, registration, life-continuum, mind-door adverting, and registration follow the discernment model for processes with wholesome impulsions. Only the impulsions differ somewhat, so the group of 20 greed-associated mental phenomena with wrong view is given as the model. Like the wholesome impulsion groups, the unwholesome impulsion groups have only present causes and have no past causes.

**VI**
Lộ cảnh sắc, tức cảnh màu — Năm uẩn ở tốc hành tham hợp tà kiến

**EN**
Visual-object process, that is, the process with colour as object — Five aggregates at greed-rooted impulsion associated with wrong view

**VI**
1. 54 sắc pháp gồm sắc ý vật, chỗ nương của tốc hành tham hợp tà kiến, và các sắc cùng với nó, cùng cảnh sắc, là sắc uẩn.

**EN**
1. The fifty-four material phenomena comprising the heart-base, the support of greed-rooted impulsion associated with wrong view, and its accompanying materiality, together with the visual object, are the materiality aggregate.

**VI**
2. Thọ trong 20 danh pháp của tốc hành tham hợp tà kiến là thọ uẩn.

**EN**
2. Feeling among the 20 mental phenomena at greed-rooted impulsion associated with wrong view is the feeling aggregate.

**VI**
3. Tưởng trong 20 danh pháp của tốc hành tham hợp tà kiến là tưởng uẩn.

**EN**
3. Perception among the 20 mental phenomena at greed-rooted impulsion associated with wrong view is the perception aggregate.

**VI**
4. Tư trong 20 danh pháp của tốc hành tham hợp tà kiến là hành uẩn theo cách thứ nhất. 17 tâm sở còn lại trong 20 danh pháp ấy là hành uẩn theo cách thứ hai.

**EN**
4. Volition among the 20 mental phenomena at greed-rooted impulsion associated with wrong view is the formations aggregate in the first method. The 17 remaining mental factors are the formations aggregate in the second method.


<a id="M05-body-P168"></a>
## Tốc hành tham hợp tà kiến thứ nhất — Thọ uẩn và thức uẩn / First greed-rooted impulsion associated with wrong view — Feeling and consciousness aggregates
Miến / Burmese 168

**VI**
5. Tâm biết, tức thức, trong 20 danh pháp của tốc hành tham hợp tà kiến là thức uẩn.

**EN**
5. Cognizing consciousness among the 20 mental phenomena at greed-rooted impulsion associated with wrong view is the consciousness aggregate.

**VI**
Hãy quán sắc uẩn của tốc hành theo cách quán sắc uẩn của tâm hướng ngũ môn.

**EN**
Discern the materiality aggregate at impulsion in the same way as the materiality aggregate at five-door adverting.

**VI**
Tốc hành tham hợp tà kiến thứ nhất — Thọ uẩn (lộ nhãn môn)

**EN**
First greed-rooted impulsion associated with wrong view — Feeling aggregate (eye-door process)

**VI**
Bốn nhân hiện tại

**EN**
Four present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
2. The object, the visual object is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
(b) Ý xúc của tốc hành thứ nhất (20 trừ thọ, còn 19) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
(b) Mind-contact at the first impulsion (20 minus feeling, leaving 19) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
4. Tác ý không như lý, tức tâm xác định (12) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
4. Unwise attention, namely determining (12) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
Tốc hành tham hợp tà kiến thứ nhất — Thức uẩn (lộ nhãn môn)

**EN**
First greed-rooted impulsion associated with wrong view — Consciousness aggregate (eye-door process)

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Nhãn xúc (8) là pháp nhân. Thức uẩn của tốc hành thứ nhất là pháp quả.

**EN**
1. Eye-contact (8) is the cause. The consciousness aggregate at the first impulsion is the effect.

**VI**
2. Danh và sắc là pháp nhân. Thức uẩn của tốc hành thứ nhất là pháp quả.

**EN**
2. Mentality and materiality is the cause. The consciousness aggregate at the first impulsion is the effect.

**VI**
3. Tác ý không như lý, tức tâm xác định (12), là pháp nhân…

**EN**
3. Unwise attention, namely determining (12), is the cause…


<a id="M05-body-P169"></a>
## Tốc hành tham hợp tà kiến thứ hai / Second greed-rooted impulsion associated with wrong view
Miến / Burmese 169

**VI**
…thức uẩn của tốc hành thứ nhất là pháp quả.

**EN**
…the consciousness aggregate at the first impulsion is the effect.

**VI**
Danh là 19 tâm sở tương ưng.

**EN**
Mentality consists of the 19 associated mental factors.

**VI**
Sắc là 54 sắc gồm sắc ý vật và các sắc đi cùng nó, cùng cảnh sắc.

**EN**
Materiality consists of the 54 material phenomena including the heart-base and its accompanying materiality, together with the visual object.

**VI**
Tốc hành tham hợp tà kiến thứ hai — Thọ uẩn (lộ nhãn môn)

**EN**
Second greed-rooted impulsion associated with wrong view — Feeling aggregate (eye-door process)

**VI**
Bốn nhân hiện tại

**EN**
Four present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
2. Cảnh, tức cảnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
2. The object, the visual object is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
3(a) Nhãn xúc (8) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
3(a) Eye-contact (8) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
(b) Ý xúc của tâm tốc hành thứ nhất (20) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
(b) Mind-contact at the first impulsion (20) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
(c) Ý xúc của tâm tốc hành thứ hai (20 trừ thọ, còn 19) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
(c) Mind-contact at the second impulsion (20 minus feeling, leaving 19) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
4. Tác ý không như lý, tức tâm xác định (12) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
4. Unwise attention, namely determining (12) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
Tốc hành tham hợp tà kiến thứ hai — Thức uẩn (lộ nhãn môn)

**EN**
Second greed-rooted impulsion associated with wrong view — Consciousness aggregate (eye-door process)

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1(a) Nhãn xúc (8) là pháp nhân. Thức uẩn của tốc hành thứ hai là pháp quả.

**EN**
1(a) Eye-contact (8) is the cause. The consciousness aggregate at the second impulsion is the effect.

**VI**
(b) Ý xúc của tốc hành thứ nhất (20) là pháp nhân…

**EN**
(b) Mind-contact at the first impulsion (20) is the cause…


<a id="M05-body-P170"></a>
## Thức uẩn và lưu ý khi chuyển sang cảnh khác / Consciousness aggregate and a note on changing objects
Miến / Burmese 170

**VI**
…thức uẩn của tốc hành thứ hai là pháp quả.

**EN**
…the consciousness aggregate at the second impulsion is the effect.

**VI**
2. Danh và sắc là pháp nhân. Thức uẩn của tốc hành thứ hai là pháp quả.

**EN**
2. Mentality and materiality is the cause. The consciousness aggregate at the second impulsion is the effect.

**VI**
3. Tác ý không như lý, tức tâm xác định (12) là pháp nhân. Thức uẩn của tốc hành thứ hai là pháp quả.

**EN**
3. Unwise attention, namely determining (12) is the cause. The consciousness aggregate at the second impulsion is the effect.

**VI**
Danh là 19 tâm sở tương ưng.

**EN**
Mentality consists of the 19 associated mental factors.

**VI**
Sắc là 54 sắc gồm sắc ý vật và các sắc đi cùng nó, cùng cảnh sắc.

**EN**
Materiality consists of the 54 material phenomena including the heart-base and its accompanying materiality, together with the visual object.

**VI**
Điểm cần lưu ý

**EN**
A point to note

**VI**
Với những mẫu trên, có thể hiểu cách quán các pháp nhân và pháp quả theo năm uẩn trong từng sát-na tâm của các lộ nhãn môn và ý môn có tốc hành bất thiện lấy cảnh sắc. Khi đã hiểu cách quán các pháp nhân và pháp quả theo năm uẩn trong từng sát-na của các lộ tốc hành thiện và bất thiện lấy cảnh sắc, hãy chuyển sang quán cảnh thinh và các cảnh khác. Ở mỗi sát-na tâm, hãy hiểu rõ số tâm sở tăng hay giảm tùy theo có nhiều hay ít tâm sở tương ưng. Hãy lưu ý rằng số tâm sở tương ưng trong một sát-na tâm làm thay đổi cả hành uẩn lẫn ý xúc đồng sinh. Nếu thiện hữu còn yếu về căn bản Abhidhamma hoặc chưa từng học phần căn bản ấy, cần nhờ thầy hướng dẫn. Vì vậy, ở đây chỉ trình bày một số điểm khác nhau.

**EN**
These models suffice to understand how to discern causes and effects by way of the five aggregates in each mind-moment of eye-door and mind-door processes with unwholesome impulsions taking a visual object. Once the discernment of causes and effects by way of the five aggregates in each moment of both wholesome and unwholesome processes taking a visual object is clear, move on to sound and the other objects. Understand how the count in each mind-moment rises or falls with the number of associated mental factors. Note that this variation in associated mental factors within a single mind-moment affects both the formations aggregate and conascent mind-contact. If, good friend, your grounding in Abhidhamma is weak or you have never studied its basics, you will need a teacher’s help. Hence only a few differences are presented here.


<a id="M05-body-P171"></a>
## Cảnh thinh và những điểm thay đổi theo cảnh / Sound and the differences according to object
Miến / Burmese 171

**VI**
Một số điểm thay đổi

**EN**
Some differences

**VI**
2. Trong lộ cảnh thinh, cảnh sắc được thay bằng cảnh thinh và nhãn xúc được thay bằng nhĩ xúc.

**EN**
2. In the sound-object process, sound replaces the visual object and ear-contact replaces eye-contact.

**VI**
3. Trong lộ cảnh hương, cảnh là cảnh hương và xúc là tỷ xúc.

**EN**
3. In the odour-object process, the object is odour and the contact is nose-contact.

**VI**
4. Trong lộ cảnh vị, cảnh là cảnh vị và xúc là thiệt xúc.

**EN**
4. In the taste-object process, the object is taste and the contact is tongue-contact.

**VI**
5. Trong lộ cảnh xúc, cảnh là cảnh xúc và xúc là thân xúc.

**EN**
5. In the tangible-object process, the object is a tangible object and the contact is body-contact.

**VI**
Lộ cảnh thinh, tức âm thanh — Hướng ngũ môn — Thọ uẩn

**EN**
Sound-object process — Five-door adverting — Feeling aggregate

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
2. Cảnh, tức cảnh thinh là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
2. The object, sound is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
(b) Ý xúc của tâm hướng ngũ môn (11 trừ thọ, còn 10) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
(b) Mind-contact at five-door adverting (11 minus feeling, leaving 10) is the cause. The feeling aggregate at five-door adverting is the effect.


<a id="M05-body-P172"></a>
## Cảnh thinh — Thọ uẩn của nhĩ thức / Sound — Feeling aggregate at ear-consciousness
Miến / Burmese 172

**VI**
Đến đây hẳn có thể hiểu các danh uẩn còn lại. Từ đây chỉ nêu mẫu một hoặc hai uẩn trong một sát-na tâm. Khi thực hành, hãy quán đầy đủ cả năm uẩn trong từng sát-na tâm.

**EN**
By now the remaining mental aggregates should be clear. From here on, only one or two aggregates in a mind-moment are illustrated. In practice, discern all five aggregates fully in each mind-moment.

**VI**
Lộ cảnh thinh, tức âm thanh — Thọ uẩn của nhĩ thức, tức tâm nghe

**EN**
Sound-object process — Feeling aggregate at ear-consciousness, the consciousness that hears

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

**EN**
1. Ignorance (20) is the cause. The feeling aggregate at ear-consciousness is the effect.

**VI**
2. Ái (20) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

**EN**
2. Craving (20) is the cause. The feeling aggregate at ear-consciousness is the effect.

**VI**
3. Thủ (20) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

**EN**
3. Clinging (20) is the cause. The feeling aggregate at ear-consciousness is the effect.

**VI**
4. Hành (34) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

**EN**
4. Formations (34) is the cause. The feeling aggregate at ear-consciousness is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at ear-consciousness is the effect.

**VI**
Năm nhân hiện tại

**EN**
Five present causes

**VI**
6. Vật, tức sắc nhĩ vật (54) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

**EN**
6. The base, the ear-base materiality (54) is the cause. The feeling aggregate at ear-consciousness is the effect.

**VI**
7. Cảnh, tức cảnh thinh là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

**EN**
7. The object, sound is the cause. The feeling aggregate at ear-consciousness is the effect.

**VI**
8. Nhĩ xúc (8 trừ thọ, còn 7) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

**EN**
8. Ear-contact (8 minus feeling, leaving 7) is the cause. The feeling aggregate at ear-consciousness is the effect.


<a id="M05-body-P173"></a>
## Giới hư không và hành uẩn của tâm tiếp thâu / Space element and formations aggregate at receiving
Miến / Burmese 173

**VI**
9. Giới hư không, tức khoảng trống ở giữa là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

**EN**
9. The space element, the intervening opening is the cause. The feeling aggregate at ear-consciousness is the effect.

**VI**
10. Tác ý, tức tâm hướng ngũ môn (11) là pháp nhân. Thọ uẩn của nhĩ thức là pháp quả.

**EN**
10. Attention, namely five-door adverting (11) is the cause. The feeling aggregate at ear-consciousness is the effect.

**VI**
Giới hư không (ākāsadhātu). Giữa nhĩ tịnh sắc và cảnh thinh phải có một khoảng trống. Nhĩ thức chỉ có thể sinh khi nương giới hư không ấy. Thiếu giới hư không, nhĩ thức không thể sinh. Thật vậy, nơi người bịt lỗ tai hoặc có lỗ tai bị bịt, nhĩ thức không thể sinh. Vì vậy, giới hư không là một trong các nhân cho nhóm danh pháp nhĩ thức sinh khởi. (Chú giải Abhidhamma 2, 322.)

**EN**
The space element (ākāsadhātu). There must be an opening between ear-sensitivity and the sound object. Ear-consciousness can arise only in dependence on that space element. Without it, ear-consciousness cannot arise. Indeed, ear-consciousness cannot arise in someone who plugs the ear opening or whose ear opening has been plugged. Thus the space element is among the causes for the arising of the ear-consciousness mental group. (Abhidhamma Commentary 2, 322.)

**VI**
Lộ cảnh thinh — Tiếp thâu — Hành uẩn (cách thứ hai)

**EN**
Sound-object process — Receiving — Formations aggregate (second method)

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

**EN**
1. Ignorance (20) is the cause. The formations aggregate at receiving is the effect.

**VI**
2. Ái (20) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

**EN**
2. Craving (20) is the cause. The formations aggregate at receiving is the effect.

**VI**
3. Thủ (20) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

**EN**
3. Clinging (20) is the cause. The formations aggregate at receiving is the effect.

**VI**
4. Hành (34) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

**EN**
4. Formations (34) is the cause. The formations aggregate at receiving is the effect.


<a id="M05-body-P174"></a>
## Cảnh thinh — Hành uẩn và thức uẩn của tâm tiếp thâu / Sound — Formations and consciousness aggregates at receiving
Miến / Burmese 174

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The formations aggregate at receiving is the effect.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật, tức sắc ý vật (54) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

**EN**
6. The base, the heart-base materiality (54) is the cause. The formations aggregate at receiving is the effect.

**VI**
7. Cảnh, tức cảnh thinh là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

**EN**
7. The object, sound is the cause. The formations aggregate at receiving is the effect.

**VI**
8(a) Nhĩ xúc (8) là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

**EN**
8(a) Ear-contact (8) is the cause. The formations aggregate at receiving is the effect.

**VI**
(b) Ba danh uẩn còn lại là pháp nhân. Hành uẩn của tâm tiếp thâu là pháp quả.

**EN**
(b) The other three mental aggregates is the cause. The formations aggregate at receiving is the effect.

**VI**
Lộ cảnh thinh — Tiếp thâu — Thức uẩn

**EN**
Sound-object process — Receiving — Consciousness aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.

**EN**
1. Ignorance (20) is the cause. The consciousness aggregate at receiving is the effect.

**VI**
2. Ái (20) là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.

**EN**
2. Craving (20) is the cause. The consciousness aggregate at receiving is the effect.

**VI**
3. Thủ (20) là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.

**EN**
3. Clinging (20) is the cause. The consciousness aggregate at receiving is the effect.

**VI**
4. Hành (34) là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.

**EN**
4. Formations (34) is the cause. The consciousness aggregate at receiving is the effect.


<a id="M05-body-P175"></a>
## Cảnh thinh — Thức uẩn của tâm tiếp thâu và thọ uẩn của tâm suy đạc / Sound — Consciousness aggregate at receiving and feeling aggregate at investigating
Miến / Burmese 175

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The consciousness aggregate at receiving is the effect.

**VI**
Hai nhân hiện tại

**EN**
Two present causes

**VI**
6. Nhĩ xúc (8) là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.

**EN**
6. Ear-contact (8) is the cause. The consciousness aggregate at receiving is the effect.

**VI**
7. Danh và sắc là pháp nhân. Thức uẩn của tâm tiếp thâu là pháp quả.

**EN**
7. Mentality and materiality is the cause. The consciousness aggregate at receiving is the effect.

**VI**
Danh là 10 tâm sở tương ưng.

**EN**
Mentality consists of the 10 associated mental factors.

**VI**
Sắc là 54 sắc gồm sắc ý vật và các sắc đi cùng nó, cùng cảnh thinh.

**EN**
Materiality consists of the 54 material phenomena including the heart-base and its accompanying materiality, together with the sound object.

**VI**
Lộ cảnh thinh — Suy đạc — Thọ uẩn

**EN**
Sound-object process — Investigating — Feeling aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
1. Ignorance (20) is the cause. The feeling aggregate at investigating is the effect.

**VI**
2. Ái (20) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
2. Craving (20) is the cause. The feeling aggregate at investigating is the effect.

**VI**
3. Thủ (20) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
3. Clinging (20) is the cause. The feeling aggregate at investigating is the effect.

**VI**
4. Hành (34) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
4. Formations (34) is the cause. The feeling aggregate at investigating is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at investigating is the effect.


<a id="M05-body-P176"></a>
## Từ cảnh thinh sang cảnh hương / From sound to odour
Miến / Burmese 176

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at investigating is the effect.

**VI**
7. Cảnh, tức cảnh thinh là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
7. The object, sound is the cause. The feeling aggregate at investigating is the effect.

**VI**
8(a) Nhĩ xúc (8) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
8(a) Ear-contact (8) is the cause. The feeling aggregate at investigating is the effect.

**VI**
(b) Ý xúc của tâm tiếp thâu (11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
(b) Mind-contact at receiving (11) is the cause. The feeling aggregate at investigating is the effect.

**VI**
(c) Ý xúc của tâm suy đạc (12 trừ thọ, còn 11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
(c) Mind-contact at investigating (12 minus feeling, leaving 11) is the cause. The feeling aggregate at investigating is the effect.

**VI**
Ở đây chỉ nêu mẫu đủ để hiểu. Với các mẫu trên, có thể hiểu cách quán cảnh thinh. Sau đây, ở lộ cảnh hương cũng chỉ nêu mẫu cách quán các pháp nhân và pháp quả theo năm uẩn trong từng sát-na tâm.

**EN**
Only enough examples to make the method clear are given here. These models should suffice for the sound-object process. Next, for the odour-object process, only examples are given of discerning causes and effects by way of the five aggregates in each mind-moment.

**VI**
Lộ cảnh hương, tức mùi — Hướng ngũ môn — Thọ uẩn

**EN**
Odour-object process — Five-door adverting — Feeling aggregate

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
2. Cảnh, tức cảnh hương là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
2. The object, odour is the cause. The feeling aggregate at five-door adverting is the effect.


<a id="M05-body-P177"></a>
## Cảnh hương — Thọ uẩn của tỷ thức / Odour — Feeling aggregate at nose-consciousness
Miến / Burmese 177

**VI**
3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
(b) Ý xúc của tâm hướng ngũ môn (10, tức 11 trừ thọ, còn 10) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
(b) Mind-contact at five-door adverting (10, that is, 11 minus feeling, leaving 10) is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
Lộ cảnh hương, tức mùi — Tỷ thức — Thọ uẩn

**EN**
Odour-object process — Nose-consciousness — Feeling aggregate

**VI**
Năm nhân quá khứ

**EN**
Five past causes

**VI**
1. Vô minh (20) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

**EN**
1. Ignorance (20) is the cause. The feeling aggregate at nose-consciousness is the effect.

**VI**
2. Ái (20) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

**EN**
2. Craving (20) is the cause. The feeling aggregate at nose-consciousness is the effect.

**VI**
3. Thủ (20) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

**EN**
3. Clinging (20) is the cause. The feeling aggregate at nose-consciousness is the effect.

**VI**
4. Hành (34) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

**EN**
4. Formations (34) is the cause. The feeling aggregate at nose-consciousness is the effect.

**VI**
5. Nghiệp, tức năng lực nghiệp của hành (34) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

**EN**
5. Kamma, the kammic potency of formations (34) is the cause. The feeling aggregate at nose-consciousness is the effect.

**VI**
Năm nhân hiện tại

**EN**
Five present causes

**VI**
6. Vật, tức sắc tỷ vật (54) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

**EN**
6. The base, the nose-base materiality (54) is the cause. The feeling aggregate at nose-consciousness is the effect.

**VI**
7. Cảnh, tức cảnh hương là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

**EN**
7. The object, odour is the cause. The feeling aggregate at nose-consciousness is the effect.


<a id="M05-body-P178"></a>
## Giới gió và tâm tiếp thâu trong lộ cảnh hương / Wind element and receiving in the odour-object process
Miến / Burmese 178

**VI**
8. Tỷ xúc (8 trừ thọ, còn 7) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

**EN**
8. Nose-contact (8 minus feeling, leaving 7) is the cause. The feeling aggregate at nose-consciousness is the effect.

**VI**
9. Giới gió là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

**EN**
9. The wind element is the cause. The feeling aggregate at nose-consciousness is the effect.

**VI**
10. Tác ý, tức tâm hướng ngũ môn (11) là pháp nhân. Thọ uẩn của tỷ thức là pháp quả.

**EN**
10. Attention, namely five-door adverting (11) is the cause. The feeling aggregate at nose-consciousness is the effect.

**VI**
Giới gió (vāyodhātu). Chỉ khi luồng gió có khả năng mang mùi, tức giới gió, đi vào khoang mũi, nơi có tỷ tịnh sắc, thì nhóm danh pháp cùng với tỷ thức mới có thể sinh và biết cùng một cảnh hương. Khi luồng gió mang mùi ấy, tức giới gió, vắng mặt, nhóm danh pháp tỷ thức cùng các pháp tương ưng không thể sinh. Vì vậy, giới gió là một nhân.

**EN**
The wind element (vāyodhātu). Only when the air capable of carrying an odour, the wind element, enters the nasal cavity where nose-sensitivity is located can the mental group together with nose-consciousness arise and cognize the same odour object. In the absence of that odour-bearing air, the wind element, the nose-consciousness mental group with its associated phenomena cannot arise. Hence the wind element is a cause.

**VI**
Lộ cảnh hương, tức mùi — Tiếp thâu — Thọ uẩn

**EN**
Odour-object process — Receiving — Feeling aggregate

**VI**
1–5. Quán năm nhân quá khứ theo cùng mẫu.

**EN**
1–5. Discern the five past causes following the same model.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

**EN**
6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at receiving is the effect.

**VI**
7. Cảnh, tức cảnh hương là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

**EN**
7. The object, odour is the cause. The feeling aggregate at receiving is the effect.

**VI**
8(a) Tỷ xúc (8) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

**EN**
8(a) Nose-contact (8) is the cause. The feeling aggregate at receiving is the effect.


<a id="M05-body-P179"></a>
## Cảnh hương — Thọ uẩn của tâm suy đạc / Odour — Feeling aggregate at investigating
Miến / Burmese 179

**VI**
(b) Ý xúc của tâm tiếp thâu (10, tức 11 trừ thọ, còn 10) là pháp nhân.

**EN**
(b) Mind-contact at receiving (10, that is, 11 minus feeling, leaving 10) is the cause.

**VI**
Lộ cảnh hương, tức mùi — Suy đạc — Thọ uẩn

**EN**
Odour-object process — Investigating — Feeling aggregate

**VI**
1–5. Quán năm nhân quá khứ theo cùng mẫu.

**EN**
1–5. Discern the five past causes following the same model.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at investigating is the effect.

**VI**
7. Cảnh, tức cảnh hương là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
7. The object, odour is the cause. The feeling aggregate at investigating is the effect.

**VI**
8(a) Tỷ xúc (8) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
8(a) Nose-contact (8) is the cause. The feeling aggregate at investigating is the effect.

**VI**
(b) Ý xúc của tâm tiếp thâu (11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
(b) Mind-contact at receiving (11) is the cause. The feeling aggregate at investigating is the effect.

**VI**
(c) Ý xúc của tâm suy đạc (11, tức 12 trừ thọ, còn 11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
(c) Mind-contact at investigating (11, that is, 12 minus feeling, leaving 11) is the cause. The feeling aggregate at investigating is the effect.

**VI**
Điểm đặc biệt cần ghi nhớ. Trong các nhân hiện tại của thức uẩn ở tỷ thức, tiếp thâu, suy đạc và các tâm khác, khi nhân được gọi là danh và sắc, về danh hãy lấy nhóm tâm sở tương ưng đồng sinh trong cùng một sát-na với thức uẩn tương ứng. Về sắc hãy lấy sắc vật làm chỗ nương và cảnh hương. Đối với các lộ còn lại cũng hãy lấy các tâm sở tương ưng, sắc vật làm chỗ nương và sắc cảnh tương ứng.

**EN**
A particular point to remember. Among the present causes of the consciousness aggregates at nose-consciousness, receiving, investigating, and the other moments, where the cause is called mentality and materiality, take mentality as the associated mental factors arising together with the corresponding consciousness aggregate in the same mind-moment. Take materiality as the supporting base materiality and the odour object. In the other processes, likewise take the appropriate associated mental factors, supporting base materiality, and material object.


<a id="M05-body-P180"></a>
## Cảnh vị — Thọ uẩn của tâm hướng ngũ môn và thiệt thức / Taste — Feeling aggregate at five-door adverting and tongue-consciousness
Miến / Burmese 180

**VI**
Lộ cảnh vị — Hướng ngũ môn — Thọ uẩn

**EN**
Taste-object process — Five-door adverting — Feeling aggregate

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
2. Cảnh, tức cảnh vị là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
2. The object, taste is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
(b) Ý xúc của tâm hướng ngũ môn (10, tức 11 trừ thọ, còn 10) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
(b) Mind-contact at five-door adverting (10, that is, 11 minus feeling, leaving 10) is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
Lộ cảnh vị — Thiệt thức — Thọ uẩn

**EN**
Taste-object process — Tongue-consciousness — Feeling aggregate

**VI**
1–5. Quán năm nhân quá khứ theo cùng mẫu.

**EN**
1–5. Discern the five past causes following the same model.

**VI**
Năm nhân hiện tại

**EN**
Five present causes

**VI**
6. Vật, tức sắc thiệt vật (54) là pháp nhân. Thọ uẩn của thiệt thức là pháp quả.

**EN**
6. The base, the tongue-base materiality (54) is the cause. The feeling aggregate at tongue-consciousness is the effect.

**VI**
7. Cảnh, tức cảnh vị là pháp nhân. Thọ uẩn của thiệt thức là pháp quả.

**EN**
7. The object, taste is the cause. The feeling aggregate at tongue-consciousness is the effect.

**VI**
8. Thiệt xúc (8 trừ thọ, còn 7) là pháp nhân. Thọ uẩn của thiệt thức là pháp quả.

**EN**
8. Tongue-contact (8 minus feeling, leaving 7) is the cause. The feeling aggregate at tongue-consciousness is the effect.

**VI**
9. Giới nước là pháp nhân. Thọ uẩn của thiệt thức là pháp quả.

**EN**
9. The water element is the cause. The feeling aggregate at tongue-consciousness is the effect.


<a id="M05-body-P181"></a>
## Giới nước và tâm tiếp thâu trong lộ cảnh vị / Water element and receiving in the taste-object process
Miến / Burmese 181

**VI**
10. Tác ý, tức tâm hướng ngũ môn (11) là pháp nhân. Thọ uẩn của thiệt thức là pháp quả.

**EN**
10. Attention, namely five-door adverting (11) is the cause. The feeling aggregate at tongue-consciousness is the effect.

**VI**
Giới nước (āpodhātu). Chỉ khi có chất lỏng thuộc giới nước làm ướt lưỡi thì nhóm pháp gồm thiệt thức và các pháp tương ưng mới có thể sinh. Thiếu chất lỏng ấy thì nhóm pháp này không thể sinh. Ngay cả khi đặt thức ăn khô có thể nhai lên lưỡi của người có lưỡi khô, thiệt thức vẫn không sinh. (Chú giải Abhidhamma 1, 322.)

**EN**
The water element (āpodhātu). The group of phenomena comprising tongue-consciousness and its associated factors can arise only when there is fluid of the water element to moisten the tongue. Without that fluid the group cannot arise. Even when dry food that can be chewed is placed on the tongue of a person whose tongue is dry, tongue-consciousness does not arise. (Abhidhamma Commentary 1, 322.)

**VI**
Trong các nhân hiện tại của thức uẩn ở thiệt thức và các tâm tiếp theo, về danh hãy lấy các tâm sở tương ưng thích hợp. Về sắc hãy lấy sắc vật làm chỗ nương và cảnh vị tương ứng.

**EN**
Among the present causes of the consciousness aggregates at tongue-consciousness and the subsequent moments, take mentality as the corresponding associated mental factors and materiality as the corresponding supporting base materiality and the taste object.

**VI**
Lộ cảnh vị — Tiếp thâu — Thọ uẩn

**EN**
Taste-object process — Receiving — Feeling aggregate

**VI**
1–5. Quán năm nhân quá khứ theo cùng mẫu.

**EN**
1–5. Discern the five past causes following the same model.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

**EN**
6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at receiving is the effect.

**VI**
7. Cảnh, tức cảnh vị là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

**EN**
7. The object, taste is the cause. The feeling aggregate at receiving is the effect.

**VI**
8(a) Thiệt xúc (8) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

**EN**
8(a) Tongue-contact (8) is the cause. The feeling aggregate at receiving is the effect.

**VI**
(b) Ý xúc của tâm tiếp thâu (10, tức 11 trừ thọ, còn 10) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

**EN**
(b) Mind-contact at receiving (10, that is, 11 minus feeling, leaving 10) is the cause. The feeling aggregate at receiving is the effect.


<a id="M05-body-P182"></a>
## Cảnh vị và cảnh xúc — Thọ uẩn / Taste and tangible objects — Feeling aggregate
Miến / Burmese 182

**VI**
Lộ cảnh vị — Suy đạc — Thọ uẩn

**EN**
Taste-object process — Investigating — Feeling aggregate

**VI**
1–5. Quán năm nhân quá khứ theo cùng mẫu.

**EN**
1–5. Discern the five past causes following the same model.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at investigating is the effect.

**VI**
7. Cảnh, tức cảnh vị là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
7. The object, taste is the cause. The feeling aggregate at investigating is the effect.

**VI**
8(a) Thiệt xúc (8) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
8(a) Tongue-contact (8) is the cause. The feeling aggregate at investigating is the effect.

**VI**
(b) Ý xúc của tâm tiếp thâu (11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
(b) Mind-contact at receiving (11) is the cause. The feeling aggregate at investigating is the effect.

**VI**
(c) Ý xúc của tâm suy đạc (11, tức 12 trừ thọ, còn 11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
(c) Mind-contact at investigating (11, that is, 12 minus feeling, leaving 11) is the cause. The feeling aggregate at investigating is the effect.

**VI**
Lộ cảnh xúc — Hướng ngũ môn — Thọ uẩn

**EN**
Tangible objects-object process — Five-door adverting — Feeling aggregate

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
2. Cảnh, tức cảnh xúc là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
2. The object, the tangible object is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
(b) Ý xúc của tâm hướng ngũ môn (10, tức 11 trừ thọ, còn 10)…

**EN**
(b) Mind-contact at five-door adverting (10, that is, 11 minus feeling, leaving 10)…


<a id="M05-body-P183"></a>
## Cảnh xúc — Thọ uẩn của thân thức và giới đất / Tangible objects — Feeling aggregate at body-consciousness and the earth element
Miến / Burmese 183

**VI**
…là pháp nhân. Thọ uẩn của tâm hướng ngũ môn là pháp quả.

**EN**
…is the cause. The feeling aggregate at five-door adverting is the effect.

**VI**
Lộ cảnh xúc — Thân thức — Thọ uẩn

**EN**
Tangible objects-object process — Body-consciousness — Feeling aggregate

**VI**
1–5. Quán năm nhân quá khứ theo cùng mẫu.

**EN**
1–5. Discern the five past causes following the same model.

**VI**
Năm nhân hiện tại

**EN**
Five present causes

**VI**
6. Vật, tức sắc thân vật (44) là pháp nhân. Thọ uẩn của thân thức là pháp quả.

**EN**
6. The base, the body-base materiality (44) is the cause. The feeling aggregate at body-consciousness is the effect.

**VI**
7. Cảnh, tức cảnh xúc là pháp nhân. Thọ uẩn của thân thức là pháp quả.

**EN**
7. The object, the tangible object is the cause. The feeling aggregate at body-consciousness is the effect.

**VI**
8. Thân xúc (8 trừ thọ, còn 7) là pháp nhân. Thọ uẩn của thân thức là pháp quả.

**EN**
8. Body-contact (8 minus feeling, leaving 7) is the cause. The feeling aggregate at body-consciousness is the effect.

**VI**
9. Giới đất là pháp nhân. Thọ uẩn của thân thức là pháp quả.

**EN**
9. The earth element is the cause. The feeling aggregate at body-consciousness is the effect.

**VI**
10. Tác ý, tức tâm hướng ngũ môn (11) là pháp nhân. Thọ uẩn của thân thức là pháp quả.

**EN**
10. Attention, namely five-door adverting (11) is the cause. The feeling aggregate at body-consciousness is the effect.

**VI**
Giới đất (paṭhavīdhātu). Khi cảnh xúc đập trực tiếp vào thân tịnh sắc, tức sắc trong sáng của thân, nó tác động không những vào thân tịnh sắc mà còn vào các đại chủng cùng nhóm sắc làm duyên y chỉ cho thân tịnh sắc. Trong các đại chủng ấy, giới đất là nhân chính của thân tịnh sắc. Nhóm danh pháp thân thức chỉ có thể sinh khi nắm bắt được giới đất là nhân gốc của thân tịnh sắc. Thiếu giới đất ấy, nhóm danh pháp thân thức không thể sinh. Thật vậy…

**EN**
The earth element (paṭhavīdhātu). When a tangible object strikes body-sensitivity, the transparent materiality of the body, it impacts both body-sensitivity and the great elements in the same cluster that serve as a support condition for body-sensitivity. Among those great elements, the earth element is the main cause of body-sensitivity. The body-consciousness mental group can arise only when it apprehends the earth element that is the root cause of body-sensitivity. Without that earth element it cannot arise. Indeed…


<a id="M05-body-P184"></a>
## Cảnh xúc — Giới đất và tâm tiếp thâu / Tangible objects — The earth element and receiving
Miến / Burmese 184

**VI**
…ở thân môn, các đại chủng bên ngoài gọi là cảnh xúc, tức đất, lửa và gió bên ngoài, trước hết đập thẳng vào thân tịnh sắc bên trong. Do va chạm ấy, chúng cũng tác động vào các đại chủng cùng nhóm sắc làm chỗ nương và làm nhân cho thân tịnh sắc. Vì vậy, giới đất là một nhân gốc cho nhóm danh pháp thân thức sinh khởi. (Chú giải Abhidhamma 1, 322.)

**EN**
…at the body door, the external great elements called a tangible object, namely external earth, fire, and wind, strike internal body-sensitivity directly. Through that impact they also affect the great elements in the same cluster that support and serve as a cause for body-sensitivity. Hence the earth element is a root cause for the arising of the body-consciousness mental group. (Abhidhamma Commentary 1, 322.)

**VI**
Trong các nhân hiện tại của thức uẩn ở thân thức, đối với nhân gọi là danh và sắc, về danh hãy lấy cả bảy tâm sở tương ưng với thân thức. Về sắc hãy lấy 44 sắc gồm sắc thân vật và các sắc đi cùng nó, cùng các sắc cảnh là đất, lửa và gió, gọi là cảnh xúc.

**EN**
Among the present causes of the consciousness aggregate at body-consciousness, for the cause termed mentality and materiality, take mentality as all seven mental factors associated with body-consciousness. Take materiality as the 44 material phenomena including the body-base and its accompanying materiality, together with the material objects earth, fire, and wind, termed a tangible object.

**VI**
Lộ cảnh xúc — Tiếp thâu — Thọ uẩn

**EN**
Tangible objects-object process — Receiving — Feeling aggregate

**VI**
1–5. Quán năm nhân quá khứ theo cùng mẫu.

**EN**
1–5. Discern the five past causes following the same model.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

**EN**
6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at receiving is the effect.

**VI**
7. Cảnh, tức cảnh xúc là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

**EN**
7. The object, the tangible object is the cause. The feeling aggregate at receiving is the effect.

**VI**
8(a) Thân xúc (8) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

**EN**
8(a) Body-contact (8) is the cause. The feeling aggregate at receiving is the effect.

**VI**
(b) Ý xúc của tâm tiếp thâu (10, tức 11 trừ thọ, còn 10) là pháp nhân. Thọ uẩn của tâm tiếp thâu là pháp quả.

**EN**
(b) Mind-contact at receiving (10, that is, 11 minus feeling, leaving 10) is the cause. The feeling aggregate at receiving is the effect.


<a id="M05-body-P185"></a>
## Cảnh xúc và cảnh pháp — Thọ uẩn / Tangible and mental objects — Feeling aggregate
Miến / Burmese 185

**VI**
Lộ cảnh xúc — Suy đạc — Thọ uẩn

**EN**
Tangible objects-object process — Investigating — Feeling aggregate

**VI**
1–5. Quán năm nhân quá khứ theo cùng mẫu.

**EN**
1–5. Discern the five past causes following the same model.

**VI**
Ba nhân hiện tại

**EN**
Three present causes

**VI**
6. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
6. The base, the heart-base materiality (54) is the cause. The feeling aggregate at investigating is the effect.

**VI**
7. Cảnh, tức cảnh xúc là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
7. The object, the tangible object is the cause. The feeling aggregate at investigating is the effect.

**VI**
8(a) Thân xúc (8) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
8(a) Body-contact (8) is the cause. The feeling aggregate at investigating is the effect.

**VI**
(b) Ý xúc của tâm tiếp thâu (11) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
(b) Mind-contact at receiving (11) is the cause. The feeling aggregate at investigating is the effect.

**VI**
(c) Ý xúc của tâm suy đạc (11 hoặc 10, tức 12 trừ thọ còn 11, hoặc 11 trừ thọ còn 10) là pháp nhân. Thọ uẩn của tâm suy đạc là pháp quả.

**EN**
(c) Mind-contact at investigating (11 or 10, that is, 12 minus feeling leaving 11, or 11 minus feeling leaving 10) is the cause. The feeling aggregate at investigating is the effect.

**VI**
Lộ cảnh pháp — Lộ tốc hành thiện lấy nhãn tịnh sắc làm cảnh

**EN**
Mental-object process — Wholesome impulsion process with eye-sensitivity as object

**VI**
Tốc hành thứ nhất — Thọ uẩn (lộ ý môn)

**EN**
First impulsion — Feeling aggregate (mind-door process)

**VI**
Bốn nhân hiện tại

**EN**
Four present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
2. Cảnh, tức cảnh pháp, tức nhãn tịnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
2. The object, eye-sensitivity is the cause. The feeling aggregate at the first impulsion is the effect.


<a id="M05-body-P186"></a>
## Cảnh pháp — Thọ uẩn của tốc hành thứ nhất và thứ hai / Mental objects — Feeling aggregate at the first and second impulsions
Miến / Burmese 186

**VI**
3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
(b) Ý xúc của tốc hành thứ nhất (33 (34 trừ thọ, còn 33)) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
(b) Mind-contact at the first impulsion (33 (34 minus feeling, leaving 33)) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
4. Tác ý như lý, tức tâm hướng ý môn (12) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
4. Wise attention, namely mind-door adverting (12) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
Tốc hành thứ hai — Thọ uẩn

**EN**
Second impulsion — Feeling aggregate

**VI**
Bốn nhân hiện tại

**EN**
Four present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
2. Cảnh, tức cảnh pháp, tức nhãn tịnh sắc là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
2. The object, eye-sensitivity is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
(b) Ý xúc của tốc hành thứ nhất (34) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
(b) Mind-contact at the first impulsion (34) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
(c) Ý xúc của tốc hành thứ hai (33 (34 trừ thọ, còn 33)) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
(c) Mind-contact at the second impulsion (33 (34 minus feeling, leaving 33)) is the cause. The feeling aggregate at the second impulsion is the effect.

**VI**
4. Tác ý như lý, tức tâm hướng ý môn (12) là pháp nhân. Thọ uẩn của tốc hành thứ hai là pháp quả.

**EN**
4. Wise attention, namely mind-door adverting (12) is the cause. The feeling aggregate at the second impulsion is the effect.


<a id="M05-body-P187"></a>
## Lộ chứng sơ thiền với tợ tướng hơi thở / First-jhāna attainment process with the breath counterpart sign
Miến / Burmese 187

**VI**
Lộ cảnh pháp — Lộ chứng sơ thiền (lấy tợ tướng hơi thở làm cảnh)

**EN**
Mental-object process — First-jhāna attainment process (taking the breath counterpart sign as object)

**VI**
Tốc hành thứ nhất — Thọ uẩn

**EN**
First impulsion — Feeling aggregate

**VI**
Bốn nhân hiện tại

**EN**
Four present causes

**VI**
1. Vật, tức sắc ý vật (54) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
1. The base, the heart-base materiality (54) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
2. Cảnh, tức cảnh pháp, tức tợ tướng hơi thở là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
2. The object, the breath counterpart sign is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
3(a) Ý xúc của hữu phần (34) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
3(a) Mind-contact of the life-continuum (34) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
(b) Ý xúc của tốc hành thứ nhất (33) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
(b) Mind-contact at the first impulsion (33) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
4. Tác ý như lý, tức tâm hướng ý môn (12) là pháp nhân. Thọ uẩn của tốc hành thứ nhất là pháp quả.

**EN**
4. Wise attention, namely mind-door adverting (12) is the cause. The feeling aggregate at the first impulsion is the effect.

**VI**
Lấy 34 danh pháp của tốc hành thứ nhất trừ thọ thì ý xúc của tốc hành thứ nhất gồm 33. Từ tốc hành thứ hai trở đi chỉ khác ở chỗ có thêm một nhân vô gián là các danh pháp ngay trước đó, như tốc hành thứ nhất.

**EN**
Subtracting feeling from the 34 mental phenomena of the first impulsion leaves 33 for mind-contact at the first impulsion. From the second impulsion onward the only difference is the addition of a proximity cause, the immediately preceding mental phenomena such as those of the first impulsion.

**VI**
Trong lộ chứng thiền này, đối với nhân danh và sắc của thức uẩn ở tốc hành, về sắc chỉ lấy 54 sắc gồm ý vật làm chỗ nương và các sắc đi cùng nó. Cảnh là tợ tướng hơi thở, một cảnh chế định. Với tợ tướng bộ xương hoặc tợ tướng biến xứ trắng…

**EN**
In this jhāna attainment process, for mentality and materiality as a cause of the consciousness aggregate at impulsion, take only the 54 material phenomena comprising the supporting heart-base and its accompanying materiality. The object is the breath counterpart sign, a conceptual object. With the skeleton counterpart sign or the white kasiṇa counterpart sign…


<a id="M05-body-P188"></a>
## Tợ tướng thiền chỉ và sắc pháp làm cảnh / Serenity counterpart signs and material phenomena as objects
Miến / Burmese 188

**VI**
…hoặc bất kỳ tướng thiền chỉ nào tương tự, hãy dùng trí thấy rõ mối quan hệ nhân quả của các danh pháp thiền sinh khởi khi lấy tướng ấy làm cảnh. Khi quán các nhân và quả, ở nhân gọi là cảnh, hãy thay bằng tợ tướng thiền chỉ mà chính nhóm danh pháp thiền mình đang quán lấy làm cảnh. Chẳng hạn, hãy thay bằng “cảnh tợ tướng biến xứ trắng” hay tên thích hợp khác. Có 34 danh pháp ở sơ thiền, 32 ở nhị thiền, 31 ở tam thiền, 31 ở tứ thiền và 31 ở mỗi tầng trong cả bốn thiền vô sắc. Vì vậy, hãy bớt số tâm sở thích hợp trong ý xúc ở tốc hành. Sau các tốc hành thiền an chỉ, tâm đăng ký không sinh.

**EN**
…or any similar serenity sign, see clearly with knowledge the causal relationship of the jhāna mental phenomena that arise taking that sign as object. When discerning causes and effects, for the cause called the object, substitute the serenity counterpart sign taken by the particular jhāna mental group you are discerning. For instance, substitute “the white kasiṇa counterpart sign as object” or the other appropriate designation. There are 34 mental phenomena in the first jhāna, 32 in the second, 31 in the third, 31 in the fourth, and 31 in each of the four immaterial jhānas. Accordingly, reduce the number of mental factors in mind-contact at impulsion as appropriate. Registration does not arise after absorption jhāna impulsions.

**VI**
Lộ cảnh pháp — Sắc pháp làm cảnh

**EN**
Mental-object process — Material phenomena as objects

**VI**
Nếu quán một sắc pháp thuộc lộ cảnh pháp, chẳng hạn một trong năm sắc tịnh, tức các sắc trong sáng, hoặc một trong mười sáu sắc tế, thì khi có tác ý như lý, các tốc hành thiện sinh theo đó. Khi có tác ý không như lý, các tốc hành bất thiện sinh theo đó. Tác ý đến sắc pháp là vô thường, khổ, vô ngã hay bất tịnh là tác ý như lý. Tác ý đến nó như nhãn tịnh sắc hoặc một sắc pháp tương ứng cũng là tác ý như lý. Hãy xem cách tác ý không như lý sinh trong phần đề mục thiền về danh pháp. Điều này đã được trình bày trong phần sự sinh khởi của mười kiết sử. Các nhân còn lại vẫn giống như trên. Đến đây có thể hiểu cách quán quan hệ nhân quả ở các lộ tốc hành bất thiện. Nếu tâm đăng ký sinh, hãy quán theo mẫu quán tâm đăng ký đã trình bày trước đây.

**EN**
When discerning a material phenomenon included in the mental-object process, such as one of the five kinds of sensitivity materiality, the transparent materiality, or one of the sixteen kinds of subtle materiality, wholesome impulsions occur accordingly when there is wise attention. Unwholesome impulsions occur accordingly when there is unwise attention. Attending to the material phenomenon as impermanent, suffering, non-self, or unattractive is wise attention. Attending to it as eye-sensitivity or the corresponding material phenomenon is also wise attention. See how unwise attention arises in the meditation subject on mentality. This has been explained in the section on the arising of the ten fetters. The remaining causes are the same as above. The causal discernment for unwholesome impulsion processes should now be clear. If registration occurs, discern it using the registration model given earlier.


<a id="M05-body-P189"></a>
## Từng nghiệp và từng phần quả / Individual kammas and their particular results
Miến / Burmese 189

**VI**
Từng phần, từng trường hợp

**EN**
Each case individually

**VI**
Hãy phân thành năm uẩn ở từng sát-na tâm của các lộ tốc hành thiện và bất thiện trong cả sáu nhóm cảnh sắc, thinh, hương, vị, xúc và pháp. Hãy quán đầy đủ các pháp nhân và pháp quả bằng cách nối nhân với quả theo năm uẩn. Trong khi quán như vậy, hãy ghi nhớ lời sau.

**EN**
Distinguish the five aggregates in each mind-moment of wholesome and unwholesome impulsion processes throughout the six classes of visual, sound, odour, taste, tangible, and mental objects. Fully discern the causes and effects by relating them according to the five aggregates. In discerning in this way, bear in mind the following.

**VI**
Vipassakena pana kammantarañca vipākantarañca ekadesato jānitabbaṃ. (Visuddhimagga 2, 237.)

**EN**
Vipassakena pana kammantarañca vipākantarañca ekadesato jānitabbaṃ. (Visuddhimagga 2, 237.)

**VI**
Theo lời giải thích ấy của Visuddhimagga, thiện hữu hãy tiếp tục quán để biết nghiệp và quả của nghiệp theo từng trường hợp, từng phần. Các thức quả trong thời bình nhật, như ngũ thức, tiếp thâu, suy đạc và đăng ký trong sáu loại lộ bắt đầu bằng lộ nhãn môn, có những nhân nghiệp khác nhau. Một số thức quả bình nhật sinh do chính nghiệp làm sinh các pháp quả tái tục, hữu phần và tử. Một số thức quả bình nhật sinh do nghiệp khác. Hãy xem mười hai loại quả Đức Phật đã nêu. Lưu ý mỗi loại quả có nghiệp riêng tương ứng. Vì vậy, thiện hữu hãy quán kỹ lại năm uẩn quá khứ. Khi quán như vậy, nếu nhận ra được một số nghiệp thiện hay bất thiện, hãy dùng trí thấy rõ…

**EN**
Following that explanation in the Visuddhimagga, good friend, continue to discern kamma and its results case by case, in their particulars. Resultant consciousnesses during life, such as the five sense consciousnesses, receiving, investigating, and registration in the six kinds of processes beginning with the eye-door process, have different kammic causes. Some resultants during life arise from the very kamma that produces rebirth-linking, life-continuum, and death. Others arise from a different kamma. Look at the twelve kinds of result given by the Buddha. Note that each kind of result has its own corresponding kamma. Therefore, good friend, discern the five past aggregates again in detail. If, in doing so, you discern certain wholesome or unwholesome kammas, see clearly with knowledge…


<a id="M05-body-P190"></a>
## Quán bên ngoài và qua nhiều đời / Discernment externally and across successive lives
Miến / Burmese 190

**VI**
…các nghiệp ấy đem lại quả tốt hay quả xấu thế nào trong thời bình nhật của đời hiện tại như đời này, rồi quán bằng cách nối nhân với quả.

**EN**
…what favourable or adverse results those kammas bring about during the course of a life such as the present one, then discern by relating cause and effect.

**VI**
Bên ngoài, nhiều đời quá khứ và nhiều đời vị lai

**EN**
Externally, across successive past and future lives

**VI**
Khi đã quán đầy đủ, trong cả sáu nhóm cảnh như trên, mối quan hệ nhân quả giữa năm nhân quá khứ và các quả hiện tại, hãy dựa theo cùng phương pháp ấy để quán các pháp nhân và quả bên ngoài. Riêng bên ngoài, hãy quán chung những gì giống nhau ở bên ngoài theo cách khái quát.

**EN**
When you have fully discerned the causal relationship between the five past causes and the present effects in all six classes of objects, as above, apply the same method to discern causes and effects externally. Externally, discern like external phenomena together in general terms.

**VI**
Nếu làm được, hãy hướng trí đến các đời quá khứ nối tiếp và quán nhân quả, chẳng hạn nhân ở đời quá khứ thứ hai với quả ở đời quá khứ thứ nhất, rồi nhân ở đời quá khứ thứ ba với quả ở đời quá khứ thứ hai. Khi quán như vậy, trong một đời quá khứ mà trước đó chưa từng quán danh sắc đến chân đế, hành giả không cần quán các danh pháp sinh khi lấy những sắc chân đế ấy làm cảnh hoặc các nhân liên hệ với những danh pháp đó. Tương tự, trong đời quá khứ chưa từng chứng thiền, không cần quán các danh pháp thiền hay những nhân liên hệ với chúng.

**EN**
If you succeed, direct knowledge back through successive past lives to discern causes and effects, for example the causes in the second past life with the effects in the first, then the causes in the third past life with the effects in the second. When discerning in this way, in a past life in which you had never discerned mentality and materiality at the ultimate level, there is no need to discern the mental phenomena that arise taking those ultimate material phenomena as object or the causes associated with those mental phenomena. Similarly, in a past life in which jhāna was never attained, there is no need to discern jhāna mental phenomena or their associated causes.

**VI**
Tương tự, hãy quán các nhân hiện tại và quả vị lai bằng cách nối nhân với quả. Hãy hướng trí đến các đời vị lai nối tiếp…

**EN**
Likewise, discern present causes and future effects by relating cause and effect. Direct knowledge to the successive future lives…


<a id="M05-body-P191"></a>
## Hạt giống hạnh và hạt giống minh / Seeds of conduct and seeds of knowledge
Miến / Burmese 191

**VI**
…cho đến tận cùng vị lai và quán các pháp nhân và quả trong khả năng của mình. Trong cả ba thời quá khứ, hiện tại và vị lai, hãy quán các pháp nhân và quả bên ngoài theo mẫu quán nhân và quả bên trong.

**EN**
…as far as the future extends and discern the causes and effects as far as you can. In all three periods, past, present, and future, discern causes and effects externally in the same manner as internally.

**VI**
Hạt giống hạnh và hạt giống minh

**EN**
Seeds of conduct and seeds of knowledge

**VI**
Khi quán các pháp nhân và quả như vậy, hãy hướng trí thấy rõ và đặc biệt lưu ý những hạt giống sau đây đã được vun bồi, nuôi dưỡng và thực hành trong những đời quá khứ khác nhau với nguyện vọng hướng đến Niết Bàn.

**EN**
In discerning causes and effects in this way, see clearly with knowledge and give particular attention to the following seeds, cultivated, nurtured, and practised in various past lives with the aspiration for Nibbāna.

**VI**
1. Hạt giống hạnh là sự thực hành bố thí, giới và thiền chỉ.

**EN**
1. Seeds of conduct are the practice of giving, virtue, and serenity.

**VI**
2(a) Đã từng quán bốn đại.

**EN**
2(a) Having discerned the four great elements.

**VI**
(b) Đã từng quán sắc pháp đến chân đế.

**EN**
(b) Having discerned material phenomena down to the ultimate level.

**VI**
(c) Đã từng quán danh pháp đến chân đế.

**EN**
(c) Having discerned mental phenomena down to the ultimate level.

**VI**
(d) Đã từng quán danh và sắc đến chân đế.

**EN**
(d) Having discerned mentality and materiality down to the ultimate level.

**VI**
(e) Đã từng quán các pháp nhân và quả.

**EN**
(e) Having discerned causes and effects.

**VI**
(f) Đã từng quán và xem xét bằng minh sát các hành, tức sắc, danh, nhân và quả, quy chúng vào ba đặc tướng. Đó là một số hạt giống minh, và cũng là một số hạt giống hạnh.

**EN**
(f) Having contemplated and examined formations, namely materiality, mentality, causes, and effects, by insight under the three characteristics. These are some seeds of knowledge and also some seeds of conduct.

**VI**
Hãy dùng trí thấy rõ cách các hạt giống hạnh và minh ấy lần lượt trợ nhau bằng năng lực nâng đỡ và năng lực trực tiếp sinh quả. Hãy quán các pháp nhân và quả.

**EN**
See clearly with knowledge how those seeds of conduct and knowledge support one another in succession through their sustaining potency and directly productive potency. Discern the causes and effects.


<a id="M05-body-P192"></a>
## Nhân vô gián của hữu phần / Proximity causes of the life-continuum
Miến / Burmese 192

**VI**
Nhân vô gián của hữu phần

**EN**
Proximity causes of the life-continuum

**VI**
Tâm sinh làm nhân cho sự tiếp nối của dòng tâm trong một đời, để dòng ấy không gián đoạn, gọi là hữu phần. Ở trên đã giải thích rằng hữu phần sinh do các nhân tương ứng, như vô minh, ái, thủ, hành, nghiệp, vật, cảnh và xúc. Vì hữu phần là loại tâm sinh thường xuyên nhất suốt một đời, các nhân vô gián của hữu phần cũng rất nhiều. Nói gọn để dễ ghi nhớ, sát-na tâm trước ngay sát tâm hữu phần đang được quán, tức sát-na sinh liền trước mà không có gián cách, chính là nhân vô gián của hữu phần ấy. Vì vậy, các pháp sau đây trợ bằng năng lực duyên vô gián.

**EN**
The consciousness that arises as a factor in the continuity of the stream of consciousness within one life, so that the stream is uninterrupted, is called the life-continuum. It has already been explained that the life-continuum arises from corresponding causes such as ignorance, craving, clinging, formations, kamma, base, object, and contact. Because the life-continuum is the type of consciousness that occurs most frequently during a life, there are also very many proximity causes of it. Briefly, to make the point easy to remember, the mind-moment immediately preceding the life-continuum moment being discerned, the moment that arises with no interval before it, is its proximity cause. Thus the following support by the power of proximity condition.

**VI**
1. Tâm tái tục trợ tâm hữu phần thứ nhất.

**EN**
1. Rebirth-linking supports the first life-continuum moment.

**VI**
2. Tâm hữu phần thứ nhất trợ tâm hữu phần thứ hai.

**EN**
2. The first life-continuum moment supports the second.

**VI**
3. Mỗi tâm hữu phần trước trợ tâm hữu phần kế tiếp.

**EN**
3. Each earlier life-continuum moment supports the following one.

**VI**
4. Nếu hữu phần sinh sau tâm xác định, tâm xác định trợ hữu phần ấy.

**EN**
4. If the life-continuum occurs after determining, determining supports it.

**VI**
5. Nếu hữu phần sinh sau tốc hành, tốc hành cuối trợ hữu phần ấy.

**EN**
5. If the life-continuum occurs after impulsion, the final impulsion supports it.

**VI**
6. Nếu hữu phần sinh sau tâm đăng ký, tâm đăng ký thứ hai trợ hữu phần ấy.

**EN**
6. If the life-continuum occurs after registration, the second registration supports it.

**VI**
Khi một hữu phần sinh tiếp sau hữu phần, mỗi hữu phần trước trợ hữu phần sau bằng năng lực duyên vô gián.

**EN**
When one life-continuum moment arises after another, each preceding moment supports the next by the power of proximity condition.


<a id="M05-body-P193"></a>
## Đạt đến tuệ liễu tri bằng nhận biết / Reaching full understanding as the known
Miến / Burmese 193

**VI**
Đạt đến tuệ liễu tri bằng nhận biết (ñātapariññā)

**EN**
Reaching full understanding as the known (ñātapariññā)

**VI**
So “idaṃ nāmarūpaṃ na ahetu appaccayā nibbattaṃ, sahetu sappaccayā nibbattaṃ. Ko pana hetu, ko pana paccayo”ti upaparikkhanto “avijjāpaccayā taṇhāpaccayā kammapaccayā āhārapaccayā cā”ti taṃ paccayaṃ vavatthapetvā “atītepi paccayā ceva paccayasamuppannā dhammā ca, anāgatepi etarahipi paccayā ceva paccayasamuppannā dhammā ca, tato uddhaṃ satto vā puggalo vā natthi, suddhasaṅkhārapuñjo evā”ti tīsu addhāsu kaṅkhaṃ vitarati. Ayaṃ pana vipassanāsaṅkhārasallakkhaṇā ñātapariññā nāma. (Chú giải Abhidhamma 2, 241–242.)

**EN**
So “idaṃ nāmarūpaṃ na ahetu appaccayā nibbattaṃ, sahetu sappaccayā nibbattaṃ. Ko pana hetu, ko pana paccayo”ti upaparikkhanto “avijjāpaccayā taṇhāpaccayā kammapaccayā āhārapaccayā cā”ti taṃ paccayaṃ vavatthapetvā “atītepi paccayā ceva paccayasamuppannā dhammā ca, anāgatepi etarahipi paccayā ceva paccayasamuppannā dhammā ca, tato uddhaṃ satto vā puggalo vā natthi, suddhasaṅkhārapuñjo evā”ti tīsu addhāsu kaṅkhaṃ vitarati. Ayaṃ pana vipassanāsaṅkhārasallakkhaṇā ñātapariññā nāma. (Abhidhamma Commentary 2, 241–242.)

**VI**
Hành giả đã quán đầy đủ năm uẩn, tức sắc pháp và danh pháp, theo các xứ và cửa trong cả sáu nhóm cảnh, dùng trí xét như sau. “Danh sắc này sinh khi có nhân trực tiếp làm sinh, tức nhân sản sinh, và khi có duyên nâng đỡ, tức nhân trợ giúp. Vậy nhân trực tiếp của danh sắc này là gì? Các duyên trợ là gì?” Khi xét như vậy, vị ấy phân định các nhân của danh sắc. “Danh sắc sinh do nhân gọi là vô minh, do nhân gọi là ái, do nhân gọi là nghiệp và do nhân gọi là vật thực.” Chẳng hạn, do vô minh sinh nên sắc do nghiệp sinh lúc tái tục, tức sắc uẩn, sinh…

**EN**
A practitioner who has fully discerned the five aggregates, that is, material and mental phenomena, by bases and doors in all six classes of objects, examines with knowledge as follows. “This mentality and materiality arises when there is a direct cause of its arising, a productive cause, and when there is a sustaining condition, a supporting cause. What, then, is the direct cause of this mentality and materiality? What are its supporting conditions?” In this way the practitioner distinguishes the causes of mentality and materiality. “It arises on account of the cause called ignorance, the cause called craving, the cause called kamma, and the cause called nutriment.” For example, with the arising of ignorance, kamma-produced materiality at rebirth-linking, the materiality aggregate, arises…


<a id="M05-body-P194"></a>
## Nhân và quả trong ba thời / Causes and effects in the three periods
Miến / Burmese 194

**VI**
…Vô minh là pháp nhân. Sắc do nghiệp sinh lúc tái tục, tức sắc uẩn, là pháp quả. Sau khi phân định như vậy, hành giả thấy rõ những điều sau.

**EN**
…Ignorance is the cause. Kamma-produced materiality at rebirth-linking, the materiality aggregate, is the effect. Having distinguished them in this way, the practitioner sees the following.

**VI**
1. Trong quá khứ cũng chỉ có các pháp nhân và các pháp quả.

**EN**
1. In the past there are only causes and effects.

**VI**
2. Trong vị lai cũng chỉ có các pháp nhân và các pháp quả.

**EN**
2. In the future there are only causes and effects.

**VI**
3. Trong hiện tại cũng chỉ có các pháp nhân và các pháp quả.

**EN**
3. In the present there are only causes and effects.

**VI**
Ngoài các pháp nhân và quả ấy, không có người hay chúng sinh làm ra hoặc tạo tác, cũng không có người hay chúng sinh được làm ra hoặc được tạo tác. Không có đàn ông, đàn bà, người, chúng sinh, chư thiên, Phạm thiên, sinh mạng, linh hồn, thức hay tự ngã theo nghĩa một thực thể. Chỉ có những nhóm hành thuần túy gồm sắc pháp, danh pháp, các pháp nhân và các pháp quả. Khi tự mình thấu suốt và thấy rõ như vậy bằng trí chánh kiến, trí ấy có thể xóa bỏ hoài nghi và những suy nghĩ lầm lạc về ba thời quá khứ, vị lai và hiện tại. Trí ấy biết phân định rõ các hành sau đây, là cảnh được trí minh sát quán.

**EN**
Beyond these causes and effects there is no person or being who makes or creates, and no person or being made or created. There is no man, woman, person, being, human, deva, Brahmā, living entity, soul, consciousness, or self as an entity. There are simply groups of formations consisting of material phenomena, mental phenomena, causes, and effects. When right-view knowledge penetrates and sees this for oneself, that knowledge can dispel doubt and mistaken speculation about the past, future, and present. It clearly distinguishes the following formations, which are the objects of insight knowledge.

**VI**
1. Sắc pháp.

**EN**
1. Material phenomena.

**VI**
2. Danh pháp.

**EN**
2. Mental phenomena.

**VI**
3. Các pháp nhân.

**EN**
3. Causes.

**VI**
4. Các pháp quả.

**EN**
4. Effects.

**VI**
Trí phân định rõ các hành này gọi là tuệ liễu tri bằng nhận biết. (Chú giải Abhidhamma 2, 241–242.) Tuy nhiên, đến đây…

**EN**
The knowledge that clearly distinguishes these formations is called full understanding as the known. (Abhidhamma Commentary 2, 241–242.) However, at this point…


<a id="M05-body-P195"></a>
## Bén rễ trong Giáo pháp / Taking root in the Dispensation
Miến / Burmese 195

**VI**
…công việc vẫn chưa xong. Còn phải cố gắng quán lại các hành là sắc, danh, nhân và quả theo đặc tính, phận sự, biểu hiện và nhân gần. Sau khi nỗ lực như vậy, công việc thực hành tiếp theo là như sau.

**EN**
…the work is still incomplete. One must make further effort to discern the formations comprising materiality, mentality, causes, and effects by characteristic, function, manifestation, and proximate cause. After making that effort, the next task in the practice is as follows.

**VI**
Bén rễ đến mức không thể lìa Giáo pháp

**EN**
Taking root so as to be unable to leave the Dispensation

**VI**
Evaṃ saṅkhāre sallakkhetvā ṭhito pana bhikkhu no dasabalassa sāsane mūlaṃ otaritvā ṭhito nāma hoti, patiṭṭhaṃ laddhā nāma, cūḷasotāpanno nāma hoti niyatagatikova. Tathārūpaṃ pana utusappāyaṃ puggalasappāyaṃ bhojanasappāyaṃ dhammassavanasappāyaṃ labhitvā ekāsane ekapallaṅkavaragato tīṇi lakkhaṇāni āropetvā vipassanāpaṭipāṭiyā saṅkhāre sammasanto arahattaṃ gaṇhāti. (Chú giải Abhidhamma 2, 242.)

**EN**
Evaṃ saṅkhāre sallakkhetvā ṭhito pana bhikkhu no dasabalassa sāsane mūlaṃ otaritvā ṭhito nāma hoti, patiṭṭhaṃ laddhā nāma, cūḷasotāpanno nāma hoti niyatagatikova. Tathārūpaṃ pana utusappāyaṃ puggalasappāyaṃ bhojanasappāyaṃ dhammassavanasappāyaṃ labhitvā ekāsane ekapallaṅkavaragato tīṇi lakkhaṇāni āropetvā vipassanāpaṭipāṭiyā saṅkhāre sammasanto arahattaṃ gaṇhāti. (Abhidhamma Commentary 2, 242.)

**VI**
Vị tỳ-kheo hành thiền đã phân định rõ sắc, danh, nhân và quả theo cách vừa nêu. Khi quán các hành ấy bằng tuệ phân biệt nhân duyên, vị ấy đạt đến thanh tịnh do vượt qua hoài nghi (kaṅkhāvitaraṇavisuddhi), tức có cái thấy trong sáng vượt qua hoài nghi. Vì thế, vị ấy đã bén rễ trong Giáo pháp của Đức Phật, bậc Thập Lực, đến mức không thể lìa Giáo pháp. Vị ấy đã có chỗ đứng trong Giáo pháp, được gọi là Tiểu Nhập Lưu (cūḷasotāpanna), có thiện thú chắc chắn. Các điều kiện thích hợp để có thể đạt quả A-la-hán gồm có những điều sau.

**EN**
The practising bhikkhu has clearly distinguished materiality, mentality, causes, and effects as just described. When discerning those formations with knowledge discerning causes and conditions, the bhikkhu reaches purification by overcoming doubt (kaṅkhāvitaraṇavisuddhi), the clear vision that has gone beyond doubt. Thus the bhikkhu has taken root in the Dispensation of the Buddha, the One of Ten Powers, to the point of being unable to leave it. The bhikkhu has gained a footing in the Dispensation and is called a lesser stream-enterer (cūḷasotāpanna), with a secure good destination. Conditions conducive to attaining arahant fruition include the following.

**VI**
1. Utusappāya, thời tiết thích hợp.

**EN**
1. Utusappāya, a suitable climate.

**VI**
2. Puggalasappāya, người thích hợp, như thiện hữu, bạn tốt và người thân tốt, thầy tốt và bạn đồng học tốt.

**EN**
2. Puggalasappāya, suitable people such as good spiritual friends, good companions and relations, good teachers, and good fellow students.


<a id="M05-body-P196"></a>
## Các duyên thích hợp và cách quán trong oai nghi / Suitable conditions and discernment in the postures
Miến / Burmese 196

**VI**
3. Bhojanasappāya, vật thực thích hợp.

**EN**
3. Bhojanasappāya, suitable food.

**VI**
4. Dhammassavanasappāya, được nghe Pháp thích hợp.

**EN**
4. Dhammassavanasappāya, hearing suitable Dhamma.

**VI**
Khi có được bốn điều kiện thích hợp này, vị ấy có thể trong một lần ngồi tại một chỗ, quán các hành theo ba đặc tướng và tuần tự xem xét chúng theo tiến trình tuệ minh sát, rồi đạt quả A-la-hán. (Chú giải Abhidhamma 2, 242.)

**EN**
Having obtained these four suitable conditions, in a single sitting the practitioner can contemplate formations under the three characteristics, examine them in succession through the course of insight knowledge, and attain arahant fruition. (Abhidhamma Commentary 2, 242.)

**VI**
Cách quán trong các oai nghi và khi tỉnh giác

**EN**
Discernment in the postures and with clear comprehension

**VI**
Thiện hữu đã thực hành tuần tự phần đề mục thiền chỉ, phần đề mục thiền về sắc pháp và phần đề mục thiền về danh pháp rồi mới sang phần Duyên khởi. Do vậy, thiện hữu đã biết quán năm uẩn, tức danh và sắc, theo các cách quán tương ứng với các oai nghi và với sự tỉnh giác. Đối với hành giả đã quán năm uẩn, tức danh và sắc, Đức Phật dạy cách tiếp tục thực hành như sau.

**EN**
Good friend, you have practised in succession the meditation subjects on serenity, materiality, and mentality before moving on to dependent origination. Thus you already know how to discern the five aggregates, that is, mentality and materiality, using the methods for the postures and for clear comprehension. For practitioners who have discerned the five aggregates, mentality and materiality, the Buddha taught how to continue as follows.

**VI**
1. Samudayadhammānupassī vā kāyasmiṃ viharati.

**EN**
1. Samudayadhammānupassī vā kāyasmiṃ viharati.

**VI**
2. Vayadhammānupassī vā kāyasmiṃ viharati.

**EN**
2. Vayadhammānupassī vā kāyasmiṃ viharati.

**VI**
3. Samudayavayadhammānupassī vā kāyasmiṃ viharati. (Majjhima 1, 71–72.)

**EN**
3. Samudayavayadhammānupassī vā kāyasmiṃ viharati. (Majjhima 1, 71–72.)

**VI**
Theo lời dạy này, thiện hữu hãy dùng trí thấy rõ mối quan hệ nhân quả của năm uẩn, tức các pháp danh và sắc, cả trong các oai nghi đi, đứng, ngồi, nằm và trong những hoạt động thực hành tỉnh giác. Hãy quán các pháp nhân và quả trong khả năng của mình.

**EN**
In accordance with these teachings, good friend, see clearly with knowledge the causal relationship of the five aggregates, mentality and materiality, while walking, standing, sitting, or lying down, and during the activities in which clear comprehension is practised. Discern causes and effects as far as you are able.


<a id="M05-body-P197"></a>
## Lời nguyện cuối cuốn / Closing aspiration
Miến / Burmese 197

**VI**
“Nguyện quý vị có thể nỗ lực tinh cần tu tập, trở thành bậc cao quý giữa loài người, bậc chư thiên giữa chư thiên.”

**EN**
“May you make the effort to practise diligently and become noble among humans, a deva among devas.”

**VI**
Pa-Auk Tawya Sayadaw

**EN**
Pa-Auk Tawya Sayadaw

**VI**
Tu viện Cittala

**EN**
Cittala Monastery

**VI**
Rừng Pa-Auk Tawya

**EN**
Pa-Auk Tawya Forest

**VI**
Năm 1367 theo lịch Miến Điện.

**EN**
Year 1367 of the Burmese Era.


<a id="M05-index-P001"></a>
## Chỉ mục — Miến 198 / Index — Burmese page 198
Chỉ mục / Index - Miến / Burmese 198

**VI**
[Trang này để trắng trong bản PDF nguồn.]

**EN**
[This page is blank in the source PDF.]


<a id="M05-index-P002"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 199 / Index in Burmese alphabetical order — 199
Chỉ mục / Index - Miến / Burmese 199

**VI**
Chỉ mục theo thứ tự chữ cái Miến

**EN**
Index in Burmese alphabetical order

**VI**
အ

**EN**
အ

**VI**
Kiến chấp vô tác dụng (akiriyadiṭṭhi) — 106

**EN**
View of the inefficacy of action (akiriyadiṭṭhi) — 106

**VI**
Vũ khí tốt nhất — 108

**EN**
The best weapon — 108

**VI**
Nghiệp sắp cho quả — 82

**EN**
Kamma about to give its result — 82

**VI**
Tóm lược để ghi nhớ — 19

**EN**
Summary for memorization — 19

**VI**
Cách quán các pháp nhân và quả — 85

**EN**
How to discern causes and effects — 85

**VI**
Một trình tự tìm các pháp nhân — 39

**EN**
A sequence for finding causes — 39

**VI**
Cách quán các pháp bằng cách nối nhân với quả — 114

**EN**
How to discern by relating causes and effects — 114

**VI**
Một ví dụ khác — 70

**EN**
Another example — 70

**VI**
Chấp ngã kiến — 104

**EN**
Clinging to a self-view — 104

**VI**
Năm pháp nhân quá khứ — 20

**EN**
The five past causes — 20

**VI**
Sức chi phối của tập khí quá khứ — 92

**EN**
The influence of past habits — 92

**VI**
Lần về cận tử quá khứ — 57

**EN**
Tracing back to the approach of death in the past — 57

**VI**
Hãy hướng trí về quá khứ để xem — 46

**EN**
Direct knowledge into the past — 46

**VI**
Điểm đặc biệt cần lưu ý — 109

**EN**
A particular point to note — 109

**VI**
Nhân vô gián — 156

**EN**
Proximity cause — 156

**VI**
Năm pháp quả vị lai — 20

**EN**
The five future effects — 20

**VI**
Nhân gần nhất (padaṭṭhāna) — 126

**EN**
The nearest cause (padaṭṭhāna) — 126

**VI**
Trí hiểu biết (anubodhañāṇa) — 4

**EN**
Knowledge of understanding (anubodhañāṇa) — 4

**VI**
Hiểu và thấu triệt (anubodha và paṭivedha) — 14

**EN**
Understanding and penetration (anubodha and paṭivedha) — 14

**VI**
Suy luận và trực chứng — 29

**EN**
Inference and direct experience — 29

**VI**
Lời nguyện của Anojādevī — 63

**EN**
Anojādevī’s aspiration — 63

**VI**
Phương pháp vô tác giả — 103

**EN**
The method of non-agency — 103

**VI**
Thắng trí và minh sát — 35

**EN**
Direct knowledge and insight — 35

**VI**
Bản Pāli của Abhidhamma Vibhaṅga — 21

**EN**
The Pāli text of the Abhidhamma Vibhaṅga — 21

**VI**
Ánh sáng màu sắc — 139

**EN**
Coloured light — 139

**VI**
Trí của Tôn giả Ānanda — 2

**EN**
Venerable Ānanda’s knowledge — 2

**VI**
Trưởng lão A-la-hán Soṇa — 84

**EN**
The arahant elder Soṇa — 84

**VI**
Tính chất thấu triệt đúng đắn — 13

**EN**
The nature of right penetration — 13

**VI**
Chấp thuyết vô nhân — 107

**EN**
Adherence to the doctrine of causelessness — 107

**VI**
Vô nhân kiến — 106, 107

**EN**
The view of causelessness — 106, 107

**VI**
Một số điểm thay đổi — 171

**EN**
Some differences — 171

**VI**
အာ

**EN**
အာ

**VI**
Khoảng trống (ākāsa) — 173

**EN**
Space (ākāsa) — 173


<a id="M05-index-P003"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 200 / Index in Burmese alphabetical order — 200
Chỉ mục / Index - Miến / Burmese 200

**VI**
Giới hư không — 173

**EN**
The space element — 173

**VI**
Giới nước — 181

**EN**
The water element — 181

**VI**
Chất lỏng thuộc giới nước — 181

**EN**
Fluid of the water element — 181

**VI**
Kinh Ánh Sáng (Ābhāsutta) — 140

**EN**
Discourse on Light (Ābhāsutta) — 140

**VI**
Hành tích lũy (āyūhanasaṅkhāra) — 25

**EN**
Formations as accumulation (āyūhanasaṅkhāra) — 25

**VI**
Cảnh — 120

**EN**
Object — 120

**VI**
Ánh sáng — 140

**EN**
Light — 140

**VI**
Nhân của sắc do vật thực sinh — 87

**EN**
Cause of nutriment-produced materiality — 87

**VI**
Nghiệp nâng đỡ — 83

**EN**
Supporting kamma — 83

**VI**
ဣ

**EN**
ဣ

**VI**
Cách quán trong các oai nghi và khi tỉnh giác — 196

**EN**
Discernment in the postures and with clear comprehension — 196

**VI**
ဥ

**EN**
ဥ

**VI**
Học hỏi (uggaha) — 6

**EN**
Learning (uggaha) — 6

**VI**
Đoạn kiến và thường kiến — 98

**EN**
Annihilationism and eternalism — 98

**VI**
ဧ

**EN**
ဧ

**VI**
Phương pháp đồng nhất — 90, 99

**EN**
The method of identity — 90, 99

**VI**
Biết phương pháp đồng nhất — 98

**EN**
Knowing the method of identity — 98

**VI**
Phương pháp tính quy luật — 106

**EN**
The method of regularity — 106

**VI**
က

**EN**
က

**VI**
Nghiệp làm cạn kiệt nghiệp — 74

**EN**
Kamma that exhausts kamma — 74

**VI**
Sức mạnh của nghiệp duyên — 25

**EN**
The power of kamma condition — 25

**VI**
Nghiệp hữu — 25

**EN**
Kamma-becoming — 25

**VI**
Hai pháp thuộc vòng nghiệp — 53, 79

**EN**
The two factors in the round of kamma — 53, 79

**VI**
Gọi là năng lực nghiệp — 27

**EN**
Called kammic potency — 27

**VI**
Thân do vật chất tạo thành (karajakāya) — 120

**EN**
The materially formed body (karajakāya) — 120

**VI**
Năm uẩn tái tục ở sát-na đầu của phôi kalala — 112

**EN**
The five rebirth-linking aggregates at the first kalala moment — 112

**VI**
Sắc trong sáng của thân — 183

**EN**
Transparent body-sensitivity — 183

**VI**
Vòng phiền não và vòng nghiệp — 51, 75

**EN**
The rounds of defilements and kamma — 51, 75

**VI**
Ba pháp thuộc vòng phiền não — 52, 77

**EN**
The three factors in the round of defilements — 52, 77

**VI**
Trích Kinh Nhà Có Nóc Nhọn (Kūṭāgārasutta) — 31

**EN**
Excerpt from the Discourse on the Peaked House (Kūṭāgārasutta) — 31

**VI**
Công chúa, con vua Kosala — 61

**EN**
The princess, daughter of the king of Kosala — 61

**VI**
Cách tìm cảnh nghiệp — 60

**EN**
How to find the kamma object — 60

**VI**
Khi đã thấy biết đúng đắn — 106

**EN**
When one has seen and known correctly — 106

**VI**
Thấy biết đúng đắn — 104

**EN**
Seeing and knowing correctly — 104

**VI**
Thế nào là thấy biết đúng đắn? — 103

**EN**
What is it to see and know correctly? — 103

**VI**
Thai nhi còn nhỏ — 116

**EN**
The young embryo — 116


<a id="M05-index-P004"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 201 / Index in Burmese alphabetical order — 201
Chỉ mục / Index - Miến / Burmese 201

**VI**
Cảnh tượng đau lòng — 68

**EN**
A heartbreaking scene — 68

**VI**
Điểm chính cần ghi nhớ trước — 86

**EN**
The main point to remember beforehand — 86

**VI**
Một điểm cần lưu ý trước — 44

**EN**
A point to note beforehand — 44

**VI**
Cù lao nương bãi bồi, bãi bồi nương cù lao — 122

**EN**
The island depends on the sandbank, and the sandbank on the island — 122

**VI**
ခ

**EN**
ခ

**VI**
Cách phân thành năm uẩn — 110

**EN**
How to classify the five aggregates — 110

**VI**
Có vẻ khó, và quả thật là khó. Có vẻ sâu, và quả thật là sâu — 93

**EN**
It seems difficult and is difficult. It seems deep and is deep — 93

**VI**
Hũ sữa chua — 99

**EN**
A pot of curd — 99

**VI**
ဂ

**EN**
ဂ

**VI**
Lộ cảnh hương, tức mùi — Tỷ thức — Thọ uẩn — 177

**EN**
Odour-object process — Nose-consciousness — Feeling aggregate — 177

**VI**
Lộ cảnh hương, tức mùi — Hướng ngũ môn — Thọ uẩn — 176

**EN**
Odour-object process — Five-door adverting — Feeling aggregate — 176

**VI**
Lộ cảnh hương, tức mùi — Suy đạc — Thọ uẩn — 179

**EN**
Odour-object process — Investigating — Feeling aggregate — 179

**VI**
Lộ cảnh hương, tức mùi — Tiếp thâu — Thọ uẩn — 178

**EN**
Odour-object process — Receiving — Feeling aggregate — 178

**VI**
စ

**EN**
စ

**VI**
Nhãn thức — Sắc uẩn — 138

**EN**
Eye-consciousness — Materiality aggregate — 138

**VI**
Nhãn thức — Thức uẩn — 141

**EN**
Eye-consciousness — Consciousness aggregate — 141

**VI**
Nhãn thức — Thọ uẩn — 138

**EN**
Eye-consciousness — Feeling aggregate — 138

**VI**
Nhãn thức — Hành uẩn — 141

**EN**
Eye-consciousness — Formations aggregate — 141

**VI**
Nhãn thức — Tưởng uẩn — 140

**EN**
Eye-consciousness — Perception aggregate — 140

**VI**
Hạt giống hạnh và hạt giống minh — 191

**EN**
Seeds of conduct and seeds of knowledge — 191

**VI**
Kinh Giáo Giới Rāhula Ngắn (Cūḷarāhulovādasutta) — 165

**EN**
Shorter Discourse of Advice to Rāhula (Cūḷarāhulovādasutta) — 165

**VI**
Lời nguyện của Cūḷasubhaddā — 67

**EN**
Cūḷasubhaddā’s aspiration — 67

**VI**
Gọi là Tiểu Nhập Lưu — 195

**EN**
Called a lesser stream-enterer — 195

**VI**
Kinh Tư (Cetanāsutta) — 73

**EN**
Discourse on Volition (Cetanāsutta) — 73

**VI**
Năng lực nghiệp — 54

**EN**
Kammic potency — 54

**VI**
Chính năng lực nghiệp ấy là nghiệp — 54

**EN**
That very kammic potency is kamma — 54

**VI**
ဆ

**EN**
ဆ

**VI**
Chuyện voi chúa Chaddanta — 64

**EN**
The story of Chaddanta, king of the elephants — 64

**VI**
Lời nguyện — 71

**EN**
Aspiration — 71


<a id="M05-index-P005"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 202 / Index in Burmese alphabetical order — 202
Chỉ mục / Index - Miến / Burmese 202

**VI**
ဇ

**EN**
ဇ

**VI**
Nghiệp sản sinh (janakakamma) — 83

**EN**
Productive kamma (janakakamma) — 83

**VI**
Tác ý dẫn đầu tốc hành (javanapaṭipādakamanasikāra) — 151

**EN**
Attention that leads to impulsion (javanapaṭipādakamanasikāra) — 151

**VI**
Trí nhớ đời trước (jātissarañāṇa) — 64

**EN**
Knowledge of remembering a former birth (jātissarañāṇa) — 64

**VI**
ဉ

**EN**
ဉ

**VI**
Liễu tri bằng nhận biết — 11

**EN**
Full understanding as the known — 11

**VI**
Đạt đến tuệ liễu tri bằng nhận biết — 193

**EN**
Reaching full understanding as the known — 193

**VI**
Gọi là liễu tri bằng nhận biết — 12, 194

**EN**
Called full understanding as the known — 12, 194

**VI**
Biết bằng liễu tri bằng nhận biết — 15

**EN**
Knowing through full understanding as the known — 15

**VI**
တ

**EN**
တ

**VI**
Chính ái được gọi là thủ — 51

**EN**
Craving itself is called clinging — 51

**VI**
Chủ trương của ngoại đạo — 6

**EN**
The doctrine of other sectarians — 6

**VI**
Kinh Các Xứ Của Ngoại Đạo (Titthāyatanasutta) — 21

**EN**
Discourse on the Sectarian Bases (Titthāyatanasutta) — 21

**VI**
Gọi là liễu tri bằng thẩm sát — 12

**EN**
Called full understanding by scrutinizing — 12

**VI**
Từng phần, từng trường hợp — 189

**EN**
Each case individually — 189

**VI**
Cùng một dòng, cùng một nhóm tâm — 123

**EN**
In the same continuum and the same group of consciousness — 123

**VI**
ဒ

**EN**
ဒ

**VI**
Nghiệp sẽ được cảm thọ ngay trong đời này — 28

**EN**
Kamma to be experienced in this very life — 28

**VI**
Trường hợp phát nguyện thứ hai — cõi Phạm thiên — 54

**EN**
Second aspiration — the Brahmā realm — 54

**VI**
Tốc hành thứ hai — Thọ uẩn — 186

**EN**
Second impulsion — Feeling aggregate — 186

**VI**
Bốn cách thuyết giảng — 42

**EN**
Four ways of teaching — 42

**VI**
ဓ

**EN**
ဓ

**VI**
Trí biết sự tồn tại của các pháp do duyên — 39

**EN**
Knowledge of the stability of phenomena through conditions — 39

**VI**
Một quy luật tự nhiên — 35

**EN**
A natural principle — 35

**VI**
Lộ cảnh pháp — Lộ tốc hành thiện lấy nhãn tịnh sắc làm cảnh — 185

**EN**
Mental-object process — Wholesome impulsions taking eye-sensitivity as object — 185

**VI**
Lộ cảnh pháp — Lộ chứng sơ thiền lấy tợ tướng hơi thở làm cảnh — 187

**EN**
Mental-object process — First-jhāna attainment taking the breath counterpart sign as object — 187

**VI**
Lộ cảnh pháp — Sắc pháp làm cảnh — 188

**EN**
Mental-object process — Material phenomena as objects — 188

**VI**
Cận sự nam Dhammika — 85

**EN**
The lay follower Dhammika — 85

**VI**
Ghi nhớ (dhāraṇā) — 7

**EN**
Retention (dhāraṇā) — 7

**VI**
န

**EN**
န

**VI**
Phương pháp sai biệt — 100

**EN**
The method of diversity — 100

**VI**
Nghiệp khác sát-na — 26

**EN**
Kamma at a different moment — 26

**VI**
Tuệ phân biệt danh sắc — 11

**EN**
Knowledge of delimiting mentality and materiality — 11

**VI**
Tuệ phân định danh sắc — 40

**EN**
Knowledge of defining mentality and materiality — 40

**VI**
Sự thay đổi của tướng — 84

**EN**
Changes in the sign — 84

**VI**
Thuyết định mệnh — 107

**EN**
Fatalism — 107

**VI**
Thế nào là thuyết định mệnh? — 107

**EN**
What is fatalism? — 107

**VI**
Bốn phương pháp — 90

**EN**
The four methods — 90

**VI**
Sắc pháp của chư thiên — 94

**EN**
Material phenomena of devas — 94

**VI**
Dòng tương tục của chư thiên — 94

**EN**
The continua of devas — 94


<a id="M05-index-P006"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 203 / Index in Burmese alphabetical order — 203
Chỉ mục / Index - Miến / Burmese 203

**VI**
Bốn danh uẩn — 88

**EN**
The four mental aggregates — 88

**VI**
Thế nào là danh? — 128

**EN**
What is mentality? — 128

**VI**
Một con bò — 82

**EN**
A cow — 82

**VI**
ပ

**EN**
ပ

**VI**
Tuệ phân biệt nhân duyên — 10

**EN**
Knowledge of discerning causes and conditions — 10

**VI**
Để đạt tuệ phân biệt nhân duyên — 34

**EN**
To attain knowledge of discerning causes and conditions — 34

**VI**
Phần tuệ phân biệt nhân duyên — 81

**EN**
Knowledge of discerning causes and conditions — 81

**VI**
Thế nào là tuệ phân biệt nhân duyên? — 34

**EN**
What is knowledge of discerning causes and conditions? — 34

**VI**
Pháp được trợ (paccayuppannadhamma) — 41

**EN**
Conditioned phenomenon (paccayuppannadhamma) — 41

**VI**
Gọi là pháp được trợ — 41

**EN**
Called a conditioned phenomenon — 41

**VI**
Năm pháp quả hiện tại — 20

**EN**
The five present effects — 20

**VI**
Năm pháp nhân hiện tại — 20

**EN**
The five present causes — 20

**VI**
Hướng ngũ môn — Sắc uẩn — 134

**EN**
Five-door adverting — Materiality aggregate — 134

**VI**
Hướng ngũ môn — Thức uẩn — 137

**EN**
Five-door adverting — Consciousness aggregate — 137

**VI**
Hướng ngũ môn — Thọ uẩn — 135

**EN**
Five-door adverting — Feeling aggregate — 135

**VI**
Hướng ngũ môn — Hành uẩn (tư, cách thứ nhất) — 136

**EN**
Five-door adverting — Formations aggregate (volition, first method) — 136

**VI**
Hướng ngũ môn — Hành uẩn (tám tâm sở, cách thứ hai) — 136

**EN**
Five-door adverting — Formations aggregate (eight mental factors, second method) — 136

**VI**
Hướng ngũ môn — Tưởng uẩn — 135

**EN**
Five-door adverting — Perception aggregate — 135

**VI**
Cảnh chế định — 187

**EN**
Conceptual object — 187

**VI**
Cách Đức Phật thuyết pháp Duyên khởi — 42

**EN**
How the Buddha taught dependent origination — 42

**VI**
Tóm lược Duyên khởi theo phương pháp thứ năm để ghi nhớ — 17

**EN**
Summary of dependent origination by the fifth method for memorization — 17

**VI**
Thế nào là quy luật Duyên khởi? — 42

**EN**
What is the principle of dependent origination? — 42

**VI**
Sắc uẩn tái tục — 115

**EN**
The materiality aggregate at rebirth-linking — 115

**VI**
Tái tục — Thức uẩn — 127

**EN**
Rebirth-linking — Consciousness aggregate — 127

**VI**
Tái tục — Thọ uẩn — 117

**EN**
Rebirth-linking — Feeling aggregate — 117

**VI**
Tái tục — Hành uẩn — 125

**EN**
Rebirth-linking — Formations aggregate — 125

**VI**
Tái tục — Tưởng uẩn — 124

**EN**
Rebirth-linking — Perception aggregate — 124

**VI**
Tái tục là thức — 18

**EN**
Rebirth-linking is consciousness — 18

**VI**
Tốc hành thứ nhất — Thọ uẩn — 187

**EN**
First impulsion — Feeling aggregate — 187

**VI**
Tốc hành thứ nhất — Thọ uẩn (lộ ý môn) — 185

**EN**
First impulsion — Feeling aggregate (mind-door process) — 185

**VI**
Giới đất — 183

**EN**
The earth element — 183

**VI**
Ba loại trí liễu tri — 3

**EN**
Three kinds of full-understanding knowledge — 3

**VI**
Hỏi thêm (paripucchā) — 7

**EN**
Inquiry (paripucchā) — 7

**VI**
Gọi là liễu tri bằng đoạn trừ — 12

**EN**
Called full understanding by abandoning — 12

**VI**
Tư trước khi làm — 24

**EN**
Volition before the act — 24

**VI**
Quy ước gọi tên theo nghĩa có trước (pubbūpacārasammuti) — 5

**EN**
Conventional designation by anticipation (pubbūpacārasammuti) — 5

**VI**
Cảnh của thắng trí nhớ các đời trước — 37

**EN**
The object of direct knowledge of former lives — 37


<a id="M05-index-P007"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 204 / Index in Burmese alphabetical order — 204
Chỉ mục / Index - Miến / Burmese 204

**VI**
Một bức tranh — 64

**EN**
A painting — 64

**VI**
ဖ

**EN**
ဖ

**VI**
Xúc — 122

**EN**
Contact — 122

**VI**
Lộ cảnh xúc — Thân thức — Thọ uẩn — 183

**EN**
Tangible-object process — Body-consciousness — Feeling aggregate — 183

**VI**
Lộ cảnh xúc — Hướng ngũ môn — Thọ uẩn — 182

**EN**
Tangible-object process — Five-door adverting — Feeling aggregate — 182

**VI**
Lộ cảnh xúc — Suy đạc — Thọ uẩn — 185

**EN**
Tangible-object process — Investigating — Feeling aggregate — 185

**VI**
Lộ cảnh xúc — Tiếp thâu — Thọ uẩn — 184

**EN**
Tangible-object process — Receiving — Feeling aggregate — 184

**VI**
ဗ

**EN**
ဗ

**VI**
Bên ngoài, nhiều đời quá khứ và nhiều đời vị lai — 190

**EN**
Externally, across successive past and future lives — 190

**VI**
Bahussutabhāva — sự đa văn — 8

**EN**
Bahussutabhāva — being learned — 8

**VI**
Thế nào là người đa văn? — 9

**EN**
What is a learned person? — 9

**VI**
Sắc pháp của chư Phạm thiên — 94

**EN**
Material phenomena of Brahmās — 94

**VI**
Dòng tương tục của chư Phạm thiên — 94

**EN**
The continua of Brahmās — 94

**VI**
Vị từ cõi Phạm thiên tái sinh xuống đây — 93

**EN**
One who has come down from the Brahmā realm — 93

**VI**
ဘ

**EN**
ဘ

**VI**
Nhân vô gián của hữu phần — 192

**EN**
Proximity causes of the life-continuum — 192

**VI**
Năm uẩn của hữu phần — 129

**EN**
The five aggregates at the life-continuum — 129

**VI**
Gọi là hữu phần — 192

**EN**
Called the life-continuum — 192

**VI**
Hữu phần — Sắc uẩn — 130

**EN**
Life-continuum — Materiality aggregate — 130

**VI**
Hữu phần — Thức uẩn — 133

**EN**
Life-continuum — Consciousness aggregate — 133

**VI**
Hữu phần — Thọ uẩn — 131

**EN**
Life-continuum — Feeling aggregate — 131

**VI**
Hữu phần — Hành uẩn — 132

**EN**
Life-continuum — Formations aggregate — 132

**VI**
Hữu phần — Tưởng uẩn — 132

**EN**
Life-continuum — Perception aggregate — 132

**VI**
Thế nào là hữu phần? — 91

**EN**
What is the life-continuum? — 91

**VI**
Ái ấy có từ khi nào? — 23

**EN**
When did that craving arise? — 23

**VI**
မ

**EN**
မ

**VI**
Tác ý dẫn đầu lộ tâm (vīthipaṭipādakamanasikāra) — 139

**EN**
Attention that leads the cognitive process (vīthipaṭipādakamanasikāra) — 139

**VI**
Thế nào là tác ý? — 139

**EN**
What is attention? — 139

**VI**
Hướng ý môn — Thọ uẩn — 162

**EN**
Mind-door adverting — Feeling aggregate — 162

**VI**
Tốc hành đại thiện thứ hai — Thọ uẩn — 157, 163

**EN**
Second great wholesome impulsion — Feeling aggregate — 157, 163

**VI**
Tốc hành đại thiện thứ nhất — Thức uẩn — 155

**EN**
First great wholesome impulsion — Consciousness aggregate — 155


<a id="M05-index-P008"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 205 / Index in Burmese alphabetical order — 205
Chỉ mục / Index - Miến / Burmese 205

**VI**
Tốc hành đại thiện thứ nhất — Thọ uẩn — 153, 162

**EN**
First great wholesome impulsion — Feeling aggregate — 153, 162

**VI**
Tốc hành đại thiện thứ nhất — Hành uẩn — 154

**EN**
First great wholesome impulsion — Formations aggregate — 154

**VI**
Tốc hành đại thiện thứ nhất — Tưởng uẩn — 154

**EN**
First great wholesome impulsion — Perception aggregate — 154

**VI**
Lời tuyên bố trong Kinh Đại Duyên — 1

**EN**
The declaration in the Great Discourse on Causation — 1

**VI**
Tâm đăng ký đại quả thứ nhất — Thức uẩn — 160

**EN**
First great-resultant registration — Consciousness aggregate — 160

**VI**
Tâm đăng ký đại quả thứ nhất — Thọ uẩn — 158

**EN**
First great-resultant registration — Feeling aggregate — 158

**VI**
Tư trong khi làm — 24

**EN**
Volition during the act — 24

**VI**
Hoàng hậu Subhaddā — 64

**EN**
Queen Subhaddā — 64

**VI**
Hạt giống và cây — 98

**EN**
The seed and the tree — 98

**VI**
Quy luật tự nhiên — 104

**EN**
Natural law — 104

**VI**
ယ

**EN**
ယ

**VI**
Một ví dụ của hành giả — 69

**EN**
An example from a practitioner — 69

**VI**
ရ

**EN**
ရ

**VI**
Lộ cảnh vị — Thiệt thức — Thọ uẩn — 180

**EN**
Taste-object process — Tongue-consciousness — Feeling aggregate — 180

**VI**
Lộ cảnh vị — Hướng ngũ môn — Thọ uẩn — 180

**EN**
Taste-object process — Five-door adverting — Feeling aggregate — 180

**VI**
Lộ cảnh vị — Suy đạc — Thọ uẩn — 182

**EN**
Taste-object process — Investigating — Feeling aggregate — 182

**VI**
Lộ cảnh vị — Tiếp thâu — Thọ uẩn — 181

**EN**
Taste-object process — Receiving — Feeling aggregate — 181

**VI**
Sắc uẩn — 87

**EN**
The materiality aggregate — 87

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn ở tốc hành thiện thứ nhất — 152

**EN**
Visual-object process — Five aggregates at the first wholesome impulsion — 152

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn của nhãn thức, tức tâm thấy — 137

**EN**
Visual-object process — Five aggregates at eye-consciousness, the consciousness that sees — 137

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm hướng ngũ môn — 133

**EN**
Visual-object process — Five aggregates at five-door adverting — 133

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn ở tâm đăng ký — 158

**EN**
Visual-object process — Five aggregates at registration — 158

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn ở tốc hành tham hợp tà kiến — 167

**EN**
Visual-object process — Five aggregates at greed-rooted impulsion associated with wrong view — 167

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm xác định — 148

**EN**
Visual-object process — Five aggregates at determining — 148

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm suy đạc — 145

**EN**
Visual-object process — Five aggregates at investigating — 145

**VI**
Lộ cảnh sắc, tức màu sắc — Năm uẩn của tâm tiếp thâu — 142

**EN**
Visual-object process — Five aggregates at receiving — 142


<a id="M05-index-P009"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 206 / Index in Burmese alphabetical order — 206
Chỉ mục / Index - Miến / Burmese 206

**VI**
Các lộ ý môn lấy cảnh sắc làm đối tượng — 161

**EN**
Mind-door processes taking a visual object — 161

**VI**
Sắc thủ uẩn — 111

**EN**
The materiality aggregate subject to clinging — 111

**VI**
Việc cần thực hành khi hình ảnh sắc hiện ra — 55

**EN**
What to practise when an image of materiality appears — 55

**VI**
Giải thích về nhãn xúc và ý xúc — 164

**EN**
Explanation of eye-contact and mind-contact — 164

**VI**
Giải thích về vật — 119

**EN**
Explanation of the base — 119

**VI**
လ

**EN**
လ

**VI**
Tái tục của loài người — 57

**EN**
Human rebirth-linking — 57

**VI**
Ba loại liễu tri hiệp thế — 11

**EN**
Three kinds of mundane full understanding — 11

**VI**
Ba loại liễu tri siêu thế — 13

**EN**
Three kinds of supramundane full understanding — 13

**VI**
Tốc hành tham hợp tà kiến thứ hai — Thức uẩn (lộ nhãn môn) — 169

**EN**
Second greed-rooted impulsion associated with wrong view — Consciousness aggregate (eye-door process) — 169

**VI**
Tốc hành tham hợp tà kiến thứ hai — Thọ uẩn (lộ nhãn môn) — 169

**EN**
Second greed-rooted impulsion associated with wrong view — Feeling aggregate (eye-door process) — 169

**VI**
ဝ

**EN**
ဝ

**VI**
Nghiệp thiện đưa đến luân hồi — 49

**EN**
Wholesome kamma that leads to the round — 49

**VI**
Sự thật về vòng luân hồi — 31

**EN**
The truth of the round — 31

**VI**
Gọi là sắc vật — 121

**EN**
Called base materiality — 121

**VI**
Giới gió — 178

**EN**
The wind element — 178

**VI**
Dấu vết của tập khí — 93

**EN**
Traces of habitual tendencies — 93

**VI**
Thức uẩn (lộ nhãn môn) — 168

**EN**
Consciousness aggregate (eye-door process) — 168

**VI**
Thức thủ uẩn — 111

**EN**
The consciousness aggregate subject to clinging — 111

**VI**
Sự thật về sự thoát khỏi vòng luân hồi — 31

**EN**
The truth of release from the round — 31

**VI**
Tâm ngoài lộ — 88, 110

**EN**
Process-free consciousness — 88, 110

**VI**
Xác định — Thức uẩn — 151

**EN**
Determining — Consciousness aggregate — 151

**VI**
Xác định — Thọ uẩn — 149

**EN**
Determining — Feeling aggregate — 149

**VI**
Xác định — Hành uẩn — 150

**EN**
Determining — Formations aggregate — 150

**VI**
Xác định — Tưởng uẩn — 149

**EN**
Determining — Perception aggregate — 149

**VI**
Thọ thủ uẩn — 111

**EN**
The feeling aggregate subject to clinging — 111

**VI**
သ

**EN**
သ

**VI**
Chỉ có những nhóm hành thuần túy — 194

**EN**
Only groups of formations — 194

**VI**
Hành và nghiệp hữu — 24

**EN**
Formations and kamma-becoming — 24

**VI**
Hành thủ uẩn — 111

**EN**
The formations aggregate subject to clinging — 111

**VI**
Tưởng thủ uẩn — 111

**EN**
The perception aggregate subject to clinging — 111

**VI**
Điểm cần lưu ý — 170

**EN**
A point to note — 170

**VI**
Lộ cảnh thinh, tức âm thanh — Hướng ngũ môn — Thọ uẩn — 171

**EN**
Sound-object process — Five-door adverting — Feeling aggregate — 171


<a id="M05-index-P010"></a>
## Chỉ mục theo thứ tự chữ cái Miến — 207 / Index in Burmese alphabetical order — 207
Chỉ mục / Index - Miến / Burmese 207

**VI**
Lộ cảnh thinh, tức âm thanh — Suy đạc — Thọ uẩn — 175

**EN**
Sound-object process — Investigating — Feeling aggregate — 175

**VI**
Lộ cảnh thinh, tức âm thanh — Tiếp thâu — Thức uẩn — 174

**EN**
Sound-object process — Receiving — Consciousness aggregate — 174

**VI**
Lộ cảnh thinh, tức âm thanh — Tiếp thâu — Hành uẩn (cách thứ hai) — 173

**EN**
Sound-object process — Receiving — Formations aggregate (second method) — 173

**VI**
Lộ cảnh thinh, tức âm thanh — Nhĩ thức, tức tâm nghe — Thọ uẩn — 172

**EN**
Sound-object process — Ear-consciousness, the consciousness that hears — Feeling aggregate — 172

**VI**
Suy đạc — Thức uẩn — 148

**EN**
Investigating — Consciousness aggregate — 148

**VI**
Suy đạc — Thọ uẩn — 145

**EN**
Investigating — Feeling aggregate — 145

**VI**
Suy đạc — Hành uẩn — 147

**EN**
Investigating — Formations aggregate — 147

**VI**
Suy đạc — Tưởng uẩn — 146

**EN**
Investigating — Perception aggregate — 146

**VI**
Hành giả lấy thiền chỉ làm cỗ xe — 50

**EN**
A practitioner whose vehicle is serenity — 50

**VI**
Nếu là hành giả lấy thiền chỉ làm cỗ xe — 50

**EN**
For a practitioner whose vehicle is serenity — 50

**VI**
Thế nào là sự thật về nguồn gốc khổ? — 21

**EN**
What is the truth of the origin of suffering? — 21

**VI**
Tiếp thâu — Thức uẩn — 144

**EN**
Receiving — Consciousness aggregate — 144

**VI**
Tiếp thâu — Thọ uẩn — 142

**EN**
Receiving — Feeling aggregate — 142

**VI**
Tiếp thâu — Hành uẩn — 143

**EN**
Receiving — Formations aggregate — 143

**VI**
Tiếp thâu — Tưởng uẩn — 143

**EN**
Receiving — Perception aggregate — 143

**VI**
Nghe học (savana) — 6

**EN**
Listening (savana) — 6

**VI**
Bén rễ đến mức không thể lìa Giáo pháp — 195

**EN**
Taking root so as to be unable to leave the Dispensation — 195

**VI**
Thế nào là sự thật được nghe (sutasacca)? — 10

**EN**
What is truth learned by hearing (sutasacca)? — 10

**VI**
Lời nguyện trước kia của công chúa Sumanā — 61

**EN**
Princess Sumanā’s former aspiration — 61

**VI**
Bồ-tát khi sắp qua đời — 59

**EN**
The Bodhisatta approaching death — 59

**VI**
Sotāpannatā — sự thành tựu Nhập lưu — 7

**EN**
Sotāpannatā — becoming a stream-enterer — 7

**VI**
Nếu tự cho mình là bậc Nhập lưu — 8

**EN**
If one takes oneself to be a stream-enterer — 8

**VI**
Thế nào là bậc Nhập lưu? — 5

**EN**
What is a stream-enterer? — 5

**VI**
Khi thấy được ba hoặc bốn đời — 96

**EN**
When three or four lives are seen — 96

**VI**
ဟ

**EN**
ဟ

**VI**
Sắc ý vật — 120

**EN**
Heart-base materiality — 120

**VI**
❂ ❂ ❂

**EN**
❂ ❂ ❂
