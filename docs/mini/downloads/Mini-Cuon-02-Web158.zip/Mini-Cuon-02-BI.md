# Nibbānagāminipaṭipadā · Mini · Cuốn 2 / Volume 2
Phần pháp hành thiền chỉ (Samatha kammaṭṭhāna) — B / Subjects of Tranquillity Meditation — B
Pa-Auk Tawya Sayadaw
Việt–Anh

## Mục lục / Contents

- [Bìa trước và bìa sau / Volume 2 — Subjects of Tranquillity Meditation — B](#M02-cover-P001)
- [Trang nhan đề / Title page](#M02-front-P001)
- [Pháp thí và lời nguyện / Dhamma verses and aspiration](#M02-front-P002)
- [Mục lục — trang က / Table of contents — page 1](#M02-front-P003)
- [Mục lục — trang ခ / Table of contents — page 2](#M02-front-P004)
- [Mục lục — trang ဂ / Table of contents — page 3](#M02-front-P005)
- [Mục lục — trang ဃ / Table of contents — page 4](#M02-front-P006)
- [Quán bất tịnh và đề mục bộ xương / Attention to repulsiveness and the skeleton meditation subject](#M02-body-P001)
- [Ba mươi hai thân phần — Hai mươi thân phần thuộc địa đại / The thirty-two parts of the body: predominant earth element](#M02-body-P002)
- [Mười hai thân phần thuộc thủy đại / Twelve parts with predominant water element](#M02-body-P003)
- [Từ gần đến xa — Ba con đường / The three entrances](#M02-body-P004)
- [Ba con đường — Tác ý bất tịnh / Attention to repulsiveness](#M02-body-P005)
- [Tác ý bất tịnh — Thân sống và tử thi / Internal and external repulsiveness](#M02-body-P006)
- [Lời giải thích của Phụ chú giải gốc / The Mūlaṭīkā explanation](#M02-body-P007)
- [Bất tịnh, kasiṇa và nền tảng minh sát / Access and absorption in repulsiveness meditation](#M02-body-P008)
- [Đề mục bộ xương / The skeleton meditation subject](#M02-body-P009)
- [Học tướng và tương tợ tướng / The learning sign and counterpart sign](#M02-body-P010)
- [Năm thiền chi — Hỷ và thọ hỷ / The five jhāna factors; joy and mental pleasant feeling](#M02-body-P011)
- [Hỷ, thọ hỷ — Điều cần ghi nhớ / A point to bear in mind](#M02-body-P012)
- [Bên trong và bên ngoài / Internally and externally](#M02-body-P013)
- [Thuần thục sơ thiền trên bộ xương / Alternating the internal and external skeleton](#M02-body-P014)
- [Mười kasiṇa — Tám chứng đắc — Bốn kasiṇa màu sắc / Ten kasiṇas and eight attainments](#M02-body-P015)
- [Kasiṇa trắng — Thiền thắng xứ / Jhāna of the bases of mastery](#M02-body-P016)
- [Ý nghĩa chế ngự cảnh kasiṇa / What the bases of mastery overcome](#M02-body-P017)
- [Bên trong và bên ngoài — Giải thích của chú giải / The internal and external bases of mastery](#M02-body-P018)
- [Điều kiện đạt cận định và an chỉ trên kasiṇa / Why external forms are more readily mastered](#M02-body-P019)
- [Hai cách thực hành — Bốn cảnh kasiṇa / With or without internal perception of form](#M02-body-P020)
- [Bốn loại cảnh — Chuyển sang kasiṇa trắng / Four kinds of kasiṇa object; proceeding to the white kasiṇa](#M02-body-P021)
- [Trình tự chuyển sang kasiṇa trắng / Taking white as the meditation object](#M02-body-P022)
- [Từ bộ xương bất tịnh đến kasiṇa trắng / Developing the white sign](#M02-body-P023)
- [Tương tợ tướng — Mở rộng vòng kasiṇa trắng / Extending the white kasiṇa](#M02-body-P024)
- [Cách mở rộng và an trú trên kasiṇa trắng / Stabilising the extended sign](#M02-body-P025)
- [Năm thiền chi của kasiṇa trắng / Five jhāna factors of the white kasiṇa](#M02-body-P026)
- [Phương pháp bốn thiền và năm thiền / The fourfold and fivefold jhāna schemes](#M02-body-P027)
- [Những cảnh trắng có thể sử dụng / Other objects for the white kasiṇa](#M02-body-P028)
- [Kasiṇa xanh (nīlakasiṇa) — Ba tướng và ba giai đoạn tu tập / The blue kasiṇa (nīlakasiṇa)](#M02-body-P029)
- [Tương tợ tướng của kasiṇa xanh / The three signs and three stages of concentration](#M02-body-P030)
- [Các cảnh xanh đen — Kasiṇa vàng / Developing the blue kasiṇa on other objects](#M02-body-P031)
- [Kasiṇa vàng (pītakasiṇa) / The yellow kasiṇa (pītakasiṇa)](#M02-body-P032)
- [Hoa padauk và sắc vàng óng / Padauk and golden shower flowers](#M02-body-P033)
- [Kasiṇa đỏ (lohitakasiṇa) / The red kasiṇa (lohitakasiṇa)](#M02-body-P034)
- [Những tinh hoa đưa đến A-la-hán quả / Essences leading to the noble path and fruition](#M02-body-P035)
- [Trân trọng cơ hội thực hành / Essences leading to the noble path and fruition](#M02-body-P036)
- [Kasiṇa đất (paṭhavīkasiṇa) / The earth kasiṇa (paṭhavīkasiṇa)](#M02-body-P037)
- [Sửa soạn vòng kasiṇa đất / Taking the earth kasiṇa sign](#M02-body-P038)
- [Điều không nên tác ý — Khiếm khuyết có thể gặp / What to attend to in the earth kasiṇa](#M02-body-P039)
- [Giữ đúng cảnh đất — Học tướng và tương tợ tướng / The learning sign and the counterpart sign](#M02-body-P040)
- [Tướng kasiṇa đất và cách mở rộng / From the learning sign to fourth jhāna](#M02-body-P041)
- [Một số hành giả — Kasiṇa nước (āpokasiṇa) / Using an existing attainment; the water kasiṇa](#M02-body-P042)
- [Lấy cảnh nước làm chuẩn bị tướng / Taking the water kasiṇa sign](#M02-body-P043)
- [Học tướng và tương tợ tướng của kasiṇa nước / The signs of the water kasiṇa](#M02-body-P044)
- [Kasiṇa lửa (tejokasiṇa) / The fire kasiṇa (tejokasiṇa)](#M02-body-P045)
- [Không tác ý màu sắc và đặc tính của lửa / What to attend to in the fire kasiṇa](#M02-body-P046)
- [Học tướng và tương tợ tướng của kasiṇa lửa / Developing the fire kasiṇa](#M02-body-P047)
- [Kasiṇa gió (vāyokasiṇa) / The signs of the fire kasiṇa; the wind kasiṇa](#M02-body-P048)
- [Hai cách lấy tướng gió — Kasiṇa ánh sáng / The signs of the wind kasiṇa; the light kasiṇa](#M02-body-P049)
- [Sửa soạn cảnh kasiṇa ánh sáng / Taking the light kasiṇa sign](#M02-body-P050)
- [Tướng ánh sáng — Đoạn trừ hôn trầm và thụy miên / The signs of the light kasiṇa; overcoming sloth and torpor](#M02-body-P051)
- [Kasiṇa hư không (ākāsakasiṇa) / The space kasiṇa (ākāsakasiṇa)](#M02-body-P052)
- [Lấy và giữ tướng hư không / Taking the space kasiṇa sign](#M02-body-P053)
- [Mười kasiṇa / Mastering the ten kasiṇas](#M02-body-P054)
- [Rút lấy tinh hoa tu tập từ các cảnh / The fruits of kasiṇa practice](#M02-body-P055)
- [Thiền vô sắc giới — Thiền Không vô biên xứ / The immaterial jhānas](#M02-body-P057)
- [Vượt qua sắc — Giải thích thêm / Seeing the drawbacks of materiality](#M02-body-P058)
- [Ví dụ thế gian để so sánh / Why the kasiṇa sign is also surmounted](#M02-body-P059)
- [Công việc cần thực hành / Preparing to develop infinite space](#M02-body-P060)
- [Từ tứ thiền đến cảnh hư không vô biên / Removing the earth kasiṇa](#M02-body-P061)
- [Loại bỏ kasiṇa — Lời khuyên / The space left by the kasiṇa](#M02-body-P062)
- [Tiến đến thiền Không vô biên xứ / Developing the sign of space](#M02-body-P063)
- [Tâm thiền Không vô biên xứ — Điểm nhấn mạnh / Absorption in the base of infinite space](#M02-body-P064)
- [Ý nghĩa công thức vượt qua các tưởng về sắc / Surmounting perceptions of form](#M02-body-P065)
- [Thiền Thức vô biên xứ (viññāṇañcāyatanajhāna) / The base of infinite consciousness](#M02-body-P066)
- [Chú ý đối tượng chân đế / Absorption with consciousness as object](#M02-body-P067)
- [Cách hướng đến Thức vô biên xứ / Advice on discerning the object](#M02-body-P068)
- [Vượt qua Không vô biên xứ / What is surmounted in this attainment](#M02-body-P069)
- [Thức vô biên / Why consciousness is called infinite](#M02-body-P070)
- [Thiền Vô sở hữu xứ (ākiñcaññāyatanajhāna) / The base of nothingness](#M02-body-P071)
- [Lấy sự không có của thức làm cảnh / Attending to absence](#M02-body-P072)
- [“Không có”, “rỗng vắng”, “trống không” / Absorption in the base of nothingness](#M02-body-P073)
- [Một điểm đặc biệt cần nhớ / Seeing only the absence](#M02-body-P074)
- [Ý nghĩa của “natthi, suññaṃ, vivittaṃ” / Nothing, empty, secluded](#M02-body-P075)
- [Giải thích ví dụ về giảng đường / The meaning of disappearance](#M02-body-P076)
- [Thành tựu Vô sở hữu xứ / Attaining the base of nothingness](#M02-body-P077)
- [Ý nghĩa tên Vô sở hữu xứ / What “there is nothing” means](#M02-body-P078)
- [Thiền Phi tưởng phi phi tưởng xứ / Neither perception nor non-perception](#M02-body-P079)
- [Trình tự tu tập Phi tưởng phi phi tưởng xứ / Preparing for the fourth immaterial attainment](#M02-body-P080)
- [Lấy tâm Vô sở hữu xứ làm cảnh / Absorption in neither perception nor non-perception](#M02-body-P081)
- [Thành tựu Phi tưởng phi phi tưởng xứ / Attaining neither perception nor non-perception](#M02-body-P082)
- [Tịch tịnh và cao quý / Attending to the peaceful and sublime](#M02-body-P083)
- [Khen ngợi nhưng không dừng lại nơi thiền trước / In what sense nothingness is peaceful](#M02-body-P084)
- [Hỏi và đáp — Ví dụ thế gian / How a peaceful attainment is surmounted](#M02-body-P085)
- [Phi tưởng và phi phi tưởng / The function of perception in the highest attainment](#M02-body-P086)
- [Minh sát đối với chứng đắc cực vi tế / The limits of insight into this attainment](#M02-body-P087)
- [Các tầng thiền càng lên càng vi tế / The increasing subtlety of the immaterial attainments](#M02-body-P088)
- [Những kasiṇa còn lại / The remaining kasiṇas](#M02-body-P089)
- [Kết thúc phần kasiṇa — Bốn đề mục bảo hộ / From the kasiṇas to the protective meditations](#M02-body-P090)
- [Bốn đề mục bảo hộ — Tu tập tâm từ / The divine abidings: loving-kindness](#M02-body-P091)
- [Những đối tượng không dùng lúc khởi đầu tâm từ / Whom to choose for developing loving-kindness](#M02-body-P092)
- [Khởi đầu tu tập tâm từ đối với bản thân / Beginning with oneself](#M02-body-P093)
- [Bản thân làm ví dụ — Bốn lời nguyện / Wishes for one's own well-being](#M02-body-P094)
- [Hướng đến một người thân ái đáng kính / Turning towards a dear and respected person](#M02-body-P095)
- [Bốn lời nguyện hướng đến người đáng kính / Directing loving-kindness to a respected person](#M02-body-P096)
- [Mỗi lời nguyện đều tu tập đến tam thiền / Developing each wish to the third jhāna](#M02-body-P097)
- [Lần lượt hướng đến các hạng người / Extending the practice to other individuals](#M02-body-P098)
- [Phá bỏ ranh giới giữa các hạng người / Breaking down the barriers](#M02-body-P099)
- [Tâm từ bình đẳng đối với bốn hạng người / Making loving-kindness equal](#M02-body-P100)
- [Luyện tập phá bỏ ranh giới / Practising the breaking down of barriers](#M02-body-P101)
- [Ba cách trải tâm từ giải thoát / The three modes of pervading with loving-kindness](#M02-body-P102)
- [Năm nhóm không giới hạn — Bảy nhóm có giới hạn / Groups for unspecified and specified pervasion](#M02-body-P103)
- [Cách thực hành trải tâm từ theo nhóm / The forty-eight ways of developing loving-kindness](#M02-body-P104)
- [Bốn lời nguyện cho tất cả chúng sinh / Practising each of the four wishes](#M02-body-P105)
- [Mười phương trải tâm từ giải thoát / Extending loving-kindness in the ten directions](#M02-body-P106)
- [Năm trăm hai mươi tám cách trải tâm từ / The 528 ways of pervading with loving-kindness](#M02-body-P107)
- [Mười một lợi ích của tâm từ / The eleven benefits of loving-kindness](#M02-body-P108)
- [Mười một lợi ích được kể riêng / The benefits of practising loving-kindness](#M02-body-P109)
- [Tu tập tâm bi (karuṇābhāvanā) / Developing compassion](#M02-body-P110)
- [Trải tâm bi sau khi phá bỏ ranh giới / Extending compassion to all beings](#M02-body-P111)
- [Tu tập tâm hỷ (muditābhāvanā) / Developing appreciative joy](#M02-body-P112)
- [Trải tâm hỷ theo 132 cách / Extending appreciative joy](#M02-body-P113)
- [Tu tập tâm xả (upekkhābhāvanā) / Developing equanimity](#M02-body-P114)
- [Thấy sự tịch tịnh của phạm trú xả / Seeing the advantages of equanimity](#M02-body-P115)
- [Chúng sinh có nghiệp là của mình / Beings are owners of their kamma](#M02-body-P116)
- [Nền tảng để đạt tứ thiền phạm trú xả / Practising equanimity with different people](#M02-body-P117)
- [Tu tập bốn phạm trú trên từng đối tượng / Breaking down the barriers in equanimity](#M02-body-P118)
- [Một câu hỏi về tứ thiền phạm trú xả / The 132 ways of pervading with equanimity](#M02-body-P119)
- [Cùng lấy chế định chúng sinh làm cảnh / The object must be the same](#M02-body-P120)
- [Tâm từ: đặc tính, phận sự, biểu hiện và nhân gần / Characteristic, function, manifestation, and proximate cause of loving-kindness](#M02-body-P121)
- [Tâm bi: đặc tính, phận sự, biểu hiện và nhân gần / Characteristic, function, manifestation, and proximate cause of compassion](#M02-body-P122)
- [Tâm hỷ: đặc tính, phận sự, biểu hiện và nhân gần / Characteristic, function, manifestation, and proximate cause of appreciative joy](#M02-body-P123)
- [Tâm xả: đặc tính, phận sự, biểu hiện và nhân gần / Characteristic, function, manifestation, and proximate cause of equanimity](#M02-body-P124)
- [Giải thoát khỏi các phiền não / The divine abidings as escapes from defilements](#M02-body-P125)
- [Bốn phạm trú chế ngự pháp đối nghịch / Dwelling free of opposing defilements](#M02-body-P126)
- [Đề mục niệm Ân đức Phật (buddhānussati) / Recollection of the Buddha](#M02-body-P127)
- [Cách tu tập ân đức Arahaṃ / Developing the recollection of Arahaṃ](#M02-body-P128)
- [Đề mục bất tịnh (asubha) / Meditation on foulness](#M02-body-P129)
- [Từ học tướng bất tịnh đến sơ thiền / From the learning sign to first jhāna](#M02-body-P130)
- [Đề mục niệm chết (maraṇassati, maraṇānussati) / Mindfulness of death](#M02-body-P131)
- [Sự chấm dứt của mạng quyền / Taking the cutting off of the life faculty as object](#M02-body-P132)
- [Quán từ hình ảnh tử thi đến sự chấm dứt mạng quyền / Discerning the cessation of the life faculty](#M02-body-P133)
- [Cảnh niệm chết và bốn đề mục bảo hộ / The four protective meditation subjects](#M02-body-P134)
- [Chọn đề mục phù hợp với trạng thái tâm / Choosing a subject to counter a hindrance](#M02-body-P135)
- [Kết phần thiền chỉ và lời nguyện / Conclusion of the section on tranquillity meditation](#M02-body-P136)
- [Chỉ mục theo thứ tự chữ Miến — 137 / Index in Burmese alphabetical order — 137](#M02-index-P001)
- [Chỉ mục theo thứ tự chữ Miến — 138 / Index in Burmese alphabetical order — 138](#M02-index-P002)
- [Chỉ mục theo thứ tự chữ Miến — 139 / Index in Burmese alphabetical order — 139](#M02-index-P003)
- [Chỉ mục theo thứ tự chữ Miến — 140 / Index in Burmese alphabetical order — 140](#M02-index-P004)
- [Chỉ mục theo thứ tự chữ Miến — 141 / Index in Burmese alphabetical order — 141](#M02-index-P005)
- [Chỉ mục theo thứ tự chữ Miến — 142 / Index in Burmese alphabetical order — 142](#M02-index-P006)

<a id="M02-cover-P001"></a>
## Bìa trước và bìa sau / Volume 2 — Subjects of Tranquillity Meditation — B
Bìa / Cover

**VI**
Nibbānagāminipaṭipadā — Pháp hành đưa đến Niết-bàn (bản lược). Cuốn 2. Phần pháp hành thiền chỉ (Samatha kammaṭṭhāna) — B. Pa-Auk Tawya Sayadaw.

**EN**
Nibbānagāminipaṭipadā — The Practice Leading to Nibbāna (Abridged). Volume 2. Subjects of Tranquillity Meditation (Samatha kammaṭṭhāna) — B. Pa-Auk Tawya Sayadaw.

**VI**
Hãy tu tập định

**EN**
DEVELOP CONCENTRATION

**VI**
Samādhiṃ, bhikkhave, bhāvetha. Samāhito, bhikkhave, bhikkhu yathābhūtaṃ pajānāti. Kiñca yathābhūtaṃ pajānāti? “Idaṃ dukkhan”ti yathābhūtaṃ pajānāti. “Ayaṃ dukkhasamudayo”ti yathābhūtaṃ pajānāti. “Ayaṃ dukkhanirodho”ti yathābhūtaṃ pajānāti. “Ayaṃ dukkhanirodhagāminī paṭipadā”ti yathābhūtaṃ pajānāti. Samādhiṃ, bhikkhave, bhāvetha. Samāhito, bhikkhave, bhikkhu yathābhūtaṃ pajānāti. (Saṃ, 3, 363.)

**EN**
Samādhiṃ, bhikkhave, bhāvetha. Samāhito, bhikkhave, bhikkhu yathābhūtaṃ pajānāti. Kiñca yathābhūtaṃ pajānāti? “Idaṃ dukkhan”ti yathābhūtaṃ pajānāti. “Ayaṃ dukkhasamudayo”ti yathābhūtaṃ pajānāti. “Ayaṃ dukkhanirodho”ti yathābhūtaṃ pajānāti. “Ayaṃ dukkhanirodhagāminī paṭipadā”ti yathābhūtaṃ pajānāti. Samādhiṃ, bhikkhave, bhāvetha. Samāhito, bhikkhave, bhikkhu yathābhūtaṃ pajānāti. (Saṃ, 3, 363.)

**VI**
Này các tỳ-khưu, hãy tu tập định. Này các tỳ-khưu, vị tỳ-khưu có định biết rõ như thật, không sai lệch. Vị ấy biết rõ như thật điều gì?

**EN**
Bhikkhus, develop concentration. A bhikkhu who is concentrated understands things as they really are, without distortion. What does he understand as it really is?

**VI**
Vị ấy biết rõ như thật: “Đây là Khổ Thánh đế”. Vị ấy biết rõ như thật: “Đây là Tập Thánh đế, nguyên nhân sinh khổ”. Vị ấy biết rõ như thật: “Đây là Diệt Thánh đế, Niết-bàn, nơi khổ diệt”. Vị ấy biết rõ như thật: “Đây là Đạo Thánh đế, pháp hành dẫn đến nơi khổ diệt — Niết-bàn”.

**EN**
He understands as it really is, “This is the Noble Truth of Suffering.” He understands as it really is, “This is the Noble Truth of the Origin of Suffering.” He understands as it really is, “This is the Noble Truth of the Cessation of Suffering—Nibbāna, where suffering ceases.” He understands as it really is, “This is the Noble Truth of the Path Leading to the Cessation of Suffering—Nibbāna.”

**VI**
Này các tỳ-khưu, hãy an lập định. Này các tỳ-khưu, vị tỳ-khưu có định biết rõ như thật, không sai lệch. (Saṃ, 3, 363.)

**EN**
Bhikkhus, establish concentration. A bhikkhu who is concentrated understands things as they really are, without distortion. (Saṃyutta Nikāya 3, p. 363.)

**Ghi chú / Note**
Bìa là ảnh JPG rời, không có trang PDF. Số dẫn giữ theo bìa; chưa đối chiếu độc lập ấn bản Saṃyutta Nikāya.


<a id="M02-front-P001"></a>
## Trang nhan đề / Title page
Đầu sách / Front matter - 1

**VI**
Nibbānagāminipaṭipadā

**EN**
Nibbānagāminipaṭipadā

**VI**
Pháp hành đưa đến Niết-bàn (bản lược) — Cuốn 2

**EN**
The Practice Leading to Nibbāna (Abridged) — Volume 2

**VI**
Phần pháp hành thiền chỉ (Samatha kammaṭṭhāna) — B

**EN**
Subjects of Tranquillity Meditation (Samatha kammaṭṭhāna) — B

**VI**
Pa-Auk Tawya Sayadaw

**EN**
Pa-Auk Tawya Sayadaw


<a id="M02-front-P002"></a>
## Pháp thí và lời nguyện / Dhamma verses and aspiration
Đầu sách / Front matter - 2

**VI**
Sabbadānaṃ dhammadānaṃ jināti. Sabbarasaṃ dhammaraso jināti. Sabbaratiṃ dhammarati jināti. Taṇhakkhayo sabbadukkhaṃ jināti.

**EN**
Sabbadānaṃ dhammadānaṃ jināti. Sabbarasaṃ dhammaraso jināti. Sabbaratiṃ dhammarati jināti. Taṇhakkhayo sabbadukkhaṃ jināti.

**VI**
Pháp thí thắng mọi sự bố thí. Vị của Pháp thắng mọi hương vị. Niềm vui trong Pháp thắng mọi niềm vui. Sự diệt tận ái thắng mọi khổ đau.

**EN**
The gift of Dhamma surpasses every gift. The taste of Dhamma surpasses every taste. Delight in Dhamma surpasses every delight. The destruction of craving overcomes all suffering.

**VI**
Ciraṃ tiṭṭhatu saddhammo, dhamme hontu sagāravā.

**EN**
Ciraṃ tiṭṭhatu saddhammo, dhamme hontu sagāravā.

**VI**
Mong Chánh pháp của Đức Phật tồn tại lâu dài, cho đến tận cùng. Mong mọi người kính trọng ba loại Chánh pháp.

**EN**
May the Buddha's true Dhamma endure for a long time, until its final limit. May all beings honour the three kinds of true Dhamma.


<a id="M02-front-P003"></a>
## Mục lục — trang က / Table of contents — page 1
Đầu sách / Front matter - 3

**VI**
Namo tassa bhagavato arahato sammāsambuddhassa. — Kính lễ Đức Thế Tôn, bậc A-la-hán, bậc Chánh Đẳng Giác.

**EN**
Namo tassa bhagavato arahato sammāsambuddhassa. — Homage to the Blessed One, the Arahant, the Perfectly Enlightened One.

**VI**
Phần pháp hành thiền chỉ — B. Mục lục. Đề mục — Trang.

**EN**
Subjects of Tranquillity Meditation — B. Table of contents. Subject — Page.

**VI**
Tác ý bất tịnh và đề mục bộ xương — trang 1

**EN**
Attention to repulsiveness and the skeleton meditation subject — page 1

**VI**
Ba mươi hai thân phần — trang 2

**EN**
The thirty-two parts of the body — page 2

**VI**
Hai mươi thân phần có địa đại trội — trang 2

**EN**
Twenty body parts with predominant earth element — page 2

**VI**
Mười hai thân phần có thủy đại trội — trang 3

**EN**
Twelve body parts with predominant water element — page 3

**VI**
Ba con đường — trang 4

**EN**
Three paths — page 4

**VI**
Tác ý bất tịnh (paṭikūlamanasikāra) — trang 5

**EN**
Attention to repulsiveness (paṭikūlamanasikāra) — page 5

**VI**
Lời giải thích của Phụ chú giải gốc (Mūlaṭīkā) — trang 7

**EN**
The Mūlaṭīkā explanation — page 7

**VI**
Đề mục bộ xương — trang 9

**EN**
The skeleton meditation subject — page 9

**VI**
Học tướng và tương tợ tướng — trang 10

**EN**
The learning sign and counterpart sign — page 10

**VI**
Năm thiền chi — trang 11

**EN**
The five jhāna factors — page 11

**VI**
Hỷ và thọ hỷ (pīti, somanassa) — trang 11

**EN**
Joy and mental pleasant feeling (pīti, somanassa) — page 11

**VI**
Điều cần ghi nhớ — trang 12

**EN**
A point to bear in mind — page 12

**VI**
Bên trong và bên ngoài (ajjhatta, bahiddha) — trang 13

**EN**
Internally and externally (ajjhatta, bahiddha) — page 13

**VI**
Mười kasiṇa — Tám chứng đắc thiền định — trang 15

**EN**
Ten kasiṇas — eight attainments — page 15

**VI**
Kasiṇa màu sắc (vaṇṇakasiṇa) — trang 15

**EN**
Colour kasiṇas (vaṇṇakasiṇa) — page 15

**VI**
Bốn loại kasiṇa màu sắc — trang 15

**EN**
Four kinds of colour kasiṇa — page 15

**VI**
Thiền thắng xứ (abhibhāyatanajhāna) — trang 16

**EN**
Jhāna of the bases of mastery (abhibhāyatanajhāna) — page 16

**VI**
Bên trong và bên ngoài — trang 18

**EN**
Internally and externally — page 18

**VI**
Chuyển sang kasiṇa trắng — trang 21

**EN**
Proceeding to the white kasiṇa — page 21

**Ghi chú / Note**
Giữ toàn bộ dòng và số trang của mục lục. Phân cấp điều hướng là biên tập; các mục chính văn sau trang 15 chưa dịch.


<a id="M02-front-P004"></a>
## Mục lục — trang ခ / Table of contents — page 2
Đầu sách / Front matter - 4

**VI**
Năm thiền chi — trang 26

**EN**
The five jhāna factors — page 26

**VI**
Phương pháp bốn thiền — trang 27

**EN**
The fourfold-jhāna method — page 27

**VI**
Phương pháp năm thiền — trang 27

**EN**
The fivefold-jhāna method — page 27

**VI**
Kasiṇa xanh (nīlakasiṇa) — trang 29

**EN**
The blue kasiṇa (nīlakasiṇa) — page 29

**VI**
Kasiṇa vàng (pītakasiṇa) — trang 32

**EN**
The yellow kasiṇa (pītakasiṇa) — page 32

**VI**
Hoa padauk và sắc vàng óng — trang 33

**EN**
Padauk flowers and shining gold — page 33

**VI**
Kasiṇa đỏ (lohitakasiṇa) — trang 34

**EN**
The red kasiṇa (lohitakasiṇa) — page 34

**VI**
Những tinh hoa đưa đến A-la-hán quả — trang 35

**EN**
Essences leading to Arahantship — page 35

**VI**
Kasiṇa đất (paṭhavīkasiṇa) — trang 37

**EN**
The earth kasiṇa (paṭhavīkasiṇa) — page 37

**VI**
Khiếm khuyết có thể gặp — trang 39

**EN**
Possible defects — page 39

**VI**
Học tướng và tương tợ tướng — trang 40

**EN**
The learning sign and counterpart sign — page 40

**VI**
Một số hành giả — trang 42

**EN**
Some meditators — page 42

**VI**
Kasiṇa nước (āpokasiṇa) — trang 42

**EN**
The water kasiṇa (āpokasiṇa) — page 42

**VI**
Học tướng và tương tợ tướng — trang 44

**EN**
The learning sign and counterpart sign — page 44

**VI**
Kasiṇa lửa (tejokasiṇa) — trang 45

**EN**
The fire kasiṇa (tejokasiṇa) — page 45

**VI**
Không tác ý màu sắc và đặc tính — trang 46

**EN**
Do not attend to colour or characteristics — page 46

**VI**
Học tướng và tương tợ tướng — trang 47

**EN**
The learning sign and counterpart sign — page 47

**VI**
Kasiṇa gió (vāyokasiṇa) — trang 48

**EN**
The air kasiṇa (vāyokasiṇa) — page 48

**VI**
Học tướng và tương tợ tướng — trang 49

**EN**
The learning sign and counterpart sign — page 49

**VI**
Kasiṇa ánh sáng (ālokakasiṇa) — trang 49

**EN**
The light kasiṇa (ālokakasiṇa) — page 49

**VI**
Học tướng và tương tợ tướng — trang 51

**EN**
The learning sign and counterpart sign — page 51

**VI**
Đoạn trừ hôn trầm và thụy miên — trang 51

**EN**
Dispelling sloth and torpor — page 51

**VI**
Kasiṇa hư không (ākāsakasiṇa) — trang 52

**EN**
The space kasiṇa (ākāsakasiṇa) — page 52

**VI**
Học tướng và tương tợ tướng — trang 53

**EN**
The learning sign and counterpart sign — page 53

**VI**
Mười kasiṇa — trang 54

**EN**
The ten kasiṇas — page 54

**Ghi chú / Note**
Giữ toàn bộ dòng và số trang của mục lục. Phân cấp điều hướng là biên tập; các mục chính văn sau trang 15 chưa dịch.


<a id="M02-front-P005"></a>
## Mục lục — trang ဂ / Table of contents — page 3
Đầu sách / Front matter - 5

**VI**
Phần thiền vô sắc giới — trang 57

**EN**
The immaterial jhānas — page 57

**VI**
Thiền Không vô biên xứ (ākāsānañcāyatanajhāna) — trang 57

**EN**
Jhāna of the base of boundless space (ākāsānañcāyatanajhāna) — page 57

**VI**
Giải thích thêm — trang 58

**EN**
Further explanation — page 58

**VI**
Ví dụ thế gian để so sánh — trang 59

**EN**
An analogy from everyday life — page 59

**VI**
Công việc cần thực hành — trang 60

**EN**
The work to be done — page 60

**VI**
Lời khuyên — trang 62

**EN**
Advice — page 62

**VI**
Tiến đến thiền Không vô biên xứ — trang 63

**EN**
Proceeding to the base of boundless space — page 63

**VI**
Điểm nhấn mạnh đặc biệt — trang 64

**EN**
A point of particular emphasis — page 64

**VI**
Thiền Thức vô biên xứ (viññāṇañcāyatanajhāna) — trang 66

**EN**
Jhāna of the base of boundless consciousness (viññāṇañcāyatanajhāna) — page 66

**VI**
Ghi nhớ rằng cảnh là chân đế — trang 67

**EN**
Remember that the object is ultimate reality — page 67

**VI**
Một khó khăn — trang 68

**EN**
A difficulty — page 68

**VI**
Người đang tiến đến thiền Thức vô biên xứ — trang 68

**EN**
One proceeding to the base of boundless consciousness — page 68

**VI**
Ý nghĩa cốt yếu — trang 69

**EN**
The essential meaning — page 69

**VI**
Anantaṃ viññāṇaṃ — trang 70

**EN**
Anantaṃ viññāṇaṃ — page 70

**VI**
Thiền Vô sở hữu xứ (ākiñcaññāyatanajhāna) — trang 71

**EN**
Jhāna of the base of nothingness (ākiñcaññāyatanajhāna) — page 71

**VI**
Điểm đặc biệt cần ghi nhớ — trang 74

**EN**
A distinctive point to bear in mind — page 74

**VI**
Natthi — natthi; suññaṃ — suññaṃ; vivittaṃ — vivittaṃ — trang 75

**EN**
Natthi — natthi; suññaṃ — suññaṃ; vivittaṃ — vivittaṃ — page 75

**VI**
Vận dụng ví dụ thế gian để so sánh — trang 76

**EN**
Applying an analogy from everyday life — page 76

**VI**
Đã đạt thiền Vô sở hữu xứ — trang 77

**EN**
Having attained the base of nothingness — page 77

**VI**
Viññāṇañcāyatanaṃ samatikkamma — trang 77

**EN**
Viññāṇañcāyatanaṃ samatikkamma — page 77

**VI**
Natthi kiñci — Không có gì cả — trang 77

**EN**
Natthi kiñci — There is nothing — page 77

**VI**
Thiền Vô sở hữu xứ là gì — trang 78

**EN**
What is jhāna of the base of nothingness? — page 78

**VI**
Thiền Phi tưởng phi phi tưởng xứ (nevasaññānāsaññāyatanajhāna) — trang 79

**EN**
Jhāna of the base of neither-perception-nor-non-perception (nevasaññānāsaññāyatanajhāna) — page 79

**VI**
Trình tự thực hành — trang 80

**EN**
The procedure of practice — page 80

**VI**
Đã đạt thiền Phi tưởng phi phi tưởng xứ — trang 82

**EN**
Having attained the base of neither-perception-nor-non-perception — page 82

**VI**
Ākiñcaññāyatanaṃ samatikkamma — trang 82

**EN**
Ākiñcaññāyatanaṃ samatikkamma — page 82

**Ghi chú / Note**
Giữ toàn bộ dòng và số trang của mục lục. Phân cấp điều hướng là biên tập; các mục chính văn sau trang 15 chưa dịch.


<a id="M02-front-P006"></a>
## Mục lục — trang ဃ / Table of contents — page 4
Đầu sách / Front matter - 6

**VI**
Thật tịch tịnh, thật thù thắng — trang 83

**EN**
Peaceful and sublime — page 83

**VI**
Hỏi và đáp — trang 85

**EN**
Questions and answers — page 85

**VI**
Ví dụ thế gian để so sánh — trang 85

**EN**
An analogy from everyday life — page 85

**VI**
Nevasaññā — nāsaññā — trang 86

**EN**
Nevasaññā — nāsaññā — page 86

**VI**
Sự thù thắng dần qua từng tầng — trang 88

**EN**
Increasing refinement through successive attainments — page 88

**VI**
Phải lấy làm cảnh vì không thể tránh khỏi — trang 88

**EN**
Taking it as object because it cannot be avoided — page 88

**VI**
Những kasiṇa còn lại — bản in không ghi số trang.

**EN**
The remaining kasiṇas — no page number printed in the source.

**VI**
Phần bốn đề mục bảo hộ — trang 91

**EN**
The four protective meditation subjects — page 91

**VI**
Phần phạm trú — Pháp tu tâm từ (mettābhāvanā) — trang 91

**EN**
The divine abidings — developing loving-kindness (mettābhāvanā) — page 91

**VI**
Người cùng giới được yêu kính (piya, garu, bhāvanīya) — trang 95

**EN**
A dear, respected, and esteemed person of the same sex (piya, garu, bhāvanīya) — page 95

**VI**
Phá bỏ ranh giới giữa các hạng người (sīmāsambheda) — trang 99

**EN**
Breaking down the boundaries between persons (sīmāsambheda) — page 99

**VI**
Phương thức tu tập tâm từ — trang 104

**EN**
The method of developing loving-kindness — page 104

**VI**
Mười một lợi ích của tâm từ — trang 108

**EN**
Eleven benefits of loving-kindness — page 108

**VI**
Tu tập tâm bi (karuṇābhāvanā) — trang 110

**EN**
Developing compassion (karuṇābhāvanā) — page 110

**VI**
Tu tập tâm hỷ (muditābhāvanā) — trang 112

**EN**
Developing appreciative joy (muditābhāvanā) — page 112

**VI**
Tu tập tâm xả (upekkhābhāvanā) — trang 114

**EN**
Developing equanimity (upekkhābhāvanā) — page 114

**VI**
Một câu hỏi nên hỏi — trang 119

**EN**
A question to ask — page 119

**VI**
Đặc tính — Phận sự — Biểu hiện — Nhân gần — trang 121

**EN**
Characteristic — function — manifestation — proximate cause — page 121

**VI**
Giải thoát khỏi các phiền não — trang 125

**EN**
Freedom from defilements — page 125

**VI**
Đề mục niệm ân đức Phật (buddhānussati) — trang 127

**EN**
Recollection of the Buddha (buddhānussati) — page 127

**VI**
Đề mục bất tịnh (asubha) — trang 129

**EN**
Foulness meditation (asubha) — page 129

**VI**
Đề mục niệm sự chết (maraṇassati — maraṇānussati) — trang 131

**EN**
Recollection of death (maraṇassati — maraṇānussati) — page 131

**VI**
Sự chấm dứt của mạng quyền — trang 132

**EN**
The cutting off of the life faculty — page 132

**Ghi chú / Note**
Giữ toàn bộ dòng và số trang của mục lục. Phân cấp điều hướng là biên tập; các mục chính văn sau trang 15 chưa dịch.


<a id="M02-body-P001"></a>
## Quán bất tịnh và đề mục bộ xương / Attention to repulsiveness and the skeleton meditation subject
Miến / Burmese 1

**VI**
Phần pháp hành thiền chỉ — B

**EN**
SUBJECTS OF TRANQUILLITY MEDITATION — B

**VI**
Namo tassa bhagavato arahato sammāsambuddhassa.

**EN**
Namo tassa bhagavato arahato sammāsambuddhassa.

**VI**
Kính lễ Đức Thế Tôn, bậc A-la-hán, bậc Chánh Đẳng Giác.

**EN**
Homage to the Blessed One, the Arahant, the Perfectly Enlightened One.

**VI**
Trong phần pháp hành thiền chỉ thứ hai này, chúng tôi xin trình bày tiếp cách tu tập bốn đề mục bảo hộ trước khi chuyển sang minh sát. Qua kinh nghiệm của phần lớn hành giả, tu tập bốn đề mục bảo hộ sẽ dễ dàng hơn sau khi đã tu tập kasiṇa trắng, hoặc mười kasiṇa và tám chứng đắc thiền định. Việc ấy cũng hỗ trợ rất nhiều cho phương pháp tu tập tứ đại được trình bày chi tiết. Vì vậy, trước khi trình bày bốn đề mục bảo hộ, chúng tôi sẽ trình bày cách quán 32 thân phần, cách quán bộ xương, cách quán kasiṇa trắng cùng những kasiṇa khác, và cách đạt tám chứng đắc trên mỗi kasiṇa.

**EN**
ATTENTION TO REPULSIVENESS AND THE SKELETON MEDITATION SUBJECT
In this second part of tranquillity meditation, I shall continue by briefly explaining how to develop the four protective meditation subjects before proceeding to insight. For most meditators, developing those protective subjects is easier after developing the white kasiṇa, or the ten kasiṇas and eight attainments. This also greatly supports the detailed method of four-elements meditation. Since there are also many methods of discerning the meditation subject of the four elements, I shall first describe how to discern the thirty-two parts of the body, the skeleton meditation subject, and how to proceed from the skeleton to the white kasiṇa and then, successively, through the eight attainments on each kasiṇa.

**VI**
Khi năng lực ánh sáng trở nên rực rỡ, sáng chói, trước hết hãy an lập lại định bằng niệm hơi thở cho đến khi đạt tứ thiền. Khi năng lực ánh sáng đã rất tốt, hãy dùng sự hỗ trợ của ánh sáng ấy để quán 32 thân phần. Khi quán, hãy chia 20 thân phần có địa đại trội thành từng nhóm năm, và 12 thân phần có thủy đại trội thành từng nhóm sáu. Mỗi lần quán một nhóm. Khi có thể quán rõ trong tâm, hãy luyện tập để thấy 32 thân phần rõ ràng, sáng tỏ, như đang nhìn thấy khuôn mặt mình trong tấm gương sạch. Trong khi quán như vậy, nếu năng lực ánh sáng mờ đi khiến các thân phần đang quán không còn hiện rõ, hãy trở lại an lập định bằng tứ thiền niệm hơi thở…

**EN**
Re-establish ānāpāna fourth-jhāna concentration until the light of wisdom shines brilliantly. When its light is very strong, use it to discern the thirty-two parts of the body. Divide the twenty body parts with predominant earth element into four groups of five, and the twelve with predominant water element into two groups of six. Begin with one group at a time. When, looking in a clear mirror, you can see your own face distinctly, you should be able to see the thirty-two parts just as distinctly. If the light of knowledge fades and the body parts become unclear while discerning them, re-establish ānāpāna fourth-jhāna concentration…


<a id="M02-body-P002"></a>
## Ba mươi hai thân phần — Hai mươi thân phần thuộc địa đại / The thirty-two parts of the body: predominant earth element
Miến / Burmese 2

**VI**
…rồi tiếp tục quán thân phần. Mỗi khi năng lực ánh sáng mờ đi, hãy dùng cách này.

**EN**
…and when the light becomes strong, discern the body parts again. Use the light of knowledge in this way.

**VI**
Ba mươi hai thân phần (32 koṭṭhāsa)

**EN**
THE THIRTY-TWO PARTS OF THE BODY

**VI**
Hai mươi thân phần có địa đại trội (paṭhavīkoṭṭhāsa):

**EN**
TWENTY PARTS WITH PREDOMINANT EARTH ELEMENT (PAṬHAVĪ)

**VI**
1. Kesā — tóc — 44 sắc.
2. Lomā — lông — 44 sắc.
3. Nakhā — móng chân, móng tay — 44 sắc.
4. Dantā — răng — 44 sắc.
5. Taco — da, gồm da dày và da mỏng — 44 sắc.
Nhóm tacapañcaka: năm thân phần kết thúc bằng da.

**EN**
1. Kesā — head hair — 44 material phenomena.
2. Lomā — body hair — 44 material phenomena.
3. Nakhā — nails — 44 material phenomena.
4. Dantā — teeth — 44 material phenomena.
5. Taco — skin, the outer skin and inner skin — 44 material phenomena.
[The skin pentad: tacapañcaka.]

**VI**
6. Maṃsaṃ — thịt — 44 sắc.
7. Nhāru — gân — 44 sắc.
8. Aṭṭhi — xương — 44 sắc.
9. Aṭṭhimiñjaṃ — tủy xương — 44 sắc.
10. Vakkaṃ — thận — 44 sắc.
Nhóm vakkapañcaka: năm thân phần kết thúc bằng thận.

**EN**
6. Maṃsaṃ — flesh — 44 material phenomena.
7. Nhāru — sinews — 44 material phenomena.
8. Aṭṭhi — bones — 44 material phenomena.
9. Aṭṭhimiñjaṃ — bone marrow — 44 material phenomena.
10. Vakkaṃ — kidneys — 44 material phenomena.
[The kidney pentad: vakkapañcaka.]

**VI**
11. Hadayaṃ — tim — 44 sắc.
12. Yakanaṃ — gan — 44 sắc.
13. Kilomakaṃ — màng — 44 sắc.
14. Pihakaṃ — lá lách — 44 sắc.
15. Papphāsaṃ — phổi — 44 sắc.
Nhóm papphāsapañcaka: năm thân phần kết thúc bằng phổi.

**EN**
11. Hadayaṃ — heart — 44 material phenomena.
12. Yakanaṃ — liver — 44 material phenomena.
13. Kilomakaṃ — membranes — 44 material phenomena.
14. Pihakaṃ — spleen — 44 material phenomena.
15. Papphāsaṃ — lungs — 44 material phenomena.
[The lung pentad: papphāsapañcaka.]

**VI**
16. Antaṃ — ruột lớn — 44 sắc.
17. Antaguṇaṃ — ruột nhỏ, các đoạn ruột cuộn — 44 sắc.
18. Udariyaṃ — vật thực mới, chưa tiêu — 8 sắc.
19. Karīsaṃ — vật thực cũ, phân — 8 sắc.
20. Matthaluṅgaṃ — não — 44 sắc.
Nhóm matthaluṅgapañcaka: năm thân phần kết thúc bằng não.

**EN**
16. Antaṃ — large intestine — 44 material phenomena.
17. Antaguṇaṃ — small intestine, the intestinal coils — 44 material phenomena.
18. Udariyaṃ — undigested food — 8 material phenomena.
19. Karīsaṃ — faeces, digested food — 8 material phenomena.
20. Matthaluṅgaṃ — brain — 44 material phenomena.
[The brain pentad: matthaluṅgapañcaka.]


<a id="M02-body-P003"></a>
## Mười hai thân phần thuộc thủy đại / Twelve parts with predominant water element
Miến / Burmese 3

**VI**
Mười hai thân phần có thủy đại trội (āpokoṭṭhāsa):

**EN**
TWELVE PARTS WITH PREDOMINANT WATER ELEMENT (ĀPO)

**VI**
1. Pittaṃ — mật, gồm mật trong túi mật và mật ngoài túi — 44 sắc.
2. Semhaṃ — đàm — 44 sắc.
3. Pubbo — mủ, sắc do thời tiết sinh (utuja) — 8 sắc.
4. Lohitaṃ — máu, gồm máu đọng và máu trong mạch — 44 sắc.
5. Sedo — mồ hôi, sắc do tâm và thời tiết sinh (cittaja + utuja) — 16 sắc.
6. Medo — mỡ đặc — 44 sắc.
Nhóm medachakka: sáu thân phần kết thúc bằng mỡ đặc.

**EN**
1. Pittaṃ — bile, contained in the gall bladder and free bile — 44 material phenomena.
2. Semhaṃ — phlegm — 44.
3. Pubbo — pus, temperature-produced (utuja) — 8.
4. Lohitaṃ — blood, contained blood and circulating blood — 44.
5. Sedo — sweat, consciousness-produced and temperature-produced (cittaja + utuja) — 16.
6. Medo — fat — 44.
[The fat hexad: medachakka.]

**VI**
7. Assu — nước mắt, sắc do tâm và thời tiết sinh — 16 sắc.
8. Vasā — mỡ lỏng — 44 sắc.
9. Kheḷo — nước bọt, sắc do tâm và thời tiết sinh — 16 sắc.
10. Siṅghānikā — nước mũi, sắc do tâm và thời tiết sinh — 16 sắc.
11. Lasikā — dịch khớp — 44 sắc.
12. Muttaṃ — nước tiểu, sắc do thời tiết sinh — 8 sắc.
Nhóm muttachakka: sáu thân phần kết thúc bằng nước tiểu.

**EN**
7. Assu — tears, consciousness-produced and temperature-produced — 16.
8. Vasā — grease — 44.
9. Kheḷo — saliva, consciousness-produced and temperature-produced — 16.
10. Siṅghānikā — nasal mucus, consciousness-produced and temperature-produced — 16.
11. Lasikā — joint fluid — 44.
12. Muttaṃ — urine, temperature-produced — 8.
[The urine hexad: muttachakka.]

**VI**
Vị thiện nhân hãy dùng sự hỗ trợ của năng lực ánh sáng phát sinh do tứ thiền niệm hơi thở để luyện tập thuần thục, từ tóc đến nước tiểu rồi từ nước tiểu trở về tóc. Hãy quán thuận từ tóc xuống dưới, rồi quán nghịch từ nước tiểu trở lên đến tóc. Khi có thể thấy rõ ràng bằng tuệ, hành giả đã luyện tập bên trong một cách thành thạo, vững chắc: đã trở nên thuần thục (paguṇa).

**EN**
Good meditator, using the light arising through ānāpāna fourth jhāna, practise until you are proficient from head hair down to urine, and from urine back to head hair. Discern forwards from head hair downwards, then backwards from urine up to head hair, seeing distinctly with knowledge. When you can do this, your internal practice is thoroughly familiar, firm, and proficient (paguṇa).

**VI**
Khi ấy, do năng lực thiền định chưa đủ vững, ánh sáng…

**EN**
Then take the support of the light arising through ānāpāna fourth jhāna…


<a id="M02-body-P004"></a>
## Từ gần đến xa — Ba con đường / The three entrances
Miến / Burmese 4

**VI**
…hãy dùng sự hỗ trợ của năng lực ánh sáng ấy. Tại nơi gần nhất mà ánh sáng lan tỏa tới, đặc biệt là ngay phía trước, hãy quán 32 thân phần trong dòng thân tâm của một vị thiện nhân hoặc một chúng sinh, thuận từ tóc đến nước tiểu rồi nghịch từ nước tiểu trở về tóc, nhiều lần. Khi đã thành công, luân phiên bên trong một lượt và bên ngoài một lượt, lặp đi lặp lại nhiều lần. Chỉ khi có thể quán luân phiên bên trong và bên ngoài nhiều lần như vậy, năng lực tu tập mới lớn mạnh.

**EN**
…At the nearest place reached by that light, especially directly in front, discern the thirty-two body parts in the continuity of a good person or another living being. Repeatedly discern forwards from head hair down to urine and backwards from urine up to head hair. When successful, alternate once internally and once externally, again and again. Only when you can repeatedly alternate internally and externally does the strength of development increase.

**VI**
Dựa vào phương pháp này, dần dần quán từ gần đến xa. Quán trải khắp cả mười phương. Với mỗi người, mỗi con vật mà ánh sáng do tứ thiền niệm hơi thở có thể chạm đến, hãy lần lượt quán từng chúng sinh, luân phiên bên trong và bên ngoài. Nếu mỗi khi quán đều không còn thấy là người nam, người nữ, trâu, bò hay con vật, mà chỉ thấy một tập hợp 32 thân phần, thì đã luyện tập thuần thục, rõ ràng, vững chắc cả bên trong lẫn bên ngoài: đã thành tựu paguṇa.

**EN**
Following this method, gradually discern from near to far, extending throughout all ten directions. Examine each person or animal reached by the light of ānāpāna fourth jhāna, one being after another, alternating internally and externally. If, whenever you discern, you no longer see a man, woman, buffalo, cow, or animal, but only a collection of thirty-two body parts, you have become thoroughly familiar and proficient, internally and externally (paguṇa).

**VI**
Ba con đường

**EN**
THREE ENTRANCES

**VI**
Koṭṭhāsānaṃ paguṇakālato paṭṭhāya tīsu mukhesu ekena mukhena vimuccissati, kammaṭṭhānaṃ vaṇṇato vā paṭikūlato vā suññato vā upaṭṭhāti. Pe. Ākaṅkhamānassa vaṇṇato ākaṅkhamānassa paṭikūlato ākaṅkhamānassa suññato kammaṭṭhānaṃ upaṭṭhahissatiyeva. (Abhi-ṭṭha, 2, 242–243.)

**EN**
Koṭṭhāsānaṃ paguṇakālato paṭṭhāya tīsu mukhesu ekena mukhena vimuccissati, kammaṭṭhānaṃ vaṇṇato vā paṭikūlato vā suññato vā upaṭṭhāti. Pe. Ākaṅkhamānassa vaṇṇato ākaṅkhamānassa paṭikūlato ākaṅkhamānassa suññato kammaṭṭhānaṃ upaṭṭhahissatiyeva. (Abhi-ṭṭha, 2, 242–243.)

**VI**
Từ khi đã thuần thục các thân phần, hành giả sẽ giải thoát qua một trong ba cửa. Đề mục thiền hiện rõ theo màu sắc, theo tính chất bất tịnh, hoặc theo tính chất rỗng không. Pe. Người muốn theo màu sắc thì đề mục hiện rõ theo màu sắc; người muốn theo bất tịnh thì hiện rõ theo bất tịnh; người muốn theo rỗng không thì hiện rõ theo rỗng không.

**EN**
From the time the parts of the body become familiar, one will be liberated through one of three entrances. The meditation subject appears as colour, as repulsive, or as empty. …pe… For one wishing to attend to colour it appears as colour; for one wishing to attend to repulsiveness, as repulsive; for one wishing to attend to emptiness, as empty.

**VI**
Sau khi đã luyện tập thuần thục, vững chắc 32 thân phần bên trong và bên ngoài như vậy, nếu từ lúc ấy hành giả đi vào một trong ba cửa lớn dẫn đến Niết-bàn…

**EN**
After practising the thirty-two body parts thoroughly and firmly, internally and externally, if from that time one enters through any one of the three great entrances leading to Nibbāna…


<a id="M02-body-P005"></a>
## Ba con đường — Tác ý bất tịnh / Attention to repulsiveness
Miến / Burmese 5

**VI**
…thì chắc chắn sẽ giải thoát khỏi các phiền não. Đề mục thiền có thể hiện rõ theo các cách sau:

**EN**
…one will certainly be freed from defilements. The meditation subject can appear:

**VI**
1. Vaṇṇa — màu sắc: theo kasiṇa màu sắc.
2. Paṭikūla — tính chất đáng ghê sợ, đáng chán: theo bất tịnh.
3. Suññata — tính chất rỗng không, vắng tự ngã.

**EN**
1. As colour (vaṇṇa), through a colour kasiṇa.
2. As repulsive (paṭikūla), through the mode of repulsiveness.
3. As empty (suññata), through the mode of emptiness, in which no self is found.

**VI**
1. Với người muốn theo màu sắc, đề mục thiền hiện rõ theo kasiṇa màu sắc.
2. Với người muốn theo bất tịnh, đề mục thiền hiện rõ theo bất tịnh.
3. Với người muốn theo rỗng không, đề mục thiền hiện rõ theo tính chất rỗng không. (Abhi-ṭṭha, 2, 243.)

**EN**
1. For one wishing to attend to colour, the subject appears as a colour kasiṇa.
2. For one wishing to attend to repulsiveness, it appears as repulsive.
3. For one wishing to attend to emptiness, it appears as empty. (Abhidhamma Commentary 2, p. 243.)

**VI**
Theo lời giải thích của chú giải này, khi vị thiện nhân đã luyện tập 32 thân phần một cách vững chắc, thuần thục, có thể chọn bất kỳ con đường nào mình ưa thích trong ba con đường trên để quán. Trong sách này, chúng tôi sẽ trình bày cả ba con đường.

**EN**
According to this commentary, when you have become thoroughly proficient in the thirty-two parts, both internally and externally, you can enter any of these three great entrances leading to Nibbāna. I shall now explain these three methods in sequence.

**VI**
Tác ý bất tịnh (paṭikūlamanasikāra)

**EN**
ATTENTION TO REPULSIVENESS (PAṬIKŪLAMANASIKĀRA)

**VI**
Ettha pana attano jīvamānakasarīre paṭikūlanti parikammaṃ karontassa appanāpi upacārampi jāyati. Parassa jīvamānakasarīre paṭikūlanti manasikarontassa neva appanā jāyati, na upacāraṃ. Nanu ca dasasu asubhesu ubhayampetaṃ jāyatīti. Āma jāyati. Tāni hi anupādinnakapakkhe ṭhitāni, tasmā tattha appanāpi upacārampi jāyati. Idaṃ pana upādinnakapakkhe ṭhitaṃ, tenevettha ubhayampetaṃ na jāyati. Asubhānupassanāsaṅkhātā pana vipassanābhāvanā hotīti veditabbā. (Abhi-ṭṭha, 2, 248.)

**EN**
Ettha pana attano jīvamānakasarīre paṭikūlanti parikammaṃ karontassa appanāpi upacārampi jāyati. Parassa jīvamānakasarīre paṭikūlanti manasikarontassa neva appanā jāyati, na upacāraṃ. Nanu ca dasasu asubhesu ubhayampetaṃ jāyatīti. Āma jāyati. Tāni hi anupādinnakapakkhe ṭhitāni, tasmā tattha appanāpi upacārampi jāyati. Idaṃ pana upādinnakapakkhe ṭhitaṃ, tenevettha ubhayampetaṃ na jāyati. Asubhānupassanāsaṅkhātā pana vipassanābhāvanā hotīti veditabbā. (Abhi-ṭṭha, 2, 248.)

**VI**
Ở đây, khi thực hành sơ khởi trên thân còn sống của chính mình, tác ý rằng “bất tịnh”, cả an chỉ định lẫn cận định đều có thể sinh khởi. Khi tác ý “bất tịnh” trên thân còn sống của người khác, an chỉ định không sinh, cận định cũng không sinh. Có câu hỏi: “Chẳng phải cả hai đều sinh trong mười đề mục tử thi bất tịnh hay sao?” Đáp: “Đúng, có sinh. Vì các đề mục ấy thuộc phía không còn được nghiệp chấp thủ, nên cả an chỉ định lẫn cận định đều sinh. Còn thân đang sống này thuộc phía được nghiệp chấp thủ, nên cả hai đều không sinh ở đây. Tuy nhiên, nên hiểu đó là sự tu tập minh sát được gọi là quán bất tịnh.”

**EN**
Here, when carrying out the preliminary work on one's own living body as repulsive, both access and absorption arise. When attending to another living body as repulsive, neither absorption nor access arises. But does not the Asubhasutta in the Suttanipāta teach that access and absorption arise in both cases? That discourse concerns a body without consciousness. In that case both occur. What is intended here, however, is hair, nails, and so forth in a living body. Attention to repulsiveness in them brings neither access nor absorption, but is beneficial to the perception of foulness. (Abhidhamma Commentary 2, p. 243.)


<a id="M02-body-P006"></a>
## Tác ý bất tịnh — Thân sống và tử thi / Internal and external repulsiveness
Miến / Burmese 6

**VI**
Theo lời giải thích của chú giải trên, nơi 32 thân phần trong dòng thân tâm của chính mình, tức bên trong, nếu lấy tính chất bất tịnh làm cảnh mà tác ý, định cận hành và định an chỉ đều có thể sinh. Còn đối với 32 thân phần thuộc thân sống của người khác, nếu lấy tính chất bất tịnh làm cảnh mà tác ý, cả định cận hành lẫn định an chỉ đều không sinh. Tuệ minh sát quán bất tịnh có thể sinh. Đối với thân không còn sống, tức tử thi, nếu lấy tính chất bất tịnh làm cảnh mà quán, cả định cận hành và định an chỉ đều có thể sinh. (Abhi-ṭṭha, 2, 248.)

**EN**
According to this commentary, when the meditator carries out preliminary work on one or several of the thirty-two parts of his own living body as “repulsive, repulsive,” either access or absorption jhāna can occur. When he carries out preliminary work on the body parts of another living being, external to himself, as “repulsive, repulsive,” neither access nor absorption occurs. Nevertheless, the perception of foulness benefits.

**VI**
Câu hỏi: Trong các đề mục bất tịnh lấy mười loại tử thi bất tịnh làm cảnh để tu tập, chẳng phải cả an chỉ định và cận định đều có thể sinh hay sao? Đó là câu hỏi.

**EN**
Question: In foulness meditation taking any of the ten kinds of corpse as object, are not both access and absorption concentration possible?

**VI**
Đáp: Đúng, có thể sinh. Mười loại tử thi bất tịnh ấy thuộc phía không được nghiệp chấp thủ (anupādinnakapakkha), tức phần không có sự sống. Vì vậy, trong các đề mục bất tịnh lấy mười loại tử thi ấy làm cảnh để tu tập, cả an chỉ định và cận định đều có thể sinh. (Abhi-ṭṭha, 2, 248.)

**EN**
Answer: Yes, they are possible. Those ten kinds of corpse are without consciousness, are they not? Therefore foulness meditation taking those corpses as object can produce either access or absorption concentration. (Abhidhamma Commentary 2, p. 248.)

**VI**
Mặt khác, 32 thân phần trong dòng thân tâm còn sống của người khác thuộc phía được nghiệp chấp thủ (upādinnakapakkha), tức phần có sự sống. (Lấy 32 thân phần của chúng sinh còn sống làm cảnh mà tu tập theo bất tịnh.) Vì vậy, cả an chỉ định lẫn cận định đều không thể sinh nơi 32 thân phần trong thân còn sống của người khác. Tuy nhiên, cần biết rằng sự tu tập minh sát được gọi là quán bất tịnh (asubhānupassanā) có thể sinh. (Đây là pháp tu minh sát quán bất tịnh nơi thân có thức, được nói trong kinh Vijaya v.v.; sẽ được trình bày rõ trong phần minh sát…

**EN**
The thirty-two parts of the body in the continuity of a living being, however, are accompanied by consciousness. Consequently, when one attends to the thirty-two parts in an external being as “repulsive, repulsive,” neither access nor absorption occurs. If those thirty-two parts belong to a dead body, access or absorption can occur…


<a id="M02-body-P007"></a>
## Lời giải thích của Phụ chú giải gốc / The Mūlaṭīkā explanation
Miến / Burmese 7

**VI**
…). (Abhi-ṭṭha, 2, 248.)

**EN**
…This is contemplation of the body. Its explanation will appear in the insight section. (Abhidhamma Commentary 2, p. 248.)

**VI**
Lời giải thích của Phụ chú giải gốc (Mūlaṭīkā)

**EN**
THE MŪLAṬĪKĀ EXPLANATION

**VI**
“Anupādinnakavatthu” — đối tượng không có sự sống. Chú giải giải thích rằng mười loại tử thi được lấy làm cảnh trong pháp tu bất tịnh đều không có sự sống. Cũng vậy, đối với hành giả có thể nhận biết 32 thân phần của một chúng sinh đang sống ở bên ngoài như không có sự sống, thân ấy có thể hiện ra như một tử thi. Các trường hợp của Trưởng lão Mahātissa ở núi Cetiya và vị sa-di hầu Trưởng lão Saṅgharakkhita minh họa cách thấy ấy. Cần hiểu rằng tác giả đang chỉ đến sự chứng đắc cận định. (Mūlaṭīkā, tập 2, tr. 155.)

**EN**
“Anupādinnakavatthu”: The commentary explains that the ten kinds of corpse taken as object in foulness meditation are devoid of life. In the same way, if the thirty-two parts in an external living being appear as lifeless in the continuity of a meditator capable of taking them as lifeless, as in the case of the Venerable Mahātissa dwelling on Cetiya Mountain or the novice attending the Venerable Saṅgharakkhita, the body appears as if belonging to someone whose life has ended, like the ten kinds of corpse. Understand that this points to attaining access concentration. (Mūlaṭīkā 2, p. 155.)

**VI**
“Atthissa kāye” — “trong thân người ấy có [32 thân phần]”.

**EN**
“Atthissa kāye”—“in that person’s body there are [the thirty-two parts]”.

**VI**
Nếu nắm lấy tóc và các thân phần khác là “tóc của người khác”, v.v., đó là nắm lấy theo hình thức một chúng sinh. Nếu không nắm lấy như vậy, mà chỉ nắm lấy rằng “imasmiṃ kāye — trong thân này”, không chấp đó là thân của người nào, thì thoát khỏi việc nắm lấy là chúng sinh. Khi sự tác ý “ta” đã được phá bỏ đối với thân chỉ gọi là “ta” như vậy — vì không nói “thân của ta” — niệm sẽ hướng đến và an trú gần nơi 32 thân phần của chính mình đang hiện rõ trước tuệ tương ưng với định. Tương tự…

**EN**
To apprehend hair and the other parts as “another person's hair,” and so forth, is to apprehend them under the aspect of a being. Instead, by apprehending simply “imasmiṃ kāye—in this body,” without taking it as somebody's body, apprehension of a being is removed. Thus, just as one does not call one's own body “my body,” but apprehends it as “in this body,” attention to “I” is removed, and mindfulness inclines towards and becomes established near one's own thirty-two parts appearing distinctly to knowledge associated with concentration. Likewise…

**Ghi chú / Note**
Ảnh Miến in Atthissa kāye ở đoạn kế tiếp.


<a id="M02-body-P008"></a>
## Bất tịnh, kasiṇa và nền tảng minh sát / Access and absorption in repulsiveness meditation
Miến / Burmese 8

**VI**
…khi 32 thân phần của người khác hiện rõ, niệm có thể hướng đến thân người ấy, tức 32 thân phần trong thân ấy có thể hiện rõ. Vì vậy, không thể đạt an chỉ định trên 32 thân phần của người khác chỉ bằng việc tác ý theo tính chất bất tịnh. Khi vị thiện nhân đi vào minh sát, dựa trên giáo thuyết được trình bày trong kinh Vijaya (Suttanipāta, 307–308), những pháp minh sát quán bất tịnh — có nghĩa là nhìn thân mình và thân người khác như nhau — có thể lấy cả 32 thân phần của người khác làm cảnh. Cần hiểu theo ý nghĩa ấy rằng lời chú giải nói “có sự tu tập minh sát được gọi là quán bất tịnh”. Đây là lời giải thích của Phụ chú giải gốc. (Mūlaṭīkā, 2, 155–156.)

**EN**
…when another person's thirty-two parts become clear, mindfulness can incline towards that body: its thirty-two parts can become manifest. Nevertheless, absorption cannot be attained by attending to repulsiveness in another person's thirty-two parts. When the good meditator proceeds to insight, however, in accordance with the Vijayasutta (Suttanipāta, pp. 307–308), insight contemplating repulsiveness—seeing one's own and another's body alike—can take another person's thirty-two parts as object. Understand in this sense the commentarial statement that there is insight development called contemplation of repulsiveness. This is the Mūlaṭīkā explanation. (Mūlaṭīkā 2, pp. 155–156.)

**VI**
Theo lời giải thích của vị tác giả Phụ chú giải gốc này, cả cận định và an chỉ định đều có thể sinh nơi 32 thân phần bên trong; bên ngoài, đối với thân sống của người khác nếu xem như tử thi, tức thân không còn sống, cận định cũng có thể sinh khi tác ý bất tịnh trên 32 thân phần ấy. Cận định ấy có năm thiền chi, còn an chỉ định có đủ năm thiền chi và sức mạnh của các thiền chi tăng lên.

**EN**
According to this Mūlaṭīkā author, both access and absorption can arise with the thirty-two internal parts. Externally, when another living body is viewed as a corpse, without life, access can also arise through attending to repulsiveness in its thirty-two parts. This access has five jhāna factors. Absorption also has five factors, but their strength is greater; the jhāna factors are the same, with a difference in power.

**VI**
Nhờ chế ngự năm triền cái, tâm tu tập có thể an trú vững chắc trên cảnh đề mục trong cận định. Người đã đạt thiền, do các thiền chi hiện rõ và có sức mạnh lớn…

**EN**
Because the five hindrances have been suppressed, the meditating mind can remain firmly concentrated on its object at access. In one who has attained absorption, because the jhāna factors appear distinctly with great strength…


<a id="M02-body-P009"></a>
## Đề mục bộ xương / The skeleton meditation subject
Miến / Burmese 9

**VI**
…nên tâm tu tập có thể an trú vững chắc trên cảnh đề mục. Trong cận định, các thiền chi chưa sinh khởi với đầy đủ sức mạnh; còn ở sát-na an chỉ, các thiền chi sinh khởi với đầy đủ sức mạnh. (Xem Visuddhi, 1, 123.)

**EN**
…the meditating mind can remain firmly established on its object. At access the jhāna factors have not yet arisen with their full power; at absorption they have arisen with their full power. (See Visuddhimagga 1, p. 123.)

**VI**
Đề mục bộ xương (aṭṭhikakammaṭṭhāna)

**EN**
THE SKELETON MEDITATION SUBJECT (AṬṬHIKAKAMMAṬṬHĀNA)

**VI**
Hành giả đã luyện tập 32 thân phần đến mức thuần thục, vững chắc có thể tu tập tác ý bất tịnh bằng cách lấy toàn bộ 32 thân phần làm cảnh, hoặc lấy từng thân phần làm cảnh. (Xem Visuddhi, 1, 257.)

**EN**
A meditator thoroughly proficient in the thirty-two parts can develop attention to repulsiveness by taking either all thirty-two parts together or each part individually as object. (See Visuddhimagga 1, p. 257.)

**VI**
Ở đây, chúng tôi trình bày cách tu tập lấy riêng bộ xương làm cảnh. Có thể bắt đầu từ bên trong hoặc bên ngoài, tùy ý. Trong phần này, chúng tôi trình bày cách thực hành bắt đầu từ bên trong.

**EN**
Here I shall explain practice taking the skeleton alone as object. You may begin internally or externally, as you wish. In this account I begin internally.

**VI**
Vị thiện nhân hãy an lập lại tứ thiền niệm hơi thở đã đạt được. Khi năng lực ánh sáng rực rỡ, sáng chói, hãy quán 32 thân phần bên trong. Ở bên ngoài, cũng quán 32 thân phần của một chúng sinh ở gần nhất, trong vùng ánh sáng có thể chạm đến. Luân phiên bên trong và bên ngoài một hai lượt. Sau đó, dùng tuệ quán trọn bộ xương bên trong. Khi bộ xương hiện rõ, lấy tính chất đáng ghê sợ, bất tịnh của bộ xương ấy làm cảnh…

**EN**
Good meditator, re-establish the ānāpāna fourth jhāna already attained. When the light becomes brilliant and bright, discern your thirty-two internal parts. Externally, discern the thirty-two parts in the nearest living being reached by the light. Alternate internally and externally once or twice. Then discern your entire internal skeleton with knowledge. When it appears clearly, take its repulsive, loathsome nature as object:

**VI**
1. “Paṭikūla, paṭikūla — đáng ghê sợ, đáng ghê sợ”; hoặc
2. “Aṭṭhikapaṭikūla — bộ xương đáng ghê sợ”; hoặc
3. “Aṭṭhika, aṭṭhika — bộ xương đáng ghê sợ, bộ xương đáng ghê sợ”.

**EN**
1. “Paṭikūla, paṭikūla—repulsive, repulsive”; or
2. “Aṭṭhikapaṭikūla—the repulsive skeleton”; or
3. “Aṭṭhika, aṭṭhika—the repulsive skeleton, the repulsive skeleton”.


<a id="M02-body-P010"></a>
## Học tướng và tương tợ tướng / The learning sign and counterpart sign
Miến / Burmese 10

**VI**
Hãy quán bằng tiếng Pāli hoặc tiếng Miến, tùy ý. Đặt niệm tu tập trên cảnh bộ xương đáng ghê sợ ấy một giờ, hai giờ, v.v., rồi cố gắng an trú vững chắc. Được nâng đỡ tốt bởi cận y duyên mạnh mẽ là tứ thiền niệm hơi thở, pháp hành tác ý bất tịnh này thường có sức mạnh lớn trong thời gian rất ngắn đối với hành giả đã tích lũy pāramī thù thắng. Vì vậy, hãy dùng tuệ quán cho tính chất bất tịnh của bộ xương hiện rõ, sáng tỏ, như đang nhìn bằng mắt.

**EN**
Contemplate in Pāli or Burmese, as you wish. Place mindfulness of development on that repulsive skeleton object for one hour, two hours, and so on, and endeavour to remain firmly established. Well supported by the powerful decisive-support condition of ānāpāna fourth jhāna, this attention to repulsiveness usually gains strength very quickly in a meditator with outstanding accumulated pāramīs. Therefore discern with knowledge until the skeleton's repulsiveness becomes distinct and clear, as though seeing with the eyes.

**VI**
Học tướng và tương tợ tướng (uggahanimitta, paṭibhāganimitta)

**EN**
THE LEARNING SIGN AND COUNTERPART SIGN (UGGAHANIMITTA, PAṬIBHĀGANIMITTA)

**VI**
Tattha vaṇṇato santhānadisokāsaparicchedavasena upaṭṭhānaṃ uggahanimittaṃ. Sabbākārato paṭikūlavasena upaṭṭhānaṃ paṭibhāganimittaṃ. (Visuddhi, 1, 257.)

**EN**
Tattha vaṇṇato santhānadisokāsaparicchedavasena upaṭṭhānaṃ uggahanimittaṃ. Sabbākārato paṭikūlavasena upaṭṭhānaṃ paṭibhāganimittaṃ. (Visuddhi, 1, 257.)

**VI**
Ở đây, đối với cảnh bộ xương:

**EN**
Here, in regard to the skeleton object:

**VI**
1. Vaṇṇa — màu của xương.
2. Santhāna — hình dáng của xương.
3. Disā — phương hướng của xương: ở phần trên hay phần dưới của thân.
4. Okāsa — vị trí mà xương hiện hữu.
5. Pariccheda — ranh giới phân biệt thân phần xương với các thân phần khác, và ranh giới phân biệt các phần xương với nhau.

**EN**
1. Colour (vaṇṇa): the colour of the bones.
2. Shape (santhāna): their shape.
3. Direction (disā): whether they belong to the upper or lower part of the body.
4. Location (okāsa): the place where they are present.
5. Delimitation (pariccheda): their separation from other body parts and the separation of the different bones from one another.

**VI**
Bộ xương hiện rõ theo năm phương diện ấy là học tướng (uggahanimitta). Khi bộ xương hiện rõ bằng sức tác ý theo tính chất bất tịnh gắn với năm phương diện này, hoặc với tất cả phương diện…

**EN**
The skeleton appearing in these five respects is the learning sign. When it appears through attention to repulsiveness connected with these five aspects, or in every aspect…


<a id="M02-body-P011"></a>
## Năm thiền chi — Hỷ và thọ hỷ / The five jhāna factors; joy and mental pleasant feeling
Miến / Burmese 11

**VI**
…thì cảnh bộ xương ấy là tương tợ tướng (paṭibhāganimitta). (Visuddhi, 1, 257; Mahāṭīkā, 1, 310; Abhi-ṭṭha, 2, 237.)

**EN**
…that skeleton is the counterpart sign. (Visuddhimagga 1, p. 257; Mahāṭīkā 1, p. 310; Abhidhamma Commentary 2, p. 237.)

**VI**
Đối với tương tợ tướng bộ xương hiện rõ theo tính chất bất tịnh ấy, nếu hành giả nỗ lực tu tập đi đến sơ thiền, an chỉ thiền có thể sinh khởi. (Visuddhi, 1, 257.) Nếu muốn, cũng có thể tu tập theo cùng cách ấy trên những thân phần còn lại.

**EN**
For the meditator developing meditation based on the skeleton counterpart sign appearing through repulsiveness, absorption occurs only as the first jhāna. (Visuddhimagga 1, p. 257.) The remaining body parts too can be developed in the same way, if desired.

**VI**
Năm thiền chi

**EN**
THE FIVE JHĀNA FACTORS

**VI**
1. Vitakka — tầm: đưa tâm đến và đặt tâm trên cảnh bộ xương bất tịnh.
2. Vicāra — tứ: liên tục xem xét, duy trì tâm trên cảnh bộ xương bất tịnh.
3. Pīti — hỷ: hoan hỷ đối với cảnh bộ xương bất tịnh.
4. Sukha — lạc: cảm thọ an vui, êm dịu khi nếm trải hương vị của cảnh bộ xương bất tịnh.
5. Ekaggatā — nhất tâm: tâm an trú, ổn định, hợp nhất trên một cảnh bộ xương bất tịnh.

**EN**
1. Applied thought (vitakka): directing and placing the mind on the repulsive skeleton.
2. Sustained thought (vicāra): repeatedly examining the repulsive skeleton.
3. Joy (pīti): delight in the repulsive skeleton.
4. Bliss (sukha): pleasantly experiencing the taste of the repulsive skeleton object.
5. One-pointedness (ekaggatā): the mind falling upon and remaining steadily on that single object, the repulsive skeleton.

**VI**
Hỷ và thọ hỷ (pīti, somanassa)

**EN**
JOY AND MENTAL PLEASANT FEELING (PĪTI, SOMANASSA)

**VI**
Đừng nghĩ rằng vì bộ xương là thứ đáng ghê sợ, bất tịnh, nên không thể có hỷ và thọ hỷ. Điều ấy có thể xảy ra. Dù bộ xương là cảnh đáng ghê sợ, bất tịnh, nhưng do thấy rõ lợi ích của sự thực hành quán bộ xương bất tịnh…

**EN**
One may ask how joy and mental pleasant feeling can arise with such a repulsive skeleton as object. The answer is as follows. Although the skeleton contemplated by the method of attention to repulsiveness is indeed loathsome, with its counterpart sign as object…


<a id="M02-body-P012"></a>
## Hỷ, thọ hỷ — Điều cần ghi nhớ / A point to bear in mind
Miến / Burmese 12

**VI**
…nên, do thấy lợi ích rằng “Addhā imāya paṭipadāya jarāmaraṇamhā parimuccissāmi — chắc chắn nhờ pháp hành này ta sẽ thoát khỏi già và chết”, và do thấy có thể chứng đạt pháp bất tử Niết-bàn, không có già và chết, hỷ và thọ hỷ có thể sinh nơi cảnh tương tợ tướng ấy. Như người hốt rác vui mừng khi thấy lợi ích, nghĩ rằng “Ta sẽ được nhiều tiền công”, hoặc như người bệnh chịu khổ vì nhiều chứng bệnh vui mừng được dùng thuốc gây nôn và thuốc xổ để chữa bệnh, hỷ và thọ hỷ có thể sinh ngay nơi cảnh bất tịnh. Hãy ghi nhớ điều ấy. (Visuddhi, 1, 188.)

**EN**
…one sees the benefit to be gained: “Addhā imāya paṭipadāya jarāmaraṇamhā parimuccissāmi”—surely through this practice I shall be freed from the great dangers of ageing and death. Because one sees that benefit, and because one abandons the hindrances which corrupt the continuity of consciousness, joy and mental pleasant feeling can arise. It is like a refuse collector who takes a great heap of refuse as object and feels joy and mental pleasure because he sees the profit he will gain from it. Or it is like a person severely ill who feels joy and mental pleasure when vomiting or purging gives relief. (Visuddhimagga 1, p. 188.)

**VI**
Điều cần ghi nhớ

**EN**
A POINT TO BEAR IN MIND

**VI**
Trong khi quán bộ xương bằng tác ý bất tịnh, lúc đầu hành giả phải bỏ tên gọi “xương”, vốn chỉ là tên chế định, mà an trú niệm bằng cách tác ý “paṭikūla, paṭikūla — đáng ghê sợ, đáng ghê sợ”. Tuy nhiên, nếu ngay khi bắt đầu cố gắng mà chưa thể bỏ tên gọi “bộ xương” và tác ý theo tính chất bất tịnh, thì trong thời gian chưa thể tác ý bộ xương theo tính chất bất tịnh, chưa nên bỏ tên gọi bộ xương. Lý do: chỉ khi bộ xương hiện rõ theo tính chất bất tịnh mới bỏ tên gọi chế định ấy; lúc ấy, bỏ tên gọi bộ xương, chỉ tác ý “paṭikūla, paṭikūla — đáng ghê sợ, đáng ghê sợ”. Theo một trong năm phương diện đã nói trên, hoặc…

**EN**
When developing attention to repulsiveness with the skeleton as object, let go of the name-concept “skeleton” and establish mindfulness only on its loathsome nature, attending “paṭikūla, paṭikūla—repulsive, repulsive.” At the beginning of the endeavour, however, that repulsive nature may not yet appear. As long as it is not manifest, do not discard the name-concept “skeleton.” When it does appear as loathsome and repulsive, discard the name-concept or skeleton concept and attend to it simply as “repulsive, repulsive.” According to the manner explained above…


<a id="M02-body-P013"></a>
## Bên trong và bên ngoài / Internally and externally
Miến / Burmese 13

**VI**
…hãy tác ý sao cho tính chất bất tịnh, đáng ghê sợ hiện rõ. (Xem Abhi-ṭṭha, 2, 245.)

**EN**
…attend in every respect so that its loathsome, repulsive nature becomes manifest. (See Abhidhamma Commentary 2, p. 245.)

**VI**
Bên trong và bên ngoài (ajjhatta, bahiddha)

**EN**
INTERNALLY AND EXTERNALLY (AJJHATTA, BAHIDDHA)

**VI**
Sace pana bahiddhāpi manasikāraṃ upasaṃharati, athassa evaṃ sabbakoṭṭhāsesu pākaṭībhūtesu āhiṇḍantā manussatiracchānādayo sattākāraṃ vijahitvā koṭṭhāsarāsivaseneva upaṭṭhahanti. Tehi ca ajjhohariyamānaṃ pānabhojanādi koṭṭhāsarāsimhi pakkhipiyamānamiva upaṭṭhāti. Athassa anupubbamuñcanādivasena paṭikūlaṃ paṭikūlanti punappunaṃ manasikaroto anukkamena appanā uppajjati. (Abhi-ṭṭha, 2, 236–237.)

**EN**
Sace pana bahiddhāpi manasikāraṃ upasaṃharati, athassa evaṃ sabbakoṭṭhāsesu pākaṭībhūtesu āhiṇḍantā manussatiracchānādayo sattākāraṃ vijahitvā koṭṭhāsarāsivaseneva upaṭṭhahanti. Tehi ca ajjhohariyamānaṃ pānabhojanādi koṭṭhāsarāsimhi pakkhipiyamānamiva upaṭṭhāti. Athassa anupubbamuñcanādivasena paṭikūlaṃ paṭikūlanti punappunaṃ manasikaroto anukkamena appanā uppajjati. (Abhi-ṭṭha, 2, 236–237.)

**VI**
Nếu cũng hướng tác ý ra bên ngoài, thì khi tất cả thân phần đã hiện rõ như vậy, những người, những loài vật đang đi lại, v.v., không còn hiện ra theo hình thức chúng sinh, mà chỉ như những khối tập hợp thân phần. Thức uống, đồ ăn, v.v. được họ nuốt vào cũng hiện ra như được bỏ vào một khối tập hợp thân phần. Sau đó, khi hành giả liên tục tác ý “bất tịnh, bất tịnh” bằng cách lần lượt buông bỏ, v.v., an chỉ định tuần tự sinh khởi.

**EN**
If, after thoroughly practising the thirty-two internal parts, one directs attention to another person's external parts, those parts all become manifest. People, animals, and other beings going about and eating no longer appear under the aspect of beings, but as collections of parts. Through the power of the light, people and animals appear like bundles of body parts into which food and drink are being put. When the meditator repeatedly attends “repulsive, repulsive” to many internal parts, or to one prominent internal part, absorption can arise in due course. (Abhidhamma Commentary 2, pp. 236–237.)

**VI**
Khi đã luyện tập 32 thân phần bên trong một cách vững chắc, thuần thục, nếu hành giả hướng tác ý đến các thân phần trong dòng thân tâm người khác ở bên ngoài, và tất cả thân phần ấy hiện rõ, thì những chúng sinh như người, thú đang đi lại và sinh hoạt sẽ không còn hiện ra theo hình thức đáng chấp là “chúng sinh”, mà chỉ như một tập hợp các thân phần. Những chúng sinh được ánh sáng soi đến ấy hiện ra như thức ăn, đồ uống được cho vào một khối tập hợp thân phần. Lúc ấy, khi hành giả nhiều lần tác ý “paṭikūla, paṭikūla — đáng ghê sợ, đáng ghê sợ” đối với các thân phần bên trong, hoặc bất kỳ thân phần nào hiện rõ, an chỉ thiền có thể tuần tự sinh khởi. (Abhi-ṭṭha, 2, 236–237.)

**EN**
When proficiency in discerning the thirty-two parts has been established, use external contemplation as described, and repeatedly return to attention to internal repulsiveness until absorption arises.


<a id="M02-body-P014"></a>
## Thuần thục sơ thiền trên bộ xương / Alternating the internal and external skeleton
Miến / Burmese 14

**VI**
Theo lời giải thích của chú giải trên, khi người hành thiền tác ý bất tịnh trên bộ xương bên trong và đã đạt sơ thiền, tức có thể gọi là đệ nhất thiền định (paṭhamajjhāna), hãy luyện tập năm pháp thuần thục của thiền ấy. Khi đã thuần thục năm pháp, hãy lấy bộ xương nơi một người ở gần mình, hoặc người ở gần nhất trong vùng ánh sáng có thể soi đến, làm cảnh mà quán theo tính chất bất tịnh. Tác ý cho các thiền chi hiện rõ. Tuy nhiên, các thiền chi hiện rõ ấy có thể không đủ mạnh mẽ để đoạn trừ tạm thời các pháp đối nghịch của thiền. Sự định tâm do tác ý nơi bộ xương bên ngoài ấy chưa phải đệ nhất thiền định.

**EN**
According to the commentary, when you reach the first jhāna by attending to the repulsiveness of your internal skeleton, practise its five kinds of mastery. After mastering them, take the skeleton of a person directly in front of you, or the nearest person reached by the light, and attend to its repulsiveness until the jhāna factors appear. According to the Mūlaṭīkā explanation above, what is obtained in this way is only access jhāna, attained by attending to the external skeleton as if it were the lifeless skeleton of a corpse.

**VI**
Khi các thiền chi ấy đã hiện rõ, hãy quay lại tác ý bộ xương bên trong theo tính chất bất tịnh. Luân phiên quán bên trong và bên ngoài. Nhờ tác ý luân phiên bên trong và bên ngoài nhiều lần, pháp hành tác ý bất tịnh sẽ dần dần mạnh mẽ, chín muồi và vững chắc. Khi ấy, hãy dùng năng lực ánh sáng quán lần lượt bộ xương của từng chúng sinh hiện hữu trong mười phương. Bắt đầu từ gần rồi tiến xa; bỏ phân biệt người nam, người nữ, các loài vật v.v., chỉ tác ý bộ xương, luân phiên bên trong và bên ngoài. Hãy luyện tập cho đến khi, ở bất kỳ phương nào trong mười phương, ngay khi muốn quán đều thấy rõ chỉ có bộ xương. Sau đó hãy chuyển sang kasiṇa trắng.

**EN**
When the factors appear, return to the internal skeleton and attend to its repulsiveness. Alternate internally and externally. By repeatedly alternating in this way, the development of attention to repulsiveness becomes very powerful. Then discern one skeleton after another in all ten directions reached by the light. Direct knowledge far and near throughout the entire area, again alternating internal and external. Practise until, wherever you look in the ten directions, you see only skeletons. When you succeed, you may proceed to the white kasiṇa.


<a id="M02-body-P015"></a>
## Mười kasiṇa — Tám chứng đắc — Bốn kasiṇa màu sắc / Ten kasiṇas and eight attainments
Miến / Burmese 15

**VI**
Mười kasiṇa — Tám chứng đắc thiền định

**EN**
TEN KASIṆAS — EIGHT ATTAINMENTS

**VI**
Kasiṇa màu sắc (vaṇṇakasiṇa)

**EN**
COLOUR KASIṆAS (VAṆṆAKASIṆA)

**VI**
Bốn loại kasiṇa màu sắc

**EN**
THE FOUR COLOUR KASIṆAS

**VI**
Trong 32 thân phần, có thể đạt bốn kasiṇa màu sắc: kasiṇa xanh (nīlakasiṇa), kasiṇa vàng (pītakasiṇa), kasiṇa đỏ (lohitakasiṇa) và kasiṇa trắng (odātakasiṇa).

**EN**
From the thirty-two body parts one can obtain four colour kasiṇas: blue, yellow, red, and white.

**VI**
1. Nīlakasiṇa — kasiṇa xanh: lấy màu của tóc, lông, mật, hoặc màu xanh đen của mắt làm cảnh; tác ý “nīla, nīla — xanh, xanh”. Hành giả ấy có thể chứng tứ thiền hoặc ngũ thiền. Lấy thiền ấy làm nền tảng minh sát, hành giả có thể tiến đến A-la-hán quả, là pháp được làm phát sinh nhờ minh sát. (Abhi-ṭṭha, 2, 239.)

**EN**
1. Blue kasiṇa (nīlakasiṇa): take as object the blue-black colour of head hair, body hair, bile, or the dark part of the eye. Attending “nīlaṃ, nīlaṃ—blue, blue,” one can attain the jhānas of the fourfold or fivefold scheme. Taking those jhānas as a basis for insight, one who develops insight knowledge can reach the Fruition of Arahantship. (Abhidhamma Commentary 2, p. 239.)

**VI**
2. Lấy màu vàng của mỡ hoặc màu vàng trong mắt làm cảnh; cũng có thể lấy màu vàng của nước tiểu hoặc của những phần cơ thể màu vàng. Tác ý “pītaka, pītaka — vàng, vàng”, hành giả có thể chứng tứ thiền hoặc ngũ thiền. Lấy thiền ấy làm nền tảng minh sát, hành giả có thể tiến đến A-la-hán quả, là pháp được làm phát sinh nhờ minh sát. (Abhi-ṭṭha, 2, 239.)

**EN**
2. Take as object the yellow colour of fat or the yellow part of the eye, or yellow skin or yellow fingernails and toenails. Attending “pītakaṃ, pītakaṃ—yellow, yellow,” one can attain the jhānas of the fourfold or fivefold scheme. Taking those jhānas as a basis for insight, one who develops insight knowledge can reach the Fruition of Arahantship. (Abhidhamma Commentary 2, p. 239.)

**VI**
3. Lấy màu của thịt, của máu, hoặc màu đỏ của mắt làm cảnh; tác ý “lohitaka, lohitaka — đỏ, đỏ”, hành giả có thể chứng tứ thiền hoặc ngũ thiền. Lấy thiền ấy…

**EN**
3. Take as object the red colour of flesh, blood, the tongue, or the red part of the eye. Attending “lohitakaṃ, lohitakaṃ—red, red,” one can attain the jhānas of the fourfold or fivefold scheme. Taking those jhānas…


<a id="M02-body-P016"></a>
## Kasiṇa trắng — Thiền thắng xứ / Jhāna of the bases of mastery
Miến / Burmese 16

**VI**
…làm nền tảng minh sát, hành giả có thể tiến đến A-la-hán quả, là pháp được làm phát sinh nhờ minh sát. (Abhi-ṭṭha 2,239; Dī-ṭṭha 2,151.)

**EN**
…as a basis for insight, one who develops insight knowledge can reach the Fruition of Arahantship. (Abhidhamma Commentary 2, p. 239; Dīgha Commentary 2, p. 151.)

**VI**
4. Lấy màu trắng của móng chân, móng tay, răng, da dày và da mỏng, xương, hoặc phần trắng của mắt làm cảnh; tác ý “odātaṃ, odātaṃ — trắng, trắng”, hành giả có thể chứng tứ thiền hoặc ngũ thiền. Lấy thiền ấy làm nền tảng minh sát, hành giả có thể tiến đến A-la-hán quả, là pháp được làm phát sinh nhờ minh sát. (Abhi-ṭṭha 2,239; Dī-ṭṭha 2,151.)

**EN**
4. Take as object the white colour of the fingernails and toenails, teeth, thick or thin skin, bones, or the white part of the eye. Attending “odātaṃ, odātaṃ—white, white,” one can attain the jhānas of the fourfold or fivefold scheme. Taking those jhānas as a basis for insight, one who develops insight knowledge can reach the Fruition of Arahantship. (Abhidhamma Commentary 2, p. 239; Dīgha Commentary 2, p. 151.)

**VI**
Thiền thắng xứ (abhibhāyatanajhāna)

**EN**
JHĀNA OF THE BASES OF MASTERY (ABHIBHĀYATANAJHĀNA)

**VI**
Các thiền đạt được bằng cách chuyển từ 32 thân phần sang bốn kasiṇa màu sắc được gọi là thiền thắng xứ, vì hành giả đạt thiền bằng cách chế ngự các cảnh kasiṇa ấy. Cũng gọi là thiền thắng xứ vì có thể dễ dàng chế ngự các pháp đối nghịch, như những cấu uế phiền não.

**EN**
The jhānas obtained by proceeding from the thirty-two body parts to the four colour kasiṇas are called jhānas of the bases of mastery because they are attained by mastering those kasiṇa objects. They are also so called because they readily master the opposing states, the defilements that stain the mind.

**VI**
Abhibhāyatanānīti abhibhavanakāraṇāni. Kiṃ abhibhavanti? Paccanīkadhammepi ārammaṇānipi. Tāni hi paṭipakkhabhāvena paccanīkadhamme abhibhavanti, puggalassa ñāṇuttariyatāya ārammaṇāni. (Dī-ṭṭha 2,151; Ma-ṭṭha 3,177; Aṅ-ṭṭha 3,243.)

**EN**
Abhibhāyatanānīti abhibhavanakāraṇāni. Kiṃ abhibhavanti? Paccanīkadhammepi ārammaṇānipi. Tāni hi paṭipakkhabhāvena paccanīkadhamme abhibhavanti, puggalassa ñāṇuttariyatāya ārammaṇāni. (Dī-ṭṭha 2,151; Ma-ṭṭha 3,177; Aṅ-ṭṭha 3,243.)

**VI**
Thắng xứ là những pháp làm nhân cho sự chế ngự, áp đảo, tức các thiền sắc giới. Chúng chế ngự những gì? Chúng chế ngự cả các pháp đối nghịch lẫn các cảnh kasiṇa. Đúng vậy…

**EN**
The bases of mastery are the fine-material jhānas that bring about mastery. What do they master? They master both the opposing states and the kasiṇa objects. Indeed…


<a id="M02-body-P017"></a>
## Ý nghĩa chế ngự cảnh kasiṇa / What the bases of mastery overcome
Miến / Burmese 17

**VI**
…các thiền thắng xứ chế ngự những pháp đối nghịch do chính chúng là các pháp đối trị. Các thiền thắng xứ cũng chế ngự cảnh kasiṇa nhờ tuệ thù thắng của hành giả đã đạt và đang tu tập những thiền ấy. (Dī-ṭṭha 2,151; Ma-ṭṭha 3,177; Aṅ-ṭṭha 3,243.)

**EN**
…these jhānas master their opposing states because they are directly opposed to them. They also master their kasiṇa objects because of the sharpness and strength of the meditator's knowledge in developing them. (Dīgha Commentary 2, p. 151; Majjhima Commentary 3, p. 177; Aṅguttara Commentary 3, p. 243.)

**VI**
Nếu thân phần có màu rất đáng ghê sợ, như mật, hành giả lấy màu của thân phần ấy làm cảnh và tu tập kasiṇa xanh, thì không những học tướng kasiṇa xanh có thể sinh mà cả thiền an chỉ cũng có thể sinh. Các thiền sinh khởi như vậy được gọi là thiền thắng xứ. (Xem Paṭisambhidāmagga-aṭṭhakathā, tập 1, tr. 69.)

**EN**
Even if the part is as small as bile, one can develop a blue kasiṇa based on it. As the blue kasiṇa sign arises, one can bring about absorption. The jhānas thus attained are called jhānas of the bases of mastery. (See Paṭisambhidāmagga Commentary, vol. 1, p. 69.)

**VI**
“Abhibhāyatana” có nghĩa là căn cứ hay nơi chế ngự. Những thiền mà hành giả đạt được bằng cách dùng năng lực tu tập để chế ngự cảnh kasiṇa và các pháp đối nghịch được gọi là thắng xứ. Căn cứ, nơi chốn chế ngự chính là thiền thắng xứ. Nói cách khác, thiền làm nhân cho việc chế ngự cảnh kasiṇa được gọi là thiền thắng xứ. Vì có thể chế ngự các cảnh kasiṇa, hành giả điều khiển cảnh ấy theo ý muốn, và chế ngự các pháp đối nghịch, nên thiền ấy được gọi là thiền thắng xứ. Đó là thiền sắc giới có đủ tầm v.v. (Dī-ṭīkā 2,159; Ma-ṭīkā 3,121; Aṅ-ṭīkā 3,245.)

**EN**
“Abhibhāyatana” means both mastery (abhibhū) and a basis (āyatana). The meditator's knowledge of preparatory kasiṇa development is called mastery because it overcomes the kasiṇa object and the opposing states. The jhāna in which that mastery functions as a supporting basis is called jhāna of the bases of mastery. Alternatively, it is so called because its supporting kasiṇa object is to be mastered. A fine-material jhāna with its associated states is mastery because it overcomes its kasiṇa object, and a basis because it is the footing for the meditator's special bliss. (Dīgha Subcommentary 2, p. 159; Majjhima Subcommentary 3, p. 121; Aṅguttara Subcommentary 3, p. 245.)

**VI**
Có thể chế ngự, áp đảo cảnh kasiṇa, dù cảnh ấy rất đáng ghê sợ như màu mật, hoặc có màu không tốt như màu xương, nghĩa là có thể làm cho cảnh kasiṇa ấy hiện rõ, có thể mở rộng…

**EN**
Mastering the kasiṇa object means that, whether the kasiṇa disk is very small, like bile, or rather large, like a skull, the meditator can easily and effortlessly extend it as far as desired…


<a id="M02-body-P018"></a>
## Bên trong và bên ngoài — Giải thích của chú giải / The internal and external bases of mastery
Miến / Burmese 18

**VI**
…trải khắp mười phương, tức đến vô lượng thế giới, và có thể tu tập cho đến thiền an chỉ.

**EN**
…throughout the ten directions, to the limit of the world-system, and can develop absorption upon it.

**VI**
Đức Phật đã thuyết các thiền thắng xứ này trong kinh Mahāparinibbāna (Dī 2,92–94), kinh Abhibhāyatana (Aṅ 3,125–126), bộ Dhammasaṅgaṇī (Abhi 1,64–65), cùng những kinh điển khác.

**EN**
The Buddha taught these jhānas of the bases of mastery in the Mahāparinibbānasutta (Dīgha Nikāya 2, pp. 92–94), the Abhibhāyatanasutta (Aṅguttara Nikāya 3, pp. 125–126), the Dhammasaṅgaṇī (Abhidhamma 1, pp. 64–65), and other places.

**VI**
Bên trong và bên ngoài

**EN**
INTERNALLY AND EXTERNALLY

**VI**
Trong các bài kinh, bằng những lời như “Ajjhattaṃ rūpasaññī eko bahiddhā rūpāni passati parittāni” (Dī 2,92), Đức Phật có đưa vào cách tu tập kasiṇa màu sắc nơi các thân phần bên trong. Nhưng trong bộ Dhammasaṅgaṇī thuộc Abhidhamma (Abhi 1,64–65), Ngài không thuyết cách quán kasiṇa màu sắc nơi các thân phần bên trong: “ajjhattaṃ arūpasaññī”. Chú giải giải thích nguyên nhân của việc không thuyết như sau:

**EN**
In the discourses, such expressions as “Ajjhattaṃ rūpasaññī eko bahiddhā rūpāni passati parittāni” (Dīgha Nikāya 2, p. 92) include development of colour kasiṇa on the basis of the internal body parts. In the Abhidhamma Dhammasaṅgaṇī (Abhidhamma 1, pp. 64–65), however, it says “ajjhattaṃ arūpasaññī”—without internal perception of form—and does not teach the development of colour kasiṇa from internal body parts. The commentary explains why:

**VI**
Ajjhattarūpāni anabhibhavanīyato. Tattha vā idha vā bahiddhārūpāneva abhibhavitabbāni. Tasmā tāni niyamato vattabbānīti tatthāpi idhāpi vuttāni. (Abhi-ṭṭha 1,234.)

**EN**
Ajjhattarūpāni anabhibhavanīyato. Tattha vā idha vā bahiddhārūpāneva abhibhavitabbāni. Tasmā tāni niyamato vattabbānīti tatthāpi idhāpi vuttāni. (Abhi-ṭṭha 1,234.)

**VI**
Bởi không thể chế ngự các sắc bên trong. Dù trong kinh hay ở đây, chính các sắc bên ngoài mới là những gì cần chế ngự. Vì vậy, chúng nhất thiết phải được nói đến, nên cả ở kia lẫn ở đây đều nói các sắc bên ngoài.

**EN**
Because internal forms cannot be mastered in the same way, only external forms are described as having been mastered. Therefore only external forms are stated as the definite basis, and so the statement occurs here too.

**VI**
Ajjhattarūpānaṃ anabhibhavanīyatā ca bahiddhārūpānaṃ viya avibhūtattā. (Mūlaṭīkā 1,106.)

**EN**
Ajjhattarūpānaṃ anabhibhavanīyatā ca bahiddhārūpānaṃ viya avibhūtattā. (Mūlaṭīkā 1,106.)

**VI**
Các sắc bên trong không thể được chế ngự bởi chúng không rõ ràng như các sắc bên ngoài.

**EN**
Internal forms are not mastered because they do not become manifest as distinctly as external forms.

**VI**
Avibhūtattāti idaṃ ñāṇuttarānaṃ saha nimittuppādanena appanānibbattanaṃ ārammaṇassa abhibhavo na suṭṭhu vibhūtabhāvamantareṇa sambhavatīti katvā vuttaṃ. (Anuṭīkā 1,114.)

**EN**
Avibhūtattāti idaṃ ñāṇuttarānaṃ saha nimittuppādanena appanānibbattanaṃ ārammaṇassa abhibhavo na suṭṭhu vibhūtabhāvamantareṇa sambhavatīti katvā vuttaṃ. (Anuṭīkā 1,114.)

**VI**
“Do không rõ ràng”: lời này được nói vì đối với người có tuệ thù thắng, việc chế ngự cảnh — tức làm phát sinh an chỉ cùng lúc với sự sinh khởi của tướng — không thể có nếu thiếu sự hiện rõ hết sức sáng tỏ của cảnh.

**EN**
“Because of being indistinct”: this is said with reference to the superior knowledge that, together with the sign, brings absorption about. Mastery of the object is not achieved by ordinary discrimination of it but by the distinction of its clear appearance.


<a id="M02-body-P019"></a>
## Điều kiện đạt cận định và an chỉ trên kasiṇa / Why external forms are more readily mastered
Miến / Burmese 19

**VI**
Nếu hành giả tu tập lấy sắc màu nơi 32 thân phần bên trong làm cảnh kasiṇa thì có thể thực hành sự tu tập sơ khởi, đúng như lời chú giải: “Ajjhattarūpe parikammavasena ajjhattaṃ rūpasaññī nāma hoti — do thực hành sơ khởi trên sắc bên trong mà được gọi là người có tưởng về sắc bên trong” (Dī-ṭṭha 2,151). Tuy nhiên, khi thực hành sơ khởi kasiṇa trên màu của các thân phần bên trong, sắc kasiṇa bên trong không hiện rõ như sắc kasiṇa bên ngoài.

**EN**
When the meditator develops a colour kasiṇa taking the colour present in his own thirty-two parts, preparatory development can occur in accordance with the commentary: “Ajjhattarūpe parikammavasena ajjhattaṃ rūpasaññī nāma hoti”—he is called one perceiving internal form by virtue of the preparatory work on internal form. (Dīgha Commentary 2, p. 151.) Nevertheless, when preparatory kasiṇa meditation takes the colour of the internal parts as object, those internal kasiṇa forms are not as clear as external kasiṇa forms.

**VI**
Đối với hành giả tuệ sắc bén, ngay khi tương tợ tướng sinh khởi, sau một số ít lần tốc hành thuộc cận định, an chỉ thiền có thể sinh. Điều ấy chỉ có được nhờ có thể chế ngự cảnh vòng kasiṇa. Mà việc chế ngự như vậy chỉ có thể có khi sắc kasiṇa hiện rõ; không thể có khi cảnh ấy chưa rõ. Vì sắc kasiṇa nơi các thân phần bên trong không hiện rõ, đối với chúng chỉ có thể có sự tu tập sơ khởi, không thể có sự tu tập cận định và an chỉ.

**EN**
For a meditator of keen knowledge, the appearance of the counterpart sign, the occurrence of a few access concentration impulsions, and then the arising of absorption are possible because he can master the kasiṇa disk. Such mastery is possible only when the kasiṇa form appears distinctly. Without that clarity it is not possible. Since the kasiṇa form in the internal parts does not appear distinctly, only preparatory development occurs with those internal kasiṇa forms; access and absorption do not occur on them in the account given here.

**VI**
Trong kinh cũng như trong bộ Abhidhamma này, khi nói về cách quán sắc kasiṇa, chính sắc kasiṇa màu nơi các thân phần bên ngoài mới có thể được hành giả chế ngự cho đến an chỉ. Chỉ trên sắc kasiṇa bên ngoài mới có thể tu tập đến an chỉ, vì các sắc ấy hiện rõ. Do đó, nếu muốn đạt thiền thắng xứ, sau khi thực hành tu tập sơ khởi trên sắc kasiṇa bên trong, hành giả phải tiếp tục tu tập sơ khởi, cận định và an chỉ trên sắc kasiṇa bên ngoài. Nếu không thể thực hành sơ khởi trên sắc kasiṇa bên trong, hoặc…

**EN**
In both the discourses and the Abhidhamma, the meditator masters external colour kasiṇa forms up to absorption. He can develop those external kasiṇa forms to absorption because they appear distinctly. Therefore, if he wishes to obtain jhāna of the bases of mastery, after developing preparation with internal kasiṇa forms he must proceed to preparatory development, access, and absorption with external forms. If he is unable to develop preparation on the internal forms, or…


<a id="M02-body-P020"></a>
## Hai cách thực hành — Bốn cảnh kasiṇa / With or without internal perception of form
Miến / Burmese 20

**VI**
…không muốn thực hành sơ khởi trên sắc kasiṇa bên trong, hành giả ấy chỉ tu tập sơ khởi, cận định và an chỉ trên sắc kasiṇa bên ngoài.

**EN**
…does not wish to do so, he should develop preparatory, access, and absorption meditation on external kasiṇa forms alone.

**VI**
Vì sắc kasiṇa bên ngoài nhất thiết phải được nói đến trong cả kinh lẫn Abhidhamma, nên các kinh ấy và bộ Abhidhamma này đều thuyết chúng. (Xem Abhi-ṭṭha 1,233–234; Mūlaṭīkā 1,106; Anuṭīkā 1,114.)

**EN**
Since the external kasiṇa forms are properly taught in both the discourses and the Abhidhamma, they have been taught in both places. (See Abhidhamma Commentary 1, pp. 233–234; Mūlaṭīkā 1, p. 106; Anuṭīkā 1, p. 114.)

**VI**
Tattha ajjhattaṃ arūpasaññīti alābhitāya vā anatthikatāya vā ajjhattarūpe parikammasaññāvirahito. (Abhi-ṭṭha 1,233.)

**EN**
Tattha ajjhattaṃ arūpasaññīti alābhitāya vā anatthikatāya vā ajjhattarūpe parikammasaññāvirahito. (Abhi-ṭṭha 1,233.)

**VI**
Ở đây, “người không có tưởng về sắc bên trong” là người không có tưởng sơ khởi đối với sắc bên trong, do không đạt được hoặc do không cần đến.

**EN**
Here, “without internal perception of form” means not having obtained, not being able to obtain, or being without the preparatory perception of internal form. This is an explanation for someone who, although exerting himself, cannot obtain kasiṇa jhānas on internal parts, or does not wish to develop them there.

**VI**
Lời giải thích này dành cho người tuy nỗ lực tu tập thiền trên sắc kasiṇa nơi các thân phần bên trong mà không đạt, hoặc người không muốn nỗ lực tu tập để đạt thiền trên sắc kasiṇa bên trong. Tuy vậy, trong phần giải thích về các giải thoát (vimokkhakathā), đối với những hành giả muốn cố gắng để đạt thiền trên sắc kasiṇa nơi các thân phần bên trong, có nêu rằng họ có thể đạt các thiền ấy. (Xem Aṅ 3,126; Aṅ-ṭṭha 3,245; Aṅ-ṭīkā 3,249; Abhi-ṭṭha 1,235.)

**EN**
The discussion of liberations, however, does say that a meditator who wishes to strive for kasiṇa jhānas on internal parts can attain them. (See Aṅguttara Nikāya 3, p. 126; Aṅguttara Commentary 3, p. 245; Aṅguttara Subcommentary 3, p. 249; Abhidhamma Commentary 1, p. 235.)

**VI**
Ajjhattaṃ rūpasaññī (arūpasaññī) eko bahiddhā rūpāni passati parittāni (appamāṇāni) suvaṇṇadubbaṇṇāni. (Dī 2,92; Aṅ 3,125–126; Abhi 1,55–56.)

**EN**
Ajjhattaṃ rūpasaññī (arūpasaññī) eko bahiddhā rūpāni passati parittāni (appamāṇāni) suvaṇṇadubbaṇṇāni. (Dī 2,92; Aṅ 3,125–126; Abhi 1,55–56.)

**VI**
Một người có tưởng về sắc bên trong (hoặc không có tưởng về sắc bên trong), thấy các sắc bên ngoài hữu hạn (hoặc vô lượng), đẹp và xấu.

**EN**
One who perceives form internally, or who does not perceive form internally, sees external forms that are limited or immeasurable, beautiful or ugly.

**VI**
Trong các thiền thắng xứ này, có bốn loại cảnh kasiṇa như sau…

**EN**
In the jhānas of the bases of mastery, four kinds of kasiṇa object are given, as follows…


<a id="M02-body-P021"></a>
## Bốn loại cảnh — Chuyển sang kasiṇa trắng / Four kinds of kasiṇa object; proceeding to the white kasiṇa
Miến / Burmese 21

**VI**
1. Paritta — vòng kasiṇa nhỏ, chưa được mở rộng.
2. Appamāṇaka — vòng kasiṇa đã được mở rộng.
3. Suvaṇṇa — vòng kasiṇa có màu đẹp.
4. Dubbaṇṇa — vòng kasiṇa có màu xấu.

**EN**
1. Limited (paritta): a small kasiṇa disk not yet extended.
2. Immeasurable (appamāṇa): a kasiṇa disk already enlarged and extended without limit.
3. Beautiful (suvaṇṇa): a kasiṇa disk of beautiful colour.
4. Ugly (dubbaṇṇa): a kasiṇa disk of unattractive colour.

**VI**
Như vậy có bốn loại cảnh kasiṇa. Trong đó:

**EN**
Thus four kinds of kasiṇa object are given. Among them:

**VI**
1. Paritta, vòng kasiṇa nhỏ chưa mở rộng, hiện rõ đối với người có tính tầm (vitakkacarita) nhiều.
2. Appamāṇaka, vòng kasiṇa đã được mở rộng để không còn lượng hạn, hiện rõ đối với người có tính si (mohacarita).
3. Suvaṇṇa, vòng kasiṇa có màu đẹp, hiện rõ đối với người có tính sân (dosacarita).
4. Dubbaṇṇa, vòng kasiṇa có màu xấu, hiện rõ đối với người có tính tham (rāgacarita). (Abhi-ṭṭha 1,234.)

**EN**
1. The limited, small unextended disk is given for one of discursive temperament.
2. The immeasurable disk, enlarged and extended without limit, is given for one of deluded temperament.
3. The beautifully coloured disk is given for one of aversive temperament.
4. The unattractively coloured disk is given for one strongly inclined to greed. (Abhidhamma Commentary 1, p. 234.)

**VI**
Chuyển sang kasiṇa trắng

**EN**
PROCEEDING TO THE WHITE KASIṆA

**VI**
Etadaggaṃ, bhikkhave, imesaṃ aṭṭhannaṃ abhibhāyatanānaṃ, yadidaṃ ajjhattaṃ arūpasaññī eko bahiddhā rūpāni passati odātāni odātavaṇṇāni odātanidassanāni odātanibhāsāni, tāni abhibhuyya “jānāmi passāmī”ti evaṃsaññī hoti. (Aṅ 3,306, kinh Paṭhamakosala.)

**EN**
Etadaggaṃ, bhikkhave, imesaṃ aṭṭhannaṃ abhibhāyatanānaṃ, yadidaṃ ajjhattaṃ arūpasaññī eko bahiddhā rūpāni passati odātāni odātavaṇṇāni odātanidassanāni odātanibhāsāni, tāni abhibhuyya “jānāmi passāmī”ti evaṃsaññī hoti. (Aṅ 3,306, kinh Paṭhamakosala.)

**VI**
Này các tỳ-khưu, trong tám thiền thắng xứ này, đây là tối thượng: một hành giả không quán sắc màu nơi các thân phần bên trong của chính mình, mà thấy các sắc bên ngoài màu trắng…

**EN**
Bhikkhus, among the eight bases of mastery, the foremost is this: without perceiving form in his internal continuity, a meditator sees external forms…


<a id="M02-body-P022"></a>
## Trình tự chuyển sang kasiṇa trắng / Taking white as the meditation object
Miến / Burmese 22

**VI**
…có sắc trắng, có màu trắng, có dáng trắng, có ánh trắng. Chế ngự các sắc ấy, vị ấy có tưởng “ta biết, ta thấy”. Thiền thắng xứ này là thù thắng nhất, tối thượng nhất. (Aṅ 3,306.)

**EN**
…white, of white colour, white in appearance, and white in lustre. Having mastered them, he is percipient thus: “I know, I see.” This is the foremost and finest jhāna of the bases of mastery. (Aṅguttara Nikāya 3, p. 306.)

**VI**
Theo lời dạy trên, trong bốn kasiṇa màu sắc, kasiṇa trắng là kasiṇa thù thắng, thanh tịnh nhất, vì có thể làm cho tâm hành giả trong sáng, sạch sẽ. Do đó, chúng tôi trình bày tiếp cách quán kasiṇa trắng.

**EN**
According to this discourse, among the four colour kasiṇas the white kasiṇa is foremost, as it makes the meditator's mind especially clear. I shall therefore explain the method of developing it first.

**VI**
1. An lập lại tứ thiền niệm hơi thở. Khi năng lực ánh sáng trở nên rực rỡ, sáng chói…
2. Quán 32 thân phần bên trong.
3. Quán 32 thân phần bên ngoài nơi một chúng sinh ở gần nhất, hoặc một chúng sinh trong vùng ánh sáng có thể chạm đến.
4. Quán bộ xương trong 32 thân phần bên ngoài ấy. Có thể quán bộ xương bằng cách tác ý theo tính chất bất tịnh, hoặc quán nó theo màu sắc và hình dáng.
5. Chọn một nơi bất kỳ trên bộ xương bên ngoài ấy, hoặc lấy màu trắng của toàn bộ bộ xương, hoặc lấy hộp sọ; tác ý “odāta, odāta — trắng, trắng”.

**EN**
1. Re-establish ānāpāna fourth-jhāna concentration. When the light is brilliant and radiant:
2. Discern the thirty-two internal parts.
3. Discern the thirty-two external parts of the person directly in front of you, or the nearest person reached by the light.
4. Discern the skeleton among those thirty-two external parts. (Attend to its repulsiveness if you wish; otherwise simply discern the skeleton.)
5. Choose the whitest part of that external skeleton. If the entire skeleton is white, take it as a whole; or take the skull as object. Attend “odāta, odāta—white, white.”

**VI**
Nếu vị thiện nhân đã tác ý bất tịnh nơi bộ xương bên trong, đạt sơ thiền, và bộ xương bên trong có màu trắng rõ ràng, thì có thể lấy chính màu trắng ấy…

**EN**
If you have a keen mind, and have attained the first jhāna by attending to repulsiveness in the internal skeleton, when that skeleton appears white, take its white colour as object…


<a id="M02-body-P023"></a>
## Từ bộ xương bất tịnh đến kasiṇa trắng / Developing the white sign
Miến / Burmese 23

**VI**
…để thực hành tu tập sơ khởi kasiṇa trắng. Nếu không thể, hoặc không muốn, quán sắc kasiṇa bên trong đến an chỉ thiền thì chỉ an lập định sơ khởi rồi tiếp tục quán kasiṇa trắng bằng cách lấy màu trắng của bộ xương bên ngoài làm cảnh.

**EN**
…for preparatory development, if you wish. If you cannot, or do not wish to, develop the internal kasiṇa form to absorption, establish only preparatory concentration on it and proceed to develop white kasiṇa taking the white colour of the external skeleton.

**VI**
Cũng có thể chuyển thẳng từ bộ xương bên ngoài sang kasiṇa trắng theo trình tự đã nói. Tác ý bất tịnh trên bộ xương bên ngoài nhằm ba mục đích: học cách tu tập tác ý bất tịnh, làm cho cảnh bộ xương vững chắc, và làm cho bộ xương trở nên trắng. Nhưng cũng có thể chuyển thẳng sang kasiṇa trắng mà không tác ý bất tịnh. Lấy màu trắng của bộ xương bên ngoài, nhất là màu trắng của hộp sọ, làm cảnh; tác ý “odāta, odāta — trắng, trắng” rồi cố gắng an trú niệm tu tập vững chắc một giờ, hai giờ, v.v.

**EN**
Alternatively, proceed directly to white kasiṇa from the external skeleton as described above. Attending to repulsiveness in the external skeleton is a means of practising attention to repulsiveness, steadying the skeleton object, and making it appear white. You may proceed to white kasiṇa without attending to repulsiveness if you wish. Take the white colour of the external skeleton, especially the skull, attend “odāta, odāta—white, white,” and strive to keep the meditating mind quietly established there for an hour, two hours, or longer.

**VI**
Được trợ giúp bởi nền tảng mạnh mẽ là tứ thiền niệm hơi thở, pháp hành kasiṇa trắng nơi người có pāramī thù thắng thường vững chắc trên cảnh trắng trong thời gian rất ngắn. Nếu có thể an trú vững chắc trên cảnh trắng một hoặc hai giờ, bộ xương không còn được nhận biết; chỉ còn vòng kasiṇa trắng. Vòng kasiṇa trắng hiện rõ như bông gòn, là học tướng. Khi vòng trắng ấy trở nên trong sáng, thanh sạch như sao mai…

**EN**
Well supported by the powerful decisive-support condition and other conditions of earlier meditation, such as ānāpāna fourth jhāna, the mind developing the white kasiṇa can remain firmly established on white. When the mind has remained quietly established on white for an hour, two hours, or more, the skeleton disappears and only the white kasiṇa disk remains. The disk white like a tuft of cotton is the learning sign. The exceptionally clear, bright disk, like the morning star, is the counterpart sign. Before the learning sign is reached…


<a id="M02-body-P024"></a>
## Tương tợ tướng — Mở rộng vòng kasiṇa trắng / Extending the white kasiṇa
Miến / Burmese 24

**VI**
…tướng bộ xương không còn nữa; tất cả chỉ là một tướng kasiṇa.

**EN**
…the skeleton signs, not yet pure white, are only preparatory signs.

**VI**
Nếu vị thiện nhân đã thực hành kasiṇa trắng trong Giáo pháp của các Đức Phật quá khứ, hoặc trong Giáo pháp Đức Phật hiện tại, và đã tích lũy pāramī kasiṇa trắng, thì khi tương tợ tướng trắng trong sáng hiện ra, vòng kasiṇa trắng có thể tự nhiên lan tỏa ra mười phương, ngay lúc tác ý “trắng, trắng”.

**EN**
If you possess pāramīs and supportive wholesome kamma from cultivating the white kasiṇa in earlier lives in this dispensation or those of earlier Buddhas, when the learning sign or counterpart sign is reached, the white disk may extend effortlessly in all ten directions as you attend “white, white,” without any special effort to extend it.

**VI**
Nếu vòng kasiṇa trắng chưa mở rộng, hãy tiếp tục lấy chính vòng ấy làm cảnh, tác ý “trắng, trắng” cho đến khi trắng tinh và hết sức sáng trong. Tiếp tục an lập định. Khi đã đạt tương tợ tướng trắng tinh, hết sức sạch sẽ, sáng trong, tiếp tục lấy tướng ấy làm cảnh mà tu tập “trắng, trắng” thì có thể đạt sơ thiền. Tuy nhiên, định ấy thường chưa vững, không tồn tại lâu. Vì vậy, cần mở rộng tương tợ tướng để định được vững chắc lâu dài.

**EN**
If the white disk does not spread, continue establishing concentration on it as “white, white” until it is pure white, exceptionally clear, and bright. When you reach the pure, clear, brilliant counterpart sign and continue developing it as “white, white,” you can reach first-jhāna concentration. But the concentration may be unstable and may not last long. Therefore extend the counterpart sign to make concentration stable and enduring.

**VI**
Khi đã an trú vững chắc trên tương tợ tướng kasiṇa trắng một hoặc hai giờ, hãy mở rộng bằng sự quyết định: “Mong vòng kasiṇa trắng này lan rộng bằng một đốt ngón tay; bằng một ngón tay; bằng hai ngón tay; bằng ba ngón tay…”. Tùy theo năng lực tu tập, hãy mở rộng từng đốt, từng ngón, hoặc một gang…

**EN**
When the mind is quietly established on that white counterpart sign for an hour, two hours, or more, resolve, in accordance with the strength of your knowledge, “May the white kasiṇa disk spread all around by a fingerbreadth, or by two, three, or four fingerbreadths.” Extend it by a fingerbreadth, two fingerbreadths…


<a id="M02-body-P025"></a>
## Cách mở rộng và an trú trên kasiṇa trắng / Stabilising the extended sign
Miến / Burmese 25

**VI**
…hai gang, v.v. Hãy quyết định phạm vi muốn mở rộng trước rồi mới mở rộng vòng kasiṇa theo phạm vi đã quyết định. Khi mở rộng đúng phạm vi ấy, vòng kasiṇa sẽ lay động. Khi ấy, hãy tác ý “trắng, trắng” để vòng kasiṇa ngừng lay động. Nhờ sức định, vòng kasiṇa sẽ đứng yên trở lại.

**EN**
…and so on. Extend it by resolving on a definite measure. Do not extend the disk without delimiting it by one fingerbreadth, two fingerbreadths, and so on. When extended by such a resolution, the disk may move slightly. Continue attending “white, white” to make it still. When concentration becomes strong, the disk will become still.

**VI**
Sau khi đã đứng yên, đừng tiếp tục mở rộng ngay. Hãy an trú định trên vòng ấy một lúc. Khi vòng kasiṇa đã ổn định, hãy tiếp tục mở rộng: quyết định “mong lan rộng một khuỷu tay, mong lan rộng hai khuỷu tay”, v.v. Cứ theo cách ấy mà mở rộng vòng kasiṇa ra mười phương, cho đến khi không có giới hạn. Ở bất kỳ phương nào trong mười phương, khi nhìn bằng tuệ, hãy làm cho chỉ còn hiện ra màu trắng, hoàn toàn không còn thấy các tướng của những vật khác.

**EN**
Once it is still, again delimit and resolve on an extension in the same way. As it gradually spreads, resolve, “May it extend a cubit; may it extend a fathom,” and so forth, extending it progressively. In this way extend the disk without limit in all ten directions. Wherever you look in the ten directions, let it be white. Within and without, let there be no perception of a being, only white.

**VI**
Nếu vòng kasiṇa trắng lay động và niệm tu tập chưa an trú vững chắc, hãy ngừng mở rộng. Hướng tâm vào màu trắng của phần vòng kasiṇa đang lay động, an trú niệm tu tập tại đó một giờ, hai giờ hoặc lâu hơn, như dùng một cây đinh ghim vào một điểm trên vòng trắng. Khi niệm tu tập vững chắc, vòng kasiṇa trắng không còn lay động và trở nên ổn định. Khi tâm vững chắc, vòng kasiṇa trắng cũng sáng trong, thanh sạch, rạng rỡ, óng ánh hơn.

**EN**
If the white kasiṇa disk is moving, keep the meditating mind steadily on the white object and make the disk still. Fix the mind on one place in the extended white kasiṇa, as one might fix a roof tile in place on a wall, and attend only “white, white.” As the meditating mind becomes firmly established on the white object, the white kasiṇa also ceases moving and becomes still.

**VI**
Nếu niệm tu tập chưa an trú vững chắc trên cảnh trắng đã mở rộng, hoặc cảnh trắng vẫn lay động, hãy gắn tâm vào một nơi trên vòng kasiṇa trắng đã mở rộng ấy, như treo một chiếc mũ trên bức tường, và chỉ tác ý “trắng, trắng”. Khi tâm tu tập an trú vững chắc, vòng kasiṇa cũng hết lay động và trở nên vững chắc. Khi tâm lắng yên và vòng trắng ổn định, vòng kasiṇa sẽ trở nên trắng tinh, hết sức sạch sẽ và sáng trong.

**EN**
When the mindfulness of development has not yet become firmly established, continue practising. When both mind and white kasiṇa are still, the white kasiṇa becomes pure white, exceptionally clear and clean. This is the counterpart sign obtained again after enlarging the white kasiṇa disk. Keep the meditating mind quietly established on it for an hour, two hours, or longer…


<a id="M02-body-P026"></a>
## Năm thiền chi của kasiṇa trắng / Five jhāna factors of the white kasiṇa
Miến / Burmese 26

**VI**
…tác ý “trắng, trắng” cho tâm an trú vững chắc. Khi nhiều lần tác ý trên tương tợ tướng ấy, tâm tu tập an trú vững chắc trên cảnh tương tợ tướng. Khi ấy, năm thiền chi của tâm thiền đang an trú trên cảnh tương tợ tướng kasiṇa trắng hết sức thanh sạch, sáng trong ấy sẽ hiện rõ. Lúc ấy hành giả đã đạt sơ thiền.

**EN**
…attending only “white, white.” When repeatedly attending to that counterpart sign, the meditating mind becomes quiet and steady, closely focused and deeply absorbed in it. The five jhāna factors become very distinct and strong. At that time first-jhāna concentration has been attained.

**VI**
Năm thiền chi

**EN**
THE FIVE JHĀNA FACTORS

**VI**
1. Vitakka — tầm: hướng và đặt tâm lên cảnh tương tợ tướng kasiṇa trắng.
2. Vicāra — tứ: liên tục xem xét cảnh tương tợ tướng kasiṇa trắng là “trắng, trắng”.
3. Pīti — hỷ: hoan hỷ đối với cảnh tương tợ tướng kasiṇa trắng.
4. Sukha — lạc: cảm thọ an vui, êm dịu khi nếm trải hương vị của cảnh tương tợ tướng kasiṇa trắng.
5. Ekaggatā — nhất tâm: tâm an trú vững chắc, hợp nhất trên một cảnh tương tợ tướng kasiṇa trắng.

**EN**
1. Applied thought (vitakka): directing and placing the mind on the white kasiṇa counterpart sign.
2. Sustained thought (vicāra): repeatedly examining it as “white, white.”
3. Joy (pīti): delighting in the white kasiṇa counterpart sign.
4. Bliss (sukha): pleasantly experiencing the taste of that object.
5. One-pointedness (ekaggatā): the mind falling upon and remaining steady on that single white kasiṇa counterpart sign.

**VI**
Năm pháp như tầm v.v. được gọi là các chi của thiền (jhānaṅga); tập hợp các thiền chi ấy được gọi là thiền. Hãy luyện tập năm pháp thuần thục của sơ thiền ấy. Khi đã thuần thục năm pháp, cũng tiếp tục tu tập nhị thiền, tam thiền và tứ thiền theo cách đã trình bày trong niệm hơi thở.

**EN**
Applied thought and the others, taken individually, are jhāna factors; the group of factors is called jhāna. Practise the five kinds of mastery of this first jhāna. When proficient in all five, proceed in order to the second, third, and fourth jhānas, as explained in the ānāpāna meditation subject.


<a id="M02-body-P027"></a>
## Phương pháp bốn thiền và năm thiền / The fourfold and fivefold jhāna schemes
Miến / Burmese 27

**VI**
Phương pháp bốn thiền

**EN**
THE FOURFOLD METHOD — FOUR JHĀNAS

**VI**
1. Sơ thiền: có năm thiền chi — tầm, tứ, hỷ, lạc, nhất tâm.
2. Nhị thiền: có ba thiền chi — hỷ, lạc, nhất tâm.
3. Tam thiền: có hai thiền chi — lạc, nhất tâm.
4. Tứ thiền: có hai thiền chi — xả, nhất tâm.

**EN**
1. First jhāna: five factors—applied thought, sustained thought, joy, bliss, and one-pointedness.
2. Second jhāna: three factors—joy, bliss, and one-pointedness.
3. Third jhāna: two factors—bliss and one-pointedness.
4. Fourth jhāna: two factors—equanimity and one-pointedness.

**VI**
Phương pháp năm thiền

**EN**
THE FIVEFOLD METHOD — FIVE JHĀNAS

**VI**
1. Sơ thiền: có năm thiền chi — tầm, tứ, hỷ, lạc, nhất tâm.
2. Nhị thiền: có bốn thiền chi — tứ, hỷ, lạc, nhất tâm.
3. Tam thiền: có ba thiền chi — hỷ, lạc, nhất tâm.
4. Tứ thiền: có hai thiền chi — lạc, nhất tâm.
5. Ngũ thiền: có hai thiền chi — xả, nhất tâm.

**EN**
1. First jhāna: five factors—applied thought, sustained thought, joy, bliss, and one-pointedness.
2. Second jhāna: four factors—sustained thought, joy, bliss, and one-pointedness.
3. Third jhāna: three factors—joy, bliss, and one-pointedness.
4. Fourth jhāna: two factors—bliss and one-pointedness.
5. Fifth jhāna: two factors—equanimity and one-pointedness.

**VI**
Phương pháp năm thiền được lập thành năm bậc do lần lượt vượt qua tầm rồi vượt qua tứ; phương pháp bốn thiền được lập thành bốn bậc do cùng lúc vượt qua cả tầm và tứ. Theo mỗi mức độ mạnh yếu của tuệ hành giả, việc vượt qua hai chi ấy có thể xảy ra khác nhau. Vì vậy Đức Phật thuyết cả hai phương pháp. Nếu tuệ sắc bén, hai thiền chi có thể được vượt qua cùng lúc; nếu tuệ chưa sắc bén bằng thì lần lượt vượt qua từng chi.

**EN**
In the fivefold method, applied thought and sustained thought are abandoned one at a time; thus there are five jhānas. In the fourfold method, they are abandoned together; thus there are four. To suit the inclinations of those to be trained—devas, humans, and Brahmās—the Buddha taught the fivefold method to those of slower knowledge and the fourfold method to those of keen knowledge. These are fine-material jhānas, capable of leading to the fine-material plane.

**VI**
Khi tu tập các thiền kasiṇa màu sắc, không phải nhằm mục đích phát triển những thần thông thế gian như biến hóa thân. Mục đích là an lập định làm nền tảng cho minh sát…

**EN**
In practising these kasiṇa jhānas, however, the work of establishing concentration is not undertaken with the intention of reaching the fine-material plane…


<a id="M02-body-P028"></a>
## Những cảnh trắng có thể sử dụng / Other objects for the white kasiṇa
Miến / Burmese 28

**VI**
…đó là an lập định có thể làm nền tảng cho sự tu tập tuệ minh sát.

**EN**
…It is undertaken to establish concentration as a basis for insight.

**VI**
Hành giả đã tu tập kasiṇa trắng lấy bộ xương bên ngoài làm cảnh đến tứ thiền một cách vững chắc, thuần thục, cũng nên tiếp tục tu tập lấy màu trắng của xương bên trong làm cảnh cho đến tứ thiền. Tương tự, có thể đạt tướng vòng kasiṇa trắng nhờ:

**EN**
A meditator who has thoroughly developed the white kasiṇa based on the external skeleton up to fourth-jhāna concentration should proceed to develop it to the fourth jhāna with the white colour of the internal skeleton as object. Thereafter the white kasiṇa sign can be taken from:

**VI**
1. Những bông hoa trắng như hoa huệ, hoa nhài, hoa ngọc lan.
2. Một tấm vải trắng.
3. Một tờ giấy trắng.
4. Những đám mây trắng trên bầu trời.

**EN**
1. White flowers such as akyaw, jasmine, and myat-lei.
2. White cloth.
3. White paper.
4. A white stone slab, such as marble.

**VI**
Nếu hành giả đã an lập thành công định đến tứ thiền bằng bộ xương, thì ngay khi tác ý nơi một vật màu trắng bất kỳ — chẳng hạn lấy một tấm vải trắng làm vòng kasiṇa — vòng kasiṇa trắng có thể sinh khởi trong tâm, lớn dần và dễ dàng lan tỏa vô lượng về bất kỳ phương nào mình muốn. Khi ấy hãy tiếp tục tu tập cho đến tứ thiền.

**EN**
When a meditator has successfully established white kasiṇa concentration on the skeleton up to the fourth jhāna, he can attend to the whiteness of any white object without making a separate disk. Merely attending to the white colour of that object, the white kasiṇa disk can arise at once and spread easily in all ten directions without special effort to extend it. Then strive to develop from first-jhāna concentration up to fourth-jhāna concentration.


<a id="M02-body-P029"></a>
## Kasiṇa xanh (nīlakasiṇa) — Ba tướng và ba giai đoạn tu tập / The blue kasiṇa (nīlakasiṇa)
Miến / Burmese 29

**VI**
Hành giả muốn tu tập kasiṇa xanh đen trước hết hãy an lập lại định tứ thiền kasiṇa trắng. Quán lại 32 thân phần. Lấy tóc màu xanh đen của một hành giả đang ngồi phía trước làm cảnh. Khi thấy rõ tóc xanh đen ấy bằng tuệ, hãy tác ý “nīla, nīla — xanh đen, xanh đen”. Định sơ khởi kasiṇa xanh đen, được trợ giúp bởi cận y duyên mạnh mẽ là các định tu tập trước đó, cũng sẽ trở nên mạnh mẽ; trong thời gian không lâu, hành giả không còn thấy tóc mà chỉ thấy một vòng kasiṇa xanh đen. Lấy vòng kasiṇa ấy làm cảnh và tiếp tục an lập định.

**EN**
A meditator wishing to develop the blue kasiṇa should re-establish white kasiṇa fourth-jhāna concentration and discern the thirty-two parts again. Take the blue-black head hair of a meditator sitting in front of you as object. When the blue-black hair appears clearly to knowledge, attend “nīla, nīla—blue, blue.” Supported by the powerful decisive-support condition of earlier concentration, preparatory blue kasiṇa concentration becomes stronger. Before long, instead of the hair you will see only the blue kasiṇa disk. Take that disk as object and continue establishing concentration.

**VI**
Tiếp tục quán cho đến khi lần lượt đạt ba tướng: chuẩn bị tướng, học tướng, tương tợ tướng; ba sự tu tập: tu tập sơ khởi, tu tập cận định, tu tập an chỉ; và ba loại định: định sơ khởi, cận định, an chỉ định.

**EN**
Continue attending and establishing concentration as explained for the white kasiṇa until, in due order, you obtain the three signs—preparatory, learning, and counterpart; the three kinds of development—preparatory, access, and absorption; and the three kinds of concentration—preparatory, access, and absorption.

**VI**
Khi còn thấy tướng tóc thông thường đúng là tóc thì đó là chuẩn bị tướng; sự tu tập lúc ấy là tu tập sơ khởi, định ấy là định sơ khởi. Khi tiếp tục an lập định, không còn thấy tóc mà một vòng kasiṇa hiện rõ trong tuệ hành giả, đó là học tướng. Các khuyết điểm của kasiṇa vẫn hiện rõ trong học tướng. Tiếp tục lấy học tướng ấy làm cảnh mà an lập định…

**EN**
When the ordinary sign of the hair still appears as hair, it is the preparatory sign, the development is preparatory development, and the concentration preparatory concentration. As concentration is developed further, the hair no longer appears; a kasiṇa disk appears to the meditator's knowledge. That is the learning sign. Its defects are still visible. When, taking that learning sign as object, you continue establishing concentration…


<a id="M02-body-P030"></a>
## Tương tợ tướng của kasiṇa xanh / The three signs and three stages of concentration
Miến / Burmese 30

**VI**
…thì sự tu tập vẫn là tu tập sơ khởi, định vẫn là định sơ khởi. Khi định lấy học tướng làm cảnh dần dần chín muồi, tướng chuyển từ học tướng sang tương tợ tướng. Tương tợ tướng hiện rõ như một vòng quạt làm bằng ngọc indanīla, tách khỏi vòng kasiṇa và hiện hữu trên không. Ở sát-na này, vẫn còn tu tập sơ khởi và định sơ khởi.

**EN**
…the development is still preparatory development and the concentration still preparatory concentration. As concentration on the learning sign matures, the sign passes to the counterpart stage. The counterpart sign appears apart from the disk, like a fan of blue gems standing in the air. Even then the development and concentration may still be preparatory.

**VI**
Tuy nhiên, nếu tiếp tục làm cho định chín muồi, tương tợ tướng sẽ càng sáng trong hơn. Đôi khi tâm tu tập chìm vào cảnh tướng ấy. Định ngay trước khi chìm vào là cận định; sự tu tập ấy là tu tập cận định. Nếu tâm tu tập đã chìm vào cảnh ấy thì định khi chìm vào ấy là định an chỉ thiền, sự tu tập là tu tập an chỉ.

**EN**
However, as you continue to mature concentration, the counterpart sign becomes clearer and brighter. The meditating mind occasionally sinks into that sign. The concentration before it sinks into the sign is access concentration, and the development is access development. When the mind sinks into that sign, the concentration is absorption-jhāna concentration and the development absorption development.

**VI**
Nhưng an chỉ định ấy có thể chưa tồn tại lâu. Để tồn tại lâu, hãy mở rộng vòng kasiṇa ra mười phương không giới hạn, ngay trong cận định hoặc trong an chỉ thiền. Sau khi đã mở rộng, lấy một phần vòng kasiṇa xanh đen ngay phía trước làm cảnh, tiếp tục an lập định thì có thể đạt an chỉ thiền vững chắc lâu dài. Ngay khi đã mở rộng vòng kasiṇa, hành giả cũng lần lượt có thể đạt:

**EN**
That absorption may not yet endure. To make it last, at access concentration or absorption concentration extend the kasiṇa disk without limit in all ten directions. Then take as object one part of that extended blue kasiṇa directly in front of you and continue establishing concentration. You can attain absorption-jhāna concentration, and that concentration can endure. After extending the disk in this way, one obtains in succession:

**VI**
1. Ba tướng: chuẩn bị tướng, học tướng, tương tợ tướng.
2. Ba sự tu tập: tu tập sơ khởi, tu tập cận định, tu tập an chỉ.
3. Ba loại định: định sơ khởi, cận định, an chỉ định.

**EN**
1. Three signs: the preparatory sign (parikammanimitta), learning sign (uggahanimitta), and counterpart sign (paṭibhāganimitta).
2. Three kinds of development: preparatory (parikammabhāvanā), access (upacārabhāvanā), and absorption (appanābhāvanā).
3. Three kinds of concentration: preparatory (parikammasamādhi), access (upacārasamādhi), and absorption (appanāsamādhi).


<a id="M02-body-P031"></a>
## Các cảnh xanh đen — Kasiṇa vàng / Developing the blue kasiṇa on other objects
Miến / Burmese 31

**VI**
Tiếp tục an lập định cho đến tứ thiền. Nếu đã thành công, cũng lấy tóc bên trong làm cảnh và thử quán; có thể an lập định đến tứ thiền. Sau đó lấy mật bên ngoài làm cảnh mà tu tập kasiṇa xanh đen; cũng có thể đạt tứ thiền. Nếu đã an lập thành công tứ thiền kasiṇa xanh đen từ mật bên ngoài, hãy lấy mật bên trong làm cảnh tu tập kasiṇa xanh đen.

**EN**
Continue establishing concentration up to the fourth jhāna. When successful, take your own head hair as object and practise in the same way; you can establish concentration up to the fourth jhāna. Next take external bile as object and develop the blue kasiṇa in the same way, up to fourth-jhāna concentration. After establishing blue kasiṇa concentration up to the fourth jhāna with external bile as object, practise likewise with internal bile.

**VI**
Một bông hoa xanh đen ấy cũng có thể làm cảnh cận y mạnh mẽ, nâng đỡ tâm tu tập của hành giả cho đến tứ thiền, nhờ cảnh cận y duyên (ārammaṇūpanissayapaccaya). Đó chính là rút lấy tinh hoa tu tập gọi là định tứ thiền từ một bông hoa. Đối với người biết như lý tác ý, những thiện pháp cao quý như thiện thiền định hoặc thiện minh sát luôn chờ đợi người ấy.

**EN**
When successful, take a blue flower such as aung-me-nyo or myat-khwa-nyo and endeavour to develop the blue kasiṇa. A single blue flower can become a powerful supporting object leading the meditator's mind to fourth-jhāna concentration, through the force of the object decisive-support condition (ārammaṇūpanissayapaccaya). This is drawing the essence of fourth-jhāna concentration from a single flower. For one who knows how to attend wisely and correctly, lofty wholesome states such as jhāna and insight are always waiting to arise.

**VI**
Tương tự, hãy lấy làm cảnh: 1. những bông hoa xanh đen khác; 2. vải màu xanh đen; 3. những loại đá xanh đen như đá añjana — rồi quán cùng một cách.

**EN**
Likewise, take other blue flowers, blue cloth, or blue stones such as sapphires as object, and practise in the same way.


<a id="M02-body-P032"></a>
## Kasiṇa vàng (pītakasiṇa) / The yellow kasiṇa (pītakasiṇa)
Miến / Burmese 32

**VI**
An lập lại bất kỳ định tứ thiền nào đã đạt. Khi nhờ định ấy mà năng lực ánh sáng rực rỡ, sáng chói, hãy dùng ánh sáng để lấy màu vàng của mỡ đặc hoặc nước tiểu trong 32 thân phần bên trong hoặc bên ngoài làm cảnh, tác ý “pītakaṃ, pītakaṃ, pītakaṃ — vàng, vàng, vàng”. Các chi tiết còn lại như đã nói đối với kasiṇa trắng và xanh đen. Hãy luân phiên tu tập cả nước tiểu bên trong và bên ngoài cho đến tứ thiền.

**EN**
Re-establish any fourth-jhāna concentration you have attained. When its light becomes brilliant and bright, use it to take as object the yellow colour of fat or urine among the thirty-two internal or external body parts. Attend “pītaka, pītaka, pītaka—yellow, yellow, yellow.” Follow the remaining instructions as explained for the white and blue kasiṇas. Develop up to fourth-jhāna concentration with internal urine and with external urine in turn.

**VI**
Phân và nước tiểu vốn là những thân phần hết sức đáng ghê sợ. Tuy nhiên, dù thân phần ấy đáng ghê sợ đến mức nào, nếu hành giả có như lý tác ý, biết hướng tâm đúng cách, và phân hay nước tiểu ấy có màu vàng, thì sắc vàng của chúng cũng có thể làm cảnh cận y mạnh mẽ, trợ giúp hành giả cho đến tứ thiền, nhờ cảnh cận y duyên (ārammaṇūpanissayapaccaya).

**EN**
Faeces and urine are by nature exceedingly repulsive body parts. However repulsive they may be, wise attention (yonisomanasikāra) is present in the continuity of a meditator who knows the proper method. If the faeces or urine is yellow, its yellow colour can stand as a powerful supporting object, supporting the meditator through the object decisive-support condition until fourth-jhāna concentration arises.

**VI**
Nếu lấy tứ thiền ấy làm nền tảng minh sát rồi chuyển sang minh sát, tùy sức pāramī, hành giả có thể tiến đến tận A-la-hán quả. Vì vậy, vị thiện nhân mong cầu Niết-bàn hãy luôn phát triển như lý tác ý. Hãy biết cách rút lấy tinh hoa tu tập từ căn nhà thân vốn không có tinh hoa bền chắc…

**EN**
Taking that fourth jhāna as a basis, if you proceed to insight you can, in accordance with your pāramīs, reach even the Fruition of Arahantship. Therefore, good meditator who aspires to Nibbāna, always cultivate wise attention. Where nothing of value is apparent…


<a id="M02-body-P033"></a>
## Hoa padauk và sắc vàng óng / Padauk and golden shower flowers
Miến / Burmese 33

**VI**
…hãy nỗ lực làm cho đời sống trở nên có giá trị.

**EN**
…learn to draw from this body the essence called meditation. Strive to make your life worthwhile.

**VI**
Hoa padauk và sắc vàng óng

**EN**
PADAUK AND GOLDEN SHOWER FLOWERS

**VI**
Những chùm hoa padauk và hoa ngù hoàng vàng óng, nở đầy cây vào khoảng tháng Tagu và Kason, như đang mời một người thiện đã tu tập kasiṇa vàng đến tứ thiền: “Hãy tới, hãy quán”. Khi gặp cây padauk hoặc cây hoa vàng nở đầy hoa, một số hành giả đã tu tập thuần thục kasiṇa vàng đến tứ thiền, dù có hay không cần nhờ các định trước trợ giúp, chỉ lấy màu vàng của những bông hoa ấy làm cảnh kasiṇa thì trong thời gian rất ngắn có thể thấy toàn thế giới như được bao phủ màu vàng, rồi dễ dàng lần lượt đạt định cho đến tứ thiền. Có người vừa đi vừa luyện tập bằng định ấy.

**EN**
Padauk blossoms are bathed in gold. Around the month of Tagu, when whole trees of padauk and golden shower are in bloom, they seem to invite the good meditator who has developed yellow kasiṇa to fourth-jhāna concentration: “Come; try contemplating.” When certain meditators thoroughly proficient in yellow kasiṇa up to the fourth jhāna see a padauk or golden shower tree in full bloom, with or without relying on their earlier concentration, they take the yellow colour of the flowers as the yellow kasiṇa sign. In a short time they see the whole world covered in yellow, and easily establish the successive levels of concentration up to the fourth jhāna. They can even practise and obtain that concentration while travelling in a vehicle.

**VI**
Đối với hành giả biết như lý tác ý, một bộ y phục màu vàng cũng có thể là nơi nương cảnh của kasiṇa vàng. Một phiến đá manosiḷā màu vàng cũng có thể là cảnh của kasiṇa vàng. Chính bộ y phục vàng hoặc phiến đá vàng ấy đang trợ giúp làm cảnh duyên cho tứ thiền sinh khởi nơi dòng tâm người tu tập kasiṇa vàng…

**EN**
For a meditator whose wise attention is established and who knows the proper method, a yellow garment too can be the sign and object of the yellow kasiṇa. A yellow slab of mineral pigment can likewise be its sign and object. That yellow garment or yellow mineral slab, for the meditator developing the yellow kasiṇa…


<a id="M02-body-P034"></a>
## Kasiṇa đỏ (lohitakasiṇa) / The red kasiṇa (lohitakasiṇa)
Miến / Burmese 34

**VI**
…nhờ cảnh duyên (ārammaṇapaccaya).

**EN**
…serves as an object condition, affording support by its power until fourth-jhāna concentration arises in the meditator's continuity.

**VI**
An lập lại một định tứ thiền đã đạt. Khi năng lực ánh sáng đặc biệt mạnh mẽ, hãy dùng ánh sáng ấy lấy màu đỏ của máu ở tim một người ngồi phía trước mình làm cảnh, tác ý “lohitaka, lohitaka, lohitaka — đỏ, đỏ, đỏ”. Khi vòng kasiṇa đỏ hiện rõ, lấy chính vòng ấy làm cảnh rồi tiếp tục an lập định. Theo cách đã trình bày, hãy mở rộng vòng kasiṇa và tiếp tục tu tập đến tứ thiền.

**EN**
Re-establish any fourth-jhāna concentration already attained. When the light becomes especially powerful, use it to take the red colour of the blood inside the heart of a meditator directly in front of you. Develop it by attending “lohitakaṃ, lohitakaṃ, lohitakaṃ—red, red, red.” When the blood disappears and the red kasiṇa disk appears, take the disk as object and continue establishing concentration. Extend it as explained above, and develop it up to the fourth jhāna.

**VI**
Có thể lấy màu đỏ của máu đọng ở vùng gan hoặc tim bên ngoài làm cảnh tu tập. Cũng có thể lấy máu bên trong tim mình, hoặc máu đọng vùng gan hay tim của chính mình làm cảnh để tu tập kasiṇa đỏ.

**EN**
You may likewise take the red colour of pooled blood around the external liver, heart, and so on. You can also develop red kasiṇa with the red colour of blood inside your own heart, or around your own liver, heart, and so on, as object.

**VI**
Đối với vị thiện nhân đã luyện tập kasiṇa đỏ thuần thục cho đến tứ thiền như vậy, một bông sen hồng cũng như đang mời: “Hãy tới, hãy quán”. Một bông hoa râm bụt đỏ rực cũng như đang mời như vậy…

**EN**
For a good meditator thoroughly proficient in red kasiṇa up to fourth-jhāna concentration, a red lotus seems to invite, “Come; try contemplating,” to develop the red kasiṇa. A reddish hibiscus flower also seems to invite him to develop the red kasiṇa…


<a id="M02-body-P035"></a>
## Những tinh hoa đưa đến A-la-hán quả / Essences leading to the noble path and fruition
Miến / Burmese 35

**VI**
…“Hãy tới, hãy quán” kasiṇa đỏ. Một viên hồng ngọc trên chiếc nhẫn cũng như đang mời: “Hãy tới, hãy quán”. Một bộ y phục nhung đỏ cũng như đang mời như vậy. Đó chính là rút lấy tinh hoa gọi là tu tập từ vũng bùn ngũ dục, năm loại cảnh đáng tham luyến, đáng yêu thích, đáng say đắm, làm phát sinh ái và tham.

**EN**
…with the words, “Come; try contemplating.” A ruby set in a ring likewise seems to say, “Come; try contemplating,” as does any reddish velvet cloth. This is how one extracts the essence of meditation from the mire of the five strands of sensual pleasure—things that entice, delight, and give rise to craving and greed.

**VI**
Những tinh hoa đưa đến A-la-hán quả

**EN**
Essences leading to the noble path and fruition

**VI**
Ngay cả một thân phần hết sức đáng ghê sợ như tóc hay mật cũng có năng lực trợ giúp cho đến tứ thiền khi làm kasiṇa xanh đen. Một bông hoa hoàng lan hết sức đáng yêu cũng có năng lực trợ giúp cho đến tứ thiền khi làm kasiṇa vàng. Một viên hồng ngọc hết sức đáng yêu cũng có năng lực trợ giúp cho đến tứ thiền khi làm kasiṇa đỏ. Một chiếc răng hết sức đáng ghê sợ cũng có năng lực trợ giúp cho đến tứ thiền khi làm kasiṇa trắng.

**EN**
Even a repulsive bodily part, such as hair or bile, can serve as a blue kasiṇa and support concentration up to the fourth jhāna. A beautiful yellow champak flower can do so as a yellow kasiṇa, a precious ruby as a red kasiṇa, and even a repulsive tooth as a white kasiṇa.

**VI**
Người hành giả có như lý tác ý có thể rút lấy tinh hoa tu tập đến tứ thiền từ vũng bùn ngũ dục ấy…

**EN**
A meditator in whom wise attention is present can extract from the mire of the five strands of sensual pleasure the essence of meditation that leads to fourth-jhāna concentration…


<a id="M02-body-P036"></a>
## Trân trọng cơ hội thực hành / Essences leading to the noble path and fruition
Miến / Burmese 36

**VI**
…vào bất cứ lúc nào. Lại nữa, lấy tứ thiền ấy làm nền tảng minh sát rồi chuyển sang minh sát, tùy sức pāramī, hành giả có thể rút lấy tinh hoa cho đến tận A-la-hán quả.

**EN**
…at any time. Furthermore, by using fourth-jhāna concentration as a basis for insight and proceeding to insight, one can extract the essences leading as far as arahant fruition, in accordance with the strength of one's perfections.

**VI**
Nếu pāramī chưa đầy đủ, chưa thể đạt A-la-hán quả mà mới chỉ đạt Nhập lưu, thì hạnh phúc Phạm thiên hết sức cao quý trong hành trình luân hồi cũng như đang đón mời người có thiền không thoái thất: “Xin hãy đến”. Dù mới là bậc Thánh Nhập lưu, một bậc Thánh đã tái sinh vào cõi Phạm thiên thì không có lệ từ cõi ấy tái sinh trở lại dục giới. Trong vòng bảy đời, vị ấy sẽ đạt A-la-hán quả và viên tịch Niết-bàn. Những vị ấy đã có tấm vé chắc chắn để an trú trong Niết-bàn, sự tịch tịnh lớn lao dập tắt đống lửa khổ luân hồi.

**EN**
Even if one's perfections are incomplete and one attains only stream-entry rather than arahant fruition, for a good person whose jhāna has not declined, the lofty happiness of the Brahmā realm stands waiting along the journey through saṃsāra, as if inviting, “Please come, please come.” Noble persons, even stream-enterers, who take rebirth in a Brahmā realm do not return from there to take rebirth in the sensual realm. Within seven lives they attain arahant fruition and attain final Nibbāna. They have already received a sure token of admission to Nibbāna, where the great fire of suffering in the round of rebirths is extinguished.

**VI**
Người thiện như quý vị, lấy niềm tin nơi Giáo pháp làm chỗ nương, có nên vì bất cứ nguyên nhân nào mà không tu tập những pháp cao quý có lợi ích lớn lao đến thế hay không? Hãy tinh cần ngay khi còn thời gian.

**EN**
Why should a good person such as you, who holds to faith in the Teaching, fail to exert yourself for these excellent and noble states of such great benefit? Make the effort while you have time.


<a id="M02-body-P037"></a>
## Kasiṇa đất (paṭhavīkasiṇa) / The earth kasiṇa (paṭhavīkasiṇa)
Miến / Burmese 37

**VI**
Có thể lấy tướng kasiṇa đất từ: 1. đất đã sửa soạn thành vòng kasiṇa; 2. đất tự nhiên chưa sửa soạn thành vòng kasiṇa, như sân đập lúa; 3. đất có phạm vi xác định; 4. đất không phải là đất không có giới hạn; 5. đất có kích thước bằng một cái mâm nhỏ; 6. đất có kích thước bằng nắp nồi hoặc nắp chảo. (Visuddhi 1,120.)

**EN**
The earth kasiṇa sign may be taken from: (1) earth prepared as a kasiṇa disk; (2) unprepared earth, such as a ploughed field or threshing floor; (3) earth with a boundary; (4) earth that is not without a boundary; (5) earth the size of a small rice sieve; or (6) earth the size of the mouth of a pot or jar. (Visuddhimagga I, 120.)

**VI**
Tattha yena atītabhavepi sāsane vā isipabbajjāya vā pabbajitvā pathavīkasiṇe catukkapañcakajjhānāni nibbattitapubbāni, evarūpassa puññavato upanissayasampannassa akatāya pathaviyā kasitaṭṭhāne vā khalamaṇḍale vā nimittaṃ uppajjati. (Visuddhi 1,120.)

**EN**
Tattha yena atītabhavepi sāsane vā isipabbajjāya vā pabbajitvā pathavīkasiṇe catukkapañcakajjhānāni nibbattitapubbāni, evarūpassa puññavato upanissayasampannassa akatāya pathaviyā kasitaṭṭhāne vā khalamaṇḍale vā nimittaṃ uppajjati. (Visuddhi 1,120.)

**VI**
Hành giả nào trong đời quá khứ đã xuất gia trong Giáo pháp, hoặc xuất gia làm đạo sĩ, và từng làm phát sinh tứ thiền hay ngũ thiền kasiṇa đất, thì người có phước và đầy đủ cận y ấy có thể làm phát sinh tướng trên đất chưa được sửa soạn, tại chỗ cày hoặc sân đập lúa.

**EN**
A meditator may have gone forth in an earlier life, either in the Buddha's dispensation or as an ascetic, and produced the fourth or fifth jhāna on the earth kasiṇa. For such a meditator, wholesome meditation in the past, supported by the accumulated merit of the perfections, serves as a powerful decisive support.

**VI**
Như vương tử Hatthipāla, Bồ-tát, nhìn dòng nước sông Hằng chưa được sửa soạn thành vòng kasiṇa, lấy tướng kasiṇa nước, thực hành sơ khởi rồi làm phát sinh các thiền (Jātaka-ṭṭha 4,483), người có đầy đủ thiện nghiệp pāramī tu tập mạnh mẽ như vậy cũng có thể ngay trên đất tự nhiên chưa sửa soạn…

**EN**
Just as the Bodhisatta Hatthipāla could take the water kasiṇa sign from the unprepared current of the Ganges and do the preliminary work that produces jhāna (Jātaka Commentary, vol. 4, p. 483), such a meditator can take the earth sign from ordinary, unprepared ground…

**Ghi chú / Note**
Dòng 4 dùng cách nói phủ định hai lần như bản in.


<a id="M02-body-P038"></a>
## Sửa soạn vòng kasiṇa đất / Taking the earth kasiṇa sign
Miến / Burmese 38

**VI**
…tại nơi cày đất hoặc trên một sân đập lúa, lấy chuẩn bị tướng, thực hành “đất, đất”, chuẩn bị tướng có thể chuyển ngay sang học tướng. (Visuddhi 1,120.)

**EN**
…such as a ploughed field or a threshing floor. As he develops the preliminary sign with “paṭhavī, paṭhavī,” it can change directly into the learning sign. (Visuddhimagga I, 120.)

**VI**
Theo các chỉ dẫn ấy, hành giả muốn lấy tướng kasiṇa đất hãy dùng que hoặc một vật gì vẽ một hình tròn trên một khoảng đất tự nhiên bằng phẳng, sạch cỏ và không có khuyết điểm như cây, gốc cây, đá, v.v. Có thể làm vòng tròn từ kích thước bằng một cái mâm nhỏ đến kích thước mình muốn.

**EN**
Following these instructions, to take the earth kasiṇa sign, select a level patch of natural ground free of grass, leaves, stones and other blemishes. Use a stick or another implement to draw a circle, from the size of a small rice sieve up to whatever size suits you.

**VI**
Aruṇavaṇṇāya mattikāya kasiṇaṃ kātabbaṃ. (Visuddhi 1,120.)

**EN**
Aruṇavaṇṇāya mattikāya kasiṇaṃ kātabbaṃ. (Visuddhi 1,120.)

**VI**
Theo chỉ dẫn của Visuddhimagga, hãy làm vòng kasiṇa trên đất màu bình minh: không quá tối cũng không quá trắng, có sắc đỏ như bình minh vừa phải. Nhìn vào vòng đất ấy và tác ý “paṭhavī, paṭhavī, paṭhavī — đất, đất, đất”.

**EN**
The Visuddhimagga directs that the disk be made of dawn-coloured clay. Use earth tinged with red like dawn, neither too dark nor too pale. Look steadily at the circle and attend: “paṭhavī, paṭhavī, paṭhavī—earth, earth, earth.”

**VI**
Có thể mở mắt rồi nhắm mắt mà quán. Nếu tướng không hiện rõ khi nhắm mắt, hãy an lập lại một định tứ thiền đã đạt. Khi ánh sáng do tứ thiền rực rỡ, hãy nhắm mắt nhìn vòng kasiṇa đất nhờ ánh sáng ấy. Vẫn tác ý “đất, đất”. Khi tướng hiện rõ, lúc mở mắt thấy thế nào, nhắm mắt cũng thấy như vậy, đã đạt học tướng. Nếu còn chưa hiện rõ, hãy mở mắt nhìn, rồi lại nhắm mắt quán…

**EN**
Open and close your eyes repeatedly to take the sign. If it remains indistinct, re-establish a fourth jhāna you have already attained. With the help of the light from that concentration, look at the prepared disk and attend, “paṭhavī, paṭhavī, paṭhavī—earth, earth, earth.” Alternatively, open and close your eyes to take the sign. When you can take it as clearly as you see it with open eyes…


<a id="M02-body-P039"></a>
## Điều không nên tác ý — Khiếm khuyết có thể gặp / What to attend to in the earth kasiṇa
Miến / Burmese 39

**VI**
…thì hành giả có thể đến chỗ mình muốn mà ngồi. Tại đó cũng an lập lại một định tứ thiền đã đạt; khi ánh sáng rực rỡ, dùng sự trợ giúp của ánh sáng ấy lấy lại tướng kasiṇa đất. Sau khi lấy được tướng ấy, hãy nhiều lần chuyên chú tu tập.

**EN**
…you may go and sit where you wish. Re-establish a fourth jhāna you already know. As its light shines brilliantly, use it to take the sign of the same disk as your object. Once you can take it again, apprehend it repeatedly.

**VI**
Na vaṇṇo paccavekkhitabbo, na lakkhaṇaṃ manasikātabbaṃ. Api ca vaṇṇaṃ amuñcitvā nissayasavaṇṇaṃ katvā ussadavasena paññattidhamme cittaṃ ṭhapetvā manasikātabbaṃ. (Visuddhi 2,122.)

**EN**
Na vaṇṇo paccavekkhitabbo, na lakkhaṇaṃ manasikātabbaṃ. Api ca vaṇṇaṃ amuñcitvā nissayasavaṇṇaṃ katvā ussadavasena paññattidhamme cittaṃ ṭhapetvā manasikātabbaṃ. (Visuddhimagga II, 122.)

**VI**
Khi tác ý nơi tướng vòng kasiṇa đất ấy, không suy xét màu sắc của vòng đất; không tác ý đặc tính cứng là đặc tính của địa đại. Tuy không bỏ màu sắc, chỉ xem màu sắc như chỗ nương, rồi an trú tâm trên pháp chế định. Không nên chỉ tác ý màu đỏ của vòng đất, vì như vậy sẽ chuyển sang kasiṇa màu đỏ. Cũng không nên chỉ tác ý đặc tính cứng, vì như vậy sẽ chuyển sang pháp hành tứ đại. Hãy lấy khái niệm đất làm cảnh, hướng tâm và niệm rằng “paṭhavī, paṭhavī — đất, đất”.

**EN**
When attending to the earth kasiṇa sign, do not examine or attend to the dawn colour of the disk. Do not attend to the hardness that characterizes the earth element in the clay. Without disregarding colour altogether, let it remain connected with its support, the disk. Go beyond it by giving prominence to earth as the underlying basis. Direct the mind to the ordinary designation “earth” and attend, “paṭhavī, paṭhavī, paṭhavī—earth, earth, earth.”

**VI**
Khiếm khuyết có thể gặp

**EN**
A possible error

**VI**
Nếu hành giả tác ý nơi màu sắc của vòng kasiṇa đất thì pháp hành kasiṇa đất sẽ chuyển thành kasiṇa màu sắc…

**EN**
If the meditator attends to the dawn colour of the earth disk, the practice becomes a colour kasiṇa rather than the earth kasiṇa…

**Ghi chú / Note**
Ảnh Miến in số dẫn Visuddhi 2,122.


<a id="M02-body-P040"></a>
## Giữ đúng cảnh đất — Học tướng và tương tợ tướng / The learning sign and the counterpart sign
Miến / Burmese 40

**VI**
…và rời khỏi pháp hành kasiṇa đất, chuyển sang kasiṇa màu sắc. Nếu hành giả lỡ tác ý tính chất cứng của địa đại nổi trội trong vòng đất thì không còn gọi là tác ý kasiṇa đất, mà gọi là tác ý pháp hành tứ đại. Hành giả đã chuyển từ con đường kasiṇa đất sang con đường tứ đại.

**EN**
…and thus shifts from the earth kasiṇa to a colour kasiṇa. If the meditator attends to the hardness of the earth element predominant in the disk, this is attention to an element meditation subject. The practice has shifted from the earth kasiṇa to contemplation of the elements.

**VI**
Một vấn đề rắc rối hơn: nếu lỡ tác ý tính chất cứng trong vòng đất, khi vòng kasiṇa lan ra mười phương thì tính cứng ấy có thể như phủ trùm toàn thân hành giả. Định càng mạnh, tính cứng càng tăng, đến mức người thiện hành giả có thể chịu không nổi. Hãy ghi nhớ và tuân theo chỉ dẫn này cả khi lấy tướng trên vòng đất thực, lẫn khi ngồi thiền nơi khác và lấy lại tướng ấy làm cảnh.

**EN**
A more troublesome problem arises if one attends to the softness of the disk. When the sign is extended in all ten directions, softness can seem to envelop the whole body. As concentration grows stronger, the softness may become so pronounced that the meditator cannot bear it. Be mindful. Observe the rule given above both when taking the sign from ordinary ground and when bringing it to mind again at your seat.

**VI**
Học tướng và tương tợ tướng

**EN**
The learning sign (uggaha-nimitta) and the counterpart sign (paṭibhāga-nimitta)

**VI**
Vòng kasiṇa đất ban đầu trên mặt đất là chuẩn bị tướng. Khi mở mắt rồi nhắm mắt lấy tướng, nếu lúc nhắm mắt tướng vòng đất vẫn hiện rõ như lúc nhìn bằng mắt mở thì đã có học tướng. Cũng vậy, khi ngồi thiền ở một nơi khác, sau khi an lập lại định tứ thiền đã đạt, hành giả có thể dùng sự trợ giúp của ánh sáng do tứ thiền ấy mà lấy lại…

**EN**
The original earth disk on the ground is the preliminary sign. Open and close your eyes to take its sign. When it appears with eyes closed just as it does with eyes open, the learning sign has arisen. Alternatively, go to your seat and establish a fourth jhāna you have already attained. Using its light, bring to mind again…


<a id="M02-body-P041"></a>
## Tướng kasiṇa đất và cách mở rộng / From the learning sign to fourth jhāna
Miến / Burmese 41

**VI**
…tướng vòng kasiṇa đất gốc đã lấy trước kia. Nếu tướng hiện rõ giống như lúc nhìn bằng mắt mở thì cũng gọi là học tướng. Khi tiếp tục tác ý, chuyên chú tu tập và an lập định trên chính học tướng ấy, tăng trưởng định ấy, năm triền cái lần lượt được loại trừ, phiền não lắng xuống; tâm an trú vững chắc bằng cận định và tương tợ tướng sinh khởi.

**EN**
…the sign of the earth disk from which you first took it. If it appears as clearly as when seen with open eyes, the learning sign has arisen in this way too. Keep attending to it, apprehending it, and strengthening concentration upon it. In due course the hindrances are suppressed, the defilements subside, the mind settles in access concentration, and the counterpart sign appears.

**VI**
Lấy tương tợ tướng làm cảnh rồi tiếp tục tác ý, an lập định, dù có mở rộng tướng hay chưa mở rộng, hành giả đều có thể đạt tứ thiền. Tuy nhiên, khi mở rộng tướng, định tu tập có thể tồn tại lâu dài; vì vậy, hãy mở rộng tướng tùy năng lực rồi quán cho đến tứ thiền.

**EN**
You may take the counterpart sign as object with or without extending it. Continued attention and development can bring concentration up to the fourth jhāna. As extending the sign helps meditative concentration endure, extend it as far as you are able, then contemplate it up to the fourth jhāna.

**VI**
Trong học tướng, những khuyết điểm của vòng kasiṇa như dấu ngón tay, vết que vẫn hiện rõ. Còn tương tợ tướng hiện ra trong sáng, sạch sẽ gấp trăm, gấp nghìn lần học tướng, như tấm gương được lấy ra khỏi túi, như đĩa xà cừ được đánh bóng, như vầng trăng tròn ra khỏi mây, hoặc như đàn sếu trắng bay trước đám mây đen; tựa như đã xuyên qua học tướng mà hiện ra. (Visuddhi 1,122.)

**EN**
In the learning sign, defects such as finger marks or stick marks may still be apparent. The counterpart sign seems to emerge through the learning sign, far clearer and purer, like a mirror disk taken from its case, a well-polished mother-of-pearl dish, the full moon emerging from clouds, or a flock of cranes against a dark cloud. (Visuddhimagga I, 122.)


<a id="M02-body-P042"></a>
## Một số hành giả — Kasiṇa nước (āpokasiṇa) / Using an existing attainment; the water kasiṇa
Miến / Burmese 42

**VI**
Như đã trình bày trên, một số hành giả lúc này đã có định tu tập mạnh mẽ nơi những kasiṇa khác trước kasiṇa đất. Đối với họ, sau khi an lập định đến tứ thiền ở một kasiṇa như kasiṇa trắng, nhờ năng lực ánh sáng rực rỡ của tứ thiền ấy, có thể dùng tuệ lấy tướng kasiṇa đất ngay tại chỗ mình đang ngồi thiền hoặc nơi đất trước mặt mà không cần đặc biệt sửa soạn vòng kasiṇa đất. Đất màu bình minh ấy có thể là học tướng. Có thể lần lượt đạt ba tướng, ba sự tu tập và ba loại định. Khi đã đạt tương tợ tướng, mở rộng tướng ấy và tiếp tục an lập định cho đến tứ thiền.

**EN**
As explained above, some meditators have already strengthened concentration on such objects as the white kasiṇa. They need not prepare a separate earth disk. Establish fourth jhāna with a kasiṇa already mastered. When the light of knowledge shines brilliantly, use it to penetrate ordinary dawn-coloured earth beneath or around the seat and take the earth kasiṇa sign. By apprehending and developing it repeatedly, the three signs, three stages of development, and three kinds of concentration can arise in order. On reaching the counterpart sign, extend it as far as you are able and continue developing it up to the fourth jhāna.

**VI**
1. Nước được đựng đầy đến miệng trong bát, chén, xô, v.v. để làm vòng kasiṇa: nước sạch, trong tự nhiên, không pha các màu xanh, vàng, trắng hoặc đỏ; như nước mưa từ trời, hoặc nước sạch tương tự.
2. Nước chưa sửa soạn thành vòng kasiṇa ở giếng, ao, hồ chứa nước một phía, hoặc nước mặn từ biển tràn vào…

**EN**
1. The water kasiṇa (āpokasiṇa) can be taken from a bowl, cup, pot or similar vessel filled to the brim with clear rainwater or equally pure water, free of admixtures of blue, yellow, white, or red.

**VI**
1. Nước đựng đầy một đồ chứa như bát, chén, nồi, được sửa soạn thành vòng kasiṇa, không có màu xanh, vàng, đỏ hay trắng: nước mưa sạch hoặc nước tinh khiết, đã được để lắng; không lẫn cặn bẩn.
2. Nước chưa được sửa soạn thành vòng kasiṇa, như nước trong ao, hồ, đầm, biển, hoặc nước mưa đọng ở nơi thấp…

**EN**
2. Water in a well, a pond, a salt pan, or seawater that has risen from the sea…


<a id="M02-body-P043"></a>
## Lấy cảnh nước làm chuẩn bị tướng / Taking the water kasiṇa sign
Miến / Burmese 43

**VI**
…hố muối đầy nước mặn, cửa sông và biển, v.v. đều có thể được lấy làm tướng kasiṇa nước. (Visuddhi 1,165.)

**EN**
…a salt pit filled with brine, a creek or the sea: the water kasiṇa sign can also be taken from such water without preparing a kasiṇa disk. (Visuddhimagga I, 165.)

**VI**
Theo những chỉ dẫn ấy, nước tốt nhất đối với một hành giả là nước giếng trong sạch. Nếu không có nước giếng, hoặc không muốn dùng nước giếng làm tướng kasiṇa nước, hãy đựng nước đầy trong bát hay nồi, rồi đợi nước đứng yên và lấy tướng. Khi lấy tướng ở giếng hoặc trong bát, nồi, chỉ lấy riêng chế định nước làm cảnh. Hãy cẩn thận đừng nhìn thành hoặc đáy giếng, hay thành và đáy đồ chứa. Chỉ nhìn nước để lấy tướng.

**EN**
Clear, clean well water is best for a meditator. If it is unavailable or you prefer not to use it, fill a bowl or pot and let the water settle before taking the sign. Whether using a well or a vessel, take only the concept of water as your object. Be careful not to look at the sides or bottom of the well or vessel. Look at the water alone to take the sign.

**VI**
Trước khi lấy tướng, an lập lại một định tứ thiền đã đạt. Khi ánh sáng mạnh mẽ, xuất thiền rồi mở mắt và nhắm mắt lấy tướng kasiṇa nước thì thường đạt nhanh hơn. Trong thời gian không lâu, có thể chuyển từ học tướng sang tương tợ tướng; đó là vì các định đã tu tập trước trợ giúp mạnh mẽ bằng cận y duyên.

**EN**
When taking the sign, first establish a fourth jhāna you already know. When the light has become strong, emerge from jhāna and open and close the eyes repeatedly to take the water sign. The practice may progress quickly from learning sign to counterpart sign. This is because earlier meditative concentration serves as a powerful decisive support for concentration on the water kasiṇa.

**VI**
Na vaṇṇo paccavekkhitabbo, na lakkhaṇaṃ manasikātabbaṃ. (Visuddhi 1,165.)

**EN**
Na vaṇṇo paccavekkhitabbo, na lakkhaṇaṃ manasikātabbaṃ. (Visuddhi 1,165.)

**VI**
Khi lấy tướng kasiṇa nước như vậy, không nên tác ý màu nước, vì sẽ chuyển sang kasiṇa màu sắc…

**EN**
When taking the water kasiṇa sign, do not attend to the colour of the water. Attending to its colour would shift the practice to a colour kasiṇa…


<a id="M02-body-P044"></a>
## Học tướng và tương tợ tướng của kasiṇa nước / The signs of the water kasiṇa
Miến / Burmese 44

**VI**
…không tác ý đặc tính chảy, kết dính (paggharaṇalakkhaṇa) của thủy đại; cũng không tác ý đặc tính lạnh (sītalakkhaṇa) của nước. Nếu tác ý các đại, sẽ chuyển sang pháp hành tứ đại. Đặc biệt, nếu tác ý tính lạnh, khi định mạnh và vòng kasiṇa mở rộng, lạnh có thể bao trùm dòng thân tâm hành giả, khiến lạnh run.

**EN**
…Do not attend to the water element's characteristic of cohesion, or to the water's coldness. Attending to an element would shift the practice to element meditation. In particular, if you attend to coldness, when concentration strengthens and the water disk is extended, cold may overwhelm you and make you shiver.

**VI**
Vì vậy, lấy màu sắc làm chỗ nương nhưng không chỉ tác ý riêng màu sắc; giữ cảnh kasiṇa nước cùng với màu sắc như chỗ nương ấy, và do thủy đại nổi trội nên đặt tâm trên chế định thế gian “āpo — nước”, tu tập “āpo, āpo, āpo — nước, nước, nước”.

**EN**
Therefore let the colour remain with the water kasiṇa that supports it, and give prominence to water. Set the mind on the ordinary designation “water” and develop it by attending, “āpo, āpo, āpo—water, water, water.”

**VI**
Học tướng và tương tợ tướng

**EN**
The learning sign and the counterpart sign

**VI**
Học tướng kasiṇa nước hiện rõ như đang lay động. Nếu lúc lấy tướng, nước có bọt hoặc bong bóng, chúng cũng hiện rõ trong tướng. Những khuyết điểm của vòng kasiṇa như sóng, gợn, bọt và bong bóng vẫn hiện rõ. Vì vậy, lấy tướng ở nước sâu và đứng yên có ít khuyết điểm hơn, tốt hơn. Tương tợ tướng không lay động, hiện ra phía trước như vòng quạt bằng ngọc maṇi đặt trên không, hoặc như vòng gương bằng ngọc. Ngay khi tướng ấy hiện rõ, nếu tiếp tục an lập định trên tướng như đã chỉ dẫn thì hành giả có thể đạt cận thiền và an chỉ thiền. (Visuddhi 1,165–166.)

**EN**
The water kasiṇa learning sign may appear to move. If the original water contained froth or bubbles, the learning sign may retain those features. Defects such as waves, froth and bubbles may still appear. Deep, still water is therefore preferable, since it has fewer defects. The counterpart sign is motionless and appears like a crystal fan set in the sky or a disk of polished metal. As soon as it appears, continue establishing concentration on it as explained above. Access and absorption can then be reached. (Visuddhimagga I, 165–166.)


<a id="M02-body-P045"></a>
## Kasiṇa lửa (tejokasiṇa) / The fire kasiṇa (tejokasiṇa)
Miến / Burmese 45

**VI**
Đối với người có thiện nghiệp tu tập kasiṇa lửa đã tích lũy trong các đời quá khứ, tướng kasiṇa lửa có thể được lấy ngay ở ngọn lửa chưa được sửa soạn thành vòng kasiṇa. Khi tình cờ nhìn ngọn lửa ở bất kỳ nơi nào đang cháy, học tướng hoặc tương tợ tướng có thể sinh khởi, như:

**EN**
A person with merit accumulated by developing the fire kasiṇa in former lives can take the sign from fire without preparing a kasiṇa disk.

**VI**
1. Ngọn lửa hoặc ánh lửa đèn.
2. Lửa ở bếp nấu ăn.
3. Đống lửa nơi nung bát.
4. Ngọn lửa của đám cháy rừng.

**EN**
The learning sign and counterpart sign can arise while watching a flame from (1) an oil lamp, (2) a cooking hearth, (3) a fire used for firing bowls, or (4) a forest fire, or while looking at flames in any other suitable fire.

**VI**
Còn hành giả chưa có thiện nghiệp pāramī tu tập kasiṇa lửa trong quá khứ thì cần sửa soạn vòng kasiṇa lửa. Hãy đốt thành một đống những mảnh củi khô có lõi, có nhựa, tại một nơi thích hợp, xếp theo kiểu nung bát, cho đến khi những ngọn lửa bốc lên thành một khối.

**EN**
A meditator without such accumulated practice should prepare a fire kasiṇa. Pile dry pieces of resinous firewood in a suitable place as for firing a bowl, and light them until flames rise.

**VI**
Khoét một lỗ tròn đường kính khoảng một gang và bốn ngón tay trên một tấm chiếu, tấm da, tấm vải thô hoặc tấm gỗ. Đặt vật có lỗ ấy phía trước rồi ngồi xuống:

**EN**
Make a circular opening about a span across in a mat, piece of leather or coarse cloth, or a wooden board. Sit with the screen in front of you.

**VI**
1. Đừng tác ý những cọng cỏ và củi đang cháy phía dưới đống lửa;
2. cũng đừng tác ý ngọn khói đang bốc lên phía trên…

**EN**
Attend neither to (1) the grass and firewood burning below nor to (2) the smoke and tongues of flame rising above…


<a id="M02-body-P046"></a>
## Không tác ý màu sắc và đặc tính của lửa / What to attend to in the fire kasiṇa
Miến / Burmese 46

**VI**
…không tác ý hai thứ ấy; không lấy vùng xung quanh mà lấy khối lửa liền nhau ở chính giữa làm học tướng và tương tợ tướng. (Visuddhi 1,166.)

**EN**
…Instead, take the learning sign and counterpart sign from the fire burning densely in the centre, as a single mass. (Visuddhimagga I, 166.)

**VI**
Không tác ý màu sắc và đặc tính

**EN**
Do not attend to colour or characteristic

**VI**
Vaṇṇo na paccavekkhitabbo, uṇhattavasena lakkhaṇaṃ na manasikātabbaṃ. (Visuddhi 1,166.)

**EN**
Vaṇṇo na paccavekkhitabbo, uṇhattavasena lakkhaṇaṃ na manasikātabbaṃ. (Visuddhi 1,166.)

**VI**
Khi lấy tướng kasiṇa lửa như vậy, đừng tác ý các màu khác nhau của ngọn lửa, như xanh đen, vàng, đỏ, v.v. Nếu tác ý màu sắc, sẽ chuyển sang kasiṇa màu sắc. Cũng đừng tác ý đặc tính nóng của lửa; nếu tác ý tính nóng, sẽ chuyển sang con đường pháp hành tứ đại.

**EN**
When taking the fire kasiṇa sign, do not attend to the flame's different colours, such as blue, yellow or red. Doing so shifts the practice to a colour kasiṇa. Do not attend to the flame's characteristic of heat, which would shift the practice to element meditation.

**VI**
Tôi từng nghe kể: một hành giả tu tập kasiṇa lửa, khi định mạnh lên đã lỡ lấy tính nóng cháy của lửa làm cảnh. Khi năng lực định lớn mạnh và vòng kasiṇa lan tỏa mười phương, tính nóng đã tác ý ban đầu trở nên hết sức rõ rệt. Không chịu nổi sức nóng ấy, vị ấy phải bỏ chạy; có cảm giác những ngọn lửa vây quanh đốt toàn thân.

**EN**
I have heard that one meditator attended to the burning heat as his fire kasiṇa concentration grew stronger. When the concentration became powerful and the disk extended in the ten directions, the heat became so vivid that he could no longer bear it and ran away. It seemed to him that flames were burning all around his body.

**VI**
Vì vậy, hành giả tu tập kasiṇa lửa chỉ lấy lửa cùng với màu sắc như chỗ nương, rồi do hỏa đại nổi trội mà đặt tâm trên chế định thế gian “tejo — lửa”…

**EN**
Therefore, in developing the fire kasiṇa, leave the colours with the fire in which they appear, and give prominence to fire. Set the mind on the ordinary designation “fire”…


<a id="M02-body-P047"></a>
## Học tướng và tương tợ tướng của kasiṇa lửa / Developing the fire kasiṇa
Miến / Burmese 47

**VI**
…tác ý, tu tập “tejo, tejo, tejo — lửa, lửa, lửa”. Nơi hành giả tu tập như vậy, học tướng và tương tợ tướng sẽ tuần tự sinh khởi. (Visuddhi 1,166.)

**EN**
…and develop it by attending, “tejo, tejo, tejo—fire, fire, fire.” For a meditator who practises in this way, the learning sign and counterpart sign arise in succession. (Visuddhimagga I, 166.)

**VI**
Theo những chỉ dẫn này, hành giả muốn tu tập kasiṇa lửa hãy an lập lại một định tứ thiền đã đạt. Trước hết, ở lửa bếp nấu cơm, đừng nhìn mảnh củi dưới đống lửa hoặc ngọn lửa ở phía trên; chỉ nhìn khối lửa giữa để thử lấy tướng kasiṇa. Nếu chưa thành công, đặt phía trước mình một cái chậu thủng có lỗ đường kính khoảng mười ngón tay, rồi lấy tướng ở ngọn lửa trước lỗ ấy. Có thể thành công. Hãy cố gắng lần lượt đạt đủ ba tướng, ba sự tu tập và ba loại định.

**EN**
To follow these instructions, re-establish a fourth jhāna you have already attained. First try taking the sign from a cooking fire. Look at the centre of the fire, leaving aside the wood below and the tongues of flame above. If this fails, place a screen with an opening about ten inches across in front of you and try taking the sign from the flame through that opening. It can succeed in this way. Make an effort to attain, in order, the three signs, the three stages of development, and the three kinds of concentration.

**VI**
Nếu trước kia từng nhìn thấy nhà cháy, làng hay thành phố cháy, hoặc cháy rừng, hành giả cũng có thể an lập lại một định tứ thiền đã đạt rồi lấy phần giữa ngọn lửa ấy làm cảnh mà tu tập kasiṇa lửa.

**EN**
If you have previously seen a house, village, town or forest on fire, you can re-establish a fourth jhāna you already know, take the centre of those flames as your object, and develop the fire kasiṇa.

**VI**
Học tướng và tương tợ tướng

**EN**
The learning sign and the counterpart sign

**VI**
Trong hai tướng sinh khởi nơi hành giả tu tập kasiṇa lửa như vậy, học tướng hiện ra giống như ngọn lửa đứt quãng, rơi xuống. Đối với người lấy tướng trên một đống lửa chưa sửa soạn thành vòng kasiṇa, các khuyết điểm của kasiṇa…

**EN**
Of these two signs, the learning sign appears like flames continually breaking and falling away. For someone who takes the fire kasiṇa sign from an unprepared fire, its defects…


<a id="M02-body-P048"></a>
## Kasiṇa gió (vāyokasiṇa) / The signs of the fire kasiṇa; the wind kasiṇa
Miến / Burmese 48

**VI**
…vẫn hiện rõ: những mảnh củi, khối than hồng, tro và khói vẫn có thể hiện ra. Tương tợ tướng thì không lay động, hiện rõ như một mảnh vải đỏ trải trên không, như một vòng quạt vàng, hoặc như một cây cột vàng. Ngay khi tương tợ tướng hiện rõ, hành giả có thể đạt cận thiền và an chỉ thiền. (Visuddhi 1,166.)

**EN**
…are apparent. Pieces of firewood, burnt wood, embers, ash or smoke may still appear. The counterpart sign is motionless, like a piece of red cloth spread in the sky, a golden fan, or a golden pillar. With its appearance, the meditator can reach access or absorption. (Visuddhimagga I, 166.)

**VI**
Kasiṇa gió

**EN**
The wind kasiṇa (vāyokasiṇa)

**VI**
Vāyokasiṇaṃ bhāvetukāmenāpi vāyusmiṃ nimittaṃ gahetabbaṃ. Tañca kho diṭṭhavasena vā phuṭṭhavasena vā. (Visuddhi 1,167.)

**EN**
Vāyokasiṇaṃ bhāvetukāmenāpi vāyusmiṃ nimittaṃ gahetabbaṃ. Tañca kho diṭṭhavasena vā phuṭṭhavasena vā. (Visuddhi 1,167.)

**VI**
Hành giả muốn tu tập kasiṇa gió phải lấy tướng nơi gió, bằng một trong hai cách: 1. bằng sự thấy; 2. bằng sự chạm. Do đó, có thể lấy tướng kasiṇa gió từ gió thổi vào ngọn cây, chóp lá, v.v. được nhìn thấy, hoặc từ gió chạm đến một phần thân của chính mình.

**EN**
A meditator who wishes to develop the wind kasiṇa should take the sign from wind, either by sight or by touch. Thus (1) you can take the sign by watching wind moving through trees or leaves, or (2) you can take the wind touching a part of your own body as the sign.

**VI**
1. Nếu muốn lấy tướng bằng cách nhìn gió thổi vào ngọn cây, chóp lá, trước hết an lập lại một định tứ thiền đã đạt; khi năng lực ánh sáng mạnh mẽ, dùng sự trợ giúp của ánh sáng ấy…

**EN**
1. To take the sign by watching wind move trees or leaves, first establish a fourth jhāna you already know. When the light is strong, use it…


<a id="M02-body-P049"></a>
## Hai cách lấy tướng gió — Kasiṇa ánh sáng / The signs of the wind kasiṇa; the light kasiṇa
Miến / Burmese 49

**VI**
…thấy gió ấy, đặt niệm nơi gió và tác ý tu tập “vāyo, vāyo, vāyo — gió, gió, gió”. Hãy lần lượt tu tập để đạt đủ ba tướng, ba sự tu tập và ba loại định.

**EN**
…to see the wind and establish mindfulness on it. Develop it by attending, “vāyo, vāyo, vāyo—wind, wind, wind.” Practise so as to attain in order the three signs, the three stages of development, and the three kinds of concentration.

**VI**
2. Nếu muốn lấy gió chạm vào một phần thân làm tướng kasiṇa gió, trước hết an lập lại một định tứ thiền đã đạt. Khi năng lực ánh sáng mạnh mẽ, đặt niệm vào khối gió đi qua cửa sổ rồi chạm một phần thân, tác ý “vāyo, vāyo, vāyo — gió, gió, gió”. An lập định tuần tự đến tứ thiền; tu tập lần lượt cho đủ ba loại định.

**EN**
2. To take as the sign the wind that touches your own body, first re-establish a fourth jhāna you already know. When the light grows strong, establish mindfulness on the wind that enters through a window or the like and touches a part of your body. Develop it by attending, “vāyo, vāyo, vāyo—wind, wind, wind.” Establish concentration in stages up to the fourth jhāna. Practise so as to attain the three kinds of concentration in order.

**VI**
Học tướng và tương tợ tướng

**EN**
The learning sign and the counterpart sign

**VI**
Học tướng hiện rõ với sự lay động như một khối hơi bốc lên từ cơm sữa vừa nhấc khỏi bếp. Tương tợ tướng hiện rõ với trạng thái đứng yên, không lay động. Những chi tiết còn lại như trên. (Visuddhi 1,167.)

**EN**
The learning sign appears to move, like steam rising from rice just taken off the stove. The counterpart sign appears still and motionless. Understand the rest in the same way. (Visuddhimagga I, 167.)

**VI**
Kasiṇa ánh sáng (ālokakasiṇa)

**EN**
The light kasiṇa (ālokakasiṇa)

**VI**
Hành giả muốn lấy tướng kasiṇa ánh sáng có thể lấy từ một vòng ánh trăng hoặc ánh mặt trời hiện ra do đi qua: 1. một lỗ trên tường; 2. một lỗ khóa; 3. một cửa sổ…

**EN**
A meditator who wishes to take the light kasiṇa sign may use a patch of sunlight or moonlight entering (1) through a hole in a wall, (2) through a keyhole, or (3) through a window…


<a id="M02-body-P050"></a>
## Sửa soạn cảnh kasiṇa ánh sáng / Taking the light kasiṇa sign
Miến / Burmese 50

**VI**
…lấy tướng nơi bất kỳ một vòng ánh sáng ấy. (Visuddhi 1,169.)

**EN**
…and take the sign from any one of these patches of light. (Visuddhimagga I, 169.)

**VI**
Người đã có pāramī, thiện nghiệp tu tập kasiṇa ánh sáng trong quá khứ, chỉ nhìn vòng ánh mặt trời hoặc ánh trăng xuyên qua một lỗ như lỗ tường, hiện trên tường hay mặt đất, là học tướng và tương tợ tướng có thể sinh khởi. Chỉ nhìn vòng ánh sáng xuyên qua kẽ giữa những cành của một cây có tán lá dày, hoặc qua chỗ hở của một giàn cành lá dày đặc, rồi hiện trên mặt đất, học tướng và tương tợ tướng cũng có thể sinh khởi. (Visuddhi 1,169.)

**EN**
For someone with wholesome merit and perfections from previous practice of the light kasiṇa, the learning sign and counterpart sign may appear simply upon seeing a patch of sunlight or moonlight on a wall or floor, cast through a hole in the wall or a similar opening. They may also arise on seeing a patch of light cast on the ground through the branches of a densely leafed tree or through gaps in a thick canopy of branches. (Visuddhimagga I, 169.)

**VI**
Hành giả có sức pāramī tu tập kasiṇa ánh sáng yếu hơn hãy lấy một trong ba loại vòng ánh sáng trên làm cảnh và tu tập “āloko, āloko, āloko — ánh sáng, ánh sáng, ánh sáng”. Nếu chưa thành công, thắp đèn trong một cái nồi, đậy miệng nồi, khoét một lỗ nhỏ trên thân nồi và đặt quay về phía tường. Ánh đèn qua lỗ ấy sẽ tạo thành vòng sáng trên tường. Lấy vòng sáng ấy làm cảnh, tác ý tu tập “āloko, āloko, āloko — ánh sáng, ánh sáng, ánh sáng”. Vòng kasiṇa ánh sáng được sửa soạn như vậy tồn tại lâu hơn vòng ánh sáng do ánh trăng hoặc mặt trời. (Visuddhi 1,169.)

**EN**
A meditator whose perfections from developing this kasiṇa are weak should attend to one of the three kinds of light mentioned above: “āloko, āloko, āloko—light, light, light.” If this fails, light an oil lamp inside a pot, cover the mouth, and place the pot with a small opening facing a wall. Light from the lamp shines through the hole, forming a patch on the wall. Develop it by attending to this patch: “āloko, āloko, āloko—light, light, light.” A disk of light prepared in this way lasts longer than one cast by the moon or sun. (Visuddhimagga I, 169.)


<a id="M02-body-P051"></a>
## Tướng ánh sáng — Đoạn trừ hôn trầm và thụy miên / The signs of the light kasiṇa; overcoming sloth and torpor
Miến / Burmese 51

**VI**
Hành giả đã an lập thành công các định tứ thiền nói trên có thể dễ dàng lấy tướng kasiṇa ánh sáng từ ánh mặt trời nhìn qua những kẽ cành lá dày vào buổi sáng hoặc chiều. Ánh sáng có thể mạnh mẽ hơn. Nếu vào đêm tối mà mở rộng vòng kasiṇa như vậy, trong phạm vi đã mở rộng vẫn sáng như ban ngày. Điều này phù hợp với lời Đức Phật chỉ dạy Trưởng lão Mahāmoggallāna trong kinh Pacalāyamāna, Aṅguttaranikāya, Sattakanipāta (Aṅ 2,463).

**EN**
A meditator who has successfully established the various fourth jhānas described above can take the sign readily from sunlight seen through thick branches and foliage in the morning or evening. This light is often more powerful. When the sign is extended at night, the area to which the kasiṇa disk extends becomes as bright as daytime. This agrees with the Buddha's instructions to Venerable Mahāmoggallāna in the Pacalāyamāna Sutta, in the Book of the Sevens of the Aṅguttara Nikāya. (Aṅguttara Nikāya, vol. 2, p. 463.)

**VI**
Học tướng và tương tợ tướng

**EN**
The learning sign and the counterpart sign

**VI**
Học tướng kasiṇa ánh sáng giống như vòng sáng tự nhiên hiện trên tường, mặt đất hoặc qua kẽ cành lá. Tương tợ tướng giống như một khối ánh sáng đặc, hết sức sáng trong, như vòng hào quang một tầm của Đức Phật. Những chi tiết còn lại như trên. (Visuddhi 1,169.)

**EN**
The learning sign resembles the ordinary patch of light on a wall or floor or among branches and leaves. The counterpart sign resembles an especially clear mass of light, with a compact shape like the Buddha's fathom-wide radiance. Understand the rest in the same way. (Visuddhimagga I, 169.)

**VI**
Đoạn trừ hôn trầm và thụy miên

**EN**
Overcoming sloth and torpor (thīnamiddha)

**VI**
Tưởng ánh sáng (ālokasaññā), tức kasiṇa ánh sáng, là một vũ khí rất tốt để đoạn trừ hôn trầm và thụy miên, sự trì trệ của tâm và tâm sở. Trong kinh Pacalāyamāna thuộc Aṅguttaranikāya, Sattakanipāta…

**EN**
The perception of light (ālokasaññā), here called the light kasiṇa, is an excellent means for dispelling the sluggishness of consciousness and its associated mental factors. In the Pacalāyamāna Sutta of the Book of the Sevens…


<a id="M02-body-P052"></a>
## Kasiṇa hư không (ākāsakasiṇa) / The space kasiṇa (ākāsakasiṇa)
Miến / Burmese 52

**VI**
…Đức Phật đã phân chia và chỉ dạy bảy phương pháp trừ hôn trầm và thụy miên. Trong bảy phương pháp ấy có tưởng ánh sáng này. Đây là một pháp hành mà mọi hành giả mong cầu Niết-bàn nên nắm giữ. Trong các kasiṇa làm nền tảng cho thiên nhãn thông (dibbacakkhuabhiññā), kasiṇa ánh sáng này là thù thắng, tốt nhất.

**EN**
…the Buddha explained seven methods for dispelling sloth and torpor, including the perception of light. Every meditator who aspires to Nibbāna should have this meditation subject at hand. Among the kasiṇas used as a basis for the higher knowledge of the divine eye, the light kasiṇa is the most excellent.

**VI**
Kasiṇa hư không

**EN**
The space kasiṇa (ākāsakasiṇa)

**VI**
Có thể lấy tướng kasiṇa hư không — tức kasiṇa khoảng trống hay lỗ hở — từ: 1. lỗ trên tường; 2. lỗ khóa; 3. khoảng hở cửa sổ.

**EN**
The sign of the space kasiṇa—that is, the kasiṇa of an opening or of the sky—can be taken from (1) a hole in a wall, (2) a keyhole, or (3) a gap in a window.

**VI**
Người có thiện nghiệp tu tập kasiṇa hư không đã làm trong quá khứ, khi nhìn thấy một khoảng hở như lỗ trên tường, học tướng và tương tợ tướng có thể dễ dàng sinh khởi. Người có thiện nghiệp ấy yếu hơn hãy khoét một lỗ tròn đường kính một gang và bốn ngón tay trên một mái che kín không bị nắng xuyên qua, hoặc trên một tấm da, tấm chiếu, v.v. Lấy lỗ đã sửa soạn thành vòng kasiṇa ấy, hoặc bất cứ một lỗ nào như lỗ tường, làm tướng hư không; tác ý tu tập “ākāso, ākāso, ākāso — hư không, hư không, hư không”.

**EN**
For someone with wholesome merit from previous development of the space kasiṇa, the learning sign and counterpart sign can readily arise on seeing an opening such as a hole in a wall. Someone with little such accumulated merit should make a round opening about a span and four fingers across in a well-covered shelter where the sun does not shine through, or in a piece of leather, a mat, or the like. Take the space in that prepared opening or another opening such as a hole in a wall, and develop it by attending, “ākāso, ākāso, ākāso—space, space, space.”


<a id="M02-body-P053"></a>
## Lấy và giữ tướng hư không / Taking the space kasiṇa sign
Miến / Burmese 53

**VI**
Nếu chưa thành công, hãy khoét thật tròn một lỗ đường kính khoảng một gang hoặc một bàn chân trên tấm ván. Giữ tấm ván có vòng kasiṇa ấy hướng lên một khoảng trời sạch, không vướng cây, sương mù hay mây. Chuyên chú lấy tướng hư không tròn trong lỗ ấy làm cảnh. Đừng nhìn vượt qua lỗ vòng kasiṇa ra bầu trời; chỉ lấy tướng trong lỗ đã khoét trên tấm ván.

**EN**
If unsuccessful, cut a circular hole about a span or a foot across in a board. Hold the board up to a clear patch of sky free of trees, clouds, and shadows, and concentrate on the bounded space. Do not let your gaze go beyond the hole into the sky. Take the space kasiṇa sign only from the opening cut in the board.

**VI**
Nếu vẫn chưa dễ dàng lấy được tướng, hãy an lập lại một định tứ thiền đã đạt; sau đó mở mắt lấy tướng vòng kasiṇa hư không cùng cách ấy. Nếu nhắm mắt mà học tướng hiện rõ thì đã thành công. Luyện tập thêm một chút để tướng vững chắc, rồi có thể đến nơi mình muốn, ngồi xuống tu tập.

**EN**
If the sign is still difficult to take, re-establish a fourth jhāna you already know. Then open your eyes and take the sign from the opening in the same way. If the learning sign appears when you close your eyes, you have succeeded. Practise a little longer until the space sign is firm, then go to a place of your choice and continue developing it there.

**VI**
Khi ngồi ở nơi thích hợp, hãy an lập lại một định tứ thiền đã đạt, rồi lấy lại tướng kasiṇa hư không mình đã có. Được trợ giúp đặc biệt mạnh mẽ bởi cận y duyên của các định trước, những định tu tập về sau cũng có thể phát triển dễ dàng, thuận lợi.

**EN**
When seated in a place you find suitable, re-establish a fourth jhāna you already know. Then take as object the space kasiṇa sign you previously acquired. Earlier meditative concentration supports later meditative concentration by the power of decisive support, making the later practice proceed smoothly.

**VI**
Học tướng và tương tợ tướng

**EN**
The learning sign and the counterpart sign

**VI**
Học tướng kasiṇa hư không hiện rõ giống đúng lỗ ban đầu, cùng với thành của lỗ, như lỗ tường…

**EN**
The learning sign of the space kasiṇa resembles the original opening in the wall or other object, together with its edges…


<a id="M02-body-P054"></a>
## Mười kasiṇa / Mastering the ten kasiṇas
Miến / Burmese 54

**VI**
…Ở giai đoạn học tướng, do năng lực tu tập còn yếu, dù cố mở rộng vòng kasiṇa cũng chưa thể mở rộng. Tương tợ tướng thì không còn hiện rõ mép lỗ của vòng tròn hư không đã khoét, mà chỉ còn riêng một vòng hư không. Khi ấy sự tu tập, định kasiṇa hư không đã vững chắc, nên nếu mở rộng vòng kasiṇa thì nó có thể rộng ra. Những chi tiết còn lại cũng như trên. (Visuddhi 1,169.)

**EN**
…At the learning-sign stage, the power of development is still weak. Even if you try to extend the disk, it will not expand. In the counterpart sign, the edges of the circular opening no longer appear. Only a disk of space appears. By this stage, concentration on the space kasiṇa has matured and the disk can be extended. Understand the rest in the same way. (Visuddhimagga I, 169.)

**VI**
Mười kasiṇa

**EN**
The ten kasiṇas

**VI**
Đến đây đã trình bày xong cách quán mười kasiṇa cho đến định tứ thiền. Hành giả đã thành công như vậy hãy nhiều lần tu tập đến tứ thiền trên từng kasiṇa, theo thứ tự Đức Phật đã dạy: đất, nước, lửa, gió, xanh đen, vàng, đỏ, trắng, ánh sáng, hư không.

**EN**
This concludes the account of developing the ten kasiṇas up to fourth-jhāna concentration. After attaining this, develop each kasiṇa repeatedly up to the fourth jhāna in the order taught by the Buddha: earth, water, fire, wind, blue, yellow, red, white, light, and space.

**VI**
Nếu có thể nỗ lực như vậy, bất kỳ lúc gặp vật gì, miễn vật ấy có thể dùng làm tướng vòng kasiṇa, chỉ vừa hướng đến lấy nó làm cảnh là hành giả có thể dễ dàng lấy được tướng. Đối với người đã thuần thục cả mười kasiṇa đến tứ thiền, ngay một bông hoa hoàng lan rất nhỏ cũng trợ giúp bằng cảnh duyên để kasiṇa vàng sinh khởi. Một bông hồng đỏ rực…

**EN**
If you practise in this way, whenever you encounter a suitable object and turn your attention to it as a kasiṇa, you can take the sign easily. For a meditator skilled in all ten kasiṇas up to the fourth jhāna, even a tiny yellow champak flower can support the arising of the yellow kasiṇa by the power of object condition. A reddish rose…


<a id="M02-body-P055"></a>
## Rút lấy tinh hoa tu tập từ các cảnh / The fruits of kasiṇa practice
Miến / Burmese 55

**VI**
…và một bông nhài rất nhỏ cũng có thể trợ giúp tương tự bằng cảnh duyên để kasiṇa đỏ hay kasiṇa trắng sinh khởi.

**EN**
…can likewise support the arising of the red kasiṇa, and a tiny jasmine flower can support the arising of the white kasiṇa, by the power of object condition.

**VI**
Nếu biết rút lấy tinh hoa tu tập từ các vật dục có sự sống và không có sự sống, từ căn nhà thân hôi thối này vốn không có gì bền chắc, thì đối với hành giả có như lý tác ý, những tinh hoa tu tập như định tứ thiền sẽ dễ dàng sinh khởi. Nếu lấy tứ thiền ấy làm nền tảng mà tiến lên minh sát, các pháp định ấy có thể trợ giúp đến tận A-la-hán quả.

**EN**
If you know how to extract the essence of meditation from living and inanimate objects of sensual desire and from this great heap of a body in which no essence can be found, then for a meditator who attends wisely in the manner described here, such fruits of meditation as fourth-jhāna concentration will arise readily. If you proceed to insight on the basis of that fourth jhāna, those states of concentration can support you as far as the attainment of arahant fruition.

**VI**
Tuy nhiên, ở đây chúng tôi tiếp tục trình bày cách tu tập các thiền vô sắc, lấy định tứ thiền đạt được nhờ cảnh chế định kasiṇa làm nền tảng.

**EN**
Here, however, the exposition will continue with how to develop the immaterial jhānas on the basis of fourth-jhāna concentration attained with a kasiṇa concept as object.


<a id="M02-body-P057"></a>
## Thiền vô sắc giới — Thiền Không vô biên xứ / The immaterial jhānas
Miến / Burmese 57

**VI**
Phần thiền vô sắc giới

**EN**
The immaterial jhānas

**VI**
Thiền Không vô biên xứ (ākāsānañcāyatanajhāna)

**EN**
The jhāna of the base of infinite space (ākāsānañcāyatanajhāna)

**VI**
Thiền vô sắc giới gồm bốn loại:

**EN**
There are four kinds of immaterial jhāna:

**VI**
1. Thiền Không vô biên xứ: thiền có chỗ nương, đối tượng là chế định hư không.
2. Thiền Thức vô biên xứ: thiền có chỗ nương, đối tượng là thức Không vô biên xứ.
3. Thiền Vô sở hữu xứ: thiền có chỗ nương, đối tượng là chế định về sự không có của thức Không vô biên xứ (natthibhāva).
4. Thiền Phi tưởng phi phi tưởng xứ: thiền có chỗ nương, đối tượng là tưởng hết sức vi tế; không thể nói là có tưởng hay không có tưởng. Không còn tưởng thô, nhưng chỉ còn tưởng cực kỳ vi tế.

**EN**
1. The jhāna of the base of infinite space takes the concept of space as its object.
2. The jhāna of the base of infinite consciousness takes the consciousness of the base of infinite space as its object.
3. The jhāna of the base of nothingness takes the concept of the absence of the consciousness of the base of infinite space as its object.
4. The jhāna of the base of neither perception nor non-perception takes an exceedingly subtle perception as its object. Gross perception is absent, but perception is not altogether absent.

**VI**
Trong đó, hành giả muốn đạt thiền Không vô biên xứ trước hết nên quán thấy khuyết điểm của sắc.

**EN**
A meditator who wishes to attain the jhāna of the base of infinite space should first contemplate material phenomena so as to see their drawbacks.

**VI**
Thân này nương vào tinh huyết của cha mẹ, hiện hữu do bốn nguyên nhân là nghiệp, tâm, thời tiết và vật thực, được gọi là karajakāya, thân vật chất. Vì thân vật chất ấy hiện hữu, người ta cầm những vũ khí như gậy, dao mà đánh, giết; đánh đập, hành hạ, tra tấn; xung đột, tranh cãi; chịu bệnh mắt…

**EN**
This body, which depends on the parents’ generative fluids and comes into being through the four causes of kamma, consciousness, temperature, and nutriment, is called the material body (karajakāya). Because this material body exists, people kill one another with sticks, swords, and other weapons. They strike, torment, and oppress one another, contend with one another, and suffer. They also undergo eye disease…


<a id="M02-body-P058"></a>
## Vượt qua sắc — Giải thích thêm / Seeing the drawbacks of materiality
Miến / Burmese 58

**VI**
…bệnh tai và nhiều loại bệnh khác. Hãy dùng tuệ suy xét: nếu không có sắc gọi là thân vật chất (karajakāya) này thì sẽ thoát những khổ ấy. Vì muốn nhàm chán, chán ghét và làm lắng diệt sắc, hành giả cố gắng tu tập để đạt thiền Không vô biên xứ.

**EN**
…ear disease, and various other illnesses. Reflect wisely that, if there were no material phenomena called the material body, one would be free from such suffering. Then strive for the jhāna of the base of infinite space, with the aim of causing materiality to fade away, become repulsive, and cease.

**VI**
Thiền Không vô biên xứ có đối tượng là chế định hư không. Sau khi quán thấy khuyết điểm của sắc gọi là thân vật chất (karajakāya) và muốn vượt qua sắc ấy, hãy làm phát sinh tứ thiền trên một trong chín kasiṇa còn lại như kasiṇa đất, ngoại trừ kasiṇa hư không. (Visuddhi 1,320.)

**EN**
The jhāna of the base of infinite space takes the concept of space as its object. Having seen the drawbacks in the material phenomena called the material body, develop the fourth jhāna with one of the nine kasiṇas beginning with earth, leaving aside the space kasiṇa, in order to surmount those material phenomena. (Visuddhimagga I, 320.)

**VI**
Giải thích thêm

**EN**
Further explanation

**VI**
Ví dụ với kasiṇa đất: mặt đất nơi hành giả lấy tướng ban đầu là tập hợp các nhóm sắc thuần tám có dưỡng chất do thời tiết sinh (utuja-ojaṭṭhamakarūpa), nên là sắc thật. Nếu quán bốn đại trong đất ấy rồi an lập định, có thể không còn thấy đất mà chỉ thấy tập hợp các nhóm sắc. Mỗi nhóm sắc có tám pháp: đất, nước, lửa, gió, màu, mùi, vị và dưỡng chất. Chính hỏa đại (utu) trong mỗi nhóm sắc làm duyên để những nhóm sắc thuần tám có dưỡng chất do thời tiết sinh tiếp tục sinh khởi nối tiếp nhau. Chúng đều là sắc thật.

**EN**
Take the earth kasiṇa as an example. The earth from which the meditator first takes the sign is actual materiality, a collection of temperature-produced material phenomena. If the meditator discerns the four great elements in that earth and establishes concentration, the earth as such disappears and only a collection of material groups is seen. In each group are eight phenomena: earth, water, fire, wind, colour, odour, taste, and nutritive essence. The fire element, or temperature, in each group gives rise to further generations of temperature-produced materiality. These are actual material phenomena.

**VI**
Tuy nhiên, đối tượng của các thiền sắc giới có cảnh kasiṇa đất, cho đến tứ thiền, là tương tợ tướng kasiṇa đất. Tương tợ tướng ấy không phải sắc chân đế được gọi là mặt đất gốc — tức những nhóm sắc thuần tám có dưỡng chất do thời tiết sinh — mà chỉ là chế định sinh khởi do tưởng tu tập của hành giả…

**EN**
The object of the fine-material jhānas up to the fourth jhāna on the earth kasiṇa is the counterpart sign of that kasiṇa. This counterpart sign is distinct from the ultimate material phenomena produced by temperature that constitute the original earth. It is a concept brought into being by the meditator's…


<a id="M02-body-P059"></a>
## Ví dụ thế gian để so sánh / Why the kasiṇa sign is also surmounted
Miến / Burmese 59

**VI**
…làm sinh khởi. Nó không phải sắc thật. Các thiền cho đến tứ thiền sắc giới chỉ lấy chế định tương tợ tướng ấy làm cảnh, không lấy sắc thật — tức tập hợp các nhóm sắc thuần tám do thời tiết sinh gọi là mặt đất ban đầu. Do đó, các thiền sắc giới cũng đã vượt qua những sắc thật gọi là thân vật chất (karajakāya).

**EN**
…perception during meditation. It is not actual materiality. The fine-material jhānas up to the fourth jhāna take only this conceptual counterpart sign as object. They do not take as object the actual material phenomena, the collection of temperature-produced materiality in the earth on which the original kasiṇa disk depended. Thus the fine-material jhānas have already surmounted the actual material phenomena called the material body.

**VI**
Ví dụ thế gian để so sánh

**EN**
Illustrations from ordinary life

**VI**
Nhờ sức tứ thiền sắc giới, hành giả không lấy thân vật chất thật làm cảnh, mà chỉ lấy tương tợ tướng, nên việc vượt qua thân vật chất thật là điều có thật. Dẫu vậy, vì sắc kasiṇa cũng có thể được lấy làm đối tượng của thiền, nó vẫn giống với thân sắc ấy; vì thế hành giả cũng muốn vượt qua sắc kasiṇa.

**EN**
Through the power of the fourth fine-material jhāna, the meditator takes only the counterpart sign as object instead of the actual material body. In this sense the material body has indeed been surmounted. Yet the kasiṇa form can still be taken as an object of jhāna and is therefore like that material form. The meditator consequently wishes to surmount the kasiṇa form as well.

**VI**
Ví dụ: người sợ rắn bị rắn đuổi trong rừng, chạy thật nhanh hết sức mệt nhọc. Khi thấy từ xa một lá thốt nốt được tô các màu giống con rắn, một dây leo, một sợi dây, hoặc khe nứt trên mặt đất, người ấy cũng sợ hãi, không muốn nhìn vật ấy.

**EN**
Suppose someone afraid of snakes is chased by one in a forest and runs away as fast as he can, exhausting himself. If from a distance he sees a palm leaf painted to resemble a snake, a creeper, a rope, or a crack in the ground, he is startled and frightened and does not want to look at it.

**VI**
Ví dụ khác: một người sống cùng làng với một kẻ thù hay làm hại mình. Bị kẻ ấy đánh, trói và đốt nhà, người ấy chuyển sang làng khác. Ở làng mới…

**EN**
Consider also a man who lives in the same village as an enemy who harms him. The enemy attacks him, harasses him, and even sets fire to his house. The man moves to another village…


<a id="M02-body-P060"></a>
## Công việc cần thực hành / Preparing to develop infinite space
Miến / Burmese 60

**VI**
…nếu gặp người có hình dáng, giọng nói, hành động giống kẻ thù ấy, người ấy lại sợ hãi, cũng không muốn nhìn người đó.

**EN**
…Yet if he encounters someone whose appearance, voice, or conduct resembles that enemy, he is again startled and afraid, and does not want to look at him.

**VI**
Tương tự những ví dụ ấy, hành giả ghi nhớ vững chắc rằng không chỉ thân vật chất thật mà cả sắc kasiṇa sinh khởi dựa trên thân vật chất thật cũng giống thân sắc ấy. Vì thế sinh khởi sự sợ, sự kinh hãi, sự không muốn nhìn sắc kasiṇa, và ước muốn vượt qua nó. (Visuddhi 1,320.)

**EN**
In the same way, firmly recognize that the kasiṇa form, which arises in dependence on the material body, resembles that material form. When fear, alarm, and aversion to seeing the kasiṇa form arise, recognize the wish to surmount it too. (Visuddhimagga I, 320.)

**VI**
Công việc cần thực hành

**EN**
The work to be done

**VI**
Hành giả muốn tu tập thiền Không vô biên xứ lấy kasiṇa đất làm nền tảng, trước hết hãy lần lượt nhập sơ thiền, nhị thiền, tam thiền và tứ thiền có đối tượng là kasiṇa đất, rồi tiếp tục như sau.

**EN**
To develop the jhāna of the base of infinite space using the earth kasiṇa as a basis, first enter the first, second, third, and fourth jhānas on the earth kasiṇa in order. Then practise as follows.

**VI**
Vì muốn nhàm chán và vượt qua sắc kasiṇa đất là cảnh của tứ thiền, sau khi đã luyện tập thuần thục năm pháp tự tại và thực hành thật thành thạo tứ thiền lấy kasiṇa đất làm cảnh, hãy xuất khỏi tứ thiền ấy và quán thấy những khuyết điểm của nó:

**EN**
Wishing to become disenchanted with and surmount the earth kasiṇa form, the object of the fourth jhāna, first gain the five kinds of mastery. Emerge from the thoroughly practised fourth jhāna on the earth kasiṇa and consider its drawbacks as follows.

**VI**
1. Tứ thiền sắc giới này vẫn lấy sắc kasiṇa mà ta đã nhàm chán làm cảnh.
2. Nó có kẻ thù gần là thọ hỷ (somanassavedanā)…

**EN**
1. This fine-material fourth jhāna still takes as object the kasiṇa form with which I have become disenchanted.
2. It has a near enemy in the pleasant mental feeling called somanassa.


<a id="M02-body-P061"></a>
## Từ tứ thiền đến cảnh hư không vô biên / Removing the earth kasiṇa
Miến / Burmese 61

**VI**
…3. So với các thiền vô sắc là những giải thoát tịch tịnh, tứ thiền này còn thô.

**EN**
3. It is gross compared with the immaterial jhānas, which are peaceful liberations.

**VI**
Hãy quán thấy khuyết điểm như vậy. Tứ thiền sắc giới chỉ có hai thiền chi là xả và nhất tâm; các thiền vô sắc cũng chỉ có hai thiền chi xả và nhất tâm. Do đó, nơi tứ thiền sắc giới không có sự thô của các thiền chi. Sau khi quán thấy khuyết điểm của tứ thiền ấy theo cách đã nói, hành giả:

**EN**
Contemplate these drawbacks. The fine-material fourth jhāna has only two factors, equanimity and one-pointedness. The immaterial jhānas likewise have only these two factors. Thus, the distinction in grossness does not lie in the jhāna factors. Having contemplated the drawbacks as described:

**VI**
4. Làm cho sự mong cầu, sự dính mắc nơi tứ thiền ấy chấm dứt.
5. Tác ý thiền Không vô biên xứ là tịch tịnh, là vô biên.
6. Mở rộng sắc kasiṇa đất đã tu tập đến tận cùng thế giới, hoặc đến phạm vi mình muốn.
7. Đối với khoảng không tại nơi sắc kasiṇa ấy đã hiện hữu, tác ý “ākāsa, ākāsa — hư không, hư không”, hoặc “anantākāsa, anantākāsa — hư không vô biên, hư không vô biên”.

**EN**
4. Bring longing and attachment to that fourth jhāna to an end.
5. Attend to the jhāna of the base of infinite space as peaceful and infinite.
6. Extend the earth kasiṇa form already developed to the bounds of the world system, or as far as you wish.
7. Attend to the space occupied by that kasiṇa form as “space, space” or “infinite space, infinite space.”

**VI**
Như vậy, hành giả loại bỏ sắc kasiṇa đất là cảnh của tứ thiền sắc giới. Nói rõ hơn: loại bỏ sắc kasiṇa đất không phải là cuộn nó lại như cuộn một tấm chiếu; cũng không phải gỡ nó ra như lấy bánh khỏi chảo. Thực chất là không suy xét, không tác ý, không xem xét kasiṇa đất. Không suy xét, không tác ý, không xem xét đất, mà chỉ hướng đến hư không tại nơi sắc kasiṇa đất ấy đã hiện hữu, tác ý “ākāsa, ākāsa — hư không, hư không”…

**EN**
This is how the meditator removes the earth kasiṇa form that was the object of the fine-material fourth jhāna. Understand that removing the earth kasiṇa form does not involve rolling it up like a mat or removing it as one might lift a cake from a pan. It consists in giving up consideration of the earth kasiṇa, ceasing to attend to it, and no longer reviewing it. Instead, the meditator attends exclusively to the space it occupied as “space, space”…


<a id="M02-body-P062"></a>
## Loại bỏ kasiṇa — Lời khuyên / The space left by the kasiṇa
Miến / Burmese 62

**VI**
…hành giả chỉ một chiều tác ý hư không như vậy được gọi là loại bỏ kasiṇa. Kasiṇa đất được loại bỏ không phải bị cuộn lại hay chìm xuống. Chính do không tác ý riêng kasiṇa đất, mà chỉ một chiều tác ý “hư không, hư không”, nên gọi là loại bỏ kasiṇa. Nhờ loại bỏ ấy, chỉ riêng chế định hư không hiện rõ.

**EN**
…A meditator who attends exclusively to space in this way is said to remove the kasiṇa. The earth kasiṇa thus removed does not roll itself up or vanish physically. The term “removal of the earth kasiṇa” refers to the meditator's giving up attention to it and attending exclusively to “space, space.” With its removal, only the concept of space appears.

**VI**
1. Kasiṇugghāṭimākāsa: hư không có được do loại bỏ kasiṇa.
2. Kasiṇaphuṭṭhākāsa: hư không tại nơi kasiṇa đã trải đến.
3. Kasiṇavivittākāsa: hư không vắng kasiṇa.

**EN**
1. Kasiṇugghāṭimākāsa: the space obtained by removing the kasiṇa.
2. Kasiṇaphuṭṭhākāsa: the space occupied by the kasiṇa.
3. Kasiṇavivittākāsa: the space clear of the kasiṇa.

**VI**
Ba tên ấy là những cách nói khác nhau, có cùng ý nghĩa. (Visuddhi 1,320–321.)

**EN**
These three expressions are alternative ways of saying the same thing. (Visuddhimagga I, 320–321.)

**VI**
Lời khuyên

**EN**
Practical advice

**VI**
Hành giả hãy tác ý theo chỉ dẫn trên; có thể thành công. Nếu chưa thành công, cũng có thể thử như sau: mở rộng vòng kasiṇa đất đầy khắp một thế giới; nếu muốn, mở rộng đến vô lượng thế giới. Sau khi mở rộng, lần lượt nhập các thiền lấy kasiṇa đất làm cảnh cho đến tứ thiền. Xuất khỏi tứ thiền, suy xét các điểm 1–5 đã trình bày ở trên. Sau đó mở rộng sắc kasiṇa đất không giới hạn…

**EN**
Try attending as instructed above. If you do not succeed, try this. Extend the earth kasiṇa disk to fill a world system. If you wish, extend it throughout countless world systems. Then enter the jhānas on the earth kasiṇa up to the fourth. Emerge and reflect on the points given above, from (1) through (5). Then extend the earth kasiṇa form without limit.


<a id="M02-body-P063"></a>
## Tiến đến thiền Không vô biên xứ / Developing the sign of space
Miến / Burmese 63

**VI**
…rồi đặt tâm tại một nơi trên vòng kasiṇa đất ấy; không tác ý đất mà chỉ một chiều tác ý hư không. Trong thời gian không lâu, một khoảng hở hư không có thể hiện ra. Khi ấy, đừng tác ý phần kasiṇa đất chưa trở thành hư không; chỉ tác ý hư không đang hiện rõ, quán “hư không, hư không”.

**EN**
…Then settle your mind on one place in the earth kasiṇa disk. Attend exclusively to space, leaving earth aside. Soon you may see an opening. From then on leave the parts of the earth kasiṇa where space has not appeared entirely out of attention. Attend exclusively to the space that has appeared, contemplating “space, space.”

**VI**
Hư không càng rõ hơn và ổn định hơn, hãy mở rộng chính hư không ấy, tiếp tục quán “hư không, hư không”. Hư không càng mở rộng thì vòng kasiṇa đất càng lùi dần, hư không chiếm chỗ. Dần dần mở rộng hư không ra mười phương. Cuối cùng, kasiṇa đất biến mất, chỉ còn hư không. Hư không ấy chính là tướng hư không có được do loại bỏ kasiṇa đất. Lúc ấy tiếp tục luyện tập theo lời Visuddhimagga dưới đây.

**EN**
As space becomes clearer and steadier, extend that very space while contemplating “space, space.” As space expands, the earth kasiṇa disk gradually recedes and space takes its place. Extend space gradually in all ten directions. Eventually the earth kasiṇa disappears and only space remains. This is the sign of space obtained by removing the earth kasiṇa. Then continue practising according to the instructions of the Visuddhimagga below.

**VI**
Tiến đến thiền Không vô biên xứ

**EN**
Entering the base of infinite space

**VI**
Hành giả nhiều lần suy xét tướng hư không đã có nhờ loại bỏ kasiṇa đất, tác ý “ākāsa, ākāsa — hư không, hư không”. Tầm hướng tâm đến hư không, liên tục đưa tâm đến cảnh ấy. Nơi hành giả nhiều lần suy xét và dùng tầm hướng tâm đến hư không như vậy, các triền cái và những cấu uế phiền não bị loại trừ. Niệm nương nơi cảnh tướng hư không trở nên hết sức rõ và khéo an trú; bằng cận định, tâm tu tập…

**EN**
Repeatedly consider the sign of space obtained by removing the earth kasiṇa, attending “space, space.” With applied thought, direct the mind to it and turn it repeatedly towards it as “space, space.” In the meditator who repeatedly considers and directs the mind to it in this way, the hindrances and stains of defilement fall away. Mindfulness, taking the sign of space as its object, becomes very clear and firmly established. Through access concentration, the mind engaged in development…


<a id="M02-body-P064"></a>
## Tâm thiền Không vô biên xứ — Điểm nhấn mạnh / Absorption in the base of infinite space
Miến / Burmese 64

**VI**
…an trú vững chắc trên tướng hư không. Hành giả tiếp tục chuyên chú, tu tập, luyện tập nhiều lần trên tướng ấy. Khi hành giả liên tục suy xét và tác ý, tâm Không vô biên xứ lấy hư không làm cảnh sinh khởi với sức an chỉ thiền, giống tâm thiền sắc giới sinh khởi với sức an chỉ trên cảnh chế định kasiṇa đất v.v.

**EN**
…settles firmly on the sign of space. The meditator repeatedly apprehends, develops, and practises with this sign. For a meditator who considers and attends in this way again and again, the consciousness of the base of infinite space arises in absorption with the sign of space as object, just as fine-material jhāna consciousness arises in absorption with a kasiṇa concept such as the earth kasiṇa as object.

**VI**
Tuy nhiên, trong tiến trình tâm Không vô biên xứ này, ba hoặc bốn tốc hành cận hành đi trước tâm thiền đều là tốc hành dục giới, tương ưng thọ xả. Tốc hành thứ tư hoặc thứ năm là tốc hành vô sắc giới gọi là Không vô biên xứ. Những điểm còn lại như đã giải thích ở kasiṇa đất. (Visuddhi 1,321.)

**EN**
In this cognitive process of the base of infinite space, however, the three or four access impulsions preceding the jhāna are sense-sphere impulsions and are accompanied only by equanimous feeling. The fourth or fifth impulsion is the immaterial-sphere impulsion called the base of infinite space. The explanation is as given for the earth kasiṇa. (Visuddhimagga I, 321.)

**VI**
Điểm nhấn mạnh đặc biệt

**EN**
A point to note

**VI**
Khi tâm thiền vô sắc giới sinh khởi như vậy, ví như mở tấm vải che miệng nồi thì tấm vải biến mất, lộ khoảng hư không ở miệng nồi: sau khi nhìn cảnh vòng kasiṇa bằng con mắt thiền sắc giới, hành giả không còn tác ý kasiṇa đất, mà tác ý “hư không, hư không”. Nhờ tác ý cận thiền thuộc giai đoạn sơ khởi này, mau chóng loại bỏ cảnh kasiṇa đất và chỉ nhìn cảnh hư không hiện rõ bằng con mắt thiền vô sắc giới. Vì muốn diễn tả trình tự dài như vậy, đoạn kinh nói về hành giả ấy như sau…

**EN**
When immaterial jhāna consciousness arises, it is as if a cloth covering the mouth of a pot were lifted away and the unobstructed space came into view. Previously the meditator contemplated the kasiṇa disk with the eye of fine-material jhāna. Then, leaving the disk out of attention, the meditator removed it by attending “space, space” with the preliminary attention of access concentration. The meditator now contemplates only the sign of space that has appeared, with the eye of immaterial jhāna. With this much understood, the meditator is described as follows…


<a id="M02-body-P065"></a>
## Ý nghĩa công thức vượt qua các tưởng về sắc / Surmounting perceptions of form
Miến / Burmese 65

**VI**
…

**EN**
…

**VI**
Sabbaso rūpasaññānaṃ samatikkamā paṭighasaññānaṃ atthaṅgamā nānattasaññānaṃ amanasikārā “ananto ākāso”ti ākāsānañcāyatanaṃ upasampajja viharati. (Abhi 2,254; Dī 2,60.)

**EN**
Sabbaso rūpasaññānaṃ samatikkamā paṭighasaññānaṃ atthaṅgamā nānattasaññānaṃ amanasikārā “ananto ākāso”ti ākāsānañcāyatanaṃ upasampajja viharati. (Abhidhamma 2, p. 254; Dīgha Nikāya 2, p. 60.)

**VI**
Vị ấy vượt qua hoàn toàn các tưởng về sắc; do các tưởng về sự xúc chạm chấm dứt; do không tác ý các tưởng sai khác; tác ý “hư không là vô biên”, thành tựu và an trú Không vô biên xứ.

**EN**
With the complete surmounting of perceptions of form, with the disappearance of perceptions of sensory impact, and with non-attention to perceptions of diversity, contemplating “space is infinite,” the meditator enters and dwells in the base of infinite space.

**VI**
1. Vượt qua hoàn toàn các thiền sắc giới lấy sắc kasiṇa đất v.v. làm cảnh, được gọi là các tưởng về sắc; đồng thời vượt qua những cảnh như kasiṇa đất là đối tượng của các thiền sắc giới ấy.

**EN**
1. The fine-material jhānas that take forms such as the earth kasiṇa as their objects are called perceptions of form. The meditator completely surmounts both these jhānas and their objects, such as the earth kasiṇa.

**VI**
2. Các tưởng về sự xúc chạm chấm dứt: đó là tưởng tương ưng với hai bộ năm thức, sinh khởi do xúc chạm với cảnh vật, gồm sắc tưởng, thanh tưởng, hương tưởng, vị tưởng, xúc tưởng.

**EN**
2. Perceptions of sensory impact disappear. These are perceptions of visible forms, sounds, odours, tastes, and tangibles that arise from the impact of sense objects on their respective bases. They accompany the two sets of five sense consciousnesses.

**VI**
3. Không tác ý các tưởng sai khác: đó là 44 loại tưởng tương ưng 44 tâm dục giới thiện, bất thiện, quả và duy tác, ngoài 10 tưởng tương ưng hai bộ năm thức. Nhờ vậy, vị ấy thành tựu và an trú thiền Không vô biên xứ, biết tác ý “hư không vô biên”. (Visuddhi 1,322.)

**EN**
3. The meditator does not attend to perceptions of diversity. These are the forty-four kinds of perception accompanying the forty-four wholesome, unwholesome, resultant, and functional sense-sphere consciousnesses other than the ten sense consciousnesses. Thus the meditator enters and dwells in the jhāna of the base of infinite space, attending to space as infinite. (Visuddhimagga I, 322.)

**VI**
Ghi chú: nên hiểu câu Pāli trên nói đến việc bỏ, không tác ý toàn bộ 54 loại tâm dục giới và các tâm sở tương ưng. Vì hành giả chỉ một chiều tác ý riêng hư không đã có do loại bỏ kasiṇa.

**EN**
Note: Understand the passage as teaching that all fifty-four kinds of sense-sphere consciousness and their associated mental factors are set aside and left out of attention in the jhāna of the base of infinite space. The meditator attends exclusively to the space obtained by removing the kasiṇa.


<a id="M02-body-P066"></a>
## Thiền Thức vô biên xứ (viññāṇañcāyatanajhāna) / The base of infinite consciousness
Miến / Burmese 66

**VI**
Thiền Thức vô biên xứ là thiền có chỗ nương, đối tượng là thức Không vô biên xứ. Đó là thiền đạt được do tu tập và xem xét lấy thức Không vô biên xứ làm đối tượng.

**EN**
The jhāna of the base of infinite consciousness (viññāṇañcāyatanajhāna) takes as its object the consciousness of the base of infinite space. It is attained by taking that consciousness as object, contemplating it, developing it, and reviewing it.

**VI**
Hành giả muốn tu tập để đạt thiền ấy cần luyện tập thành thạo năm pháp thuần thục của chứng đắc Không vô biên xứ. Khi đã thành thạo, hãy:

**EN**
A meditator who wishes to attain this jhāna should first practise the attainment of the base of infinite space until proficient in all five kinds of mastery. Having gained those masteries:

**VI**
1. Thấy khuyết điểm: chứng đắc Không vô biên xứ mà ta đã đạt có kẻ thù gần là thiền sắc giới.
2. Nó không tịch tịnh như chứng đắc Thức vô biên xứ. Quán thấy khuyết điểm của Không vô biên xứ như vậy.
3. Làm chấm dứt ái, sự say thích Không vô biên xứ.
4. Tác ý Thức vô biên xứ là tịch tịnh.

**EN**
1. See that the attainment of the base of infinite space has a near enemy in the fine-material jhānas.
2. See that it is less peaceful than the attainment of the base of infinite consciousness. Contemplate its drawbacks in this way.
3. Bring craving and delight in the jhāna of the base of infinite space to an end.
4. Attend to the jhāna of the base of infinite consciousness as peaceful.

**VI**
Sau đó nhiều lần suy xét và tác ý “viññāṇaṃ, viññāṇaṃ — thức, thức” đối với thức Không vô biên xứ đã sinh khởi, trải khắp cảnh tướng hư không có được do loại bỏ kasiṇa đất. Hãy suy xét bằng tuệ, với sự hiểu biết; dùng tầm hướng tâm và liên tục đưa tâm đến cảnh “thức, thức”.

**EN**
Then repeatedly consider and attend to the consciousness of the base of infinite space, which arose pervading the sign of space obtained by removing the earth kasiṇa. Consider it with discernment. Through applied thought, direct the mind repeatedly towards it as “viññāṇaṃ, viññāṇaṃ—consciousness, consciousness.”

**VI**
Không nên chỉ tác ý riêng “vô biên, vô biên”. Có thể tác ý “viññāṇaṃ, viññāṇaṃ — thức, thức”, hoặc “anantaṃ viññāṇaṃ, anantaṃ viññāṇaṃ — thức vô biên, thức vô biên”.

**EN**
Do not attend simply to “infinite, infinite.” You may attend either to “consciousness, consciousness” or to “infinite consciousness, infinite consciousness.”


<a id="M02-body-P067"></a>
## Chú ý đối tượng chân đế / Absorption with consciousness as object
Miến / Burmese 67

**VI**
Khi hành giả liên tục suy xét và tác ý như vậy, các triền cái bị chế ngự, niệm vững chắc trên cảnh thức Không vô biên xứ. Nhờ cận định, tâm an trú. Hành giả nhiều lần chuyên chú, tu tập và làm cho sung mãn cảnh thức ấy. Như tâm Không vô biên xứ an chỉ trên hư không đã có do loại bỏ kasiṇa, tâm Thức vô biên xứ an chỉ trên thức Không vô biên xứ đã trải khắp hư không ấy. (Visuddhi 1,325.)

**EN**
When a meditator repeatedly develops the mind with that sign of consciousness, namely the consciousness of the base of infinite space, the hindrances and stains of defilement fall away. Mindfulness is firmly established on that consciousness. Through access concentration the mind engaged in development becomes well collected. The meditator repeatedly apprehends the sign of consciousness, develops it, and practises it many times. Just as the jhāna consciousness of the base of infinite space arose in absorption with the sign of space obtained by removing the kasiṇa, so the jhāna consciousness of the base of infinite consciousness arises in absorption with the consciousness that had pervaded that space as its object. (Visuddhimagga I, 325.)

**VI**
Hãy nhớ đối tượng là pháp chân đế

**EN**
Remember that the object is an ultimate reality

**VI**
Đối tượng ở đây là thức Không vô biên xứ, một pháp chân đế. Lấy riêng thức ấy làm cảnh, hành giả tác ý “viññāṇaṃ, viññāṇaṃ — thức, thức”. Tâm tu tập suy xét thức ấy rồi đạt sức an chỉ chính là tâm Thức vô biên xứ. Thiền Không vô biên xứ và thiền Thức vô biên xứ đều là những tâm thiền rất mạnh. Đối tượng của thiền trước là tướng hư không chế định; đối tượng của thiền sau là thức Không vô biên xứ, pháp chân đế. Cả hai đều là tâm thiền, là pháp chân đế.

**EN**
The object contemplated here is the jhāna consciousness of the base of infinite space, an ultimate object. When the meditator contemplates that consciousness as “consciousness, consciousness,” the mind engaged in development settles firmly on it. The jhāna consciousness that arises in absorption after the access impulsions is that of the base of infinite consciousness. It takes the consciousness of the base of infinite space as object. One is the jhāna consciousness being contemplated. The other is the jhāna consciousness that contemplates it. Both are jhāna consciousnesses and both are ultimate realities.


<a id="M02-body-P068"></a>
## Cách hướng đến Thức vô biên xứ / Advice on discerning the object
Miến / Burmese 68

**VI**
Lời khuyên đặc biệt

**EN**
A practical difficulty

**VI**
Vì đối tượng là pháp chân đế, hành giả tuệ bén nhạy, khéo quan sát danh pháp, thường không gặp khó khăn trong việc nhận biết thức Không vô biên xứ. Hành giả có thể muốn biết các chi thiền xả và nhất tâm của Không vô biên xứ: trước hết hãy phân biệt chúng. Rồi lấy riêng tâm trong nhóm tâm và tâm sở ấy làm đối tượng của tu tập.

**EN**
Because the object is an ultimate reality, some meditators who have yet to discern mentality may have difficulty discerning the consciousness of the base of infinite space. When asked whether they can discern that jhāna's two factors, equanimity and one-pointedness, they say that they can.

**VI**
Hãy quan sát tâm thiền sinh khởi nương sắc ý vật bên trong trái tim. Nếu không phân biệt được sắc ý vật, có thể quan sát tâm thiền trong ý môn, tức tâm hữu phần sinh khởi nương sắc ý vật ấy. Tuy nhiên, nên nhớ: đây là việc biết bằng tâm, không phải nhìn bằng mắt hay dùng trí tưởng tượng; sắc ý vật không phải quả tim thịt.

**EN**
They are then advised to discern the jhāna consciousness that arises with those two factors in the same cognitive process. This enables them to discern it. A further question often arises. As the consciousness of the base of infinite space arises in dependence on the material heart-base within the heart, should one focus on the location of the heart-base when contemplating “consciousness, consciousness”? The answer is yes. This is done by directing the mind there. There is no need to bend the head and look towards the heart with the eyes.

**VI**
Cách thành tựu thiền Thức vô biên xứ

**EN**
Attaining the base of infinite consciousness

**VI**
Khi hành giả tu tập như trên, kinh diễn tả thành tựu như sau:

**EN**
When a meditator develops the practice to this extent, the attainment is described as follows.

**VI**
Sabbaso ākāsānañcāyatanaṃ samatikkamma “anantaṃ viññāṇaṃ”ti viññāṇañcāyatanaṃ upasampajja viharati. (Abhi 2,254; Dī 2,60.)

**EN**
Sabbaso ākāsānañcāyatanaṃ samatikkamma “anantaṃ viññāṇaṃ”ti viññāṇañcāyatanaṃ upasampajja viharati. (Abhidhamma 2, p. 254; Dīgha Nikāya 2, p. 60.)


<a id="M02-body-P069"></a>
## Vượt qua Không vô biên xứ / What is surmounted in this attainment
Miến / Burmese 69

**VI**
“Vượt qua hoàn toàn Không vô biên xứ, tác ý ‘thức là vô biên’, vị ấy thành tựu và an trú Thức vô biên xứ.” (Abhi 2,254; Dī 2,60; Visuddhi 1,325.)

**EN**
“Having completely surmounted the base of infinite space, attending ‘consciousness is infinite,’ the meditator enters and dwells in the base of infinite consciousness.” (Abhidhamma 2, p. 254; Dīgha Nikāya 2, p. 60; Visuddhimagga I, 325.)

**VI**
Khi trình bày con đường đến Không vô biên xứ, kinh nói vượt qua các thiền sắc giới cùng đối tượng của chúng, tức sắc kasiṇa đất v.v. Còn ở đây, để đi đến Thức vô biên xứ, kinh nói vượt qua riêng Không vô biên xứ, không nói thêm vượt qua đối tượng của nó. Vì sao? Tuy vượt qua tâm thiền và cảnh thiền trước, hành giả vẫn lấy chính tâm thiền Không vô biên xứ làm đối tượng. Do đó, đức Phật chỉ dạy “sabbaso ākāsānañcāyatanaṃ samatikkamma — vượt qua hoàn toàn Không vô biên xứ”. (Visuddhi 1,325–326.)

**EN**
Here “the base of infinite space” refers both to the jhāna and to its object, the sign of space. The meditator can enter and dwell in the base of infinite consciousness only by completely surmounting both, through the non-arising of that jhāna and by leaving its object out of attention. The Buddha therefore describes the surmounting of the jhāna and its object together by saying “having surmounted the base of infinite space.” (Visuddhimagga I, 325–326.)

**VI**
Bản chất cần hiểu

**EN**
What this means

**VI**
Một tâm không thể có đồng thời hai đối tượng. Cũng vậy, nó không thể đồng thời là đối tượng của chính nó. Thiền Không vô biên xứ và Thức vô biên xứ đều là tâm, nhưng trong thiền trước, hư không vô biên hiện ra như chế định. Trong thiền sau, chính tâm thiền trước ấy hiện rõ làm đối tượng…

**EN**
Two consciousnesses cannot arise simultaneously in a single mind moment. One can arise only after another. The jhāna consciousness of the base of infinite space that is contemplated and the jhāna consciousness of the base of infinite consciousness that contemplates it cannot arise together. When the former is undergoing arising, presence, and dissolution, the latter cannot do so. When the latter is undergoing arising, presence, and dissolution, the former cannot…


<a id="M02-body-P070"></a>
## Thức vô biên / Why consciousness is called infinite
Miến / Burmese 70

**VI**
…Đối tượng hư không của tâm Không vô biên xứ không còn hiện rõ như trước; chính tâm thiền ấy hiện rõ với tư cách cảnh. Không thể vì nhận biết tâm Không vô biên xứ mà cho rằng vẫn chưa vượt qua Không vô biên xứ. Đã vượt qua ở đây có nghĩa là vượt qua sự chứng nhập và cảnh của thiền trước. Hành giả chỉ biết tâm thiền trước làm cảnh, không còn biết hư không là cảnh của nó. Dù vậy, nhờ thường tu tập, hành giả vẫn có thể nhập lại Không vô biên xứ; không nên hiểu rằng sau khi đạt Thức vô biên xứ thì không thể nhập lại thiền trước. (Xem Anupadasutta, Uparipaṇṇāsa, mục 95; Majjhima, tập 3, tr. 78.)

**EN**
…do so. Only when the consciousness taken as object, that of the base of infinite space, is no longer undergoing arising, presence, and dissolution can the consciousness of the base of infinite consciousness fully arise. The earlier jhāna consciousness knew only the sign of space obtained by removing the kasiṇa. Once the consciousness that knew space is surmounted, that knowing of the sign of space is no longer present. The sign of space as object is therefore surmounted at the same time. Although both that jhāna and its object have been surmounted, the consciousness of the base of infinite consciousness can still take the past, ceased consciousness of the base of infinite space as its object. (See the Anupada Sutta, Uparipaṇṇāsa, section 95; Majjhima, vol. 3, p. 78.)

**VI**
Thức vô biên

**EN**
Infinite consciousness

**VI**
Thức Không vô biên xứ lấy hư không chế định vô biên, không có chỗ tận cùng và giới hạn, làm đối tượng. Hành giả lấy chính thức thiền đã trải khắp hư không vô biên ấy làm cảnh, quán “anantaṃ viññāṇaṃ — thức vô biên”. Nói theo lời các vị chú giải, “thức vô biên” là tâm thiền Không vô biên xứ biết hư không không giới hạn…

**EN**
The consciousness of the base of infinite space takes as object the concept of boundless space, the sign of space with no limit. “Infinite,” the name of its object, is applied figuratively to the consciousness that takes it, transferring the name of the cause to the result. Thus the consciousness of the base of infinite space itself is called “infinite consciousness.” A meditator who seeks the base of infinite consciousness should attend to that very consciousness as “infinite consciousness.” On this explanation, “infinite consciousness” refers to consciousness whose object is the concept of space without bounds…


<a id="M02-body-P071"></a>
## Thiền Vô sở hữu xứ (ākiñcaññāyatanajhāna) / The base of nothingness
Miến / Burmese 71

**VI**
…Nói cách khác, đối với người đang tu tập để đạt Thức vô biên xứ, không phải tùy lúc mở rộng đối tượng một tầm tay, hai tầm tay, một do-tuần v.v. Phải lấy thức Không vô biên xứ đã biết hư không vô biên làm đối tượng. Khi không giới hạn cảnh thức ấy, hành giả nói trong tâm “anantaṃ viññāṇaṃ — thức vô biên”. Chính vì lấy thức biết hư không vô biên làm cảnh mà gọi là Thức vô biên xứ. (Visuddhi 1,326.)

**EN**
…that is, the sign of space, and thus refers to the consciousness of the base of infinite space. Alternatively, when the mind engaged in developing infinite consciousness takes the earlier consciousness as its object, it does not take arising, presence, or dissolution separately. It takes the whole consciousness of the base of infinite space without dividing it. In particular, the developing mind of infinite consciousness takes it without imposing boundaries, attending to the whole of that earlier consciousness without omitting even the least part. On this explanation it is called “infinite consciousness” because the consciousness of the base of infinite space is taken without division. (Visuddhimagga I, 326.)

**VI**
Thiền Vô sở hữu xứ

**EN**
The jhāna of the base of nothingness (ākiñcaññāyatanajhāna)

**VI**
Vô sở hữu xứ là thiền có đối tượng là sự không có của thức Không vô biên xứ. Hành giả muốn đạt thiền ấy trước hết cần luyện năm pháp thuần thục đối với Thức vô biên xứ. Sau khi thuần thục, hãy:

**EN**
The jhāna of the base of nothingness takes as object the concept of the absence of the jhāna of the base of infinite space. To develop it, first practise the attainment of the base of infinite consciousness until proficient in all five kinds of mastery. Then reflect as follows.

**VI**
1. Suy xét khuyết điểm: thiền Thức vô biên xứ đã đạt có kẻ thù gần là Không vô biên xứ…

**EN**
1. The attainment of the base of infinite consciousness that I have attained has a near enemy in the base of infinite space. That is, it may decline at any time and fall back to the base of infinite space…


<a id="M02-body-P072"></a>
## Lấy sự không có của thức làm cảnh / Attending to absence
Miến / Burmese 72

**VI**
…đó là ý nghĩa của kẻ thù gần.

**EN**
…This is what is meant by a near enemy.

**VI**
2. Thiền Thức vô biên xứ không tịch tịnh như Vô sở hữu xứ; thấy khuyết điểm của thiền Thức vô biên xứ như vậy.
3. Làm chấm dứt sự say thích, ái đối với Thức vô biên xứ.
4. Tác ý rằng Vô sở hữu xứ là tịch tịnh.
5. Thức Không vô biên xứ trước kia là đối tượng của Thức vô biên xứ. Nay tác ý sự không có, sự rỗng vắng, sự trống không của chính thức Không vô biên xứ ấy.

**EN**
2. The base of infinite consciousness is less peaceful than the base of nothingness. See its drawbacks in this way.
3. Bring attachment and longing for the base of infinite consciousness to an end.
4. Attend to the base of nothingness as peaceful.
5. The jhāna of the base of infinite consciousness arose taking as object the consciousness of the base of infinite space. Attend to the absence of that earlier consciousness, the concept of its non-presence, as empty and secluded.

**VI**
Ghi chú — Như đã nói ở trên, một tâm không thể đồng thời có hai cảnh. Khi thức Không vô biên xứ hiện rõ với tư cách cảnh, thức Thức vô biên xứ hiện rõ với tư cách tâm biết cảnh ấy. Nhưng ở đây không lấy thức Không vô biên xứ làm cảnh như vậy nữa. Chỉ lấy sự không có của nó làm cảnh. Đó gọi là sự không có, natthibhāva. Cần tác ý chính sự không có ấy.

**EN**
Note. As explained above, two consciousnesses cannot arise simultaneously in one mind moment. While the consciousness of the base of infinite space undergoes arising, presence, and dissolution, the consciousness of the base of infinite consciousness cannot do so. Conversely, when the latter undergoes arising, presence, and dissolution, the former no longer does so. The absence of the earlier consciousness in terms of arising, presence, and dissolution is called the concept of absence. Attend to that concept.

**VI**
Tác ý thế nào? Không tiếp tục suy xét thức Không vô biên xứ như trước, mà lấy sự không có của thức ấy làm cảnh…

**EN**
How should one attend? Leave the consciousness of the base of infinite space entirely out of attention and take only its absence as object…


<a id="M02-body-P073"></a>
## “Không có”, “rỗng vắng”, “trống không” / Absorption in the base of nothingness
Miến / Burmese 73

**VI**
1. “Natthi, natthi — không có, không có”; hoặc “natthi kiñci, natthi kiñci — không có bất cứ gì, không có bất cứ gì”.
2. “Suññaṃ, suññaṃ — rỗng vắng, rỗng vắng”.
3. “Vivittaṃ, vivittaṃ — trống không, trống không”.

**EN**
1. “Natthi, natthi—there is none, there is none,” or “natthi kiñci, natthi kiñci—there is nothing, there is nothing.”
2. “Suññaṃ, suññaṃ—empty, empty.”
3. “Vivittaṃ, vivittaṃ—secluded, secluded.”

**VI**
Hãy nhiều lần suy xét, tác ý, quán sát bằng tuệ, dùng tầm hướng tâm đến cảnh ấy. Câu “natthi kiñci — không có bất cứ gì” chỉ nhằm nêu ý nghĩa của việc không có ấy. (Visuddhi 1,326–327.)

**EN**
Consider it and attend to it repeatedly. Penetrate it with discernment. With applied thought, direct the mind to it and turn the mind repeatedly towards it as “there is nothing, there is nothing.” (Visuddhimagga I, 326–327.)

**VI**
Nhờ liên tục suy xét theo cách trên về sự không có của thức Không vô biên xứ, các triền cái bị chế ngự, niệm vững chắc nơi cảnh là sự không có của thức ấy. Tâm tu tập an trú với sức cận định. Hành giả tiếp tục chuyên chú, tu tập và làm cho sung mãn cảnh sự không có. Khi ấy, tâm Vô sở hữu xứ an chỉ trên sự rỗng vắng, sự trống không, sự không có của thức Không vô biên xứ. Cũng giống như tâm Không vô biên xứ an chỉ trên hư không có được do loại bỏ kasiṇa, rồi tâm Thức vô biên xứ an chỉ trên thức Không vô biên xứ. (Visuddhi 1,327.)

**EN**
When the meditator develops the mind with this sign that leads to jhāna, the concept of the absence of the consciousness of the base of infinite space, the hindrances and stains of defilement fall away. Mindfulness is firmly established on that absence. Through access concentration the developing mind settles well. Repeatedly apprehend, develop, and practise with that sign. In one who practises in this way, the jhāna consciousness of the base of nothingness arises in absorption taking as its object the emptiness, seclusion, or absence of the consciousness of the base of infinite space, which had arisen pervading the sign of space obtained by removing the earth kasiṇa. This is analogous to the arising of the consciousness of the base of infinite consciousness with the consciousness that had pervaded the sign of space as its object. (Visuddhimagga I, 327.)


<a id="M02-body-P074"></a>
## Một điểm đặc biệt cần nhớ / Seeing only the absence
Miến / Burmese 74

**VI**
Khi tâm Vô sở hữu xứ an chỉ trên sự không có của thức Không vô biên xứ như vậy, không phải chỉ bằng lời “không có” mà thành tựu. Tâm tu tập phải trực tiếp nhận biết sự không có ấy.

**EN**
A point to remember. When the jhāna consciousness of the base of nothingness arises with the concept of absence as its object, the meditator contemplates only the absence of the consciousness of the base of infinite space.

**VI**
Ví dụ thế gian: một người đến giảng đường hoặc một nơi họp và thấy chúng tỳ-khưu đang hội họp trong đó. Người ấy đi nơi khác làm việc. Sau khi các tỳ-khưu kết thúc cuộc họp và đi khỏi, người ấy trở lại. Từ cửa nhìn vào, người ấy không thấy các vị tỳ-khưu mà trước đó mình đã thấy. Nhưng người ấy không suy xét rằng họ đã chết hay đã đi phương nào. Chỉ thấy nơi họp rỗng vắng, trống không, không có người, và nghĩ: “Nơi này rỗng vắng, trống không”.

**EN**
For an illustration from ordinary life, suppose a man sees monks assembled on some business in a meeting hall and then goes elsewhere. He later returns to the hall. By then the meeting has ended and the monks have left. Standing in the doorway, he looks in and sees only that the place is empty and deserted. It does not occur to him to speculate whether so many monks have died or gone somewhere else. He sees only that they are absent from the meeting place and that it is empty of them.

**VI**
Cũng vậy, trước kia hành giả lấy thức Không vô biên xứ đã trải khắp cảnh hư không làm cảnh và đạt Thức vô biên xứ. Nay hành giả không tác ý thức ấy mà lấy sự không có của nó làm cảnh…

**EN**
Similarly, the meditator formerly contemplated as “consciousness, consciousness,” with the eye of the jhāna of the base of infinite consciousness, the consciousness of the base of infinite space that had arisen on the sign of space obtained by removing the earth kasiṇa. Later…


<a id="M02-body-P075"></a>
## Ý nghĩa của “natthi, suññaṃ, vivittaṃ” / Nothing, empty, secluded
Miến / Burmese 75

**VI**
…tác ý nhiều lần “natthi, natthi”, “suññaṃ, suññaṃ”, “vivittaṃ, vivittaṃ”. Khi ấy tâm tu tập chỉ thấy sự không có, sự trống không, sự rỗng vắng của thức Không vô biên xứ; chứ không thấy thức ấy đã đi đâu. (Visuddhi 1,327.)

**EN**
…taking as object the absence of that consciousness, the meditator applies the preliminary attention “natthi, natthi,” “suññaṃ, suññaṃ,” or “vivittaṃ, vivittaṃ.” When the consciousness of the base of infinite space disappears from view, the developing mind repeatedly contemplates only the concept of its absence, that is, the fact that it is absent and has disappeared from view. (Visuddhimagga I, 327.)

**VI**
Natthi, natthi; suññaṃ, suññaṃ; vivittaṃ, vivittaṃ

**EN**
Natthi, natthi. Suññaṃ, suññaṃ. Vivittaṃ, vivittaṃ.

**VI**
Nhờ tác ý theo các từ chuẩn bị ấy mà thức Không vô biên xứ biến mất trong sự nhận biết, nhưng không phải vì không còn nhớ hay đã hủy diệt thức ấy. Thức Thức vô biên xứ lấy thức Không vô biên xứ làm cảnh; do đó được gọi bằng tên Thức vô biên xứ. Khi muốn vượt qua, hành giả thôi tác ý đối tượng ấy. Vì không tác ý và không suy xét thức Không vô biên xứ, thức ấy không hiện rõ ở tư cách cảnh. Hành giả chỉ lấy sự không có của nó làm cảnh. Do không tác ý, không lấy nó làm cảnh và tác ý sự không có của nó, thức Không vô biên xứ không hiện rõ…

**EN**
The statement that the consciousness of the base of infinite space disappears through this preliminary attention means that its disappearance becomes apparent because it is no longer taken as object. It does not disappear on account of being destroyed. The consciousness of the base of infinite consciousness takes the consciousness of the base of infinite space as object and attends to it. While the former arises, the latter is apparent in its role as an object condition. The consciousness of the base of nothingness, however, does not take that earlier consciousness as object or attend to it. It takes and attends only to the concept of its absence. Thus, because the consciousness of the base of nothingness does not take or attend to the consciousness of the base of infinite space and attends only to its absence, that consciousness of the base of infinite space…


<a id="M02-body-P076"></a>
## Giải thích ví dụ về giảng đường / The meaning of disappearance
Miến / Burmese 76

**VI**
…đó là ý nghĩa của việc thức Không vô biên xứ biến mất. Không phải thức ấy thật sự bị hủy diệt hay bị xóa khỏi trí nhớ.

**EN**
…disappears from view. This is the intended meaning. Its disappearance here does not refer to its destruction.

**VI**
Giải thích ví dụ thế gian

**EN**
Explanation of the illustration

**VI**
Ở trên, Visuddhimagga dùng ví dụ giảng đường để giải thích. Không nên hiểu lầm ví dụ. Người trước kia thấy các tỳ-khưu đang họp, rồi đi làm việc ở nơi khác; khi trở lại, nếu nhìn giảng đường mà không nhớ trước đó có các vị ở đây thì không thể biết nơi ấy nay vắng các vị. Chỉ vì nhớ từng có các vị ở đó, nay nhìn lại không thấy, người ấy mới biết sự vắng mặt của các vị và sự trống không của giảng đường.

**EN**
In the example above, the man saw a group of monks assembled in a hall and went elsewhere. Later all the monks left the hall on some business. When the man returned and looked in, he saw only that the assembly place was deserted. He did not investigate why the monks had gone.

**VI**
Cũng vậy, tuy hành giả đã vượt qua Không vô biên xứ nhờ tâm Thức vô biên xứ và không còn lấy thức trước làm cảnh, khi tu tập “natthi — không có”, hành giả vẫn nhớ biết thức Không vô biên xứ đã từng làm đối tượng. Nhờ vậy mới biết và tác ý sự không có của thức ấy. Điều cần vượt qua không phải là khả năng nhớ biết nó, mà là việc lấy nó làm đối tượng và tác ý nó. (Đại sớ giải 1,402.)

**EN**
Likewise, the meditator first contemplated the consciousness of the base of infinite space with the eye of the jhāna of the base of infinite consciousness. Later, attending to it in preliminary development as “there is none,” the meditator finds that it is absent. With the eye of the jhāna of the base of nothingness, the meditator contemplates only the concept of its absence, without investigating why that consciousness is absent or ceased. The jhāna of the base of nothingness does not attend to the cause of its absence, cessation, or non-presence. (Mahāṭīkā I, 402.)


<a id="M02-body-P077"></a>
## Thành tựu Vô sở hữu xứ / Attaining the base of nothingness
Miến / Burmese 77

**VI**
Sabbaso viññāṇañcāyatanaṃ samatikkamma “natthi kiñcī”ti ākiñcaññāyatanaṃ upasampajja viharati. (Abhi 2,254; Dī 2,60.)

**EN**
Sabbaso viññāṇañcāyatanaṃ samatikkamma “natthi kiñci”ti ākiñcaññāyatanaṃ upasampajja viharati. (Abhidhamma 2, p. 254; Dīgha Nikāya 2, p. 60.)

**VI**
Nhờ tu tập như trên, hành giả vượt qua hoàn toàn Thức vô biên xứ cùng đối tượng của nó, tức thức Không vô biên xứ đã làm cảnh của Thức vô biên xứ. Tác ý “natthi kiñci — không có bất cứ gì”, tức sự không có của thức Không vô biên xứ, bằng những cách chuẩn bị “natthi, natthi; suññaṃ, suññaṃ; vivittaṃ, vivittaṃ”, hành giả thành tựu và an trú Vô sở hữu xứ. (Abhi 2,254; Dī 2,60; Visuddhi 1,327.)

**EN**
The words describe a meditator who completely surmounts the jhāna of the base of infinite consciousness and its object, the consciousness of the base of infinite space. Taking as object the concept of the absence of that earlier consciousness, the meditator attends “there is none,” “empty,” or “secluded,” and enters and dwells in the base of nothingness. (Abhidhamma 2, p. 254; Dīgha Nikāya 2, p. 60; Visuddhimagga I, 327.)

**VI**
Sabbaso viññāṇañcāyatanaṃ samatikkamma

**EN**
Sabbaso viññāṇañcāyatanaṃ samatikkamma—having completely surmounted the base of infinite consciousness

**VI**
Ở đây, vượt qua cả Thức vô biên xứ và thức Không vô biên xứ là đối tượng của nó. Vì vậy, đức Phật chỉ dạy vượt qua Thức vô biên xứ mà không cần nói riêng việc vượt qua đối tượng của thiền ấy. Đó là ý nghĩa câu “vượt qua hoàn toàn Thức vô biên xứ”. (Visuddhi 1,328.)

**EN**
The meditator enters and dwells in the base of nothingness only after fully surmounting the base of infinite consciousness and its object, the consciousness of the base of infinite space, through the non-arising of that jhāna and non-attention to its object. The Buddha accordingly includes both jhāna and object in the phrase “having surmounted the base of infinite consciousness.” (Visuddhimagga I, 328.)

**VI**
Natthi kiñci — không có bất cứ gì

**EN**
Natthi kiñci—there is nothing

**VI**
“Natthi, natthi; suññaṃ, suññaṃ; vivittaṃ, vivittaṃ” là những cách tác ý…

**EN**
This refers to attending “natthi, natthi,” “suññaṃ, suññaṃ,” or “vivittaṃ, vivittaṃ”…


<a id="M02-body-P078"></a>
## Ý nghĩa tên Vô sở hữu xứ / What “there is nothing” means
Miến / Burmese 78

**VI**
…đối với sự không có của thức ấy. Vì vậy, khi giải nghĩa câu “natthi kiñci” trong kinh, chú giải nói không thấy, không tác ý thức Không vô biên xứ. Không phải vì thức ấy bị hủy diệt mà nói “không có bất cứ gì”. Phải nắm lấy ý nghĩa này khi đọc lời giải về câu “sabbaso viññāṇañcāyatanaṃ samatikkamma”, thay vì chỉ chấp chữ. Chú giải dùng lời ngắn gọn để chỉ ý nghĩa đã trình bày. Đừng hiểu rằng mình phải quên hay hủy diệt thức ấy. Chỉ ngừng suy xét, ngừng tác ý và biết bằng tuệ sự không có của nó, thì ý nghĩa của lời kinh không bị mất hay mâu thuẫn. Nên ghi nhớ ý chính ấy. (Visuddhi 1,328.)

**EN**
…The Vibhaṅga says that the consciousness of the base of infinite space, previously attended to as “infinite consciousness,” is made to disappear from view, so that not even the least trace of it remains apparent. One contemplates in this way, hence the words “there is nothing.” Although the wording resembles that used of insight contemplating the dissolution of formations, as in the phrase “as subject to destruction,” understand the Vibhaṅga here in the sense already explained. The meditator does not consider that consciousness, attend to it, or penetrate it with discernment. By attending exclusively to its absence, the concept of its non-presence, the meditator makes it disappear from view. The passage should be understood in this sense. (Visuddhimagga I, 328.)

**VI**
Vô sở hữu xứ có nghĩa là gì?

**EN**
What is the jhāna of the base of nothingness?

**VI**
Hành giả lấy sự không có, sự vắng mặt của thức Không vô biên xứ làm cảnh và nỗ lực đạt tâm thiền Vô sở hữu xứ. Thức Không vô biên xứ không còn lại dù chỉ một phần nhỏ, theo nghĩa nó không hiện hữu trong đối tượng đang được tác ý. Do đó gọi là akiñcana — không có chút gì. Sự không có chút gì ấy…

**EN**
The meditator strives to attain the jhāna of the base of nothingness by taking the concept of the absence of the consciousness of the base of infinite space as object. In this practice not the slightest trace of that consciousness, as the object contemplated in the lower attainment, remains. It is therefore described by the term akiñcana in the explanation of the name.


<a id="M02-body-P079"></a>
## Thiền Phi tưởng phi phi tưởng xứ / Neither perception nor non-perception
Miến / Burmese 79

**VI**
…không để lại dù chút gì của thức Không vô biên xứ làm cảnh, được gọi là ākiñcañña. Sự không có ấy được gọi là natthibhāva. Vì đây là chế định, không phải một thực tại chân đế, nên có tên natthibhāva, sự không có. Từ “không có bất cứ gì” chỉ sự không có của thức Không vô biên xứ vốn đã làm cảnh cho Thức vô biên xứ. Cảnh ấy là chỗ nương của tâm thiền thứ ba trong các thiền vô sắc; bởi vậy gọi là ākiñcaññāyatanajhāna, thiền Vô sở hữu xứ. (Visuddhi 1,328.)

**EN**
…The disappearance from the meditator's knowledge of the consciousness of the base of infinite space, with no trace left, is called ākiñcañña. Its absence is called natthibhāva. This absence is a concept rather than an ultimate reality and is therefore called the concept of absence (natthibhāvapaññatti). Just as a deity's residence is called a dwelling place, this concept of absence is called a base (āyatana) because it serves as the basis for the third immaterial jhāna. Hence the third immaterial jhāna arising with that concept as its object is called the jhāna of the base of nothingness. (Visuddhimagga I, 328.)

**VI**
Thiền Phi tưởng phi phi tưởng xứ

**EN**
The jhāna of the base of neither perception nor non-perception (nevasaññānāsaññāyatanajhāna)

**VI**
Trong thiền này không có tưởng thô rõ, mà chỉ có tưởng cực kỳ vi tế. Vì thế không thể nói có tưởng, cũng không thể nói không có tưởng. Đó là thiền Phi tưởng phi phi tưởng xứ. Ở đây kinh dùng tưởng làm pháp đứng đầu để diễn tả. Thật ra, tất cả 10 danh pháp tương ưng trong chứng đắc ấy — tâm, tưởng, thọ, tư v.v. — đều hết sức vi tế. Không có danh pháp thô rõ, cũng không phải không có các danh pháp vi tế. Do vượt qua các tướng thô rõ và chỉ còn sự vận hành vi tế, chứng đắc này còn được gọi là chứng đắc thứ tư của thiền vô sắc, có tính chất hành dư tối hậu, saṅkhārāvasesasamāpatti.

**EN**
In this attainment there is no gross perception, only exceedingly subtle perception. It is therefore called the jhāna of the base of neither perception nor non-perception. The teaching names it in terms of perception. All thirty-one mental phenomena present in this attainment, including consciousness, contact, feeling, and volition, are also exceedingly subtle. Only these exceedingly subtle mental phenomena are present. The attainment is therefore called saṅkhārāvasesasamāpatti, the attainment with only a residue of formations. Formations have reached the utmost subtlety and only this barely describable residue remains in the fourth immaterial attainment.


<a id="M02-body-P080"></a>
## Trình tự tu tập Phi tưởng phi phi tưởng xứ / Preparing for the fourth immaterial attainment
Miến / Burmese 80

**VI**
Hành giả muốn tu tập để đạt chứng đắc Phi tưởng phi phi tưởng xứ cần thành thạo năm pháp thuần thục đối với Vô sở hữu xứ. Khi đã thuần thục, hãy suy xét:

**EN**
A meditator who wishes to attain the base of neither perception nor non-perception should first practise the base of nothingness until proficient in all five kinds of mastery. Having done so, reflect as follows.

**VI**
1. Chứng đắc Vô sở hữu xứ mà ta đã đạt có kẻ thù gần là Thức vô biên xứ.
2. Nó chưa tịch tịnh như chứng đắc Phi tưởng phi phi tưởng xứ. “Tưởng là bệnh; tưởng như ung nhọt; tưởng như mũi tên. Chỉ Phi tưởng phi phi tưởng xứ mới tịch tịnh, mới cao quý.”

**EN**
1. The attainment of the base of nothingness that I have gained has a near enemy in the base of infinite consciousness.
2. It is less peaceful than the base of neither perception nor non-perception. Reflect also: “Perception is a disease, perception is a boil, perception is a dart. This base of neither perception nor non-perception is peaceful. This base of neither perception nor non-perception is sublime.”

**VI**
Hãy thấy khuyết điểm của Vô sở hữu xứ và lợi ích của Phi tưởng phi phi tưởng xứ như vậy.

**EN**
In this way see the drawbacks of the base of nothingness and the benefits of the higher attainment, the base of neither perception nor non-perception.

**VI**
3. Làm chấm dứt sự say thích, ái đối với Vô sở hữu xứ.
4. Tác ý Phi tưởng phi phi tưởng xứ là tịch tịnh.
5. Lấy chứng đắc Vô sở hữu xứ, vốn đã sinh khởi với sự không có của thức Không vô biên xứ làm cảnh, làm đối tượng…

**EN**
3. Bring delight in and attachment to the base of nothingness to an end.
4. Attend to the base of neither perception nor non-perception as peaceful.
5. The jhāna of the base of nothingness arises taking as object the concept of the absence of the consciousness of the base of infinite space…


<a id="M02-body-P081"></a>
## Lấy tâm Vô sở hữu xứ làm cảnh / Absorption in neither perception nor non-perception
Miến / Burmese 81

**VI**
…quán “santaṃ, santaṃ — tịch tịnh, tịch tịnh”. Hãy nhiều lần suy xét, tác ý, dùng tuệ quán sát và dùng tầm hướng tâm đến cảnh ấy. Cách nói “santaṃ, santaṃ” chỉ nhằm gợi ý phương pháp tác ý. (Visuddhi 1,328–329.)

**EN**
…Take that very attainment as object and repeatedly consider and attend to it as “santaṃ, santaṃ—peaceful, peaceful.” Discern it with understanding. With applied thought, direct the mind to it and turn the mind repeatedly towards it as “peaceful, peaceful.” (Visuddhimagga I, 328–329.)

**VI**
Nơi hành giả liên tục tác ý và suy xét tâm chứng đắc Vô sở hữu xứ như vậy, các triền cái và những cấu uế phiền não bị chế ngự; niệm vững chắc trên cảnh tâm Vô sở hữu xứ. Nhờ cận định, tâm tu tập an trú vững chắc.

**EN**
As the meditator repeatedly applies this meditative attention to the sign of the attainment of nothingness, the hindrances and stains of defilement fall away. Mindfulness is firmly established with the consciousness of the base of nothingness as object. The developing mind becomes well collected through access concentration.

**VI**
Hành giả tiếp tục chuyên chú, tu tập, làm cho sung mãn tướng tâm Vô sở hữu xứ ấy, là cảnh hỗ trợ cho Phi tưởng phi phi tưởng xứ. Tâm tu tập nhiều lần tác ý và làm cho thuần thục cảnh ấy. Khi đó, như tâm Vô sở hữu xứ đã an chỉ trên sự không có của thức Không vô biên xứ, tâm Phi tưởng phi phi tưởng xứ an chỉ trên bốn danh uẩn của chứng đắc Vô sở hữu xứ, vốn hết sức tịch tịnh. (Visuddhi 1,329.)

**EN**
The meditator repeatedly apprehends, develops, and practises this sign of the attainment of nothingness, which leads to the jhāna of neither perception nor non-perception. Taking it repeatedly as object, the meditator establishes concentration so that the developing mind settles firmly on it. Just as the jhāna of nothingness arose in absorption with the concept of the absence of the consciousness of infinite space as object, so the consciousness of neither perception nor non-perception arises in absorption with the four mental aggregates of the attainment of nothingness as object. (Visuddhimagga I, 329.)


<a id="M02-body-P082"></a>
## Thành tựu Phi tưởng phi phi tưởng xứ / Attaining neither perception nor non-perception
Miến / Burmese 82

**VI**
Vuttañhetaṃ: “sabbaso ākiñcaññāyatanaṃ samatikkamma nevasaññānāsaññāyatanaṃ upasampajja viharatī”ti. (Abhi 2,254; Dī 2,60; Visuddhi 1,329.)

**EN**
Vuttañhetaṃ: “Sabbaso ākiñcaññāyatanaṃ samatikkamma nevasaññānāsaññāyatanaṃ upasampajja viharatī”ti vuccati. (Abhidhamma 2, p. 254; Dīgha Nikāya 2, p. 60; Visuddhimagga I, 329.)

**VI**
Vì thế, kinh nói: “Vượt qua hoàn toàn Vô sở hữu xứ, vị ấy thành tựu và an trú Phi tưởng phi phi tưởng xứ”. Nghĩa là hành giả vượt qua cả Vô sở hữu xứ và sự không có của thức Không vô biên xứ vốn là cảnh của nó. Tác ý “santaṃ, santaṃ — tịch tịnh, tịch tịnh” đối với thức Vô sở hữu xứ, hành giả thành tựu và an trú Phi tưởng phi phi tưởng xứ. (Abhi 2,254; Dī 2,60; Visuddhi 1,329.)

**EN**
This describes a meditator who completely surmounts the jhāna of the base of nothingness and its object, the concept of the absence of the consciousness of infinite space. Attending to the consciousness of nothingness as “peaceful, peaceful,” the meditator enters and dwells in the base of neither perception nor non-perception. (Abhidhamma 2, p. 254; Dīgha Nikāya 2, p. 60; Visuddhimagga I, 329.)

**VI**
Ākiñcaññāyatanaṃ samatikkamma

**EN**
Ākiñcaññāyatanaṃ samatikkamma—having surmounted the base of nothingness

**VI**
Cả tâm thiền Vô sở hữu xứ và sự không có vốn là đối tượng của nó đều được gọi là Vô sở hữu xứ. Như đã giải thích, sự không có ấy gọi là ākiñcañña. Vì làm cảnh cho tâm thiền vô sắc thứ ba nên gọi là āyatana, chỗ nương; như nơi sinh của chư thiên được gọi là thiên xứ. Vì vậy cảnh sự không có có tên ākiñcaññāyatana. Như làng vừa là nơi sinh sống vừa được gọi bằng tên làng, theo nghĩa chuyển sang chỗ nương, sự không có ấy được gọi là Vô sở hữu xứ…

**EN**
Both the jhāna of nothingness and the concept of absence that serves as its object are called the base of nothingness here. Its object, the concept of absence, is called ākiñcañña as explained above. It is also called a base (āyatana) because the third immaterial jhāna rests on it, just as a deity's residence is called a dwelling place. Thus the concept of absence is called the base of nothingness. Just as the country of Kamboja is a region in which horses arise, so the concept of absence…


<a id="M02-body-P083"></a>
## Tịch tịnh và cao quý / Attending to the peaceful and sublime
Miến / Burmese 83

**VI**
…Tâm thiền vô sắc thứ ba lấy cảnh ấy làm chỗ nương cũng được gọi bằng tên Vô sở hữu xứ. Do lấy cảnh Vô sở hữu xứ làm chỗ nương nên tâm thiền được gọi là āyatana; bởi vậy có tên ākiñcaññāyatana.

**EN**
…is ākiñcañña and is also a base because it is a cause of the arising of the third immaterial jhāna, the base of nothingness. For this reason too it is called ākiñcaññāyatana.

**VI**
Khi nói “vượt qua hoàn toàn Vô sở hữu xứ”, kinh bao gồm cả tâm thiền ấy lẫn sự không có vốn là đối tượng của nó. Tuy vượt qua cả hai, khi chứng nhập Phi tưởng phi phi tưởng xứ, hành giả vẫn lấy riêng tâm Vô sở hữu xứ làm cảnh. Vì thế, trong trường hợp này kinh không nói thêm vượt qua cảnh thiền. Cần biết ý nghĩa ấy. (Visuddhi 1,329.)

**EN**
Only after surmounting both the jhāna and the concept of absence, through the non-arising of the jhāna and non-attention to its object, does the meditator enter and dwell in the base of neither perception nor non-perception. The Buddha accordingly includes both in the words “having surmounted the base of nothingness.” (Visuddhimagga I, 329.)

**VI**
Tịch tịnh, cao quý

**EN**
Peaceful and sublime

**VI**
[CHƯA XÁC MINH: cần kiểm lại toàn bộ chuyển tự Latin của câu Pāli ở đoạn này; giữ riêng nghi vấn, không tự hoàn chỉnh theo trí nhớ.] (Visuddhi 1,329.)

**EN**
Santato manasi karotīti “santā vatāyaṃ samāpatti, yatra hi nāma natthibhāvampi ārammaṇaṃ karitvā ṭhassatī”ti ce santārammaṇatāya taṃ santāti manasi karoti. (Visuddhimagga I, 329.) [Latin transcription to be checked against the Pāli edition.]

**VI**
[CHƯA XÁC MINH: toàn bộ chuyển tự Latin câu Pāli in ở đây cần được kiểm lại trên bản rõ hơn.] Ý câu trích: khi tác ý sự tịch tịnh, hành giả khen ngợi tưởng ấy: “Tưởng này thật tịch tịnh: nó có thể an trú lấy chính sự không có làm đối tượng”. Như vậy, hành giả tác ý sự tịch tịnh nơi chính đối tượng là tưởng ấy. (Visuddhi 1,329.)

**EN**
To attain neither perception nor non-perception, attend to the base of nothingness, which is the object contemplated, in the following ways.

**VI**
1. “Santaṃ santaṃ — tịch tịnh, tịch tịnh”; hoặc “santametaṃ — đây là tịch tịnh”.
2. “Sukhaṃ sukhaṃ; sukhametaṃ — an lạc, an lạc; đây là an lạc”.
3. “Paṇītaṃ paṇītaṃ — cao quý, cao quý”…

**EN**
1. “Etaṃ santaṃ, etaṃ paṇītaṃ—this is peaceful, this is sublime.”
2. “Santaṃ, santaṃ,” or “santā, santā—peaceful, peaceful.”
3. “Paṇītaṃ, paṇītaṃ—sublime, sublime.”


<a id="M02-body-P084"></a>
## Khen ngợi nhưng không dừng lại nơi thiền trước / In what sense nothingness is peaceful
Miến / Burmese 84

**VI**
…Hành giả tác ý như vậy. Mỗi tâm chỉ có thể biết một đối tượng ở một thời điểm. Nay tâm lấy Vô sở hữu xứ làm cảnh và khen ngợi: “Tâm thiền này tịch tịnh biết bao! Với sự không có của thức Không vô biên xứ làm cảnh, nó có thể an trú thật vi tế”. Khen ngợi thiền trước bằng cách tác ý sự tịch tịnh của nó, rồi vượt qua thiền trước ấy. (Visuddhi 1,329.)

**EN**
…Attend in this way. Ordinarily consciousnesses can remain absorbed for a long time only when they have some definite thing as a knowable object. The third immaterial attainment, the base of nothingness, can take the very concept of absence as its object. Thus the meditator reflects, “How peaceful this attainment is. It can remain with so subtle an object as the concept of absence, the emptiness of the consciousness of infinite space.” Because that attainment has a peaceful object, the meditator attends to it as peaceful. (Visuddhimagga I, 329.)

**VI**
Hành giả không lấy sự không có của thức Không vô biên xứ làm đối tượng như khi nhập thiền vô sắc thứ ba nữa. Vị ấy lấy các tâm chứng đắc Vô sở hữu xứ làm đối tượng và khen ngợi chúng là tịch tịnh. Bởi vậy, các vị chú giải dạy tác ý “tịch tịnh”. Cũng với ý nghĩa ấy có thể tác ý “an lạc”, “cao quý”. Khen ngợi cảnh ấy nhưng không say thích hay dừng lại tại chính chứng đắc đó; sự hướng đến của tâm vẫn là vượt qua nó để đạt chứng đắc cao hơn. Thế nên, lời khen ngợi không ngăn trở việc vượt qua: hành giả vừa lấy thiền trước làm cảnh, vừa hướng đến thiền sau.

**EN**
The meditator praises the third immaterial jhāna as exceedingly peaceful and sublime because it can take the concept of absence as its object. Earlier, during preparation, the meditator considered it less peaceful than the consciousness and mental factors of the fourth immaterial jhāna. The praise “this is peaceful, this is sublime” concerns its ability to take absence as its object. Seeing a fault where there is a fault and praising a quality where there is a quality do not conflict. It is like finding fault with the appearance of an unattractive girl and praising her for her skill.


<a id="M02-body-P085"></a>
## Hỏi và đáp — Ví dụ thế gian / How a peaceful attainment is surmounted
Miến / Burmese 85

**VI**
Hỏi: Nếu tác ý tâm Vô sở hữu xứ là tịch tịnh, làm sao có thể vượt qua tâm thiền và các chi thiền ấy?

**EN**
Question. If one attends to the base of nothingness as peaceful, how can one surmount that jhāna and its object?

**VI**
Đáp: Có thể vượt qua vì không có ý muốn nhập và an trú chứng đắc Vô sở hữu xứ. Tuy suy xét tịch tịnh, hành giả không muốn “ta sẽ nhập, sẽ an trú, sẽ xuất khỏi chứng đắc này”; cũng không còn ý muốn làm các phận sự ấy hay điều khiển chứng đắc bằng năm pháp thuần thục. Hành giả chỉ tác ý tâm thiền ấy là tịch tịnh. Nhờ tác ý như vậy, các tưởng của tâm Vô sở hữu xứ, cùng tính chất không còn tưởng thô rõ của thiền sau, được thành tựu theo trình tự. (Visuddhi 1,330.)

**EN**
Answer. One can surmount it because one has no wish to enter the attainment of nothingness. The meditator does indeed attend to it as peaceful. Yet the meditator does not repeatedly turn the mind towards reviewing it, entering it, resolving to stay in it, emerging from it, or reviewing its factors. Such attention does not arise because the base of neither perception nor non-perception is more peaceful and sublime than the base of nothingness. (Visuddhimagga I, 330.)

**VI**
Ví dụ thế gian

**EN**
An illustration from ordinary life

**VI**
Một vị vua, trong khi đi trên voi của mình, thấy những người thợ ngà dùng vải che đầu, ngồi chụm chân bên đống ngà, chăm chỉ làm các đồ ngà như vòng tay, vòng trang sức. Vua thấy vậy, vui thích và khen: “Khéo thật, giỏi thật!” Nhưng chính vua không từ bỏ vương vị để trở thành người thợ ngà…

**EN**
Suppose a king goes round an exhibition of crafts. He sees ivory workers with one cloth wrapped around their heads and another tied at their waists. Their bodies are covered with ivory dust as they work hard making fine ivory figures, bangles, and other objects. The king warmly praises their workmanship and skill. Yet he has no wish to leave his throne and take up ivory carving himself…


<a id="M02-body-P086"></a>
## Phi tưởng và phi phi tưởng / The function of perception in the highest attainment
Miến / Burmese 86

**VI**
…Vua vẫn đi về cung điện như trước. Đó là ví dụ cho người khen ngợi chứng đắc tịch tịnh mà không muốn an trú lại trong chứng đắc ấy. (Visuddhi 1,330.)

**EN**
…He praises the ivory workers and continues past them until he reaches his palace. Understand the example in this way. (Visuddhimagga I, 330.)

**VI**
Nevasaññā — nāsaññā

**EN**
Nevasaññā—nāsaññā

**VI**
Tưởng trong Phi tưởng phi phi tưởng xứ không thể làm phận sự phân biệt cảnh một cách rõ rệt, nên gọi là nevasaññā — không phải có tưởng. Nhưng vẫn còn tưởng hết sức vi tế, nên gọi là nāsaññā — không phải không có tưởng.

**EN**
The perception in this attainment is called “neither perception” because it cannot perform the evident function of perception. It is also called “nor non-perception” because an exceedingly subtle residue of perception is present.

**VI**
Hỏi: Thế nào là phận sự phân biệt rõ rệt?

**EN**
Question. What is the evident function of perception here?

**VI**
Đáp: Đó là biết rõ các đặc tính của đối tượng; và khả năng, nhờ tạo nền cho minh sát, thấy rõ bản chất của các pháp được lấy làm cảnh.

**EN**
Answer. It consists in recognizing and marking the object, the attainment of nothingness, or in being taken as an object of insight knowledge and giving rise to knowledge of disenchantment.

**VI**
Giải thích: Tưởng trong chứng đắc này không thể phân biệt rõ các đặc tính của cảnh theo cách thô rõ. Nó cũng không thể hỗ trợ minh sát để biết đối tượng rõ như các thiền vô sắc bậc dưới. Vì vậy gọi là phi tưởng. Tuy vậy, không nên hiểu nó hoàn toàn không có tưởng. Trong chứng đắc ấy vẫn còn dòng tưởng vi tế. Nhờ đã từng tác ý cảnh Vô sở hữu xứ một cách cực kỳ vi tế, hành giả mới đạt chứng đắc Phi tưởng phi phi tưởng xứ…

**EN**
Just as the fire element in cold water cannot perform the function of burning, this perception cannot clearly perform the function of marking and recognizing its object, the attainment of nothingness. Nor can it serve as an object of insight and give rise to knowledge of disenchantment in the way that perception in the other three immaterial attainments can. Indeed, a meditating bhikkhu who has never discerned or attended with insight to aggregates other than those of neither perception nor non-perception cannot, by applying the three characteristics to the aggregates of neither perception nor non-perception…


<a id="M02-body-P087"></a>
## Minh sát đối với chứng đắc cực vi tế / The limits of insight into this attainment
Miến / Burmese 87

**VI**
…Nhưng trong chứng đắc Phi tưởng phi phi tưởng xứ, các pháp quá vi tế để hành giả có thể phân biệt từng pháp bằng tuệ minh sát, rồi đạt các Thánh đạo theo phương pháp tuần tự từng pháp như ở các tầng thiền dưới. Đối với pháp tu tập này, ngay cả trí của đại đệ tử đứng đầu về trí tuệ là tôn giả Sāriputta cũng không thể phân biệt tuần tự từng pháp của chứng đắc ấy như các pháp của những tầng dưới. Ngài phân biệt các pháp thuộc những chứng đắc ấy với tuệ hết sức bén nhạy; nhưng khi đến Phi tưởng phi phi tưởng xứ thì phải quán các danh pháp theo nhóm.

**EN**
…contemplate them with insight and reach knowledge of disenchantment with formations. Even Venerable Sāriputta could not have attained knowledge of disenchantment by starting with those aggregates without having attended with insight to other aggregates first.

**VI**
Tôn giả Sāriputta có thể phân biệt từng pháp như xúc v.v. của các chứng đắc dưới, biết rõ lúc chúng sinh, trụ, diệt, với phương pháp anupadadhamma-vipassanā. Tuy nhiên, ở chứng đắc Phi tưởng phi phi tưởng xứ, ngài tác ý: “Các pháp này trước chưa có, nay sinh khởi; sau khi có rồi thì tiêu mất”, rồi quán tổng thể các danh pháp.

**EN**
Only someone of wisdom comparable to Venerable Sāriputta, who began by developing insight into the five aggregates and was thoroughly familiar with seeing the material and mental formations that continually arise at the six doors together with their objects, could bring forth knowledge of rise and fall with regard to the aggregates of neither perception nor non-perception.

**VI**
Do vậy, khi hành minh sát đối với các danh pháp cực vi tế của Phi tưởng phi phi tưởng xứ, ngài phải dùng phương pháp quán theo nhóm, kalāpasammasana. Điều ấy cho thấy sự cực kỳ vi tế của các danh pháp trong chứng đắc này. Không nên vì không phân biệt từng pháp như ở các tầng dưới mà cho rằng hoàn toàn không có tưởng.

**EN**
Even an insight meditator as wise as Venerable Sāriputta could contemplate the mental phenomena of this attainment only collectively, by the method of comprehension in groups (kalāpasammasana): “These phenomena were absent before, then suddenly arose. Having arisen, they suddenly ceased.” He could not apply the three characteristics to each ultimate phenomenon in the attainment separately by the method of insight into successive phenomena (anupadadhammavipassanā). Thus even Venerable Sāriputta, the General of the Dhamma, could not contemplate this attainment by that method…


<a id="M02-body-P088"></a>
## Các tầng thiền càng lên càng vi tế / The increasing subtlety of the immaterial attainments
Miến / Burmese 88

**VI**
…Vì các pháp của chứng đắc ấy hết sức vi tế nên việc minh sát đối với chúng khó khăn như vậy. (Visuddhi 1,331.)

**EN**
…because it had reached such extreme subtlety. (Visuddhimagga I, 331.)

**VI**
Càng lên cao càng vi tế

**EN**
Each successive attainment is more sublime

**VI**
Bốn chứng đắc vô sắc đều chỉ có hai chi thiền theo cách phân biệt chi: xả và nhất tâm. Tuy giống nhau về chi thiền, tầng trên vi tế hơn tầng dưới nhờ sức tu tập mạnh mẽ; vì vậy không thể nói chúng hoàn toàn giống nhau. Ví như một tấm vải được dệt từ sợi mịn dần: qua mỗi lần, người thợ chuẩn bị rồi dệt lại bằng sợi tốt hơn, nên tấm sau mịn hơn tấm trước. Hoặc ví như bốn tấm vải dệt từ sợi thô, sợi mịn, sợi mịn hơn và sợi cực mịn: tuy đều là vải, độ vi tế khác nhau. Hãy nhớ ví dụ ấy để hiểu mỗi chứng đắc vô sắc sau vi tế hơn chứng đắc trước. (Visuddhi 1,332–333.)

**EN**
All four immaterial attainments have the same two jhāna factors, equanimity and one-pointedness. They may therefore appear indistinguishable. Yet each successive attainment is more sublime through the increasing power of development. Imagine a building with four floors. On the lowest floor delicious food and dancers are provided to delight the senses, and the second, third, and fourth floors are similarly furnished, each more splendid than the one below. Or imagine four pieces of cloth of the same length and width, woven from thread that is coarse, fine, finer still, and exceedingly fine. Each piece is finer than the preceding one. Understand the attainments in the same way. (Visuddhimagga I, 332–333.)

**VI**
Có những cảnh không được yêu thích

**EN**
An object one must nevertheless take

**VI**
Người nỗ lực đạt Thức vô biên xứ phải thấy khuyết điểm của Không vô biên xứ; bởi vậy, tuy không còn thích thú thiền trước, vì không có một đối tượng khác cho thiền sau, vị ấy vẫn phải lấy tâm Không vô biên xứ làm cảnh.

**EN**
One striving to attain the base of infinite consciousness sees drawbacks in the consciousness of the base of infinite space. Yet there is no other object with which to reach the base of infinite consciousness. As development proceeds, the consciousness of infinite consciousness must take that earlier consciousness as its object.


<a id="M02-body-P089"></a>
## Những kasiṇa còn lại / The remaining kasiṇas
Miến / Burmese 89

**VI**
Cũng vậy, người nỗ lực đạt Phi tưởng phi phi tưởng xứ phải thấy khuyết điểm của Vô sở hữu xứ. Dù không còn yêu thích thiền trước, vì không có một cảnh khác, vị ấy vẫn lấy tâm Vô sở hữu xứ làm đối tượng để đạt chứng đắc cao hơn. Ví như một vị vua không ưa vị vua láng giềng nhưng vì không tìm được chỗ nương khác nên vẫn phải nương người ấy. (Visuddhi 1,334.)

**EN**
Likewise, one striving to attain neither perception nor non-perception sees drawbacks in the consciousness of the base of nothingness. Yet there is no other object with which to reach the higher attainment. As development proceeds, the consciousness of neither perception nor non-perception must take that consciousness as its object. It is like a minister who sees faults in the king but, having no other suitable livelihood, must remain in the service of that same king. (Visuddhimagga I, 334.)

**VI**
Một người thấy khuyết điểm của quê hương, không còn muốn sống ở đó, nhưng không có nơi sống khác nên phải quay lại; hoặc không ưa một miền nhưng không có phương cách sinh sống ở nơi khác nên phải nương miền ấy; hoặc chán món ăn này nhưng không có món khác nên phải dùng lại. Cũng theo cách ấy, tâm Thức vô biên xứ lấy tâm Không vô biên xứ làm cảnh, còn tâm Phi tưởng phi phi tưởng xứ lấy tâm Vô sở hữu xứ làm cảnh. (Visuddhi 1,334–335.)

**EN**
The need to take such an object may also be understood through a man climbing a long ladder who must rely on the rungs because there is nothing else to hold, someone ascending mountain peaks who must use those very peaks, or someone climbing a rocky mountain who trembles and, having nothing else to grasp, must rely on his own cloth. In the same way, the jhāna of infinite consciousness arises with the consciousness of infinite space as its object, and the jhāna of neither perception nor non-perception arises with the consciousness of nothingness as its object. (Visuddhimagga I, 334–335.)

**VI**
Những kasiṇa còn lại

**EN**
The remaining kasiṇas

**VI**
Đã trình bày theo thứ tự cách đạt tám chứng đắc lấy kasiṇa đất làm nền. Cũng vậy, với những kasiṇa còn lại, ngoại trừ kasiṇa hư không giới hạn, hãy nỗ lực đạt tám chứng đắc…

**EN**
The method of developing the eight attainments using the earth kasiṇa as a basis has now been presented in sequence. Apply the same method to the other kasiṇas from water through light and strive to attain the eight attainments with each…


<a id="M02-body-P090"></a>
## Kết thúc phần kasiṇa — Bốn đề mục bảo hộ / From the kasiṇas to the protective meditations
Miến / Burmese 90

**VI**
…Hãy đạt ít nhất tứ thiền. Sau khi đạt tứ thiền trên một kasiṇa còn lại, nhập tứ thiền ấy rồi mở rộng cảnh kasiṇa đến vô biên. Xuất thiền, loại bỏ cảnh kasiṇa và lấy hư không có được do loại bỏ kasiṇa làm cảnh, đạt Không vô biên xứ. Tiếp theo, lấy thức Không vô biên xứ làm cảnh, đạt Thức vô biên xứ; lấy sự không có của thức ấy làm cảnh, đạt Vô sở hữu xứ; lấy thức Vô sở hữu xứ làm cảnh, đạt Phi tưởng phi phi tưởng xứ. Làm như vậy, đường đi của tu tập trở nên rộng mở.

**EN**
…Here is a brief example. Establish concentration on the water kasiṇa up to the fourth jhāna. Emerge and consider the drawbacks of materiality. Extend the water kasiṇa through countless world systems. Reflect on the drawbacks of the fourth jhāna and the advantages of infinite space. Then discern the sign of space in the water kasiṇa sign and remove the water kasiṇa. When it disappears and only the sign of space remains, take that sign as object to attain infinite space. Take the consciousness of infinite space as object to attain infinite consciousness, the concept of the absence of the consciousness of infinite space to attain nothingness, and the consciousness of nothingness to attain neither perception nor non-perception. This much should suffice to make the method clear.

**VI**
Bây giờ sẽ lần lượt trình bày bốn đề mục bảo hộ, caturārakkha kammaṭṭhāna: tu tập tâm từ, niệm Ân đức Phật, tu tập bất tịnh và niệm chết. Trước hết trình bày tâm từ. Nhân dịp giải thích tâm từ thuộc các phạm trú, cũng trình bày chung tâm bi, tâm hỷ, tâm xả. Cách tu tập sẽ được trình bày dựa vào hành giả lấy niệm hơi thở, ānāpāna, làm nền.

**EN**
The four protective meditation subjects will now be presented. They are loving-kindness, recollection of the Buddha, foulness, and mindfulness of death. Loving-kindness will be presented first. Because it is one of the divine abidings, the other three divine abidings, compassion, appreciative joy, and equanimity, will be presented along with it. The method of practice will be given in outline following the exposition on the divine abidings in the Visuddhimagga.


<a id="M02-body-P091"></a>
## Bốn đề mục bảo hộ — Tu tập tâm từ / The divine abidings: loving-kindness
Miến / Burmese 91

**VI**
Các phạm trú — Đề mục tu tập tâm từ

**EN**
The four protective meditation subjects. The divine abidings and the development of loving-kindness (mettā)

**VI**
Thiện nam tử muốn tu tập đề mục tâm từ cần biết lời dạy “đừng tu tập tâm từ ngay từ đầu đối với những hạng người này; và đừng tu tập tâm từ đối với những hạng người này”. Đó là:

**EN**
A good person who wishes to develop loving-kindness should know which persons can hinder its development. With some one should not begin the practice, and with others one should not develop it in the specified manner at all.

**VI**
1. Appiyapuggala — người không thân ái.
2. Atippiyasahāyaka — người bạn quá đỗi thân ái.
3. Majjhattapuggala — người trung tính, không thân không ghét.
4. Verīpuggala — người thù nghịch.

**EN**
1. Appiyapuggala—a person who is not dear.
2. Atippiyasahāyaka—a very dear friend or companion.
3. Majjhattapuggala—a neutral person, neither loved nor disliked.
4. Veripuggala—an enemy.

**VI**
Đừng bắt đầu tu tập tâm từ với bốn hạng người này. Sau khi đã đạt thiền tâm từ, có thể lần lượt tu tập theo thứ tự: bản thân, người thân ái, người trung tính, người thù nghịch. Những người được dùng làm đối tượng phải là người đang sống và cùng giới tính.

**EN**
Do not begin by developing loving-kindness towards these four kinds of person before attaining mettā jhāna. Once mettā jhāna has been attained, develop it in the order self, dear person, neutral person, and enemy, so as to attain jhāna. The individuals chosen should be living persons of the same sex.

**VI**
Ghi chú: Người không thân ái là người từng gây tổn hại lợi ích của mình, của người thân mình, hoặc làm lợi ích cho người mình không ưa, v.v. Khi mình nghĩ đến họ, những điều như “người ấy đã làm hại lợi ích của ta; đã làm hại lợi ích người ta yêu quý” dễ khơi dậy tâm sân. Người thù nghịch cũng là người gây tổn hại mình hoặc người thân mình, hay giúp ích người mình không ưa, khiến mình đối nghịch với họ. (Đại sớ giải 1,351.)

**EN**
Note. A person who is not dear includes someone who does not act for one's welfare or the welfare of someone dear to oneself, or someone who acts for the welfare of a person one dislikes. Such people can be grounds for resentment, as when one thinks, “They did not act for my welfare,” or “They did not act for the welfare of someone dear to me.” An enemy is someone who acts to harm oneself or someone dear to oneself. (Mahāṭīkā I, 351.)


<a id="M02-body-P092"></a>
## Những đối tượng không dùng lúc khởi đầu tâm từ / Whom to choose for developing loving-kindness
Miến / Burmese 92

**VI**
5. Liṅgavisabhāga — người khác giới tính: không tu tập tâm từ riêng biệt chỉ hướng đến một người khác giới. Nam hành giả không lấy riêng một người nữ làm đối tượng; nữ hành giả không lấy riêng một người nam làm đối tượng. Vì ái dục có thể sinh khởi, đừng tu tập riêng như thế.

**EN**
5. Liṅgavisabhāga—a person of the opposite sex. Do not develop loving-kindness with a particular person of the opposite sex as the object. A woman should not direct it specifically to an individual man, and a man should not direct it specifically to an individual woman. Lust may arise.

**VI**
6. Kālakata puggala — người đã chết: hoàn toàn không tu tập tâm từ với người ấy làm đối tượng.

**EN**
6. Kālakata puggala—a person who has died. Do not develop loving-kindness with a deceased person as object.

**VI**
Giải thích lý do

**EN**
The reasons

**VI**
Muốn xem người mình không thân ái như người thân ái để trải tâm từ là việc mệt nhọc. Với người quá đỗi yêu quý cũng vậy: chỉ một chút bất hạnh xảy đến với họ đã có thể làm mình khóc lóc. Muốn xem người trung tính như người đáng kính, đáng yêu để tu tập tâm từ cũng khó. Khi nhớ đến người thù nghịch, sân có thể sinh khởi. Vì vậy, ban đầu không nên lấy bốn hạng người ấy làm đối tượng. Với người khác giới, vì có thể sinh ái dục, không tu tập riêng biệt như đã nói. Nếu lấy người chết làm đối tượng thì không đạt cận định hay an chỉ định của tâm từ. Do đó không tu tập tâm từ đối với người ấy.

**EN**
Trying to place someone who is not dear in the position of a dear person is tiring. Trying to place a very dear friend in the position of a neutral person is tiring too. If even slight suffering befalls that very dear friend, one may feel as if one were about to weep. Trying to regard a neutral person as someone respected or dear is also tiring. Repeatedly recalling an enemy can arouse anger. Therefore do not begin the practice with these four kinds of person. Do not develop it specifically towards an individual of the opposite sex because lust may arise. After attaining mettā jhāna and breaking down the barriers, one may develop loving-kindness towards all women (sabbā itthiyo) or all men (sabbe purisā). If one develops it towards a deceased person…


<a id="M02-body-P093"></a>
## Khởi đầu tu tập tâm từ đối với bản thân / Beginning with oneself
Miến / Burmese 93

**VI**
…Không thể đạt cận định hoặc an chỉ thiền tâm từ với người chết làm đối tượng. Vì vậy không lấy họ làm cảnh tu tập. (Visuddhi 1,287–288.)

**EN**
…one cannot reach either absorption or access concentration in loving-kindness. Therefore do not develop loving-kindness with a deceased person as object. (See Visuddhimagga I, 287–288.)

**VI**
Thứ tự các đối tượng để tu tập tâm từ:

**EN**
The order of persons towards whom loving-kindness is developed:

**VI**
1. Atta — bản thân.
2. Piya — người đáng yêu, đáng kính, hết sức thân ái.
3. Majjhatta — người trung tính, không thân không ghét.
4. Verī — người thù nghịch.

**EN**
1. Atta—oneself.
2. Piya—someone dear or respected, and someone very dear.
3. Majjhatta—a neutral person, neither loved nor disliked.
4. Veri—an enemy.

**VI**
Hãy tu tập lần lượt đối với bốn hạng này. Trước hết trải tâm từ đến chính mình. Dù tu tập với bản thân làm cảnh suốt cả trăm năm hay ngàn năm, vẫn không đạt thiền tâm từ. Vì sao phải bắt đầu như vậy? Khi nghĩ “ahaṃ sukhito homi — mong ta được an vui; mong ta thoát khỏi khổ thân và khổ tâm”, hành giả lấy chính mình làm ví dụ. Khi thật sự hiểu rằng mình muốn được an vui, hành giả suy xét: “Ta muốn an vui và ghét khổ; các chúng sinh khác cũng vậy. Họ cũng muốn được an vui, không muốn chịu khổ”.

**EN**
Develop loving-kindness towards these four in order. Begin with oneself as an example. This is not for attaining absorption. Even if a meditator were to develop loving-kindness towards oneself for a hundred or a thousand years with the thought “Ahaṃ sukhito homi—may I be happy in body and mind,” absorption would not arise in this way.

**VI**
Nhờ ví dụ bản thân, hành giả dễ phát khởi ý muốn các chúng sinh khác được an vui. Vì vậy, trước khi hướng đến người khác, cần làm phát sinh ước muốn an vui đối với bản thân, rồi dùng chính mình làm chứng cho sự ước muốn ấy ở mọi người.

**EN**
When developing loving-kindness towards oneself with the thought “May I be happy in body and mind,” the meditator reflects that just as one wishes for happiness, dislikes suffering, wants to live, and does not want to die, other beings likewise wish for happiness, dislike suffering, and want to live. Using oneself as an example in this way gives rise to a wish for the welfare and happiness of other beings.


<a id="M02-body-P094"></a>
## Bản thân làm ví dụ — Bốn lời nguyện / Wishes for one's own well-being
Miến / Burmese 94

**VI**
Sabbā disā anuparigamma cetasā,
nevajjhagā piyataramattanā kvaci;
evaṃ piyo puthu attā paresaṃ,
tasmā na hiṃse paramattakāmo. (Saṃ 1,75; Khu 1,133.)

**EN**
Sabbā disā anuparigamma cetasā,
nevajjhagā piyataramattanā kvaci.
Evaṃ piyo puthu attā paresaṃ,
tasmā na hiṃse paramattakāmo. (Saṃyutta Nikāya 1, p. 75; Khuddaka Nikāya 1, p. 133.)

**VI**
Dù dùng tâm tìm khắp các phương, cũng không thấy nơi nào có người được mình yêu quý hơn bản thân. Bản thân của những người khác cũng được họ yêu quý như vậy. Do đó, người muốn an vui cho mình đừng làm hại người khác. (Saṃ 1,75; Khu 1,133.)

**EN**
Even after searching all directions with the mind, one finds no other being dearer than oneself. Just as one can find no one dearer than oneself, each of the other beings holds themselves dear. Therefore a good person who wishes for their own welfare and happiness should not harm another being. (Saṃyutta Nikāya 1, p. 75; Khuddaka Nikāya 1, p. 133.)

**VI**
Nhờ suy xét và ghi nhớ các lời dạy này, hãy làm tâm mềm dịu, để ước muốn chúng sinh được an vui phát triển. Trước hết, đối với bản thân, tu tập tâm từ theo bốn cách:

**EN**
Following these instructions, first develop loving-kindness towards yourself for a short time, so that the mind becomes gentle and tender and empathy takes root.

**VI**
1. Ahaṃ avero homi.
2. Abyāpajjo homi.
3. Anīgho homi.
4. Sukhī attānaṃ pariharāmi.

**EN**
1. Ahaṃ avero homi.
2. Abyāpajjo homi.
3. Anīgho homi.
4. Sukhī attānaṃ pariharāmi.

**VI**
1. Mong tôi không có hiểm nguy, thù nghịch.
2. Mong tôi không có khổ tâm.
3. Mong tôi không có khổ thân.
4. Mong tôi được khỏe mạnh, an vui, tự gìn giữ bản thân.

**EN**
1. May I be free from enmity and danger.
2. May I be free from mental suffering.
3. May I be free from bodily suffering.
4. May I look after myself happily and in good health.


<a id="M02-body-P095"></a>
## Hướng đến một người thân ái đáng kính / Turning towards a dear and respected person
Miến / Burmese 95

**VI**
Khi tâm đã mềm dịu và ước muốn chúng sinh an vui trở nên mạnh mẽ, hành giả có thể phát triển tâm từ hướng đến những người khác. Tuy nhiên, ở giai đoạn đầu, nếu tâm chưa mềm dịu và ước muốn an vui ấy chưa mạnh, hãy liên tục trải tâm từ đến chính mình theo cách trên. Khi những yếu tố ấy đã đầy đủ, hãy tiếp tục tu tập theo thứ tự dưới đây để thành tựu thiền tâm từ.

**EN**
When the mind has become gentle and tender and empathy has grown strong, turn to developing loving-kindness towards other beings. For someone whose mind is already tender and whose empathy is strong, loving-kindness towards another being may be developed readily, without difficulty, and extensive practice towards oneself is unnecessary. To develop loving-kindness towards another being up to mettā jhāna, practise in the following order.

**VI**
Hướng đến một người đáng yêu, đáng kính

**EN**
A dear and respected person of the same sex

**VI**
Hành giả hãy nhập tứ thiền niệm hơi thở đã đạt, hoặc tứ thiền của một kasiṇa. An trú cho đến khi ánh sáng rực rỡ, lan khắp, rồi xuất thiền. Nhớ đến một người cùng giới tính, còn sống, đáng yêu và đáng kính; nhờ có giới hạnh, định, tuệ hay những đức tính khác, người ấy khiến mình khởi lòng tôn kính và thiện cảm. Nhớ những ân đức như giới hạnh, rộng lượng, lời nói đáng mến của vị ấy; làm cho lòng kính mến và ước muốn an vui đối với vị ấy khởi lên.

**EN**
Re-establish fourth-jhāna concentration on mindfulness of breathing or, if you can, fourth-jhāna concentration on the white kasiṇa, until the light shines brilliantly. Concentration on the white kasiṇa is preferable. With the aid of this concentration and its light, and with the strength imparted by that concentration as a powerful decisive support, the development of loving-kindness proceeds readily.

**VI**
Hãy nhớ công đức của người đáng kính ấy và khiến hình ảnh vị ấy hiện rõ trong ánh sáng của định. Khi nhớ đến vị ấy, hãy làm cho ước muốn vị ấy được an vui mạnh mẽ…

**EN**
Through fourth-jhāna concentration the mind is clear of the stains of greed, hatred, delusion, and the other defilements. It has become malleable (mudubhūta), tender and pliant, and wieldy (kammaniya), ready for the particular meditation to be developed. It is purified and bright, with radiant light. These qualities enable the development of loving-kindness to proceed readily within a short time…


<a id="M02-body-P096"></a>
## Bốn lời nguyện hướng đến người đáng kính / Directing loving-kindness to a respected person
Miến / Burmese 96

**VI**
…Vì hành giả đã từng nhìn thấy người đáng kính ấy, hãy dùng ánh sáng mạnh của định tìm đến nơi vị ấy đang ở, nhìn rõ vị ấy trong ánh sáng ấy. Nhờ định có được từ tứ thiền, ánh sáng sáng trong, rực rỡ. Nếu thấy nhiều người bên cạnh vị ấy thì không tác ý những người đó. Chỉ chú ý khuôn mặt, hình dáng người đáng kính đã chọn, nhất là vẻ mặt tươi vui, và làm cho thiện cảm đối với vị ấy sinh khởi. Hướng tâm đến vị ấy như người đáng yêu quý của mình, khiến ý mong vị ấy được an vui trở nên rõ ràng; rồi trải tâm từ theo bốn cách:

**EN**
…because they help strengthen loving-kindness. When the light shines brilliantly, bring to mind a living person of the same sex whom you dearly love, value, and respect. The light arising from fourth-jhāna concentration spreads in all directions around you. You will see within that light the person you have brought to mind as the object of loving-kindness. Choose the posture and appearance in which you most liked to see that person and in which they seemed happiest, whether sitting, standing, or otherwise. Bring that image to mind about four or five cubits away. Once the person appears clearly in the light, develop loving-kindness as follows.

**VI**
Ayaṃ sappuriso:
1. Avero hotu.
2. Abyāpajjo hotu.
3. Anīgho hotu.
4. Sukhī attānaṃ pariharatu.

**EN**
Ayaṃ sappuriso:
1. Avero hotu.
2. Abyāpajjo hotu.
3. Anīgho hotu.
4. Sukhī attānaṃ pariharatu.

**VI**
Mong bậc thiện nhân này:
1. Không có hiểm nguy, thù nghịch.
2. Không có khổ tâm.
3. Không có khổ thân.
4. Được khỏe mạnh, an vui, tự gìn giữ bản thân.

**EN**
May this good person:
1. Be free from enmity and danger.
2. Be free from mental suffering.
3. Be free from bodily suffering.
4. Look after themselves happily and in good health.


<a id="M02-body-P097"></a>
## Mỗi lời nguyện đều tu tập đến tam thiền / Developing each wish to the third jhāna
Miến / Burmese 97

**VI**
Hành giả chỉ tu tập một cách trải tâm từ mỗi lần. Không gộp cả bốn lời nguyện thành một đối tượng. Ví dụ, chọn lời nguyện “mong vị ấy không có khổ tâm”; làm cho tâm tha thiết mong vị ấy thoát khổ tâm, rồi tiếp tục tu tập cho đến khi tâm an trú vững chắc. Hãy tu tập lời nguyện này cho đến sơ thiền, nhị thiền và tam thiền theo thứ tự. Sau đó, chọn một trong ba lời nguyện còn lại và cũng tu tập đến tam thiền. Cứ thế, khi nguyện vị ấy không hiểm nguy thì phải hướng tâm đến việc không hiểm nguy; khi nguyện không khổ tâm thì hướng tâm đến việc không khổ tâm; khi nguyện không khổ thân thì hướng tâm đến việc không khổ thân; khi nguyện vị ấy an vui tự gìn giữ bản thân thì hướng đến chính sự an vui ấy. Có thể vận dụng tám thành tố của an chỉ đã nêu ở phần niệm hơi thở để luyện tập cho thuần thục.

**EN**
Practise the four ways of developing loving-kindness about three or four times. Then choose whichever of the four you prefer. Suppose you choose “May this person be free from mental suffering.” Take the image of that person free from mental suffering and smiling as your object. Repeat the wish many times. Once the developing mind settles very peacefully on the image, review the jhāna factors. Develop the first, second, and third jhānas in order. Then develop each of the four wishes in turn up to the third jhāna. When wishing freedom from danger, let the person appear free from danger. When wishing freedom from mental or bodily suffering, let the person appear free from that suffering. When wishing that the person look after themselves happily and in good health, let them appear to do so. Practise until proficient in the five kinds of mastery for each mettā jhāna.

**VI**
Evarūpe ca puggale kāmaṃ appanā sampajjati. (Visuddhi 1,289.)
Jhānacittaṃ upanetabbaṃ uppādetabbanti attho. (Đại sớ giải 1,354.)

Đối với hạng người như vậy, quả thật có thể thành tựu an chỉ. “Đưa tâm thiền đến” nghĩa là làm cho tâm thiền sinh khởi.

**EN**
Evarūpe ca puggale kāmaṃ appanā sampajjati. (Visuddhimagga I, 289.)
Jhānacittaṃ upanetabbaṃ uppādetabbanti attho. (Mahāṭīkā I, 354.)

**VI**
Theo các lời giải ấy, mỗi cách tu tập trên mỗi người đều phải đạt tam thiền tâm từ. Hãy luyện tám thành tố an chỉ để mỗi lần tác ý bốn lời nguyện đều có thể đạt tam thiền. Ý muốn người ấy không hiểm nguy, không khổ tâm…

**EN**
According to these explanations in the commentary and subcommentary, develop loving-kindness towards each individual up to the third jhāna. With each of the four ways of developing loving-kindness, reach the third jhāna and practise the five masteries for each jhāna. The wish for freedom from danger, freedom from mental suffering…


<a id="M02-body-P098"></a>
## Lần lượt hướng đến các hạng người / Extending the practice to other individuals
Miến / Burmese 98

**VI**
…không khổ thân, được an vui, phải thật sự là ước muốn cho người ấy, chứ không chỉ đọc câu chữ. Khi tâm mong sự an vui ấy mạnh mẽ và liên tục, có thể đạt tam thiền tâm từ.

**EN**
…and freedom from bodily suffering, and the wish for the person to live happily, are wishes for the person's welfare. Since these wishes are of the nature of loving-kindness rather than equanimity, this practice does not reach the fourth jhāna.

**VI**
Sau khi thành công với một người thân ái đáng kính, hãy lần lượt chọn những người thân ái đáng kính khác, cùng giới, còn sống. Tu tập thành công với ít nhất khoảng mười người, mỗi người đều đạt tam thiền, rồi tiếp tục những người hết sức thân ái. Với mỗi người, tu tập cả bốn cách đến tam thiền. Hai hạng đáng kính và rất thân ái có thể gộp chung dưới tên người thân ái, piya.

**EN**
After succeeding, develop loving-kindness in the same way towards other dear and respected people of the same sex, one at a time. After succeeding with at least about ten, bring to mind very dear living friends of the same sex one by one. Develop loving-kindness up to the third jhāna with each. Practise until loving-kindness towards the dear and respected people and towards the very dear friends is equal, so they all belong to the category of dear persons.

**VI**
Sau đó chọn ít nhất khoảng mười người trung tính, không thân không ghét; tu tập từng người đến tam thiền theo cả bốn cách. Tất cả các đối tượng đều phải cùng giới và còn sống. Tiếp theo tu tập đối với người thù nghịch. Lúc này cũng không vội chọn một kẻ thù quá dữ dội: hãy chọn người chỉ từng khiến mình bất bình, khó chịu. Nếu không có người thù nghịch, không cần cố tạo ra một người như thế; hãy dùng người chỉ không thích hợp với mình…

**EN**
Then take at least about ten neutral persons, neither loved nor disliked, one by one and develop loving-kindness up to the third jhāna with each. They should all be living persons of the same sex. Then develop loving-kindness towards enemies or people you dislike. Leave the person you dislike most until last and begin with someone with whom you have had a slight disagreement. Once successful, bring enemies to mind one by one and suffuse them with loving-kindness up to jhāna. Develop each of the four wishes up to the third jhāna for each individual. All should be living persons of the same sex. Some people have no enemy and no one they hate. Their minds are like those of the Bodhisatta in the Great Being's births, such as King Nandiya, so even towards people who act against their welfare…


<a id="M02-body-P099"></a>
## Phá bỏ ranh giới giữa các hạng người / Breaking down the barriers
Miến / Burmese 99

**VI**
…hoặc một người có những đặc tính khiến mình không thích. Nếu không có người thù nghịch thì bỏ qua giai đoạn này. Nếu có, hãy tu tập tâm từ đối với người ấy.

**EN**
…the perception “enemy” does not arise. Such a meditator need not seek out an enemy. Those who have an enemy should develop loving-kindness towards that person.

**VI**
[CHƯA XÁC MINH: chuyển tự Latin hai câu Pāli chữ đậm trong phần này và câu trích dưới đây cần kiểm lại.] (Visuddhi 1,289; Đại sớ giải 1,354.)

**EN**
Āsevantena ca ekekaṃ koṭṭhāse muduṃ kammaniyaṃ cittaṃ katvā tadanantare tadanantare upasaṃharitabbaṃ. (Visuddhimagga I, 289.)
Tena vuttaṃ “tadanantare tadanantare upasaṃharitabban”ti, jhānacittaṃ uppādetabbanti attho. (Mahāṭīkā I, 354.) [Transcription of these two Pāli lines to be checked.]

**VI**
Có bốn loại người: người thân ái, người quá đỗi thân ái, người trung tính và người thù nghịch. Hành giả có thể đã làm cho tâm từ trở nên nhu nhuyến đối với từng hạng, đạt tam thiền đối với họ, rồi khiến tâm hoàn toàn thích hợp cho việc tu tập. Tiếp theo cần phá bỏ ranh giới giữa các loại người, sīmāsambheda.

**EN**
There are four classes of person to whom loving-kindness is directed here: a dear person, a very dear person, a neutral person, and an enemy. Practise with one class until the mind engaged in development becomes pliant and accustomed to the practice, reaching the third jhāna. Then direct the mind to each succeeding class and bring forth jhāna consciousness. (Visuddhimagga I, 289. Mahāṭīkā I, 354.)

**VI**
Sīmāsambheda — Phá bỏ ranh giới giữa các hạng người

**EN**
Sīmāsambheda—breaking down the boundaries between persons

**VI**
Bằng cách liên tục tu tập tâm từ và làm cho tâm thuần thục, hãy khiến tâm từ đối với cả bốn — bản thân, người thân ái, người trung tính và người thù nghịch — được bình đẳng. Khi tâm từ không phân biệt các ranh giới ấy thì gọi là phá bỏ ranh giới. (Visuddhi 1,300; Đại sớ giải 1,362.)

**EN**
By repeatedly developing loving-kindness, make the mind equal towards oneself, a dear person, a neutral person, and an enemy. This is how the barriers are broken down. “Equality of mind” here means an equal mind towards the persons concerned. It is that equality which constitutes the breaking down of the barriers. (Visuddhimagga I, 300. Mahāṭīkā I, 362.)

**VI**
1. Người thân ái đáng kính: người được kính yêu bởi những đức tính như giới, định, tuệ…

**EN**
1. Piyamanāpagārubhāvanīya—a person who is dear, pleasing, worthy of respect and esteem, and who encourages the growth of wholesome qualities.


<a id="M02-body-P100"></a>
## Tâm từ bình đẳng đối với bốn hạng người / Making loving-kindness equal
Miến / Burmese 100

**VI**
2. Người quá đỗi thân ái: người bạn rất đỗi yêu quý.
3. Người trung tính: người không thân không ghét.
4. Người thù nghịch: người đối nghịch với mình.

**EN**
2. Atippiyasahāyaka—a very dear friend or companion.
3. Majjhatta—a neutral person, neither loved nor disliked.
4. Veri—an enemy or a person one dislikes.

**VI**
Khi đã tu tập đến tam thiền đối với những hạng ấy, hãy gộp người đáng kính và người quá đỗi thân ái thành hạng piya. Để tu tập phá bỏ ranh giới, có bốn hạng:

**EN**
When you have become proficient in developing loving-kindness up to the third jhāna towards these four kinds of person, loving-kindness towards the dear and respected person and the very dear friend becomes equal. They can then be treated as a single category of dear persons.

**VI**
1. Atta — bản thân.
2. Piya — người thân ái, gồm người đáng kính và người quá đỗi thân ái.
3. Majjhatta — người trung tính.
4. Verī — người thù nghịch.

**EN**
1. Atta—oneself.
2. Piya—a dear and respected person or a very dear person.
3. Majjhatta—a neutral person, neither loved nor disliked.
4. Veri—an enemy or a person one dislikes.

**VI**
Hãy khiến tâm từ đối với bốn hạng người ấy bình đẳng. Không còn nghĩ “người này là chính ta”, “người này thân ái”, “người này trung tính”, “người này là thù nghịch”. Hãy luyện tập đề mục tâm từ để tâm không còn bị chia cắt theo các ranh giới ấy. Khi trải tâm từ đến bản thân, không thể đạt thiền, nhưng tâm từ vẫn phải bình đẳng đối với cả bốn. Với các đối tượng khác, tu tập đến tam thiền. Nhờ liên tục tu tập như thế, hành giả có thể phá bỏ những ranh giới giữa các hạng người. Sự phá bỏ ranh giới ấy là làm tâm từ đối với bản thân…

**EN**
Practise so that loving-kindness is equal towards these four. Develop it repeatedly until the mind makes no distinction such as “this is oneself,” “this is a dear person,” “this is a neutral person,” or “this is an enemy.” Loving-kindness with oneself as object cannot reach jhāna. Here the purpose is to develop an equal and uninterrupted flow of loving-kindness, without distinctions between oneself, a dear person, a neutral person, and an enemy. When the loving-kindness is equal, the barriers between persons have been broken down. It is for this breaking down of the barriers…


<a id="M02-body-P101"></a>
## Luyện tập phá bỏ ranh giới / Practising the breaking down of barriers
Miến / Burmese 101

**VI**
…và các hạng người khác trở nên bình đẳng.

**EN**
…that loving-kindness is developed towards oneself at this stage.

**VI**
Trước hết nhập lại tứ thiền niệm hơi thở hoặc tứ thiền kasiṇa đã thành tựu. Khi định đã sáng rõ, an trú vững chắc, xuất thiền, tu tập tâm từ đối với bản thân, rồi lần lượt đối với một người thân ái, một người trung tính, một người thù nghịch, mỗi người đến tam thiền. Sau đó lại trải tâm từ đến bản thân; rồi chọn một người thân ái khác, một người trung tính khác, một người thù nghịch khác, lần lượt tu tập đến tam thiền. Cả bốn cách trải tâm từ đều phải đạt tam thiền trên những đối tượng có thể đạt thiền.

**EN**
First re-establish a fourth jhāna already attained on mindfulness of breathing or the white kasiṇa. When the light becomes strong, develop loving-kindness towards yourself for a short time, about a quarter of a minute. Then take a dear person as object and develop loving-kindness up to the third jhāna. Do the same with a neutral person, and then with an enemy.

**VI**
Tiếp tục chuyển qua các người thân ái, trung tính, thù nghịch khác. Hãy nhiều lần tu tập lần lượt: bản thân — thân ái — trung tính — thù nghịch; bản thân — thân ái — trung tính — thù nghịch. Khi sức tu tập tăng trưởng, khiến tâm từ đối với ba hạng người ấy đều bình đẳng. Khi đạt được sự bình đẳng này, ranh giới giữa các hạng người đã bị phá bỏ, gọi là sīmāsambheda.

**EN**
Next develop loving-kindness towards yourself again in the same way. Then take another dear person, another neutral person, and another enemy in turn and do likewise. For each dear person, neutral person, and enemy, develop each of the four wishes up to the third jhāna.

**VI**
Sau khi thành tựu sīmāsambheda, hành giả có thể tiếp tục tu tập tâm từ giải thoát theo ba cách…

**EN**
Continue in this way, changing the dear, neutral, and hostile persons one by one and repeating the sequence oneself, dear person, neutral person, and enemy many times. Train so that the mind developing loving-kindness has an even quality and so that the mettā jhānas attained towards dear, neutral, and hostile persons are equal. When the attitude and the mettā jhānas have become equal, the barriers between persons have been broken down. At that point, as stated in the Paṭisambhidāmagga, the meditator can proceed to the following methods…


<a id="M02-body-P102"></a>
## Ba cách trải tâm từ giải thoát / The three modes of pervading with loving-kindness
Miến / Burmese 102

**VI**
1. Anodhisopharaṇā mettā cetovimutti — năm cách trải tâm từ giải thoát không phân biệt giới hạn.
2. Odhisopharaṇā mettā cetovimutti — bảy cách trải tâm từ giải thoát có phân biệt giới hạn.
3. Disāpharaṇā mettā cetovimutti — mười cách trải tâm từ giải thoát theo phương hướng.

**EN**
1. Five modes of liberation of mind through loving-kindness by unspecified pervasion (anodhisopharaṇā mettā cetovimutti).
2. Seven modes of liberation of mind through loving-kindness by specified pervasion (odhisopharaṇā mettā cetovimutti).
3. Ten modes of liberation of mind through loving-kindness by directional pervasion (disāpharaṇā mettā cetovimutti). These methods of developing loving-kindness can now be practised.

**VI**
Tasmiṃ appanāppattacittasseva sattādīnaṃ pharaṇaṃ ijjhati. (Visuddhi 1,302.)

**EN**
Tasmiṃ appanāppattacittasseva samijjhatīti veditabbaṃ. (Visuddhimagga I, 302.) [Transcription to be checked.]

**VI**
Tasmiṃ pana anuppanne sattādīnaṃ pharaṇaṃ sampajjati.

**EN**
Understand that this succeeds only in one whose mind has reached absorption.

**VI**
Trước khi phá bỏ ranh giới giữa bản thân, người thân ái, người trung tính và người thù nghịch, việc trải tâm từ theo các cách “tất cả chúng sinh” v.v. chưa được thành tựu. Vì vậy chỉ sau khi đạt sīmāsambheda mới nên tu tập các cách trải tâm từ không giới hạn và có giới hạn dưới đây. (Visuddhi 1,302.)

**EN**
The modes of development listed above, beginning with unspecified pervasion, become fully established only in one who has broken down the barriers between oneself, a dear person, a neutral person, and an enemy, and has attained absorption in loving-kindness with dear, neutral, and hostile persons as objects. (Visuddhimagga I, 302.)

**VI**
Người đã phá bỏ ranh giới giữa các hạng người mới có thể thành tựu việc tu tập với những đối tượng tập thể “sabbe sattā averā hontu — mong tất cả chúng sinh không có hiểm nguy” v.v.

**EN**
Those wishing to develop loving-kindness with such formulas as “Sabbe sattā averā hontu—may all beings be free from enmity” should carefully bear this rule in mind and practise accordingly.

**VI**
Năm cách trải tâm từ giải thoát không giới hạn

**EN**
Five modes of unspecified pervasion

**VI**
Không phân chia đối tượng thành những nhóm giới hạn, hành giả trải tâm từ theo năm cách:

**EN**
There are five ways of pervading with the liberation of mind through loving-kindness without delimiting the group intended.

**VI**
1. Sabbe sattā — tất cả chúng sinh, những hữu tình bị tham ái trói buộc trong năm uẩn…

**EN**
1. Sabbe sattā—all beings, so called because they cling to the five aggregates.


<a id="M02-body-P103"></a>
## Năm nhóm không giới hạn — Bảy nhóm có giới hạn / Groups for unspecified and specified pervasion
Miến / Burmese 103

**VI**
2. Sabbe pāṇā — tất cả sinh vật, những hữu tình có hơi thở ra vào.
3. Sabbe bhūtā — tất cả hữu tình đã sinh thành, hiện hữu do các uẩn được sinh khởi bởi nghiệp và phiền não.
4. Sabbe puggalā — tất cả cá thể, những hữu tình đi đến địa ngục gọi là “puṃ” [CHƯA XÁC MINH: chi tiết giải từ puggalā trong dòng Miến cần kiểm chuyên môn].
5. Sabbe attabhāvapariyāpannā — tất cả hữu tình có tự thể, những hữu tình có thân năm uẩn.

**EN**
2. Sabbe pāṇā—all breathing beings.
3. Sabbe bhūtā—all beings who have come into existence through kamma and defilements.
4. Sabbe puggalā—all persons, beings subject to falling away and rebirth.
5. Sabbe attabhāvapariyāpannā—all beings included in an individual existence, that is, in a body taken as self.

**VI**
Bảy cách trải tâm từ giải thoát có giới hạn

**EN**
Seven modes of specified pervasion

**VI**
Có phân biệt đối tượng thành các nhóm giới hạn, hành giả trải tâm từ theo bảy cách:

**EN**
There are seven ways of pervading with the liberation of mind through loving-kindness by delimiting the group intended.

**VI**
1. Sabbā itthiyo — tất cả người nữ.
2. Sabbe purisā — tất cả người nam.
3. Sabbe ariyā — tất cả bậc Thánh.
4. Sabbe anariyā — tất cả người chưa phải bậc Thánh, các phàm phu.
5. Sabbe devā — tất cả chư thiên.
6. Sabbe manussā — tất cả loài người.
7. Sabbe vinipātikā — tất cả chúng sinh trong các đọa xứ.

**EN**
1. Sabbā itthiyo—all women.
2. Sabbe purisā—all men.
3. Sabbe ariyā—all noble persons.
4. Sabbe anariyā—all who are not noble persons.
5. Sabbe devā—all deities.
6. Sabbe manussā—all human beings.
7. Sabbe vinipātikā—all beings in the states of deprivation.


<a id="M02-body-P104"></a>
## Cách thực hành trải tâm từ theo nhóm / The forty-eight ways of developing loving-kindness
Miến / Burmese 104

**VI**
Trước hết, nhập lại tứ thiền đã thành tựu. Tu tập lại tâm từ với bản thân, người thân ái, người trung tính và người thù nghịch cho đến khi tâm từ bình đẳng, ranh giới được phá bỏ, theo phương pháp đã trình bày. Sau đó, trong phạm vi ngôi chùa hay nhà mình đang ở, hãy hướng tâm đến tất cả chúng sinh, làm cho họ hiện rõ trong ánh sáng của định. Khi tâm từ đã mạnh, ánh sáng do tâm tu tập sinh ra rực rỡ, sáng trong, tỏa rộng.

**EN**
First re-establish concentration up to the fourth jhāna on the white kasiṇa. As explained above, repeatedly enter mettā jhāna, making loving-kindness equal towards yourself, a dear person, a neutral person, and an enemy. When loving-kindness has become equal and the barriers are gone, bring to mind all the beings within a monastery compound or a house and its grounds, as far as you are able. At that time the light arising from the mind engaged in tranquillity meditation through loving-kindness will shine brilliantly.

**VI**
Nhờ ánh sáng ấy, lấy toàn thể chúng sinh trong phạm vi đã định làm cảnh, rồi trải tâm từ đến tất cả họ. Đừng phân biệt người này với người kia. Bằng cách này, lần lượt tu tập năm cách trải tâm từ không giới hạn và bảy cách trải tâm từ có giới hạn. Mỗi nhóm lại có bốn lời nguyện, thành 12 × 4 =48 cách tu tập.

**EN**
With the help of that light, take all beings within the area you have marked out as your object, seeing them clearly in the light. Then develop the five modes of unspecified pervasion and the seven modes of specified pervasion, twelve groups in all. There are four wishes for each group, making forty-eight ways of developing loving-kindness.

**VI**
Ví dụ:

**EN**
For example:

**VI**
1. Sabbe sattā:
(a) Averā hontu.
(b) Abyāpajjā hontu.
(c) Anīghā hontu.
(d) Sukhī attānaṃ pariharantu.

**EN**
1. Sabbe sattā:
(a) Averā hontu.
(b) Abyāpajjā hontu.
(c) Anīghā hontu.
(d) Sukhī attānaṃ pariharantu.


<a id="M02-body-P105"></a>
## Bốn lời nguyện cho tất cả chúng sinh / Practising each of the four wishes
Miến / Burmese 105

**VI**
1. Mong tất cả chúng sinh, những hữu tình bị tham ái trói buộc trong năm uẩn:

**EN**
1. May all beings who cling to the five aggregates:

**VI**
(a) Không có hiểm nguy, thù nghịch. Hãy tu tập cho đến tam thiền.
(b) Không có khổ tâm. Hãy tu tập cho đến tam thiền.
(c) Không có khổ thân. Hãy tu tập cho đến tam thiền.
(d) Được khỏe mạnh, an vui, tự gìn giữ bản thân. Hãy tu tập cho đến tam thiền.

**EN**
(a) Be free from enmity and danger. Develop this to the third jhāna.
(b) Be free from mental suffering. Develop this to the third jhāna.
(c) Be free from bodily suffering. Develop this to the third jhāna.
(d) Look after themselves happily and in good health. Develop this to the third jhāna.

**VI**
Mỗi lời nguyện đều cần tu tập đến tam thiền. Trong lúc tu tập, tất cả chúng sinh đang được lấy làm đối tượng phải hiện rõ trong ánh sáng của định. Khi đã thành công, chuyển sang “sabbe pāṇā — tất cả sinh vật”, rồi tu tập bốn lời nguyện, mỗi lời đến tam thiền. Tiếp theo “sabbe bhūtā — tất cả hữu tình đã sinh thành”, cũng tu tập bốn lời nguyện đến tam thiền.

**EN**
In developing these four wishes, attain the third jhāna with each. See all the beings who are the object of mettā jhāna clearly in the light of knowledge. When you succeed, do the same with “sabbe pāṇā,” reaching the third jhāna with each of the four wishes.

**VI**
Cùng ý nghĩa như vậy, lần lượt chuyển qua “sabbe puggalā — tất cả cá thể”, “sabbe attabhāvapariyāpannā — tất cả hữu tình có tự thể”. Rồi tu tập theo bảy nhóm có giới hạn: tất cả người nữ, người nam, bậc Thánh, phàm phu, chư thiên, loài người và chúng sinh đọa xứ. Mỗi nhóm đều phải được biết rõ trong ánh sáng của định; với mỗi nhóm, phát triển từng lời nguyện đến tam thiền. Đó là 48 cách tu tập. Hãy luyện cho thuần thục…

**EN**
Continue with the four wishes for the remaining groups, beginning with “sabbe bhūtā.” When developing “sabbā itthiyo,” see all the women within the area you have marked out in the light. With “sabbe purisā,” see all the men. With “sabbe devā,” see all the deities in the area. With “sabbe manussā,” see all the human beings. With “sabbe vinipātikā,” encompass all the beings in states of deprivation within that area, as far as your knowledge permits. Practise these forty-eight ways repeatedly.


<a id="M02-body-P106"></a>
## Mười phương trải tâm từ giải thoát / Extending loving-kindness in the ten directions
Miến / Burmese 106

**VI**
…Khi đã tu tập thành công trong phạm vi chùa hay nhà ở, hãy lần lượt mở rộng phạm vi: cả chùa, cả làng, cả thị trấn, cả thành phố, cả quốc gia, rồi một thế giới; tiếp tục mở rộng từng phần cho đến vô lượng thế giới. Trong mỗi phạm vi, tu tập 48 cách trên cho thuần thục. Khi đã mở rộng vô biên, tiếp tục mười cách trải tâm từ giải thoát theo phương hướng.

**EN**
Once you succeed within a monastery compound or a house and its grounds, gradually extend mettā jhāna. Develop the forty-eight ways throughout the whole monastery, then throughout two monasteries, and so on. Practise the forty-eight ways over a village, a township, two townships, a region, two regions, a whole country, a whole world system, and all thirty-one planes, extending the range gradually. Once successful, extend the forty-eight ways throughout countless world systems. Then proceed to the ten modes of directional pervasion.

**VI**
Mười cách trải tâm từ giải thoát theo phương hướng

**EN**
Ten modes of directional pervasion

**VI**
Mười cách trải tâm từ giải thoát, disāpharaṇā mettā cetovimutti, là trải khắp mười phương:

**EN**
The liberation of mind through loving-kindness may be spread in ten directions as follows.

**VI**
1. Phương đông:48 cách.
2. Phương tây:48 cách.
3. Phương nam:48 cách.
4. Phương bắc:48 cách.
5. Phương đông nam:48 cách.
6. Phương tây nam:48 cách.
7. Phương tây bắc:48 cách.
8. Phương đông bắc:48 cách.
9. Phương trên:48 cách.
10. Phương dưới:48 cách.

**EN**
1. East: forty-eight ways.
2. West: forty-eight ways.
3. South: forty-eight ways.
4. North: forty-eight ways.
5. Southeast: forty-eight ways.
6. Southwest: forty-eight ways.
7. Northwest: forty-eight ways.
8. Northeast: forty-eight ways.
9. Above: forty-eight ways.
10. Below: forty-eight ways.


<a id="M02-body-P107"></a>
## Năm trăm hai mươi tám cách trải tâm từ / The 528 ways of pervading with loving-kindness
Miến / Burmese 107

**VI**
Tính chung mười phương có 10 × 48 = 480 cách. Cộng với 48 cách trải tâm từ đã tu tập ở trên, lấy tất cả chúng sinh trong vô lượng thế giới làm cảnh, thì có 528 cách trải tâm từ.

**EN**
The ten directions give 10 × 48 = 480 ways. Add these to the forty-eight ways already developed towards all beings throughout countless world systems. Together they make 528 ways of developing loving-kindness.

**VI**
Khi tu tập tâm từ giải thoát theo phương hướng, trước hết hãy lấy tất cả chúng sinh ở phương đông cho đến vô lượng thế giới làm cảnh. Khi thấy họ trong ánh sáng của định, hãy tu tập 48 cách trải tâm từ. Cũng tu tập như vậy đối với phương tây và các phương còn lại. Khi thành công, có thể tiếp tục tu tập theo những cách trải tâm từ được nêu trong các kinh về tâm từ. Khi đã tu tập có hệ thống 528 cách trải tâm từ như vậy, vị thiện nhân sẽ tự biết đề mục tâm từ của mình phù hợp với lời dạy sau đây của Đức Phật và mình đang tu tập theo ý Ngài.

**EN**
To practise directional pervasion, take as object all beings to the east, extending as far as countless world systems. When you see them in the light, develop the forty-eight ways of loving-kindness. Do likewise towards the west and in the remaining directions. Once successful, you can continue with the methods given in the Mettā Sutta and elsewhere. When you can practise the 528 ways systematically, you can know for yourself that your practice accords with the following teaching of the Buddha.

**VI**
So mettāsahagatena cetasā ekaṃ disaṃ pharitvā viharati. Tathā dutiyaṃ, tathā tatiyaṃ, tathā catutthaṃ. Iti uddhamadho tiriyaṃ sabbadhi sabbattatāya sabbāvantaṃ lokaṃ mettāsahagatena cetasā vipulena mahaggatena appamāṇena averena abyāpajjena pharitvā viharati. (Dī 1,234.)

**EN**
So mettāsahagatena cetasā ekaṃ disaṃ pharitvā viharati. Tathā dutiyaṃ, tathā tatiyaṃ, tathā catutthaṃ. Iti uddhamadho tiriyaṃ sabbadhi sabbattatāya sabbāvantaṃ lokaṃ mettāsahagatena cetasā vipulena mahaggatena appamāṇena averena abyāpajjena pharitvā viharati. (Dī 1,234.)

**VI**
Hành giả an trú, trải tâm câu hữu với từ khắp một phương. Cũng vậy, vị ấy trải khắp phương thứ hai, phương thứ ba và phương thứ tư…

**EN**
The meditator dwells pervading one direction with a mind imbued with loving-kindness. In the same way the meditator pervades the second, third, and fourth directions…


<a id="M02-body-P108"></a>
## Mười một lợi ích của tâm từ / The eleven benefits of loving-kindness
Miến / Burmese 108

**VI**
…Cũng theo cách ấy, vị ấy trải tâm câu hữu với từ đến tất cả chúng sinh ở mọi phương, trên, dưới và ngang, xem tất cả như chính mình. Vị ấy an trú, trải khắp thế giới gồm tất cả chúng sinh bằng tâm từ rộng lớn, cao cả, vô lượng, không thù nghịch, không oán hại. (Dī 1,234.)

**EN**
…and likewise above, below, and across, everywhere and in every respect. Regarding all beings as oneself, the meditator dwells pervading the whole world of beings with a mind imbued with loving-kindness, abundant, exalted, immeasurable, free from enmity and affliction. (Dīgha Nikāya 1, p. 234.)

**VI**
Mettāya, bhikkhave, cetovimuttiyā āsevitāya bhāvitāya bahulīkatāya yānīkatāya vatthukatāya anuṭṭhitāya paricitāya susamāraddhāya ekādasānisaṃsā pāṭikaṅkhā. Katame ekādasa? Sukhaṃ supati, sukhaṃ paṭibujjhati, na pāpakaṃ supinaṃ passati, manussānaṃ piyo hoti, amanussānaṃ piyo hoti, devatā rakkhanti, nāssa aggi vā visaṃ vā satthaṃ vā kamati, tuvaṭaṃ cittaṃ samādhiyati, mukhavaṇṇo vippasīdati, asammūḷho kālaṃ karoti, uttari appaṭivijjhanto brahmalokūpago hoti. (Aṅ 3,542.)

**EN**
Mettāya, bhikkhave, cetovimuttiyā āsevitāya bhāvitāya bahulīkatāya yānīkatāya vatthukatāya anuṭṭhitāya paricitāya susamāraddhāya ekādasānisaṃsā pāṭikaṅkhā. Katame ekādasa? Sukhaṃ supati, sukhaṃ paṭibujjhati, na pāpakaṃ supinaṃ passati, manussānaṃ piyo hoti, amanussānaṃ piyo hoti, devatā rakkhanti, nāssa aggi vā visaṃ vā satthaṃ vā kamati, tuvaṭaṃ cittaṃ samādhiyati, mukhavaṇṇo vippasīdati, asammūḷho kālaṃ karoti, uttari appaṭivijjhanto brahmalokūpago hoti. (Aṅ 3,542.)

**VI**
Này các tỳ-khưu, tâm từ được gọi là tâm giải thoát vì thoát khỏi pháp đối nghịch. Khi tâm từ giải thoát đã được thực hành, được phát triển, được làm cho sung mãn, được dùng như cỗ xe, được làm thành nền tảng, được duy trì, được luyện tập thành thạo và được khéo thực hiện, có thể mong đợi mười một lợi ích. Mười một lợi ích ấy là gì?

**EN**
Bhikkhus, when the liberation of mind through loving-kindness, so called because it is freed from opposing states, has been cultivated, developed, practised repeatedly, made a vehicle and a foundation, maintained, consolidated, and well undertaken, eleven benefits can be expected. What eleven?


<a id="M02-body-P109"></a>
## Mười một lợi ích được kể riêng / The benefits of practising loving-kindness
Miến / Burmese 109

**VI**
1. Ngủ an vui.
2. Thức dậy an vui.
3. Không thấy ác mộng.
4. Được loài người yêu mến.
5. Được các loài phi nhân yêu mến.
6. Được chư thiên bảo hộ.
7. Lửa, thuốc độc và vũ khí không thể làm hại người tu tập tâm từ.
8. Tâm tu tập mau an trú vững chắc, dễ đạt định.
9. Sắc mặt trong sáng.
10. Khi chết, tâm không mê loạn.
11. Nếu chưa thấu đạt pháp cao hơn là A-la-hán quả, vị ấy đi đến cõi Phạm thiên. (Aṅ 3,542.)

**EN**
1. One sleeps at ease.
2. One wakes at ease.
3. One has no bad dreams.
4. One is dear to human beings.
5. One is dear to non-human beings.
6. Deities protect one.
7. Fire, poison, and weapons do not harm one.
8. The mind becomes concentrated quickly.
9. One's complexion is clear.
10. One dies unconfused.
11. If one penetrates no higher to arahant fruition, one is reborn in the Brahmā world. (Aṅguttara Nikāya 3, p. 542.)

**VI**
Ngủ yên, thức dậy an vui, không gặp ác mộng. Người và phi nhân yêu mến, chư thiên gìn giữ. Độc, vũ khí và lửa không hại. Tâm mau an định, sắc mặt trong sáng. Khi chết không mê loạn, đi đến Phạm thiên giới. Đó là mười một lợi ích. Hãy ghi nhớ tâm từ, pháp có những lợi ích rõ ràng ấy, và thực hành hằng ngày. (Kệ Miến của ngài Pyay Sayadaw, bản dẫn giải Visuddhimagga, tập 2, tr. 332.)

**EN**
Sleep and waking are peaceful, dreams are free from evil, one is dear to others and guarded by deities, fire and poison do not harm one, the mind settles, the face is clear, death comes without confusion, and one goes to the Brahmā world. These eleven benefits follow the cultivation of loving-kindness. It is a practice for monastics and laypeople alike. (Pyay Sayadaw, Burmese explanation of the Visuddhimagga, vol. 2, p. 332.)


<a id="M02-body-P110"></a>
## Tu tập tâm bi (karuṇābhāvanā) / Developing compassion
Miến / Burmese 110

**VI**
Hành giả muốn tu tập tâm bi trước hết hãy chọn một chúng sinh đang chịu khổ, ở gần mình, cùng giới tính và còn sống. Hãy suy xét nỗi khổ của người ấy và tác ý cho lòng bi mẫn hiện rõ, tăng trưởng.

**EN**
To develop compassion (karuṇā), first choose a living being of the same sex, near to you, who is suffering. Consider that person's suffering and attend to it in a way that brings forth compassion.

**VI**
Sau đó an lập lại tứ thiền kasiṇa trắng hoặc kasiṇa ánh sáng. Khi sức ánh sáng mạnh, hãy dùng ánh sáng ấy để thấy người đang khổ mà mình đã chọn. Khi thấy rõ bằng tuệ, nếu muốn, hãy lấy người ấy làm cảnh và nhập thiền tâm từ. Nếu nhập thiền tâm từ, hãy xuất khỏi thiền ấy rồi tu tập tâm bi. Nếu muốn tu tập trực tiếp thì có thể tu tập tâm bi ngay, không cần nhập thiền tâm từ. Hãy lấy chính người đang khổ ấy làm cảnh:

**EN**
Re-establish the fourth jhāna on the white or light kasiṇa. When the light grows strong, use it to see the suffering person you have chosen. When the person appears as clearly as if illuminated by a torch, take them as object. You may first enter mettā jhāna and then emerge to develop compassion, or you may develop compassion directly. In either case take that suffering person as object.

**VI**
Ayaṃ sappuriso dukkhā muccatu …
Mong người thiện này thoát khỏi khổ …

**EN**
Ayaṃ sappuriso dukkhā muccatu…
May this good person be freed from suffering…

**VI**
Hãy tu tập tâm bi nhiều lần như vậy, cho đến tam thiền, và luyện thành thạo năm pháp tự tại ở mỗi tầng thiền. Tiếp tục chọn từng người đang chịu khổ, cùng giới tính, lần lượt khoảng bốn, năm hay mười người. Tu tập như vậy đến tam thiền trên từng người. Sau đó theo thứ tự đã trình bày ở đề mục tâm từ, tu tập tâm bi đối với người thân ái, người trung tính và người thù nghịch, mỗi người cho đến tam thiền.

**EN**
Develop compassion repeatedly in this way up to the third jhāna and gain the five masteries in each jhāna. Then take four, five, or about ten suffering people of the same sex, one by one, and develop compassion towards each up to the third jhāna. Then, in the order explained for loving-kindness, develop compassion up to the third jhāna towards a dear person, a neutral person, and an enemy.


<a id="M02-body-P111"></a>
## Trải tâm bi sau khi phá bỏ ranh giới / Extending compassion to all beings
Miến / Burmese 111

**VI**
Tất cả phàm phu đều đáng được thương xót vì chưa thoát khỏi hiểm họa lớn là các đọa xứ. Do những nghiệp bất thiện đã tích lũy từ các đời trong luân hồi cho đến nay, chừng nào chưa thoát khỏi hiểm họa đọa xứ, họ vẫn có thể phải chịu khổ ở đó một ngày nào đó. Vì vậy tất cả phàm phu đều đáng được thương xót. Mỗi chúng sinh phàm phu chưa thoát khỏi hiểm họa lớn là già, bệnh và chết đều là đối tượng đáng thương xót. Hãy dùng tuệ suy xét tình trạng đáng thương ấy và lấy đó làm cảnh để tu tập tâm bi đối với mọi chúng sinh.

**EN**
All ordinary persons are worthy of compassion because they have yet to escape the danger of the states of deprivation. Until they escape that danger, they may one day experience suffering there as a result of misconduct committed in the long course of saṃsāra. All beings, ordinary or noble, are worthy of compassion insofar as they have yet to escape the dangers of ageing, illness, and death. By wisely reflecting on these grounds, compassion can also be developed towards those who are presently happy.

**VI**
Khi đã thành công, hãy làm cho tâm bi bình đẳng đối với bản thân, người thân ái, người trung tính và người thù nghịch, như đã trình bày ở phần tâm từ. Khi đã phá bỏ ranh giới (sīmāsambheda), hãy giữ lấy tướng chế định về chúng sinh ấy, tu tập và làm cho sung mãn nhiều lần để các thiền tâm bi lần lượt sinh khởi đến sơ thiền, nhị thiền và tam thiền. Sau đó tiếp tục trải tâm bi không giới hạn, có giới hạn và theo phương hướng.

**EN**
When successful, break down the barriers between oneself, a dear person, a neutral person, and an enemy as explained for loving-kindness. Repeatedly apprehend, develop, and practise with the resulting conceptual sign of beings, strengthening absorption in compassion through the first, second, and third jhānas. Then develop compassion by unspecified, specified, and directional pervasion.

**VI**
Trải tâm bi đến tất cả chúng sinh trong vô lượng thế giới:
1. Tu tập tâm bi không giới hạn (anodhisopharaṇā): 5 cách.
2. Tu tập tâm bi có giới hạn (odhisopharaṇā): 7 cách.
3. Tu tập tâm bi theo phương hướng (disāpharaṇā): 10 × 12 = 120 cách.
Tính chung có 132 cách tu tập tâm bi.

**EN**
Pervading all beings throughout countless world systems, develop: (1) five modes of unspecified compassion, (2) seven modes of specified compassion, and (3) 120 modes of directional compassion (10 × 12). There are 132 ways of developing compassion in all.


<a id="M02-body-P112"></a>
## Tu tập tâm hỷ (muditābhāvanā) / Developing appreciative joy
Miến / Burmese 112

**VI**
Hành giả muốn tu tập tâm hỷ trước hết hãy chọn một người đang hưng thịnh, an vui. Người ấy nên là một người bạn thân mà mình yêu quý, cùng giới tính, còn sống, và là người khi gặp có thể làm mình vui mừng nhiều nhất.

**EN**
To develop appreciative joy (muditā), first choose someone who is prospering and happy. Let that person be a very dear friend or companion, alive and of the same sex, someone whose very appearance brings you much joy and gladness.

**VI**
Hãy an lập lại tứ thiền kasiṇa trắng hoặc kasiṇa ánh sáng. Khi sức ánh sáng mạnh, hướng tâm đến người an vui đã chọn. Khi thấy người ấy rõ như vật đặt trong lòng bàn tay, nếu muốn, hãy lấy họ làm cảnh, nhập lại thiền tâm từ rồi nhập thiền tâm bi. Cũng có thể tu tập tâm hỷ trực tiếp. Sau khi xuất khỏi các thiền tâm từ và tâm bi, hoặc khi bắt đầu tu tập tâm hỷ trực tiếp, hãy lấy chính người đã chọn làm cảnh:

**EN**
Re-establish fourth jhāna on the white or light kasiṇa. When the light becomes strong, bring to mind the happy person you selected. When you see them as clearly as if by torchlight, you may take them as object and enter mettā jhāna, then enter compassion jhāna. You may also proceed directly to appreciative joy. If you first develop loving-kindness and compassion, emerge from those attainments. Whether proceeding from them or starting directly, take the person you selected as object.

**VI**
Ayaṃ sappuriso yathāladdhasampattito mā vigacchatu …
Mong người thiện này không mất sự hưng thịnh và an vui đã đạt được …

**EN**
Ayaṃ sappuriso yathāladdhasampattito mā vigacchatu…
May this good person not lose the prosperity and happiness they have gained…

**VI**
Hãy tu tập đề mục tâm hỷ như vậy, lặp đi lặp lại cho đến tam thiền. Các định đã tu tập trước có thể trợ giúp mạnh mẽ bằng cận y duyên…

**EN**
Practise appreciative joy in this way. Develop it repeatedly up to the third jhāna. Earlier meditative concentration supports this development as a powerful decisive condition…


<a id="M02-body-P113"></a>
## Trải tâm hỷ theo 132 cách / Extending appreciative joy
Miến / Burmese 113

**VI**
…Nhờ sức trợ giúp đặc biệt ấy, việc tu tập tâm hỷ sẽ dễ dàng, thuận lợi. Có thể lấy hình ảnh người ấy khi được an vui trong quá khứ, hiện đang an vui hoặc sẽ an vui trong tương lai làm cảnh. Ở đây nói quá khứ và tương lai của người hiện còn sống, trong chính đời này.

**EN**
…The special strength received from that support makes appreciative joy easy to develop. You can take as object the person's appearance when happy in the past, when happy at present, or as they will be when happy in the future. Here past and future refer to times in the present life of someone still alive.

**VI**
Tiếp tục tu tập tâm hỷ theo cách trên với khoảng mười người đang an vui, cùng giới tính, đáng yêu quý. Rồi lần lượt tu tập tâm hỷ với người thân ái, người trung tính và người thù nghịch. Hãy tinh cần cho đến tam thiền, làm tăng trưởng an chỉ thiền của tâm hỷ. Hãy làm cho tâm hỷ đối với bản thân, người thân ái, người trung tính và người thù nghịch được bình đẳng để phá bỏ ranh giới giữa các hạng người. Khi đã phá bỏ ranh giới, hãy nắm giữ tướng chế định về chúng sinh ấy, tu tập nhiều lần cho an chỉ của tâm hỷ tăng trưởng. Sau đó lấy vô lượng chúng sinh trong vô lượng thế giới làm cảnh:

**EN**
Continue in the same way with about ten happy beings of the same sex whom you love and esteem. Then develop appreciative joy towards a dear person, a neutral person, and an enemy in order. Attain the third jhāna and strengthen absorption. Make appreciative joy equal towards oneself, a dear person, a neutral person, and an enemy, breaking down the barriers. Repeatedly apprehend and develop the resulting conceptual sign of beings to strengthen absorption in appreciative joy. Then take the countless beings in countless world systems as object.

**VI**
1. Tu tập tâm hỷ không giới hạn (anodhisopharaṇā): 5 cách.
2. Tu tập tâm hỷ có giới hạn (odhisopharaṇā): 7 cách.
3. Tu tập tâm hỷ theo phương hướng (disāpharaṇā): 10 × 12 = 120 cách.
Tính chung có 132 cách tu tập tâm hỷ.

**EN**
1. Five modes of unspecified pervasion.
2. Seven modes of specified pervasion.
3. 120 modes of directional pervasion (10 × 12).
In all there are 132 ways of developing appreciative joy.

**VI**
Hãy tiếp tục tu tập các cách trải tâm hỷ ấy. Vận dụng các điểm và phương pháp đã trình bày trong phần tu tập tâm từ.

**EN**
Continue developing these ways of appreciative joy. Apply the relevant details already given in the section on loving-kindness.


<a id="M02-body-P114"></a>
## Tu tập tâm xả (upekkhābhāvanā) / Developing equanimity
Miến / Burmese 114

**VI**
Hành giả muốn tu tập phạm trú xả trước hết hãy:

**EN**
A meditator who wishes to develop equanimity (upekkhā) as a divine abiding should proceed as follows.

**VI**
1. An lập lại tứ thiền kasiṇa trắng hoặc kasiṇa ánh sáng. Khi sức ánh sáng mạnh…
2. Lấy một người trung tính, không thân không ghét, cùng giới tính và còn sống làm cảnh. Tu tập đề mục tâm từ đến tam thiền.
3. Lấy chính người ấy làm cảnh, tu tập đề mục tâm bi đến tam thiền.
4. Lấy chính người ấy làm cảnh, tu tập đề mục tâm hỷ đến tam thiền.

**EN**
1. Re-establish the fourth jhāna on the white or light kasiṇa. When the light becomes strong, proceed as below.
2. Take as object a living person of the same sex who is neutral, neither loved nor disliked. Develop loving-kindness up to the third jhāna.
3. With the same person as object, develop compassion up to the third jhāna.
4. With that very person as object, develop appreciative joy up to the third jhāna.

**VI**
Sau khi đã đạt tam thiền trên từng đề mục tâm từ, tâm bi và tâm hỷ với cùng một người trung tính, hãy nhập lại các tầng thiền đã luyện thuần thục theo thứ tự. Xuất khỏi tam thiền phạm trú hỷ, rồi suy xét:

**EN**
Having obtained the third jhāna on each of these three divine abidings with a neutral person as object, enter them in order as thoroughly practised. Emerge from the third jhāna of appreciative joy and consider the following.

**VI**
1. Sukhitā hontu — mong chúng sinh được an vui. Với cách tác ý như vậy, tu tập đề mục tâm từ cho đến tam thiền phạm trú từ, vì tam thiền ấy đi cùng sự tác ý yêu mến, quan tâm đến chúng sinh…

**EN**
1. Sukhitā hontu—may beings be happy. In developing loving-kindness up to the third jhāna with this and similar wishes, attention is coloured by concern for the beings who are its object.


<a id="M02-body-P115"></a>
## Thấy sự tịch tịnh của phạm trú xả / Seeing the advantages of equanimity
Miến / Burmese 115

**VI**
2. Dukkhā muccantu — mong chúng sinh thoát khỏi khổ. Với cách tác ý như vậy, tu tập phạm trú bi cho đến tam thiền. Tầng thiền ấy còn gần với sự đau buồn do khổ.
3. Yathāladdhasampattito mā vigacchantu — mong chúng sinh không mất sự hưng thịnh và an vui đã đạt được. Với cách tác ý như vậy, tu tập phạm trú hỷ cho đến tam thiền. Tầng thiền ấy còn thô vì đi cùng niềm vui và thọ hỷ.

**EN**
2. Dukkhā muccantu—may beings be freed from suffering. In developing compassion up to the third jhāna in this way, the attainment remains close to the distinction between those one dislikes and those one loves.
3. Yathāladdhasampattito mā vigacchantu—may beings not lose the prosperity they have gained. In developing appreciative joy up to the third jhāna in this way, that jhāna is accompanied by gladness and is therefore comparatively gross.

**VI**
Hãy thấy các khuyết điểm của tam thiền phạm trú từ, bi và hỷ như vậy, và thấy lợi ích của tứ thiền phạm trú xả do sự tịch tịnh của nó. Hãy lấy một người trung tính đã quen làm đối tượng, tức người đã được dùng làm cảnh để tu tập tâm từ, tâm bi và tâm hỷ đến tam thiền. Đối với người không thân không ghét ấy, hãy khởi tâm xả một cách tự nhiên.

**EN**
See these drawbacks in the third jhānas of loving-kindness, compassion, and appreciative joy. See the benefit of the peaceful nature of the fourth jhāna of equanimity.

**VI**
Cách tu tập là lấy chính người trung tính ấy làm cảnh, nhập tam thiền tâm từ, tam thiền tâm bi rồi tam thiền tâm hỷ. Sau khi xuất thiền, hãy suy xét như trên, hoặc suy xét về người thiện ấy như sau…

**EN**
Take the neutral person already used for the three preceding jhānas, someone towards whom you can naturally be impartial. Enter the third jhānas of loving-kindness, compassion, and appreciative joy on that same person and then reflect as above, or reflect as follows.


<a id="M02-body-P116"></a>
## Chúng sinh có nghiệp là của mình / Beings are owners of their kamma
Miến / Burmese 116

**VI**
1. Dù tu tập tâm từ với lời nguyện người ấy không có hiểm nguy, người ấy chỉ thoát hiểm nguy khi đủ duyên để thoát. Dù tu tập tâm từ với lời nguyện người ấy không có khổ tâm, người ấy chỉ thoát khổ tâm khi đủ duyên để thoát. Dù tu tập tâm từ với lời nguyện người ấy không có khổ thân, người ấy chỉ thoát khổ thân khi đủ duyên để thoát. Dù tu tập tâm từ với lời nguyện người ấy được khỏe mạnh, an vui và tự gìn giữ bản thân, người ấy chỉ có thể sống như vậy khi đủ duyên.
2. Dù tu tập tâm bi với lời nguyện người ấy thoát khổ, người ấy chỉ thoát khổ khi đủ duyên để thoát.
3. Dù tu tập tâm hỷ với lời nguyện người ấy không mất sự hưng thịnh và an vui đã đạt được, người ấy chỉ giữ được sự hưng thịnh và an vui ấy khi đủ duyên để giữ.
4. Vì sao? Tất cả chúng sinh đều chỉ có nghiệp là tài sản riêng của mình. Hãy suy xét như vậy.

**EN**
1. Even when you develop loving-kindness wishing that the person be free from danger, mental suffering, and bodily suffering, and that they look after themselves happily and in good health, those wishes will come about only if conditions allow.
2. Even when you develop compassion wishing that the person be freed from suffering, they will be freed only if conditions allow.
3. Even when you develop appreciative joy wishing that the person not lose the prosperity already gained, it will remain only if conditions allow.
4. Why? Reflect that all beings have kamma as their own possession.

**VI**
Ayaṃ sappuriso kammassako.
Người thiện này có nghiệp là của mình.

**EN**
Ayaṃ sappuriso kammassako.
This good person is the owner of their kamma.

**VI**
Hãy tu tập tâm xả lặp đi lặp lại như vậy. Khi dựa trên tam thiền phạm trú từ, bi và hỷ để tiến đến phạm trú xả, các định tu tập trước trợ giúp bằng cận y duyên mạnh. Do năng lực trợ giúp ấy, việc tu tập phạm trú xả sau đó có thể đạt tứ thiền trong thời gian ngắn.

**EN**
Develop equanimity repeatedly in this way. Because you have advanced to this divine abiding on the basis of the third jhānas of loving-kindness, compassion, and appreciative joy, the earlier concentration lends its strength as a powerful decisive support. With this special strength, the subsequent development of equanimity can reach the fourth jhāna before long.


<a id="M02-body-P117"></a>
## Nền tảng để đạt tứ thiền phạm trú xả / Practising equanimity with different people
Miến / Burmese 117

**VI**
Khi đã thành công, hãy lần lượt lấy khoảng mười người trung tính làm cảnh và tiếp tục tu tập bốn phạm trú từ, bi, hỷ, xả. Đối với từng người, tu tập tâm từ đến tam thiền, tâm bi đến tam thiền, tâm hỷ đến tam thiền, rồi lấy chính người ấy làm cảnh để tu tập tâm xả đến tứ thiền. Hãy nhớ rằng phạm trú xả chỉ có tứ thiền. Phạm trú xả không có sơ thiền, nhị thiền hay tam thiền. Tuy vậy, chỉ hành giả đã tu tập đến sơ thiền, nhị thiền, tam thiền trong từng phạm trú từ, bi và hỷ mới có thể tu tập đạt tứ thiền phạm trú xả. Dựa vào tam thiền niệm hơi thở hoặc tam thiền kasiṇa để tiến đến phạm trú xả thì không thể đạt tứ thiền phạm trú xả, vì đối tượng của các tam thiền ấy khác với chế định chúng sinh.

**EN**
When successful, take about ten neutral persons one by one and develop the four divine abidings towards each. Develop loving-kindness, compassion, and appreciative joy up to the third jhāna, then equanimity with the same person as object up to the fourth. The first, second, and third jhānas do not occur with this equanimity. Only the fourth occurs. It is attainable only after developing the first three jhānas separately in loving-kindness, compassion, and appreciative joy. If one tries to develop this equanimity based on the third jhāna of breathing or a kasiṇa, the fourth jhāna of equanimity cannot be reached because those attainments do not take the concept of a being as object.

**VI**
Khi đã tu tập thành công các phạm trú từ, bi, hỷ, xả theo thứ tự với nhiều người trung tính và đạt đến tứ thiền, hãy lần lượt chọn:
1. Khoảng mười người thân ái (piya).
2. Khoảng mười người rất thân ái (atippiya).
3. Khoảng mười người trung tính (majjhatta).
4. Khoảng mười người thù nghịch (verī), hoặc số người thù nghịch mình có…

**EN**
After succeeding with many neutral persons, developing the divine abidings in order up to the fourth jhāna, proceed to: (1) about ten dear persons, (2) about ten very dear persons, (3) about ten neutral persons, and (4) about ten enemies, or as many as there are…


<a id="M02-body-P118"></a>
## Tu tập bốn phạm trú trên từng đối tượng / Breaking down the barriers in equanimity
Miến / Burmese 118

**VI**
…Lấy từng người trong số ấy làm cảnh và tu tập các phạm trú từ, bi, hỷ, xả như vậy. Cần nhớ rằng muốn tu tập tâm xả đối với mỗi người thì phải lấy các thiền tâm từ, tâm bi và tâm hỷ đối với chính người ấy làm nền.

**EN**
…Take each of these persons individually and develop loving-kindness, compassion, appreciative joy, and equanimity in the same way. Remember that equanimity cannot be attained for an individual without first establishing the jhānas of loving-kindness, compassion, and appreciative joy for that individual.

**VI**
Sau đó, hãy tu tập để đạt thiền tâm từ, tâm bi, tâm hỷ và tâm xả như trên, sao cho tâm không còn phân chia ranh giới giữa bốn hạng: bản thân, người thân ái, người trung tính và người thù nghịch. Hãy phá bỏ ranh giới (sīmāsambheda) để sự phân biệt giữa các hạng người mất đi. Khi đã phá bỏ ranh giới, lấy chính tướng chế định chúng sinh ấy làm cảnh:

**EN**
Then develop the four divine abidings so that there are no barriers between oneself, a dear person, a neutral person, and an enemy. Break down these barriers. With the conceptual sign of beings obtained after breaking them down, develop the following.

**VI**
1. Tâm từ: sơ thiền, nhị thiền, tam thiền.
2. Tâm bi: sơ thiền, nhị thiền, tam thiền.
3. Tâm hỷ: sơ thiền, nhị thiền, tam thiền.
4. Tâm xả: tứ thiền.

**EN**
1. Loving-kindness: first, second, and third jhānas.
2. Compassion: first, second, and third jhānas.
3. Appreciative joy: first, second, and third jhānas.
4. Equanimity: fourth jhāna.

**VI**
Hãy nắm giữ, tu tập, làm cho sung mãn nhiều lần bốn phạm trú để đạt từng tầng thiền tương ứng. Tu tập tuần tự các phạm trú từ, bi, hỷ, xả như vậy chính là nỗ lực tu tập phạm trú xả. Sau khi phá bỏ ranh giới giữa các hạng người, hành giả lấy tướng chế định chúng sinh đã có làm cảnh, tiếp tục tu tập tâm xả nhiều lần. Bấy giờ tứ thiền phạm trú xả sinh khởi trong dòng tâm của hành giả. Sau đó…

**EN**
Apprehend, develop, and practise repeatedly with each divine abiding to attain its respective jhānas. Developing the four in this order is the way to develop the divine abiding of equanimity. After breaking down the barriers, the meditator who repeatedly takes the conceptual sign of beings as object and develops equanimity in this way attains the fourth jhāna of equanimity. Then proceed as follows.


<a id="M02-body-P119"></a>
## Một câu hỏi về tứ thiền phạm trú xả / The 132 ways of pervading with equanimity
Miến / Burmese 119

**VI**
1. Trải phạm trú xả không giới hạn: 5 cách.
2. Trải phạm trú xả có giới hạn: 7 cách.
3. Trải phạm trú xả theo phương hướng: 10 × 12 = 120 cách.
Tính chung có 132 cách tu tập phạm trú xả.

**EN**
1. Five modes of unspecified pervasion with equanimity.
2. Seven modes of specified pervasion with equanimity.
3. 120 modes of directional pervasion with equanimity (10 × 12).
In all there are 132 ways of developing equanimity.

**VI**
Hãy tiếp tục nỗ lực tu tập 132 cách ấy. Dù nói tu tập phạm trú xả, hành giả cần tu tập tuần tự từ, bi, hỷ và xả cho đến các tầng thiền tương ứng.

**EN**
Continue practising these 132 ways. Development of the divine abiding of equanimity involves cultivating loving-kindness, compassion, appreciative joy, and equanimity in order up to their respective jhānas.

**VI**
Hỏi: Tứ thiền phạm trú xả có thể sinh khởi nơi hành giả đã đạt tam thiền trên kasiṇa đất hoặc đề mục tương tự không?

**EN**
Question. Can the fourth jhāna of equanimity arise in a meditator who has attained the third jhāna on the earth kasiṇa or a similar subject?

**VI**
Đáp: Không thể. Vì sao? Tam thiền kasiṇa đất v.v. lấy kasiṇa đất v.v. làm cảnh. Tứ thiền phạm trú xả lấy chế định chúng sinh làm cảnh. Do bản chất của các cảnh khác nhau nên không thể tiến lên như vậy. Cảnh của sơ thiền, nhị thiền và tam thiền làm nền khác với cảnh của tứ thiền phạm trú xả. Chỉ nơi hành giả đã đạt tam thiền với các đề mục tâm từ, tâm bi và tâm hỷ thì tứ thiền phạm trú xả…

**EN**
Answer. It cannot. The third jhāna on the earth kasiṇa and similar subjects takes a kasiṇa as object, whereas the fourth jhāna of equanimity takes the concept of a being as object. The objects of the first three jhānas and that of the fourth would differ. The fourth jhāna of equanimity can arise only in a meditator who has attained the third jhānas of loving-kindness, compassion, and appreciative joy…


<a id="M02-body-P120"></a>
## Cùng lấy chế định chúng sinh làm cảnh / The object must be the same
Miến / Burmese 120

**VI**
…mới có thể sinh khởi, vì các thiền ấy có cùng bản chất về đối tượng là chế định chúng sinh. Nếu đã làm sinh khởi thiền tâm từ, tâm bi và tâm hỷ với một người thân ái, thì có thể làm sinh khởi thiền phạm trú xả đối với chính người ấy. Ý ở đây là cảnh của sơ thiền, nhị thiền, tam thiền và cảnh của tứ thiền phạm trú xả giống nhau về đối tượng. Cảnh của từng thiền từ, bi, hỷ, xả cùng là người thân ái, người trung tính hoặc người thù nghịch tương ứng. Nếu làm sinh khởi tam thiền tâm từ, tam thiền tâm bi và tam thiền tâm hỷ đối với tất cả chúng sinh, thì cũng có thể làm sinh khởi tứ thiền phạm trú xả đối với chính tất cả chúng sinh ấy. Các phạm trú có cùng đối tượng là chế định chúng sinh như vậy. (Xem Visuddhi 1,287–319.)

**EN**
…because they share the same kind of object, the concept of a being. Having developed the jhānas of loving-kindness, compassion, and appreciative joy towards a dear person, one can develop the jhāna of equanimity towards that same person. The object of the first, second, and third jhānas must be the same as that of the fourth jhāna of equanimity. Thus the jhānas of loving-kindness, compassion, appreciative joy, and equanimity share the same dear, neutral, or hostile person as their object. Likewise, when one has developed the third jhānas of loving-kindness, compassion, and appreciative joy towards all beings, one can develop the fourth jhāna of equanimity towards all those same beings. In this way the divine abidings share the concept of a being as their object. (See Visuddhimagga I, pp. 287–319.)


<a id="M02-body-P121"></a>
## Tâm từ: đặc tính, phận sự, biểu hiện và nhân gần / Characteristic, function, manifestation, and proximate cause of loving-kindness
Miến / Burmese 121

**VI**
1. Hitākārappavattilakkhaṇā mettā.
2. Hitūpasaṃhārarasā.
3. Āghātavinayapaccupaṭṭhānā.
4. Sattānaṃ manāpabhāvadassanapadaṭṭhānā.
Byāpādūpasamo etissā sampatti, sinehasambhavo vipatti. (Visuddhi 1,311.)

**EN**
1. Hitākārappavattilakkhaṇā mettā.
2. Hitūpasaṃhārarasā.
3. Āghātavinayapaccupaṭṭhānā.
4. Sattānaṃ manāpabhāvadassanapadaṭṭhānā.
Byāpādūpasamo etissā sampatti, sinehasambhavo vipatti. (Visuddhi 1,311.)

**VI**
1. Tâm từ có đặc tính vận hành theo hướng lợi ích của chúng sinh, hay làm phát sinh điều lợi ích.
2. Có phận sự đem lợi ích đến cho chúng sinh, hay có sự thành tựu là đem lợi ích đến cho chúng sinh.
3. Biểu hiện trước tuệ của hành giả là sự loại bỏ oán giận. Nói theo kết quả, tâm từ làm cho oán giận biến mất.
4. Nhân gần là tác ý đúng cách, thấy phương diện đáng mến của chúng sinh.

**EN**
1. Loving-kindness has the characteristic of proceeding in the mode of promoting the welfare of beings, or of bringing about that welfare.
2. Its function is to bring welfare to beings, or its accomplishment consists in bringing welfare to them.
3. It manifests to the meditator's discernment as the removal of resentment, or it brings about the disappearance of resentment.
4. Its proximate cause is wise attention that sees what is endearing in beings.

**VI**
Sự lắng dịu của ác ý (byāpāda), tức sân muốn làm hại, hủy hoại chúng sinh, là thành tựu của tâm từ. Khi sự quyến luyến do tham ái sinh khởi, đó là thất bại của tâm từ. (Visuddhi 1,311.)

**EN**
Its success is the subsiding of ill will, the desire to harm or destroy beings, through suppression by concentration. This is its proper accomplishment. When attachment and craving arise, loving-kindness has failed. (Visuddhimagga I, 311.)


<a id="M02-body-P122"></a>
## Tâm bi: đặc tính, phận sự, biểu hiện và nhân gần / Characteristic, function, manifestation, and proximate cause of compassion
Miến / Burmese 122

**VI**
1. Dukkhāpanayanākārappavattilakkhaṇā karuṇā.
2. Paradukkhāsahanarasā.
3. Avihiṃsāpaccupaṭṭhānā.
4. Dukkhābhibhūtānaṃ anāthabhāvadassanapadaṭṭhānā.
Vihiṃsūpasamo tassā sampatti, sokasambhavo vipatti. (Visuddhi 1,311.)

**EN**
1. Dukkhāpanayanākārappavattilakkhaṇā karuṇā.
2. Paradukkhāsahanarasā.
3. Avihiṃsāpaccupaṭṭhānā.
4. Dukkhābhibhūtānaṃ anāthabhāvadassanapadaṭṭhānā.
Vihiṃsūpasamo tassā sampatti, sokasambhavo vipatti. (Visuddhi 1,311.)

**VI**
1. Tâm bi có đặc tính vận hành theo hướng mong loại bỏ khổ đau của chúng sinh.
2. Có phận sự không đành lòng trước nỗi khổ của người khác, vì mong loại bỏ nỗi khổ ấy.
3. Làm phát sinh sự không làm hại chúng sinh. Đó là biểu hiện theo kết quả. Trước tuệ của hành giả, tâm bi hiện ra như pháp đối nghịch với sự hành hạ, bức hại chúng sinh. Đó là biểu hiện theo cách pháp ấy hiện rõ.
4. Nhân gần là tác ý đúng cách, thấy tình cảnh không nơi nương tựa của những chúng sinh đang bị khổ đau bức bách.

**EN**
1. Compassion has the characteristic of proceeding in the mode of wishing to remove the suffering of beings.
2. Its function is to be unable to bear others' suffering, in the sense of wishing to remove it.
3. Its effect is to bring about non-cruelty. To the discernment of the meditator it appears as the opposite of cruelty and oppression.
4. Its proximate cause is wise attention that sees the helplessness of beings afflicted and oppressed by suffering.

**VI**
Khi tâm và tâm sở thuộc nhóm tâm sân, vốn có chiều hướng bức hại chúng sinh, lắng xuống, đó là thành tựu của tâm bi, là phận sự được làm trọn. Khi buồn rầu trước những chúng sinh đang chịu khổ, đó là thất bại của tâm bi. (Visuddhi 1,311.)

**EN**
Compassion succeeds when cruelty subsides, that is, when the mental factor of aversion that directly opposes compassion and takes the form of cruelty towards beings subsides. This is the accomplishment of its function. Compassion fails when sorrow over suffering beings arises. (Visuddhimagga I, 311.)


<a id="M02-body-P123"></a>
## Tâm hỷ: đặc tính, phận sự, biểu hiện và nhân gần / Characteristic, function, manifestation, and proximate cause of appreciative joy
Miến / Burmese 123

**VI**
1. Pamodanalakkhaṇā muditā.
2. Anissāyanarasā.
3. Arativighātapaccupaṭṭhānā.
4. Sattānaṃ sampattidassanapadaṭṭhānā.
Arativūpasamo tassā sampatti, pahāsasambhavo vipatti. (Visuddhi 1,311.)

**EN**
1. Pamodanalakkhaṇā muditā.
2. Anissāyanarasā.
3. Arativighātapaccupaṭṭhānā.
4. Sattānaṃ sampattidassanapadaṭṭhānā.
Arativūpasamo tassā sampatti, pahāsasambhavo vipatti. (Visuddhi 1,311.)

**VI**
1. Tâm hỷ có đặc tính vui mừng khi thấy người khác đầy đủ của cải và những điều tốt đẹp.
2. Có phận sự không ganh tị trước sự hưng thịnh và đầy đủ của người khác. Nói cách khác, có phận sự loại bỏ sự ganh tị vì tâm hỷ đối nghịch với ganh tị.
3. Trước tuệ của hành giả, tâm hỷ hiện rõ như pháp loại bỏ sự không vui, chán ghét trước sự hưng thịnh của người khác hoặc trước những thiện pháp cao quý như thiền chỉ và minh sát. Đó là biểu hiện theo cách pháp ấy hiện rõ. Nói cách khác, tâm hỷ làm cho sự không vui, chán ghét (arati) trước các điều ấy biến mất. Đó là biểu hiện theo kết quả.
4. Nhân gần là tác ý đúng cách, quen thấy sự hưng thịnh và đầy đủ của người khác.

**EN**
1. Appreciative joy has the characteristic of rejoicing when one sees the success and prosperity of others.
2. Its function is freedom from envy of others' success and prosperity, or the removal of envy as its opposite.
3. It appears to the meditator's discernment as the removal of discontent with others' worldly prosperity or with their excellent wholesome accomplishments, such as tranquillity and insight. Alternatively, its effect is to dispel discontent with these achievements.
4. Its proximate cause is wise attention that sees the success of beings with approval.

**VI**
Khi sự không vui, chán ghét đối với sự hưng thịnh của người khác hoặc đối với những thiện pháp cao quý như thiền chỉ và minh sát…

**EN**
When discontent with others' prosperity or their excellent wholesome accomplishments, such as tranquillity and insight…


<a id="M02-body-P124"></a>
## Tâm xả: đặc tính, phận sự, biểu hiện và nhân gần / Characteristic, function, manifestation, and proximate cause of equanimity
Miến / Burmese 124

**VI**
…lắng xuống, đó là thành tựu của tâm hỷ. Sự vui cười do hỷ dựa vào đời sống thế tục (gehasitapīti), khi nương vào dục lạc trong sự hưng thịnh của người khác hay trong các việc thiện, là thất bại của tâm hỷ. (Visuddhi 1,311.)

**EN**
…subsides, appreciative joy succeeds. It fails when one rejoices in others' prosperity or wholesome accomplishments with worldly gladness arising in dependence on sensual pleasures. (Visuddhimagga I, 311.)

**VI**
1. Sattesu majjhattākārappavattilakkhaṇā upekkhā.
2. Sattesu samabhāvadassanarasā.
3. Paṭighānunayūpasamapaccupaṭṭhānā.
4. “Kammassakā sattā, te kassa ruciyā sukhitā vā bhavissanti, dukkhato vā muccissanti, pattasampattito vā na parihāyissantī”ti evaṃ pavattakammassakatādassanapadaṭṭhānā.
Paṭighānunayūpasamo tassā sampatti, gehasitāya aññāṇupekkhāya sambhavo vipatti. (Visuddhi 1,311–312.)

**EN**
1. Sattesu majjhattākārappavattilakkhaṇā upekkhā.
2. Sattesu samabhāvadassanarasā.
3. Paṭighānunayūpasamapaccupaṭṭhānā.
4. “Kammassakā sattā, te kassa ruciyā sukhitā vā bhavissanti, dukkhato vā muccissanti, pattasampattito vā na parihāyissantī”ti evaṃ pavattakammassakatādassanapadaṭṭhānā.
Paṭighānunayūpasamo tassā sampatti, gehasitāya aññāṇupekkhāya sambhavo vipatti. (Visuddhi 1,311–312.)

**VI**
1. Tâm xả có đặc tính vận hành với thái độ trung lập đối với chúng sinh.
2. Có phận sự thấy chúng sinh một cách bình đẳng, không thiên vị.
3. Làm lắng dịu sự ghét bỏ và yêu luyến đối với chúng sinh. Đó là biểu hiện theo kết quả.
4. Nhân gần là trí thấy chúng sinh có nghiệp là của mình, vận hành theo cách suy xét: “Chúng sinh có nghiệp mình đã làm là tài sản riêng. Do ý muốn của ai mà họ sẽ được an vui như lời nguyện của người tu tập tâm từ? Do ý muốn của ai mà họ sẽ thoát khổ…”

**EN**
1. Equanimity has the characteristic of proceeding impartially towards beings.
2. Its function is to see equality among beings, through looking on without taking sides.
3. Its effect is to quiet aversion and affection towards beings.
4. Its proximate cause is discernment that beings own their kamma: “Beings have the kamma they have done as their own possession. By whose wish would they become happy, as one who develops loving-kindness wishes them to be happy? By whose wish would they be freed from suffering…


<a id="M02-body-P125"></a>
## Giải thoát khỏi các phiền não / The divine abidings as escapes from defilements
Miến / Burmese 125

**VI**
“…như lời nguyện của người tu tập tâm bi? Do ý muốn của ai mà họ sẽ giữ được sự hưng thịnh và an vui đã đạt được, như lời nguyện của người tu tập tâm hỷ?” Suy xét như vậy, thấy chúng sinh có nghiệp là tài sản riêng. Cái thấy ấy là nhân gần của tâm xả.

**EN**
…as one who develops compassion wishes them to be freed? By whose wish would they retain the prosperity and happiness they have gained, as one who develops appreciative joy wishes them not to lose it?” The discernment that beings own their kamma, arising in this way, is the proximate cause.

**VI**
Sự lắng dịu của ghét bỏ và yêu luyến là thành tựu của phạm trú xả, là làm trọn phận sự. Khi xả do không hiểu biết, câu hữu với si mê và dựa trên dục lạc thế tục, sinh khởi, đó là thất bại của phạm trú xả. (Visuddhi 1,311.)

**EN**
The quieting of aversion and affection is the success and proper accomplishment of equanimity as a divine abiding. When unknowing indifference associated with delusion and dependent on sensual pleasures arises, equanimity has failed. (Visuddhimagga I, 311.)

**VI**
Giải thoát khỏi các phiền não

**EN**
Escape from defilements

**VI**
1. Nissaraṇañhetaṃ, āvuso, byāpādassa yadidaṃ mettā cetovimutti.
2. Nissaraṇañhetaṃ, āvuso, vihesāya yadidaṃ karuṇā cetovimutti.
3. Nissaraṇañhetaṃ, āvuso, aratiyā yadidaṃ muditā cetovimutti.
4. Nissaraṇañhetaṃ, āvuso, rāgassa yadidaṃ upekkhā cetovimutti. (Dī 3,205–206; Aṅ 2,257.)

**EN**
1. Nissaraṇañhetaṃ, āvuso, byāpādassa yadidaṃ mettā cetovimutti.
2. Nissaraṇañhetaṃ, āvuso, vihesāya yadidaṃ karuṇā cetovimutti.
3. Nissaraṇañhetaṃ, āvuso, aratiyā yadidaṃ muditā cetovimutti.
4. Nissaraṇañhetaṃ, āvuso, rāgassa yadidaṃ upekkhā cetovimutti. (Dī 3,205–206; Aṅ 2,257.)

**VI**
1. Này hiền giả, tâm thiền câu hữu với từ, đã thoát khỏi phiền não đối nghịch, là lối thoát khỏi sân muốn làm hại chúng sinh…

**EN**
1. Friend, the jhāna consciousness accompanied by loving-kindness, free from defilements, is the escape from ill will, the wish to harm beings…


<a id="M02-body-P126"></a>
## Bốn phạm trú chế ngự pháp đối nghịch / Dwelling free of opposing defilements
Miến / Burmese 126

**VI**
…tức thoát khỏi sân.

**EN**
…that is, it is the escape from aversion.

**VI**
2. Này hiền giả, tâm thiền câu hữu với bi, đã thoát khỏi phiền não đối nghịch, là lối thoát khỏi ý muốn hành hạ, bức hại chúng sinh, tức thoát khỏi pháp bức hại (vihesā).
3. Này hiền giả, tâm thiền câu hữu với hỷ, đã thoát khỏi phiền não đối nghịch, là lối thoát khỏi sự không vui, chán ghét (arati).
4. Này hiền giả, tâm thiền câu hữu với xả, tức tâm nhìn chúng sinh một cách bình đẳng, đã thoát khỏi phiền não đối nghịch, là lối thoát khỏi sự luyến ái, tức tham (rāga). (Dī 3,205–206; Aṅ 2,257.)

**EN**
2. Friend, the jhāna consciousness accompanied by compassion, free from defilements, is the escape from cruelty, the wish to torment beings.
3. Friend, the jhāna consciousness accompanied by appreciative joy, free from defilements, is the escape from discontent.
4. Friend, the jhāna consciousness accompanied by equanimity, free from defilements, is the escape from attachment, that is, lust. (Dīgha Nikāya 3, pp. 205–206; Aṅguttara Nikāya 2, p. 257.)

**VI**
Theo những lời dạy này, các thiền phạm trú có năng lực đưa tâm thoát khỏi những phiền não đối nghịch. Sống với tâm đã thoát khỏi những phiền não đối nghịch như vậy được gọi là phạm trú (brahmavihāra), nghĩa là cách sống cao quý. Cũng có thể gọi là sống như các vị Phạm thiên.

**EN**
According to these teachings, the jhānas of the divine abidings have the power to free the mind from the opposing defilements. Dwelling with a mind free from those defilements is called brahmavihāra, a sublime abiding. It may also be called dwelling like a Brahmā.


<a id="M02-body-P127"></a>
## Đề mục niệm Ân đức Phật (buddhānussati) / Recollection of the Buddha
Miến / Burmese 127

**VI**
Ārakattā hatattā ca kilesārīna so muni,
hatasaṃsāracakkāro paccayādīna cāraho,
na raho karoti pāpāni arahaṃ tena vuccati. (Visuddhi 1,195.)

**EN**
Ārakattā hatattā ca kilesārīna so muni,
hatasaṃsāracakkāro paccayādīna cāraho,
na raho karoti pāpāni arahaṃ tena vuccati. (Visuddhi 1,195.)

**VI**
1. Vì Đức Thế Tôn đã dùng tuệ minh sát cùng tuệ Thánh đạo để nhổ tận gốc các phiền não và ở rất xa phiền não, nên Ngài được gọi là Arahaṃ.
2. Vì Ngài đã dùng tuệ của A-la-hán đạo để tiêu diệt các kẻ thù là phiền não, nên Ngài được gọi là Arahaṃ.
3. Vì Ngài đã bẻ gãy các nan của bánh xe luân hồi, tức các pháp duyên khởi do vô minh và ái dẫn đầu, nên Ngài được gọi là Arahaṃ.
4. Vì có giới, định, tuệ và các ân đức không ai sánh bằng, Ngài xứng đáng nhận những vật cúng dường cao quý của người, chư thiên và Phạm thiên. Vì vậy Ngài được gọi là Arahaṃ.
5. Vì ngay cả ở nơi kín đáo Ngài cũng không làm, nói hay nghĩ điều bất thiện, nên Ngài được gọi là Arahaṃ.

**EN**
1. The Blessed Buddha is called Arahaṃ because, having eradicated defilements along with their habitual traces, he is far removed from them.
2. The Blessed Buddha is called Arahaṃ because he destroyed the fifteen hundred enemies that are the defilements with the sword of the knowledge of the path of arahantship.
3. The Blessed Buddha is called Arahaṃ because he broke the spokes of the wheel of saṃsāra, whose hub is ignorance and craving and whose rim is ageing and death.
4. The Blessed Buddha is called Arahaṃ because his unsurpassed virtue, concentration, and wisdom make him worthy of the special offerings and homage of humans, deities, and Brahmās.
5. The Blessed Buddha is called Arahaṃ because he commits no evil in deed, speech, or thought even in a hidden place.

**VI**
Đó là năm nghĩa của ân đức Arahaṃ. Các nghĩa ấy…

**EN**
These are the five meanings of the quality Arahaṃ. Practise so that…


<a id="M02-body-P128"></a>
## Cách tu tập ân đức Arahaṃ / Developing the recollection of Arahaṃ
Miến / Burmese 128

**VI**
…hãy học cho thông thạo và thuộc lòng. Người thiện muốn tu tập đề mục ân đức Arahaṃ trước hết hãy an lập lại tứ thiền kasiṇa trắng hoặc tứ thiền niệm hơi thở. Nhờ ánh sáng phát sinh từ tuệ tu tập thiền chỉ ấy, hãy hướng tâm đến một tượng Phật mình kính ngưỡng và cố gắng thấy tượng. Vì chưa từng thấy Đức Phật khi Ngài còn tại thế, trước hết cần nhờ đến một pho tượng thay cho hình ảnh Ngài. Khi thấy rõ tượng, hãy ghi nhận hình ảnh đó như Đức Phật đang hiện diện và lấy làm cảnh. Nếu đã từng gặp các Đức Phật quá khứ khi các Ngài còn tại thế, hình ảnh một vị Phật ấy có thể hiện ra. Hãy chuyển từ hình ảnh Đức Phật sang ân đức của Ngài.

**EN**
…you know these meanings well and remember them fluently. To develop this subject, re-establish fourth-jhāna concentration on the white kasiṇa or mindfulness of breathing. Using the light that arises from the knowledge of tranquillity meditation, bring into view a Buddha image for which you have reverence and faith. Since you have not seen the living Buddha, start with an image representing him. When it appears clearly, recognize the image as the living Buddha and direct the mind to it.

**VI**
Nếu hình ảnh Đức Phật như khi Ngài còn tại thế không hiện ra, hãy ghi nhận pho tượng đã lấy làm cảnh như Đức Phật đang hiện diện, rồi chuyển từ hình ảnh ấy sang ân đức. Trong năm nghĩa của Arahaṃ đã nêu, chọn một nghĩa mình ưa thích và tu tập “Arahaṃ, Arahaṃ” với nghĩa ấy làm cảnh. Khi định mạnh, hình ảnh mất đi và tâm tu tập an trú yên tĩnh trên ân đức. Lúc đó đừng chạy theo hình ảnh, đừng tìm lại hình ảnh, mà tiếp tục tu tập cho tâm an trú yên tĩnh trên ân đức. Khi tâm an trú trên cảnh ân đức suốt một giờ, hãy suy xét lại các chi thiền. Định này chỉ đến cận định. Hãy tu tập đến cận định ấy. Các ân đức còn lại cũng tu tập theo cách này. Hãy luyện cho thuần thục.

**EN**
If you met a living Buddha in the past, an image of that Buddha may appear. Then shift attention from that image to his quality. If no image of a living Buddha appears, regard the image you have taken as the living Buddha and shift from the image to the quality. Choose whichever of the five meanings of Arahaṃ you prefer and develop it as “Arahaṃ, Arahaṃ.” When concentration grows strong, the image disappears and the developing mind remains peacefully settled on the quality. Do not seek the image again. Develop the mind so that it remains peacefully settled on the quality alone. When it has remained settled on the quality for about an hour, review the jhāna factors. This is access jhāna only. Develop it to that point and cultivate the remaining qualities in the same manner. Practise until proficient in the masteries.


<a id="M02-body-P129"></a>
## Đề mục bất tịnh (asubha) / Meditation on foulness
Miến / Burmese 129

**VI**
Hãy an lập lại tứ thiền niệm hơi thở hoặc tứ thiền kasiṇa trắng. Khi ánh sáng do tuệ tu tập cùng với định ấy lan khắp và chiếu sáng rực rỡ, hãy hướng tâm đến một tử thi cùng giới tính mà mình từng thấy, ở trạng thái ghê tởm nhất. Hãy cố gắng thấy tử thi ấy trong ánh sáng của tuệ. Nhờ ánh sáng, hướng tâm để thấy lại hình ảnh như đã từng thấy. Khi thấy rõ bằng ánh sáng của tuệ, hãy đặt tâm tu tập yên tĩnh trên trạng thái ghê tởm nhất của tử thi ấy, quán “paṭikūla, paṭikūla — đáng ghê tởm, đáng ghê tởm”.

**EN**
Re-establish fourth-jhāna concentration on mindfulness of breathing or the white kasiṇa. When the light associated with that concentration spreads and shines brilliantly all around, bring to mind the most repulsive corpse of someone of the same sex that you have seen. Try to see the corpse in the light of knowledge. Use the light to bring it into view as it appeared when you saw it before. When it is clearly visible, settle the developing mind peacefully on its most repulsive aspect, contemplating “paṭikkūla, paṭikkūla—repulsive, repulsive.”

**VI**
Khi tâm tu tập bất tịnh an trú yên tĩnh trên cảnh tử thi ấy suốt một giờ, hai giờ, cảnh bất tịnh chuyển từ học tướng sang tương tợ tướng. Tướng tử thi hiện rõ như nhìn bằng mắt thường là học tướng. (Visuddhi 1,180.)

**EN**
When the mind developing foulness remains peacefully settled on the corpse for an hour, two hours, or so, the object will pass from the learning sign to the counterpart sign. The image of the corpse seen as distinctly as if with the eyes open is the learning sign.

**VI**
Uggahanimittaṃ virūpaṃ bībhacchaṃ bheravadassanaṃ hutvā upaṭṭhāti. Paṭibhāganimittaṃ pana yāvadatthaṃ bhuñjitvā nipanno thūlaṅgapaccaṅgapuriso viya. (Visuddhi 1,183–184.)

**EN**
Uggahanimittaṃ virūpaṃ bībhacchaṃ bheravadassanaṃ hutvā upaṭṭhāti. Paṭibhāganimittaṃ pana yāvadatthaṃ bhuñjitvā nipanno thūlaṅgapaccaṅgapuriso viya. (Visuddhi 1,183–184.)

**VI**
Do tác ý tu tập trên cảnh tử thi bất tịnh chưa chín muồi, chưa phát triển rộng mạnh…

**EN**
When attention to the foul corpse has not yet grown expansive and strong…


<a id="M02-body-P130"></a>
## Từ học tướng bất tịnh đến sơ thiền / From the learning sign to first jhāna
Miến / Burmese 130

**VI**
…và do cảnh tử thi bất tịnh chưa trở nên hết sức tĩnh lặng, học tướng hiện ra xấu xí và đáng sợ. Khi tác ý tu tập bất tịnh đã chín muồi, phát triển rộng mạnh, và khi cảnh tử thi bất tịnh đã trở nên tĩnh lặng, tương tợ tướng hiện ra như một người thân hình to lớn đang nằm sau khi ăn no thỏa thích. (Visuddhi 1,183–184; Mahāṭīkā 1,210.)

**EN**
…and the object of the foul corpse has yet to become very peaceful, the learning sign appears misshapen, hideous, and frightening. When attention to foulness grows expansive and strong and the object has become peaceful, the counterpart sign appears like a well-fed man with large limbs, lying asleep after eating his fill. (Visuddhimagga I, pp. 183–184; Mahāṭīkā I, p. 210.)

**VI**
Nhiều lần lấy chính tương tợ tướng ấy làm cảnh và tác ý “paṭikūla, paṭikūla — đáng ghê tởm, đáng ghê tởm”. Khi tâm tu tập an trú yên tĩnh trên cảnh ấy suốt một giờ, hai giờ, các chi thiền sẽ hiện rõ. Khi các chi thiền hiện rõ thì đã đạt sơ thiền. Hãy luyện cho thành thạo năm pháp tự tại.

**EN**
Repeatedly contemplate that very counterpart sign as “paṭikkūla, paṭikkūla—repulsive, repulsive.” When the developing mind remains peacefully settled on that object for one or two hours, the jhāna factors become evident. When they are evident, first-jhāna concentration has been reached. Practise until proficient in all five masteries.


<a id="M02-body-P131"></a>
## Đề mục niệm chết (maraṇassati, maraṇānussati) / Mindfulness of death
Miến / Burmese 131

**VI**
Tattha maraṇanti ekabhavapariyāpannassa jīvitindriyassa upacchedo.

**EN**
Tattha maraṇanti ekabhavapariyāpannassa jīvitindriyassa upacchedo.

**VI**
Pe. Iti jīvitindriyupacchedasaṅkhātassa maraṇassa saraṇaṃ maraṇassati. (Visuddhi 1,222.)

**EN**
Pe. Iti jīvitindriyupacchedasaṅkhātassa maraṇassa saraṇaṃ maraṇassati. (Visuddhimagga I, 222.)

**VI**
Ở đây, chết là sự chấm dứt mạng quyền thuộc một đời sống. Pe. Ghi nhớ sự chết được gọi là sự chấm dứt mạng quyền là niệm chết.

**EN**
Here death means the cutting off of the life faculty within a single existence. Mindfulness of death is the recollection of death as the cutting off of the life faculty.

**VI**
Puna caparaṃ, bhikkhave, bhikkhu seyyathāpi passeyya sarīraṃ sivathikāya chaḍḍitaṃ ekāhamataṃ vā dvīhamataṃ vā tīhamataṃ vā uddhumātakaṃ vinīlakaṃ vipubbakajātaṃ. So imameva kāyaṃ upasaṃharati: “Ayampi kho kāyo evaṃdhammo evaṃbhāvī evaṃanatīto”ti. (Ma 1,73.)

**EN**
Puna caparaṃ, bhikkhave, bhikkhu seyyathāpi passeyya sarīraṃ sivathikāya chaḍḍitaṃ ekāhamataṃ vā dvīhamataṃ vā tīhamataṃ vā uddhumātakaṃ vinīlakaṃ vipubbakajātaṃ. So imameva kāyaṃ upasaṃharati: “Ayampi kho kāyo evaṃdhammo evaṃbhāvī evaṃanatīto”ti. (Ma 1,73.)

**VI**
Lại nữa, này các tỳ-khưu, như thể một tỳ-khưu thấy thân bị bỏ ở nghĩa địa, chết đã một ngày, hai ngày hay ba ngày, trương phồng, xanh bầm, chảy mủ. Vị ấy đem so với chính thân này: “Thân này cũng có bản chất như vậy, sẽ trở thành như vậy, không vượt khỏi tình trạng ấy.”

**EN**
Again, bhikkhus, as though seeing a corpse thrown into a charnel ground, one day, two days, or three days dead, swollen, discoloured, and festering, a bhikkhu compares this very body with it: “This body too is of that nature, will become like that, and has not gone beyond that.”

**VI**
Tasmā tattha hatamatādisatte oloketvā diṭṭhapubbasampattīnaṃ sattānaṃ matānaṃ maraṇaṃ āvajjetvā satiñca saṃvegañca ñāṇañca yojetvā “maraṇaṃ bhavissatī”tiādinā nayena manasikāro pavattetabbo. (Visuddhi 1,223.)

**EN**
Tasmā tattha hatamatādisatte oloketvā diṭṭhapubbasampattīnaṃ sattānaṃ matānaṃ maraṇaṃ āvajjetvā satiñca saṃvegañca ñāṇañca yojetvā “maraṇaṃ bhavissatī”tiādinā nayena manasikāro pavattetabbo. (Visuddhi 1,223.)

**VI**
Vì vậy, hãy nhìn những chúng sinh bị giết, đã chết v.v., hướng tâm đến cái chết của những chúng sinh từng thấy hưng thịnh mà nay đã chết, kết hợp niệm, sự kinh cảm và tuệ, rồi tác ý theo cách “cái chết sẽ đến” v.v.

**EN**
Therefore, look at beings who have been killed or have died here and there, and bring to mind the death of beings who died amid prosperity. With mindfulness, a sense of urgency, and discernment, attend in such ways as “Death will come.”

**VI**
Theo kinh và chú giải nêu trên, vị thiện nhân muốn tu tập niệm chết hãy an lập lại định đến sơ thiền của đề mục bất tịnh đã đạt. Khi có thể an trú định sơ thiền trên tử thi bất tịnh bên ngoài, hãy hướng tuệ về cái chết của chính mình, làm sinh khởi niệm, sự kinh cảm và tuệ: “Thân này của ta cũng có bản chất phải chết như vậy. Sự chết như vậy chắc chắn sẽ xảy đến. Thân này không thể vượt khỏi bản chất phải chết ấy.” Khi nhìn như vậy, sẽ thấy hình ảnh tử thi bất tịnh của chính mình. Khi ấy, trong hình ảnh mình đã chết, hãy dùng tuệ…

**EN**
Following these passages, to develop mindfulness of death, first re-establish concentration on foulness up to the first jhāna. When you can contemplate the repulsive corpse up to first-jhāna concentration, direct discernment to your own death: “This body of mine too is subject to such death. This death will surely occur. I cannot go beyond it.” Looking with mindfulness, urgency, and discernment, you will see your own repulsive corpse. Then use discernment to see the cutting off of the life faculty in that image of your own death…


<a id="M02-body-P132"></a>
## Sự chấm dứt của mạng quyền / Taking the cutting off of the life faculty as object
Miến / Burmese 132

**VI**
…thấy rõ sự chấm dứt mạng quyền. Hãy đặt tâm tu tập yên tĩnh trên cảnh sự chấm dứt mạng quyền ấy:

**EN**
…Keep the developing mind peacefully settled on the cutting off of the life faculty, attending as follows.

**VI**
1. Maraṇaṃ me dhuvaṃ, jīvitaṃ me adhuvaṃ. Cái chết của ta là chắc chắn, sự sống của ta là không chắc chắn.
2. Maraṇaṃ me bhavissati. Cái chết của ta chắc chắn sẽ đến.
3. Maraṇapariyosānaṃ me jīvitaṃ. Sự sống của ta kết thúc ở cái chết.
4. Maraṇaṃ, maraṇaṃ. Chết, chết.

**EN**
1. Maraṇaṃ me dhuvaṃ, jīvitaṃ me adhuvaṃ. My death is certain, my life uncertain.
2. Maraṇaṃ me bhavissati. Death will come to me.
3. Maraṇapariyosānaṃ me jīvitaṃ. My life ends in death.
4. Maraṇaṃ, maraṇaṃ. Death, death.

**VI**
Trong những cách tác ý ấy, hãy chọn cách mình ưa thích, quán bằng Pāli hoặc tiếng Miến. Hãy cố gắng giữ tâm tu tập niệm chết an trú yên tĩnh một giờ, hai giờ v.v. trên cảnh sự chấm dứt mạng quyền trong hình ảnh mình đã chết. Khi tâm an trú yên tĩnh, năm chi thiền cũng sẽ hiện rõ. Định ấy chỉ là cận định.

**EN**
Choose whichever of these ways of attending you prefer, in Pāli or your own language. Strive to keep the mind developing mindfulness of death peacefully settled for an hour or two on the cutting off of the life faculty in the image of your death. When it remains settled in this way, the five jhāna factors will become evident. This is access jhāna only.

**VI**
Sự chấm dứt của mạng quyền

**EN**
The cutting off of the life faculty

**VI**
Điểm này là một chỗ quán khó, dễ lẫn lộn vì liên hệ đến pháp chân đế là mạng quyền. Jīvitindriyupacchedasaṅkhātassa maraṇassa saraṇaṃ maraṇassati. Theo lời giải của Visuddhimagga, niệm chết là ghi nhớ cái chết được gọi là sự chấm dứt mạng quyền. Do đó cần quán để thấy sự chấm dứt mạng quyền của chính mình. Chỉ thấy tử thi của mình bằng tuệ vẫn chưa hoàn tất việc ấy. Vì vậy, sau khi hành giả…

**EN**
This is a difficult contemplation because it concerns an ultimate reality, the life faculty. The Visuddhimagga defines mindfulness of death as recollecting death as the cutting off of the life faculty. Practise so as to see the cutting off of your own life faculty. Merely bringing to mind and seeing your own corpse with discernment does not complete the task. Therefore, once the meditator…


<a id="M02-body-P133"></a>
## Quán từ hình ảnh tử thi đến sự chấm dứt mạng quyền / Discerning the cessation of the life faculty
Miến / Burmese 133

**VI**
…đã tu tập định sơ thiền trên tử thi bên ngoài, hãy dùng tuệ hướng đến hình ảnh mình đã chết. Khi thấy tử thi của chính mình, hãy đưa tuệ vào bên trong vùng tim của tử thi ấy. Ở đó khó nhận ra sự chấm dứt mạng quyền vì mạng quyền nơi tử thi đã chấm dứt. Hãy đưa tuệ vào vùng tim như vậy, rồi lùi trở về thời điểm sắp chết. Khi ấy có thể thấy ý môn hữu phần trong dòng tâm trước lúc chết. Điều nói đến ở đây là sự trong sáng của ý môn hữu phần. Hành giả đã từng phân biệt các chi thiền thì đã có thể nhận biết sự trong sáng của ý môn hữu phần, nên lúc này cũng có thể nhận biết dễ dàng.

**EN**
…has developed first-jhāna concentration with a repulsive corpse as object, they can direct discernment towards the image of their own death. When you see your corpse, direct attention inside its heart. You may not immediately see the cutting off of the life faculty, since in that corpse the faculty has already been cut off.

**VI**
Khi đã thấy sự trong sáng của ý môn hữu phần bằng tuệ, hãy tiến trở lại về phía cái chết để quán. Bấy giờ có thể thấy sự chấm dứt của sự trong sáng ấy. Tiếp đó, như đã giải thích ở trên, hãy hướng tuệ vào và quán tâm hữu phần làm duyên cho sự trong sáng của ý môn hữu phần. Khi thấy tâm hữu phần, hãy quán thêm để thấy sự chấm dứt của mạng quyền đi cùng tâm hữu phần ấy. Khi thấy được thì sẽ hiểu sự chấm dứt của mạng quyền.

**EN**
When you can direct discernment into the heart in this way, look back a little to the time before death. You may then see, near the time of death, the clarity of the life-continuum mind-door or the stream of consciousness. Here the intended object is the clarity of the life-continuum mind-door. Since you have already discerned it when discerning the jhāna factors, you can discern it readily here too. When you see it with discernment, move closer to the time of death. You can then see that clarity cease. As explained earlier, discern the life-continuum consciousness that produces that clarity. When you see it, look further to see the cutting off of the life faculty that accompanies it. In seeing that, you understand the cutting off of the life faculty.

**VI**
Tuy nhiên, đối với phần lớn hành giả chưa từng phân biệt danh pháp, chưa luyện thuần thục đề mục danh pháp, việc hiểu rõ tâm hữu phần và mạng quyền ở giai đoạn này còn khó khăn.

**EN**
For most meditators who have never discerned mentality, however, at this stage it is very difficult to understand the life-continuum consciousness and the life faculty.


<a id="M02-body-P134"></a>
## Cảnh niệm chết và bốn đề mục bảo hộ / The four protective meditation subjects
Miến / Burmese 134

**VI**
Dù khó như thế, vì đã thấy sự trong sáng của ý môn hữu phần, hành giả có thể lấy sự chấm dứt của sự trong sáng ấy làm cảnh để tu tập niệm chết. Như đã giải thích trên, sự trong sáng ấy được gọi là hữu phần theo nghĩa chuyển. Dù khó đến đâu, hành giả vẫn có thể quán bằng tuệ và thấy tử thi của chính mình. Người từng tu tập niệm chết trong các đời quá khứ cũng có thể thấy trực tiếp sự chấm dứt mạng quyền, tức sự chấm dứt mạng quyền cùng với tâm hữu phần. Nếu thấy được như vậy thì tốt nhất.

**EN**
Even if this is difficult, you have already seen the clarity of the life-continuum mind-door and can develop mindfulness of death by taking its cessation as object. As explained above, this clarity is called the life-continuum by way of a figurative designation. With discernment you can still bring your own corpse into view. Someone who has practised mindfulness of death in past lives may see the cutting off of the life faculty, or, put another way, the cessation of the life-continuum consciousness together with the life faculty. It is best if this can be seen.

**VI**
Phần lớn hành giả chưa từng phân biệt danh pháp vẫn có thể quán thấy sự chấm dứt của sự trong sáng của ý môn hữu phần, được gọi theo nghĩa chuyển như đã giải thích trên. Có thể lấy sự chấm dứt ấy làm cảnh để tu tập niệm chết. Tuy nhiên, hành giả đã quán các pháp duyên khởi, tức mối liên hệ nhân quả, đến giai đoạn tuệ phân biệt nhân duyên (paccayapariggahañāṇa), có thể dễ dàng quán thấy sự chấm dứt của mạng quyền cùng với tâm hữu phần.

**EN**
Most meditators who have yet to discern mentality can see the cessation of the clarity of the life-continuum mind-door just explained, called the life-continuum figuratively. They can develop mindfulness of death by taking as object the cessation of that material clarity. Meditators who have discerned the relations of cause and effect in dependent origination up to knowledge of discerning conditions can readily see the cessation of the life-continuum consciousness together with the life faculty.

**VI**
Bốn đề mục tâm từ, niệm Ân đức Phật, bất tịnh và niệm chết là bốn đề mục bảo hộ (caturārakkha) giúp bảo hộ hành giả. Đây là những đề mục nên học và tu tập trước khi bước sang minh sát.

**EN**
Loving-kindness, recollection of the Buddha, foulness, and mindfulness of death are the four protective meditation subjects. They are called protective because they guard meditators. They are subjects to learn and cultivate before proceeding to insight.


<a id="M02-body-P135"></a>
## Chọn đề mục phù hợp với trạng thái tâm / Choosing a subject to counter a hindrance
Miến / Burmese 135

**VI**
Asubhā bhāvetabbā rāgassa pahānāya.
Mettā bhāvetabbā byāpādassa pahānāya.
Ānāpānassati bhāvetabbā vitakkupacchedāya. (Aṅ 3,169; Udāna 120, Meghiyasutta.)

**EN**
Asubhā bhāvetabbā rāgassa pahānāya.
Mettā bhāvetabbā byāpādassa pahānāya.
Ānāpānassati bhāvetabbā vitakkupacchedāya. (Aṅ 3,169; Udāna 120, Meghiyasutta.)

**VI**
Nên tu tập bất tịnh để đoạn trừ tham ái.
Nên tu tập tâm từ để đoạn trừ ác ý.
Nên tu tập niệm hơi thở để cắt đứt các tầm.

**EN**
Develop foulness for abandoning lust. Develop loving-kindness for abandoning ill will. Develop mindfulness of breathing for cutting off applied thoughts.

**VI**
Theo kinh Meghiya trên đây, tu tập bất tịnh là vũ khí tốt nhất để chống lại tham ái. Tu tập bất tịnh lấy tử thi làm cảnh như đã trình bày được gọi là bất tịnh nơi thân không có thức (aviññāṇaka-asubha). Trong kinh Girimānanda (Aṅ 3,343), Đức Phật dạy tu tập bất tịnh bằng cách lấy 32 thân phần của chúng sinh còn sống làm cảnh và tác ý theo tính chất đáng ghê tởm. Đó là bất tịnh nơi thân có thức (saviññāṇaka-asubha). Cả hai cách tu tập bất tịnh đều là vũ khí tốt nhất để loại bỏ tham ái. Đề mục tâm từ là đề mục tốt nhất để loại bỏ ác ý, tức sân. Đề mục niệm hơi thở có năng lực chống lại các loại tầm làm tâm bất an.

**EN**
According to this teaching in the Meghiya Sutta, foulness is an excellent means of countering lust. The foulness meditation described above, with a corpse as its object, is foulness connected with the lifeless. The Girimānanda Sutta teaches another subject of foulness, attending to the thirty-two parts of a living body as repulsive. This is foulness connected with the living. Both kinds are excellent means of removing lust. Loving-kindness is an excellent subject for removing ill will and aversion. Mindfulness of breathing is an effective subject for countering plans and other kinds of thought.

**VI**
Vì vậy, vị thiện nhân hãy tu tập bất tịnh khi tham ái mạnh, tu tập tâm từ khi sân mạnh, tu tập niệm hơi thở khi nhiều tầm khởi lên. Khi đức tin suy giảm và tâm thiếu trong sáng trong lúc tu tập, hãy niệm Ân đức Phật. Khi sự kinh cảm suy giảm và việc tu tập trở nên biếng nhác, hãy tu tập niệm chết.

**EN**
Therefore, good meditator, develop foulness when lust is strong, loving-kindness when aversion is strong, and mindfulness of breathing when thoughts proliferate. When faith diminishes and the mind lacks clarity in meditation, develop recollection of the Buddha. When urgency diminishes and you become lax in meditation, develop mindfulness of death.


<a id="M02-body-P136"></a>
## Kết phần thiền chỉ và lời nguyện / Conclusion of the section on tranquillity meditation
Miến / Burmese 136

**VI**
Đức Phật đã dạy 40 đề mục thiền chỉ. Trong số ấy, phần thiền chỉ này đã trình bày tóm lược:

**EN**
The Buddha taught forty meditation subjects for tranquillity. Of these, this section has presented the following subjects in brief.

**VI**
1. Đề mục niệm hơi thở.
2. Đề mục bộ xương với tác ý bất tịnh.
3. Mười kasiṇa và tám chứng đắc thiền định.
4. Bốn phạm trú.
5. Đề mục niệm Ân đức Phật.
6. Đề mục bất tịnh.
7. Đề mục niệm chết.

**EN**
1. Mindfulness of breathing.
2. Attention to repulsiveness, the meditation on the bones.
3. The ten kasiṇas and the eight attainments.
4. The four divine abidings.
5. Recollection of the Buddha.
6. Meditation on foulness.
7. Mindfulness of death.

**VI**
Ai muốn tu tập các đề mục thiền chỉ còn lại, hãy đến học với các vị thầy. Nếu vị thiện nhân muốn chuyển sang đề mục minh sát, hãy tiếp tục tu tập theo phần đề mục sắc và các phần tiếp theo.

**EN**
Anyone wishing to cultivate the remaining tranquillity subjects should approach teachers and learn from them. If you wish to proceed to insight meditation, continue by developing the subjects beginning with the discernment of materiality.

**VI**
Ciraṃ tiṭṭhatu saddhammo, dhamme hontu sagāravā.

**EN**
Ciraṃ tiṭṭhatu saddhammo, dhamme hontu sagāravā.

**VI**
Mong Chánh pháp của Đức Phật tồn tại lâu dài.
Mong mọi người tôn kính ba loại Chánh pháp.

**EN**
May the Buddha's true teaching endure for a long time. May there be reverence for the threefold true Dhamma.

**VI**
Pa-Auk Tawya Sayadaw
Tu viện Cittalapabbata, Pa-Auk Tawya.
Năm 1367 theo lịch Miến Điện.

**EN**
Pa-Auk Tawya Sayadaw
Cittala Hill Monastery
Pa-Auk Tawya
Myanmar Era 1367


<a id="M02-index-P001"></a>
## Chỉ mục theo thứ tự chữ Miến — 137 / Index in Burmese alphabetical order — 137
Chỉ mục / Index - Miến / Burmese 137

**VI**
[အ]

**EN**
[အ]

**VI**
Nước thích hợp nhất — 43

**EN**
The most suitable water — 43

**VI**
Lời khuyên — 62

**EN**
Advice — 62

**VI**
Một khó khăn — 68

**EN**
A difficulty — 68

**VI**
Một số hành giả — 42

**EN**
Some meditators — 42

**VI**
Không còn dấu vết của giới hạn — 71

**EN**
No trace of a limit remains — 71

**VI**
Các tầng lần lượt vi tế hơn — 88

**EN**
Successively subtler attainments — 88

**VI**
Bên trong và bên ngoài (ajjhatta, bahiddha) — 18

**EN**
Internally and externally (ajjhatta, bahiddha) — 18

**VI**
Bên trong — bên ngoài (ajjhatta — bahiddha) — 13

**EN**
Internal and external (ajjhatta — bahiddha) — 13

**VI**
Điểm nhấn mạnh đặc biệt — 64

**EN**
A point of special emphasis — 64

**VI**
Thức vô biên (anantaṃ viññāṇaṃ) — 70

**EN**
Infinite consciousness (anantaṃ viññāṇaṃ) — 70

**VI**
Từ gần đến xa — 4

**EN**
From near to far — 4

**VI**
Nhờ năng lực minh sát từng pháp (anupadadhamma-vipassanā) — 87

**EN**
Through the power of insight into phenomena one by one (anupadadhamma-vipassanā) — 87

**VI**
Phần không được nghiệp chấp thủ (anupādinnakapakkha) — 6

**EN**
The part not clung to by kamma (anupādinnakapakkha) — 6

**VI**
Năm cách trải tâm từ giải thoát không giới hạn — 102

**EN**
Five ways of extending boundless deliverance of mind through loving-kindness — 102

**VI**
Người có tâm từ đạt an chỉ — 102

**EN**
One whose loving-kindness reaches absorption — 102

**VI**
Không giới hạn (appamāṇa) — 21

**EN**
Boundless (appamāṇa) — 21

**VI**
Chỉ lấy riêng màu trắng — 28

**EN**
Taking only the white colour — 28

**VI**
Thiền thắng xứ (abhibhāyatanajhāna) — 16

**EN**
Jhāna of the bases of mastery (abhibhāyatanajhāna) — 16

**VI**
Hỏi và đáp — 85

**EN**
Questions and answers — 85

**VI**
Để người mình ghét nhất đến sau cùng — 98

**EN**
Leave the person you dislike most until last — 98

**VI**
Sự không vui, chán ghét (arati) — 124

**EN**
Discontent (arati) — 124

**VI**
Những tinh hoa đưa đến A-la-hán quả — 35

**EN**
Essential points leading to arahant fruition — 35

**VI**
Năm nghĩa của ân đức Arahaṃ — 127

**EN**
Five meanings of the quality Arahaṃ — 127

**VI**
Phần thiền vô sắc giới — 57

**EN**
The section on immaterial jhāna — 57

**VI**
Đề mục bộ xương — 9

**EN**
The skeleton meditation subject — 9

**VI**
Đừng tác ý màu sắc và đặc tính — 46

**EN**
Do not attend to colour or characteristic — 46

**VI**
Có thể khen vì sự khéo léo — 84

**EN**
It may be praised for its workmanship — 84

**VI**
Tốt nhất, cao quý nhất — 22

**EN**
The best and most excellent — 22

**VI**
Đề mục bất tịnh (asubha) — 129

**EN**
The meditation subject of foulness (asubha) — 129

**VI**
[အာ]

**EN**
[အာ]

**VI**
Kasiṇa hư không (ākāsakasiṇa) — 52

**EN**
Space kasiṇa (ākāsakasiṇa) — 52

**VI**
Thiền Không vô biên xứ (ākāsānañcāyatanajhāna) — 57

**EN**
Jhāna of the base of infinite space (ākāsānañcāyatanajhāna) — 57

**VI**
Tiến đến thiền Không vô biên xứ — 63

**EN**
Proceeding to the jhāna of the base of infinite space — 63

**VI**
Thiền Vô sở hữu xứ (ākiñcaññāyatanajhāna) — 71

**EN**
Jhāna of the base of nothingness (ākiñcaññāyatanajhāna) — 71

**VI**
Đã đạt thiền Vô sở hữu xứ — 77

**EN**
Having attained the jhāna of the base of nothingness — 77


<a id="M02-index-P002"></a>
## Chỉ mục theo thứ tự chữ Miến — 138 / Index in Burmese alphabetical order — 138
Chỉ mục / Index - Miến / Burmese 138

**VI**
[အာ — tiếp]

**EN**
[အာ — continued]

**VI**
Thiền Vô sở hữu xứ — 78

**EN**
Jhāna of the base of nothingness — 78

**VI**
Vượt qua Vô sở hữu xứ (ākiñcaññāyatanaṃ samatikkamma) — 82

**EN**
Surmounting the base of nothingness (ākiñcaññāyatanaṃ samatikkamma) — 82

**VI**
Kasiṇa nước (āpokasiṇa) — 42

**EN**
Water kasiṇa (āpokasiṇa) — 42

**VI**
Mười hai thân phần có thủy đại trội — 3

**EN**
Twelve bodily parts in which the water element predominates — 3

**VI**
Sự hướng tâm (ābhoga) — 85

**EN**
Adverting (ābhoga) — 85

**VI**
Vì bản chất các cảnh khác nhau — 119

**EN**
Because the objects differ in nature — 119

**VI**
Kasiṇa ánh sáng (ālokakasiṇa) — 49

**EN**
Light kasiṇa (ālokakasiṇa) — 49

**VI**
Dù khen ngợi hết sức nhiệt thành — 85

**EN**
Even if praised most enthusiastically — 85

**VI**
[ဥ]

**EN**
[ဥ]

**VI**
Học tướng — tương tợ tướng (uggahanimitta — paṭibhāganimitta) — 40, 44, 47

**EN**
Learning sign and counterpart sign (uggahanimitta — paṭibhāganimitta) — 40, 44, 47

**VI**
Học tướng và tương tợ tướng — 10, 49, 51, 53

**EN**
The learning sign and the counterpart sign — 10, 49, 51, 53

**VI**
Phần được nghiệp chấp thủ (upādinnakapakkha) — 6

**EN**
The part clung to by kamma (upādinnakapakkha) — 6

**VI**
Thất bại của phạm trú xả (vipatti) — 125

**EN**
Failure of equanimity as a divine abiding (vipatti) — 125

**VI**
Thành tựu của phạm trú xả — 125

**EN**
Success of equanimity as a divine abiding — 125

**VI**
Tu tập tâm xả (upekkhābhāvanā) — 114

**EN**
Development of equanimity (upekkhābhāvanā) — 114

**VI**
[ဩ]

**EN**
[ဩ]

**VI**
Chuyển sang kasiṇa trắng (odātakasiṇa) — 21

**EN**
Switching to the white kasiṇa (odātakasiṇa) — 21

**VI**
Bảy cách trải tâm từ giải thoát có giới hạn — 103

**EN**
Seven ways of extending limited deliverance of mind through loving-kindness — 103

**VI**
Tấm vải đậy kín miệng nồi — 64

**EN**
A cloth covering the mouth of a pot — 64

**VI**
[က]

**EN**
[က]

**VI**
Thân vật chất (karajakāya) — 57

**EN**
The material body (karajakāya) — 57

**VI**
Thất bại của tâm bi — 122

**EN**
Failure of compassion — 122

**VI**
Thành tựu của tâm bi — 122

**EN**
Success of compassion — 122

**VI**
Tu tập tâm bi (karuṇābhāvanā) — 110

**EN**
Development of compassion (karuṇābhāvanā) — 110

**VI**
Chỉ nhờ năng lực quán theo nhóm (kalāpasammasana) — 87

**EN**
Solely through the power of comprehension by groups (kalāpasammasana) — 87

**VI**
Mười kasiṇa — 54

**EN**
The ten kasiṇas — 54

**VI**
Mười kasiṇa và tám chứng đắc thiền định — 15

**EN**
The ten kasiṇas and the eight meditative attainments — 15

**VI**
Từ vũng bùn ngũ dục — 35

**EN**
From the mire of the five strands of sensual pleasure — 35

**VI**
Giải thoát khỏi các phiền não — 125

**EN**
Freedom from defilements — 125

**VI**
Chúng sinh chỉ có nghiệp là tài sản riêng — 116

**EN**
Beings have kamma as their own property — 116

**VI**
Kasiṇa hư không — 52

**EN**
Space kasiṇa — 52

**VI**
Tấm vé chắc chắn — 36

**EN**
A sure ticket — 36

**VI**
Những kasiṇa còn lại — bản in không ghi số trang

**EN**
The remaining kasiṇas — no page number in the printed source


<a id="M02-index-P003"></a>
## Chỉ mục theo thứ tự chữ Miến — 139 / Index in Burmese alphabetical order — 139
Chỉ mục / Index - Miến / Burmese 139

**VI**
[ခ]

**EN**
[ခ]

**VI**
Có thể thấy lạnh tăng lên — 44

**EN**
Increasing coldness can be discerned — 44

**VI**
[င]

**EN**
[င]

**VI**
Năm phương diện — 12

**EN**
Five aspects — 12

**VI**
Thật tịch tịnh, thật thù thắng — 83

**EN**
Truly peaceful, truly sublime — 83

**VI**
[စ]

**EN**
[စ]

**VI**
Phương pháp bốn thiền (catukka) — 27

**EN**
The four-jhāna method (catukka) — 27

**VI**
Phần bốn đề mục bảo hộ — 91

**EN**
The four protective meditation subjects — 91

**VI**
Khoét một lỗ thật tròn — 53

**EN**
Make a perfectly round hole — 53

**VI**
Tu tập hết lòng — 97

**EN**
Devote yourself to the practice — 97

**VI**
[ဆ]

**EN**
[ဆ]

**VI**
Ý nghĩa cốt yếu — 69

**EN**
The essential meaning — 69

**VI**
[ဇ]

**EN**
[ဇ]

**VI**
Bản chất chấm dứt của mạng quyền (jīvitindriya) — 131

**EN**
The cessation nature of the life faculty (jīvitindriya) — 131

**VI**
Sự chấm dứt của mạng quyền — 132

**EN**
Cessation of the life faculty — 132

**VI**
[ဈ]

**EN**
[ဈ]

**VI**
Năm thiền chi — 11, 26

**EN**
The five jhāna factors — 11, 26

**VI**
[ဉ]

**EN**
[ဉ]

**VI**
Hãy quán bao quát đến mức tuệ có thể — 105

**EN**
Discern as comprehensively as your knowledge allows — 105

**VI**
[တ]

**EN**
[တ]

**VI**
Kasiṇa lửa (tejokasiṇa) — 45

**EN**
Fire kasiṇa (tejokasiṇa) — 45

**VI**
Thông suốt [CHƯA XÁC MINH: cách hiểu cụm Miến trong dòng chỉ mục] — 3

**EN**
Understanding clearly [The meaning of this Burmese index phrase remains to be verified] — 3

**VI**
Làm cho một đời sống có giá trị — 33

**EN**
Making a life worthwhile — 33

**VI**
[ထ]

**EN**
[ထ]

**VI**
Đặc tính cứng (thaddhalakkhaṇa) — 39

**EN**
The characteristic of hardness (thaddhalakkhaṇa) — 39

**VI**
Đoạn trừ hôn trầm và thụy miên — 51

**EN**
Overcoming sloth and torpor — 51

**VI**
Giải thích thêm — 58

**EN**
Further explanation — 58

**VI**
[ဒ]

**EN**
[ဒ]

**VI**
Mười cách trải tâm từ giải thoát theo phương hướng — 106

**EN**
Ten ways of extending deliverance of mind through loving-kindness in the directions — 106

**VI**
Hãy chọn một chúng sinh đang chịu khổ — 110

**EN**
Choose a being who is suffering — 110

**VI**
Màu xấu (dubbaṇṇa) — 21

**EN**
An unattractive colour (dubbaṇṇa) — 21


<a id="M02-index-P004"></a>
## Chỉ mục theo thứ tự chữ Miến — 140 / Index in Burmese alphabetical order — 140
Chỉ mục / Index - Miến / Burmese 140

**VI**
[န]

**EN**
[န]

**VI**
Natthi kiñci — không có gì cả — 77

**EN**
Natthi kiñci — there is nothing at all — 77

**VI**
Natthi, natthi — suññaṃ, suññaṃ — vivittaṃ, vivittaṃ — 75

**EN**
Natthi, natthi — suññaṃ, suññaṃ — vivittaṃ, vivittaṃ — 75

**VI**
Ba cửa lớn vào Niết-bàn — 4

**EN**
Three great gateways to Nibbāna — 4

**VI**
Kasiṇa xanh đen (nīlakasiṇa) — 29

**EN**
Blue kasiṇa (nīlakasiṇa) — 29

**VI**
Nevasaññā — nāsaññā — 86

**EN**
Nevasaññā — nāsaññā — 86

**VI**
Thiền Phi tưởng phi phi tưởng xứ — 79

**EN**
Jhāna of the base of neither perception nor non-perception — 79

**VI**
Đã đạt thiền Phi tưởng phi phi tưởng xứ — 82

**EN**
Having attained the jhāna of the base of neither perception nor non-perception — 82

**VI**
Hai tâm không thể sinh cùng lúc — 69

**EN**
Two consciousnesses cannot arise simultaneously — 69

**VI**
Bắt đầu theo cách nào cũng được — 9

**EN**
Either way of beginning is suitable — 9

**VI**
Cả hai đều chỉ là tâm thiền — 67

**EN**
Both are simply jhāna consciousness — 67

**VI**
Ví dụ thế gian để so sánh — 59, 85

**EN**
An everyday simile for comparison — 59, 85

**VI**
Vận dụng ví dụ thế gian để so sánh — 76

**EN**
Applying the everyday simile — 76

**VI**
[ပ]

**EN**
[ပ]

**VI**
Phương pháp năm thiền (pañcaka) — 27

**EN**
The five-jhāna method (pañcaka) — 27

**VI**
Tác ý bất tịnh (paṭikūlamanasikāra) — 5

**EN**
Attention to repulsiveness (paṭikūlamanasikāra) — 5

**VI**
Đề mục bộ xương với tác ý bất tịnh — 1

**EN**
The skeleton meditation subject with attention to repulsiveness — 1

**VI**
Kasiṇa đất (paṭhavīkasiṇa) — 37

**EN**
Earth kasiṇa (paṭhavīkasiṇa) — 37

**VI**
Hai mươi thân phần có địa đại trội — 2

**EN**
Twenty bodily parts in which the earth element predominates — 2

**VI**
Ghi nhớ rằng cảnh là pháp chân đế — 67

**EN**
Remember that the object is an ultimate reality — 67

**VI**
Giới hạn (paritta) — 21

**EN**
Limited (paritta) — 21

**VI**
Người cùng giới được yêu kính (piya, garu, bhāvanīya) — 95

**EN**
A dear, respected, and esteemed companion in virtue (piya, garu, bhāvanīya) — 95

**VI**
Kasiṇa vàng (pītakasiṇa) — 32

**EN**
Yellow kasiṇa (pītakasiṇa) — 32

**VI**
Hỷ và thọ hỷ (pīti, somanassa) — 11

**EN**
Joy and pleasant feeling (pīti, somanassa) — 11

**VI**
Tất cả phàm phu đều đáng được thương xót — 111

**EN**
All worldlings are deserving of compassion — 111

**VI**
Nhóm hoa (pupphachakka) — 12

**EN**
The sixfold group of flowers (pupphachakka) — 12

**VI**
Vấn đề làm tính cứng càng tăng — 40

**EN**
The question of increasing hardness — 40

**VI**
Nhờ kinh nghiệm trực tiếp — 87

**EN**
Through direct experience — 87

**VI**
Công việc cần thực hành — 60

**EN**
The work to be practised — 60

**VI**
Vòng kasiṇa ánh sáng đã sửa soạn — 50

**EN**
The prepared disk of the light kasiṇa — 50

**VI**
Hoa padauk và sắc vàng óng — 33

**EN**
Padauk flowers and their golden colour — 33

**VI**
Những đề mục nên tu tập — 134

**EN**
Meditation subjects to develop — 134


<a id="M02-index-P005"></a>
## Chỉ mục theo thứ tự chữ Miến — 141 / Index in Burmese alphabetical order — 141
Chỉ mục / Index - Miến / Burmese 141

**VI**
[ဖ]

**EN**
[ဖ]

**VI**
Như cuộn một tấm chiếu — 61

**EN**
Like rolling up a mat — 61

**VI**
[ဗ]

**EN**
[ဗ]

**VI**
Đề mục niệm Ân đức Phật (buddhānussati) — 127

**EN**
The meditation subject of recollection of the Buddha (buddhānussati) — 127

**VI**
Phần phạm trú — đề mục tu tập tâm từ — 91

**EN**
The divine abidings: development of loving-kindness — 91

**VI**
Sống như các vị Phạm thiên — 126

**EN**
Living like the Brahmās — 126

**VI**
[ဘ]

**EN**
[ဘ]

**VI**
Thiện nghiệp do tu tập (bhāvanākusala-puññasaṅkhāra) — 45

**EN**
Wholesome kamma through development (bhāvanākusala-puññasaṅkhāra) — 45

**VI**
[မ]

**EN**
[မ]

**VI**
Không chịu nổi nên đã bỏ chạy — 46

**EN**
Unable to bear it, they ran away — 46

**VI**
Chỉ còn hành vi tế đến mức khó diễn tả — 79

**EN**
Only an indescribably subtle formation remains — 79

**VI**
Niệm chết (maraṇassati, maraṇānussati) — 131

**EN**
Recollection of death (maraṇassati, maraṇānussati) — 131

**VI**
Phải lấy làm cảnh vì không thể tránh khỏi — 88

**EN**
It must be taken as the object because it cannot be avoided — 88

**VI**
Cho đến khi ngọn lửa bùng lên — 45

**EN**
Until the flame flares up — 45

**VI**
Thất bại của tâm hỷ (vipatti) — 124

**EN**
Failure of appreciative joy (vipatti) — 124

**VI**
Tu tập tâm hỷ (muditābhāvanā) — 112

**EN**
Development of appreciative joy (muditābhāvanā) — 112

**VI**
Giải thích của Phụ chú giải gốc (Mūlaṭīkā) — 7

**EN**
Explanation in the Root Subcommentary (Mūlaṭīkā) — 7

**VI**
Theo kinh Meghiya — 135

**EN**
According to the Meghiya Sutta — 135

**VI**
Mười một lợi ích của tâm từ — 108

**EN**
Eleven benefits of loving-kindness — 108

**VI**
Thất bại của tâm từ — 121

**EN**
Failure of loving-kindness — 121

**VI**
Thành tựu của tâm từ — 121

**EN**
Success of loving-kindness — 121

**VI**
Phương thức tu tập tâm từ — 104

**EN**
The method for developing loving-kindness — 104

**VI**
Những hạng người cản trở việc tu tập tâm từ — 91

**EN**
People who present obstacles to developing loving-kindness — 91

**VI**
Một câu hỏi nên hỏi — 119

**EN**
A question worth asking — 119

**VI**
Mỗi khi quán một phần bất kỳ — 14

**EN**
Whenever discerning any one part — 14

**VI**
Như gỡ bánh ra khỏi chảo — 61

**EN**
Like taking a cake out of a pan — 61

**VI**
Gần với ghét bỏ và yêu luyến — 115

**EN**
Close to aversion and attachment — 115

**VI**
Trong chế định thế gian gọi là đất — 39

**EN**
Conventionally called earth in the world — 39

**VI**
Điểm đặc biệt cần ghi nhớ — 74

**EN**
A particular point to remember — 74

**VI**
[ယ]

**EN**
[ယ]

**VI**
Người có như lý tác ý (yonisomanasikāra) — 31

**EN**
A person who attends wisely (yonisomanasikāra) — 31

**VI**
Hãy quán cho thấy được tâm thiền ấy — 68

**EN**
Discern until you can see that jhāna consciousness — 68

**VI**
[ရ]

**EN**
[ရ]

**VI**
Khiếm khuyết có thể gặp — 39

**EN**
A defect that may occur — 39

**VI**
Kasiṇa nước — 42

**EN**
Water kasiṇa — 42


<a id="M02-index-P006"></a>
## Chỉ mục theo thứ tự chữ Miến — 142 / Index in Burmese alphabetical order — 142
Chỉ mục / Index - Miến / Burmese 142

**VI**
[ရ — tiếp]

**EN**
[ရ — continued]

**VI**
Nước lẫn bọt và bong bóng hiện ra trong tướng — 44

**EN**
Water with foam and bubbles appearing in the sign — 44

**VI**
Có thể chê vì hình dáng bên ngoài — 84

**EN**
It may be criticised for its outward form — 84

**VI**
Như một cột vàng — 48

**EN**
Like a golden pillar — 48

**VI**
[လ]

**EN**
[လ]

**VI**
Đặc tính — phận sự — biểu hiện — nhân gần — 121

**EN**
Characteristic, function, manifestation, and proximate cause — 121

**VI**
Kasiṇa đỏ (lohitakasiṇa) — 34

**EN**
Red kasiṇa (lohitakasiṇa) — 34

**VI**
Rõ như vật đặt trong lòng bàn tay — 112

**EN**
As clear as an object placed in the palm of the hand — 112

**VI**
Tử thi bất tịnh cùng giới tính — 129

**EN**
A corpse of the same sex as an object of foulness — 129

**VI**
Trình tự thực hành — 80

**EN**
Sequence of practice — 80

**VI**
Ba con đường — 4

**EN**
Three paths — 4

**VI**
Cảnh kasiṇa có thể bao trùm và chế ngự — 17

**EN**
A kasiṇa object can be extended and mastered — 17

**VI**
[ဝ]

**EN**
[ဝ]

**VI**
Người nằm sau khi ăn no — 130

**EN**
A person lying down after eating their fill — 130

**VI**
Kasiṇa màu sắc (vaṇṇakasiṇa) — 15

**EN**
Colour kasiṇa (vaṇṇakasiṇa) — 15

**VI**
Bốn loại kasiṇa màu sắc — 15

**EN**
The four colour kasiṇas — 15

**VI**
Kasiṇa gió (vāyokasiṇa) — 48

**EN**
Wind kasiṇa (vāyokasiṇa) — 48

**VI**
Thiền Thức vô biên xứ (viññāṇañcāyatanajhāna) — 66

**EN**
Jhāna of the base of infinite consciousness (viññāṇañcāyatanajhāna) — 66

**VI**
Người đang tiến đến thiền Thức vô biên xứ — 68

**EN**
One proceeding towards the jhāna of the base of infinite consciousness — 68

**VI**
Vượt qua Thức vô biên xứ (viññāṇañcāyatanaṃ samatikkamma) — 77

**EN**
Surmounting the base of infinite consciousness (viññāṇañcāyatanaṃ samatikkamma) — 77

**VI**
Để chống lại các loại tầm — 135

**EN**
To counter the various kinds of thought — 135

**VI**
Thất bại (vipatti) — 125

**EN**
Failure (vipatti) — 125

**VI**
[သ]

**EN**
[သ]

**VI**
Điều cần ghi nhớ — 12

**EN**
A point to remember — 12

**VI**
Từ bỏ cách nắm giữ đối tượng là chúng sinh — 13

**EN**
Giving up the way of apprehending the object as a being — 13

**VI**
Phá bỏ ranh giới giữa các hạng người (sīmāsambheda) — 99

**EN**
Breaking down the barriers between classes of people (sīmāsambheda) — 99

**VI**
Màu đẹp (suvaṇṇa) — 21

**EN**
An attractive colour (suvaṇṇa) — 21

**VI**
Sự trong sáng của ý môn hữu phần lúc gần chết — 133

**EN**
Clarity of the bhavaṅga mind-door near death — 133

**VI**
Ba mươi hai thân phần (koṭṭhāsa) — 2

**EN**
Thirty-two bodily parts (koṭṭhāsa) — 2

**VI**
Có thể không chịu nổi — 40

**EN**
It may become unbearable — 40
